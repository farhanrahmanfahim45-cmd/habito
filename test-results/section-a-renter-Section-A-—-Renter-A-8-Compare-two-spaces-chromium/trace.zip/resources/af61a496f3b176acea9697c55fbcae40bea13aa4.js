import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/NotFound.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=9ceb86a3"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("D:/I2I Project - Habito/App Folder/habito/src/pages/NotFound.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=9ceb86a3";
import { Compass } from "/node_modules/.vite/deps/lucide-react.js?v=9ceb86a3";
import { Button } from "/src/components/ui/Button.tsx";
export default function NotFound() {
  return /* @__PURE__ */ jsxDEV("div", { className: "container-page py-24 text-center", children: [
    /* @__PURE__ */ jsxDEV("span", { className: "mx-auto mb-5 flex size-12 items-center justify-center rounded-full bg-aqua-100 text-aqua-700", children: /* @__PURE__ */ jsxDEV(Compass, { size: 22, "aria-hidden": true }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/NotFound.tsx",
      lineNumber: 28,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/NotFound.tsx",
      lineNumber: 27,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("h1", { className: "font-display text-2xl font-bold text-ink", children: "That page isn't here." }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/NotFound.tsx",
      lineNumber: 30,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("p", { className: "mx-auto mt-2 max-w-sm text-sm text-muted", children: "The link may be out of date. Start from Explore and you'll find your way back." }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/NotFound.tsx",
      lineNumber: 31,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Link, { to: "/explore", className: "mt-6 inline-block", children: /* @__PURE__ */ jsxDEV(Button, { children: "Explore spaces" }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/NotFound.tsx",
      lineNumber: 35,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/NotFound.tsx",
      lineNumber: 34,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/NotFound.tsx",
    lineNumber: 26,
    columnNumber: 5
  }, this);
}
_c = NotFound;
var _c;
$RefreshReg$(_c, "NotFound");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/I2I Project - Habito/App Folder/habito/src/pages/NotFound.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/I2I Project - Habito/App Folder/habito/src/pages/NotFound.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBUVE7Ozs7Ozs7Ozs7Ozs7Ozs7QUFSUixTQUFTQSxZQUFZO0FBQ3JCLFNBQVNDLGVBQWU7QUFDeEIsU0FBU0MsY0FBYztBQUV2Qix3QkFBd0JDLFdBQVc7QUFDakMsU0FDRSx1QkFBQyxTQUFJLFdBQVUsb0NBQ2I7QUFBQSwyQkFBQyxVQUFLLFdBQVUsZ0dBQ2QsaUNBQUMsV0FBUSxNQUFNLElBQUksZUFBVyxRQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQThCLEtBRGhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLElBQ0EsdUJBQUMsUUFBRyxXQUFVLDRDQUEyQyxxQ0FBekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE4RTtBQUFBLElBQzlFLHVCQUFDLE9BQUUsV0FBVSw0Q0FBMEMsOEZBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLElBQ0EsdUJBQUMsUUFBSyxJQUFHLFlBQVcsV0FBVSxxQkFDNUIsaUNBQUMsVUFBTyw4QkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXNCLEtBRHhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLE9BVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVdBO0FBRUo7QUFBQ0MsS0FmdUJEO0FBQVEsSUFBQUM7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsiTGluayIsIkNvbXBhc3MiLCJCdXR0b24iLCJOb3RGb3VuZCIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIk5vdEZvdW5kLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBMaW5rIH0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIjtcbmltcG9ydCB7IENvbXBhc3MgfSBmcm9tIFwibHVjaWRlLXJlYWN0XCI7XG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tIFwiQC9jb21wb25lbnRzL3VpL0J1dHRvblwiO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBOb3RGb3VuZCgpIHtcbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbnRhaW5lci1wYWdlIHB5LTI0IHRleHQtY2VudGVyXCI+XG4gICAgICA8c3BhbiBjbGFzc05hbWU9XCJteC1hdXRvIG1iLTUgZmxleCBzaXplLTEyIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciByb3VuZGVkLWZ1bGwgYmctYXF1YS0xMDAgdGV4dC1hcXVhLTcwMFwiPlxuICAgICAgICA8Q29tcGFzcyBzaXplPXsyMn0gYXJpYS1oaWRkZW4gLz5cbiAgICAgIDwvc3Bhbj5cbiAgICAgIDxoMSBjbGFzc05hbWU9XCJmb250LWRpc3BsYXkgdGV4dC0yeGwgZm9udC1ib2xkIHRleHQtaW5rXCI+VGhhdCBwYWdlIGlzbid0IGhlcmUuPC9oMT5cbiAgICAgIDxwIGNsYXNzTmFtZT1cIm14LWF1dG8gbXQtMiBtYXgtdy1zbSB0ZXh0LXNtIHRleHQtbXV0ZWRcIj5cbiAgICAgICAgVGhlIGxpbmsgbWF5IGJlIG91dCBvZiBkYXRlLiBTdGFydCBmcm9tIEV4cGxvcmUgYW5kIHlvdSdsbCBmaW5kIHlvdXIgd2F5IGJhY2suXG4gICAgICA8L3A+XG4gICAgICA8TGluayB0bz1cIi9leHBsb3JlXCIgY2xhc3NOYW1lPVwibXQtNiBpbmxpbmUtYmxvY2tcIj5cbiAgICAgICAgPEJ1dHRvbj5FeHBsb3JlIHNwYWNlczwvQnV0dG9uPlxuICAgICAgPC9MaW5rPlxuICAgIDwvZGl2PlxuICApO1xufVxuIl0sImZpbGUiOiJEOi9JMkkgUHJvamVjdCAtIEhhYml0by9BcHAgRm9sZGVyL2hhYml0by9zcmMvcGFnZXMvTm90Rm91bmQudHN4In0=