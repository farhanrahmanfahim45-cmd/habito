import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/@fs/D:\\I2I Project - Habito\\App Folder\\habito\\src\\components\\layout\\PageHeader.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=9ceb86a3"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("D:/I2I Project - Habito/App Folder/habito/src/components/layout/PageHeader.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
export function PageHeader({
  title,
  lead,
  actions
}) {
  return /* @__PURE__ */ jsxDEV("div", { className: "border-b border-hairline bg-surface", children: /* @__PURE__ */ jsxDEV("div", { className: "container-page flex flex-wrap items-end justify-between gap-4 py-8 md:py-10", children: [
    /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("h1", { className: "font-display text-3xl font-bold text-ink sm:text-4xl", children: title }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/layout/PageHeader.tsx",
        lineNumber: 35,
        columnNumber: 11
      }, this),
      lead && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 max-w-xl text-sm leading-relaxed text-muted", children: lead }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/layout/PageHeader.tsx",
        lineNumber: 36,
        columnNumber: 20
      }, this)
    ] }, void 0, true, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/layout/PageHeader.tsx",
      lineNumber: 34,
      columnNumber: 9
    }, this),
    actions
  ] }, void 0, true, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/layout/PageHeader.tsx",
    lineNumber: 33,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/layout/PageHeader.tsx",
    lineNumber: 32,
    columnNumber: 5
  }, this);
}
_c = PageHeader;
var _c;
$RefreshReg$(_c, "PageHeader");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/I2I Project - Habito/App Folder/habito/src/components/layout/PageHeader.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/I2I Project - Habito/App Folder/habito/src/components/layout/PageHeader.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZVU7Ozs7Ozs7Ozs7Ozs7Ozs7QUFiSCxnQkFBU0EsV0FBVztBQUFBLEVBQ3pCQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUtGLEdBQUc7QUFDRCxTQUNFLHVCQUFDLFNBQUksV0FBVSx1Q0FDYixpQ0FBQyxTQUFJLFdBQVUsK0VBQ2I7QUFBQSwyQkFBQyxTQUNDO0FBQUEsNkJBQUMsUUFBRyxXQUFVLHdEQUF3REYsbUJBQXRFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNEU7QUFBQSxNQUMzRUMsUUFBUSx1QkFBQyxPQUFFLFdBQVUsb0RBQW9EQSxrQkFBakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFzRTtBQUFBLFNBRmpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQTtBQUFBLElBQ0NDO0FBQUFBLE9BTEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQU1BLEtBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVFBO0FBRUo7QUFBQ0MsS0FwQmVKO0FBQVUsSUFBQUk7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsiUGFnZUhlYWRlciIsInRpdGxlIiwibGVhZCIsImFjdGlvbnMiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJQYWdlSGVhZGVyLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgdHlwZSB7IFJlYWN0Tm9kZSB9IGZyb20gXCJyZWFjdFwiO1xuXG5leHBvcnQgZnVuY3Rpb24gUGFnZUhlYWRlcih7XG4gIHRpdGxlLFxuICBsZWFkLFxuICBhY3Rpb25zLFxufToge1xuICB0aXRsZTogc3RyaW5nO1xuICBsZWFkPzogc3RyaW5nO1xuICBhY3Rpb25zPzogUmVhY3ROb2RlO1xufSkge1xuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9yZGVyLWIgYm9yZGVyLWhhaXJsaW5lIGJnLXN1cmZhY2VcIj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29udGFpbmVyLXBhZ2UgZmxleCBmbGV4LXdyYXAgaXRlbXMtZW5kIGp1c3RpZnktYmV0d2VlbiBnYXAtNCBweS04IG1kOnB5LTEwXCI+XG4gICAgICAgIDxkaXY+XG4gICAgICAgICAgPGgxIGNsYXNzTmFtZT1cImZvbnQtZGlzcGxheSB0ZXh0LTN4bCBmb250LWJvbGQgdGV4dC1pbmsgc206dGV4dC00eGxcIj57dGl0bGV9PC9oMT5cbiAgICAgICAgICB7bGVhZCAmJiA8cCBjbGFzc05hbWU9XCJtdC0yIG1heC13LXhsIHRleHQtc20gbGVhZGluZy1yZWxheGVkIHRleHQtbXV0ZWRcIj57bGVhZH08L3A+fVxuICAgICAgICA8L2Rpdj5cbiAgICAgICAge2FjdGlvbnN9XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiRDovSTJJIFByb2plY3QgLSBIYWJpdG8vQXBwIEZvbGRlci9oYWJpdG8vc3JjL2NvbXBvbmVudHMvbGF5b3V0L1BhZ2VIZWFkZXIudHN4In0=