import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/@fs/D:\\I2I Project - Habito\\App Folder\\habito\\src\\components\\ui\\LanguageToggle.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=9ceb86a3"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("D:/I2I Project - Habito/App Folder/habito/src/components/ui/LanguageToggle.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useI18n } from "/src/i18n/index.tsx";
import { cn } from "/src/lib/cn.ts";
export function LanguageToggle({ compact }) {
  _s();
  const { language, setLanguage } = useI18n();
  return /* @__PURE__ */ jsxDEV(
    "div",
    {
      role: "group",
      "aria-label": "Language / ভাষা",
      className: cn(
        "inline-flex w-fit items-center rounded-full bg-ivory-deep p-0.5 ring-1 ring-hairline",
        compact ? "gap-0" : "gap-0.5"
      ),
      children: [
        { code: "en", label: "EN", full: "English" },
        { code: "bn", label: "বাং", full: "বাংলা" }
      ].map(
        (option) => /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            lang: option.code,
            "aria-pressed": language === option.code,
            onClick: () => setLanguage(option.code),
            title: option.full,
            className: cn(
              "rounded-full px-2.5 py-1.5 text-xs font-bold transition-colors",
              language === option.code ? "bg-ink text-ivory" : "text-muted hover:text-ink"
            ),
            children: option.label
          },
          option.code,
          false,
          {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/ui/LanguageToggle.tsx",
            lineNumber: 43,
            columnNumber: 7
          },
          this
        )
      )
    },
    void 0,
    false,
    {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/ui/LanguageToggle.tsx",
      lineNumber: 31,
      columnNumber: 5
    },
    this
  );
}
_s(LanguageToggle, "hvelcBH+8MxtdUKJ9i2679Ed6CU=", false, function() {
  return [useI18n];
});
_c = LanguageToggle;
var _c;
$RefreshReg$(_c, "LanguageToggle");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/I2I Project - Habito/App Folder/habito/src/components/ui/LanguageToggle.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/I2I Project - Habito/App Folder/habito/src/components/ui/LanguageToggle.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdUJROzs7Ozs7Ozs7Ozs7Ozs7OztBQXZCUixTQUFTQSxlQUFlO0FBQ3hCLFNBQVNDLFVBQVU7QUFNWixnQkFBU0MsZUFBZSxFQUFFQyxRQUErQixHQUFHO0FBQUFDLEtBQUE7QUFDakUsUUFBTSxFQUFFQyxVQUFVQyxZQUFZLElBQUlOLFFBQVE7QUFFMUMsU0FDRTtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0MsTUFBSztBQUFBLE1BQ0wsY0FBVztBQUFBLE1BQ1gsV0FBV0M7QUFBQUEsUUFDVDtBQUFBLFFBQ0FFLFVBQVUsVUFBVTtBQUFBLE1BQ3RCO0FBQUEsTUFFRTtBQUFBLFFBQ0EsRUFBRUksTUFBTSxNQUFlQyxPQUFPLE1BQU1DLE1BQU0sVUFBVTtBQUFBLFFBQ3BELEVBQUVGLE1BQU0sTUFBZUMsT0FBTyxPQUFPQyxNQUFNLFFBQVE7QUFBQSxNQUFDLEVBQ25EQztBQUFBQSxRQUFJLENBQUNDLFdBQ047QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUVDLE1BQUs7QUFBQSxZQUNMLE1BQU1BLE9BQU9KO0FBQUFBLFlBQ2IsZ0JBQWNGLGFBQWFNLE9BQU9KO0FBQUFBLFlBQ2xDLFNBQVMsTUFBTUQsWUFBWUssT0FBT0osSUFBSTtBQUFBLFlBQ3RDLE9BQU9JLE9BQU9GO0FBQUFBLFlBQ2QsV0FBV1I7QUFBQUEsY0FDVDtBQUFBLGNBQ0FJLGFBQWFNLE9BQU9KLE9BQU8sc0JBQXNCO0FBQUEsWUFDbkQ7QUFBQSxZQUVDSSxpQkFBT0g7QUFBQUE7QUFBQUEsVUFYSEcsT0FBT0o7QUFBQUEsVUFEZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBYUE7QUFBQSxNQUNEO0FBQUE7QUFBQSxJQTFCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUEyQkE7QUFFSjtBQUFDSCxHQWpDZUYsZ0JBQWM7QUFBQSxVQUNNRixPQUFPO0FBQUE7QUFBQSxLQUQzQkU7QUFBYyxJQUFBVTtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJ1c2VJMThuIiwiY24iLCJMYW5ndWFnZVRvZ2dsZSIsImNvbXBhY3QiLCJfcyIsImxhbmd1YWdlIiwic2V0TGFuZ3VhZ2UiLCJjb2RlIiwibGFiZWwiLCJmdWxsIiwibWFwIiwib3B0aW9uIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiTGFuZ3VhZ2VUb2dnbGUudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUkxOG4gfSBmcm9tIFwiQC9pMThuXCI7XG5pbXBvcnQgeyBjbiB9IGZyb20gXCJAL2xpYi9jblwiO1xuXG4vKipcbiAqIExhbmd1YWdlIHN3aXRjaC4gS2VwdCBhcyB0d28gdmlzaWJsZSBsYWJlbHMgcmF0aGVyIHRoYW4gYSBkcm9wZG93biDigJQgZm9yIGFcbiAqIHVzZXIgd2hvIGNhbid0IHJlYWQgdGhlIGN1cnJlbnQgbGFuZ3VhZ2UsIGEgZHJvcGRvd24gaXMgYSBndWVzcy5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIExhbmd1YWdlVG9nZ2xlKHsgY29tcGFjdCB9OiB7IGNvbXBhY3Q/OiBib29sZWFuIH0pIHtcbiAgY29uc3QgeyBsYW5ndWFnZSwgc2V0TGFuZ3VhZ2UgfSA9IHVzZUkxOG4oKTtcblxuICByZXR1cm4gKFxuICAgIDxkaXZcbiAgICAgIHJvbGU9XCJncm91cFwiXG4gICAgICBhcmlhLWxhYmVsPVwiTGFuZ3VhZ2UgLyDgpq3gpr7gprfgpr5cIlxuICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgXCJpbmxpbmUtZmxleCB3LWZpdCBpdGVtcy1jZW50ZXIgcm91bmRlZC1mdWxsIGJnLWl2b3J5LWRlZXAgcC0wLjUgcmluZy0xIHJpbmctaGFpcmxpbmVcIixcbiAgICAgICAgY29tcGFjdCA/IFwiZ2FwLTBcIiA6IFwiZ2FwLTAuNVwiLFxuICAgICAgKX1cbiAgICA+XG4gICAgICB7KFtcbiAgICAgICAgeyBjb2RlOiBcImVuXCIgYXMgY29uc3QsIGxhYmVsOiBcIkVOXCIsIGZ1bGw6IFwiRW5nbGlzaFwiIH0sXG4gICAgICAgIHsgY29kZTogXCJiblwiIGFzIGNvbnN0LCBsYWJlbDogXCLgpqzgpr7gpoJcIiwgZnVsbDogXCLgpqzgpr7gpoLgprLgpr5cIiB9LFxuICAgICAgXSkubWFwKChvcHRpb24pID0+IChcbiAgICAgICAgPGJ1dHRvblxuICAgICAgICAgIGtleT17b3B0aW9uLmNvZGV9XG4gICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgbGFuZz17b3B0aW9uLmNvZGV9XG4gICAgICAgICAgYXJpYS1wcmVzc2VkPXtsYW5ndWFnZSA9PT0gb3B0aW9uLmNvZGV9XG4gICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0TGFuZ3VhZ2Uob3B0aW9uLmNvZGUpfVxuICAgICAgICAgIHRpdGxlPXtvcHRpb24uZnVsbH1cbiAgICAgICAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgICAgICAgXCJyb3VuZGVkLWZ1bGwgcHgtMi41IHB5LTEuNSB0ZXh0LXhzIGZvbnQtYm9sZCB0cmFuc2l0aW9uLWNvbG9yc1wiLFxuICAgICAgICAgICAgbGFuZ3VhZ2UgPT09IG9wdGlvbi5jb2RlID8gXCJiZy1pbmsgdGV4dC1pdm9yeVwiIDogXCJ0ZXh0LW11dGVkIGhvdmVyOnRleHQtaW5rXCIsXG4gICAgICAgICAgKX1cbiAgICAgICAgPlxuICAgICAgICAgIHtvcHRpb24ubGFiZWx9XG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgKSl9XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXSwiZmlsZSI6IkQ6L0kySSBQcm9qZWN0IC0gSGFiaXRvL0FwcCBGb2xkZXIvaGFiaXRvL3NyYy9jb21wb25lbnRzL3VpL0xhbmd1YWdlVG9nZ2xlLnRzeCJ9