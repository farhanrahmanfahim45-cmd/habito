import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Profile.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=9ceb86a3"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("D:/I2I Project - Habito/App Folder/habito/src/pages/Profile.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9ceb86a3"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=9ceb86a3";
import { RotateCcw, Check, Database, HardDrive } from "/node_modules/.vite/deps/lucide-react.js?v=9ceb86a3";
import { useHabito } from "/src/hooks/useHabito.tsx";
import { useAuth } from "/src/hooks/useAuth.tsx";
import { db, usingDatabase } from "/src/lib/api/index.ts";
import { PageHeader } from "/src/components/layout/PageHeader.tsx";
import { Button } from "/src/components/ui/Button.tsx";
import { useToast } from "/src/components/ui/Toast.tsx";
import { money, longDate } from "/src/lib/format.ts";
import { CATEGORY_LABEL } from "/src/types/space.ts";
import { cn } from "/src/lib/cn.ts";
import { useI18n } from "/src/i18n/index.tsx";
import { LanguageToggle } from "/src/components/ui/LanguageToggle.tsx";
import { Store } from "/node_modules/.vite/deps/lucide-react.js?v=9ceb86a3";
const inputClass = "h-11 w-full rounded-xl bg-ivory px-3 text-[0.9375rem] text-ink ring-1 ring-hairline-strong focus:outline-none focus:ring-2 focus:ring-aqua-600";
const VERIFICATION_COPY = {
  verified: { label: "Verified", tone: "bg-ok-100 text-ok-600" },
  pending: { label: "Verification pending", tone: "bg-warn-100 text-warn-700" },
  unverified: { label: "Not verified", tone: "bg-ivory-deep text-muted" }
};
export default function Profile() {
  _s();
  const { role, ownerId, savedIds, compareIds, inquiries, requests, requirements, hasStatedNeeds, refresh } = useHabito();
  const { account, configured, updateProfile, enableOwnerTools } = useAuth();
  const { t } = useI18n();
  const [enabling, setEnabling] = useState(false);
  const { notify } = useToast();
  const [owner, setOwner] = useState(null);
  const [name, setName] = useState(account?.name ?? "");
  const [phone, setPhone] = useState(account?.phone ?? "");
  const [saving, setSaving] = useState(false);
  const [resetting, setResetting] = useState(false);
  useEffect(() => {
    setName(account?.name ?? "");
    setPhone(account?.phone ?? "");
  }, [account]);
  useEffect(() => {
    void db.owner(ownerId).then(setOwner).catch(() => setOwner(null));
  }, [ownerId]);
  const save = async () => {
    setSaving(true);
    try {
      await updateProfile({ name: name.trim(), phone: phone.trim() });
      notify("Profile updated");
    } catch (e) {
      notify(e instanceof Error ? e.message : "Could not save your profile");
    } finally {
      setSaving(false);
    }
  };
  const reset = async () => {
    setResetting(true);
    try {
      await db.reset();
      await refresh();
      notify("Demo data restored");
    } catch (e) {
      notify(e instanceof Error ? e.message : "Could not reset");
    } finally {
      setResetting(false);
    }
  };
  const turnOnOwner = async () => {
    setEnabling(true);
    try {
      await enableOwnerTools();
      notify(t("mode.enabled"));
    } catch (e) {
      notify(e instanceof Error ? e.message : "Could not switch that on");
    } finally {
      setEnabling(false);
    }
  };
  const dirty = account ? name.trim() !== account.name || phone.trim() !== (account.phone ?? "") : false;
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(
      PageHeader,
      {
        title: account ? "Your account" : "Your profile",
        lead: "Enough context for an owner to reply, without handing over your documents."
      },
      void 0,
      false,
      {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Profile.tsx",
        lineNumber: 110,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { className: "container-page grid gap-5 py-8 md:grid-cols-2 md:py-10", children: [
      /* @__PURE__ */ jsxDEV("section", { className: "rounded-card bg-surface p-6 ring-1 ring-hairline", children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "font-display text-lg font-bold text-ink", children: account ? "Profile" : "Demo profile" }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Profile.tsx",
          lineNumber: 117,
          columnNumber: 11
        }, this),
        account ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
          /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-muted", children: [
            "Signed in as ",
            account.email,
            " · ",
            account.role
          ] }, void 0, true, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Profile.tsx",
            lineNumber: 123,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "mt-4 space-y-3", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "mb-1.5 block text-sm font-medium text-ink-soft", children: "Name" }, void 0, false, {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Profile.tsx",
                lineNumber: 129,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("input", { value: name, onChange: (e) => setName(e.target.value), className: inputClass }, void 0, false, {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Profile.tsx",
                lineNumber: 130,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Profile.tsx",
              lineNumber: 128,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("label", { className: "block", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "mb-1.5 block text-sm font-medium text-ink-soft", children: "Phone" }, void 0, false, {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Profile.tsx",
                lineNumber: 133,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  value: phone,
                  onChange: (e) => setPhone(e.target.value),
                  inputMode: "tel",
                  placeholder: "01XXXXXXXXX",
                  className: inputClass
                },
                void 0,
                false,
                {
                  fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Profile.tsx",
                  lineNumber: 134,
                  columnNumber: 19
                },
                this
              )
            ] }, void 0, true, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Profile.tsx",
              lineNumber: 132,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(Button, { size: "sm", disabled: !dirty || saving, onClick: () => void save(), children: [
              /* @__PURE__ */ jsxDEV(Check, { size: 15, "aria-hidden": true }, void 0, false, {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Profile.tsx",
                lineNumber: 143,
                columnNumber: 19
              }, this),
              saving ? "Saving…" : "Save changes"
            ] }, void 0, true, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Profile.tsx",
              lineNumber: 142,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Profile.tsx",
            lineNumber: 127,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "mt-5 border-t border-hairline pt-4", children: [
            /* @__PURE__ */ jsxDEV(
              "span",
              {
                className: cn(
                  "inline-block rounded-full px-2.5 py-1 text-xs font-semibold",
                  VERIFICATION_COPY[account.verification].tone
                ),
                children: VERIFICATION_COPY[account.verification].label
              },
              void 0,
              false,
              {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Profile.tsx",
                lineNumber: 149,
                columnNumber: 17
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-xs leading-relaxed text-muted", children: "Identity verification isn't switched on yet. When it is, Habito will hold only the status shown here — never your NID number, and never anything visible to other users." }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Profile.tsx",
              lineNumber: 157,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Profile.tsx",
            lineNumber: 148,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Profile.tsx",
          lineNumber: 122,
          columnNumber: 11
        }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
          /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-muted", children: [
            "Browsing as a ",
            /* @__PURE__ */ jsxDEV("strong", { className: "font-semibold text-ink", children: role }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Profile.tsx",
              lineNumber: 166,
              columnNumber: 31
            }, this),
            " without an account."
          ] }, void 0, true, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Profile.tsx",
            lineNumber: 165,
            columnNumber: 15
          }, this),
          configured ? /* @__PURE__ */ jsxDEV("div", { className: "mt-4 flex gap-2", children: [
            /* @__PURE__ */ jsxDEV(Link, { to: "/signin", children: /* @__PURE__ */ jsxDEV(Button, { size: "sm", variant: "secondary", children: "Sign in" }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Profile.tsx",
              lineNumber: 171,
              columnNumber: 21
            }, this) }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Profile.tsx",
              lineNumber: 170,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(Link, { to: "/signup", children: /* @__PURE__ */ jsxDEV(Button, { size: "sm", children: "Create an account" }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Profile.tsx",
              lineNumber: 176,
              columnNumber: 21
            }, this) }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Profile.tsx",
              lineNumber: 175,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Profile.tsx",
            lineNumber: 169,
            columnNumber: 13
          }, this) : /* @__PURE__ */ jsxDEV("p", { className: "mt-4 text-xs leading-relaxed text-muted", children: "This build isn't connected to the database, so the role switch in the header stands in for signing in. Everything you do is kept in this browser only." }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Profile.tsx",
            lineNumber: 180,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Profile.tsx",
          lineNumber: 164,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Profile.tsx",
        lineNumber: 116,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("section", { className: "rounded-card bg-surface p-6 ring-1 ring-hairline", children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "font-display text-lg font-bold text-ink", children: t("account.language") }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Profile.tsx",
          lineNumber: 191,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm leading-relaxed text-muted", children: t("account.languageBody") }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Profile.tsx",
          lineNumber: 192,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-4", children: /* @__PURE__ */ jsxDEV(LanguageToggle, {}, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Profile.tsx",
          lineNumber: 194,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Profile.tsx",
          lineNumber: 193,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Profile.tsx",
        lineNumber: 190,
        columnNumber: 9
      }, this),
      account && !account.canOwn && /* @__PURE__ */ jsxDEV("section", { className: "rounded-card bg-surface p-6 ring-1 ring-hairline", children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "flex items-center gap-2 font-display text-lg font-bold text-ink", children: [
          /* @__PURE__ */ jsxDEV(Store, { size: 17, className: "text-coral", "aria-hidden": true }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Profile.tsx",
            lineNumber: 202,
            columnNumber: 15
          }, this),
          t("mode.enableOwner")
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Profile.tsx",
          lineNumber: 201,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "mt-1.5 text-sm leading-relaxed text-muted", children: t("mode.enableOwnerBody") }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Profile.tsx",
          lineNumber: 205,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(Button, { size: "sm", className: "mt-4", disabled: enabling, onClick: () => void turnOnOwner(), children: enabling ? t("auth.working") : t("mode.switchToOwner") }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Profile.tsx",
          lineNumber: 206,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Profile.tsx",
        lineNumber: 200,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("section", { className: "rounded-card bg-surface p-6 ring-1 ring-hairline", children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "font-display text-lg font-bold text-ink", children: t("account.lookingFor") }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Profile.tsx",
          lineNumber: 213,
          columnNumber: 11
        }, this),
        hasStatedNeeds ? /* @__PURE__ */ jsxDEV("dl", { className: "mt-4 space-y-2 text-sm", children: [
          /* @__PURE__ */ jsxDEV(
            Row,
            {
              label: "Category",
              value: requirements.category === "any" ? "Anything" : CATEGORY_LABEL[requirements.category]
            },
            void 0,
            false,
            {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Profile.tsx",
              lineNumber: 216,
              columnNumber: 15
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(Row, { label: "Area", value: requirements.area }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Profile.tsx",
            lineNumber: 220,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(Row, { label: "Budget", value: `${money(requirements.budgetMin)} – ${money(requirements.budgetMax)}` }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Profile.tsx",
            lineNumber: 221,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(Row, { label: "Needed by", value: longDate(requirements.moveInDate) }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Profile.tsx",
            lineNumber: 222,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Profile.tsx",
          lineNumber: 215,
          columnNumber: 11
        }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
          /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-muted", children: "You haven't told us what you need yet." }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Profile.tsx",
            lineNumber: 226,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(Link, { to: "/find", className: "mt-4 inline-block", children: /* @__PURE__ */ jsxDEV(Button, { size: "sm", children: "Tell us what you need" }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Profile.tsx",
            lineNumber: 228,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Profile.tsx",
            lineNumber: 227,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Profile.tsx",
          lineNumber: 225,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Profile.tsx",
        lineNumber: 212,
        columnNumber: 9
      }, this),
      (account?.role === "owner" || !configured) && owner && /* @__PURE__ */ jsxDEV("section", { className: "rounded-card bg-surface p-6 ring-1 ring-hairline", children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "font-display text-lg font-bold text-ink", children: "Owner activity" }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Profile.tsx",
          lineNumber: 236,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("dl", { className: "mt-4 space-y-2 text-sm", children: [
          /* @__PURE__ */ jsxDEV(Row, { label: "Response rate", value: `${owner.responseRate}%` }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Profile.tsx",
            lineNumber: 238,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(Row, { label: "Usual reply", value: `Within ${owner.responseTimeHours}h` }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Profile.tsx",
            lineNumber: 239,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(Row, { label: "Member since", value: longDate(owner.memberSince) }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Profile.tsx",
            lineNumber: 240,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Profile.tsx",
          lineNumber: 237,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(Link, { to: "/portfolio", className: "mt-4 inline-block", children: /* @__PURE__ */ jsxDEV(Button, { size: "sm", variant: "secondary", children: "Open my spaces" }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Profile.tsx",
          lineNumber: 243,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Profile.tsx",
          lineNumber: 242,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Profile.tsx",
        lineNumber: 235,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("section", { className: "rounded-card bg-surface p-6 ring-1 ring-hairline", children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "flex items-center gap-2 font-display text-lg font-bold text-ink", children: [
          usingDatabase ? /* @__PURE__ */ jsxDEV(Database, { size: 17, className: "text-aqua-600", "aria-hidden": true }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Profile.tsx",
            lineNumber: 253,
            columnNumber: 13
          }, this) : /* @__PURE__ */ jsxDEV(HardDrive, { size: 17, className: "text-muted", "aria-hidden": true }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Profile.tsx",
            lineNumber: 255,
            columnNumber: 13
          }, this),
          usingDatabase ? "Your data" : "This device"
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Profile.tsx",
          lineNumber: 251,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("dl", { className: "mt-4 space-y-2 text-sm", children: [
          /* @__PURE__ */ jsxDEV(Row, { label: "Saved spaces", value: String(savedIds.length) }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Profile.tsx",
            lineNumber: 261,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(Row, { label: "In compare", value: String(compareIds.length) }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Profile.tsx",
            lineNumber: 262,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(Row, { label: "Inquiries", value: String(inquiries.length) }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Profile.tsx",
            lineNumber: 263,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(Row, { label: "Requests posted", value: String(requests.length) }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Profile.tsx",
            lineNumber: 264,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Profile.tsx",
          lineNumber: 260,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "mt-4 text-xs leading-relaxed text-muted", children: usingDatabase ? "Your listings, saved spaces and messages live in Habito's database, so they follow your account onto any device." : "Habito is running without a database, so this activity is stored in this browser alone and isn't shared with anyone." }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Profile.tsx",
          lineNumber: 267,
          columnNumber: 11
        }, this),
        !usingDatabase && /* @__PURE__ */ jsxDEV(Button, { variant: "secondary", size: "sm", className: "mt-4", disabled: resetting, onClick: () => void reset(), children: [
          /* @__PURE__ */ jsxDEV(RotateCcw, { size: 14, "aria-hidden": true }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Profile.tsx",
            lineNumber: 275,
            columnNumber: 15
          }, this),
          resetting ? "Resetting…" : "Reset demo data"
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Profile.tsx",
          lineNumber: 274,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Profile.tsx",
        lineNumber: 250,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Profile.tsx",
      lineNumber: 115,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Profile.tsx",
    lineNumber: 109,
    columnNumber: 5
  }, this);
}
_s(Profile, "ovvDbFmUKgT7Z5M+FhofzLnGwBk=", false, function() {
  return [useHabito, useAuth, useI18n, useToast];
});
_c = Profile;
function Row({ label, value }) {
  return /* @__PURE__ */ jsxDEV("div", { className: "flex items-baseline justify-between gap-3", children: [
    /* @__PURE__ */ jsxDEV("dt", { className: "text-ink-soft", children: label }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Profile.tsx",
      lineNumber: 288,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("dd", { className: "font-semibold text-ink", children: value }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Profile.tsx",
      lineNumber: 289,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Profile.tsx",
    lineNumber: 287,
    columnNumber: 5
  }, this);
}
_c2 = Row;
var _c, _c2;
$RefreshReg$(_c, "Profile");
$RefreshReg$(_c2, "Row");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/I2I Project - Habito/App Folder/habito/src/pages/Profile.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/I2I Project - Habito/App Folder/habito/src/pages/Profile.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMEZNLFNBWU0sVUFaTjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUExRk4sU0FBU0EsV0FBV0MsZ0JBQWdCO0FBQ3BDLFNBQVNDLFlBQVk7QUFDckIsU0FBU0MsV0FBV0MsT0FBT0MsVUFBVUMsaUJBQWlCO0FBQ3RELFNBQVNDLGlCQUFpQjtBQUMxQixTQUFTQyxlQUFlO0FBQ3hCLFNBQVNDLElBQUlDLHFCQUFxQjtBQUNsQyxTQUFTQyxrQkFBa0I7QUFDM0IsU0FBU0MsY0FBYztBQUN2QixTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0MsT0FBT0MsZ0JBQWdCO0FBQ2hDLFNBQVNDLHNCQUFzQjtBQUUvQixTQUFTQyxVQUFVO0FBQ25CLFNBQVNDLGVBQWU7QUFDeEIsU0FBU0Msc0JBQXNCO0FBQy9CLFNBQVNDLGFBQWE7QUFFdEIsTUFBTUMsYUFDSjtBQUVGLE1BQU1DLG9CQUFvQjtBQUFBLEVBQ3hCQyxVQUFVLEVBQUVDLE9BQU8sWUFBWUMsTUFBTSx3QkFBd0I7QUFBQSxFQUM3REMsU0FBUyxFQUFFRixPQUFPLHdCQUF3QkMsTUFBTSw0QkFBNEI7QUFBQSxFQUM1RUUsWUFBWSxFQUFFSCxPQUFPLGdCQUFnQkMsTUFBTSwyQkFBMkI7QUFDeEU7QUFFQSx3QkFBd0JHLFVBQVU7QUFBQUMsS0FBQTtBQUNoQyxRQUFNLEVBQUVDLE1BQU1DLFNBQVNDLFVBQVVDLFlBQVlDLFdBQVdDLFVBQVVDLGNBQWNDLGdCQUFnQkMsUUFBUSxJQUN0Ry9CLFVBQVU7QUFDWixRQUFNLEVBQUVnQyxTQUFTQyxZQUFZQyxlQUFlQyxpQkFBaUIsSUFBSWxDLFFBQVE7QUFDekUsUUFBTSxFQUFFbUMsRUFBRSxJQUFJekIsUUFBUTtBQUN0QixRQUFNLENBQUMwQixVQUFVQyxXQUFXLElBQUk1QyxTQUFTLEtBQUs7QUFDOUMsUUFBTSxFQUFFNkMsT0FBTyxJQUFJakMsU0FBUztBQUU1QixRQUFNLENBQUNrQyxPQUFPQyxRQUFRLElBQUkvQyxTQUF1QixJQUFJO0FBQ3JELFFBQU0sQ0FBQ2dELE1BQU1DLE9BQU8sSUFBSWpELFNBQVNzQyxTQUFTVSxRQUFRLEVBQUU7QUFDcEQsUUFBTSxDQUFDRSxPQUFPQyxRQUFRLElBQUluRCxTQUFTc0MsU0FBU1ksU0FBUyxFQUFFO0FBQ3ZELFFBQU0sQ0FBQ0UsUUFBUUMsU0FBUyxJQUFJckQsU0FBUyxLQUFLO0FBQzFDLFFBQU0sQ0FBQ3NELFdBQVdDLFlBQVksSUFBSXZELFNBQVMsS0FBSztBQUVoREQsWUFBVSxNQUFNO0FBQ2RrRCxZQUFRWCxTQUFTVSxRQUFRLEVBQUU7QUFDM0JHLGFBQVNiLFNBQVNZLFNBQVMsRUFBRTtBQUFBLEVBQy9CLEdBQUcsQ0FBQ1osT0FBTyxDQUFDO0FBRVp2QyxZQUFVLE1BQU07QUFDZCxTQUFLUyxHQUFHc0MsTUFBTWhCLE9BQU8sRUFBRTBCLEtBQUtULFFBQVEsRUFBRVUsTUFBTSxNQUFNVixTQUFTLElBQUksQ0FBQztBQUFBLEVBQ2xFLEdBQUcsQ0FBQ2pCLE9BQU8sQ0FBQztBQUVaLFFBQU00QixPQUFPLFlBQVk7QUFDdkJMLGNBQVUsSUFBSTtBQUNkLFFBQUk7QUFDRixZQUFNYixjQUFjLEVBQUVRLE1BQU1BLEtBQUtXLEtBQUssR0FBR1QsT0FBT0EsTUFBTVMsS0FBSyxFQUFFLENBQUM7QUFDOURkLGFBQU8saUJBQWlCO0FBQUEsSUFDMUIsU0FBU2UsR0FBRztBQUNWZixhQUFPZSxhQUFhQyxRQUFRRCxFQUFFRSxVQUFVLDZCQUE2QjtBQUFBLElBQ3ZFLFVBQUM7QUFDQ1QsZ0JBQVUsS0FBSztBQUFBLElBQ2pCO0FBQUEsRUFDRjtBQUVBLFFBQU1VLFFBQVEsWUFBWTtBQUN4QlIsaUJBQWEsSUFBSTtBQUNqQixRQUFJO0FBQ0YsWUFBTS9DLEdBQUd1RCxNQUFNO0FBQ2YsWUFBTTFCLFFBQVE7QUFDZFEsYUFBTyxvQkFBb0I7QUFBQSxJQUM3QixTQUFTZSxHQUFHO0FBQ1ZmLGFBQU9lLGFBQWFDLFFBQVFELEVBQUVFLFVBQVUsaUJBQWlCO0FBQUEsSUFDM0QsVUFBQztBQUNDUCxtQkFBYSxLQUFLO0FBQUEsSUFDcEI7QUFBQSxFQUNGO0FBRUEsUUFBTVMsY0FBYyxZQUFZO0FBQzlCcEIsZ0JBQVksSUFBSTtBQUNoQixRQUFJO0FBQ0YsWUFBTUgsaUJBQWlCO0FBQ3ZCSSxhQUFPSCxFQUFFLGNBQWMsQ0FBQztBQUFBLElBQzFCLFNBQVNrQixHQUFHO0FBQ1ZmLGFBQU9lLGFBQWFDLFFBQVFELEVBQUVFLFVBQVUsMEJBQTBCO0FBQUEsSUFDcEUsVUFBQztBQUNDbEIsa0JBQVksS0FBSztBQUFBLElBQ25CO0FBQUEsRUFDRjtBQUVBLFFBQU1xQixRQUFRM0IsVUFBVVUsS0FBS1csS0FBSyxNQUFNckIsUUFBUVUsUUFBUUUsTUFBTVMsS0FBSyxPQUFPckIsUUFBUVksU0FBUyxNQUFNO0FBRWpHLFNBQ0UsbUNBQ0U7QUFBQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsT0FBT1osVUFBVSxpQkFBaUI7QUFBQSxRQUNsQyxNQUFLO0FBQUE7QUFBQSxNQUZQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUVtRjtBQUFBLElBR25GLHVCQUFDLFNBQUksV0FBVSwwREFDYjtBQUFBLDZCQUFDLGFBQVEsV0FBVSxvREFDakI7QUFBQSwrQkFBQyxRQUFHLFdBQVUsMkNBQ1hBLG9CQUFVLFlBQVksa0JBRHpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBRUNBLFVBQ0MsbUNBQ0U7QUFBQSxpQ0FBQyxPQUFFLFdBQVUsMkJBQXlCO0FBQUE7QUFBQSxZQUN0QkEsUUFBUTRCO0FBQUFBLFlBQU07QUFBQSxZQUFJNUIsUUFBUVQ7QUFBQUEsZUFEMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBRUEsdUJBQUMsU0FBSSxXQUFVLGtCQUNiO0FBQUEsbUNBQUMsV0FBTSxXQUFVLFNBQ2Y7QUFBQSxxQ0FBQyxVQUFLLFdBQVUsa0RBQWlELG9CQUFqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFxRTtBQUFBLGNBQ3JFLHVCQUFDLFdBQU0sT0FBT21CLE1BQU0sVUFBVSxDQUFDWSxNQUFNWCxRQUFRVyxFQUFFTyxPQUFPQyxLQUFLLEdBQUcsV0FBV2hELGNBQXpFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW9GO0FBQUEsaUJBRnRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxZQUNBLHVCQUFDLFdBQU0sV0FBVSxTQUNmO0FBQUEscUNBQUMsVUFBSyxXQUFVLGtEQUFpRCxxQkFBakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBc0U7QUFBQSxjQUN0RTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxPQUFPOEI7QUFBQUEsa0JBQ1AsVUFBVSxDQUFDVSxNQUFNVCxTQUFTUyxFQUFFTyxPQUFPQyxLQUFLO0FBQUEsa0JBQ3hDLFdBQVU7QUFBQSxrQkFDVixhQUFZO0FBQUEsa0JBQ1osV0FBV2hEO0FBQUFBO0FBQUFBLGdCQUxiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUt3QjtBQUFBLGlCQVAxQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVNBO0FBQUEsWUFDQSx1QkFBQyxVQUFPLE1BQUssTUFBSyxVQUFVLENBQUM2QyxTQUFTYixRQUFRLFNBQVMsTUFBTSxLQUFLTSxLQUFLLEdBQ3JFO0FBQUEscUNBQUMsU0FBTSxNQUFNLElBQUksZUFBVyxRQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE0QjtBQUFBLGNBQzNCTixTQUFTLFlBQVk7QUFBQSxpQkFGeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLGVBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBbUJBO0FBQUEsVUFFQSx1QkFBQyxTQUFJLFdBQVUsc0NBQ2I7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFdBQVdwQztBQUFBQSxrQkFDVDtBQUFBLGtCQUNBSyxrQkFBa0JpQixRQUFRK0IsWUFBWSxFQUFFN0M7QUFBQUEsZ0JBQzFDO0FBQUEsZ0JBRUNILDRCQUFrQmlCLFFBQVErQixZQUFZLEVBQUU5QztBQUFBQTtBQUFBQSxjQU4zQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFPQTtBQUFBLFlBQ0EsdUJBQUMsT0FBRSxXQUFVLDJDQUF5Qyx3TEFBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLGVBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFhQTtBQUFBLGFBdkNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF3Q0EsSUFFQSxtQ0FDRTtBQUFBLGlDQUFDLE9BQUUsV0FBVSwyQkFBeUI7QUFBQTtBQUFBLFlBQ3RCLHVCQUFDLFlBQU8sV0FBVSwwQkFBMEJNLGtCQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFpRDtBQUFBLFlBQVM7QUFBQSxlQUQxRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQ1UsYUFDQyx1QkFBQyxTQUFJLFdBQVUsbUJBQ2I7QUFBQSxtQ0FBQyxRQUFLLElBQUcsV0FDUCxpQ0FBQyxVQUFPLE1BQUssTUFBSyxTQUFRLGFBQVcsdUJBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUlBO0FBQUEsWUFDQSx1QkFBQyxRQUFLLElBQUcsV0FDUCxpQ0FBQyxVQUFPLE1BQUssTUFBSyxpQ0FBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBbUMsS0FEckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFTQSxJQUVBLHVCQUFDLE9BQUUsV0FBVSwyQ0FBeUMsc0tBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxhQW5CSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBcUJBO0FBQUEsV0FyRUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXVFQTtBQUFBLE1BR0EsdUJBQUMsYUFBUSxXQUFVLG9EQUNqQjtBQUFBLCtCQUFDLFFBQUcsV0FBVSwyQ0FBMkNHLFlBQUUsa0JBQWtCLEtBQTdFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBK0U7QUFBQSxRQUMvRSx1QkFBQyxPQUFFLFdBQVUsMkNBQTJDQSxZQUFFLHNCQUFzQixLQUFoRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtGO0FBQUEsUUFDbEYsdUJBQUMsU0FBSSxXQUFVLFFBQ2IsaUNBQUMsb0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFlLEtBRGpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU1BO0FBQUEsTUFHQ0osV0FBVyxDQUFDQSxRQUFRZ0MsVUFDbkIsdUJBQUMsYUFBUSxXQUFVLG9EQUNqQjtBQUFBLCtCQUFDLFFBQUcsV0FBVSxtRUFDWjtBQUFBLGlDQUFDLFNBQU0sTUFBTSxJQUFJLFdBQVUsY0FBYSxlQUFXLFFBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1EO0FBQUEsVUFDbEQ1QixFQUFFLGtCQUFrQjtBQUFBLGFBRnZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBQ0EsdUJBQUMsT0FBRSxXQUFVLDZDQUE2Q0EsWUFBRSxzQkFBc0IsS0FBbEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFvRjtBQUFBLFFBQ3BGLHVCQUFDLFVBQU8sTUFBSyxNQUFLLFdBQVUsUUFBTyxVQUFVQyxVQUFVLFNBQVMsTUFBTSxLQUFLcUIsWUFBWSxHQUNwRnJCLHFCQUFXRCxFQUFFLGNBQWMsSUFBSUEsRUFBRSxvQkFBb0IsS0FEeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBU0E7QUFBQSxNQUdGLHVCQUFDLGFBQVEsV0FBVSxvREFDakI7QUFBQSwrQkFBQyxRQUFHLFdBQVUsMkNBQTJDQSxZQUFFLG9CQUFvQixLQUEvRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWlGO0FBQUEsUUFDaEZOLGlCQUNDLHVCQUFDLFFBQUcsV0FBVSwwQkFDWjtBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxPQUFNO0FBQUEsY0FDTixPQUFPRCxhQUFhb0MsYUFBYSxRQUFRLGFBQWF4RCxlQUFlb0IsYUFBYW9DLFFBQVE7QUFBQTtBQUFBLFlBRjVGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUU4RjtBQUFBLFVBRTlGLHVCQUFDLE9BQUksT0FBTSxRQUFPLE9BQU9wQyxhQUFhcUMsUUFBdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMkM7QUFBQSxVQUMzQyx1QkFBQyxPQUFJLE9BQU0sVUFBUyxPQUFPLEdBQUczRCxNQUFNc0IsYUFBYXNDLFNBQVMsQ0FBQyxNQUFNNUQsTUFBTXNCLGFBQWF1QyxTQUFTLENBQUMsTUFBOUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBaUc7QUFBQSxVQUNqRyx1QkFBQyxPQUFJLE9BQU0sYUFBWSxPQUFPNUQsU0FBU3FCLGFBQWF3QyxVQUFVLEtBQTlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWdFO0FBQUEsYUFQbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVFBLElBRUEsbUNBQ0U7QUFBQSxpQ0FBQyxPQUFFLFdBQVUsMkJBQTBCLHNEQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE2RTtBQUFBLFVBQzdFLHVCQUFDLFFBQUssSUFBRyxTQUFRLFdBQVUscUJBQ3pCLGlDQUFDLFVBQU8sTUFBSyxNQUFLLHFDQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF1QyxLQUR6QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBS0E7QUFBQSxXQWxCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBb0JBO0FBQUEsT0FFRXJDLFNBQVNULFNBQVMsV0FBVyxDQUFDVSxlQUFlTyxTQUM3Qyx1QkFBQyxhQUFRLFdBQVUsb0RBQ2pCO0FBQUEsK0JBQUMsUUFBRyxXQUFVLDJDQUEwQyw4QkFBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzRTtBQUFBLFFBQ3RFLHVCQUFDLFFBQUcsV0FBVSwwQkFDWjtBQUFBLGlDQUFDLE9BQUksT0FBTSxpQkFBZ0IsT0FBTyxHQUFHQSxNQUFNOEIsWUFBWSxPQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEyRDtBQUFBLFVBQzNELHVCQUFDLE9BQUksT0FBTSxlQUFjLE9BQU8sVUFBVTlCLE1BQU0rQixpQkFBaUIsT0FBakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBcUU7QUFBQSxVQUNyRSx1QkFBQyxPQUFJLE9BQU0sZ0JBQWUsT0FBTy9ELFNBQVNnQyxNQUFNZ0MsV0FBVyxLQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE2RDtBQUFBLGFBSC9EO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFJQTtBQUFBLFFBQ0EsdUJBQUMsUUFBSyxJQUFHLGNBQWEsV0FBVSxxQkFDOUIsaUNBQUMsVUFBTyxNQUFLLE1BQUssU0FBUSxhQUFXLDhCQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBSUE7QUFBQSxXQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFZQTtBQUFBLE1BR0YsdUJBQUMsYUFBUSxXQUFVLG9EQUNqQjtBQUFBLCtCQUFDLFFBQUcsV0FBVSxtRUFDWHJFO0FBQUFBLDBCQUNDLHVCQUFDLFlBQVMsTUFBTSxJQUFJLFdBQVUsaUJBQWdCLGVBQVcsUUFBekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBeUQsSUFFekQsdUJBQUMsYUFBVSxNQUFNLElBQUksV0FBVSxjQUFhLGVBQVcsUUFBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBdUQ7QUFBQSxVQUV4REEsZ0JBQWdCLGNBQWM7QUFBQSxhQU5qQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBT0E7QUFBQSxRQUVBLHVCQUFDLFFBQUcsV0FBVSwwQkFDWjtBQUFBLGlDQUFDLE9BQUksT0FBTSxnQkFBZSxPQUFPc0UsT0FBT2hELFNBQVNpRCxNQUFNLEtBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXlEO0FBQUEsVUFDekQsdUJBQUMsT0FBSSxPQUFNLGNBQWEsT0FBT0QsT0FBTy9DLFdBQVdnRCxNQUFNLEtBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXlEO0FBQUEsVUFDekQsdUJBQUMsT0FBSSxPQUFNLGFBQVksT0FBT0QsT0FBTzlDLFVBQVUrQyxNQUFNLEtBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXVEO0FBQUEsVUFDdkQsdUJBQUMsT0FBSSxPQUFNLG1CQUFrQixPQUFPRCxPQUFPN0MsU0FBUzhDLE1BQU0sS0FBMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNEQ7QUFBQSxhQUo5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBS0E7QUFBQSxRQUVBLHVCQUFDLE9BQUUsV0FBVSwyQ0FDVnZFLDBCQUNHLHFIQUNBLDBIQUhOO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFJQTtBQUFBLFFBRUMsQ0FBQ0EsaUJBQ0EsdUJBQUMsVUFBTyxTQUFRLGFBQVksTUFBSyxNQUFLLFdBQVUsUUFBTyxVQUFVNkMsV0FBVyxTQUFTLE1BQU0sS0FBS1MsTUFBTSxHQUNwRztBQUFBLGlDQUFDLGFBQVUsTUFBTSxJQUFJLGVBQVcsUUFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0M7QUFBQSxVQUMvQlQsWUFBWSxlQUFlO0FBQUEsYUFGOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsV0EzQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTZCQTtBQUFBLFNBcEtGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FxS0E7QUFBQSxPQTNLRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBNEtBO0FBRUo7QUFBQzFCLEdBN091QkQsU0FBTztBQUFBLFVBRTNCckIsV0FDK0RDLFNBQ25EVSxTQUVLTCxRQUFRO0FBQUE7QUFBQSxLQU5MZTtBQStPeEIsU0FBU3NELElBQUksRUFBRTFELE9BQU82QyxNQUF3QyxHQUFHO0FBQy9ELFNBQ0UsdUJBQUMsU0FBSSxXQUFVLDZDQUNiO0FBQUEsMkJBQUMsUUFBRyxXQUFVLGlCQUFpQjdDLG1CQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXFDO0FBQUEsSUFDckMsdUJBQUMsUUFBRyxXQUFVLDBCQUEwQjZDLG1CQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQThDO0FBQUEsT0FGaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUdBO0FBRUo7QUFBQ2MsTUFQUUQ7QUFBRyxJQUFBRSxJQUFBRDtBQUFBLGFBQUFDLElBQUE7QUFBQSxhQUFBRCxLQUFBIiwibmFtZXMiOlsidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJMaW5rIiwiUm90YXRlQ2N3IiwiQ2hlY2siLCJEYXRhYmFzZSIsIkhhcmREcml2ZSIsInVzZUhhYml0byIsInVzZUF1dGgiLCJkYiIsInVzaW5nRGF0YWJhc2UiLCJQYWdlSGVhZGVyIiwiQnV0dG9uIiwidXNlVG9hc3QiLCJtb25leSIsImxvbmdEYXRlIiwiQ0FURUdPUllfTEFCRUwiLCJjbiIsInVzZUkxOG4iLCJMYW5ndWFnZVRvZ2dsZSIsIlN0b3JlIiwiaW5wdXRDbGFzcyIsIlZFUklGSUNBVElPTl9DT1BZIiwidmVyaWZpZWQiLCJsYWJlbCIsInRvbmUiLCJwZW5kaW5nIiwidW52ZXJpZmllZCIsIlByb2ZpbGUiLCJfcyIsInJvbGUiLCJvd25lcklkIiwic2F2ZWRJZHMiLCJjb21wYXJlSWRzIiwiaW5xdWlyaWVzIiwicmVxdWVzdHMiLCJyZXF1aXJlbWVudHMiLCJoYXNTdGF0ZWROZWVkcyIsInJlZnJlc2giLCJhY2NvdW50IiwiY29uZmlndXJlZCIsInVwZGF0ZVByb2ZpbGUiLCJlbmFibGVPd25lclRvb2xzIiwidCIsImVuYWJsaW5nIiwic2V0RW5hYmxpbmciLCJub3RpZnkiLCJvd25lciIsInNldE93bmVyIiwibmFtZSIsInNldE5hbWUiLCJwaG9uZSIsInNldFBob25lIiwic2F2aW5nIiwic2V0U2F2aW5nIiwicmVzZXR0aW5nIiwic2V0UmVzZXR0aW5nIiwidGhlbiIsImNhdGNoIiwic2F2ZSIsInRyaW0iLCJlIiwiRXJyb3IiLCJtZXNzYWdlIiwicmVzZXQiLCJ0dXJuT25Pd25lciIsImRpcnR5IiwiZW1haWwiLCJ0YXJnZXQiLCJ2YWx1ZSIsInZlcmlmaWNhdGlvbiIsImNhbk93biIsImNhdGVnb3J5IiwiYXJlYSIsImJ1ZGdldE1pbiIsImJ1ZGdldE1heCIsIm1vdmVJbkRhdGUiLCJyZXNwb25zZVJhdGUiLCJyZXNwb25zZVRpbWVIb3VycyIsIm1lbWJlclNpbmNlIiwiU3RyaW5nIiwibGVuZ3RoIiwiUm93IiwiX2MyIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiUHJvZmlsZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgTGluayB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XG5pbXBvcnQgeyBSb3RhdGVDY3csIENoZWNrLCBEYXRhYmFzZSwgSGFyZERyaXZlIH0gZnJvbSBcImx1Y2lkZS1yZWFjdFwiO1xuaW1wb3J0IHsgdXNlSGFiaXRvIH0gZnJvbSBcIkAvaG9va3MvdXNlSGFiaXRvXCI7XG5pbXBvcnQgeyB1c2VBdXRoIH0gZnJvbSBcIkAvaG9va3MvdXNlQXV0aFwiO1xuaW1wb3J0IHsgZGIsIHVzaW5nRGF0YWJhc2UgfSBmcm9tIFwiQC9saWIvYXBpXCI7XG5pbXBvcnQgeyBQYWdlSGVhZGVyIH0gZnJvbSBcIkAvY29tcG9uZW50cy9sYXlvdXQvUGFnZUhlYWRlclwiO1xuaW1wb3J0IHsgQnV0dG9uIH0gZnJvbSBcIkAvY29tcG9uZW50cy91aS9CdXR0b25cIjtcbmltcG9ydCB7IHVzZVRvYXN0IH0gZnJvbSBcIkAvY29tcG9uZW50cy91aS9Ub2FzdFwiO1xuaW1wb3J0IHsgbW9uZXksIGxvbmdEYXRlIH0gZnJvbSBcIkAvbGliL2Zvcm1hdFwiO1xuaW1wb3J0IHsgQ0FURUdPUllfTEFCRUwgfSBmcm9tIFwiQC90eXBlcy9zcGFjZVwiO1xuaW1wb3J0IHR5cGUgeyBPd25lciB9IGZyb20gXCJAL3R5cGVzL3NwYWNlXCI7XG5pbXBvcnQgeyBjbiB9IGZyb20gXCJAL2xpYi9jblwiO1xuaW1wb3J0IHsgdXNlSTE4biB9IGZyb20gXCJAL2kxOG5cIjtcbmltcG9ydCB7IExhbmd1YWdlVG9nZ2xlIH0gZnJvbSBcIkAvY29tcG9uZW50cy91aS9MYW5ndWFnZVRvZ2dsZVwiO1xuaW1wb3J0IHsgU3RvcmUgfSBmcm9tIFwibHVjaWRlLXJlYWN0XCI7XG5cbmNvbnN0IGlucHV0Q2xhc3MgPVxuICBcImgtMTEgdy1mdWxsIHJvdW5kZWQteGwgYmctaXZvcnkgcHgtMyB0ZXh0LVswLjkzNzVyZW1dIHRleHQtaW5rIHJpbmctMSByaW5nLWhhaXJsaW5lLXN0cm9uZyBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctYXF1YS02MDBcIjtcblxuY29uc3QgVkVSSUZJQ0FUSU9OX0NPUFkgPSB7XG4gIHZlcmlmaWVkOiB7IGxhYmVsOiBcIlZlcmlmaWVkXCIsIHRvbmU6IFwiYmctb2stMTAwIHRleHQtb2stNjAwXCIgfSxcbiAgcGVuZGluZzogeyBsYWJlbDogXCJWZXJpZmljYXRpb24gcGVuZGluZ1wiLCB0b25lOiBcImJnLXdhcm4tMTAwIHRleHQtd2Fybi03MDBcIiB9LFxuICB1bnZlcmlmaWVkOiB7IGxhYmVsOiBcIk5vdCB2ZXJpZmllZFwiLCB0b25lOiBcImJnLWl2b3J5LWRlZXAgdGV4dC1tdXRlZFwiIH0sXG59IGFzIGNvbnN0O1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBQcm9maWxlKCkge1xuICBjb25zdCB7IHJvbGUsIG93bmVySWQsIHNhdmVkSWRzLCBjb21wYXJlSWRzLCBpbnF1aXJpZXMsIHJlcXVlc3RzLCByZXF1aXJlbWVudHMsIGhhc1N0YXRlZE5lZWRzLCByZWZyZXNoIH0gPVxuICAgIHVzZUhhYml0bygpO1xuICBjb25zdCB7IGFjY291bnQsIGNvbmZpZ3VyZWQsIHVwZGF0ZVByb2ZpbGUsIGVuYWJsZU93bmVyVG9vbHMgfSA9IHVzZUF1dGgoKTtcbiAgY29uc3QgeyB0IH0gPSB1c2VJMThuKCk7XG4gIGNvbnN0IFtlbmFibGluZywgc2V0RW5hYmxpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCB7IG5vdGlmeSB9ID0gdXNlVG9hc3QoKTtcblxuICBjb25zdCBbb3duZXIsIHNldE93bmVyXSA9IHVzZVN0YXRlPE93bmVyIHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IFtuYW1lLCBzZXROYW1lXSA9IHVzZVN0YXRlKGFjY291bnQ/Lm5hbWUgPz8gXCJcIik7XG4gIGNvbnN0IFtwaG9uZSwgc2V0UGhvbmVdID0gdXNlU3RhdGUoYWNjb3VudD8ucGhvbmUgPz8gXCJcIik7XG4gIGNvbnN0IFtzYXZpbmcsIHNldFNhdmluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtyZXNldHRpbmcsIHNldFJlc2V0dGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBzZXROYW1lKGFjY291bnQ/Lm5hbWUgPz8gXCJcIik7XG4gICAgc2V0UGhvbmUoYWNjb3VudD8ucGhvbmUgPz8gXCJcIik7XG4gIH0sIFthY2NvdW50XSk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICB2b2lkIGRiLm93bmVyKG93bmVySWQpLnRoZW4oc2V0T3duZXIpLmNhdGNoKCgpID0+IHNldE93bmVyKG51bGwpKTtcbiAgfSwgW293bmVySWRdKTtcblxuICBjb25zdCBzYXZlID0gYXN5bmMgKCkgPT4ge1xuICAgIHNldFNhdmluZyh0cnVlKTtcbiAgICB0cnkge1xuICAgICAgYXdhaXQgdXBkYXRlUHJvZmlsZSh7IG5hbWU6IG5hbWUudHJpbSgpLCBwaG9uZTogcGhvbmUudHJpbSgpIH0pO1xuICAgICAgbm90aWZ5KFwiUHJvZmlsZSB1cGRhdGVkXCIpO1xuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIG5vdGlmeShlIGluc3RhbmNlb2YgRXJyb3IgPyBlLm1lc3NhZ2UgOiBcIkNvdWxkIG5vdCBzYXZlIHlvdXIgcHJvZmlsZVwiKTtcbiAgICB9IGZpbmFsbHkge1xuICAgICAgc2V0U2F2aW5nKGZhbHNlKTtcbiAgICB9XG4gIH07XG5cbiAgY29uc3QgcmVzZXQgPSBhc3luYyAoKSA9PiB7XG4gICAgc2V0UmVzZXR0aW5nKHRydWUpO1xuICAgIHRyeSB7XG4gICAgICBhd2FpdCBkYi5yZXNldCgpO1xuICAgICAgYXdhaXQgcmVmcmVzaCgpO1xuICAgICAgbm90aWZ5KFwiRGVtbyBkYXRhIHJlc3RvcmVkXCIpO1xuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIG5vdGlmeShlIGluc3RhbmNlb2YgRXJyb3IgPyBlLm1lc3NhZ2UgOiBcIkNvdWxkIG5vdCByZXNldFwiKTtcbiAgICB9IGZpbmFsbHkge1xuICAgICAgc2V0UmVzZXR0aW5nKGZhbHNlKTtcbiAgICB9XG4gIH07XG5cbiAgY29uc3QgdHVybk9uT3duZXIgPSBhc3luYyAoKSA9PiB7XG4gICAgc2V0RW5hYmxpbmcodHJ1ZSk7XG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IGVuYWJsZU93bmVyVG9vbHMoKTtcbiAgICAgIG5vdGlmeSh0KFwibW9kZS5lbmFibGVkXCIpKTtcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICBub3RpZnkoZSBpbnN0YW5jZW9mIEVycm9yID8gZS5tZXNzYWdlIDogXCJDb3VsZCBub3Qgc3dpdGNoIHRoYXQgb25cIik7XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldEVuYWJsaW5nKGZhbHNlKTtcbiAgICB9XG4gIH07XG5cbiAgY29uc3QgZGlydHkgPSBhY2NvdW50ID8gbmFtZS50cmltKCkgIT09IGFjY291bnQubmFtZSB8fCBwaG9uZS50cmltKCkgIT09IChhY2NvdW50LnBob25lID8/IFwiXCIpIDogZmFsc2U7XG5cbiAgcmV0dXJuIChcbiAgICA8PlxuICAgICAgPFBhZ2VIZWFkZXJcbiAgICAgICAgdGl0bGU9e2FjY291bnQgPyBcIllvdXIgYWNjb3VudFwiIDogXCJZb3VyIHByb2ZpbGVcIn1cbiAgICAgICAgbGVhZD1cIkVub3VnaCBjb250ZXh0IGZvciBhbiBvd25lciB0byByZXBseSwgd2l0aG91dCBoYW5kaW5nIG92ZXIgeW91ciBkb2N1bWVudHMuXCJcbiAgICAgIC8+XG5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29udGFpbmVyLXBhZ2UgZ3JpZCBnYXAtNSBweS04IG1kOmdyaWQtY29scy0yIG1kOnB5LTEwXCI+XG4gICAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cInJvdW5kZWQtY2FyZCBiZy1zdXJmYWNlIHAtNiByaW5nLTEgcmluZy1oYWlybGluZVwiPlxuICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJmb250LWRpc3BsYXkgdGV4dC1sZyBmb250LWJvbGQgdGV4dC1pbmtcIj5cbiAgICAgICAgICAgIHthY2NvdW50ID8gXCJQcm9maWxlXCIgOiBcIkRlbW8gcHJvZmlsZVwifVxuICAgICAgICAgIDwvaDI+XG5cbiAgICAgICAgICB7YWNjb3VudCA/IChcbiAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC1zbSB0ZXh0LW11dGVkXCI+XG4gICAgICAgICAgICAgICAgU2lnbmVkIGluIGFzIHthY2NvdW50LmVtYWlsfSDCtyB7YWNjb3VudC5yb2xlfVxuICAgICAgICAgICAgICA8L3A+XG5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC00IHNwYWNlLXktM1wiPlxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9ja1wiPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWItMS41IGJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1pbmstc29mdFwiPk5hbWU8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8aW5wdXQgdmFsdWU9e25hbWV9IG9uQ2hhbmdlPXsoZSkgPT4gc2V0TmFtZShlLnRhcmdldC52YWx1ZSl9IGNsYXNzTmFtZT17aW5wdXRDbGFzc30gLz5cbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9ja1wiPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWItMS41IGJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1pbmstc29mdFwiPlBob25lPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtwaG9uZX1cbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRQaG9uZShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgIGlucHV0TW9kZT1cInRlbFwiXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiMDFYWFhYWFhYWFhcIlxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2lucHV0Q2xhc3N9XG4gICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgPEJ1dHRvbiBzaXplPVwic21cIiBkaXNhYmxlZD17IWRpcnR5IHx8IHNhdmluZ30gb25DbGljaz17KCkgPT4gdm9pZCBzYXZlKCl9PlxuICAgICAgICAgICAgICAgICAgPENoZWNrIHNpemU9ezE1fSBhcmlhLWhpZGRlbiAvPlxuICAgICAgICAgICAgICAgICAge3NhdmluZyA/IFwiU2F2aW5n4oCmXCIgOiBcIlNhdmUgY2hhbmdlc1wifVxuICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTUgYm9yZGVyLXQgYm9yZGVyLWhhaXJsaW5lIHB0LTRcIj5cbiAgICAgICAgICAgICAgICA8c3BhblxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgICAgICAgICAgICAgXCJpbmxpbmUtYmxvY2sgcm91bmRlZC1mdWxsIHB4LTIuNSBweS0xIHRleHQteHMgZm9udC1zZW1pYm9sZFwiLFxuICAgICAgICAgICAgICAgICAgICBWRVJJRklDQVRJT05fQ09QWVthY2NvdW50LnZlcmlmaWNhdGlvbl0udG9uZSxcbiAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAge1ZFUklGSUNBVElPTl9DT1BZW2FjY291bnQudmVyaWZpY2F0aW9uXS5sYWJlbH1cbiAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXhzIGxlYWRpbmctcmVsYXhlZCB0ZXh0LW11dGVkXCI+XG4gICAgICAgICAgICAgICAgICBJZGVudGl0eSB2ZXJpZmljYXRpb24gaXNuJ3Qgc3dpdGNoZWQgb24geWV0LiBXaGVuIGl0IGlzLCBIYWJpdG8gd2lsbCBob2xkIG9ubHkgdGhlXG4gICAgICAgICAgICAgICAgICBzdGF0dXMgc2hvd24gaGVyZSDigJQgbmV2ZXIgeW91ciBOSUQgbnVtYmVyLCBhbmQgbmV2ZXIgYW55dGhpbmcgdmlzaWJsZSB0byBvdGhlciB1c2Vycy5cbiAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC8+XG4gICAgICAgICAgKSA6IChcbiAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC1zbSB0ZXh0LW11dGVkXCI+XG4gICAgICAgICAgICAgICAgQnJvd3NpbmcgYXMgYSA8c3Ryb25nIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1pbmtcIj57cm9sZX08L3N0cm9uZz4gd2l0aG91dCBhbiBhY2NvdW50LlxuICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgIHtjb25maWd1cmVkID8gKFxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNCBmbGV4IGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICA8TGluayB0bz1cIi9zaWduaW5cIj5cbiAgICAgICAgICAgICAgICAgICAgPEJ1dHRvbiBzaXplPVwic21cIiB2YXJpYW50PVwic2Vjb25kYXJ5XCI+XG4gICAgICAgICAgICAgICAgICAgICAgU2lnbiBpblxuICAgICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgICAgICAgIDwvTGluaz5cbiAgICAgICAgICAgICAgICAgIDxMaW5rIHRvPVwiL3NpZ251cFwiPlxuICAgICAgICAgICAgICAgICAgICA8QnV0dG9uIHNpemU9XCJzbVwiPkNyZWF0ZSBhbiBhY2NvdW50PC9CdXR0b24+XG4gICAgICAgICAgICAgICAgICA8L0xpbms+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtNCB0ZXh0LXhzIGxlYWRpbmctcmVsYXhlZCB0ZXh0LW11dGVkXCI+XG4gICAgICAgICAgICAgICAgICBUaGlzIGJ1aWxkIGlzbid0IGNvbm5lY3RlZCB0byB0aGUgZGF0YWJhc2UsIHNvIHRoZSByb2xlIHN3aXRjaCBpbiB0aGUgaGVhZGVyIHN0YW5kcyBpblxuICAgICAgICAgICAgICAgICAgZm9yIHNpZ25pbmcgaW4uIEV2ZXJ5dGhpbmcgeW91IGRvIGlzIGtlcHQgaW4gdGhpcyBicm93c2VyIG9ubHkuXG4gICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgPC8+XG4gICAgICAgICAgKX1cbiAgICAgICAgPC9zZWN0aW9uPlxuXG4gICAgICAgIHsvKiBMYW5ndWFnZSAqL31cbiAgICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwicm91bmRlZC1jYXJkIGJnLXN1cmZhY2UgcC02IHJpbmctMSByaW5nLWhhaXJsaW5lXCI+XG4gICAgICAgICAgPGgyIGNsYXNzTmFtZT1cImZvbnQtZGlzcGxheSB0ZXh0LWxnIGZvbnQtYm9sZCB0ZXh0LWlua1wiPnt0KFwiYWNjb3VudC5sYW5ndWFnZVwiKX08L2gyPlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC1zbSBsZWFkaW5nLXJlbGF4ZWQgdGV4dC1tdXRlZFwiPnt0KFwiYWNjb3VudC5sYW5ndWFnZUJvZHlcIil9PC9wPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNFwiPlxuICAgICAgICAgICAgPExhbmd1YWdlVG9nZ2xlIC8+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvc2VjdGlvbj5cblxuICAgICAgICB7LyogT3duZXIgdG9vbHMgb3B0LWluICovfVxuICAgICAgICB7YWNjb3VudCAmJiAhYWNjb3VudC5jYW5Pd24gJiYgKFxuICAgICAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cInJvdW5kZWQtY2FyZCBiZy1zdXJmYWNlIHAtNiByaW5nLTEgcmluZy1oYWlybGluZVwiPlxuICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIGZvbnQtZGlzcGxheSB0ZXh0LWxnIGZvbnQtYm9sZCB0ZXh0LWlua1wiPlxuICAgICAgICAgICAgICA8U3RvcmUgc2l6ZT17MTd9IGNsYXNzTmFtZT1cInRleHQtY29yYWxcIiBhcmlhLWhpZGRlbiAvPlxuICAgICAgICAgICAgICB7dChcIm1vZGUuZW5hYmxlT3duZXJcIil9XG4gICAgICAgICAgICA8L2gyPlxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMS41IHRleHQtc20gbGVhZGluZy1yZWxheGVkIHRleHQtbXV0ZWRcIj57dChcIm1vZGUuZW5hYmxlT3duZXJCb2R5XCIpfTwvcD5cbiAgICAgICAgICAgIDxCdXR0b24gc2l6ZT1cInNtXCIgY2xhc3NOYW1lPVwibXQtNFwiIGRpc2FibGVkPXtlbmFibGluZ30gb25DbGljaz17KCkgPT4gdm9pZCB0dXJuT25Pd25lcigpfT5cbiAgICAgICAgICAgICAge2VuYWJsaW5nID8gdChcImF1dGgud29ya2luZ1wiKSA6IHQoXCJtb2RlLnN3aXRjaFRvT3duZXJcIil9XG4gICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICA8L3NlY3Rpb24+XG4gICAgICAgICl9XG5cbiAgICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwicm91bmRlZC1jYXJkIGJnLXN1cmZhY2UgcC02IHJpbmctMSByaW5nLWhhaXJsaW5lXCI+XG4gICAgICAgICAgPGgyIGNsYXNzTmFtZT1cImZvbnQtZGlzcGxheSB0ZXh0LWxnIGZvbnQtYm9sZCB0ZXh0LWlua1wiPnt0KFwiYWNjb3VudC5sb29raW5nRm9yXCIpfTwvaDI+XG4gICAgICAgICAge2hhc1N0YXRlZE5lZWRzID8gKFxuICAgICAgICAgICAgPGRsIGNsYXNzTmFtZT1cIm10LTQgc3BhY2UteS0yIHRleHQtc21cIj5cbiAgICAgICAgICAgICAgPFJvd1xuICAgICAgICAgICAgICAgIGxhYmVsPVwiQ2F0ZWdvcnlcIlxuICAgICAgICAgICAgICAgIHZhbHVlPXtyZXF1aXJlbWVudHMuY2F0ZWdvcnkgPT09IFwiYW55XCIgPyBcIkFueXRoaW5nXCIgOiBDQVRFR09SWV9MQUJFTFtyZXF1aXJlbWVudHMuY2F0ZWdvcnldfVxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8Um93IGxhYmVsPVwiQXJlYVwiIHZhbHVlPXtyZXF1aXJlbWVudHMuYXJlYX0gLz5cbiAgICAgICAgICAgICAgPFJvdyBsYWJlbD1cIkJ1ZGdldFwiIHZhbHVlPXtgJHttb25leShyZXF1aXJlbWVudHMuYnVkZ2V0TWluKX0g4oCTICR7bW9uZXkocmVxdWlyZW1lbnRzLmJ1ZGdldE1heCl9YH0gLz5cbiAgICAgICAgICAgICAgPFJvdyBsYWJlbD1cIk5lZWRlZCBieVwiIHZhbHVlPXtsb25nRGF0ZShyZXF1aXJlbWVudHMubW92ZUluRGF0ZSl9IC8+XG4gICAgICAgICAgICA8L2RsPlxuICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICA8PlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1tdXRlZFwiPllvdSBoYXZlbid0IHRvbGQgdXMgd2hhdCB5b3UgbmVlZCB5ZXQuPC9wPlxuICAgICAgICAgICAgICA8TGluayB0bz1cIi9maW5kXCIgY2xhc3NOYW1lPVwibXQtNCBpbmxpbmUtYmxvY2tcIj5cbiAgICAgICAgICAgICAgICA8QnV0dG9uIHNpemU9XCJzbVwiPlRlbGwgdXMgd2hhdCB5b3UgbmVlZDwvQnV0dG9uPlxuICAgICAgICAgICAgICA8L0xpbms+XG4gICAgICAgICAgICA8Lz5cbiAgICAgICAgICApfVxuICAgICAgICA8L3NlY3Rpb24+XG5cbiAgICAgICAgeyhhY2NvdW50Py5yb2xlID09PSBcIm93bmVyXCIgfHwgIWNvbmZpZ3VyZWQpICYmIG93bmVyICYmIChcbiAgICAgICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJyb3VuZGVkLWNhcmQgYmctc3VyZmFjZSBwLTYgcmluZy0xIHJpbmctaGFpcmxpbmVcIj5cbiAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJmb250LWRpc3BsYXkgdGV4dC1sZyBmb250LWJvbGQgdGV4dC1pbmtcIj5Pd25lciBhY3Rpdml0eTwvaDI+XG4gICAgICAgICAgICA8ZGwgY2xhc3NOYW1lPVwibXQtNCBzcGFjZS15LTIgdGV4dC1zbVwiPlxuICAgICAgICAgICAgICA8Um93IGxhYmVsPVwiUmVzcG9uc2UgcmF0ZVwiIHZhbHVlPXtgJHtvd25lci5yZXNwb25zZVJhdGV9JWB9IC8+XG4gICAgICAgICAgICAgIDxSb3cgbGFiZWw9XCJVc3VhbCByZXBseVwiIHZhbHVlPXtgV2l0aGluICR7b3duZXIucmVzcG9uc2VUaW1lSG91cnN9aGB9IC8+XG4gICAgICAgICAgICAgIDxSb3cgbGFiZWw9XCJNZW1iZXIgc2luY2VcIiB2YWx1ZT17bG9uZ0RhdGUob3duZXIubWVtYmVyU2luY2UpfSAvPlxuICAgICAgICAgICAgPC9kbD5cbiAgICAgICAgICAgIDxMaW5rIHRvPVwiL3BvcnRmb2xpb1wiIGNsYXNzTmFtZT1cIm10LTQgaW5saW5lLWJsb2NrXCI+XG4gICAgICAgICAgICAgIDxCdXR0b24gc2l6ZT1cInNtXCIgdmFyaWFudD1cInNlY29uZGFyeVwiPlxuICAgICAgICAgICAgICAgIE9wZW4gbXkgc3BhY2VzXG4gICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgPC9MaW5rPlxuICAgICAgICAgIDwvc2VjdGlvbj5cbiAgICAgICAgKX1cblxuICAgICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJyb3VuZGVkLWNhcmQgYmctc3VyZmFjZSBwLTYgcmluZy0xIHJpbmctaGFpcmxpbmVcIj5cbiAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgZm9udC1kaXNwbGF5IHRleHQtbGcgZm9udC1ib2xkIHRleHQtaW5rXCI+XG4gICAgICAgICAgICB7dXNpbmdEYXRhYmFzZSA/IChcbiAgICAgICAgICAgICAgPERhdGFiYXNlIHNpemU9ezE3fSBjbGFzc05hbWU9XCJ0ZXh0LWFxdWEtNjAwXCIgYXJpYS1oaWRkZW4gLz5cbiAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgIDxIYXJkRHJpdmUgc2l6ZT17MTd9IGNsYXNzTmFtZT1cInRleHQtbXV0ZWRcIiBhcmlhLWhpZGRlbiAvPlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIHt1c2luZ0RhdGFiYXNlID8gXCJZb3VyIGRhdGFcIiA6IFwiVGhpcyBkZXZpY2VcIn1cbiAgICAgICAgICA8L2gyPlxuXG4gICAgICAgICAgPGRsIGNsYXNzTmFtZT1cIm10LTQgc3BhY2UteS0yIHRleHQtc21cIj5cbiAgICAgICAgICAgIDxSb3cgbGFiZWw9XCJTYXZlZCBzcGFjZXNcIiB2YWx1ZT17U3RyaW5nKHNhdmVkSWRzLmxlbmd0aCl9IC8+XG4gICAgICAgICAgICA8Um93IGxhYmVsPVwiSW4gY29tcGFyZVwiIHZhbHVlPXtTdHJpbmcoY29tcGFyZUlkcy5sZW5ndGgpfSAvPlxuICAgICAgICAgICAgPFJvdyBsYWJlbD1cIklucXVpcmllc1wiIHZhbHVlPXtTdHJpbmcoaW5xdWlyaWVzLmxlbmd0aCl9IC8+XG4gICAgICAgICAgICA8Um93IGxhYmVsPVwiUmVxdWVzdHMgcG9zdGVkXCIgdmFsdWU9e1N0cmluZyhyZXF1ZXN0cy5sZW5ndGgpfSAvPlxuICAgICAgICAgIDwvZGw+XG5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC00IHRleHQteHMgbGVhZGluZy1yZWxheGVkIHRleHQtbXV0ZWRcIj5cbiAgICAgICAgICAgIHt1c2luZ0RhdGFiYXNlXG4gICAgICAgICAgICAgID8gXCJZb3VyIGxpc3RpbmdzLCBzYXZlZCBzcGFjZXMgYW5kIG1lc3NhZ2VzIGxpdmUgaW4gSGFiaXRvJ3MgZGF0YWJhc2UsIHNvIHRoZXkgZm9sbG93IHlvdXIgYWNjb3VudCBvbnRvIGFueSBkZXZpY2UuXCJcbiAgICAgICAgICAgICAgOiBcIkhhYml0byBpcyBydW5uaW5nIHdpdGhvdXQgYSBkYXRhYmFzZSwgc28gdGhpcyBhY3Rpdml0eSBpcyBzdG9yZWQgaW4gdGhpcyBicm93c2VyIGFsb25lIGFuZCBpc24ndCBzaGFyZWQgd2l0aCBhbnlvbmUuXCJ9XG4gICAgICAgICAgPC9wPlxuXG4gICAgICAgICAgeyF1c2luZ0RhdGFiYXNlICYmIChcbiAgICAgICAgICAgIDxCdXR0b24gdmFyaWFudD1cInNlY29uZGFyeVwiIHNpemU9XCJzbVwiIGNsYXNzTmFtZT1cIm10LTRcIiBkaXNhYmxlZD17cmVzZXR0aW5nfSBvbkNsaWNrPXsoKSA9PiB2b2lkIHJlc2V0KCl9PlxuICAgICAgICAgICAgICA8Um90YXRlQ2N3IHNpemU9ezE0fSBhcmlhLWhpZGRlbiAvPlxuICAgICAgICAgICAgICB7cmVzZXR0aW5nID8gXCJSZXNldHRpbmfigKZcIiA6IFwiUmVzZXQgZGVtbyBkYXRhXCJ9XG4gICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICApfVxuICAgICAgICA8L3NlY3Rpb24+XG4gICAgICA8L2Rpdj5cbiAgICA8Lz5cbiAgKTtcbn1cblxuZnVuY3Rpb24gUm93KHsgbGFiZWwsIHZhbHVlIH06IHsgbGFiZWw6IHN0cmluZzsgdmFsdWU6IHN0cmluZyB9KSB7XG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWJhc2VsaW5lIGp1c3RpZnktYmV0d2VlbiBnYXAtM1wiPlxuICAgICAgPGR0IGNsYXNzTmFtZT1cInRleHQtaW5rLXNvZnRcIj57bGFiZWx9PC9kdD5cbiAgICAgIDxkZCBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtaW5rXCI+e3ZhbHVlfTwvZGQ+XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXSwiZmlsZSI6IkQ6L0kySSBQcm9qZWN0IC0gSGFiaXRvL0FwcCBGb2xkZXIvaGFiaXRvL3NyYy9wYWdlcy9Qcm9maWxlLnRzeCJ9