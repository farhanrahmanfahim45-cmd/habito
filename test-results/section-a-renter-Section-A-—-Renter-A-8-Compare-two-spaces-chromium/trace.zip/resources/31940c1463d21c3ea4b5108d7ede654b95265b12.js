import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/@fs/D:\\I2I Project - Habito\\App Folder\\habito\\src\\components\\space\\badges.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=9ceb86a3"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("D:/I2I Project - Habito/App Folder/habito/src/components/space/badges.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import { ShieldCheck, ShieldQuestion, ShieldAlert } from "/node_modules/.vite/deps/lucide-react.js?v=9ceb86a3";
import { cn } from "/src/lib/cn.ts";
import { useI18n } from "/src/i18n/index.tsx";
export function trustLevel(v) {
  if (v.owner === "verified" && v.space === "verified") return "verified";
  if (v.owner === "unverified" && v.space === "unverified") return "unverified";
  return "in-review";
}
const TRUST = {
  verified: { key: "trust.verified", icon: ShieldCheck, className: "bg-ok-100 text-ok-600" },
  "in-review": { key: "trust.inReview", icon: ShieldQuestion, className: "bg-warn-100 text-warn-700" },
  unverified: { key: "trust.unverified", icon: ShieldAlert, className: "bg-ivory-deep text-muted" }
};
export function TrustBadge({ verification, compact }) {
  _s();
  const { t } = useI18n();
  const { key, icon: Icon, className } = TRUST[trustLevel(verification)];
  return /* @__PURE__ */ jsxDEV("span", { className: cn("inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-xs font-semibold", className), children: [
    /* @__PURE__ */ jsxDEV(Icon, { size: 12, "aria-hidden": true }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/badges.tsx",
      lineNumber: 47,
      columnNumber: 7
    }, this),
    t(key),
    !compact && /* @__PURE__ */ jsxDEV("span", { className: "font-normal opacity-70", children: t("trust.demo") }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/badges.tsx",
      lineNumber: 49,
      columnNumber: 20
    }, this)
  ] }, void 0, true, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/badges.tsx",
    lineNumber: 46,
    columnNumber: 5
  }, this);
}
_s(TrustBadge, "82N5KF9nLzZ6+2WH7KIjzIXRkLw=", false, function() {
  return [useI18n];
});
_c = TrustBadge;
const AVAILABILITY_STYLE = {
  available: "bg-ok-100 text-ok-600",
  "partially-available": "bg-sun/45 text-sun-ink",
  "available-soon": "bg-aqua-100 text-aqua-700",
  occupied: "bg-ivory-deep text-muted",
  maintenance: "bg-warn-100 text-warn-700"
};
const AVAILABILITY_KEY = {
  available: "availability.available",
  "partially-available": "availability.partial",
  "available-soon": "availability.soon",
  occupied: "availability.occupied",
  maintenance: "availability.maintenance"
};
export function AvailabilityBadge({ availability }) {
  _s2();
  const { t } = useI18n();
  return /* @__PURE__ */ jsxDEV(
    "span",
    {
      className: cn(
        "inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-xs font-semibold",
        AVAILABILITY_STYLE[availability.status]
      ),
      children: t(AVAILABILITY_KEY[availability.status])
    },
    void 0,
    false,
    {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/badges.tsx",
      lineNumber: 73,
      columnNumber: 5
    },
    this
  );
}
_s2(AvailabilityBadge, "82N5KF9nLzZ6+2WH7KIjzIXRkLw=", false, function() {
  return [useI18n];
});
_c2 = AvailabilityBadge;
var _c, _c2;
$RefreshReg$(_c, "TrustBadge");
$RefreshReg$(_c2, "AvailabilityBadge");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/I2I Project - Habito/App Folder/habito/src/components/space/badges.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/I2I Project - Habito/App Folder/habito/src/components/space/badges.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMkJNOzs7Ozs7Ozs7Ozs7Ozs7OztBQTNCTixTQUFTQSxhQUFhQyxnQkFBZ0JDLG1CQUFtQjtBQUd6RCxTQUFTQyxVQUFVO0FBQ25CLFNBQVNDLGVBQWU7QUFJakIsZ0JBQVNDLFdBQVdDLEdBQTZCO0FBQ3RELE1BQUlBLEVBQUVDLFVBQVUsY0FBY0QsRUFBRUUsVUFBVSxXQUFZLFFBQU87QUFDN0QsTUFBSUYsRUFBRUMsVUFBVSxnQkFBZ0JELEVBQUVFLFVBQVUsYUFBYyxRQUFPO0FBQ2pFLFNBQU87QUFDVDtBQUVBLE1BQU1DLFFBQVE7QUFBQSxFQUNaQyxVQUFVLEVBQUVDLEtBQUssa0JBQWtCQyxNQUFNWixhQUFhYSxXQUFXLHdCQUF3QjtBQUFBLEVBQ3pGLGFBQWEsRUFBRUYsS0FBSyxrQkFBa0JDLE1BQU1YLGdCQUFnQlksV0FBVyw0QkFBNEI7QUFBQSxFQUNuR0MsWUFBWSxFQUFFSCxLQUFLLG9CQUFvQkMsTUFBTVYsYUFBYVcsV0FBVywyQkFBMkI7QUFDbEc7QUFHTyxnQkFBU0UsV0FBVyxFQUFFQyxjQUFjQyxRQUEyRCxHQUFHO0FBQUFDLEtBQUE7QUFDdkcsUUFBTSxFQUFFQyxFQUFFLElBQUlmLFFBQVE7QUFDdEIsUUFBTSxFQUFFTyxLQUFLQyxNQUFNUSxNQUFNUCxVQUFVLElBQUlKLE1BQU1KLFdBQVdXLFlBQVksQ0FBQztBQUVyRSxTQUNFLHVCQUFDLFVBQUssV0FBV2IsR0FBRyxpRkFBaUZVLFNBQVMsR0FDNUc7QUFBQSwyQkFBQyxRQUFLLE1BQU0sSUFBSSxlQUFXLFFBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBMkI7QUFBQSxJQUMxQk0sRUFBRVIsR0FBRztBQUFBLElBQ0wsQ0FBQ00sV0FBVyx1QkFBQyxVQUFLLFdBQVUsMEJBQTBCRSxZQUFFLFlBQVksS0FBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEwRDtBQUFBLE9BSHpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FJQTtBQUVKO0FBQUNELEdBWGVILFlBQVU7QUFBQSxVQUNWWCxPQUFPO0FBQUE7QUFBQSxLQURQVztBQWFoQixNQUFNTSxxQkFBNkM7QUFBQSxFQUNqREMsV0FBVztBQUFBLEVBQ1gsdUJBQXVCO0FBQUEsRUFDdkIsa0JBQWtCO0FBQUEsRUFDbEJDLFVBQVU7QUFBQSxFQUNWQyxhQUFhO0FBQ2Y7QUFFQSxNQUFNQyxtQkFBbUI7QUFBQSxFQUN2QkgsV0FBVztBQUFBLEVBQ1gsdUJBQXVCO0FBQUEsRUFDdkIsa0JBQWtCO0FBQUEsRUFDbEJDLFVBQVU7QUFBQSxFQUNWQyxhQUFhO0FBQ2Y7QUFFTyxnQkFBU0Usa0JBQWtCLEVBQUVDLGFBQW1ELEdBQUc7QUFBQUMsTUFBQTtBQUN4RixRQUFNLEVBQUVULEVBQUUsSUFBSWYsUUFBUTtBQUN0QixTQUNFO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDQyxXQUFXRDtBQUFBQSxRQUNUO0FBQUEsUUFDQWtCLG1CQUFtQk0sYUFBYUUsTUFBTTtBQUFBLE1BQ3hDO0FBQUEsTUFFQ1YsWUFBRU0saUJBQWlCRSxhQUFhRSxNQUFNLENBQUM7QUFBQTtBQUFBLElBTjFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQU9BO0FBRUo7QUFBQ0QsSUFaZUYsbUJBQWlCO0FBQUEsVUFDakJ0QixPQUFPO0FBQUE7QUFBQSxNQURQc0I7QUFBaUIsSUFBQUksSUFBQUM7QUFBQSxhQUFBRCxJQUFBO0FBQUEsYUFBQUMsS0FBQSIsIm5hbWVzIjpbIlNoaWVsZENoZWNrIiwiU2hpZWxkUXVlc3Rpb24iLCJTaGllbGRBbGVydCIsImNuIiwidXNlSTE4biIsInRydXN0TGV2ZWwiLCJ2Iiwib3duZXIiLCJzcGFjZSIsIlRSVVNUIiwidmVyaWZpZWQiLCJrZXkiLCJpY29uIiwiY2xhc3NOYW1lIiwidW52ZXJpZmllZCIsIlRydXN0QmFkZ2UiLCJ2ZXJpZmljYXRpb24iLCJjb21wYWN0IiwiX3MiLCJ0IiwiSWNvbiIsIkFWQUlMQUJJTElUWV9TVFlMRSIsImF2YWlsYWJsZSIsIm9jY3VwaWVkIiwibWFpbnRlbmFuY2UiLCJBVkFJTEFCSUxJVFlfS0VZIiwiQXZhaWxhYmlsaXR5QmFkZ2UiLCJhdmFpbGFiaWxpdHkiLCJfczIiLCJzdGF0dXMiLCJfYyIsIl9jMiJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJiYWRnZXMudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IFNoaWVsZENoZWNrLCBTaGllbGRRdWVzdGlvbiwgU2hpZWxkQWxlcnQgfSBmcm9tIFwibHVjaWRlLXJlYWN0XCI7XG5pbXBvcnQgdHlwZSB7IEF2YWlsYWJpbGl0eURldGFpbCwgVmVyaWZpY2F0aW9uIH0gZnJvbSBcIkAvdHlwZXMvc3BhY2VcIjtcblxuaW1wb3J0IHsgY24gfSBmcm9tIFwiQC9saWIvY25cIjtcbmltcG9ydCB7IHVzZUkxOG4gfSBmcm9tIFwiQC9pMThuXCI7XG5cbmV4cG9ydCB0eXBlIFRydXN0TGV2ZWwgPSBcInZlcmlmaWVkXCIgfCBcImluLXJldmlld1wiIHwgXCJ1bnZlcmlmaWVkXCI7XG5cbmV4cG9ydCBmdW5jdGlvbiB0cnVzdExldmVsKHY6IFZlcmlmaWNhdGlvbik6IFRydXN0TGV2ZWwge1xuICBpZiAodi5vd25lciA9PT0gXCJ2ZXJpZmllZFwiICYmIHYuc3BhY2UgPT09IFwidmVyaWZpZWRcIikgcmV0dXJuIFwidmVyaWZpZWRcIjtcbiAgaWYgKHYub3duZXIgPT09IFwidW52ZXJpZmllZFwiICYmIHYuc3BhY2UgPT09IFwidW52ZXJpZmllZFwiKSByZXR1cm4gXCJ1bnZlcmlmaWVkXCI7XG4gIHJldHVybiBcImluLXJldmlld1wiO1xufVxuXG5jb25zdCBUUlVTVCA9IHtcbiAgdmVyaWZpZWQ6IHsga2V5OiBcInRydXN0LnZlcmlmaWVkXCIsIGljb246IFNoaWVsZENoZWNrLCBjbGFzc05hbWU6IFwiYmctb2stMTAwIHRleHQtb2stNjAwXCIgfSxcbiAgXCJpbi1yZXZpZXdcIjogeyBrZXk6IFwidHJ1c3QuaW5SZXZpZXdcIiwgaWNvbjogU2hpZWxkUXVlc3Rpb24sIGNsYXNzTmFtZTogXCJiZy13YXJuLTEwMCB0ZXh0LXdhcm4tNzAwXCIgfSxcbiAgdW52ZXJpZmllZDogeyBrZXk6IFwidHJ1c3QudW52ZXJpZmllZFwiLCBpY29uOiBTaGllbGRBbGVydCwgY2xhc3NOYW1lOiBcImJnLWl2b3J5LWRlZXAgdGV4dC1tdXRlZFwiIH0sXG59IGFzIGNvbnN0O1xuXG4vKiogQWx3YXlzIGNhcnJpZXMgXCIoZGVtbylcIiDigJQgSGFiaXRvIHBlcmZvcm1zIG5vIHJlYWwgY2hlY2tzLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIFRydXN0QmFkZ2UoeyB2ZXJpZmljYXRpb24sIGNvbXBhY3QgfTogeyB2ZXJpZmljYXRpb246IFZlcmlmaWNhdGlvbjsgY29tcGFjdD86IGJvb2xlYW4gfSkge1xuICBjb25zdCB7IHQgfSA9IHVzZUkxOG4oKTtcbiAgY29uc3QgeyBrZXksIGljb246IEljb24sIGNsYXNzTmFtZSB9ID0gVFJVU1RbdHJ1c3RMZXZlbCh2ZXJpZmljYXRpb24pXTtcblxuICByZXR1cm4gKFxuICAgIDxzcGFuIGNsYXNzTmFtZT17Y24oXCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgcm91bmRlZC1mdWxsIHB4LTIgcHktMC41IHRleHQteHMgZm9udC1zZW1pYm9sZFwiLCBjbGFzc05hbWUpfT5cbiAgICAgIDxJY29uIHNpemU9ezEyfSBhcmlhLWhpZGRlbiAvPlxuICAgICAge3Qoa2V5KX1cbiAgICAgIHshY29tcGFjdCAmJiA8c3BhbiBjbGFzc05hbWU9XCJmb250LW5vcm1hbCBvcGFjaXR5LTcwXCI+e3QoXCJ0cnVzdC5kZW1vXCIpfTwvc3Bhbj59XG4gICAgPC9zcGFuPlxuICApO1xufVxuXG5jb25zdCBBVkFJTEFCSUxJVFlfU1RZTEU6IFJlY29yZDxzdHJpbmcsIHN0cmluZz4gPSB7XG4gIGF2YWlsYWJsZTogXCJiZy1vay0xMDAgdGV4dC1vay02MDBcIixcbiAgXCJwYXJ0aWFsbHktYXZhaWxhYmxlXCI6IFwiYmctc3VuLzQ1IHRleHQtc3VuLWlua1wiLFxuICBcImF2YWlsYWJsZS1zb29uXCI6IFwiYmctYXF1YS0xMDAgdGV4dC1hcXVhLTcwMFwiLFxuICBvY2N1cGllZDogXCJiZy1pdm9yeS1kZWVwIHRleHQtbXV0ZWRcIixcbiAgbWFpbnRlbmFuY2U6IFwiYmctd2Fybi0xMDAgdGV4dC13YXJuLTcwMFwiLFxufTtcblxuY29uc3QgQVZBSUxBQklMSVRZX0tFWSA9IHtcbiAgYXZhaWxhYmxlOiBcImF2YWlsYWJpbGl0eS5hdmFpbGFibGVcIixcbiAgXCJwYXJ0aWFsbHktYXZhaWxhYmxlXCI6IFwiYXZhaWxhYmlsaXR5LnBhcnRpYWxcIixcbiAgXCJhdmFpbGFibGUtc29vblwiOiBcImF2YWlsYWJpbGl0eS5zb29uXCIsXG4gIG9jY3VwaWVkOiBcImF2YWlsYWJpbGl0eS5vY2N1cGllZFwiLFxuICBtYWludGVuYW5jZTogXCJhdmFpbGFiaWxpdHkubWFpbnRlbmFuY2VcIixcbn0gYXMgY29uc3Q7XG5cbmV4cG9ydCBmdW5jdGlvbiBBdmFpbGFiaWxpdHlCYWRnZSh7IGF2YWlsYWJpbGl0eSB9OiB7IGF2YWlsYWJpbGl0eTogQXZhaWxhYmlsaXR5RGV0YWlsIH0pIHtcbiAgY29uc3QgeyB0IH0gPSB1c2VJMThuKCk7XG4gIHJldHVybiAoXG4gICAgPHNwYW5cbiAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgIFwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0xIHJvdW5kZWQtZnVsbCBweC0yIHB5LTAuNSB0ZXh0LXhzIGZvbnQtc2VtaWJvbGRcIixcbiAgICAgICAgQVZBSUxBQklMSVRZX1NUWUxFW2F2YWlsYWJpbGl0eS5zdGF0dXNdLFxuICAgICAgKX1cbiAgICA+XG4gICAgICB7dChBVkFJTEFCSUxJVFlfS0VZW2F2YWlsYWJpbGl0eS5zdGF0dXNdKX1cbiAgICA8L3NwYW4+XG4gICk7XG59XG4iXSwiZmlsZSI6IkQ6L0kySSBQcm9qZWN0IC0gSGFiaXRvL0FwcCBGb2xkZXIvaGFiaXRvL3NyYy9jb21wb25lbnRzL3NwYWNlL2JhZGdlcy50c3gifQ==