import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/routes/Guard.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=9ceb86a3"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("D:/I2I Project - Habito/App Folder/habito/src/routes/Guard.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { Navigate, useLocation } from "/node_modules/.vite/deps/react-router-dom.js?v=9ceb86a3";
import { useAuth } from "/src/hooks/useAuth.tsx";
export function Guard({ allow, children }) {
  _s();
  const { ready, configured, account } = useAuth();
  const location = useLocation();
  const adminOnly = allow.length === 1 && allow[0] === "admin";
  if (adminOnly && !configured) {
    return /* @__PURE__ */ jsxDEV("div", { className: "container-page max-w-md py-24 text-center", children: [
      /* @__PURE__ */ jsxDEV("h1", { className: "font-display text-2xl font-bold text-ink", children: "Not available in this build." }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/routes/Guard.tsx",
        lineNumber: 42,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm leading-relaxed text-muted", children: "Moderation needs the database and an administrator account. This build has neither." }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/routes/Guard.tsx",
        lineNumber: 43,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/routes/Guard.tsx",
      lineNumber: 41,
      columnNumber: 7
    }, this);
  }
  if (!configured) return /* @__PURE__ */ jsxDEV(Fragment, { children }, void 0, false, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/routes/Guard.tsx",
    lineNumber: 53,
    columnNumber: 27
  }, this);
  if (!ready) {
    return /* @__PURE__ */ jsxDEV("div", { className: "container-page py-24 text-center text-sm text-muted", children: "Checking your session…" }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/routes/Guard.tsx",
      lineNumber: 56,
      columnNumber: 12
    }, this);
  }
  if (!account) {
    return /* @__PURE__ */ jsxDEV(Navigate, { to: "/signin", state: { from: location.pathname }, replace: true }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/routes/Guard.tsx",
      lineNumber: 60,
      columnNumber: 12
    }, this);
  }
  if (account.suspended) {
    return /* @__PURE__ */ jsxDEV("div", { className: "container-page max-w-md py-24 text-center", children: [
      /* @__PURE__ */ jsxDEV("h1", { className: "font-display text-2xl font-bold text-ink", children: "Your account is suspended." }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/routes/Guard.tsx",
        lineNumber: 66,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-muted", children: "Contact support if you think this is a mistake." }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/routes/Guard.tsx",
        lineNumber: 67,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/routes/Guard.tsx",
      lineNumber: 65,
      columnNumber: 7
    }, this);
  }
  const permitted = allow.includes(account.role) || allow.includes("owner") && account.canOwn;
  if (!permitted) {
    return /* @__PURE__ */ jsxDEV("div", { className: "container-page max-w-md py-24 text-center", children: [
      /* @__PURE__ */ jsxDEV("h1", { className: "font-display text-2xl font-bold text-ink", children: "That page isn't for this account." }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/routes/Guard.tsx",
        lineNumber: 78,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm leading-relaxed text-muted", children: [
        "You're signed in as a ",
        account.role,
        ". ",
        allow.includes("owner") && "Owner tools need an owner account."
      ] }, void 0, true, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/routes/Guard.tsx",
        lineNumber: 79,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/routes/Guard.tsx",
      lineNumber: 77,
      columnNumber: 7
    }, this);
  }
  return /* @__PURE__ */ jsxDEV(Fragment, { children }, void 0, false, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/routes/Guard.tsx",
    lineNumber: 86,
    columnNumber: 10
  }, this);
}
_s(Guard, "jsVSjEdGeqGif1Q/Lh2jizDlKoQ=", false, function() {
  return [useAuth, useLocation];
});
_c = Guard;
var _c;
$RefreshReg$(_c, "Guard");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/I2I Project - Habito/App Folder/habito/src/routes/Guard.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/I2I Project - Habito/App Folder/habito/src/routes/Guard.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0JRLFNBV2tCLFVBWGxCOzs7Ozs7Ozs7Ozs7Ozs7OztBQXRCUixTQUFTQSxVQUFVQyxtQkFBbUI7QUFFdEMsU0FBU0MsZUFBZTtBQVFqQixnQkFBU0MsTUFBTSxFQUFFQyxPQUFPQyxTQUF3RCxHQUFHO0FBQUFDLEtBQUE7QUFDeEYsUUFBTSxFQUFFQyxPQUFPQyxZQUFZQyxRQUFRLElBQUlQLFFBQVE7QUFDL0MsUUFBTVEsV0FBV1QsWUFBWTtBQUs3QixRQUFNVSxZQUFZUCxNQUFNUSxXQUFXLEtBQUtSLE1BQU0sQ0FBQyxNQUFNO0FBRXJELE1BQUlPLGFBQWEsQ0FBQ0gsWUFBWTtBQUM1QixXQUNFLHVCQUFDLFNBQUksV0FBVSw2Q0FDYjtBQUFBLDZCQUFDLFFBQUcsV0FBVSw0Q0FBMkMsNENBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBcUY7QUFBQSxNQUNyRix1QkFBQyxPQUFFLFdBQVUsMkNBQXlDLG1HQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxTQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FLQTtBQUFBLEVBRUo7QUFLQSxNQUFJLENBQUNBLFdBQVksUUFBTyxtQ0FBR0gsWUFBSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQVk7QUFFcEMsTUFBSSxDQUFDRSxPQUFPO0FBQ1YsV0FBTyx1QkFBQyxTQUFJLFdBQVUsdURBQXNELHNDQUFyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTJGO0FBQUEsRUFDcEc7QUFFQSxNQUFJLENBQUNFLFNBQVM7QUFDWixXQUFPLHVCQUFDLFlBQVMsSUFBRyxXQUFVLE9BQU8sRUFBRUksTUFBTUgsU0FBU0ksU0FBUyxHQUFHLFNBQU8sUUFBbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFrRTtBQUFBLEVBQzNFO0FBRUEsTUFBSUwsUUFBUU0sV0FBVztBQUNyQixXQUNFLHVCQUFDLFNBQUksV0FBVSw2Q0FDYjtBQUFBLDZCQUFDLFFBQUcsV0FBVSw0Q0FBMkMsMENBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBbUY7QUFBQSxNQUNuRix1QkFBQyxPQUFFLFdBQVUsMkJBQTBCLCtEQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXNGO0FBQUEsU0FGeEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdBO0FBQUEsRUFFSjtBQUdBLFFBQU1DLFlBQVlaLE1BQU1hLFNBQVNSLFFBQVFTLElBQUksS0FBTWQsTUFBTWEsU0FBUyxPQUFPLEtBQUtSLFFBQVFVO0FBRXRGLE1BQUksQ0FBQ0gsV0FBVztBQUNkLFdBQ0UsdUJBQUMsU0FBSSxXQUFVLDZDQUNiO0FBQUEsNkJBQUMsUUFBRyxXQUFVLDRDQUEyQyxpREFBekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEwRjtBQUFBLE1BQzFGLHVCQUFDLE9BQUUsV0FBVSwyQ0FBeUM7QUFBQTtBQUFBLFFBQzdCUCxRQUFRUztBQUFBQSxRQUFLO0FBQUEsUUFBR2QsTUFBTWEsU0FBUyxPQUFPLEtBQUs7QUFBQSxXQURwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxTQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FLQTtBQUFBLEVBRUo7QUFFQSxTQUFPLG1DQUFHWixZQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBWTtBQUNyQjtBQUFDQyxHQXpEZUgsT0FBSztBQUFBLFVBQ29CRCxTQUN0QkQsV0FBVztBQUFBO0FBQUEsS0FGZEU7QUFBSyxJQUFBaUI7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsiTmF2aWdhdGUiLCJ1c2VMb2NhdGlvbiIsInVzZUF1dGgiLCJHdWFyZCIsImFsbG93IiwiY2hpbGRyZW4iLCJfcyIsInJlYWR5IiwiY29uZmlndXJlZCIsImFjY291bnQiLCJsb2NhdGlvbiIsImFkbWluT25seSIsImxlbmd0aCIsImZyb20iLCJwYXRobmFtZSIsInN1c3BlbmRlZCIsInBlcm1pdHRlZCIsImluY2x1ZGVzIiwicm9sZSIsImNhbk93biIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkd1YXJkLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBOYXZpZ2F0ZSwgdXNlTG9jYXRpb24gfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xuaW1wb3J0IHR5cGUgeyBSZWFjdE5vZGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IHVzZUF1dGggfSBmcm9tIFwiQC9ob29rcy91c2VBdXRoXCI7XG5pbXBvcnQgdHlwZSB7IEFjY291bnRSb2xlIH0gZnJvbSBcIkAvaG9va3MvdXNlQXV0aFwiO1xuXG4vKipcbiAqIFJvdXRlIGd1YXJkLiBUeXBpbmcgYSBVUkwgaXNuJ3QgZW5vdWdoIHRvIHJlYWNoIGEgcHJvdGVjdGVkIHBhZ2Ug4oCUIGFuZCB0aGVcbiAqIGRhdGFiYXNlIHJlZnVzZXMgdGhlIHVuZGVybHlpbmcgcXVlcmllcyBhbnl3YXksIHNvIHRoaXMgaXMgYWJvdXQgc2hvd2luZyB0aGVcbiAqIHJpZ2h0IHNjcmVlbiByYXRoZXIgdGhhbiBhYm91dCBzZWN1cml0eS5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIEd1YXJkKHsgYWxsb3csIGNoaWxkcmVuIH06IHsgYWxsb3c6IEFjY291bnRSb2xlW107IGNoaWxkcmVuOiBSZWFjdE5vZGUgfSkge1xuICBjb25zdCB7IHJlYWR5LCBjb25maWd1cmVkLCBhY2NvdW50IH0gPSB1c2VBdXRoKCk7XG4gIGNvbnN0IGxvY2F0aW9uID0gdXNlTG9jYXRpb24oKTtcblxuICAvLyBNb2RlcmF0aW9uIGlzIHRoZSBleGNlcHRpb24gdG8gZXZlcnl0aGluZyBiZWxvdzogaXQgYWx3YXlzIG5lZWRzIGEgcmVhbFxuICAvLyBhZG1pbiBhY2NvdW50LiBXaXRob3V0IGEgZGF0YWJhc2UgdGhlcmUgaXMgbm90aGluZyB0byBtb2RlcmF0ZSBhbmQgbm8gd2F5XG4gIC8vIHRvIGJlIGFuIGFkbWluLCBzbyB0aGUgcGFnZSBpcyBzaW1wbHkgdW5hdmFpbGFibGUuXG4gIGNvbnN0IGFkbWluT25seSA9IGFsbG93Lmxlbmd0aCA9PT0gMSAmJiBhbGxvd1swXSA9PT0gXCJhZG1pblwiO1xuXG4gIGlmIChhZG1pbk9ubHkgJiYgIWNvbmZpZ3VyZWQpIHtcbiAgICByZXR1cm4gKFxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb250YWluZXItcGFnZSBtYXgtdy1tZCBweS0yNCB0ZXh0LWNlbnRlclwiPlxuICAgICAgICA8aDEgY2xhc3NOYW1lPVwiZm9udC1kaXNwbGF5IHRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LWlua1wiPk5vdCBhdmFpbGFibGUgaW4gdGhpcyBidWlsZC48L2gxPlxuICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gbGVhZGluZy1yZWxheGVkIHRleHQtbXV0ZWRcIj5cbiAgICAgICAgICBNb2RlcmF0aW9uIG5lZWRzIHRoZSBkYXRhYmFzZSBhbmQgYW4gYWRtaW5pc3RyYXRvciBhY2NvdW50LiBUaGlzIGJ1aWxkIGhhcyBuZWl0aGVyLlxuICAgICAgICA8L3A+XG4gICAgICA8L2Rpdj5cbiAgICApO1xuICB9XG5cbiAgLy8gRXZlcnl0aGluZyBlbHNlOiB3aXRob3V0IGEgZGF0YWJhc2UgdGhlcmUgYXJlIG5vIGFjY291bnRzLCBzbyBndWFyZHMgd291bGRcbiAgLy8gbG9jayBvdXQgdGhlIHdob2xlIG93bmVyIHNpZGUgb2YgdGhlIGRlbW8uIExldCBpdCB0aHJvdWdoIGFuZCBsZXQgdGhlIGxvY2FsXG4gIC8vIHN0b3JlIHNlcnZlLlxuICBpZiAoIWNvbmZpZ3VyZWQpIHJldHVybiA8PntjaGlsZHJlbn08Lz47XG5cbiAgaWYgKCFyZWFkeSkge1xuICAgIHJldHVybiA8ZGl2IGNsYXNzTmFtZT1cImNvbnRhaW5lci1wYWdlIHB5LTI0IHRleHQtY2VudGVyIHRleHQtc20gdGV4dC1tdXRlZFwiPkNoZWNraW5nIHlvdXIgc2Vzc2lvbuKApjwvZGl2PjtcbiAgfVxuXG4gIGlmICghYWNjb3VudCkge1xuICAgIHJldHVybiA8TmF2aWdhdGUgdG89XCIvc2lnbmluXCIgc3RhdGU9e3sgZnJvbTogbG9jYXRpb24ucGF0aG5hbWUgfX0gcmVwbGFjZSAvPjtcbiAgfVxuXG4gIGlmIChhY2NvdW50LnN1c3BlbmRlZCkge1xuICAgIHJldHVybiAoXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbnRhaW5lci1wYWdlIG1heC13LW1kIHB5LTI0IHRleHQtY2VudGVyXCI+XG4gICAgICAgIDxoMSBjbGFzc05hbWU9XCJmb250LWRpc3BsYXkgdGV4dC0yeGwgZm9udC1ib2xkIHRleHQtaW5rXCI+WW91ciBhY2NvdW50IGlzIHN1c3BlbmRlZC48L2gxPlxuICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1tdXRlZFwiPkNvbnRhY3Qgc3VwcG9ydCBpZiB5b3UgdGhpbmsgdGhpcyBpcyBhIG1pc3Rha2UuPC9wPlxuICAgICAgPC9kaXY+XG4gICAgKTtcbiAgfVxuXG4gIC8vIE93bmVyIHBhZ2VzIG5lZWQgdGhlIGNhcGFiaWxpdHksIHdoaWNoIGEgcmVudGVyIGNhbiBzd2l0Y2ggb24gYXQgYW55IHRpbWUuXG4gIGNvbnN0IHBlcm1pdHRlZCA9IGFsbG93LmluY2x1ZGVzKGFjY291bnQucm9sZSkgfHwgKGFsbG93LmluY2x1ZGVzKFwib3duZXJcIikgJiYgYWNjb3VudC5jYW5Pd24pO1xuXG4gIGlmICghcGVybWl0dGVkKSB7XG4gICAgcmV0dXJuIChcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29udGFpbmVyLXBhZ2UgbWF4LXctbWQgcHktMjQgdGV4dC1jZW50ZXJcIj5cbiAgICAgICAgPGgxIGNsYXNzTmFtZT1cImZvbnQtZGlzcGxheSB0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1pbmtcIj5UaGF0IHBhZ2UgaXNuJ3QgZm9yIHRoaXMgYWNjb3VudC48L2gxPlxuICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gbGVhZGluZy1yZWxheGVkIHRleHQtbXV0ZWRcIj5cbiAgICAgICAgICBZb3UncmUgc2lnbmVkIGluIGFzIGEge2FjY291bnQucm9sZX0uIHthbGxvdy5pbmNsdWRlcyhcIm93bmVyXCIpICYmIFwiT3duZXIgdG9vbHMgbmVlZCBhbiBvd25lciBhY2NvdW50LlwifVxuICAgICAgICA8L3A+XG4gICAgICA8L2Rpdj5cbiAgICApO1xuICB9XG5cbiAgcmV0dXJuIDw+e2NoaWxkcmVufTwvPjtcbn1cbiJdLCJmaWxlIjoiRDovSTJJIFByb2plY3QgLSBIYWJpdG8vQXBwIEZvbGRlci9oYWJpdG8vc3JjL3JvdXRlcy9HdWFyZC50c3gifQ==