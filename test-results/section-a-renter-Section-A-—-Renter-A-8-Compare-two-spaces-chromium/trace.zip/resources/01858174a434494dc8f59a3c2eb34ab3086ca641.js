import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/routes/AppRoutes.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=9ceb86a3"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("D:/I2I Project - Habito/App Folder/habito/src/routes/AppRoutes.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { Routes, Route, Navigate } from "/node_modules/.vite/deps/react-router-dom.js?v=9ceb86a3";
import { Guard } from "/src/routes/Guard.tsx";
import Home from "/src/pages/Home.tsx";
import Explore from "/src/pages/Explore.tsx";
import Search from "/src/pages/Search.tsx";
import Find from "/src/pages/Find.tsx";
import SpaceDetail from "/src/pages/SpaceDetail.tsx";
import Compare from "/src/pages/Compare.tsx";
import Saved from "/src/pages/Saved.tsx";
import Portfolio from "/src/pages/Portfolio.tsx";
import ListSpace from "/src/pages/ListSpace.tsx";
import Requests from "/src/pages/Requests.tsx";
import Profile from "/src/pages/Profile.tsx";
import Auth from "/src/pages/Auth.tsx";
import Messages from "/src/pages/Messages.tsx";
import Bookings from "/src/pages/Bookings.tsx";
import Admin from "/src/pages/Admin.tsx";
import Settings from "/src/pages/Settings.tsx";
import NotFound from "/src/pages/NotFound.tsx";
export function AppRoutes() {
  return /* @__PURE__ */ jsxDEV(Routes, { children: [
    /* @__PURE__ */ jsxDEV(Route, { path: "/", element: /* @__PURE__ */ jsxDEV(Home, {}, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/routes/AppRoutes.tsx",
      lineNumber: 44,
      columnNumber: 32
    }, this) }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/routes/AppRoutes.tsx",
      lineNumber: 44,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "/explore", element: /* @__PURE__ */ jsxDEV(Explore, {}, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/routes/AppRoutes.tsx",
      lineNumber: 45,
      columnNumber: 39
    }, this) }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/routes/AppRoutes.tsx",
      lineNumber: 45,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "/search", element: /* @__PURE__ */ jsxDEV(Search, {}, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/routes/AppRoutes.tsx",
      lineNumber: 46,
      columnNumber: 38
    }, this) }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/routes/AppRoutes.tsx",
      lineNumber: 46,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "/find", element: /* @__PURE__ */ jsxDEV(Find, {}, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/routes/AppRoutes.tsx",
      lineNumber: 47,
      columnNumber: 36
    }, this) }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/routes/AppRoutes.tsx",
      lineNumber: 47,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "/space/:id", element: /* @__PURE__ */ jsxDEV(SpaceDetail, {}, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/routes/AppRoutes.tsx",
      lineNumber: 48,
      columnNumber: 41
    }, this) }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/routes/AppRoutes.tsx",
      lineNumber: 48,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "/compare", element: /* @__PURE__ */ jsxDEV(Compare, {}, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/routes/AppRoutes.tsx",
      lineNumber: 49,
      columnNumber: 39
    }, this) }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/routes/AppRoutes.tsx",
      lineNumber: 49,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "/requests", element: /* @__PURE__ */ jsxDEV(Requests, {}, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/routes/AppRoutes.tsx",
      lineNumber: 50,
      columnNumber: 40
    }, this) }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/routes/AppRoutes.tsx",
      lineNumber: 50,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "/signin", element: /* @__PURE__ */ jsxDEV(Auth, { initial: "signin" }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/routes/AppRoutes.tsx",
      lineNumber: 52,
      columnNumber: 38
    }, this) }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/routes/AppRoutes.tsx",
      lineNumber: 52,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "/signup", element: /* @__PURE__ */ jsxDEV(Auth, { initial: "signup" }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/routes/AppRoutes.tsx",
      lineNumber: 53,
      columnNumber: 38
    }, this) }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/routes/AppRoutes.tsx",
      lineNumber: 53,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      Route,
      {
        path: "/saved",
        element: /* @__PURE__ */ jsxDEV(Guard, { allow: ["renter", "owner", "admin"], children: /* @__PURE__ */ jsxDEV(Saved, {}, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/routes/AppRoutes.tsx",
          lineNumber: 60,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/routes/AppRoutes.tsx",
          lineNumber: 59,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/routes/AppRoutes.tsx",
        lineNumber: 56,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Route,
      {
        path: "/messages",
        element: /* @__PURE__ */ jsxDEV(Guard, { allow: ["renter", "owner", "admin"], children: /* @__PURE__ */ jsxDEV(Messages, {}, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/routes/AppRoutes.tsx",
          lineNumber: 68,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/routes/AppRoutes.tsx",
          lineNumber: 67,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/routes/AppRoutes.tsx",
        lineNumber: 64,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Route,
      {
        path: "/messages/:id",
        element: /* @__PURE__ */ jsxDEV(Guard, { allow: ["renter", "owner", "admin"], children: /* @__PURE__ */ jsxDEV(Messages, {}, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/routes/AppRoutes.tsx",
          lineNumber: 76,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/routes/AppRoutes.tsx",
          lineNumber: 75,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/routes/AppRoutes.tsx",
        lineNumber: 72,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Route,
      {
        path: "/bookings",
        element: /* @__PURE__ */ jsxDEV(Guard, { allow: ["renter", "owner", "admin"], children: /* @__PURE__ */ jsxDEV(Bookings, {}, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/routes/AppRoutes.tsx",
          lineNumber: 84,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/routes/AppRoutes.tsx",
          lineNumber: 83,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/routes/AppRoutes.tsx",
        lineNumber: 80,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Route,
      {
        path: "/admin",
        element: /* @__PURE__ */ jsxDEV(Guard, { allow: ["admin"], children: /* @__PURE__ */ jsxDEV(Admin, {}, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/routes/AppRoutes.tsx",
          lineNumber: 94,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/routes/AppRoutes.tsx",
          lineNumber: 93,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/routes/AppRoutes.tsx",
        lineNumber: 90,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Route,
      {
        path: "/account",
        element: /* @__PURE__ */ jsxDEV(Guard, { allow: ["renter", "owner", "admin"], children: /* @__PURE__ */ jsxDEV(Profile, {}, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/routes/AppRoutes.tsx",
          lineNumber: 102,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/routes/AppRoutes.tsx",
          lineNumber: 101,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/routes/AppRoutes.tsx",
        lineNumber: 98,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Route,
      {
        path: "/portfolio",
        element: /* @__PURE__ */ jsxDEV(Guard, { allow: ["renter", "owner", "admin"], children: /* @__PURE__ */ jsxDEV(Portfolio, {}, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/routes/AppRoutes.tsx",
          lineNumber: 113,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/routes/AppRoutes.tsx",
          lineNumber: 112,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/routes/AppRoutes.tsx",
        lineNumber: 109,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Route,
      {
        path: "/list",
        element: /* @__PURE__ */ jsxDEV(Guard, { allow: ["renter", "owner", "admin"], children: /* @__PURE__ */ jsxDEV(ListSpace, {}, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/routes/AppRoutes.tsx",
          lineNumber: 121,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/routes/AppRoutes.tsx",
          lineNumber: 120,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/routes/AppRoutes.tsx",
        lineNumber: 117,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Route,
      {
        path: "/list/:id",
        element: /* @__PURE__ */ jsxDEV(Guard, { allow: ["renter", "owner", "admin"], children: /* @__PURE__ */ jsxDEV(ListSpace, {}, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/routes/AppRoutes.tsx",
          lineNumber: 130,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/routes/AppRoutes.tsx",
          lineNumber: 129,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/routes/AppRoutes.tsx",
        lineNumber: 126,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Route,
      {
        path: "/space/:id/edit",
        element: /* @__PURE__ */ jsxDEV(Guard, { allow: ["renter", "owner", "admin"], children: /* @__PURE__ */ jsxDEV(ListSpace, {}, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/routes/AppRoutes.tsx",
          lineNumber: 138,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/routes/AppRoutes.tsx",
          lineNumber: 137,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/routes/AppRoutes.tsx",
        lineNumber: 134,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Route,
      {
        path: "/settings",
        element: /* @__PURE__ */ jsxDEV(Guard, { allow: ["renter", "owner", "admin"], children: /* @__PURE__ */ jsxDEV(Settings, {}, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/routes/AppRoutes.tsx",
          lineNumber: 146,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/routes/AppRoutes.tsx",
          lineNumber: 145,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/routes/AppRoutes.tsx",
        lineNumber: 142,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(Route, { path: "/profile", element: /* @__PURE__ */ jsxDEV(Navigate, { to: "/account", replace: true }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/routes/AppRoutes.tsx",
      lineNumber: 152,
      columnNumber: 39
    }, this) }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/routes/AppRoutes.tsx",
      lineNumber: 152,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "/property/:id", element: /* @__PURE__ */ jsxDEV(Navigate, { to: "/portfolio", replace: true }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/routes/AppRoutes.tsx",
      lineNumber: 153,
      columnNumber: 44
    }, this) }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/routes/AppRoutes.tsx",
      lineNumber: 153,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "/intake", element: /* @__PURE__ */ jsxDEV(Navigate, { to: "/find", replace: true }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/routes/AppRoutes.tsx",
      lineNumber: 154,
      columnNumber: 38
    }, this) }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/routes/AppRoutes.tsx",
      lineNumber: 154,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "/list-property", element: /* @__PURE__ */ jsxDEV(Navigate, { to: "/list", replace: true }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/routes/AppRoutes.tsx",
      lineNumber: 155,
      columnNumber: 45
    }, this) }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/routes/AppRoutes.tsx",
      lineNumber: 155,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "/owner", element: /* @__PURE__ */ jsxDEV(Navigate, { to: "/portfolio", replace: true }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/routes/AppRoutes.tsx",
      lineNumber: 156,
      columnNumber: 37
    }, this) }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/routes/AppRoutes.tsx",
      lineNumber: 156,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "*", element: /* @__PURE__ */ jsxDEV(NotFound, {}, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/routes/AppRoutes.tsx",
      lineNumber: 158,
      columnNumber: 32
    }, this) }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/routes/AppRoutes.tsx",
      lineNumber: 158,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/routes/AppRoutes.tsx",
    lineNumber: 42,
    columnNumber: 5
  }, this);
}
_c = AppRoutes;
var _c;
$RefreshReg$(_c, "AppRoutes");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/I2I Project - Habito/App Folder/habito/src/routes/AppRoutes.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/I2I Project - Habito/App Folder/habito/src/routes/AppRoutes.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBd0IrQjs7Ozs7Ozs7Ozs7Ozs7OztBQXhCL0IsU0FBU0EsUUFBUUMsT0FBT0MsZ0JBQWdCO0FBQ3hDLFNBQVNDLGFBQWE7QUFDdEIsT0FBT0MsVUFBVTtBQUNqQixPQUFPQyxhQUFhO0FBQ3BCLE9BQU9DLFlBQVk7QUFDbkIsT0FBT0MsVUFBVTtBQUNqQixPQUFPQyxpQkFBaUI7QUFDeEIsT0FBT0MsYUFBYTtBQUNwQixPQUFPQyxXQUFXO0FBQ2xCLE9BQU9DLGVBQWU7QUFDdEIsT0FBT0MsZUFBZTtBQUN0QixPQUFPQyxjQUFjO0FBQ3JCLE9BQU9DLGFBQWE7QUFDcEIsT0FBT0MsVUFBVTtBQUNqQixPQUFPQyxjQUFjO0FBQ3JCLE9BQU9DLGNBQWM7QUFDckIsT0FBT0MsV0FBVztBQUNsQixPQUFPQyxjQUFjO0FBQ3JCLE9BQU9DLGNBQWM7QUFFZCxnQkFBU0MsWUFBWTtBQUMxQixTQUNFLHVCQUFDLFVBRUM7QUFBQSwyQkFBQyxTQUFNLE1BQUssS0FBSSxTQUFTLHVCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFLLEtBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBa0M7QUFBQSxJQUNsQyx1QkFBQyxTQUFNLE1BQUssWUFBVyxTQUFTLHVCQUFDLGFBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFRLEtBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBNEM7QUFBQSxJQUM1Qyx1QkFBQyxTQUFNLE1BQUssV0FBVSxTQUFTLHVCQUFDLFlBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFPLEtBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBMEM7QUFBQSxJQUMxQyx1QkFBQyxTQUFNLE1BQUssU0FBUSxTQUFTLHVCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFLLEtBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBc0M7QUFBQSxJQUN0Qyx1QkFBQyxTQUFNLE1BQUssY0FBYSxTQUFTLHVCQUFDLGlCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBWSxLQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWtEO0FBQUEsSUFDbEQsdUJBQUMsU0FBTSxNQUFLLFlBQVcsU0FBUyx1QkFBQyxhQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBUSxLQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTRDO0FBQUEsSUFDNUMsdUJBQUMsU0FBTSxNQUFLLGFBQVksU0FBUyx1QkFBQyxjQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBUyxLQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQThDO0FBQUEsSUFFOUMsdUJBQUMsU0FBTSxNQUFLLFdBQVUsU0FBUyx1QkFBQyxRQUFLLFNBQVEsWUFBZDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXNCLEtBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBeUQ7QUFBQSxJQUN6RCx1QkFBQyxTQUFNLE1BQUssV0FBVSxTQUFTLHVCQUFDLFFBQUssU0FBUSxZQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBc0IsS0FBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF5RDtBQUFBLElBR3pEO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxNQUFLO0FBQUEsUUFDTCxTQUNFLHVCQUFDLFNBQU0sT0FBTyxDQUFDLFVBQVUsU0FBUyxPQUFPLEdBQ3ZDLGlDQUFDLFdBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFNLEtBRFI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUE7QUFBQSxNQUxKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQU1HO0FBQUEsSUFFSDtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsTUFBSztBQUFBLFFBQ0wsU0FDRSx1QkFBQyxTQUFNLE9BQU8sQ0FBQyxVQUFVLFNBQVMsT0FBTyxHQUN2QyxpQ0FBQyxjQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBUyxLQURYO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBO0FBQUEsTUFMSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFNRztBQUFBLElBRUg7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLE1BQUs7QUFBQSxRQUNMLFNBQ0UsdUJBQUMsU0FBTSxPQUFPLENBQUMsVUFBVSxTQUFTLE9BQU8sR0FDdkMsaUNBQUMsY0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQVMsS0FEWDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQTtBQUFBLE1BTEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBTUc7QUFBQSxJQUVIO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxNQUFLO0FBQUEsUUFDTCxTQUNFLHVCQUFDLFNBQU0sT0FBTyxDQUFDLFVBQVUsU0FBUyxPQUFPLEdBQ3ZDLGlDQUFDLGNBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFTLEtBRFg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUE7QUFBQSxNQUxKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQU1HO0FBQUEsSUFJSDtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsTUFBSztBQUFBLFFBQ0wsU0FDRSx1QkFBQyxTQUFNLE9BQU8sQ0FBQyxPQUFPLEdBQ3BCLGlDQUFDLFdBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFNLEtBRFI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUE7QUFBQSxNQUxKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQU1HO0FBQUEsSUFFSDtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsTUFBSztBQUFBLFFBQ0wsU0FDRSx1QkFBQyxTQUFNLE9BQU8sQ0FBQyxVQUFVLFNBQVMsT0FBTyxHQUN2QyxpQ0FBQyxhQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBUSxLQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBO0FBQUEsTUFMSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFNRztBQUFBLElBS0g7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLE1BQUs7QUFBQSxRQUNMLFNBQ0UsdUJBQUMsU0FBTSxPQUFPLENBQUMsVUFBVSxTQUFTLE9BQU8sR0FDdkMsaUNBQUMsZUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQVUsS0FEWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQTtBQUFBLE1BTEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBTUc7QUFBQSxJQUVIO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxNQUFLO0FBQUEsUUFDTCxTQUNFLHVCQUFDLFNBQU0sT0FBTyxDQUFDLFVBQVUsU0FBUyxPQUFPLEdBQ3ZDLGlDQUFDLGVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFVLEtBRFo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUE7QUFBQSxNQUxKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQU1HO0FBQUEsSUFHSDtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsTUFBSztBQUFBLFFBQ0wsU0FDRSx1QkFBQyxTQUFNLE9BQU8sQ0FBQyxVQUFVLFNBQVMsT0FBTyxHQUN2QyxpQ0FBQyxlQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBVSxLQURaO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBO0FBQUEsTUFMSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFNRztBQUFBLElBRUg7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLE1BQUs7QUFBQSxRQUNMLFNBQ0UsdUJBQUMsU0FBTSxPQUFPLENBQUMsVUFBVSxTQUFTLE9BQU8sR0FDdkMsaUNBQUMsZUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQVUsS0FEWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQTtBQUFBLE1BTEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBTUc7QUFBQSxJQUVIO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxNQUFLO0FBQUEsUUFDTCxTQUNFLHVCQUFDLFNBQU0sT0FBTyxDQUFDLFVBQVUsU0FBUyxPQUFPLEdBQ3ZDLGlDQUFDLGNBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFTLEtBRFg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUE7QUFBQSxNQUxKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQU1HO0FBQUEsSUFJSCx1QkFBQyxTQUFNLE1BQUssWUFBVyxTQUFTLHVCQUFDLFlBQVMsSUFBRyxZQUFXLFNBQU8sUUFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUErQixLQUEvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQW1FO0FBQUEsSUFDbkUsdUJBQUMsU0FBTSxNQUFLLGlCQUFnQixTQUFTLHVCQUFDLFlBQVMsSUFBRyxjQUFhLFNBQU8sUUFBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFpQyxLQUF0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTBFO0FBQUEsSUFDMUUsdUJBQUMsU0FBTSxNQUFLLFdBQVUsU0FBUyx1QkFBQyxZQUFTLElBQUcsU0FBUSxTQUFPLFFBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBNEIsS0FBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUErRDtBQUFBLElBQy9ELHVCQUFDLFNBQU0sTUFBSyxrQkFBaUIsU0FBUyx1QkFBQyxZQUFTLElBQUcsU0FBUSxTQUFPLFFBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBNEIsS0FBbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFzRTtBQUFBLElBQ3RFLHVCQUFDLFNBQU0sTUFBSyxVQUFTLFNBQVMsdUJBQUMsWUFBUyxJQUFHLGNBQWEsU0FBTyxRQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWlDLEtBQS9EO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBbUU7QUFBQSxJQUVuRSx1QkFBQyxTQUFNLE1BQUssS0FBSSxTQUFTLHVCQUFDLGNBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFTLEtBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBc0M7QUFBQSxPQXBIeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXFIQTtBQUVKO0FBQUNDLEtBekhlRDtBQUFTLElBQUFDO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbIlJvdXRlcyIsIlJvdXRlIiwiTmF2aWdhdGUiLCJHdWFyZCIsIkhvbWUiLCJFeHBsb3JlIiwiU2VhcmNoIiwiRmluZCIsIlNwYWNlRGV0YWlsIiwiQ29tcGFyZSIsIlNhdmVkIiwiUG9ydGZvbGlvIiwiTGlzdFNwYWNlIiwiUmVxdWVzdHMiLCJQcm9maWxlIiwiQXV0aCIsIk1lc3NhZ2VzIiwiQm9va2luZ3MiLCJBZG1pbiIsIlNldHRpbmdzIiwiTm90Rm91bmQiLCJBcHBSb3V0ZXMiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJBcHBSb3V0ZXMudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IFJvdXRlcywgUm91dGUsIE5hdmlnYXRlIH0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIjtcbmltcG9ydCB7IEd1YXJkIH0gZnJvbSBcIi4vR3VhcmRcIjtcbmltcG9ydCBIb21lIGZyb20gXCJAL3BhZ2VzL0hvbWVcIjtcbmltcG9ydCBFeHBsb3JlIGZyb20gXCJAL3BhZ2VzL0V4cGxvcmVcIjtcbmltcG9ydCBTZWFyY2ggZnJvbSBcIkAvcGFnZXMvU2VhcmNoXCI7XG5pbXBvcnQgRmluZCBmcm9tIFwiQC9wYWdlcy9GaW5kXCI7XG5pbXBvcnQgU3BhY2VEZXRhaWwgZnJvbSBcIkAvcGFnZXMvU3BhY2VEZXRhaWxcIjtcbmltcG9ydCBDb21wYXJlIGZyb20gXCJAL3BhZ2VzL0NvbXBhcmVcIjtcbmltcG9ydCBTYXZlZCBmcm9tIFwiQC9wYWdlcy9TYXZlZFwiO1xuaW1wb3J0IFBvcnRmb2xpbyBmcm9tIFwiQC9wYWdlcy9Qb3J0Zm9saW9cIjtcbmltcG9ydCBMaXN0U3BhY2UgZnJvbSBcIkAvcGFnZXMvTGlzdFNwYWNlXCI7XG5pbXBvcnQgUmVxdWVzdHMgZnJvbSBcIkAvcGFnZXMvUmVxdWVzdHNcIjtcbmltcG9ydCBQcm9maWxlIGZyb20gXCJAL3BhZ2VzL1Byb2ZpbGVcIjtcbmltcG9ydCBBdXRoIGZyb20gXCJAL3BhZ2VzL0F1dGhcIjtcbmltcG9ydCBNZXNzYWdlcyBmcm9tIFwiQC9wYWdlcy9NZXNzYWdlc1wiO1xuaW1wb3J0IEJvb2tpbmdzIGZyb20gXCJAL3BhZ2VzL0Jvb2tpbmdzXCI7XG5pbXBvcnQgQWRtaW4gZnJvbSBcIkAvcGFnZXMvQWRtaW5cIjtcbmltcG9ydCBTZXR0aW5ncyBmcm9tIFwiQC9wYWdlcy9TZXR0aW5nc1wiO1xuaW1wb3J0IE5vdEZvdW5kIGZyb20gXCJAL3BhZ2VzL05vdEZvdW5kXCI7XG5cbmV4cG9ydCBmdW5jdGlvbiBBcHBSb3V0ZXMoKSB7XG4gIHJldHVybiAoXG4gICAgPFJvdXRlcz5cbiAgICAgIHsvKiBPcGVuIHRvIGV2ZXJ5b25lICovfVxuICAgICAgPFJvdXRlIHBhdGg9XCIvXCIgZWxlbWVudD17PEhvbWUgLz59IC8+XG4gICAgICA8Um91dGUgcGF0aD1cIi9leHBsb3JlXCIgZWxlbWVudD17PEV4cGxvcmUgLz59IC8+XG4gICAgICA8Um91dGUgcGF0aD1cIi9zZWFyY2hcIiBlbGVtZW50PXs8U2VhcmNoIC8+fSAvPlxuICAgICAgPFJvdXRlIHBhdGg9XCIvZmluZFwiIGVsZW1lbnQ9ezxGaW5kIC8+fSAvPlxuICAgICAgPFJvdXRlIHBhdGg9XCIvc3BhY2UvOmlkXCIgZWxlbWVudD17PFNwYWNlRGV0YWlsIC8+fSAvPlxuICAgICAgPFJvdXRlIHBhdGg9XCIvY29tcGFyZVwiIGVsZW1lbnQ9ezxDb21wYXJlIC8+fSAvPlxuICAgICAgPFJvdXRlIHBhdGg9XCIvcmVxdWVzdHNcIiBlbGVtZW50PXs8UmVxdWVzdHMgLz59IC8+XG5cbiAgICAgIDxSb3V0ZSBwYXRoPVwiL3NpZ25pblwiIGVsZW1lbnQ9ezxBdXRoIGluaXRpYWw9XCJzaWduaW5cIiAvPn0gLz5cbiAgICAgIDxSb3V0ZSBwYXRoPVwiL3NpZ251cFwiIGVsZW1lbnQ9ezxBdXRoIGluaXRpYWw9XCJzaWdudXBcIiAvPn0gLz5cblxuICAgICAgey8qIE5lZWRzIGFuIGFjY291bnQgKi99XG4gICAgICA8Um91dGVcbiAgICAgICAgcGF0aD1cIi9zYXZlZFwiXG4gICAgICAgIGVsZW1lbnQ9e1xuICAgICAgICAgIDxHdWFyZCBhbGxvdz17W1wicmVudGVyXCIsIFwib3duZXJcIiwgXCJhZG1pblwiXX0+XG4gICAgICAgICAgICA8U2F2ZWQgLz5cbiAgICAgICAgICA8L0d1YXJkPlxuICAgICAgICB9XG4gICAgICAvPlxuICAgICAgPFJvdXRlXG4gICAgICAgIHBhdGg9XCIvbWVzc2FnZXNcIlxuICAgICAgICBlbGVtZW50PXtcbiAgICAgICAgICA8R3VhcmQgYWxsb3c9e1tcInJlbnRlclwiLCBcIm93bmVyXCIsIFwiYWRtaW5cIl19PlxuICAgICAgICAgICAgPE1lc3NhZ2VzIC8+XG4gICAgICAgICAgPC9HdWFyZD5cbiAgICAgICAgfVxuICAgICAgLz5cbiAgICAgIDxSb3V0ZVxuICAgICAgICBwYXRoPVwiL21lc3NhZ2VzLzppZFwiXG4gICAgICAgIGVsZW1lbnQ9e1xuICAgICAgICAgIDxHdWFyZCBhbGxvdz17W1wicmVudGVyXCIsIFwib3duZXJcIiwgXCJhZG1pblwiXX0+XG4gICAgICAgICAgICA8TWVzc2FnZXMgLz5cbiAgICAgICAgICA8L0d1YXJkPlxuICAgICAgICB9XG4gICAgICAvPlxuICAgICAgPFJvdXRlXG4gICAgICAgIHBhdGg9XCIvYm9va2luZ3NcIlxuICAgICAgICBlbGVtZW50PXtcbiAgICAgICAgICA8R3VhcmQgYWxsb3c9e1tcInJlbnRlclwiLCBcIm93bmVyXCIsIFwiYWRtaW5cIl19PlxuICAgICAgICAgICAgPEJvb2tpbmdzIC8+XG4gICAgICAgICAgPC9HdWFyZD5cbiAgICAgICAgfVxuICAgICAgLz5cbiAgICAgIHsvKiBBZG1pbiBvbmx5IOKAlCB0aGUgZGF0YWJhc2UgcmVmdXNlcyB0aGVzZSBjYWxscyBmb3IgYW55b25lIGVsc2UsIHNvXG4gICAgICAgICAgdGhlIGd1YXJkIGlzIGNvbnZlbmllbmNlIHJhdGhlciB0aGFuIHRoZSBwcm90ZWN0aW9uLiAqL31cbiAgICAgIDxSb3V0ZVxuICAgICAgICBwYXRoPVwiL2FkbWluXCJcbiAgICAgICAgZWxlbWVudD17XG4gICAgICAgICAgPEd1YXJkIGFsbG93PXtbXCJhZG1pblwiXX0+XG4gICAgICAgICAgICA8QWRtaW4gLz5cbiAgICAgICAgICA8L0d1YXJkPlxuICAgICAgICB9XG4gICAgICAvPlxuICAgICAgPFJvdXRlXG4gICAgICAgIHBhdGg9XCIvYWNjb3VudFwiXG4gICAgICAgIGVsZW1lbnQ9e1xuICAgICAgICAgIDxHdWFyZCBhbGxvdz17W1wicmVudGVyXCIsIFwib3duZXJcIiwgXCJhZG1pblwiXX0+XG4gICAgICAgICAgICA8UHJvZmlsZSAvPlxuICAgICAgICAgIDwvR3VhcmQ+XG4gICAgICAgIH1cbiAgICAgIC8+XG5cbiAgICAgIHsvKiBPd25lciBvbmx5ICovfVxuICAgICAgey8qIE93bmVyIHRvb2xzIG5lZWQgYW4gYWNjb3VudCwgbm90IGEgc2VwYXJhdGUga2luZCBvZiBhY2NvdW50LiAqL31cbiAgICAgIDxSb3V0ZVxuICAgICAgICBwYXRoPVwiL3BvcnRmb2xpb1wiXG4gICAgICAgIGVsZW1lbnQ9e1xuICAgICAgICAgIDxHdWFyZCBhbGxvdz17W1wicmVudGVyXCIsIFwib3duZXJcIiwgXCJhZG1pblwiXX0+XG4gICAgICAgICAgICA8UG9ydGZvbGlvIC8+XG4gICAgICAgICAgPC9HdWFyZD5cbiAgICAgICAgfVxuICAgICAgLz5cbiAgICAgIDxSb3V0ZVxuICAgICAgICBwYXRoPVwiL2xpc3RcIlxuICAgICAgICBlbGVtZW50PXtcbiAgICAgICAgICA8R3VhcmQgYWxsb3c9e1tcInJlbnRlclwiLCBcIm93bmVyXCIsIFwiYWRtaW5cIl19PlxuICAgICAgICAgICAgPExpc3RTcGFjZSAvPlxuICAgICAgICAgIDwvR3VhcmQ+XG4gICAgICAgIH1cbiAgICAgIC8+XG4gICAgICB7LyogU2FtZSBjb21wb25lbnQsIGVkaXRpbmcgYW4gZXhpc3Rpbmcgc3BhY2UuICovfVxuICAgICAgPFJvdXRlXG4gICAgICAgIHBhdGg9XCIvbGlzdC86aWRcIlxuICAgICAgICBlbGVtZW50PXtcbiAgICAgICAgICA8R3VhcmQgYWxsb3c9e1tcInJlbnRlclwiLCBcIm93bmVyXCIsIFwiYWRtaW5cIl19PlxuICAgICAgICAgICAgPExpc3RTcGFjZSAvPlxuICAgICAgICAgIDwvR3VhcmQ+XG4gICAgICAgIH1cbiAgICAgIC8+XG4gICAgICA8Um91dGVcbiAgICAgICAgcGF0aD1cIi9zcGFjZS86aWQvZWRpdFwiXG4gICAgICAgIGVsZW1lbnQ9e1xuICAgICAgICAgIDxHdWFyZCBhbGxvdz17W1wicmVudGVyXCIsIFwib3duZXJcIiwgXCJhZG1pblwiXX0+XG4gICAgICAgICAgICA8TGlzdFNwYWNlIC8+XG4gICAgICAgICAgPC9HdWFyZD5cbiAgICAgICAgfVxuICAgICAgLz5cbiAgICAgIDxSb3V0ZVxuICAgICAgICBwYXRoPVwiL3NldHRpbmdzXCJcbiAgICAgICAgZWxlbWVudD17XG4gICAgICAgICAgPEd1YXJkIGFsbG93PXtbXCJyZW50ZXJcIiwgXCJvd25lclwiLCBcImFkbWluXCJdfT5cbiAgICAgICAgICAgIDxTZXR0aW5ncyAvPlxuICAgICAgICAgIDwvR3VhcmQ+XG4gICAgICAgIH1cbiAgICAgIC8+XG5cbiAgICAgIHsvKiBMZWdhY3kgcGF0aHMgZnJvbSBlYXJsaWVyIHBoYXNlcyAqL31cbiAgICAgIDxSb3V0ZSBwYXRoPVwiL3Byb2ZpbGVcIiBlbGVtZW50PXs8TmF2aWdhdGUgdG89XCIvYWNjb3VudFwiIHJlcGxhY2UgLz59IC8+XG4gICAgICA8Um91dGUgcGF0aD1cIi9wcm9wZXJ0eS86aWRcIiBlbGVtZW50PXs8TmF2aWdhdGUgdG89XCIvcG9ydGZvbGlvXCIgcmVwbGFjZSAvPn0gLz5cbiAgICAgIDxSb3V0ZSBwYXRoPVwiL2ludGFrZVwiIGVsZW1lbnQ9ezxOYXZpZ2F0ZSB0bz1cIi9maW5kXCIgcmVwbGFjZSAvPn0gLz5cbiAgICAgIDxSb3V0ZSBwYXRoPVwiL2xpc3QtcHJvcGVydHlcIiBlbGVtZW50PXs8TmF2aWdhdGUgdG89XCIvbGlzdFwiIHJlcGxhY2UgLz59IC8+XG4gICAgICA8Um91dGUgcGF0aD1cIi9vd25lclwiIGVsZW1lbnQ9ezxOYXZpZ2F0ZSB0bz1cIi9wb3J0Zm9saW9cIiByZXBsYWNlIC8+fSAvPlxuXG4gICAgICA8Um91dGUgcGF0aD1cIipcIiBlbGVtZW50PXs8Tm90Rm91bmQgLz59IC8+XG4gICAgPC9Sb3V0ZXM+XG4gICk7XG59XG4iXSwiZmlsZSI6IkQ6L0kySSBQcm9qZWN0IC0gSGFiaXRvL0FwcCBGb2xkZXIvaGFiaXRvL3NyYy9yb3V0ZXMvQXBwUm91dGVzLnRzeCJ9