import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/onboarding/FirstRun.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=9ceb86a3"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("D:/I2I Project - Habito/App Folder/habito/src/components/onboarding/FirstRun.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9ceb86a3"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import { useLocation } from "/node_modules/.vite/deps/react-router-dom.js?v=9ceb86a3";
import { Onboarding, hasOnboarded } from "/src/components/onboarding/Onboarding.tsx";
export function FirstRun() {
  _s();
  const { pathname } = useLocation();
  const [show, setShow] = useState(false);
  useEffect(() => {
    const deepLink = pathname !== "/" && pathname !== "/explore";
    if (!hasOnboarded() && !deepLink) setShow(true);
  }, []);
  if (!show) return null;
  return /* @__PURE__ */ jsxDEV(Onboarding, { onDone: () => setShow(false) }, void 0, false, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/onboarding/FirstRun.tsx",
    lineNumber: 42,
    columnNumber: 10
  }, this);
}
_s(FirstRun, "zxiJCc2Yn1XHwtkhTzWzD7PmieA=", false, function() {
  return [useLocation];
});
_c = FirstRun;
var _c;
$RefreshReg$(_c, "FirstRun");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/I2I Project - Habito/App Folder/habito/src/components/onboarding/FirstRun.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/I2I Project - Habito/App Folder/habito/src/components/onboarding/FirstRun.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0JTOzs7Ozs7Ozs7Ozs7Ozs7OztBQXRCVCxTQUFTQSxXQUFXQyxnQkFBZ0I7QUFDcEMsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLFlBQVlDLG9CQUFvQjtBQVFsQyxnQkFBU0MsV0FBVztBQUFBQyxLQUFBO0FBQ3pCLFFBQU0sRUFBRUMsU0FBUyxJQUFJTCxZQUFZO0FBQ2pDLFFBQU0sQ0FBQ00sTUFBTUMsT0FBTyxJQUFJUixTQUFTLEtBQUs7QUFFdENELFlBQVUsTUFBTTtBQUNkLFVBQU1VLFdBQVdILGFBQWEsT0FBT0EsYUFBYTtBQUNsRCxRQUFJLENBQUNILGFBQWEsS0FBSyxDQUFDTSxTQUFVRCxTQUFRLElBQUk7QUFBQSxFQUdoRCxHQUFHLEVBQUU7QUFFTCxNQUFJLENBQUNELEtBQU0sUUFBTztBQUNsQixTQUFPLHVCQUFDLGNBQVcsUUFBUSxNQUFNQyxRQUFRLEtBQUssS0FBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUF5QztBQUNsRDtBQUFDSCxHQWJlRCxVQUFRO0FBQUEsVUFDREgsV0FBVztBQUFBO0FBQUEsS0FEbEJHO0FBQVEsSUFBQU07QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJ1c2VMb2NhdGlvbiIsIk9uYm9hcmRpbmciLCJoYXNPbmJvYXJkZWQiLCJGaXJzdFJ1biIsIl9zIiwicGF0aG5hbWUiLCJzaG93Iiwic2V0U2hvdyIsImRlZXBMaW5rIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiRmlyc3RSdW4udHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IHVzZUxvY2F0aW9uIH0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIjtcbmltcG9ydCB7IE9uYm9hcmRpbmcsIGhhc09uYm9hcmRlZCB9IGZyb20gXCIuL09uYm9hcmRpbmdcIjtcblxuLyoqXG4gKiBEZWNpZGVzIHdoZXRoZXIgZmlyc3QtcnVuIG9uYm9hcmRpbmcgc2hvdWxkIGFwcGVhci5cbiAqXG4gKiBPbmx5IG9uIGEgZ2VudWluZSBmaXJzdCBhcnJpdmFsLCBhbmQgbmV2ZXIgb24gYSBkZWVwIGxpbmsg4oCUIHNvbWVvbmUgd2hvXG4gKiBmb2xsb3dlZCBhIHNoYXJlZCBsaXN0aW5nIHdhbnRzIHRoYXQgbGlzdGluZywgbm90IHRocmVlIHF1ZXN0aW9ucy5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIEZpcnN0UnVuKCkge1xuICBjb25zdCB7IHBhdGhuYW1lIH0gPSB1c2VMb2NhdGlvbigpO1xuICBjb25zdCBbc2hvdywgc2V0U2hvd10gPSB1c2VTdGF0ZShmYWxzZSk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBjb25zdCBkZWVwTGluayA9IHBhdGhuYW1lICE9PSBcIi9cIiAmJiBwYXRobmFtZSAhPT0gXCIvZXhwbG9yZVwiO1xuICAgIGlmICghaGFzT25ib2FyZGVkKCkgJiYgIWRlZXBMaW5rKSBzZXRTaG93KHRydWUpO1xuICAgIC8vIE9ubHkgb24gbW91bnQ6IG5hdmlnYXRpbmcgbGF0ZXIgc2hvdWxkIG5ldmVyIHN1bW1vbiBpdC5cbiAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgcmVhY3QtaG9va3MvZXhoYXVzdGl2ZS1kZXBzXG4gIH0sIFtdKTtcblxuICBpZiAoIXNob3cpIHJldHVybiBudWxsO1xuICByZXR1cm4gPE9uYm9hcmRpbmcgb25Eb25lPXsoKSA9PiBzZXRTaG93KGZhbHNlKX0gLz47XG59XG4iXSwiZmlsZSI6IkQ6L0kySSBQcm9qZWN0IC0gSGFiaXRvL0FwcCBGb2xkZXIvaGFiaXRvL3NyYy9jb21wb25lbnRzL29uYm9hcmRpbmcvRmlyc3RSdW4udHN4In0=