import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Messages.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=9ceb86a3"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("D:/I2I Project - Habito/App Folder/habito/src/pages/Messages.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9ceb86a3"; const useCallback = __vite__cjsImport3_react["useCallback"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useRef = __vite__cjsImport3_react["useRef"]; const useState = __vite__cjsImport3_react["useState"];
import { Link, useNavigate, useParams } from "/node_modules/.vite/deps/react-router-dom.js?v=9ceb86a3";
import { ArrowLeft, Send, MessagesSquare, Check, CheckCheck } from "/node_modules/.vite/deps/lucide-react.js?v=9ceb86a3";
import { db } from "/src/lib/api/index.ts";
import { useAuth } from "/src/hooks/useAuth.tsx";
import { PageHeader } from "/src/components/layout/PageHeader.tsx";
import { Button } from "/src/components/ui/Button.tsx";
import { Skeleton } from "/src/components/ui/Skeleton.tsx";
import { cn } from "/src/lib/cn.ts";
import { useI18n } from "/src/i18n/index.tsx";
export default function Messages() {
  _s();
  const { t } = useI18n();
  const { id } = useParams();
  const navigate = useNavigate();
  const [conversations, setConversations] = useState(null);
  const [error, setError] = useState(null);
  const load = useCallback(async () => {
    try {
      setConversations(await db.conversations());
      setError(null);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not load your messages.");
      setConversations([]);
    }
  }, []);
  useEffect(() => {
    void load();
    try {
      return db.subscribeToMessages(() => void load());
    } catch {
      return void 0;
    }
  }, [load]);
  const active = conversations?.find((c) => c.id === id) ?? null;
  const totalUnread = (conversations ?? []).reduce((sum, c) => sum + c.unread, 0);
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(
      PageHeader,
      {
        title: t("messages.title"),
        lead: totalUnread > 0 ? `${totalUnread} unread ${totalUnread === 1 ? "message" : "messages"}.` : "Every conversation is tied to the space it's about."
      },
      void 0,
      false,
      {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Messages.tsx",
        lineNumber: 70,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { className: "container-page py-6 md:py-8", children: [
      error && /* @__PURE__ */ jsxDEV("p", { className: "mb-4 rounded-card bg-danger-100 p-4 text-sm text-danger-600", children: error }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Messages.tsx",
        lineNumber: 81,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "grid gap-6 lg:grid-cols-[20rem_1fr]", children: [
        /* @__PURE__ */ jsxDEV("aside", { className: cn(id && "hidden lg:block"), children: /* @__PURE__ */ jsxDEV(ConversationList, { items: conversations, activeId: id ?? null }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Messages.tsx",
          lineNumber: 87,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Messages.tsx",
          lineNumber: 86,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("section", { className: cn(!id && "hidden lg:block"), children: id ? /* @__PURE__ */ jsxDEV(
          Thread,
          {
            conversationId: id,
            conversation: active,
            onBack: () => navigate("/messages"),
            onSent: () => void load()
          },
          void 0,
          false,
          {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Messages.tsx",
            lineNumber: 93,
            columnNumber: 13
          },
          this
        ) : /* @__PURE__ */ jsxDEV("div", { className: "flex h-full min-h-72 flex-col items-center justify-center rounded-card bg-surface p-10 text-center ring-1 ring-hairline", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "mb-3 flex size-11 items-center justify-center rounded-full bg-aqua-100 text-aqua-700", children: /* @__PURE__ */ jsxDEV(MessagesSquare, { size: 20, "aria-hidden": true }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Messages.tsx",
            lineNumber: 102,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Messages.tsx",
            lineNumber: 101,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "font-display font-bold text-ink", children: "Pick a conversation" }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Messages.tsx",
            lineNumber: 104,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "mt-1 max-w-xs text-sm text-muted", children: "Or open a space and send an inquiry to start a new one." }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Messages.tsx",
            lineNumber: 105,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Messages.tsx",
          lineNumber: 100,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Messages.tsx",
          lineNumber: 91,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Messages.tsx",
        lineNumber: 84,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Messages.tsx",
      lineNumber: 79,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Messages.tsx",
    lineNumber: 69,
    columnNumber: 5
  }, this);
}
_s(Messages, "IYPdl4VJ+vbH/epGzr8+dduuRgA=", false, function() {
  return [useI18n, useParams, useNavigate];
});
_c = Messages;
function ConversationList({ items, activeId }) {
  if (items === null) {
    return /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [0, 1, 2].map(
      (i) => /* @__PURE__ */ jsxDEV(Skeleton, { className: "h-20 w-full rounded-card" }, i, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Messages.tsx",
        lineNumber: 124,
        columnNumber: 9
      }, this)
    ) }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Messages.tsx",
      lineNumber: 122,
      columnNumber: 7
    }, this);
  }
  if (items.length === 0) {
    return /* @__PURE__ */ jsxDEV("div", { className: "rounded-card bg-surface p-8 text-center ring-1 ring-hairline", children: [
      /* @__PURE__ */ jsxDEV("span", { className: "mx-auto mb-3 flex size-11 items-center justify-center rounded-full bg-aqua-100 text-aqua-700", children: /* @__PURE__ */ jsxDEV(MessagesSquare, { size: 20, "aria-hidden": true }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Messages.tsx",
        lineNumber: 134,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Messages.tsx",
        lineNumber: 133,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "font-display font-bold text-ink", children: "No conversations yet." }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Messages.tsx",
        lineNumber: 136,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "mt-1.5 text-sm leading-relaxed text-muted", children: "Send an inquiry on a space and the thread appears here." }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Messages.tsx",
        lineNumber: 137,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Link, { to: "/search", className: "mt-4 inline-block", children: /* @__PURE__ */ jsxDEV(Button, { size: "sm", variant: "secondary", children: "Browse spaces" }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Messages.tsx",
        lineNumber: 141,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Messages.tsx",
        lineNumber: 140,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Messages.tsx",
      lineNumber: 132,
      columnNumber: 7
    }, this);
  }
  return /* @__PURE__ */ jsxDEV("ul", { className: "space-y-2", children: items.map(
    (c) => /* @__PURE__ */ jsxDEV("li", { children: /* @__PURE__ */ jsxDEV(
      Link,
      {
        to: `/messages/${c.id}`,
        className: cn(
          "flex items-center gap-3 rounded-card p-3 ring-1 transition-colors",
          c.id === activeId ? "bg-aqua-50 ring-aqua-600" : "bg-surface ring-hairline hover:ring-hairline-strong"
        ),
        children: [
          c.spaceImage ? /* @__PURE__ */ jsxDEV("img", { src: c.spaceImage, alt: "", className: "size-12 shrink-0 rounded-xl object-cover" }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Messages.tsx",
            lineNumber: 161,
            columnNumber: 11
          }, this) : /* @__PURE__ */ jsxDEV("span", { className: "size-12 shrink-0 rounded-xl bg-ivory-deep", "aria-hidden": true }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Messages.tsx",
            lineNumber: 163,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "min-w-0 flex-1", children: [
            /* @__PURE__ */ jsxDEV("p", { className: "flex items-center gap-2", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "truncate font-semibold text-ink", children: c.counterpartName }, void 0, false, {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Messages.tsx",
                lineNumber: 168,
                columnNumber: 17
              }, this),
              c.unread > 0 && /* @__PURE__ */ jsxDEV("span", { className: "shrink-0 rounded-full bg-aqua-600 px-1.5 text-[0.65rem] font-bold tnum text-white", children: c.unread }, void 0, false, {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Messages.tsx",
                lineNumber: 170,
                columnNumber: 15
              }, this)
            ] }, void 0, true, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Messages.tsx",
              lineNumber: 167,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "truncate text-xs text-muted", children: [
              c.spaceName,
              c.propertyArea && ` · ${c.propertyArea}`
            ] }, void 0, true, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Messages.tsx",
              lineNumber: 175,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: cn("mt-0.5 truncate text-sm", c.unread > 0 ? "font-medium text-ink" : "text-ink-soft"), children: c.lastMessage || "No messages yet" }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Messages.tsx",
              lineNumber: 179,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Messages.tsx",
            lineNumber: 166,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "shrink-0 self-start text-xs text-muted", children: whenShort(c.lastMessageAt) }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Messages.tsx",
            lineNumber: 184,
            columnNumber: 13
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Messages.tsx",
        lineNumber: 153,
        columnNumber: 11
      },
      this
    ) }, c.id, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Messages.tsx",
      lineNumber: 152,
      columnNumber: 7
    }, this)
  ) }, void 0, false, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Messages.tsx",
    lineNumber: 150,
    columnNumber: 5
  }, this);
}
_c2 = ConversationList;
function Thread({
  conversationId,
  conversation,
  onBack,
  onSent
}) {
  _s2();
  const { account, configured } = useAuth();
  const [messages, setMessages] = useState(null);
  const [draft, setDraft] = useState("");
  const [sending, setSending] = useState(false);
  const [error, setError] = useState(null);
  const endRef = useRef(null);
  const load = useCallback(async () => {
    try {
      const rows = await db.messages(conversationId);
      const seen = /* @__PURE__ */ new Set();
      setMessages(rows.filter((m) => seen.has(m.id) ? false : seen.add(m.id)));
      await db.markRead(conversationId);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not load this conversation.");
      setMessages([]);
    }
  }, [conversationId]);
  useEffect(() => {
    setMessages(null);
    void load();
    try {
      return db.subscribeToMessages(() => void load());
    } catch {
      return void 0;
    }
  }, [load]);
  useEffect(() => {
    endRef.current?.scrollIntoView({ block: "end" });
  }, [messages?.length]);
  const send = async () => {
    const body = draft.trim();
    if (!body) return;
    setSending(true);
    setError(null);
    try {
      const sent = await db.sendMessage(conversationId, body);
      setDraft("");
      setMessages((prev) => {
        const current = prev ?? [];
        return current.some((m) => m.id === sent.id) ? current : [...current, sent];
      });
      onSent();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Your message didn't send.");
    } finally {
      setSending(false);
    }
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "flex h-[70vh] min-h-96 flex-col overflow-hidden rounded-card bg-surface ring-1 ring-hairline", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 border-b border-hairline p-3.5", children: [
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          onClick: onBack,
          "aria-label": "Back to conversations",
          className: "rounded-full p-1.5 text-muted hover:bg-ivory-deep hover:text-ink lg:hidden",
          children: /* @__PURE__ */ jsxDEV(ArrowLeft, { size: 18, "aria-hidden": true }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Messages.tsx",
            lineNumber: 275,
            columnNumber: 11
          }, this)
        },
        void 0,
        false,
        {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Messages.tsx",
          lineNumber: 269,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { className: "min-w-0 flex-1", children: [
        /* @__PURE__ */ jsxDEV("p", { className: "truncate font-semibold text-ink", children: conversation?.counterpartName ?? "Conversation" }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Messages.tsx",
          lineNumber: 279,
          columnNumber: 11
        }, this),
        conversation && /* @__PURE__ */ jsxDEV("p", { className: "truncate text-xs text-muted", children: [
          conversation.youAreOwner ? "Asking about" : "Your inquiry about",
          " ",
          conversation.spaceName
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Messages.tsx",
          lineNumber: 281,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Messages.tsx",
        lineNumber: 278,
        columnNumber: 9
      }, this),
      conversation?.spaceId && /* @__PURE__ */ jsxDEV(Link, { to: `/space/${conversation.spaceId}`, children: /* @__PURE__ */ jsxDEV(Button, { size: "sm", variant: "secondary", children: "View space" }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Messages.tsx",
        lineNumber: 289,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Messages.tsx",
        lineNumber: 288,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Messages.tsx",
      lineNumber: 268,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex-1 space-y-3 overflow-y-auto p-4", children: [
      messages === null ? /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: [
        /* @__PURE__ */ jsxDEV(Skeleton, { className: "h-12 w-2/3" }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Messages.tsx",
          lineNumber: 300,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(Skeleton, { className: "ml-auto h-12 w-1/2" }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Messages.tsx",
          lineNumber: 301,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(Skeleton, { className: "h-12 w-3/5" }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Messages.tsx",
          lineNumber: 302,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Messages.tsx",
        lineNumber: 299,
        columnNumber: 9
      }, this) : messages.length === 0 ? /* @__PURE__ */ jsxDEV("p", { className: "py-10 text-center text-sm text-muted", children: "No messages yet. Say hello and ask what you need to know." }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Messages.tsx",
        lineNumber: 305,
        columnNumber: 9
      }, this) : messages.map((m, i) => {
        const showDay = i === 0 || dayOf(m.sentAt) !== dayOf(messages[i - 1].sentAt);
        return /* @__PURE__ */ jsxDEV("div", { children: [
          showDay && /* @__PURE__ */ jsxDEV("p", { className: "my-4 text-center text-xs font-semibold text-muted", children: dayLabel(m.sentAt) }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Messages.tsx",
            lineNumber: 314,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: cn("flex", m.mine ? "justify-end" : "justify-start"), children: /* @__PURE__ */ jsxDEV(
            "div",
            {
              className: cn(
                "max-w-[85%] rounded-2xl px-3.5 py-2.5 sm:max-w-[70%]",
                m.mine ? "bg-ink text-ivory" : "bg-ivory-deep text-ink"
              ),
              children: [
                /* @__PURE__ */ jsxDEV("p", { className: "whitespace-pre-wrap break-words text-sm leading-relaxed", children: m.body }, void 0, false, {
                  fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Messages.tsx",
                  lineNumber: 323,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "p",
                  {
                    className: cn(
                      "mt-1 flex items-center justify-end gap-1 text-[0.7rem]",
                      m.mine ? "text-ivory/60" : "text-muted"
                    ),
                    children: [
                      timeOf(m.sentAt),
                      m.mine && (m.readAt ? /* @__PURE__ */ jsxDEV(CheckCheck, { size: 12, "aria-label": "Read" }, void 0, false, {
                        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Messages.tsx",
                        lineNumber: 333,
                        columnNumber: 21
                      }, this) : /* @__PURE__ */ jsxDEV(Check, { size: 12, "aria-label": "Sent" }, void 0, false, {
                        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Messages.tsx",
                        lineNumber: 335,
                        columnNumber: 21
                      }, this))
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Messages.tsx",
                    lineNumber: 324,
                    columnNumber: 21
                  },
                  this
                )
              ]
            },
            void 0,
            true,
            {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Messages.tsx",
              lineNumber: 317,
              columnNumber: 19
            },
            this
          ) }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Messages.tsx",
            lineNumber: 316,
            columnNumber: 17
          }, this)
        ] }, m.id, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Messages.tsx",
          lineNumber: 312,
          columnNumber: 13
        }, this);
      }),
      /* @__PURE__ */ jsxDEV("div", { ref: endRef }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Messages.tsx",
        lineNumber: 344,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Messages.tsx",
      lineNumber: 297,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "border-t border-hairline p-3", children: [
      error && /* @__PURE__ */ jsxDEV("p", { className: "mb-2 text-sm text-danger-600", children: error }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Messages.tsx",
        lineNumber: 349,
        columnNumber: 19
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-end gap-2", children: [
        /* @__PURE__ */ jsxDEV("label", { className: "flex-1", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "sr-only", children: "Your message" }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Messages.tsx",
            lineNumber: 353,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            "textarea",
            {
              rows: 1,
              value: draft,
              onChange: (e) => setDraft(e.target.value),
              onKeyDown: (e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  void send();
                }
              },
              placeholder: configured && !account ? "Sign in to reply" : "Write a message",
              disabled: configured && !account,
              className: "max-h-32 w-full resize-y rounded-2xl bg-ivory px-3.5 py-2.5 text-[0.9375rem] text-ink ring-1 ring-hairline-strong focus:outline-none focus:ring-2 focus:ring-aqua-600 disabled:opacity-60"
            },
            void 0,
            false,
            {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Messages.tsx",
              lineNumber: 354,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Messages.tsx",
          lineNumber: 352,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          Button,
          {
            onClick: () => void send(),
            disabled: sending || draft.trim().length === 0,
            "aria-label": "Send message",
            className: "shrink-0",
            children: /* @__PURE__ */ jsxDEV(Send, { size: 16, "aria-hidden": true }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Messages.tsx",
              lineNumber: 377,
              columnNumber: 13
            }, this)
          },
          void 0,
          false,
          {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Messages.tsx",
            lineNumber: 371,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Messages.tsx",
        lineNumber: 351,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Messages.tsx",
      lineNumber: 348,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Messages.tsx",
    lineNumber: 266,
    columnNumber: 5
  }, this);
}
_s2(Thread, "tVUAJSkyAGO7z7UeZyUqnjezhgU=", false, function() {
  return [useAuth];
});
_c3 = Thread;
const dayOf = (iso) => new Date(iso).toDateString();
function dayLabel(iso) {
  const d = new Date(iso);
  const today = /* @__PURE__ */ new Date();
  const yesterday = new Date(Date.now() - 864e5);
  if (d.toDateString() === today.toDateString()) return "Today";
  if (d.toDateString() === yesterday.toDateString()) return "Yesterday";
  return d.toLocaleDateString("en-GB", { day: "numeric", month: "long" });
}
const timeOf = (iso) => new Date(iso).toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" });
function whenShort(iso) {
  const mins = Math.floor((Date.now() - new Date(iso).getTime()) / 6e4);
  if (mins < 1) return "now";
  if (mins < 60) return `${mins}m`;
  if (mins < 1440) return `${Math.floor(mins / 60)}h`;
  if (mins < 10080) return `${Math.floor(mins / 1440)}d`;
  return new Date(iso).toLocaleDateString("en-GB", { day: "numeric", month: "short" });
}
var _c, _c2, _c3;
$RefreshReg$(_c, "Messages");
$RefreshReg$(_c2, "ConversationList");
$RefreshReg$(_c3, "Thread");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/I2I Project - Habito/App Folder/habito/src/pages/Messages.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/I2I Project - Habito/App Folder/habito/src/pages/Messages.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaURJLG1CQUNFLGNBREY7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBakRKLFNBQVNBLGFBQWFDLFdBQVdDLFFBQVFDLGdCQUFnQjtBQUN6RCxTQUFTQyxNQUFNQyxhQUFhQyxpQkFBaUI7QUFDN0MsU0FBU0MsV0FBV0MsTUFBTUMsZ0JBQWdCQyxPQUFPQyxrQkFBa0I7QUFDbkUsU0FBU0MsVUFBVTtBQUNuQixTQUFTQyxlQUFlO0FBQ3hCLFNBQVNDLGtCQUFrQjtBQUMzQixTQUFTQyxjQUFjO0FBQ3ZCLFNBQVNDLGdCQUFnQjtBQUV6QixTQUFTQyxVQUFVO0FBQ25CLFNBQVNDLGVBQWU7QUFReEIsd0JBQXdCQyxXQUFXO0FBQUFDLEtBQUE7QUFDakMsUUFBTSxFQUFFQyxFQUFFLElBQUlILFFBQVE7QUFDdEIsUUFBTSxFQUFFSSxHQUFHLElBQUloQixVQUFVO0FBQ3pCLFFBQU1pQixXQUFXbEIsWUFBWTtBQUU3QixRQUFNLENBQUNtQixlQUFlQyxnQkFBZ0IsSUFBSXRCLFNBQWdDLElBQUk7QUFDOUUsUUFBTSxDQUFDdUIsT0FBT0MsUUFBUSxJQUFJeEIsU0FBd0IsSUFBSTtBQUV0RCxRQUFNeUIsT0FBTzVCLFlBQVksWUFBWTtBQUNuQyxRQUFJO0FBQ0Z5Qix1QkFBaUIsTUFBTWIsR0FBR1ksY0FBYyxDQUFDO0FBQ3pDRyxlQUFTLElBQUk7QUFBQSxJQUNmLFNBQVNFLEdBQUc7QUFDVkYsZUFBU0UsYUFBYUMsUUFBUUQsRUFBRUUsVUFBVSwrQkFBK0I7QUFDekVOLHVCQUFpQixFQUFFO0FBQUEsSUFDckI7QUFBQSxFQUNGLEdBQUcsRUFBRTtBQUVMeEIsWUFBVSxNQUFNO0FBQ2QsU0FBSzJCLEtBQUs7QUFDVixRQUFJO0FBQ0YsYUFBT2hCLEdBQUdvQixvQkFBb0IsTUFBTSxLQUFLSixLQUFLLENBQUM7QUFBQSxJQUNqRCxRQUFRO0FBQ04sYUFBT0s7QUFBQUEsSUFDVDtBQUFBLEVBQ0YsR0FBRyxDQUFDTCxJQUFJLENBQUM7QUFFVCxRQUFNTSxTQUFTVixlQUFlVyxLQUFLLENBQUNDLE1BQU1BLEVBQUVkLE9BQU9BLEVBQUUsS0FBSztBQUMxRCxRQUFNZSxlQUFlYixpQkFBaUIsSUFBSWMsT0FBTyxDQUFDQyxLQUFLSCxNQUFNRyxNQUFNSCxFQUFFSSxRQUFRLENBQUM7QUFFOUUsU0FDRSxtQ0FDRTtBQUFBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxPQUFPbkIsRUFBRSxnQkFBZ0I7QUFBQSxRQUN6QixNQUNFZ0IsY0FBYyxJQUNWLEdBQUdBLFdBQVcsV0FBV0EsZ0JBQWdCLElBQUksWUFBWSxVQUFVLE1BQ25FO0FBQUE7QUFBQSxNQUxSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQU1HO0FBQUEsSUFHSCx1QkFBQyxTQUFJLFdBQVUsK0JBQ1pYO0FBQUFBLGVBQ0MsdUJBQUMsT0FBRSxXQUFVLCtEQUErREEsbUJBQTVFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBa0Y7QUFBQSxNQUdwRix1QkFBQyxTQUFJLFdBQVUsdUNBRWI7QUFBQSwrQkFBQyxXQUFNLFdBQVdULEdBQUdLLE1BQU0saUJBQWlCLEdBQzFDLGlDQUFDLG9CQUFpQixPQUFPRSxlQUFlLFVBQVVGLE1BQU0sUUFBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE2RCxLQUQvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUdBLHVCQUFDLGFBQVEsV0FBV0wsR0FBRyxDQUFDSyxNQUFNLGlCQUFpQixHQUM1Q0EsZUFDQztBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsZ0JBQWdCQTtBQUFBQSxZQUNoQixjQUFjWTtBQUFBQSxZQUNkLFFBQVEsTUFBTVgsU0FBUyxXQUFXO0FBQUEsWUFDbEMsUUFBUSxNQUFNLEtBQUtLLEtBQUs7QUFBQTtBQUFBLFVBSjFCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUk0QixJQUc1Qix1QkFBQyxTQUFJLFdBQVUsMkhBQ2I7QUFBQSxpQ0FBQyxVQUFLLFdBQVUsd0ZBQ2QsaUNBQUMsa0JBQWUsTUFBTSxJQUFJLGVBQVcsUUFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBcUMsS0FEdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsT0FBRSxXQUFVLG1DQUFrQyxtQ0FBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBa0U7QUFBQSxVQUNsRSx1QkFBQyxPQUFFLFdBQVUsb0NBQWtDLHVFQUEvQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBUUEsS0FqQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQW1CQTtBQUFBLFdBMUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUEyQkE7QUFBQSxTQWhDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBaUNBO0FBQUEsT0EzQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTRDQTtBQUVKO0FBRUFSLEdBL0V3QkQsVUFBUTtBQUFBLFVBQ2hCRCxTQUNDWixXQUNFRCxXQUFXO0FBQUE7QUFBQSxLQUhOYztBQWlGeEIsU0FBU3NCLGlCQUFpQixFQUFFQyxPQUFPQyxTQUFvRSxHQUFHO0FBQ3hHLE1BQUlELFVBQVUsTUFBTTtBQUNsQixXQUNFLHVCQUFDLFNBQUksV0FBVSxhQUNaLFdBQUMsR0FBRyxHQUFHLENBQUMsRUFBRUU7QUFBQUEsTUFBSSxDQUFDQyxNQUNkLHVCQUFDLFlBQWlCLFdBQVUsOEJBQWJBLEdBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFzRDtBQUFBLElBQ3ZELEtBSEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUlBO0FBQUEsRUFFSjtBQUVBLE1BQUlILE1BQU1JLFdBQVcsR0FBRztBQUN0QixXQUNFLHVCQUFDLFNBQUksV0FBVSxnRUFDYjtBQUFBLDZCQUFDLFVBQUssV0FBVSxnR0FDZCxpQ0FBQyxrQkFBZSxNQUFNLElBQUksZUFBVyxRQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXFDLEtBRHZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsT0FBRSxXQUFVLG1DQUFrQyxxQ0FBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFvRTtBQUFBLE1BQ3BFLHVCQUFDLE9BQUUsV0FBVSw2Q0FBMkMsdUVBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsUUFBSyxJQUFHLFdBQVUsV0FBVSxxQkFDM0IsaUNBQUMsVUFBTyxNQUFLLE1BQUssU0FBUSxhQUFXLDZCQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBSUE7QUFBQSxTQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FhQTtBQUFBLEVBRUo7QUFFQSxTQUNFLHVCQUFDLFFBQUcsV0FBVSxhQUNYSixnQkFBTUU7QUFBQUEsSUFBSSxDQUFDUixNQUNWLHVCQUFDLFFBQ0M7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLElBQUksYUFBYUEsRUFBRWQsRUFBRTtBQUFBLFFBQ3JCLFdBQVdMO0FBQUFBLFVBQ1Q7QUFBQSxVQUNBbUIsRUFBRWQsT0FBT3FCLFdBQVcsNkJBQTZCO0FBQUEsUUFDbkQ7QUFBQSxRQUVDUDtBQUFBQSxZQUFFVyxhQUNELHVCQUFDLFNBQUksS0FBS1gsRUFBRVcsWUFBWSxLQUFJLElBQUcsV0FBVSw4Q0FBekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbUYsSUFFbkYsdUJBQUMsVUFBSyxXQUFVLDZDQUE0QyxlQUFXLFFBQXZFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXVFO0FBQUEsVUFHekUsdUJBQUMsU0FBSSxXQUFVLGtCQUNiO0FBQUEsbUNBQUMsT0FBRSxXQUFVLDJCQUNYO0FBQUEscUNBQUMsVUFBSyxXQUFVLG1DQUFtQ1gsWUFBRVksbUJBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXFFO0FBQUEsY0FDcEVaLEVBQUVJLFNBQVMsS0FDVix1QkFBQyxVQUFLLFdBQVUscUZBQ2JKLFlBQUVJLFVBREw7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQUxKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBT0E7QUFBQSxZQUNBLHVCQUFDLE9BQUUsV0FBVSwrQkFDVko7QUFBQUEsZ0JBQUVhO0FBQUFBLGNBQ0ZiLEVBQUVjLGdCQUFnQixNQUFNZCxFQUFFYyxZQUFZO0FBQUEsaUJBRnpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxZQUNBLHVCQUFDLE9BQUUsV0FBV2pDLEdBQUcsMkJBQTJCbUIsRUFBRUksU0FBUyxJQUFJLHlCQUF5QixlQUFlLEdBQ2hHSixZQUFFZSxlQUFlLHFCQURwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFmRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWdCQTtBQUFBLFVBRUEsdUJBQUMsVUFBSyxXQUFVLDBDQUEwQ0Msb0JBQVVoQixFQUFFaUIsYUFBYSxLQUFuRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFxRjtBQUFBO0FBQUE7QUFBQSxNQS9CdkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBZ0NBLEtBakNPakIsRUFBRWQsSUFBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBa0NBO0FBQUEsRUFDRCxLQXJDSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBc0NBO0FBRUo7QUFFQWdDLE1BekVTYjtBQTJFVCxTQUFTYyxPQUFPO0FBQUEsRUFDZEM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFNRixHQUFHO0FBQUFDLE1BQUE7QUFDRCxRQUFNLEVBQUVDLFNBQVNDLFdBQVcsSUFBSWpELFFBQVE7QUFDeEMsUUFBTSxDQUFDa0QsVUFBVUMsV0FBVyxJQUFJN0QsU0FBMkIsSUFBSTtBQUMvRCxRQUFNLENBQUM4RCxPQUFPQyxRQUFRLElBQUkvRCxTQUFTLEVBQUU7QUFDckMsUUFBTSxDQUFDZ0UsU0FBU0MsVUFBVSxJQUFJakUsU0FBUyxLQUFLO0FBQzVDLFFBQU0sQ0FBQ3VCLE9BQU9DLFFBQVEsSUFBSXhCLFNBQXdCLElBQUk7QUFDdEQsUUFBTWtFLFNBQVNuRSxPQUF1QixJQUFJO0FBRTFDLFFBQU0wQixPQUFPNUIsWUFBWSxZQUFZO0FBQ25DLFFBQUk7QUFDRixZQUFNc0UsT0FBTyxNQUFNMUQsR0FBR21ELFNBQVNQLGNBQWM7QUFHN0MsWUFBTWUsT0FBTyxvQkFBSUMsSUFBWTtBQUM3QlIsa0JBQVlNLEtBQUtHLE9BQU8sQ0FBQ0MsTUFBT0gsS0FBS0ksSUFBSUQsRUFBRXBELEVBQUUsSUFBSSxRQUFRaUQsS0FBS0ssSUFBSUYsRUFBRXBELEVBQUUsQ0FBRSxDQUFDO0FBQ3pFLFlBQU1WLEdBQUdpRSxTQUFTckIsY0FBYztBQUFBLElBQ2xDLFNBQVMzQixHQUFHO0FBQ1ZGLGVBQVNFLGFBQWFDLFFBQVFELEVBQUVFLFVBQVUsbUNBQW1DO0FBQzdFaUMsa0JBQVksRUFBRTtBQUFBLElBQ2hCO0FBQUEsRUFDRixHQUFHLENBQUNSLGNBQWMsQ0FBQztBQUVuQnZELFlBQVUsTUFBTTtBQUNkK0QsZ0JBQVksSUFBSTtBQUNoQixTQUFLcEMsS0FBSztBQUNWLFFBQUk7QUFDRixhQUFPaEIsR0FBR29CLG9CQUFvQixNQUFNLEtBQUtKLEtBQUssQ0FBQztBQUFBLElBQ2pELFFBQVE7QUFDTixhQUFPSztBQUFBQSxJQUNUO0FBQUEsRUFDRixHQUFHLENBQUNMLElBQUksQ0FBQztBQUdUM0IsWUFBVSxNQUFNO0FBQ2RvRSxXQUFPUyxTQUFTQyxlQUFlLEVBQUVDLE9BQU8sTUFBTSxDQUFDO0FBQUEsRUFDakQsR0FBRyxDQUFDakIsVUFBVWpCLE1BQU0sQ0FBQztBQUVyQixRQUFNbUMsT0FBTyxZQUFZO0FBQ3ZCLFVBQU1DLE9BQU9qQixNQUFNa0IsS0FBSztBQUN4QixRQUFJLENBQUNELEtBQU07QUFFWGQsZUFBVyxJQUFJO0FBQ2Z6QyxhQUFTLElBQUk7QUFFYixRQUFJO0FBQ0YsWUFBTXlELE9BQU8sTUFBTXhFLEdBQUd5RSxZQUFZN0IsZ0JBQWdCMEIsSUFBSTtBQUN0RGhCLGVBQVMsRUFBRTtBQUdYRixrQkFBWSxDQUFDc0IsU0FBUztBQUNwQixjQUFNUixVQUFVUSxRQUFRO0FBQ3hCLGVBQU9SLFFBQVFTLEtBQUssQ0FBQ2IsTUFBTUEsRUFBRXBELE9BQU84RCxLQUFLOUQsRUFBRSxJQUFJd0QsVUFBVSxDQUFDLEdBQUdBLFNBQVNNLElBQUk7QUFBQSxNQUM1RSxDQUFDO0FBQ0R6QixhQUFPO0FBQUEsSUFDVCxTQUFTOUIsR0FBRztBQUNWRixlQUFTRSxhQUFhQyxRQUFRRCxFQUFFRSxVQUFVLDJCQUEyQjtBQUFBLElBQ3ZFLFVBQUM7QUFDQ3FDLGlCQUFXLEtBQUs7QUFBQSxJQUNsQjtBQUFBLEVBQ0Y7QUFFQSxTQUNFLHVCQUFDLFNBQUksV0FBVSxnR0FFYjtBQUFBLDJCQUFDLFNBQUksV0FBVSwwREFDYjtBQUFBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxNQUFLO0FBQUEsVUFDTCxTQUFTVjtBQUFBQSxVQUNULGNBQVc7QUFBQSxVQUNYLFdBQVU7QUFBQSxVQUVWLGlDQUFDLGFBQVUsTUFBTSxJQUFJLGVBQVcsUUFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0M7QUFBQTtBQUFBLFFBTmxDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQU9BO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsa0JBQ2I7QUFBQSwrQkFBQyxPQUFFLFdBQVUsbUNBQW1DRCx3QkFBY1QsbUJBQW1CLGtCQUFqRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWdHO0FBQUEsUUFDL0ZTLGdCQUNDLHVCQUFDLE9BQUUsV0FBVSwrQkFDVkE7QUFBQUEsdUJBQWErQixjQUFjLGlCQUFpQjtBQUFBLFVBQXFCO0FBQUEsVUFBRS9CLGFBQWFSO0FBQUFBLGFBRG5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBTEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU9BO0FBQUEsTUFFQ1EsY0FBY2dDLFdBQ2IsdUJBQUMsUUFBSyxJQUFJLFVBQVVoQyxhQUFhZ0MsT0FBTyxJQUN0QyxpQ0FBQyxVQUFPLE1BQUssTUFBSyxTQUFRLGFBQVcsMEJBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFJQTtBQUFBLFNBeEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0EwQkE7QUFBQSxJQUdBLHVCQUFDLFNBQUksV0FBVSx3Q0FDWjFCO0FBQUFBLG1CQUFhLE9BQ1osdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSwrQkFBQyxZQUFTLFdBQVUsZ0JBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ0M7QUFBQSxRQUNoQyx1QkFBQyxZQUFTLFdBQVUsd0JBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBd0M7QUFBQSxRQUN4Qyx1QkFBQyxZQUFTLFdBQVUsZ0JBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ0M7QUFBQSxXQUhsQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBSUEsSUFDRUEsU0FBU2pCLFdBQVcsSUFDdEIsdUJBQUMsT0FBRSxXQUFVLHdDQUFzQyx5RUFBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBLElBRUFpQixTQUFTbkIsSUFBSSxDQUFDOEIsR0FBRzdCLE1BQU07QUFDckIsY0FBTTZDLFVBQVU3QyxNQUFNLEtBQUs4QyxNQUFNakIsRUFBRWtCLE1BQU0sTUFBTUQsTUFBTTVCLFNBQVNsQixJQUFJLENBQUMsRUFBRStDLE1BQU07QUFDM0UsZUFDRSx1QkFBQyxTQUNFRjtBQUFBQSxxQkFDQyx1QkFBQyxPQUFFLFdBQVUscURBQXFERyxtQkFBU25CLEVBQUVrQixNQUFNLEtBQW5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXFGO0FBQUEsVUFFdkYsdUJBQUMsU0FBSSxXQUFXM0UsR0FBRyxRQUFReUQsRUFBRW9CLE9BQU8sZ0JBQWdCLGVBQWUsR0FDakU7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFdBQVc3RTtBQUFBQSxnQkFDVDtBQUFBLGdCQUNBeUQsRUFBRW9CLE9BQU8sc0JBQXNCO0FBQUEsY0FDakM7QUFBQSxjQUVBO0FBQUEsdUNBQUMsT0FBRSxXQUFVLDJEQUEyRHBCLFlBQUVRLFFBQTFFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQStFO0FBQUEsZ0JBQy9FO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVdqRTtBQUFBQSxzQkFDVDtBQUFBLHNCQUNBeUQsRUFBRW9CLE9BQU8sa0JBQWtCO0FBQUEsb0JBQzdCO0FBQUEsb0JBRUNDO0FBQUFBLDZCQUFPckIsRUFBRWtCLE1BQU07QUFBQSxzQkFDZmxCLEVBQUVvQixTQUNBcEIsRUFBRXNCLFNBQ0QsdUJBQUMsY0FBVyxNQUFNLElBQUksY0FBVyxVQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUF1QyxJQUV2Qyx1QkFBQyxTQUFNLE1BQU0sSUFBSSxjQUFXLFVBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWtDO0FBQUE7QUFBQTtBQUFBLGtCQVh4QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBYUE7QUFBQTtBQUFBO0FBQUEsWUFwQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBcUJBLEtBdEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBdUJBO0FBQUEsYUEzQlF0QixFQUFFcEQsSUFBWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBNEJBO0FBQUEsTUFFSixDQUFDO0FBQUEsTUFFSCx1QkFBQyxTQUFJLEtBQUsrQyxVQUFWO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBaUI7QUFBQSxTQS9DbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWdEQTtBQUFBLElBR0EsdUJBQUMsU0FBSSxXQUFVLGdDQUNaM0M7QUFBQUEsZUFBUyx1QkFBQyxPQUFFLFdBQVUsZ0NBQWdDQSxtQkFBN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFtRDtBQUFBLE1BRTdELHVCQUFDLFNBQUksV0FBVSx3QkFDYjtBQUFBLCtCQUFDLFdBQU0sV0FBVSxVQUNmO0FBQUEsaUNBQUMsVUFBSyxXQUFVLFdBQVUsNEJBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXNDO0FBQUEsVUFDdEM7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQU07QUFBQSxjQUNOLE9BQU91QztBQUFBQSxjQUNQLFVBQVUsQ0FBQ3BDLE1BQU1xQyxTQUFTckMsRUFBRW9FLE9BQU9DLEtBQUs7QUFBQSxjQUN4QyxXQUFXLENBQUNyRSxNQUFNO0FBRWhCLG9CQUFJQSxFQUFFc0UsUUFBUSxXQUFXLENBQUN0RSxFQUFFdUUsVUFBVTtBQUNwQ3ZFLG9CQUFFd0UsZUFBZTtBQUNqQix1QkFBS3BCLEtBQUs7QUFBQSxnQkFDWjtBQUFBLGNBQ0Y7QUFBQSxjQUNBLGFBQWFuQixjQUFjLENBQUNELFVBQVUscUJBQXFCO0FBQUEsY0FDM0QsVUFBVUMsY0FBYyxDQUFDRDtBQUFBQSxjQUN6QixXQUFVO0FBQUE7QUFBQSxZQWJaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQWF1TTtBQUFBLGFBZnpNO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFpQkE7QUFBQSxRQUVBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxTQUFTLE1BQU0sS0FBS29CLEtBQUs7QUFBQSxZQUN6QixVQUFVZCxXQUFXRixNQUFNa0IsS0FBSyxFQUFFckMsV0FBVztBQUFBLFlBQzdDLGNBQVc7QUFBQSxZQUNYLFdBQVU7QUFBQSxZQUVWLGlDQUFDLFFBQUssTUFBTSxJQUFJLGVBQVcsUUFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMkI7QUFBQTtBQUFBLFVBTjdCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU9BO0FBQUEsV0EzQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTRCQTtBQUFBLFNBL0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FnQ0E7QUFBQSxPQWxIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBbUhBO0FBRUo7QUFFQWMsSUEvTFNMLFFBQU07QUFBQSxVQVdtQjFDLE9BQU87QUFBQTtBQUFBLE1BWGhDMEM7QUFpTVQsTUFBTW9DLFFBQVFBLENBQUNXLFFBQWdCLElBQUlDLEtBQUtELEdBQUcsRUFBRUUsYUFBYTtBQUUxRCxTQUFTWCxTQUFTUyxLQUFxQjtBQUNyQyxRQUFNRyxJQUFJLElBQUlGLEtBQUtELEdBQUc7QUFDdEIsUUFBTUksUUFBUSxvQkFBSUgsS0FBSztBQUN2QixRQUFNSSxZQUFZLElBQUlKLEtBQUtBLEtBQUtLLElBQUksSUFBSSxLQUFVO0FBRWxELE1BQUlILEVBQUVELGFBQWEsTUFBTUUsTUFBTUYsYUFBYSxFQUFHLFFBQU87QUFDdEQsTUFBSUMsRUFBRUQsYUFBYSxNQUFNRyxVQUFVSCxhQUFhLEVBQUcsUUFBTztBQUMxRCxTQUFPQyxFQUFFSSxtQkFBbUIsU0FBUyxFQUFFQyxLQUFLLFdBQVdDLE9BQU8sT0FBTyxDQUFDO0FBQ3hFO0FBRUEsTUFBTWhCLFNBQVNBLENBQUNPLFFBQ2QsSUFBSUMsS0FBS0QsR0FBRyxFQUFFVSxtQkFBbUIsU0FBUyxFQUFFQyxNQUFNLFdBQVdDLFFBQVEsVUFBVSxDQUFDO0FBRWxGLFNBQVM5RCxVQUFVa0QsS0FBcUI7QUFDdEMsUUFBTWEsT0FBT0MsS0FBS0MsT0FBT2QsS0FBS0ssSUFBSSxJQUFJLElBQUlMLEtBQUtELEdBQUcsRUFBRWdCLFFBQVEsS0FBSyxHQUFLO0FBQ3RFLE1BQUlILE9BQU8sRUFBRyxRQUFPO0FBQ3JCLE1BQUlBLE9BQU8sR0FBSSxRQUFPLEdBQUdBLElBQUk7QUFDN0IsTUFBSUEsT0FBTyxLQUFNLFFBQU8sR0FBR0MsS0FBS0MsTUFBTUYsT0FBTyxFQUFFLENBQUM7QUFDaEQsTUFBSUEsT0FBTyxNQUFPLFFBQU8sR0FBR0MsS0FBS0MsTUFBTUYsT0FBTyxJQUFJLENBQUM7QUFDbkQsU0FBTyxJQUFJWixLQUFLRCxHQUFHLEVBQUVPLG1CQUFtQixTQUFTLEVBQUVDLEtBQUssV0FBV0MsT0FBTyxRQUFRLENBQUM7QUFDckY7QUFBQyxJQUFBUSxJQUFBakUsS0FBQWtFO0FBQUEsYUFBQUQsSUFBQTtBQUFBLGFBQUFqRSxLQUFBO0FBQUEsYUFBQWtFLEtBQUEiLCJuYW1lcyI6WyJ1c2VDYWxsYmFjayIsInVzZUVmZmVjdCIsInVzZVJlZiIsInVzZVN0YXRlIiwiTGluayIsInVzZU5hdmlnYXRlIiwidXNlUGFyYW1zIiwiQXJyb3dMZWZ0IiwiU2VuZCIsIk1lc3NhZ2VzU3F1YXJlIiwiQ2hlY2siLCJDaGVja0NoZWNrIiwiZGIiLCJ1c2VBdXRoIiwiUGFnZUhlYWRlciIsIkJ1dHRvbiIsIlNrZWxldG9uIiwiY24iLCJ1c2VJMThuIiwiTWVzc2FnZXMiLCJfcyIsInQiLCJpZCIsIm5hdmlnYXRlIiwiY29udmVyc2F0aW9ucyIsInNldENvbnZlcnNhdGlvbnMiLCJlcnJvciIsInNldEVycm9yIiwibG9hZCIsImUiLCJFcnJvciIsIm1lc3NhZ2UiLCJzdWJzY3JpYmVUb01lc3NhZ2VzIiwidW5kZWZpbmVkIiwiYWN0aXZlIiwiZmluZCIsImMiLCJ0b3RhbFVucmVhZCIsInJlZHVjZSIsInN1bSIsInVucmVhZCIsIkNvbnZlcnNhdGlvbkxpc3QiLCJpdGVtcyIsImFjdGl2ZUlkIiwibWFwIiwiaSIsImxlbmd0aCIsInNwYWNlSW1hZ2UiLCJjb3VudGVycGFydE5hbWUiLCJzcGFjZU5hbWUiLCJwcm9wZXJ0eUFyZWEiLCJsYXN0TWVzc2FnZSIsIndoZW5TaG9ydCIsImxhc3RNZXNzYWdlQXQiLCJfYzIiLCJUaHJlYWQiLCJjb252ZXJzYXRpb25JZCIsImNvbnZlcnNhdGlvbiIsIm9uQmFjayIsIm9uU2VudCIsIl9zMiIsImFjY291bnQiLCJjb25maWd1cmVkIiwibWVzc2FnZXMiLCJzZXRNZXNzYWdlcyIsImRyYWZ0Iiwic2V0RHJhZnQiLCJzZW5kaW5nIiwic2V0U2VuZGluZyIsImVuZFJlZiIsInJvd3MiLCJzZWVuIiwiU2V0IiwiZmlsdGVyIiwibSIsImhhcyIsImFkZCIsIm1hcmtSZWFkIiwiY3VycmVudCIsInNjcm9sbEludG9WaWV3IiwiYmxvY2siLCJzZW5kIiwiYm9keSIsInRyaW0iLCJzZW50Iiwic2VuZE1lc3NhZ2UiLCJwcmV2Iiwic29tZSIsInlvdUFyZU93bmVyIiwic3BhY2VJZCIsInNob3dEYXkiLCJkYXlPZiIsInNlbnRBdCIsImRheUxhYmVsIiwibWluZSIsInRpbWVPZiIsInJlYWRBdCIsInRhcmdldCIsInZhbHVlIiwia2V5Iiwic2hpZnRLZXkiLCJwcmV2ZW50RGVmYXVsdCIsImlzbyIsIkRhdGUiLCJ0b0RhdGVTdHJpbmciLCJkIiwidG9kYXkiLCJ5ZXN0ZXJkYXkiLCJub3ciLCJ0b0xvY2FsZURhdGVTdHJpbmciLCJkYXkiLCJtb250aCIsInRvTG9jYWxlVGltZVN0cmluZyIsImhvdXIiLCJtaW51dGUiLCJtaW5zIiwiTWF0aCIsImZsb29yIiwiZ2V0VGltZSIsIl9jIiwiX2MzIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIk1lc3NhZ2VzLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VDYWxsYmFjaywgdXNlRWZmZWN0LCB1c2VSZWYsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBMaW5rLCB1c2VOYXZpZ2F0ZSwgdXNlUGFyYW1zIH0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIjtcbmltcG9ydCB7IEFycm93TGVmdCwgU2VuZCwgTWVzc2FnZXNTcXVhcmUsIENoZWNrLCBDaGVja0NoZWNrIH0gZnJvbSBcImx1Y2lkZS1yZWFjdFwiO1xuaW1wb3J0IHsgZGIgfSBmcm9tIFwiQC9saWIvYXBpXCI7XG5pbXBvcnQgeyB1c2VBdXRoIH0gZnJvbSBcIkAvaG9va3MvdXNlQXV0aFwiO1xuaW1wb3J0IHsgUGFnZUhlYWRlciB9IGZyb20gXCJAL2NvbXBvbmVudHMvbGF5b3V0L1BhZ2VIZWFkZXJcIjtcbmltcG9ydCB7IEJ1dHRvbiB9IGZyb20gXCJAL2NvbXBvbmVudHMvdWkvQnV0dG9uXCI7XG5pbXBvcnQgeyBTa2VsZXRvbiB9IGZyb20gXCJAL2NvbXBvbmVudHMvdWkvU2tlbGV0b25cIjtcbmltcG9ydCB0eXBlIHsgQ29udmVyc2F0aW9uLCBNZXNzYWdlIH0gZnJvbSBcIkAvdHlwZXMvc3BhY2VcIjtcbmltcG9ydCB7IGNuIH0gZnJvbSBcIkAvbGliL2NuXCI7XG5pbXBvcnQgeyB1c2VJMThuIH0gZnJvbSBcIkAvaTE4blwiO1xuXG4vKipcbiAqIE1lc3NhZ2VzLiBPbmUgbGlzdCwgb25lIHRocmVhZCwgYW5kIG9uIGRlc2t0b3AgYm90aCBhdCBvbmNlLlxuICpcbiAqIFRocmVhZHMgYXJlIHRpZWQgdG8gYSBzcGFjZSwgc28gbmVpdGhlciBzaWRlIGhhcyB0byBhc2sgXCJ3aGljaCBwbGFjZSBpc1xuICogdGhpcyBhYm91dFwiIOKAlCB0aGUgdGhpbmcgYmVpbmcgZGlzY3Vzc2VkIHNpdHMgYXQgdGhlIHRvcCBvZiB0aGUgc2NyZWVuLlxuICovXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBNZXNzYWdlcygpIHtcbiAgY29uc3QgeyB0IH0gPSB1c2VJMThuKCk7XG4gIGNvbnN0IHsgaWQgfSA9IHVzZVBhcmFtcygpO1xuICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XG5cbiAgY29uc3QgW2NvbnZlcnNhdGlvbnMsIHNldENvbnZlcnNhdGlvbnNdID0gdXNlU3RhdGU8Q29udmVyc2F0aW9uW10gfCBudWxsPihudWxsKTtcbiAgY29uc3QgW2Vycm9yLCBzZXRFcnJvcl0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcblxuICBjb25zdCBsb2FkID0gdXNlQ2FsbGJhY2soYXN5bmMgKCkgPT4ge1xuICAgIHRyeSB7XG4gICAgICBzZXRDb252ZXJzYXRpb25zKGF3YWl0IGRiLmNvbnZlcnNhdGlvbnMoKSk7XG4gICAgICBzZXRFcnJvcihudWxsKTtcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICBzZXRFcnJvcihlIGluc3RhbmNlb2YgRXJyb3IgPyBlLm1lc3NhZ2UgOiBcIkNvdWxkIG5vdCBsb2FkIHlvdXIgbWVzc2FnZXMuXCIpO1xuICAgICAgc2V0Q29udmVyc2F0aW9ucyhbXSk7XG4gICAgfVxuICB9LCBbXSk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICB2b2lkIGxvYWQoKTtcbiAgICB0cnkge1xuICAgICAgcmV0dXJuIGRiLnN1YnNjcmliZVRvTWVzc2FnZXMoKCkgPT4gdm9pZCBsb2FkKCkpO1xuICAgIH0gY2F0Y2gge1xuICAgICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgICB9XG4gIH0sIFtsb2FkXSk7XG5cbiAgY29uc3QgYWN0aXZlID0gY29udmVyc2F0aW9ucz8uZmluZCgoYykgPT4gYy5pZCA9PT0gaWQpID8/IG51bGw7XG4gIGNvbnN0IHRvdGFsVW5yZWFkID0gKGNvbnZlcnNhdGlvbnMgPz8gW10pLnJlZHVjZSgoc3VtLCBjKSA9PiBzdW0gKyBjLnVucmVhZCwgMCk7XG5cbiAgcmV0dXJuIChcbiAgICA8PlxuICAgICAgPFBhZ2VIZWFkZXJcbiAgICAgICAgdGl0bGU9e3QoXCJtZXNzYWdlcy50aXRsZVwiKX1cbiAgICAgICAgbGVhZD17XG4gICAgICAgICAgdG90YWxVbnJlYWQgPiAwXG4gICAgICAgICAgICA/IGAke3RvdGFsVW5yZWFkfSB1bnJlYWQgJHt0b3RhbFVucmVhZCA9PT0gMSA/IFwibWVzc2FnZVwiIDogXCJtZXNzYWdlc1wifS5gXG4gICAgICAgICAgICA6IFwiRXZlcnkgY29udmVyc2F0aW9uIGlzIHRpZWQgdG8gdGhlIHNwYWNlIGl0J3MgYWJvdXQuXCJcbiAgICAgICAgfVxuICAgICAgLz5cblxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb250YWluZXItcGFnZSBweS02IG1kOnB5LThcIj5cbiAgICAgICAge2Vycm9yICYmIChcbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtYi00IHJvdW5kZWQtY2FyZCBiZy1kYW5nZXItMTAwIHAtNCB0ZXh0LXNtIHRleHQtZGFuZ2VyLTYwMFwiPntlcnJvcn08L3A+XG4gICAgICAgICl9XG5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdhcC02IGxnOmdyaWQtY29scy1bMjByZW1fMWZyXVwiPlxuICAgICAgICAgIHsvKiBMaXN0IOKAlCBoaWRkZW4gb24gbW9iaWxlIG9uY2UgYSB0aHJlYWQgaXMgb3BlbiAqL31cbiAgICAgICAgICA8YXNpZGUgY2xhc3NOYW1lPXtjbihpZCAmJiBcImhpZGRlbiBsZzpibG9ja1wiKX0+XG4gICAgICAgICAgICA8Q29udmVyc2F0aW9uTGlzdCBpdGVtcz17Y29udmVyc2F0aW9uc30gYWN0aXZlSWQ9e2lkID8/IG51bGx9IC8+XG4gICAgICAgICAgPC9hc2lkZT5cblxuICAgICAgICAgIHsvKiBUaHJlYWQgKi99XG4gICAgICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPXtjbighaWQgJiYgXCJoaWRkZW4gbGc6YmxvY2tcIil9PlxuICAgICAgICAgICAge2lkID8gKFxuICAgICAgICAgICAgICA8VGhyZWFkXG4gICAgICAgICAgICAgICAgY29udmVyc2F0aW9uSWQ9e2lkfVxuICAgICAgICAgICAgICAgIGNvbnZlcnNhdGlvbj17YWN0aXZlfVxuICAgICAgICAgICAgICAgIG9uQmFjaz17KCkgPT4gbmF2aWdhdGUoXCIvbWVzc2FnZXNcIil9XG4gICAgICAgICAgICAgICAgb25TZW50PXsoKSA9PiB2b2lkIGxvYWQoKX1cbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBoLWZ1bGwgbWluLWgtNzIgZmxleC1jb2wgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHJvdW5kZWQtY2FyZCBiZy1zdXJmYWNlIHAtMTAgdGV4dC1jZW50ZXIgcmluZy0xIHJpbmctaGFpcmxpbmVcIj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtYi0zIGZsZXggc2l6ZS0xMSBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC1mdWxsIGJnLWFxdWEtMTAwIHRleHQtYXF1YS03MDBcIj5cbiAgICAgICAgICAgICAgICAgIDxNZXNzYWdlc1NxdWFyZSBzaXplPXsyMH0gYXJpYS1oaWRkZW4gLz5cbiAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiZm9udC1kaXNwbGF5IGZvbnQtYm9sZCB0ZXh0LWlua1wiPlBpY2sgYSBjb252ZXJzYXRpb248L3A+XG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMSBtYXgtdy14cyB0ZXh0LXNtIHRleHQtbXV0ZWRcIj5cbiAgICAgICAgICAgICAgICAgIE9yIG9wZW4gYSBzcGFjZSBhbmQgc2VuZCBhbiBpbnF1aXJ5IHRvIHN0YXJ0IGEgbmV3IG9uZS5cbiAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICA8L3NlY3Rpb24+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgPC8+XG4gICk7XG59XG5cbi8qIOKUgOKUgCBDb252ZXJzYXRpb24gbGlzdCDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIAgKi9cblxuZnVuY3Rpb24gQ29udmVyc2F0aW9uTGlzdCh7IGl0ZW1zLCBhY3RpdmVJZCB9OiB7IGl0ZW1zOiBDb252ZXJzYXRpb25bXSB8IG51bGw7IGFjdGl2ZUlkOiBzdHJpbmcgfCBudWxsIH0pIHtcbiAgaWYgKGl0ZW1zID09PSBudWxsKSB7XG4gICAgcmV0dXJuIChcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XG4gICAgICAgIHtbMCwgMSwgMl0ubWFwKChpKSA9PiAoXG4gICAgICAgICAgPFNrZWxldG9uIGtleT17aX0gY2xhc3NOYW1lPVwiaC0yMCB3LWZ1bGwgcm91bmRlZC1jYXJkXCIgLz5cbiAgICAgICAgKSl9XG4gICAgICA8L2Rpdj5cbiAgICApO1xuICB9XG5cbiAgaWYgKGl0ZW1zLmxlbmd0aCA9PT0gMCkge1xuICAgIHJldHVybiAoXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdW5kZWQtY2FyZCBiZy1zdXJmYWNlIHAtOCB0ZXh0LWNlbnRlciByaW5nLTEgcmluZy1oYWlybGluZVwiPlxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJteC1hdXRvIG1iLTMgZmxleCBzaXplLTExIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciByb3VuZGVkLWZ1bGwgYmctYXF1YS0xMDAgdGV4dC1hcXVhLTcwMFwiPlxuICAgICAgICAgIDxNZXNzYWdlc1NxdWFyZSBzaXplPXsyMH0gYXJpYS1oaWRkZW4gLz5cbiAgICAgICAgPC9zcGFuPlxuICAgICAgICA8cCBjbGFzc05hbWU9XCJmb250LWRpc3BsYXkgZm9udC1ib2xkIHRleHQtaW5rXCI+Tm8gY29udmVyc2F0aW9ucyB5ZXQuPC9wPlxuICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0xLjUgdGV4dC1zbSBsZWFkaW5nLXJlbGF4ZWQgdGV4dC1tdXRlZFwiPlxuICAgICAgICAgIFNlbmQgYW4gaW5xdWlyeSBvbiBhIHNwYWNlIGFuZCB0aGUgdGhyZWFkIGFwcGVhcnMgaGVyZS5cbiAgICAgICAgPC9wPlxuICAgICAgICA8TGluayB0bz1cIi9zZWFyY2hcIiBjbGFzc05hbWU9XCJtdC00IGlubGluZS1ibG9ja1wiPlxuICAgICAgICAgIDxCdXR0b24gc2l6ZT1cInNtXCIgdmFyaWFudD1cInNlY29uZGFyeVwiPlxuICAgICAgICAgICAgQnJvd3NlIHNwYWNlc1xuICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICA8L0xpbms+XG4gICAgICA8L2Rpdj5cbiAgICApO1xuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8dWwgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XG4gICAgICB7aXRlbXMubWFwKChjKSA9PiAoXG4gICAgICAgIDxsaSBrZXk9e2MuaWR9PlxuICAgICAgICAgIDxMaW5rXG4gICAgICAgICAgICB0bz17YC9tZXNzYWdlcy8ke2MuaWR9YH1cbiAgICAgICAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgICAgICAgIFwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgcm91bmRlZC1jYXJkIHAtMyByaW5nLTEgdHJhbnNpdGlvbi1jb2xvcnNcIixcbiAgICAgICAgICAgICAgYy5pZCA9PT0gYWN0aXZlSWQgPyBcImJnLWFxdWEtNTAgcmluZy1hcXVhLTYwMFwiIDogXCJiZy1zdXJmYWNlIHJpbmctaGFpcmxpbmUgaG92ZXI6cmluZy1oYWlybGluZS1zdHJvbmdcIixcbiAgICAgICAgICAgICl9XG4gICAgICAgICAgPlxuICAgICAgICAgICAge2Muc3BhY2VJbWFnZSA/IChcbiAgICAgICAgICAgICAgPGltZyBzcmM9e2Muc3BhY2VJbWFnZX0gYWx0PVwiXCIgY2xhc3NOYW1lPVwic2l6ZS0xMiBzaHJpbmstMCByb3VuZGVkLXhsIG9iamVjdC1jb3ZlclwiIC8+XG4gICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJzaXplLTEyIHNocmluay0wIHJvdW5kZWQteGwgYmctaXZvcnktZGVlcFwiIGFyaWEtaGlkZGVuIC8+XG4gICAgICAgICAgICApfVxuXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi13LTAgZmxleC0xXCI+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidHJ1bmNhdGUgZm9udC1zZW1pYm9sZCB0ZXh0LWlua1wiPntjLmNvdW50ZXJwYXJ0TmFtZX08L3NwYW4+XG4gICAgICAgICAgICAgICAge2MudW5yZWFkID4gMCAmJiAoXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJzaHJpbmstMCByb3VuZGVkLWZ1bGwgYmctYXF1YS02MDAgcHgtMS41IHRleHQtWzAuNjVyZW1dIGZvbnQtYm9sZCB0bnVtIHRleHQtd2hpdGVcIj5cbiAgICAgICAgICAgICAgICAgICAge2MudW5yZWFkfVxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidHJ1bmNhdGUgdGV4dC14cyB0ZXh0LW11dGVkXCI+XG4gICAgICAgICAgICAgICAge2Muc3BhY2VOYW1lfVxuICAgICAgICAgICAgICAgIHtjLnByb3BlcnR5QXJlYSAmJiBgIMK3ICR7Yy5wcm9wZXJ0eUFyZWF9YH1cbiAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9e2NuKFwibXQtMC41IHRydW5jYXRlIHRleHQtc21cIiwgYy51bnJlYWQgPiAwID8gXCJmb250LW1lZGl1bSB0ZXh0LWlua1wiIDogXCJ0ZXh0LWluay1zb2Z0XCIpfT5cbiAgICAgICAgICAgICAgICB7Yy5sYXN0TWVzc2FnZSB8fCBcIk5vIG1lc3NhZ2VzIHlldFwifVxuICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwic2hyaW5rLTAgc2VsZi1zdGFydCB0ZXh0LXhzIHRleHQtbXV0ZWRcIj57d2hlblNob3J0KGMubGFzdE1lc3NhZ2VBdCl9PC9zcGFuPlxuICAgICAgICAgIDwvTGluaz5cbiAgICAgICAgPC9saT5cbiAgICAgICkpfVxuICAgIDwvdWw+XG4gICk7XG59XG5cbi8qIOKUgOKUgCBUaHJlYWQg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAICovXG5cbmZ1bmN0aW9uIFRocmVhZCh7XG4gIGNvbnZlcnNhdGlvbklkLFxuICBjb252ZXJzYXRpb24sXG4gIG9uQmFjayxcbiAgb25TZW50LFxufToge1xuICBjb252ZXJzYXRpb25JZDogc3RyaW5nO1xuICBjb252ZXJzYXRpb246IENvbnZlcnNhdGlvbiB8IG51bGw7XG4gIG9uQmFjazogKCkgPT4gdm9pZDtcbiAgb25TZW50OiAoKSA9PiB2b2lkO1xufSkge1xuICBjb25zdCB7IGFjY291bnQsIGNvbmZpZ3VyZWQgfSA9IHVzZUF1dGgoKTtcbiAgY29uc3QgW21lc3NhZ2VzLCBzZXRNZXNzYWdlc10gPSB1c2VTdGF0ZTxNZXNzYWdlW10gfCBudWxsPihudWxsKTtcbiAgY29uc3QgW2RyYWZ0LCBzZXREcmFmdF0gPSB1c2VTdGF0ZShcIlwiKTtcbiAgY29uc3QgW3NlbmRpbmcsIHNldFNlbmRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbZXJyb3IsIHNldEVycm9yXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xuICBjb25zdCBlbmRSZWYgPSB1c2VSZWY8SFRNTERpdkVsZW1lbnQ+KG51bGwpO1xuXG4gIGNvbnN0IGxvYWQgPSB1c2VDYWxsYmFjayhhc3luYyAoKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHJvd3MgPSBhd2FpdCBkYi5tZXNzYWdlcyhjb252ZXJzYXRpb25JZCk7XG4gICAgICAvLyBUaGUgc2VydmVyJ3MgY29weSBpcyBhdXRob3JpdGF0aXZlOyBkZS1kdXBsaWNhdGUgZGVmZW5zaXZlbHkgaW4gY2FzZSBhXG4gICAgICAvLyBiYWNrZW5kIGV2ZXIgcmV0dXJucyB0aGUgc2FtZSByb3cgdHdpY2UuXG4gICAgICBjb25zdCBzZWVuID0gbmV3IFNldDxzdHJpbmc+KCk7XG4gICAgICBzZXRNZXNzYWdlcyhyb3dzLmZpbHRlcigobSkgPT4gKHNlZW4uaGFzKG0uaWQpID8gZmFsc2UgOiBzZWVuLmFkZChtLmlkKSkpKTtcbiAgICAgIGF3YWl0IGRiLm1hcmtSZWFkKGNvbnZlcnNhdGlvbklkKTtcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICBzZXRFcnJvcihlIGluc3RhbmNlb2YgRXJyb3IgPyBlLm1lc3NhZ2UgOiBcIkNvdWxkIG5vdCBsb2FkIHRoaXMgY29udmVyc2F0aW9uLlwiKTtcbiAgICAgIHNldE1lc3NhZ2VzKFtdKTtcbiAgICB9XG4gIH0sIFtjb252ZXJzYXRpb25JZF0pO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgc2V0TWVzc2FnZXMobnVsbCk7XG4gICAgdm9pZCBsb2FkKCk7XG4gICAgdHJ5IHtcbiAgICAgIHJldHVybiBkYi5zdWJzY3JpYmVUb01lc3NhZ2VzKCgpID0+IHZvaWQgbG9hZCgpKTtcbiAgICB9IGNhdGNoIHtcbiAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgfVxuICB9LCBbbG9hZF0pO1xuXG4gIC8vIEp1bXAgdG8gdGhlIG5ld2VzdCBtZXNzYWdlIHdoZW5ldmVyIHRoZSB0aHJlYWQgZ3Jvd3MuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgZW5kUmVmLmN1cnJlbnQ/LnNjcm9sbEludG9WaWV3KHsgYmxvY2s6IFwiZW5kXCIgfSk7XG4gIH0sIFttZXNzYWdlcz8ubGVuZ3RoXSk7XG5cbiAgY29uc3Qgc2VuZCA9IGFzeW5jICgpID0+IHtcbiAgICBjb25zdCBib2R5ID0gZHJhZnQudHJpbSgpO1xuICAgIGlmICghYm9keSkgcmV0dXJuO1xuXG4gICAgc2V0U2VuZGluZyh0cnVlKTtcbiAgICBzZXRFcnJvcihudWxsKTtcblxuICAgIHRyeSB7XG4gICAgICBjb25zdCBzZW50ID0gYXdhaXQgZGIuc2VuZE1lc3NhZ2UoY29udmVyc2F0aW9uSWQsIGJvZHkpO1xuICAgICAgc2V0RHJhZnQoXCJcIik7XG4gICAgICAvLyBTaG93IGl0IGltbWVkaWF0ZWx5IHJhdGhlciB0aGFuIHdhaXRpbmcgZm9yIHRoZSByb3VuZCB0cmlwIOKAlCBidXQgdGhlXG4gICAgICAvLyBzdWJzY3JpcHRpb24gbWF5IGhhdmUgYWxyZWFkeSBkZWxpdmVyZWQgaXQsIHNvIG1hdGNoIG9uIGlkIGZpcnN0LlxuICAgICAgc2V0TWVzc2FnZXMoKHByZXYpID0+IHtcbiAgICAgICAgY29uc3QgY3VycmVudCA9IHByZXYgPz8gW107XG4gICAgICAgIHJldHVybiBjdXJyZW50LnNvbWUoKG0pID0+IG0uaWQgPT09IHNlbnQuaWQpID8gY3VycmVudCA6IFsuLi5jdXJyZW50LCBzZW50XTtcbiAgICAgIH0pO1xuICAgICAgb25TZW50KCk7XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgc2V0RXJyb3IoZSBpbnN0YW5jZW9mIEVycm9yID8gZS5tZXNzYWdlIDogXCJZb3VyIG1lc3NhZ2UgZGlkbid0IHNlbmQuXCIpO1xuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRTZW5kaW5nKGZhbHNlKTtcbiAgICB9XG4gIH07XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaC1bNzB2aF0gbWluLWgtOTYgZmxleC1jb2wgb3ZlcmZsb3ctaGlkZGVuIHJvdW5kZWQtY2FyZCBiZy1zdXJmYWNlIHJpbmctMSByaW5nLWhhaXJsaW5lXCI+XG4gICAgICB7LyogV2hvIGFuZCB3aGF0IHRoaXMgaXMgYWJvdXQgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zIGJvcmRlci1iIGJvcmRlci1oYWlybGluZSBwLTMuNVwiPlxuICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgb25DbGljaz17b25CYWNrfVxuICAgICAgICAgIGFyaWEtbGFiZWw9XCJCYWNrIHRvIGNvbnZlcnNhdGlvbnNcIlxuICAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQtZnVsbCBwLTEuNSB0ZXh0LW11dGVkIGhvdmVyOmJnLWl2b3J5LWRlZXAgaG92ZXI6dGV4dC1pbmsgbGc6aGlkZGVuXCJcbiAgICAgICAgPlxuICAgICAgICAgIDxBcnJvd0xlZnQgc2l6ZT17MTh9IGFyaWEtaGlkZGVuIC8+XG4gICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLXctMCBmbGV4LTFcIj5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0cnVuY2F0ZSBmb250LXNlbWlib2xkIHRleHQtaW5rXCI+e2NvbnZlcnNhdGlvbj8uY291bnRlcnBhcnROYW1lID8/IFwiQ29udmVyc2F0aW9uXCJ9PC9wPlxuICAgICAgICAgIHtjb252ZXJzYXRpb24gJiYgKFxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidHJ1bmNhdGUgdGV4dC14cyB0ZXh0LW11dGVkXCI+XG4gICAgICAgICAgICAgIHtjb252ZXJzYXRpb24ueW91QXJlT3duZXIgPyBcIkFza2luZyBhYm91dFwiIDogXCJZb3VyIGlucXVpcnkgYWJvdXRcIn0ge2NvbnZlcnNhdGlvbi5zcGFjZU5hbWV9XG4gICAgICAgICAgICA8L3A+XG4gICAgICAgICAgKX1cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAge2NvbnZlcnNhdGlvbj8uc3BhY2VJZCAmJiAoXG4gICAgICAgICAgPExpbmsgdG89e2Avc3BhY2UvJHtjb252ZXJzYXRpb24uc3BhY2VJZH1gfT5cbiAgICAgICAgICAgIDxCdXR0b24gc2l6ZT1cInNtXCIgdmFyaWFudD1cInNlY29uZGFyeVwiPlxuICAgICAgICAgICAgICBWaWV3IHNwYWNlXG4gICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICA8L0xpbms+XG4gICAgICAgICl9XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIE1lc3NhZ2VzICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgc3BhY2UteS0zIG92ZXJmbG93LXktYXV0byBwLTRcIj5cbiAgICAgICAge21lc3NhZ2VzID09PSBudWxsID8gKFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0zXCI+XG4gICAgICAgICAgICA8U2tlbGV0b24gY2xhc3NOYW1lPVwiaC0xMiB3LTIvM1wiIC8+XG4gICAgICAgICAgICA8U2tlbGV0b24gY2xhc3NOYW1lPVwibWwtYXV0byBoLTEyIHctMS8yXCIgLz5cbiAgICAgICAgICAgIDxTa2VsZXRvbiBjbGFzc05hbWU9XCJoLTEyIHctMy81XCIgLz5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKSA6IG1lc3NhZ2VzLmxlbmd0aCA9PT0gMCA/IChcbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJweS0xMCB0ZXh0LWNlbnRlciB0ZXh0LXNtIHRleHQtbXV0ZWRcIj5cbiAgICAgICAgICAgIE5vIG1lc3NhZ2VzIHlldC4gU2F5IGhlbGxvIGFuZCBhc2sgd2hhdCB5b3UgbmVlZCB0byBrbm93LlxuICAgICAgICAgIDwvcD5cbiAgICAgICAgKSA6IChcbiAgICAgICAgICBtZXNzYWdlcy5tYXAoKG0sIGkpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IHNob3dEYXkgPSBpID09PSAwIHx8IGRheU9mKG0uc2VudEF0KSAhPT0gZGF5T2YobWVzc2FnZXNbaSAtIDFdLnNlbnRBdCk7XG4gICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICA8ZGl2IGtleT17bS5pZH0+XG4gICAgICAgICAgICAgICAge3Nob3dEYXkgJiYgKFxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXktNCB0ZXh0LWNlbnRlciB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1tdXRlZFwiPntkYXlMYWJlbChtLnNlbnRBdCl9PC9wPlxuICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2NuKFwiZmxleFwiLCBtLm1pbmUgPyBcImp1c3RpZnktZW5kXCIgOiBcImp1c3RpZnktc3RhcnRcIil9PlxuICAgICAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgICAgICAgICAgICAgICAgIFwibWF4LXctWzg1JV0gcm91bmRlZC0yeGwgcHgtMy41IHB5LTIuNSBzbTptYXgtdy1bNzAlXVwiLFxuICAgICAgICAgICAgICAgICAgICAgIG0ubWluZSA/IFwiYmctaW5rIHRleHQtaXZvcnlcIiA6IFwiYmctaXZvcnktZGVlcCB0ZXh0LWlua1wiLFxuICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ3aGl0ZXNwYWNlLXByZS13cmFwIGJyZWFrLXdvcmRzIHRleHQtc20gbGVhZGluZy1yZWxheGVkXCI+e20uYm9keX08L3A+XG4gICAgICAgICAgICAgICAgICAgIDxwXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgICAgICAgICAgICAgICAgIFwibXQtMSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWVuZCBnYXAtMSB0ZXh0LVswLjdyZW1dXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICBtLm1pbmUgPyBcInRleHQtaXZvcnkvNjBcIiA6IFwidGV4dC1tdXRlZFwiLFxuICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICB7dGltZU9mKG0uc2VudEF0KX1cbiAgICAgICAgICAgICAgICAgICAgICB7bS5taW5lICYmXG4gICAgICAgICAgICAgICAgICAgICAgICAobS5yZWFkQXQgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxDaGVja0NoZWNrIHNpemU9ezEyfSBhcmlhLWxhYmVsPVwiUmVhZFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgICAgICA8Q2hlY2sgc2l6ZT17MTJ9IGFyaWEtbGFiZWw9XCJTZW50XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApO1xuICAgICAgICAgIH0pXG4gICAgICAgICl9XG4gICAgICAgIDxkaXYgcmVmPXtlbmRSZWZ9IC8+XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIENvbXBvc2VyICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJib3JkZXItdCBib3JkZXItaGFpcmxpbmUgcC0zXCI+XG4gICAgICAgIHtlcnJvciAmJiA8cCBjbGFzc05hbWU9XCJtYi0yIHRleHQtc20gdGV4dC1kYW5nZXItNjAwXCI+e2Vycm9yfTwvcD59XG5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWVuZCBnYXAtMlwiPlxuICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJmbGV4LTFcIj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInNyLW9ubHlcIj5Zb3VyIG1lc3NhZ2U8L3NwYW4+XG4gICAgICAgICAgICA8dGV4dGFyZWFcbiAgICAgICAgICAgICAgcm93cz17MX1cbiAgICAgICAgICAgICAgdmFsdWU9e2RyYWZ0fVxuICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldERyYWZ0KGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgb25LZXlEb3duPXsoZSkgPT4ge1xuICAgICAgICAgICAgICAgIC8vIEVudGVyIHNlbmRzOyBTaGlmdCtFbnRlciBtYWtlcyBhIG5ldyBsaW5lLlxuICAgICAgICAgICAgICAgIGlmIChlLmtleSA9PT0gXCJFbnRlclwiICYmICFlLnNoaWZ0S2V5KSB7XG4gICAgICAgICAgICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgICAgICAgICAgICB2b2lkIHNlbmQoKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgIHBsYWNlaG9sZGVyPXtjb25maWd1cmVkICYmICFhY2NvdW50ID8gXCJTaWduIGluIHRvIHJlcGx5XCIgOiBcIldyaXRlIGEgbWVzc2FnZVwifVxuICAgICAgICAgICAgICBkaXNhYmxlZD17Y29uZmlndXJlZCAmJiAhYWNjb3VudH1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWF4LWgtMzIgdy1mdWxsIHJlc2l6ZS15IHJvdW5kZWQtMnhsIGJnLWl2b3J5IHB4LTMuNSBweS0yLjUgdGV4dC1bMC45Mzc1cmVtXSB0ZXh0LWluayByaW5nLTEgcmluZy1oYWlybGluZS1zdHJvbmcgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWFxdWEtNjAwIGRpc2FibGVkOm9wYWNpdHktNjBcIlxuICAgICAgICAgICAgLz5cbiAgICAgICAgICA8L2xhYmVsPlxuXG4gICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gdm9pZCBzZW5kKCl9XG4gICAgICAgICAgICBkaXNhYmxlZD17c2VuZGluZyB8fCBkcmFmdC50cmltKCkubGVuZ3RoID09PSAwfVxuICAgICAgICAgICAgYXJpYS1sYWJlbD1cIlNlbmQgbWVzc2FnZVwiXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJzaHJpbmstMFwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgPFNlbmQgc2l6ZT17MTZ9IGFyaWEtaGlkZGVuIC8+XG4gICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICk7XG59XG5cbi8qIOKUgOKUgCBUaW1lIGhlbHBlcnMg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAICovXG5cbmNvbnN0IGRheU9mID0gKGlzbzogc3RyaW5nKSA9PiBuZXcgRGF0ZShpc28pLnRvRGF0ZVN0cmluZygpO1xuXG5mdW5jdGlvbiBkYXlMYWJlbChpc286IHN0cmluZyk6IHN0cmluZyB7XG4gIGNvbnN0IGQgPSBuZXcgRGF0ZShpc28pO1xuICBjb25zdCB0b2RheSA9IG5ldyBEYXRlKCk7XG4gIGNvbnN0IHllc3RlcmRheSA9IG5ldyBEYXRlKERhdGUubm93KCkgLSA4Nl80MDBfMDAwKTtcblxuICBpZiAoZC50b0RhdGVTdHJpbmcoKSA9PT0gdG9kYXkudG9EYXRlU3RyaW5nKCkpIHJldHVybiBcIlRvZGF5XCI7XG4gIGlmIChkLnRvRGF0ZVN0cmluZygpID09PSB5ZXN0ZXJkYXkudG9EYXRlU3RyaW5nKCkpIHJldHVybiBcIlllc3RlcmRheVwiO1xuICByZXR1cm4gZC50b0xvY2FsZURhdGVTdHJpbmcoXCJlbi1HQlwiLCB7IGRheTogXCJudW1lcmljXCIsIG1vbnRoOiBcImxvbmdcIiB9KTtcbn1cblxuY29uc3QgdGltZU9mID0gKGlzbzogc3RyaW5nKSA9PlxuICBuZXcgRGF0ZShpc28pLnRvTG9jYWxlVGltZVN0cmluZyhcImVuLUdCXCIsIHsgaG91cjogXCIyLWRpZ2l0XCIsIG1pbnV0ZTogXCIyLWRpZ2l0XCIgfSk7XG5cbmZ1bmN0aW9uIHdoZW5TaG9ydChpc286IHN0cmluZyk6IHN0cmluZyB7XG4gIGNvbnN0IG1pbnMgPSBNYXRoLmZsb29yKChEYXRlLm5vdygpIC0gbmV3IERhdGUoaXNvKS5nZXRUaW1lKCkpIC8gNjAwMDApO1xuICBpZiAobWlucyA8IDEpIHJldHVybiBcIm5vd1wiO1xuICBpZiAobWlucyA8IDYwKSByZXR1cm4gYCR7bWluc31tYDtcbiAgaWYgKG1pbnMgPCAxNDQwKSByZXR1cm4gYCR7TWF0aC5mbG9vcihtaW5zIC8gNjApfWhgO1xuICBpZiAobWlucyA8IDEwMDgwKSByZXR1cm4gYCR7TWF0aC5mbG9vcihtaW5zIC8gMTQ0MCl9ZGA7XG4gIHJldHVybiBuZXcgRGF0ZShpc28pLnRvTG9jYWxlRGF0ZVN0cmluZyhcImVuLUdCXCIsIHsgZGF5OiBcIm51bWVyaWNcIiwgbW9udGg6IFwic2hvcnRcIiB9KTtcbn1cbiJdLCJmaWxlIjoiRDovSTJJIFByb2plY3QgLSBIYWJpdG8vQXBwIEZvbGRlci9oYWJpdG8vc3JjL3BhZ2VzL01lc3NhZ2VzLnRzeCJ9