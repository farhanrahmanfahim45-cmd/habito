import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/Toast.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=9ceb86a3"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("D:/I2I Project - Habito/App Folder/habito/src/components/ui/Toast.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9ceb86a3"; const createContext = __vite__cjsImport3_react["createContext"]; const useCallback = __vite__cjsImport3_react["useCallback"]; const useContext = __vite__cjsImport3_react["useContext"]; const useMemo = __vite__cjsImport3_react["useMemo"]; const useState = __vite__cjsImport3_react["useState"];
import { Check, Info } from "/node_modules/.vite/deps/lucide-react.js?v=9ceb86a3";
const ToastContext = createContext({
  notify: () => {
  }
});
export function useToast() {
  _s();
  return useContext(ToastContext);
}
_s(useToast, "gDsCjeeItUuvgOWf1v4qoK9RF6k=");
export function ToastProvider({ children }) {
  _s2();
  const [items, setItems] = useState([]);
  const notify = useCallback((message, tone = "ok") => {
    const id = Date.now() + Math.random();
    setItems((prev) => [...prev, { id, message, tone }]);
    window.setTimeout(() => {
      setItems((prev) => prev.filter((t) => t.id !== id));
    }, 3200);
  }, []);
  const value = useMemo(() => ({ notify }), [notify]);
  return /* @__PURE__ */ jsxDEV(ToastContext.Provider, { value, children: [
    children,
    /* @__PURE__ */ jsxDEV(
      "div",
      {
        "aria-live": "polite",
        "aria-atomic": "false",
        className: "pointer-events-none fixed inset-x-0 bottom-20 z-60 flex flex-col items-center gap-2 px-4 md:bottom-6",
        children: items.map(
          (t) => /* @__PURE__ */ jsxDEV(
            "div",
            {
              className: "pointer-events-auto flex items-center gap-2 rounded-md bg-ink px-3.5 py-2.5 text-sm font-medium text-ivory shadow-lg",
              children: [
                t.tone === "ok" ? /* @__PURE__ */ jsxDEV(Check, { size: 15, "aria-hidden": true }, void 0, false, {
                  fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/ui/Toast.tsx",
                  lineNumber: 64,
                  columnNumber: 32
                }, this) : /* @__PURE__ */ jsxDEV(Info, { size: 15, "aria-hidden": true }, void 0, false, {
                  fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/ui/Toast.tsx",
                  lineNumber: 64,
                  columnNumber: 66
                }, this),
                t.message
              ]
            },
            t.id,
            true,
            {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/ui/Toast.tsx",
              lineNumber: 60,
              columnNumber: 9
            },
            this
          )
        )
      },
      void 0,
      false,
      {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/ui/Toast.tsx",
        lineNumber: 54,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/ui/Toast.tsx",
    lineNumber: 52,
    columnNumber: 5
  }, this);
}
_s2(ToastProvider, "LHCinEnh+zUy83SROEW8rajvD8M=");
_c = ToastProvider;
var _c;
$RefreshReg$(_c, "ToastProvider");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/I2I Project - Habito/App Folder/habito/src/components/ui/Toast.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/I2I Project - Habito/App Folder/habito/src/components/ui/Toast.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNEMrQjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUE1Qy9CLFNBQVNBLGVBQWVDLGFBQWFDLFlBQVlDLFNBQVNDLGdCQUFnQjtBQUUxRSxTQUFTQyxPQUFPQyxZQUFZO0FBUTVCLE1BQU1DLGVBQWVQLGNBQTJFO0FBQUEsRUFDOUZRLFFBQVFBLE1BQU07QUFBQSxFQUFDO0FBQ2pCLENBQUM7QUFFTSxnQkFBU0MsV0FBVztBQUFBQyxLQUFBO0FBQ3pCLFNBQU9SLFdBQVdLLFlBQVk7QUFDaEM7QUFBQ0csR0FGZUQsVUFBUTtBQUlqQixnQkFBU0UsY0FBYyxFQUFFQyxTQUFrQyxHQUFHO0FBQUFDLE1BQUE7QUFDbkUsUUFBTSxDQUFDQyxPQUFPQyxRQUFRLElBQUlYLFNBQXNCLEVBQUU7QUFFbEQsUUFBTUksU0FBU1AsWUFBWSxDQUFDZSxTQUFpQkMsT0FBc0IsU0FBUztBQUMxRSxVQUFNQyxLQUFLQyxLQUFLQyxJQUFJLElBQUlDLEtBQUtDLE9BQU87QUFDcENQLGFBQVMsQ0FBQ1EsU0FBUyxDQUFDLEdBQUdBLE1BQU0sRUFBRUwsSUFBSUYsU0FBU0MsS0FBSyxDQUFDLENBQUM7QUFDbkRPLFdBQU9DLFdBQVcsTUFBTTtBQUN0QlYsZUFBUyxDQUFDUSxTQUFTQSxLQUFLRyxPQUFPLENBQUNDLE1BQU1BLEVBQUVULE9BQU9BLEVBQUUsQ0FBQztBQUFBLElBQ3BELEdBQUcsSUFBSTtBQUFBLEVBQ1QsR0FBRyxFQUFFO0FBRUwsUUFBTVUsUUFBUXpCLFFBQVEsT0FBTyxFQUFFSyxPQUFPLElBQUksQ0FBQ0EsTUFBTSxDQUFDO0FBRWxELFNBQ0UsdUJBQUMsYUFBYSxVQUFiLEVBQXNCLE9BQ3BCSTtBQUFBQTtBQUFBQSxJQUNEO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxhQUFVO0FBQUEsUUFDVixlQUFZO0FBQUEsUUFDWixXQUFVO0FBQUEsUUFFVEUsZ0JBQU1lO0FBQUFBLFVBQUksQ0FBQ0YsTUFDVjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBRUMsV0FBVTtBQUFBLGNBRVRBO0FBQUFBLGtCQUFFVixTQUFTLE9BQU8sdUJBQUMsU0FBTSxNQUFNLElBQUksZUFBVyxRQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUE0QixJQUFNLHVCQUFDLFFBQUssTUFBTSxJQUFJLGVBQVcsUUFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBMkI7QUFBQSxnQkFDL0VVLEVBQUVYO0FBQUFBO0FBQUFBO0FBQUFBLFlBSkVXLEVBQUVUO0FBQUFBLFlBRFQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU1BO0FBQUEsUUFDRDtBQUFBO0FBQUEsTUFiSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFjQTtBQUFBLE9BaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FpQkE7QUFFSjtBQUFDTCxJQWpDZUYsZUFBYTtBQUFBLEtBQWJBO0FBQWEsSUFBQW1CO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbImNyZWF0ZUNvbnRleHQiLCJ1c2VDYWxsYmFjayIsInVzZUNvbnRleHQiLCJ1c2VNZW1vIiwidXNlU3RhdGUiLCJDaGVjayIsIkluZm8iLCJUb2FzdENvbnRleHQiLCJub3RpZnkiLCJ1c2VUb2FzdCIsIl9zIiwiVG9hc3RQcm92aWRlciIsImNoaWxkcmVuIiwiX3MyIiwiaXRlbXMiLCJzZXRJdGVtcyIsIm1lc3NhZ2UiLCJ0b25lIiwiaWQiLCJEYXRlIiwibm93IiwiTWF0aCIsInJhbmRvbSIsInByZXYiLCJ3aW5kb3ciLCJzZXRUaW1lb3V0IiwiZmlsdGVyIiwidCIsInZhbHVlIiwibWFwIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiVG9hc3QudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGNyZWF0ZUNvbnRleHQsIHVzZUNhbGxiYWNrLCB1c2VDb250ZXh0LCB1c2VNZW1vLCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHR5cGUgeyBSZWFjdE5vZGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IENoZWNrLCBJbmZvIH0gZnJvbSBcImx1Y2lkZS1yZWFjdFwiO1xuXG5pbnRlcmZhY2UgVG9hc3RJdGVtIHtcbiAgaWQ6IG51bWJlcjtcbiAgbWVzc2FnZTogc3RyaW5nO1xuICB0b25lOiBcIm9rXCIgfCBcImluZm9cIjtcbn1cblxuY29uc3QgVG9hc3RDb250ZXh0ID0gY3JlYXRlQ29udGV4dDx7IG5vdGlmeTogKG1lc3NhZ2U6IHN0cmluZywgdG9uZT86IFwib2tcIiB8IFwiaW5mb1wiKSA9PiB2b2lkIH0+KHtcbiAgbm90aWZ5OiAoKSA9PiB7fSxcbn0pO1xuXG5leHBvcnQgZnVuY3Rpb24gdXNlVG9hc3QoKSB7XG4gIHJldHVybiB1c2VDb250ZXh0KFRvYXN0Q29udGV4dCk7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBUb2FzdFByb3ZpZGVyKHsgY2hpbGRyZW4gfTogeyBjaGlsZHJlbjogUmVhY3ROb2RlIH0pIHtcbiAgY29uc3QgW2l0ZW1zLCBzZXRJdGVtc10gPSB1c2VTdGF0ZTxUb2FzdEl0ZW1bXT4oW10pO1xuXG4gIGNvbnN0IG5vdGlmeSA9IHVzZUNhbGxiYWNrKChtZXNzYWdlOiBzdHJpbmcsIHRvbmU6IFwib2tcIiB8IFwiaW5mb1wiID0gXCJva1wiKSA9PiB7XG4gICAgY29uc3QgaWQgPSBEYXRlLm5vdygpICsgTWF0aC5yYW5kb20oKTtcbiAgICBzZXRJdGVtcygocHJldikgPT4gWy4uLnByZXYsIHsgaWQsIG1lc3NhZ2UsIHRvbmUgfV0pO1xuICAgIHdpbmRvdy5zZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgIHNldEl0ZW1zKChwcmV2KSA9PiBwcmV2LmZpbHRlcigodCkgPT4gdC5pZCAhPT0gaWQpKTtcbiAgICB9LCAzMjAwKTtcbiAgfSwgW10pO1xuXG4gIGNvbnN0IHZhbHVlID0gdXNlTWVtbygoKSA9PiAoeyBub3RpZnkgfSksIFtub3RpZnldKTtcblxuICByZXR1cm4gKFxuICAgIDxUb2FzdENvbnRleHQuUHJvdmlkZXIgdmFsdWU9e3ZhbHVlfT5cbiAgICAgIHtjaGlsZHJlbn1cbiAgICAgIDxkaXZcbiAgICAgICAgYXJpYS1saXZlPVwicG9saXRlXCJcbiAgICAgICAgYXJpYS1hdG9taWM9XCJmYWxzZVwiXG4gICAgICAgIGNsYXNzTmFtZT1cInBvaW50ZXItZXZlbnRzLW5vbmUgZml4ZWQgaW5zZXQteC0wIGJvdHRvbS0yMCB6LTYwIGZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGdhcC0yIHB4LTQgbWQ6Ym90dG9tLTZcIlxuICAgICAgPlxuICAgICAgICB7aXRlbXMubWFwKCh0KSA9PiAoXG4gICAgICAgICAgPGRpdlxuICAgICAgICAgICAga2V5PXt0LmlkfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwicG9pbnRlci1ldmVudHMtYXV0byBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiByb3VuZGVkLW1kIGJnLWluayBweC0zLjUgcHktMi41IHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1pdm9yeSBzaGFkb3ctbGdcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIHt0LnRvbmUgPT09IFwib2tcIiA/IDxDaGVjayBzaXplPXsxNX0gYXJpYS1oaWRkZW4gLz4gOiA8SW5mbyBzaXplPXsxNX0gYXJpYS1oaWRkZW4gLz59XG4gICAgICAgICAgICB7dC5tZXNzYWdlfVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICApKX1cbiAgICAgIDwvZGl2PlxuICAgIDwvVG9hc3RDb250ZXh0LlByb3ZpZGVyPlxuICApO1xufVxuIl0sImZpbGUiOiJEOi9JMkkgUHJvamVjdCAtIEhhYml0by9BcHAgRm9sZGVyL2hhYml0by9zcmMvY29tcG9uZW50cy91aS9Ub2FzdC50c3gifQ==