import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/space/SpacePhoto.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=9ceb86a3"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("D:/I2I Project - Habito/App Folder/habito/src/components/space/SpacePhoto.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9ceb86a3"; const useState = __vite__cjsImport3_react["useState"];
import { FALLBACK_ART, PHOTO_MODE } from "/src/data/photos.ts";
import { useI18n } from "/src/i18n/index.tsx";
import { cn } from "/src/lib/cn.ts";
export function SpacePhoto({
  src,
  alt,
  category,
  demo,
  className,
  imgClassName,
  priority,
  bandPosition = "bottom"
}) {
  _s();
  const { t } = useI18n();
  const [loaded, setLoaded] = useState(false);
  const [failed, setFailed] = useState(false);
  const source = failed ? FALLBACK_ART[category] : src;
  return /* @__PURE__ */ jsxDEV("div", { className: cn("relative overflow-hidden bg-ivory-deep", className), children: [
    /* @__PURE__ */ jsxDEV(
      "div",
      {
        "aria-hidden": true,
        className: cn(
          "absolute inset-0 bg-gradient-to-br from-ivory-deep to-hairline transition-opacity duration-500",
          loaded ? "opacity-0" : "opacity-100 shimmer"
        )
      },
      void 0,
      false,
      {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/SpacePhoto.tsx",
        lineNumber: 64,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      "img",
      {
        src: source,
        alt,
        loading: priority ? "eager" : "lazy",
        decoding: "async",
        onLoad: () => setLoaded(true),
        onError: () => {
          setFailed(true);
          setLoaded(true);
        },
        className: cn(
          "relative size-full object-cover transition-[opacity,transform] duration-700 ease-out",
          loaded ? "opacity-100" : "opacity-0",
          imgClassName
        )
      },
      void 0,
      false,
      {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/SpacePhoto.tsx",
        lineNumber: 72,
        columnNumber: 7
      },
      this
    ),
    demo && PHOTO_MODE === "photo" && !failed && /* @__PURE__ */ jsxDEV(
      "span",
      {
        className: cn(
          "pointer-events-none absolute inset-x-0 z-20 bg-ink/65 px-2 py-0.5 text-center text-[0.55rem] font-semibold uppercase tracking-[0.08em] text-ivory/90 backdrop-blur-[2px]",
          bandPosition === "top" ? "top-0" : "bottom-0"
        ),
        children: t("photo.illustrative")
      },
      void 0,
      false,
      {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/SpacePhoto.tsx",
        lineNumber: 92,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/SpacePhoto.tsx",
    lineNumber: 62,
    columnNumber: 5
  }, this);
}
_s(SpacePhoto, "etqNQYFy+x1mTIgQHMDqkWhobUY=", false, function() {
  return [useI18n];
});
_c = SpacePhoto;
var _c;
$RefreshReg$(_c, "SpacePhoto");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/I2I Project - Habito/App Folder/habito/src/components/space/SpacePhoto.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/I2I Project - Habito/App Folder/habito/src/components/space/SpacePhoto.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNENNOzs7Ozs7Ozs7Ozs7Ozs7OztBQTVDTixTQUFTQSxnQkFBZ0I7QUFDekIsU0FBU0MsY0FBY0Msa0JBQWtCO0FBQ3pDLFNBQVNDLGVBQWU7QUFFeEIsU0FBU0MsVUFBVTtBQVVaLGdCQUFTQyxXQUFXO0FBQUEsRUFDekJDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDLGVBQWU7QUFZakIsR0FBRztBQUFBQyxLQUFBO0FBQ0QsUUFBTSxFQUFFQyxFQUFFLElBQUlaLFFBQVE7QUFDdEIsUUFBTSxDQUFDYSxRQUFRQyxTQUFTLElBQUlqQixTQUFTLEtBQUs7QUFDMUMsUUFBTSxDQUFDa0IsUUFBUUMsU0FBUyxJQUFJbkIsU0FBUyxLQUFLO0FBRTFDLFFBQU1vQixTQUFTRixTQUFTakIsYUFBYU8sUUFBUSxJQUFJRjtBQUVqRCxTQUNFLHVCQUFDLFNBQUksV0FBV0YsR0FBRywwQ0FBMENNLFNBQVMsR0FFcEU7QUFBQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0M7QUFBQSxRQUNBLFdBQVdOO0FBQUFBLFVBQ1Q7QUFBQSxVQUNBWSxTQUFTLGNBQWM7QUFBQSxRQUN6QjtBQUFBO0FBQUEsTUFMRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFLSTtBQUFBLElBR0o7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLEtBQUtJO0FBQUFBLFFBQ0w7QUFBQSxRQUNBLFNBQVNSLFdBQVcsVUFBVTtBQUFBLFFBQzlCLFVBQVM7QUFBQSxRQUNULFFBQVEsTUFBTUssVUFBVSxJQUFJO0FBQUEsUUFDNUIsU0FBUyxNQUFNO0FBQ2JFLG9CQUFVLElBQUk7QUFDZEYsb0JBQVUsSUFBSTtBQUFBLFFBQ2hCO0FBQUEsUUFDQSxXQUFXYjtBQUFBQSxVQUNUO0FBQUEsVUFDQVksU0FBUyxnQkFBZ0I7QUFBQSxVQUN6Qkw7QUFBQUEsUUFDRjtBQUFBO0FBQUEsTUFkRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFjSTtBQUFBLElBS0hGLFFBQVFQLGVBQWUsV0FBVyxDQUFDZ0IsVUFDbEM7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLFdBQVdkO0FBQUFBLFVBQ1Q7QUFBQSxVQUNBUyxpQkFBaUIsUUFBUSxVQUFVO0FBQUEsUUFDckM7QUFBQSxRQUVDRSxZQUFFLG9CQUFvQjtBQUFBO0FBQUEsTUFOekI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBT0E7QUFBQSxPQXJDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBdUNBO0FBRUo7QUFBQ0QsR0FyRWVULFlBQVU7QUFBQSxVQXFCVkYsT0FBTztBQUFBO0FBQUEsS0FyQlBFO0FBQVUsSUFBQWdCO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwiRkFMTEJBQ0tfQVJUIiwiUEhPVE9fTU9ERSIsInVzZUkxOG4iLCJjbiIsIlNwYWNlUGhvdG8iLCJzcmMiLCJhbHQiLCJjYXRlZ29yeSIsImRlbW8iLCJjbGFzc05hbWUiLCJpbWdDbGFzc05hbWUiLCJwcmlvcml0eSIsImJhbmRQb3NpdGlvbiIsIl9zIiwidCIsImxvYWRlZCIsInNldExvYWRlZCIsImZhaWxlZCIsInNldEZhaWxlZCIsInNvdXJjZSIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlNwYWNlUGhvdG8udHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBGQUxMQkFDS19BUlQsIFBIT1RPX01PREUgfSBmcm9tIFwiQC9kYXRhL3Bob3Rvc1wiO1xuaW1wb3J0IHsgdXNlSTE4biB9IGZyb20gXCJAL2kxOG5cIjtcbmltcG9ydCB0eXBlIHsgU3BhY2VDYXRlZ29yeSB9IGZyb20gXCJAL3R5cGVzL3NwYWNlXCI7XG5pbXBvcnQgeyBjbiB9IGZyb20gXCJAL2xpYi9jblwiO1xuXG4vKipcbiAqIEEgbGlzdGluZyBwaG90b2dyYXBoLlxuICpcbiAqIFRocmVlIHRoaW5ncyBpdCBoYW5kbGVzIHRoYXQgYSBiYXJlIDxpbWc+IGRvZXMgbm90OiBhIGRlbW8gYmFuZCB0aGF0IGNhbm5vdFxuICogYmUgc2Nyb2xsZWQgYXdheSBmcm9tLCBhIGdyYWNlZnVsIGZhbGwgYmFjayB0byBpbGx1c3RyYXRpb24gd2hlbiBhIHJlbW90ZVxuICogcGhvdG8gZmFpbHMsIGFuZCBhIHRpbnRlZCBwbGFjZWhvbGRlciB3aGlsZSBpdCBsb2FkcyBzbyBhIHNsb3cgY29ubmVjdGlvblxuICogZG9lc24ndCBzaG93IGEgcGFnZSBvZiB3aGl0ZSByZWN0YW5nbGVzLlxuICovXG5leHBvcnQgZnVuY3Rpb24gU3BhY2VQaG90byh7XG4gIHNyYyxcbiAgYWx0LFxuICBjYXRlZ29yeSxcbiAgZGVtbyxcbiAgY2xhc3NOYW1lLFxuICBpbWdDbGFzc05hbWUsXG4gIHByaW9yaXR5LFxuICBiYW5kUG9zaXRpb24gPSBcImJvdHRvbVwiLFxufToge1xuICBzcmM6IHN0cmluZztcbiAgYWx0OiBzdHJpbmc7XG4gIGNhdGVnb3J5OiBTcGFjZUNhdGVnb3J5O1xuICAvKiogU2VlZCBsaXN0aW5ncyBhcmUgaW52ZW50ZWQsIGFuZCB0aGVpciBwaG90b2dyYXBocyBzYXkgc28uICovXG4gIGRlbW8/OiBib29sZWFuO1xuICBjbGFzc05hbWU/OiBzdHJpbmc7XG4gIGltZ0NsYXNzTmFtZT86IHN0cmluZztcbiAgLyoqIFRoZSBmaXJzdCBpbWFnZSBvbiBhIHBhZ2Ugc2hvdWxkbid0IHdhaXQgZm9yIHRoZSBsYXp5IGxvYWRlci4gKi9cbiAgcHJpb3JpdHk/OiBib29sZWFuO1xuICBiYW5kUG9zaXRpb24/OiBcInRvcFwiIHwgXCJib3R0b21cIjtcbn0pIHtcbiAgY29uc3QgeyB0IH0gPSB1c2VJMThuKCk7XG4gIGNvbnN0IFtsb2FkZWQsIHNldExvYWRlZF0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtmYWlsZWQsIHNldEZhaWxlZF0gPSB1c2VTdGF0ZShmYWxzZSk7XG5cbiAgY29uc3Qgc291cmNlID0gZmFpbGVkID8gRkFMTEJBQ0tfQVJUW2NhdGVnb3J5XSA6IHNyYztcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPXtjbihcInJlbGF0aXZlIG92ZXJmbG93LWhpZGRlbiBiZy1pdm9yeS1kZWVwXCIsIGNsYXNzTmFtZSl9PlxuICAgICAgey8qIEhvbGRzIHRoZSBzcGFjZSBhbmQgZ2l2ZXMgdGhlIGV5ZSBzb21ldGhpbmcgd2hpbGUgdGhlIHBob3RvIGFycml2ZXMuICovfVxuICAgICAgPGRpdlxuICAgICAgICBhcmlhLWhpZGRlblxuICAgICAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgICAgIFwiYWJzb2x1dGUgaW5zZXQtMCBiZy1ncmFkaWVudC10by1iciBmcm9tLWl2b3J5LWRlZXAgdG8taGFpcmxpbmUgdHJhbnNpdGlvbi1vcGFjaXR5IGR1cmF0aW9uLTUwMFwiLFxuICAgICAgICAgIGxvYWRlZCA/IFwib3BhY2l0eS0wXCIgOiBcIm9wYWNpdHktMTAwIHNoaW1tZXJcIixcbiAgICAgICAgKX1cbiAgICAgIC8+XG5cbiAgICAgIDxpbWdcbiAgICAgICAgc3JjPXtzb3VyY2V9XG4gICAgICAgIGFsdD17YWx0fVxuICAgICAgICBsb2FkaW5nPXtwcmlvcml0eSA/IFwiZWFnZXJcIiA6IFwibGF6eVwifVxuICAgICAgICBkZWNvZGluZz1cImFzeW5jXCJcbiAgICAgICAgb25Mb2FkPXsoKSA9PiBzZXRMb2FkZWQodHJ1ZSl9XG4gICAgICAgIG9uRXJyb3I9eygpID0+IHtcbiAgICAgICAgICBzZXRGYWlsZWQodHJ1ZSk7XG4gICAgICAgICAgc2V0TG9hZGVkKHRydWUpO1xuICAgICAgICB9fVxuICAgICAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgICAgIFwicmVsYXRpdmUgc2l6ZS1mdWxsIG9iamVjdC1jb3ZlciB0cmFuc2l0aW9uLVtvcGFjaXR5LHRyYW5zZm9ybV0gZHVyYXRpb24tNzAwIGVhc2Utb3V0XCIsXG4gICAgICAgICAgbG9hZGVkID8gXCJvcGFjaXR5LTEwMFwiIDogXCJvcGFjaXR5LTBcIixcbiAgICAgICAgICBpbWdDbGFzc05hbWUsXG4gICAgICAgICl9XG4gICAgICAvPlxuXG4gICAgICB7LyogT25seSBvdmVyIGEgcGhvdG9ncmFwaC4gQW4gaWxsdXN0cmF0aW9uIGFscmVhZHkgcmVhZHMgYXMgb25lLCBhbmQgdGhlXG4gICAgICAgICAgY2FyZCBjYXJyaWVzIGEgREVNTyBjaGlwLCBzbyBhIGJhbmQgaGVyZSBqdXN0IGNvdmVycyB0aGUgYWRkcmVzcy4gKi99XG4gICAgICB7ZGVtbyAmJiBQSE9UT19NT0RFID09PSBcInBob3RvXCIgJiYgIWZhaWxlZCAmJiAoXG4gICAgICAgIDxzcGFuXG4gICAgICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgICAgIFwicG9pbnRlci1ldmVudHMtbm9uZSBhYnNvbHV0ZSBpbnNldC14LTAgei0yMCBiZy1pbmsvNjUgcHgtMiBweS0wLjUgdGV4dC1jZW50ZXIgdGV4dC1bMC41NXJlbV0gZm9udC1zZW1pYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctWzAuMDhlbV0gdGV4dC1pdm9yeS85MCBiYWNrZHJvcC1ibHVyLVsycHhdXCIsXG4gICAgICAgICAgICBiYW5kUG9zaXRpb24gPT09IFwidG9wXCIgPyBcInRvcC0wXCIgOiBcImJvdHRvbS0wXCIsXG4gICAgICAgICAgKX1cbiAgICAgICAgPlxuICAgICAgICAgIHt0KFwicGhvdG8uaWxsdXN0cmF0aXZlXCIpfVxuICAgICAgICA8L3NwYW4+XG4gICAgICApfVxuICAgIDwvZGl2PlxuICApO1xufVxuIl0sImZpbGUiOiJEOi9JMkkgUHJvamVjdCAtIEhhYml0by9BcHAgRm9sZGVyL2hhYml0by9zcmMvY29tcG9uZW50cy9zcGFjZS9TcGFjZVBob3RvLnRzeCJ9