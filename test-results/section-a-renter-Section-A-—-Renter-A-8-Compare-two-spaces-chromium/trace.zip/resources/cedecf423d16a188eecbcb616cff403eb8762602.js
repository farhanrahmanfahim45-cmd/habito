import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/@fs/D:\\I2I Project - Habito\\App Folder\\habito\\src\\components\\space\\MatchRing.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=9ceb86a3"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("D:/I2I Project - Habito/App Folder/habito/src/components/space/MatchRing.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9ceb86a3"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useRef = __vite__cjsImport3_react["useRef"]; const useState = __vite__cjsImport3_react["useState"];
import { cn } from "/src/lib/cn.ts";
import { matchLabel } from "/src/lib/matching.ts";
export function MatchRing({
  score,
  size = 88,
  showLabel = true,
  className
}) {
  _s();
  const ref = useRef(null);
  const [shown, setShown] = useState(0);
  useEffect(() => {
    const node = ref.current;
    if (!node) return;
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduce) {
      setShown(score);
      return;
    }
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (!entry.isIntersecting) return;
        observer.disconnect();
        const start = performance.now();
        const duration = 700;
        const tick = (now) => {
          const t = Math.min(1, (now - start) / duration);
          const eased = 1 - Math.pow(1 - t, 3);
          setShown(Math.round(score * eased));
          if (t < 1) requestAnimationFrame(tick);
        };
        requestAnimationFrame(tick);
      },
      { threshold: 0.4 }
    );
    observer.observe(node);
    return () => observer.disconnect();
  }, [score]);
  const stroke = size >= 70 ? 7 : 5;
  const radius = (size - stroke) / 2;
  const circumference = 2 * Math.PI * radius;
  return /* @__PURE__ */ jsxDEV("div", { ref, className: cn("inline-flex items-center gap-3", className), children: [
    /* @__PURE__ */ jsxDEV("div", { className: "relative shrink-0", style: { width: size, height: size }, children: [
      /* @__PURE__ */ jsxDEV("svg", { width: size, height: size, viewBox: `0 0 ${size} ${size}`, "aria-hidden": true, children: [
        /* @__PURE__ */ jsxDEV("circle", { cx: size / 2, cy: size / 2, r: radius, fill: "none", stroke: "currentColor", strokeWidth: stroke, className: "text-ink/10" }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/MatchRing.tsx",
          lineNumber: 81,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          "circle",
          {
            cx: size / 2,
            cy: size / 2,
            r: radius,
            fill: "none",
            stroke: "currentColor",
            strokeWidth: stroke,
            strokeLinecap: "round",
            className: "text-aqua-600 transition-[stroke-dashoffset] duration-150",
            strokeDasharray: circumference,
            strokeDashoffset: circumference * (1 - shown / 100),
            transform: `rotate(-90 ${size / 2} ${size / 2})`
          },
          void 0,
          false,
          {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/MatchRing.tsx",
            lineNumber: 82,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/MatchRing.tsx",
        lineNumber: 80,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        "span",
        {
          className: "absolute inset-0 flex items-center justify-center font-display font-bold text-ink tnum",
          style: { fontSize: size * 0.28 },
          children: [
            shown,
            /* @__PURE__ */ jsxDEV("span", { style: { fontSize: size * 0.16 }, className: "ml-0.5 text-muted", children: "%" }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/MatchRing.tsx",
              lineNumber: 101,
              columnNumber: 11
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/MatchRing.tsx",
          lineNumber: 96,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/MatchRing.tsx",
      lineNumber: 79,
      columnNumber: 7
    }, this),
    showLabel && /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("p", { className: "font-display font-bold leading-tight text-ink", children: matchLabel(score) }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/MatchRing.tsx",
        lineNumber: 106,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-muted", children: "Habito Match" }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/MatchRing.tsx",
        lineNumber: 107,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/MatchRing.tsx",
      lineNumber: 105,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("span", { className: "sr-only", children: [
      score,
      "% match — ",
      matchLabel(score)
    ] }, void 0, true, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/MatchRing.tsx",
      lineNumber: 110,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/MatchRing.tsx",
    lineNumber: 78,
    columnNumber: 5
  }, this);
}
_s(MatchRing, "LbTgjUheulRxAI/J+XVvnLb2EtM=");
_c = MatchRing;
export function MatchPill({ score }) {
  return /* @__PURE__ */ jsxDEV("span", { className: "inline-flex items-center gap-1 rounded-full bg-ink/85 px-2.5 py-1 text-xs font-bold text-ivory backdrop-blur-sm tnum", children: [
    /* @__PURE__ */ jsxDEV("span", { className: "size-1.5 rounded-full bg-aqua-400", "aria-hidden": true }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/MatchRing.tsx",
      lineNumber: 119,
      columnNumber: 7
    }, this),
    score,
    "% match"
  ] }, void 0, true, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/MatchRing.tsx",
    lineNumber: 118,
    columnNumber: 5
  }, this);
}
_c2 = MatchPill;
var _c, _c2;
$RefreshReg$(_c, "MatchRing");
$RefreshReg$(_c2, "MatchPill");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/I2I Project - Habito/App Folder/habito/src/components/space/MatchRing.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/I2I Project - Habito/App Folder/habito/src/components/space/MatchRing.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNkRVOzs7Ozs7Ozs7Ozs7Ozs7OztBQTdEVixTQUFTQSxXQUFXQyxRQUFRQyxnQkFBZ0I7QUFDNUMsU0FBU0MsVUFBVTtBQUNuQixTQUFTQyxrQkFBa0I7QUFNcEIsZ0JBQVNDLFVBQVU7QUFBQSxFQUN4QkM7QUFBQUEsRUFDQUMsT0FBTztBQUFBLEVBQ1BDLFlBQVk7QUFBQSxFQUNaQztBQU1GLEdBQUc7QUFBQUMsS0FBQTtBQUNELFFBQU1DLE1BQU1WLE9BQXVCLElBQUk7QUFDdkMsUUFBTSxDQUFDVyxPQUFPQyxRQUFRLElBQUlYLFNBQVMsQ0FBQztBQUVwQ0YsWUFBVSxNQUFNO0FBQ2QsVUFBTWMsT0FBT0gsSUFBSUk7QUFDakIsUUFBSSxDQUFDRCxLQUFNO0FBRVgsVUFBTUUsU0FBU0MsT0FBT0MsV0FBVyxrQ0FBa0MsRUFBRUM7QUFDckUsUUFBSUgsUUFBUTtBQUNWSCxlQUFTUCxLQUFLO0FBQ2Q7QUFBQSxJQUNGO0FBRUEsVUFBTWMsV0FBVyxJQUFJQztBQUFBQSxNQUNuQixDQUFDLENBQUNDLEtBQUssTUFBTTtBQUNYLFlBQUksQ0FBQ0EsTUFBTUMsZUFBZ0I7QUFDM0JILGlCQUFTSSxXQUFXO0FBQ3BCLGNBQU1DLFFBQVFDLFlBQVlDLElBQUk7QUFDOUIsY0FBTUMsV0FBVztBQUNqQixjQUFNQyxPQUFPQSxDQUFDRixRQUFnQjtBQUM1QixnQkFBTUcsSUFBSUMsS0FBS0MsSUFBSSxJQUFJTCxNQUFNRixTQUFTRyxRQUFRO0FBQzlDLGdCQUFNSyxRQUFRLElBQUlGLEtBQUtHLElBQUksSUFBSUosR0FBRyxDQUFDO0FBQ25DakIsbUJBQVNrQixLQUFLSSxNQUFNN0IsUUFBUTJCLEtBQUssQ0FBQztBQUNsQyxjQUFJSCxJQUFJLEVBQUdNLHVCQUFzQlAsSUFBSTtBQUFBLFFBQ3ZDO0FBQ0FPLDhCQUFzQlAsSUFBSTtBQUFBLE1BQzVCO0FBQUEsTUFDQSxFQUFFUSxXQUFXLElBQUk7QUFBQSxJQUNuQjtBQUVBakIsYUFBU2tCLFFBQVF4QixJQUFJO0FBQ3JCLFdBQU8sTUFBTU0sU0FBU0ksV0FBVztBQUFBLEVBQ25DLEdBQUcsQ0FBQ2xCLEtBQUssQ0FBQztBQUVWLFFBQU1pQyxTQUFTaEMsUUFBUSxLQUFLLElBQUk7QUFDaEMsUUFBTWlDLFVBQVVqQyxPQUFPZ0MsVUFBVTtBQUNqQyxRQUFNRSxnQkFBZ0IsSUFBSVYsS0FBS1csS0FBS0Y7QUFFcEMsU0FDRSx1QkFBQyxTQUFJLEtBQVUsV0FBV3JDLEdBQUcsa0NBQWtDTSxTQUFTLEdBQ3RFO0FBQUEsMkJBQUMsU0FBSSxXQUFVLHFCQUFvQixPQUFPLEVBQUVrQyxPQUFPcEMsTUFBTXFDLFFBQVFyQyxLQUFLLEdBQ3BFO0FBQUEsNkJBQUMsU0FBSSxPQUFPQSxNQUFNLFFBQVFBLE1BQU0sU0FBUyxPQUFPQSxJQUFJLElBQUlBLElBQUksSUFBSSxlQUFXLE1BQ3pFO0FBQUEsK0JBQUMsWUFBTyxJQUFJQSxPQUFPLEdBQUcsSUFBSUEsT0FBTyxHQUFHLEdBQUdpQyxRQUFRLE1BQUssUUFBTyxRQUFPLGdCQUFlLGFBQWFELFFBQVEsV0FBVSxpQkFBaEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE2SDtBQUFBLFFBQzdIO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxJQUFJaEMsT0FBTztBQUFBLFlBQ1gsSUFBSUEsT0FBTztBQUFBLFlBQ1gsR0FBR2lDO0FBQUFBLFlBQ0gsTUFBSztBQUFBLFlBQ0wsUUFBTztBQUFBLFlBQ1AsYUFBYUQ7QUFBQUEsWUFDYixlQUFjO0FBQUEsWUFDZCxXQUFVO0FBQUEsWUFDVixpQkFBaUJFO0FBQUFBLFlBQ2pCLGtCQUFrQkEsaUJBQWlCLElBQUk3QixRQUFRO0FBQUEsWUFDL0MsV0FBVyxjQUFjTCxPQUFPLENBQUMsSUFBSUEsT0FBTyxDQUFDO0FBQUE7QUFBQSxVQVgvQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFXbUQ7QUFBQSxXQWJyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBZUE7QUFBQSxNQUNBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxXQUFVO0FBQUEsVUFDVixPQUFPLEVBQUVzQyxVQUFVdEMsT0FBTyxLQUFLO0FBQUEsVUFFOUJLO0FBQUFBO0FBQUFBLFlBQ0QsdUJBQUMsVUFBSyxPQUFPLEVBQUVpQyxVQUFVdEMsT0FBTyxLQUFLLEdBQUcsV0FBVSxxQkFBb0IsaUJBQXRFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXVFO0FBQUE7QUFBQTtBQUFBLFFBTHpFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQU1BO0FBQUEsU0F2QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXdCQTtBQUFBLElBQ0NDLGFBQ0MsdUJBQUMsU0FDQztBQUFBLDZCQUFDLE9BQUUsV0FBVSxpREFBaURKLHFCQUFXRSxLQUFLLEtBQTlFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBZ0Y7QUFBQSxNQUNoRix1QkFBQyxPQUFFLFdBQVUsc0JBQXFCLDRCQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQThDO0FBQUEsU0FGaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdBO0FBQUEsSUFFRix1QkFBQyxVQUFLLFdBQVUsV0FBV0E7QUFBQUE7QUFBQUEsTUFBTTtBQUFBLE1BQVdGLFdBQVdFLEtBQUs7QUFBQSxTQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQThEO0FBQUEsT0FoQ2hFO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FpQ0E7QUFFSjtBQUVBSSxHQXZGZ0JMLFdBQVM7QUFBQSxLQUFUQTtBQXdGVCxnQkFBU3lDLFVBQVUsRUFBRXhDLE1BQXlCLEdBQUc7QUFDdEQsU0FDRSx1QkFBQyxVQUFLLFdBQVUsd0hBQ2Q7QUFBQSwyQkFBQyxVQUFLLFdBQVUscUNBQW9DLGVBQVcsUUFBL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUErRDtBQUFBLElBQzlEQTtBQUFBQSxJQUFNO0FBQUEsT0FGVDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBR0E7QUFFSjtBQUFDeUMsTUFQZUQ7QUFBUyxJQUFBRSxJQUFBRDtBQUFBLGFBQUFDLElBQUE7QUFBQSxhQUFBRCxLQUFBIiwibmFtZXMiOlsidXNlRWZmZWN0IiwidXNlUmVmIiwidXNlU3RhdGUiLCJjbiIsIm1hdGNoTGFiZWwiLCJNYXRjaFJpbmciLCJzY29yZSIsInNpemUiLCJzaG93TGFiZWwiLCJjbGFzc05hbWUiLCJfcyIsInJlZiIsInNob3duIiwic2V0U2hvd24iLCJub2RlIiwiY3VycmVudCIsInJlZHVjZSIsIndpbmRvdyIsIm1hdGNoTWVkaWEiLCJtYXRjaGVzIiwib2JzZXJ2ZXIiLCJJbnRlcnNlY3Rpb25PYnNlcnZlciIsImVudHJ5IiwiaXNJbnRlcnNlY3RpbmciLCJkaXNjb25uZWN0Iiwic3RhcnQiLCJwZXJmb3JtYW5jZSIsIm5vdyIsImR1cmF0aW9uIiwidGljayIsInQiLCJNYXRoIiwibWluIiwiZWFzZWQiLCJwb3ciLCJyb3VuZCIsInJlcXVlc3RBbmltYXRpb25GcmFtZSIsInRocmVzaG9sZCIsIm9ic2VydmUiLCJzdHJva2UiLCJyYWRpdXMiLCJjaXJjdW1mZXJlbmNlIiwiUEkiLCJ3aWR0aCIsImhlaWdodCIsImZvbnRTaXplIiwiTWF0Y2hQaWxsIiwiX2MyIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiTWF0Y2hSaW5nLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVJlZiwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IGNuIH0gZnJvbSBcIkAvbGliL2NuXCI7XG5pbXBvcnQgeyBtYXRjaExhYmVsIH0gZnJvbSBcIkAvbGliL21hdGNoaW5nXCI7XG5cbi8qKlxuICogVGhlIHNjb3JlLCBkcmF3biByYXRoZXIgdGhhbiBwcmludGVkLiBBbmltYXRlcyBvbmNlIG9uIGVudHJ5IOKAlCB0aGUgbnVtYmVyXG4gKiBjb3VudGluZyB1cCBpcyB0aGUgb25seSBtb21lbnQgb24gdGhlIHBhZ2UgdGhhdCBhc2tzIGZvciBhdHRlbnRpb24uXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBNYXRjaFJpbmcoe1xuICBzY29yZSxcbiAgc2l6ZSA9IDg4LFxuICBzaG93TGFiZWwgPSB0cnVlLFxuICBjbGFzc05hbWUsXG59OiB7XG4gIHNjb3JlOiBudW1iZXI7XG4gIHNpemU/OiBudW1iZXI7XG4gIHNob3dMYWJlbD86IGJvb2xlYW47XG4gIGNsYXNzTmFtZT86IHN0cmluZztcbn0pIHtcbiAgY29uc3QgcmVmID0gdXNlUmVmPEhUTUxEaXZFbGVtZW50PihudWxsKTtcbiAgY29uc3QgW3Nob3duLCBzZXRTaG93bl0gPSB1c2VTdGF0ZSgwKTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGNvbnN0IG5vZGUgPSByZWYuY3VycmVudDtcbiAgICBpZiAoIW5vZGUpIHJldHVybjtcblxuICAgIGNvbnN0IHJlZHVjZSA9IHdpbmRvdy5tYXRjaE1lZGlhKFwiKHByZWZlcnMtcmVkdWNlZC1tb3Rpb246IHJlZHVjZSlcIikubWF0Y2hlcztcbiAgICBpZiAocmVkdWNlKSB7XG4gICAgICBzZXRTaG93bihzY29yZSk7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgY29uc3Qgb2JzZXJ2ZXIgPSBuZXcgSW50ZXJzZWN0aW9uT2JzZXJ2ZXIoXG4gICAgICAoW2VudHJ5XSkgPT4ge1xuICAgICAgICBpZiAoIWVudHJ5LmlzSW50ZXJzZWN0aW5nKSByZXR1cm47XG4gICAgICAgIG9ic2VydmVyLmRpc2Nvbm5lY3QoKTtcbiAgICAgICAgY29uc3Qgc3RhcnQgPSBwZXJmb3JtYW5jZS5ub3coKTtcbiAgICAgICAgY29uc3QgZHVyYXRpb24gPSA3MDA7XG4gICAgICAgIGNvbnN0IHRpY2sgPSAobm93OiBudW1iZXIpID0+IHtcbiAgICAgICAgICBjb25zdCB0ID0gTWF0aC5taW4oMSwgKG5vdyAtIHN0YXJ0KSAvIGR1cmF0aW9uKTtcbiAgICAgICAgICBjb25zdCBlYXNlZCA9IDEgLSBNYXRoLnBvdygxIC0gdCwgMyk7XG4gICAgICAgICAgc2V0U2hvd24oTWF0aC5yb3VuZChzY29yZSAqIGVhc2VkKSk7XG4gICAgICAgICAgaWYgKHQgPCAxKSByZXF1ZXN0QW5pbWF0aW9uRnJhbWUodGljayk7XG4gICAgICAgIH07XG4gICAgICAgIHJlcXVlc3RBbmltYXRpb25GcmFtZSh0aWNrKTtcbiAgICAgIH0sXG4gICAgICB7IHRocmVzaG9sZDogMC40IH0sXG4gICAgKTtcblxuICAgIG9ic2VydmVyLm9ic2VydmUobm9kZSk7XG4gICAgcmV0dXJuICgpID0+IG9ic2VydmVyLmRpc2Nvbm5lY3QoKTtcbiAgfSwgW3Njb3JlXSk7XG5cbiAgY29uc3Qgc3Ryb2tlID0gc2l6ZSA+PSA3MCA/IDcgOiA1O1xuICBjb25zdCByYWRpdXMgPSAoc2l6ZSAtIHN0cm9rZSkgLyAyO1xuICBjb25zdCBjaXJjdW1mZXJlbmNlID0gMiAqIE1hdGguUEkgKiByYWRpdXM7XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IHJlZj17cmVmfSBjbGFzc05hbWU9e2NuKFwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCIsIGNsYXNzTmFtZSl9PlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBzaHJpbmstMFwiIHN0eWxlPXt7IHdpZHRoOiBzaXplLCBoZWlnaHQ6IHNpemUgfX0+XG4gICAgICAgIDxzdmcgd2lkdGg9e3NpemV9IGhlaWdodD17c2l6ZX0gdmlld0JveD17YDAgMCAke3NpemV9ICR7c2l6ZX1gfSBhcmlhLWhpZGRlbj5cbiAgICAgICAgICA8Y2lyY2xlIGN4PXtzaXplIC8gMn0gY3k9e3NpemUgLyAyfSByPXtyYWRpdXN9IGZpbGw9XCJub25lXCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgc3Ryb2tlV2lkdGg9e3N0cm9rZX0gY2xhc3NOYW1lPVwidGV4dC1pbmsvMTBcIiAvPlxuICAgICAgICAgIDxjaXJjbGVcbiAgICAgICAgICAgIGN4PXtzaXplIC8gMn1cbiAgICAgICAgICAgIGN5PXtzaXplIC8gMn1cbiAgICAgICAgICAgIHI9e3JhZGl1c31cbiAgICAgICAgICAgIGZpbGw9XCJub25lXCJcbiAgICAgICAgICAgIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiXG4gICAgICAgICAgICBzdHJva2VXaWR0aD17c3Ryb2tlfVxuICAgICAgICAgICAgc3Ryb2tlTGluZWNhcD1cInJvdW5kXCJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtYXF1YS02MDAgdHJhbnNpdGlvbi1bc3Ryb2tlLWRhc2hvZmZzZXRdIGR1cmF0aW9uLTE1MFwiXG4gICAgICAgICAgICBzdHJva2VEYXNoYXJyYXk9e2NpcmN1bWZlcmVuY2V9XG4gICAgICAgICAgICBzdHJva2VEYXNob2Zmc2V0PXtjaXJjdW1mZXJlbmNlICogKDEgLSBzaG93biAvIDEwMCl9XG4gICAgICAgICAgICB0cmFuc2Zvcm09e2Byb3RhdGUoLTkwICR7c2l6ZSAvIDJ9ICR7c2l6ZSAvIDJ9KWB9XG4gICAgICAgICAgLz5cbiAgICAgICAgPC9zdmc+XG4gICAgICAgIDxzcGFuXG4gICAgICAgICAgY2xhc3NOYW1lPVwiYWJzb2x1dGUgaW5zZXQtMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBmb250LWRpc3BsYXkgZm9udC1ib2xkIHRleHQtaW5rIHRudW1cIlxuICAgICAgICAgIHN0eWxlPXt7IGZvbnRTaXplOiBzaXplICogMC4yOCB9fVxuICAgICAgICA+XG4gICAgICAgICAge3Nob3dufVxuICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGZvbnRTaXplOiBzaXplICogMC4xNiB9fSBjbGFzc05hbWU9XCJtbC0wLjUgdGV4dC1tdXRlZFwiPiU8L3NwYW4+XG4gICAgICAgIDwvc3Bhbj5cbiAgICAgIDwvZGl2PlxuICAgICAge3Nob3dMYWJlbCAmJiAoXG4gICAgICAgIDxkaXY+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwiZm9udC1kaXNwbGF5IGZvbnQtYm9sZCBsZWFkaW5nLXRpZ2h0IHRleHQtaW5rXCI+e21hdGNoTGFiZWwoc2NvcmUpfTwvcD5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtbXV0ZWRcIj5IYWJpdG8gTWF0Y2g8L3A+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cbiAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInNyLW9ubHlcIj57c2NvcmV9JSBtYXRjaCDigJQge21hdGNoTGFiZWwoc2NvcmUpfTwvc3Bhbj5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cblxuLyoqIENvbXBhY3QgcGlsbCBmb3IgY2FyZCBjb3JuZXJzLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIE1hdGNoUGlsbCh7IHNjb3JlIH06IHsgc2NvcmU6IG51bWJlciB9KSB7XG4gIHJldHVybiAoXG4gICAgPHNwYW4gY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0xIHJvdW5kZWQtZnVsbCBiZy1pbmsvODUgcHgtMi41IHB5LTEgdGV4dC14cyBmb250LWJvbGQgdGV4dC1pdm9yeSBiYWNrZHJvcC1ibHVyLXNtIHRudW1cIj5cbiAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInNpemUtMS41IHJvdW5kZWQtZnVsbCBiZy1hcXVhLTQwMFwiIGFyaWEtaGlkZGVuIC8+XG4gICAgICB7c2NvcmV9JSBtYXRjaFxuICAgIDwvc3Bhbj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiRDovSTJJIFByb2plY3QgLSBIYWJpdG8vQXBwIEZvbGRlci9oYWJpdG8vc3JjL2NvbXBvbmVudHMvc3BhY2UvTWF0Y2hSaW5nLnRzeCJ9