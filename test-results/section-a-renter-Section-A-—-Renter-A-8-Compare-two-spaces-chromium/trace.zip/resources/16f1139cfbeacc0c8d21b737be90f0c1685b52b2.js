import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Auth.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=9ceb86a3"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("D:/I2I Project - Habito/App Folder/habito/src/pages/Auth.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9ceb86a3"; const useState = __vite__cjsImport3_react["useState"];
import { Link, Navigate, useLocation, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=9ceb86a3";
import { ArrowRight, Home, Store, AlertCircle, MailCheck } from "/node_modules/.vite/deps/lucide-react.js?v=9ceb86a3";
import { useAuth } from "/src/hooks/useAuth.tsx";
import { Button } from "/src/components/ui/Button.tsx";
import { cn } from "/src/lib/cn.ts";
import { useI18n } from "/src/i18n/index.tsx";
const inputClass = "h-11 w-full rounded-xl bg-ivory px-3 text-[0.9375rem] text-ink ring-1 ring-hairline-strong focus:outline-none focus:ring-2 focus:ring-aqua-600";
export default function Auth({ initial = "signin" }) {
  _s();
  const { t } = useI18n();
  const { account, configured, signIn, signUp, resetPassword } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [mode, setMode] = useState(initial);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState("renter");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(null);
  const [notice, setNotice] = useState(null);
  const from = location.state?.from;
  if (account) return /* @__PURE__ */ jsxDEV(Navigate, { to: from ?? (account.role === "owner" ? "/portfolio" : "/explore"), replace: true }, void 0, false, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Auth.tsx",
    lineNumber: 52,
    columnNumber: 23
  }, this);
  const submit = async () => {
    setError(null);
    setNotice(null);
    if (!email.trim() || password.length < 6) {
      setError("Enter your email and a password of at least 6 characters.");
      return;
    }
    if (mode === "signup" && name.trim().length < 2) {
      setError("Tell us your name so owners know who's asking.");
      return;
    }
    setBusy(true);
    try {
      if (mode === "signin") {
        await signIn(email.trim(), password);
        navigate(from ?? "/explore", { replace: true });
      } else {
        const { needsConfirmation } = await signUp({
          name: name.trim(),
          email: email.trim(),
          password,
          phone: phone.trim() || void 0,
          role
        });
        if (needsConfirmation) {
          setNotice("Check your email for a confirmation link, then sign in.");
          setMode("signin");
        } else {
          navigate(role === "owner" ? "/portfolio" : "/explore", { replace: true });
        }
      }
    } catch (e) {
      setError(e instanceof Error ? e.message : "Something went wrong. Try again.");
    } finally {
      setBusy(false);
    }
  };
  const forgot = async () => {
    if (!email.trim()) {
      setError("Enter your email first, then tap reset.");
      return;
    }
    try {
      await resetPassword(email.trim());
      setNotice("If that email has an account, a reset link is on its way.");
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not send the reset link.");
    }
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "container-page max-w-md py-12 md:py-16", children: [
    /* @__PURE__ */ jsxDEV("h1", { className: "font-display text-3xl font-extrabold text-ink sm:text-4xl", children: mode === "signin" ? "Welcome back." : "Create your account." }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Auth.tsx",
      lineNumber: 110,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm leading-relaxed text-muted", children: mode === "signin" ? "Sign in to reach your saved spaces, inquiries and listings." : "One account, whichever side of Habito you're on." }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Auth.tsx",
      lineNumber: 113,
      columnNumber: 7
    }, this),
    !configured && /* @__PURE__ */ jsxDEV("p", { className: "mt-5 flex gap-2.5 rounded-card bg-warn-100 p-4 text-sm leading-relaxed text-warn-700", children: [
      /* @__PURE__ */ jsxDEV(AlertCircle, { size: 16, className: "mt-0.5 shrink-0", "aria-hidden": true }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Auth.tsx",
        lineNumber: 121,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("span", { children: "Habito isn't connected to a database in this build, so accounts can't be created. Browsing still works and your activity is kept in this browser." }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Auth.tsx",
        lineNumber: 122,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Auth.tsx",
      lineNumber: 120,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "mt-7 space-y-4", children: [
      mode === "signup" && /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV(Field, { label: "Your name", children: /* @__PURE__ */ jsxDEV(
          "input",
          {
            value: name,
            onChange: (e) => setName(e.target.value),
            autoComplete: "name",
            placeholder: "Farhana Akter",
            className: inputClass
          },
          void 0,
          false,
          {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Auth.tsx",
            lineNumber: 133,
            columnNumber: 15
          },
          this
        ) }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Auth.tsx",
          lineNumber: 132,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(Field, { label: "What brings you here?", children: /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-2", children: [
          /* @__PURE__ */ jsxDEV(
            RoleOption,
            {
              active: role === "renter",
              onClick: () => setRole("renter"),
              icon: Home,
              title: t("auth.needSpace"),
              body: "Search, save and enquire"
            },
            void 0,
            false,
            {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Auth.tsx",
              lineNumber: 144,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            RoleOption,
            {
              active: role === "owner",
              onClick: () => setRole("owner"),
              icon: Store,
              title: t("auth.haveSpace"),
              body: "List and manage it"
            },
            void 0,
            false,
            {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Auth.tsx",
              lineNumber: 151,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Auth.tsx",
          lineNumber: 143,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Auth.tsx",
          lineNumber: 142,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Auth.tsx",
        lineNumber: 131,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Field, { label: "Email", children: /* @__PURE__ */ jsxDEV(
        "input",
        {
          type: "email",
          value: email,
          onChange: (e) => setEmail(e.target.value),
          autoComplete: "email",
          inputMode: "email",
          placeholder: "you@example.com",
          className: inputClass
        },
        void 0,
        false,
        {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Auth.tsx",
          lineNumber: 164,
          columnNumber: 11
        },
        this
      ) }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Auth.tsx",
        lineNumber: 163,
        columnNumber: 9
      }, this),
      mode === "signup" && /* @__PURE__ */ jsxDEV(Field, { label: "Phone", optional: true, children: /* @__PURE__ */ jsxDEV(
        "input",
        {
          type: "tel",
          value: phone,
          onChange: (e) => setPhone(e.target.value),
          autoComplete: "tel",
          inputMode: "tel",
          placeholder: "01XXXXXXXXX",
          className: inputClass
        },
        void 0,
        false,
        {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Auth.tsx",
          lineNumber: 177,
          columnNumber: 13
        },
        this
      ) }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Auth.tsx",
        lineNumber: 176,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Field, { label: "Password", children: /* @__PURE__ */ jsxDEV(
        "input",
        {
          type: "password",
          value: password,
          onChange: (e) => setPassword(e.target.value),
          autoComplete: mode === "signin" ? "current-password" : "new-password",
          placeholder: "At least 6 characters",
          className: inputClass
        },
        void 0,
        false,
        {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Auth.tsx",
          lineNumber: 190,
          columnNumber: 11
        },
        this
      ) }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Auth.tsx",
        lineNumber: 189,
        columnNumber: 9
      }, this),
      error && /* @__PURE__ */ jsxDEV("p", { className: "flex gap-2 rounded-xl bg-danger-100 p-3 text-sm text-danger-600", children: [
        /* @__PURE__ */ jsxDEV(AlertCircle, { size: 15, className: "mt-0.5 shrink-0", "aria-hidden": true }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Auth.tsx",
          lineNumber: 202,
          columnNumber: 13
        }, this),
        error
      ] }, void 0, true, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Auth.tsx",
        lineNumber: 201,
        columnNumber: 9
      }, this),
      notice && /* @__PURE__ */ jsxDEV("p", { className: "flex gap-2 rounded-xl bg-ok-100 p-3 text-sm text-ok-600", children: [
        /* @__PURE__ */ jsxDEV(MailCheck, { size: 15, className: "mt-0.5 shrink-0", "aria-hidden": true }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Auth.tsx",
          lineNumber: 209,
          columnNumber: 13
        }, this),
        notice
      ] }, void 0, true, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Auth.tsx",
        lineNumber: 208,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Button, { size: "lg", fullWidth: true, disabled: busy || !configured, onClick: () => void submit(), children: [
        busy ? "Working…" : mode === "signin" ? "Sign in" : "Create account",
        /* @__PURE__ */ jsxDEV(ArrowRight, { size: 17, "aria-hidden": true }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Auth.tsx",
          lineNumber: 216,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Auth.tsx",
        lineNumber: 214,
        columnNumber: 9
      }, this),
      mode === "signin" && configured && /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          onClick: () => void forgot(),
          className: "w-full text-center text-xs font-semibold text-muted hover:text-ink",
          children: "Forgot your password?"
        },
        void 0,
        false,
        {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Auth.tsx",
          lineNumber: 220,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Auth.tsx",
      lineNumber: 129,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("p", { className: "mt-8 border-t border-hairline pt-5 text-center text-sm text-muted", children: [
      mode === "signin" ? "No account yet?" : "Already have an account?",
      " ",
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          onClick: () => {
            setMode(mode === "signin" ? "signup" : "signin");
            setError(null);
            setNotice(null);
          },
          className: "font-semibold text-aqua-700 hover:underline",
          children: mode === "signin" ? "Create one" : "Sign in"
        },
        void 0,
        false,
        {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Auth.tsx",
          lineNumber: 232,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Auth.tsx",
      lineNumber: 230,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("p", { className: "mt-4 text-center text-xs text-muted", children: [
      "Just looking?",
      " ",
      /* @__PURE__ */ jsxDEV(Link, { to: "/explore", className: "font-semibold hover:text-ink", children: "Browse without an account" }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Auth.tsx",
        lineNumber: 247,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Auth.tsx",
      lineNumber: 245,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Auth.tsx",
    lineNumber: 109,
    columnNumber: 5
  }, this);
}
_s(Auth, "LKc6wyIlh7TFAyAzSSTnqrQadAw=", false, function() {
  return [useI18n, useAuth, useNavigate, useLocation];
});
_c = Auth;
function Field({ label, optional, children }) {
  return /* @__PURE__ */ jsxDEV("label", { className: "block", children: [
    /* @__PURE__ */ jsxDEV("span", { className: "mb-1.5 block text-sm font-medium text-ink-soft", children: [
      label,
      optional && /* @__PURE__ */ jsxDEV("span", { className: "ml-1.5 text-xs text-muted", children: "optional" }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Auth.tsx",
        lineNumber: 260,
        columnNumber: 22
      }, this)
    ] }, void 0, true, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Auth.tsx",
      lineNumber: 258,
      columnNumber: 7
    }, this),
    children
  ] }, void 0, true, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Auth.tsx",
    lineNumber: 257,
    columnNumber: 5
  }, this);
}
_c2 = Field;
function RoleOption({
  active,
  onClick,
  icon: Icon,
  title,
  body
}) {
  return /* @__PURE__ */ jsxDEV(
    "button",
    {
      type: "button",
      "aria-pressed": active,
      onClick,
      className: cn(
        "rounded-2xl p-3.5 text-left ring-1 transition-colors",
        active ? "bg-aqua-50 ring-aqua-600" : "bg-ivory ring-hairline hover:ring-hairline-strong"
      ),
      children: [
        /* @__PURE__ */ jsxDEV(Icon, { size: 18, className: active ? "text-aqua-700" : "text-muted", "aria-hidden": true }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Auth.tsx",
          lineNumber: 290,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "mt-2 block text-sm font-bold text-ink", children: title }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Auth.tsx",
          lineNumber: 291,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "mt-0.5 block text-xs leading-snug text-muted", children: body }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Auth.tsx",
          lineNumber: 292,
          columnNumber: 7
        }, this)
      ]
    },
    void 0,
    true,
    {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Auth.tsx",
      lineNumber: 281,
      columnNumber: 5
    },
    this
  );
}
_c3 = RoleOption;
var _c, _c2, _c3;
$RefreshReg$(_c, "Auth");
$RefreshReg$(_c2, "Field");
$RefreshReg$(_c3, "RoleOption");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/I2I Project - Habito/App Folder/habito/src/pages/Auth.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/I2I Project - Habito/App Folder/habito/src/pages/Auth.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0NzQixTQStFWixVQS9FWTs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFoQ3RCLFNBQVNBLGdCQUFnQjtBQUN6QixTQUFTQyxNQUFNQyxVQUFVQyxhQUFhQyxtQkFBbUI7QUFDekQsU0FBU0MsWUFBWUMsTUFBTUMsT0FBT0MsYUFBYUMsaUJBQWlCO0FBQ2hFLFNBQVNDLGVBQWU7QUFDeEIsU0FBU0MsY0FBYztBQUN2QixTQUFTQyxVQUFVO0FBQ25CLFNBQVNDLGVBQWU7QUFJeEIsTUFBTUMsYUFDSjtBQUVGLHdCQUF3QkMsS0FBSyxFQUFFQyxVQUFVLFNBQTZCLEdBQUc7QUFBQUMsS0FBQTtBQUN2RSxRQUFNLEVBQUVDLEVBQUUsSUFBSUwsUUFBUTtBQUN0QixRQUFNLEVBQUVNLFNBQVNDLFlBQVlDLFFBQVFDLFFBQVFDLGNBQWMsSUFBSWIsUUFBUTtBQUN2RSxRQUFNYyxXQUFXcEIsWUFBWTtBQUM3QixRQUFNcUIsV0FBV3RCLFlBQVk7QUFFN0IsUUFBTSxDQUFDdUIsTUFBTUMsT0FBTyxJQUFJM0IsU0FBZWdCLE9BQU87QUFDOUMsUUFBTSxDQUFDWSxNQUFNQyxPQUFPLElBQUk3QixTQUFTLEVBQUU7QUFDbkMsUUFBTSxDQUFDOEIsT0FBT0MsUUFBUSxJQUFJL0IsU0FBUyxFQUFFO0FBQ3JDLFFBQU0sQ0FBQ2dDLE9BQU9DLFFBQVEsSUFBSWpDLFNBQVMsRUFBRTtBQUNyQyxRQUFNLENBQUNrQyxVQUFVQyxXQUFXLElBQUluQyxTQUFTLEVBQUU7QUFDM0MsUUFBTSxDQUFDb0MsTUFBTUMsT0FBTyxJQUFJckMsU0FBNkIsUUFBUTtBQUU3RCxRQUFNLENBQUNzQyxNQUFNQyxPQUFPLElBQUl2QyxTQUFTLEtBQUs7QUFDdEMsUUFBTSxDQUFDd0MsT0FBT0MsUUFBUSxJQUFJekMsU0FBd0IsSUFBSTtBQUN0RCxRQUFNLENBQUMwQyxRQUFRQyxTQUFTLElBQUkzQyxTQUF3QixJQUFJO0FBRXhELFFBQU00QyxPQUFRbkIsU0FBU29CLE9BQW9DRDtBQUUzRCxNQUFJekIsUUFBUyxRQUFPLHVCQUFDLFlBQVMsSUFBSXlCLFNBQVN6QixRQUFRaUIsU0FBUyxVQUFVLGVBQWUsYUFBYSxTQUFPLFFBQXJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBcUY7QUFFekcsUUFBTVUsU0FBUyxZQUFZO0FBQ3pCTCxhQUFTLElBQUk7QUFDYkUsY0FBVSxJQUFJO0FBRWQsUUFBSSxDQUFDYixNQUFNaUIsS0FBSyxLQUFLYixTQUFTYyxTQUFTLEdBQUc7QUFDeENQLGVBQVMsMkRBQTJEO0FBQ3BFO0FBQUEsSUFDRjtBQUNBLFFBQUlmLFNBQVMsWUFBWUUsS0FBS21CLEtBQUssRUFBRUMsU0FBUyxHQUFHO0FBQy9DUCxlQUFTLGdEQUFnRDtBQUN6RDtBQUFBLElBQ0Y7QUFFQUYsWUFBUSxJQUFJO0FBQ1osUUFBSTtBQUNGLFVBQUliLFNBQVMsVUFBVTtBQUNyQixjQUFNTCxPQUFPUyxNQUFNaUIsS0FBSyxHQUFHYixRQUFRO0FBQ25DVixpQkFBU29CLFFBQVEsWUFBWSxFQUFFSyxTQUFTLEtBQUssQ0FBQztBQUFBLE1BQ2hELE9BQU87QUFDTCxjQUFNLEVBQUVDLGtCQUFrQixJQUFJLE1BQU01QixPQUFPO0FBQUEsVUFDekNNLE1BQU1BLEtBQUttQixLQUFLO0FBQUEsVUFDaEJqQixPQUFPQSxNQUFNaUIsS0FBSztBQUFBLFVBQ2xCYjtBQUFBQSxVQUNBRixPQUFPQSxNQUFNZSxLQUFLLEtBQUtJO0FBQUFBLFVBQ3ZCZjtBQUFBQSxRQUNGLENBQUM7QUFFRCxZQUFJYyxtQkFBbUI7QUFDckJQLG9CQUFVLHlEQUF5RDtBQUNuRWhCLGtCQUFRLFFBQVE7QUFBQSxRQUNsQixPQUFPO0FBQ0xILG1CQUFTWSxTQUFTLFVBQVUsZUFBZSxZQUFZLEVBQUVhLFNBQVMsS0FBSyxDQUFDO0FBQUEsUUFDMUU7QUFBQSxNQUNGO0FBQUEsSUFDRixTQUFTRyxHQUFHO0FBQ1ZYLGVBQVNXLGFBQWFDLFFBQVFELEVBQUVFLFVBQVUsa0NBQWtDO0FBQUEsSUFDOUUsVUFBQztBQUNDZixjQUFRLEtBQUs7QUFBQSxJQUNmO0FBQUEsRUFDRjtBQUVBLFFBQU1nQixTQUFTLFlBQVk7QUFDekIsUUFBSSxDQUFDekIsTUFBTWlCLEtBQUssR0FBRztBQUNqQk4sZUFBUyx5Q0FBeUM7QUFDbEQ7QUFBQSxJQUNGO0FBQ0EsUUFBSTtBQUNGLFlBQU1sQixjQUFjTyxNQUFNaUIsS0FBSyxDQUFDO0FBQ2hDSixnQkFBVSwyREFBMkQ7QUFBQSxJQUN2RSxTQUFTUyxHQUFHO0FBQ1ZYLGVBQVNXLGFBQWFDLFFBQVFELEVBQUVFLFVBQVUsZ0NBQWdDO0FBQUEsSUFDNUU7QUFBQSxFQUNGO0FBRUEsU0FDRSx1QkFBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSwyQkFBQyxRQUFHLFdBQVUsNkRBQ1g1QixtQkFBUyxXQUFXLGtCQUFrQiwwQkFEekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsSUFDQSx1QkFBQyxPQUFFLFdBQVUsMkNBQ1ZBLG1CQUFTLFdBQ04sZ0VBQ0Esc0RBSE47QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUlBO0FBQUEsSUFFQyxDQUFDTixjQUNBLHVCQUFDLE9BQUUsV0FBVSx3RkFDWDtBQUFBLDZCQUFDLGVBQVksTUFBTSxJQUFJLFdBQVUsbUJBQWtCLGVBQVcsUUFBOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE4RDtBQUFBLE1BQzlELHVCQUFDLFVBQUksaUtBQUw7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsU0FMRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBTUE7QUFBQSxJQUdGLHVCQUFDLFNBQUksV0FBVSxrQkFDWk07QUFBQUEsZUFBUyxZQUNSLG1DQUNFO0FBQUEsK0JBQUMsU0FBTSxPQUFNLGFBQ1g7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE9BQU9FO0FBQUFBLFlBQ1AsVUFBVSxDQUFDd0IsTUFBTXZCLFFBQVF1QixFQUFFSSxPQUFPQyxLQUFLO0FBQUEsWUFDdkMsY0FBYTtBQUFBLFlBQ2IsYUFBWTtBQUFBLFlBQ1osV0FBVzNDO0FBQUFBO0FBQUFBLFVBTGI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBS3dCLEtBTjFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFRQTtBQUFBLFFBRUEsdUJBQUMsU0FBTSxPQUFNLHlCQUNYLGlDQUFDLFNBQUksV0FBVSwwQkFDYjtBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxRQUFRc0IsU0FBUztBQUFBLGNBQ2pCLFNBQVMsTUFBTUMsUUFBUSxRQUFRO0FBQUEsY0FDL0IsTUFBTS9CO0FBQUFBLGNBQ04sT0FBT1ksRUFBRSxnQkFBZ0I7QUFBQSxjQUN6QixNQUFLO0FBQUE7QUFBQSxZQUxQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUtpQztBQUFBLFVBRWpDO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxRQUFRa0IsU0FBUztBQUFBLGNBQ2pCLFNBQVMsTUFBTUMsUUFBUSxPQUFPO0FBQUEsY0FDOUIsTUFBTTlCO0FBQUFBLGNBQ04sT0FBT1csRUFBRSxnQkFBZ0I7QUFBQSxjQUN6QixNQUFLO0FBQUE7QUFBQSxZQUxQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUsyQjtBQUFBLGFBYjdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFlQSxLQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBaUJBO0FBQUEsV0E1QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTZCQTtBQUFBLE1BR0YsdUJBQUMsU0FBTSxPQUFNLFNBQ1g7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE1BQUs7QUFBQSxVQUNMLE9BQU9ZO0FBQUFBLFVBQ1AsVUFBVSxDQUFDc0IsTUFBTXJCLFNBQVNxQixFQUFFSSxPQUFPQyxLQUFLO0FBQUEsVUFDeEMsY0FBYTtBQUFBLFVBQ2IsV0FBVTtBQUFBLFVBQ1YsYUFBWTtBQUFBLFVBQ1osV0FBVzNDO0FBQUFBO0FBQUFBLFFBUGI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BT3dCLEtBUjFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFVQTtBQUFBLE1BRUNZLFNBQVMsWUFDUix1QkFBQyxTQUFNLE9BQU0sU0FBUSxVQUFRLE1BQzNCO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxNQUFLO0FBQUEsVUFDTCxPQUFPTTtBQUFBQSxVQUNQLFVBQVUsQ0FBQ29CLE1BQU1uQixTQUFTbUIsRUFBRUksT0FBT0MsS0FBSztBQUFBLFVBQ3hDLGNBQWE7QUFBQSxVQUNiLFdBQVU7QUFBQSxVQUNWLGFBQVk7QUFBQSxVQUNaLFdBQVczQztBQUFBQTtBQUFBQSxRQVBiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQU93QixLQVIxQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBVUE7QUFBQSxNQUdGLHVCQUFDLFNBQU0sT0FBTSxZQUNYO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxNQUFLO0FBQUEsVUFDTCxPQUFPb0I7QUFBQUEsVUFDUCxVQUFVLENBQUNrQixNQUFNakIsWUFBWWlCLEVBQUVJLE9BQU9DLEtBQUs7QUFBQSxVQUMzQyxjQUFjL0IsU0FBUyxXQUFXLHFCQUFxQjtBQUFBLFVBQ3ZELGFBQVk7QUFBQSxVQUNaLFdBQVdaO0FBQUFBO0FBQUFBLFFBTmI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BTXdCLEtBUDFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFTQTtBQUFBLE1BRUMwQixTQUNDLHVCQUFDLE9BQUUsV0FBVSxtRUFDWDtBQUFBLCtCQUFDLGVBQVksTUFBTSxJQUFJLFdBQVUsbUJBQWtCLGVBQVcsUUFBOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE4RDtBQUFBLFFBQzdEQTtBQUFBQSxXQUZIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BR0RFLFVBQ0MsdUJBQUMsT0FBRSxXQUFVLDJEQUNYO0FBQUEsK0JBQUMsYUFBVSxNQUFNLElBQUksV0FBVSxtQkFBa0IsZUFBVyxRQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTREO0FBQUEsUUFDM0RBO0FBQUFBLFdBRkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFHRix1QkFBQyxVQUFPLE1BQUssTUFBSyxXQUFTLE1BQUMsVUFBVUosUUFBUSxDQUFDbEIsWUFBWSxTQUFTLE1BQU0sS0FBSzBCLE9BQU8sR0FDbkZSO0FBQUFBLGVBQU8sYUFBYVosU0FBUyxXQUFXLFlBQVk7QUFBQSxRQUNyRCx1QkFBQyxjQUFXLE1BQU0sSUFBSSxlQUFXLFFBQWpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaUM7QUFBQSxXQUZuQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUVDQSxTQUFTLFlBQVlOLGNBQ3BCO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxNQUFLO0FBQUEsVUFDTCxTQUFTLE1BQU0sS0FBS21DLE9BQU87QUFBQSxVQUMzQixXQUFVO0FBQUEsVUFBb0U7QUFBQTtBQUFBLFFBSGhGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQU1BO0FBQUEsU0FqR0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW1HQTtBQUFBLElBRUEsdUJBQUMsT0FBRSxXQUFVLHFFQUNWN0I7QUFBQUEsZUFBUyxXQUFXLG9CQUFvQjtBQUFBLE1BQTRCO0FBQUEsTUFDckU7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE1BQUs7QUFBQSxVQUNMLFNBQVMsTUFBTTtBQUNiQyxvQkFBUUQsU0FBUyxXQUFXLFdBQVcsUUFBUTtBQUMvQ2UscUJBQVMsSUFBSTtBQUNiRSxzQkFBVSxJQUFJO0FBQUEsVUFDaEI7QUFBQSxVQUNBLFdBQVU7QUFBQSxVQUVUakIsbUJBQVMsV0FBVyxlQUFlO0FBQUE7QUFBQSxRQVR0QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFVQTtBQUFBLFNBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWFBO0FBQUEsSUFFQSx1QkFBQyxPQUFFLFdBQVUsdUNBQXFDO0FBQUE7QUFBQSxNQUNsQztBQUFBLE1BQ2QsdUJBQUMsUUFBSyxJQUFHLFlBQVcsV0FBVSxnQ0FBOEIseUNBQTVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUtBO0FBQUEsT0E3SUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQThJQTtBQUVKO0FBQUNULEdBNU51QkYsTUFBSTtBQUFBLFVBQ1pGLFNBQ2lESCxTQUM5Q04sYUFDQUQsV0FBVztBQUFBO0FBQUEsS0FKTlk7QUE4TnhCLFNBQVMyQyxNQUFNLEVBQUVDLE9BQU9DLFVBQVVDLFNBQTJFLEdBQUc7QUFDOUcsU0FDRSx1QkFBQyxXQUFNLFdBQVUsU0FDZjtBQUFBLDJCQUFDLFVBQUssV0FBVSxrREFDYkY7QUFBQUE7QUFBQUEsTUFDQUMsWUFBWSx1QkFBQyxVQUFLLFdBQVUsNkJBQTRCLHdCQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW9EO0FBQUEsU0FGbkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdBO0FBQUEsSUFDQ0M7QUFBQUEsT0FMSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBTUE7QUFFSjtBQUFDQyxNQVZRSjtBQVlULFNBQVNLLFdBQVc7QUFBQSxFQUNsQkM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUMsTUFBTUM7QUFBQUEsRUFDTkM7QUFBQUEsRUFDQUM7QUFPRixHQUFHO0FBQ0QsU0FDRTtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0MsTUFBSztBQUFBLE1BQ0wsZ0JBQWNMO0FBQUFBLE1BQ2Q7QUFBQSxNQUNBLFdBQVdwRDtBQUFBQSxRQUNUO0FBQUEsUUFDQW9ELFNBQVMsNkJBQTZCO0FBQUEsTUFDeEM7QUFBQSxNQUVBO0FBQUEsK0JBQUMsUUFBSyxNQUFNLElBQUksV0FBV0EsU0FBUyxrQkFBa0IsY0FBYyxlQUFXLFFBQS9FO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBK0U7QUFBQSxRQUMvRSx1QkFBQyxVQUFLLFdBQVUseUNBQXlDSSxtQkFBekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUErRDtBQUFBLFFBQy9ELHVCQUFDLFVBQUssV0FBVSxnREFBZ0RDLGtCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXFFO0FBQUE7QUFBQTtBQUFBLElBWHZFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQVlBO0FBRUo7QUFBQ0MsTUE1QlFQO0FBQVUsSUFBQVEsSUFBQVQsS0FBQVE7QUFBQSxhQUFBQyxJQUFBO0FBQUEsYUFBQVQsS0FBQTtBQUFBLGFBQUFRLEtBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsIkxpbmsiLCJOYXZpZ2F0ZSIsInVzZUxvY2F0aW9uIiwidXNlTmF2aWdhdGUiLCJBcnJvd1JpZ2h0IiwiSG9tZSIsIlN0b3JlIiwiQWxlcnRDaXJjbGUiLCJNYWlsQ2hlY2siLCJ1c2VBdXRoIiwiQnV0dG9uIiwiY24iLCJ1c2VJMThuIiwiaW5wdXRDbGFzcyIsIkF1dGgiLCJpbml0aWFsIiwiX3MiLCJ0IiwiYWNjb3VudCIsImNvbmZpZ3VyZWQiLCJzaWduSW4iLCJzaWduVXAiLCJyZXNldFBhc3N3b3JkIiwibmF2aWdhdGUiLCJsb2NhdGlvbiIsIm1vZGUiLCJzZXRNb2RlIiwibmFtZSIsInNldE5hbWUiLCJlbWFpbCIsInNldEVtYWlsIiwicGhvbmUiLCJzZXRQaG9uZSIsInBhc3N3b3JkIiwic2V0UGFzc3dvcmQiLCJyb2xlIiwic2V0Um9sZSIsImJ1c3kiLCJzZXRCdXN5IiwiZXJyb3IiLCJzZXRFcnJvciIsIm5vdGljZSIsInNldE5vdGljZSIsImZyb20iLCJzdGF0ZSIsInN1Ym1pdCIsInRyaW0iLCJsZW5ndGgiLCJyZXBsYWNlIiwibmVlZHNDb25maXJtYXRpb24iLCJ1bmRlZmluZWQiLCJlIiwiRXJyb3IiLCJtZXNzYWdlIiwiZm9yZ290IiwidGFyZ2V0IiwidmFsdWUiLCJGaWVsZCIsImxhYmVsIiwib3B0aW9uYWwiLCJjaGlsZHJlbiIsIl9jMiIsIlJvbGVPcHRpb24iLCJhY3RpdmUiLCJvbkNsaWNrIiwiaWNvbiIsIkljb24iLCJ0aXRsZSIsImJvZHkiLCJfYzMiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJBdXRoLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgTGluaywgTmF2aWdhdGUsIHVzZUxvY2F0aW9uLCB1c2VOYXZpZ2F0ZSB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XG5pbXBvcnQgeyBBcnJvd1JpZ2h0LCBIb21lLCBTdG9yZSwgQWxlcnRDaXJjbGUsIE1haWxDaGVjayB9IGZyb20gXCJsdWNpZGUtcmVhY3RcIjtcbmltcG9ydCB7IHVzZUF1dGggfSBmcm9tIFwiQC9ob29rcy91c2VBdXRoXCI7XG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tIFwiQC9jb21wb25lbnRzL3VpL0J1dHRvblwiO1xuaW1wb3J0IHsgY24gfSBmcm9tIFwiQC9saWIvY25cIjtcbmltcG9ydCB7IHVzZUkxOG4gfSBmcm9tIFwiQC9pMThuXCI7XG5cbnR5cGUgTW9kZSA9IFwic2lnbmluXCIgfCBcInNpZ251cFwiO1xuXG5jb25zdCBpbnB1dENsYXNzID1cbiAgXCJoLTExIHctZnVsbCByb3VuZGVkLXhsIGJnLWl2b3J5IHB4LTMgdGV4dC1bMC45Mzc1cmVtXSB0ZXh0LWluayByaW5nLTEgcmluZy1oYWlybGluZS1zdHJvbmcgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWFxdWEtNjAwXCI7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEF1dGgoeyBpbml0aWFsID0gXCJzaWduaW5cIiB9OiB7IGluaXRpYWw/OiBNb2RlIH0pIHtcbiAgY29uc3QgeyB0IH0gPSB1c2VJMThuKCk7XG4gIGNvbnN0IHsgYWNjb3VudCwgY29uZmlndXJlZCwgc2lnbkluLCBzaWduVXAsIHJlc2V0UGFzc3dvcmQgfSA9IHVzZUF1dGgoKTtcbiAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpO1xuICBjb25zdCBsb2NhdGlvbiA9IHVzZUxvY2F0aW9uKCk7XG5cbiAgY29uc3QgW21vZGUsIHNldE1vZGVdID0gdXNlU3RhdGU8TW9kZT4oaW5pdGlhbCk7XG4gIGNvbnN0IFtuYW1lLCBzZXROYW1lXSA9IHVzZVN0YXRlKFwiXCIpO1xuICBjb25zdCBbZW1haWwsIHNldEVtYWlsXSA9IHVzZVN0YXRlKFwiXCIpO1xuICBjb25zdCBbcGhvbmUsIHNldFBob25lXSA9IHVzZVN0YXRlKFwiXCIpO1xuICBjb25zdCBbcGFzc3dvcmQsIHNldFBhc3N3b3JkXSA9IHVzZVN0YXRlKFwiXCIpO1xuICBjb25zdCBbcm9sZSwgc2V0Um9sZV0gPSB1c2VTdGF0ZTxcInJlbnRlclwiIHwgXCJvd25lclwiPihcInJlbnRlclwiKTtcblxuICBjb25zdCBbYnVzeSwgc2V0QnVzeV0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IFtub3RpY2UsIHNldE5vdGljZV0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcblxuICBjb25zdCBmcm9tID0gKGxvY2F0aW9uLnN0YXRlIGFzIHsgZnJvbT86IHN0cmluZyB9IHwgbnVsbCk/LmZyb207XG5cbiAgaWYgKGFjY291bnQpIHJldHVybiA8TmF2aWdhdGUgdG89e2Zyb20gPz8gKGFjY291bnQucm9sZSA9PT0gXCJvd25lclwiID8gXCIvcG9ydGZvbGlvXCIgOiBcIi9leHBsb3JlXCIpfSByZXBsYWNlIC8+O1xuXG4gIGNvbnN0IHN1Ym1pdCA9IGFzeW5jICgpID0+IHtcbiAgICBzZXRFcnJvcihudWxsKTtcbiAgICBzZXROb3RpY2UobnVsbCk7XG5cbiAgICBpZiAoIWVtYWlsLnRyaW0oKSB8fCBwYXNzd29yZC5sZW5ndGggPCA2KSB7XG4gICAgICBzZXRFcnJvcihcIkVudGVyIHlvdXIgZW1haWwgYW5kIGEgcGFzc3dvcmQgb2YgYXQgbGVhc3QgNiBjaGFyYWN0ZXJzLlwiKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgaWYgKG1vZGUgPT09IFwic2lnbnVwXCIgJiYgbmFtZS50cmltKCkubGVuZ3RoIDwgMikge1xuICAgICAgc2V0RXJyb3IoXCJUZWxsIHVzIHlvdXIgbmFtZSBzbyBvd25lcnMga25vdyB3aG8ncyBhc2tpbmcuXCIpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIHNldEJ1c3kodHJ1ZSk7XG4gICAgdHJ5IHtcbiAgICAgIGlmIChtb2RlID09PSBcInNpZ25pblwiKSB7XG4gICAgICAgIGF3YWl0IHNpZ25JbihlbWFpbC50cmltKCksIHBhc3N3b3JkKTtcbiAgICAgICAgbmF2aWdhdGUoZnJvbSA/PyBcIi9leHBsb3JlXCIsIHsgcmVwbGFjZTogdHJ1ZSB9KTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGNvbnN0IHsgbmVlZHNDb25maXJtYXRpb24gfSA9IGF3YWl0IHNpZ25VcCh7XG4gICAgICAgICAgbmFtZTogbmFtZS50cmltKCksXG4gICAgICAgICAgZW1haWw6IGVtYWlsLnRyaW0oKSxcbiAgICAgICAgICBwYXNzd29yZCxcbiAgICAgICAgICBwaG9uZTogcGhvbmUudHJpbSgpIHx8IHVuZGVmaW5lZCxcbiAgICAgICAgICByb2xlLFxuICAgICAgICB9KTtcblxuICAgICAgICBpZiAobmVlZHNDb25maXJtYXRpb24pIHtcbiAgICAgICAgICBzZXROb3RpY2UoXCJDaGVjayB5b3VyIGVtYWlsIGZvciBhIGNvbmZpcm1hdGlvbiBsaW5rLCB0aGVuIHNpZ24gaW4uXCIpO1xuICAgICAgICAgIHNldE1vZGUoXCJzaWduaW5cIik7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgbmF2aWdhdGUocm9sZSA9PT0gXCJvd25lclwiID8gXCIvcG9ydGZvbGlvXCIgOiBcIi9leHBsb3JlXCIsIHsgcmVwbGFjZTogdHJ1ZSB9KTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIHNldEVycm9yKGUgaW5zdGFuY2VvZiBFcnJvciA/IGUubWVzc2FnZSA6IFwiU29tZXRoaW5nIHdlbnQgd3JvbmcuIFRyeSBhZ2Fpbi5cIik7XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldEJ1c3koZmFsc2UpO1xuICAgIH1cbiAgfTtcblxuICBjb25zdCBmb3Jnb3QgPSBhc3luYyAoKSA9PiB7XG4gICAgaWYgKCFlbWFpbC50cmltKCkpIHtcbiAgICAgIHNldEVycm9yKFwiRW50ZXIgeW91ciBlbWFpbCBmaXJzdCwgdGhlbiB0YXAgcmVzZXQuXCIpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICB0cnkge1xuICAgICAgYXdhaXQgcmVzZXRQYXNzd29yZChlbWFpbC50cmltKCkpO1xuICAgICAgc2V0Tm90aWNlKFwiSWYgdGhhdCBlbWFpbCBoYXMgYW4gYWNjb3VudCwgYSByZXNldCBsaW5rIGlzIG9uIGl0cyB3YXkuXCIpO1xuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIHNldEVycm9yKGUgaW5zdGFuY2VvZiBFcnJvciA/IGUubWVzc2FnZSA6IFwiQ291bGQgbm90IHNlbmQgdGhlIHJlc2V0IGxpbmsuXCIpO1xuICAgIH1cbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiY29udGFpbmVyLXBhZ2UgbWF4LXctbWQgcHktMTIgbWQ6cHktMTZcIj5cbiAgICAgIDxoMSBjbGFzc05hbWU9XCJmb250LWRpc3BsYXkgdGV4dC0zeGwgZm9udC1leHRyYWJvbGQgdGV4dC1pbmsgc206dGV4dC00eGxcIj5cbiAgICAgICAge21vZGUgPT09IFwic2lnbmluXCIgPyBcIldlbGNvbWUgYmFjay5cIiA6IFwiQ3JlYXRlIHlvdXIgYWNjb3VudC5cIn1cbiAgICAgIDwvaDE+XG4gICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gbGVhZGluZy1yZWxheGVkIHRleHQtbXV0ZWRcIj5cbiAgICAgICAge21vZGUgPT09IFwic2lnbmluXCJcbiAgICAgICAgICA/IFwiU2lnbiBpbiB0byByZWFjaCB5b3VyIHNhdmVkIHNwYWNlcywgaW5xdWlyaWVzIGFuZCBsaXN0aW5ncy5cIlxuICAgICAgICAgIDogXCJPbmUgYWNjb3VudCwgd2hpY2hldmVyIHNpZGUgb2YgSGFiaXRvIHlvdSdyZSBvbi5cIn1cbiAgICAgIDwvcD5cblxuICAgICAgeyFjb25maWd1cmVkICYmIChcbiAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtNSBmbGV4IGdhcC0yLjUgcm91bmRlZC1jYXJkIGJnLXdhcm4tMTAwIHAtNCB0ZXh0LXNtIGxlYWRpbmctcmVsYXhlZCB0ZXh0LXdhcm4tNzAwXCI+XG4gICAgICAgICAgPEFsZXJ0Q2lyY2xlIHNpemU9ezE2fSBjbGFzc05hbWU9XCJtdC0wLjUgc2hyaW5rLTBcIiBhcmlhLWhpZGRlbiAvPlxuICAgICAgICAgIDxzcGFuPlxuICAgICAgICAgICAgSGFiaXRvIGlzbid0IGNvbm5lY3RlZCB0byBhIGRhdGFiYXNlIGluIHRoaXMgYnVpbGQsIHNvIGFjY291bnRzIGNhbid0IGJlIGNyZWF0ZWQuIEJyb3dzaW5nXG4gICAgICAgICAgICBzdGlsbCB3b3JrcyBhbmQgeW91ciBhY3Rpdml0eSBpcyBrZXB0IGluIHRoaXMgYnJvd3Nlci5cbiAgICAgICAgICA8L3NwYW4+XG4gICAgICAgIDwvcD5cbiAgICAgICl9XG5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNyBzcGFjZS15LTRcIj5cbiAgICAgICAge21vZGUgPT09IFwic2lnbnVwXCIgJiYgKFxuICAgICAgICAgIDw+XG4gICAgICAgICAgICA8RmllbGQgbGFiZWw9XCJZb3VyIG5hbWVcIj5cbiAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgdmFsdWU9e25hbWV9XG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXROYW1lKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICBhdXRvQ29tcGxldGU9XCJuYW1lXCJcbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkZhcmhhbmEgQWt0ZXJcIlxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17aW5wdXRDbGFzc31cbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDwvRmllbGQ+XG5cbiAgICAgICAgICAgIDxGaWVsZCBsYWJlbD1cIldoYXQgYnJpbmdzIHlvdSBoZXJlP1wiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICA8Um9sZU9wdGlvblxuICAgICAgICAgICAgICAgICAgYWN0aXZlPXtyb2xlID09PSBcInJlbnRlclwifVxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0Um9sZShcInJlbnRlclwiKX1cbiAgICAgICAgICAgICAgICAgIGljb249e0hvbWV9XG4gICAgICAgICAgICAgICAgICB0aXRsZT17dChcImF1dGgubmVlZFNwYWNlXCIpfVxuICAgICAgICAgICAgICAgICAgYm9keT1cIlNlYXJjaCwgc2F2ZSBhbmQgZW5xdWlyZVwiXG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICA8Um9sZU9wdGlvblxuICAgICAgICAgICAgICAgICAgYWN0aXZlPXtyb2xlID09PSBcIm93bmVyXCJ9XG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRSb2xlKFwib3duZXJcIil9XG4gICAgICAgICAgICAgICAgICBpY29uPXtTdG9yZX1cbiAgICAgICAgICAgICAgICAgIHRpdGxlPXt0KFwiYXV0aC5oYXZlU3BhY2VcIil9XG4gICAgICAgICAgICAgICAgICBib2R5PVwiTGlzdCBhbmQgbWFuYWdlIGl0XCJcbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvRmllbGQ+XG4gICAgICAgICAgPC8+XG4gICAgICAgICl9XG5cbiAgICAgICAgPEZpZWxkIGxhYmVsPVwiRW1haWxcIj5cbiAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgIHR5cGU9XCJlbWFpbFwiXG4gICAgICAgICAgICB2YWx1ZT17ZW1haWx9XG4gICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEVtYWlsKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgIGF1dG9Db21wbGV0ZT1cImVtYWlsXCJcbiAgICAgICAgICAgIGlucHV0TW9kZT1cImVtYWlsXCJcbiAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwieW91QGV4YW1wbGUuY29tXCJcbiAgICAgICAgICAgIGNsYXNzTmFtZT17aW5wdXRDbGFzc31cbiAgICAgICAgICAvPlxuICAgICAgICA8L0ZpZWxkPlxuXG4gICAgICAgIHttb2RlID09PSBcInNpZ251cFwiICYmIChcbiAgICAgICAgICA8RmllbGQgbGFiZWw9XCJQaG9uZVwiIG9wdGlvbmFsPlxuICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgIHR5cGU9XCJ0ZWxcIlxuICAgICAgICAgICAgICB2YWx1ZT17cGhvbmV9XG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0UGhvbmUoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICBhdXRvQ29tcGxldGU9XCJ0ZWxcIlxuICAgICAgICAgICAgICBpbnB1dE1vZGU9XCJ0ZWxcIlxuICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIjAxWFhYWFhYWFhYXCJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPXtpbnB1dENsYXNzfVxuICAgICAgICAgICAgLz5cbiAgICAgICAgICA8L0ZpZWxkPlxuICAgICAgICApfVxuXG4gICAgICAgIDxGaWVsZCBsYWJlbD1cIlBhc3N3b3JkXCI+XG4gICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICB0eXBlPVwicGFzc3dvcmRcIlxuICAgICAgICAgICAgdmFsdWU9e3Bhc3N3b3JkfVxuICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRQYXNzd29yZChlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICBhdXRvQ29tcGxldGU9e21vZGUgPT09IFwic2lnbmluXCIgPyBcImN1cnJlbnQtcGFzc3dvcmRcIiA6IFwibmV3LXBhc3N3b3JkXCJ9XG4gICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkF0IGxlYXN0IDYgY2hhcmFjdGVyc1wiXG4gICAgICAgICAgICBjbGFzc05hbWU9e2lucHV0Q2xhc3N9XG4gICAgICAgICAgLz5cbiAgICAgICAgPC9GaWVsZD5cblxuICAgICAgICB7ZXJyb3IgJiYgKFxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImZsZXggZ2FwLTIgcm91bmRlZC14bCBiZy1kYW5nZXItMTAwIHAtMyB0ZXh0LXNtIHRleHQtZGFuZ2VyLTYwMFwiPlxuICAgICAgICAgICAgPEFsZXJ0Q2lyY2xlIHNpemU9ezE1fSBjbGFzc05hbWU9XCJtdC0wLjUgc2hyaW5rLTBcIiBhcmlhLWhpZGRlbiAvPlxuICAgICAgICAgICAge2Vycm9yfVxuICAgICAgICAgIDwvcD5cbiAgICAgICAgKX1cblxuICAgICAgICB7bm90aWNlICYmIChcbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJmbGV4IGdhcC0yIHJvdW5kZWQteGwgYmctb2stMTAwIHAtMyB0ZXh0LXNtIHRleHQtb2stNjAwXCI+XG4gICAgICAgICAgICA8TWFpbENoZWNrIHNpemU9ezE1fSBjbGFzc05hbWU9XCJtdC0wLjUgc2hyaW5rLTBcIiBhcmlhLWhpZGRlbiAvPlxuICAgICAgICAgICAge25vdGljZX1cbiAgICAgICAgICA8L3A+XG4gICAgICAgICl9XG5cbiAgICAgICAgPEJ1dHRvbiBzaXplPVwibGdcIiBmdWxsV2lkdGggZGlzYWJsZWQ9e2J1c3kgfHwgIWNvbmZpZ3VyZWR9IG9uQ2xpY2s9eygpID0+IHZvaWQgc3VibWl0KCl9PlxuICAgICAgICAgIHtidXN5ID8gXCJXb3JraW5n4oCmXCIgOiBtb2RlID09PSBcInNpZ25pblwiID8gXCJTaWduIGluXCIgOiBcIkNyZWF0ZSBhY2NvdW50XCJ9XG4gICAgICAgICAgPEFycm93UmlnaHQgc2l6ZT17MTd9IGFyaWEtaGlkZGVuIC8+XG4gICAgICAgIDwvQnV0dG9uPlxuXG4gICAgICAgIHttb2RlID09PSBcInNpZ25pblwiICYmIGNvbmZpZ3VyZWQgJiYgKFxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gdm9pZCBmb3Jnb3QoKX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCB0ZXh0LWNlbnRlciB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1tdXRlZCBob3Zlcjp0ZXh0LWlua1wiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgRm9yZ290IHlvdXIgcGFzc3dvcmQ/XG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICl9XG4gICAgICA8L2Rpdj5cblxuICAgICAgPHAgY2xhc3NOYW1lPVwibXQtOCBib3JkZXItdCBib3JkZXItaGFpcmxpbmUgcHQtNSB0ZXh0LWNlbnRlciB0ZXh0LXNtIHRleHQtbXV0ZWRcIj5cbiAgICAgICAge21vZGUgPT09IFwic2lnbmluXCIgPyBcIk5vIGFjY291bnQgeWV0P1wiIDogXCJBbHJlYWR5IGhhdmUgYW4gYWNjb3VudD9cIn17XCIgXCJ9XG4gICAgICAgIDxidXR0b25cbiAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICBzZXRNb2RlKG1vZGUgPT09IFwic2lnbmluXCIgPyBcInNpZ251cFwiIDogXCJzaWduaW5cIik7XG4gICAgICAgICAgICBzZXRFcnJvcihudWxsKTtcbiAgICAgICAgICAgIHNldE5vdGljZShudWxsKTtcbiAgICAgICAgICB9fVxuICAgICAgICAgIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1hcXVhLTcwMCBob3Zlcjp1bmRlcmxpbmVcIlxuICAgICAgICA+XG4gICAgICAgICAge21vZGUgPT09IFwic2lnbmluXCIgPyBcIkNyZWF0ZSBvbmVcIiA6IFwiU2lnbiBpblwifVxuICAgICAgICA8L2J1dHRvbj5cbiAgICAgIDwvcD5cblxuICAgICAgPHAgY2xhc3NOYW1lPVwibXQtNCB0ZXh0LWNlbnRlciB0ZXh0LXhzIHRleHQtbXV0ZWRcIj5cbiAgICAgICAgSnVzdCBsb29raW5nP3tcIiBcIn1cbiAgICAgICAgPExpbmsgdG89XCIvZXhwbG9yZVwiIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgaG92ZXI6dGV4dC1pbmtcIj5cbiAgICAgICAgICBCcm93c2Ugd2l0aG91dCBhbiBhY2NvdW50XG4gICAgICAgIDwvTGluaz5cbiAgICAgIDwvcD5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cblxuZnVuY3Rpb24gRmllbGQoeyBsYWJlbCwgb3B0aW9uYWwsIGNoaWxkcmVuIH06IHsgbGFiZWw6IHN0cmluZzsgb3B0aW9uYWw/OiBib29sZWFuOyBjaGlsZHJlbjogUmVhY3QuUmVhY3ROb2RlIH0pIHtcbiAgcmV0dXJuIChcbiAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2tcIj5cbiAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1iLTEuNSBibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtaW5rLXNvZnRcIj5cbiAgICAgICAge2xhYmVsfVxuICAgICAgICB7b3B0aW9uYWwgJiYgPHNwYW4gY2xhc3NOYW1lPVwibWwtMS41IHRleHQteHMgdGV4dC1tdXRlZFwiPm9wdGlvbmFsPC9zcGFuPn1cbiAgICAgIDwvc3Bhbj5cbiAgICAgIHtjaGlsZHJlbn1cbiAgICA8L2xhYmVsPlxuICApO1xufVxuXG5mdW5jdGlvbiBSb2xlT3B0aW9uKHtcbiAgYWN0aXZlLFxuICBvbkNsaWNrLFxuICBpY29uOiBJY29uLFxuICB0aXRsZSxcbiAgYm9keSxcbn06IHtcbiAgYWN0aXZlOiBib29sZWFuO1xuICBvbkNsaWNrOiAoKSA9PiB2b2lkO1xuICBpY29uOiB0eXBlb2YgSG9tZTtcbiAgdGl0bGU6IHN0cmluZztcbiAgYm9keTogc3RyaW5nO1xufSkge1xuICByZXR1cm4gKFxuICAgIDxidXR0b25cbiAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgYXJpYS1wcmVzc2VkPXthY3RpdmV9XG4gICAgICBvbkNsaWNrPXtvbkNsaWNrfVxuICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgXCJyb3VuZGVkLTJ4bCBwLTMuNSB0ZXh0LWxlZnQgcmluZy0xIHRyYW5zaXRpb24tY29sb3JzXCIsXG4gICAgICAgIGFjdGl2ZSA/IFwiYmctYXF1YS01MCByaW5nLWFxdWEtNjAwXCIgOiBcImJnLWl2b3J5IHJpbmctaGFpcmxpbmUgaG92ZXI6cmluZy1oYWlybGluZS1zdHJvbmdcIixcbiAgICAgICl9XG4gICAgPlxuICAgICAgPEljb24gc2l6ZT17MTh9IGNsYXNzTmFtZT17YWN0aXZlID8gXCJ0ZXh0LWFxdWEtNzAwXCIgOiBcInRleHQtbXV0ZWRcIn0gYXJpYS1oaWRkZW4gLz5cbiAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm10LTIgYmxvY2sgdGV4dC1zbSBmb250LWJvbGQgdGV4dC1pbmtcIj57dGl0bGV9PC9zcGFuPlxuICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibXQtMC41IGJsb2NrIHRleHQteHMgbGVhZGluZy1zbnVnIHRleHQtbXV0ZWRcIj57Ym9keX08L3NwYW4+XG4gICAgPC9idXR0b24+XG4gICk7XG59XG4iXSwiZmlsZSI6IkQ6L0kySSBQcm9qZWN0IC0gSGFiaXRvL0FwcCBGb2xkZXIvaGFiaXRvL3NyYy9wYWdlcy9BdXRoLnRzeCJ9