import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/space/PinPicker.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=9ceb86a3"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("D:/I2I Project - Habito/App Folder/habito/src/components/space/PinPicker.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9ceb86a3"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useMemo = __vite__cjsImport3_react["useMemo"]; const useRef = __vite__cjsImport3_react["useRef"]; const useState = __vite__cjsImport3_react["useState"];
import { MapContainer, TileLayer, Marker, useMap } from "/node_modules/.vite/deps/react-leaflet.js?v=9ceb86a3";
import __vite__cjsImport5_leaflet from "/node_modules/.vite/deps/leaflet.js?v=9ceb86a3"; const L = __vite__cjsImport5_leaflet.__esModule ? __vite__cjsImport5_leaflet.default : __vite__cjsImport5_leaflet;
import "/node_modules/leaflet/dist/leaflet.css";
import { MapPin } from "/node_modules/.vite/deps/lucide-react.js?v=9ceb86a3";
import { useI18n } from "/src/i18n/index.tsx";
import { Button } from "/src/components/ui/Button.tsx";
import { cn } from "/src/lib/cn.ts";
function Recentre({ position }) {
  _s();
  const map = useMap();
  const key = position.join(",");
  useEffect(() => {
    map.setView(position, map.getZoom() < 14 ? 15 : map.getZoom(), { animate: true });
  }, [key]);
  return null;
}
_s(Recentre, "IoceErwr5KVGS9kN4RQ1bOkYMAg=", false, function() {
  return [useMap];
});
_c = Recentre;
export function PinPicker({
  centre,
  value,
  onChange
}) {
  _s2();
  const { t } = useI18n();
  const markerRef = useRef(null);
  const [position, setPosition] = useState(value ?? centre);
  useEffect(() => {
    if (!value) setPosition(centre);
  }, [centre, value]);
  const icon = useMemo(
    () => L.divIcon({
      className: "habito-pin",
      html: `<span class="block size-5 rounded-full bg-aqua-600 ring-4 ring-white shadow-[0_3px_10px_-2px_rgb(16,24,40,0.45)]"></span>`,
      iconSize: [20, 20],
      iconAnchor: [10, 10]
    }),
    []
  );
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("div", { className: "overflow-hidden rounded-card ring-1 ring-hairline", children: /* @__PURE__ */ jsxDEV(MapContainer, { center: position, zoom: 15, className: "h-64 w-full sm:h-72", children: [
      /* @__PURE__ */ jsxDEV(
        TileLayer,
        {
          attribution: '© <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
          url: "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
          maxZoom: 19
        },
        void 0,
        false,
        {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/PinPicker.tsx",
          lineNumber: 85,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(Recentre, { position }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/PinPicker.tsx",
        lineNumber: 90,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(
        Marker,
        {
          draggable: true,
          ref: markerRef,
          position,
          icon,
          eventHandlers: {
            dragend: () => {
              const next = markerRef.current?.getLatLng();
              if (!next) return;
              const point = [next.lat, next.lng];
              setPosition(point);
              onChange(point);
            }
          }
        },
        void 0,
        false,
        {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/PinPicker.tsx",
          lineNumber: 91,
          columnNumber: 11
        },
        this
      )
    ] }, void 0, true, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/PinPicker.tsx",
      lineNumber: 84,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/PinPicker.tsx",
      lineNumber: 83,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "mt-3 flex flex-wrap items-center gap-3", children: [
      /* @__PURE__ */ jsxDEV(
        "p",
        {
          className: cn(
            "inline-flex items-center gap-1.5 text-sm",
            value ? "font-medium text-ok-600" : "text-muted"
          ),
          children: [
            /* @__PURE__ */ jsxDEV(MapPin, { size: 14, "aria-hidden": true }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/PinPicker.tsx",
              lineNumber: 116,
              columnNumber: 11
            }, this),
            value ? t("map.pinSet") : t("map.useArea")
          ]
        },
        void 0,
        true,
        {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/PinPicker.tsx",
          lineNumber: 110,
          columnNumber: 9
        },
        this
      ),
      value && /* @__PURE__ */ jsxDEV(Button, { size: "sm", variant: "ghost", onClick: () => onChange(null), children: t("map.pinSkip") }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/PinPicker.tsx",
        lineNumber: 121,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/PinPicker.tsx",
      lineNumber: 109,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/PinPicker.tsx",
    lineNumber: 82,
    columnNumber: 5
  }, this);
}
_s2(PinPicker, "Rh8/dYxsv4AiUbuXSfGoEoq1TDE=", false, function() {
  return [useI18n];
});
_c2 = PinPicker;
var _c, _c2;
$RefreshReg$(_c, "Recentre");
$RefreshReg$(_c2, "PinPicker");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/I2I Project - Habito/App Folder/habito/src/components/space/PinPicker.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/I2I Project - Habito/App Folder/habito/src/components/space/PinPicker.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUVVOzs7Ozs7Ozs7Ozs7Ozs7OztBQWpFVixTQUFTQSxXQUFXQyxTQUFTQyxRQUFRQyxnQkFBZ0I7QUFDckQsU0FBU0MsY0FBY0MsV0FBV0MsUUFBUUMsY0FBYztBQUN4RCxPQUFPQyxPQUFPO0FBQ2QsT0FBTztBQUNQLFNBQVNDLGNBQWM7QUFDdkIsU0FBU0MsZUFBZTtBQUN4QixTQUFTQyxjQUFjO0FBQ3ZCLFNBQVNDLFVBQVU7QUFZbkIsU0FBU0MsU0FBUyxFQUFFQyxTQUF5QyxHQUFHO0FBQUFDLEtBQUE7QUFDOUQsUUFBTUMsTUFBTVQsT0FBTztBQUNuQixRQUFNVSxNQUFNSCxTQUFTSSxLQUFLLEdBQUc7QUFFN0JsQixZQUFVLE1BQU07QUFDZGdCLFFBQUlHLFFBQVFMLFVBQVVFLElBQUlJLFFBQVEsSUFBSSxLQUFLLEtBQUtKLElBQUlJLFFBQVEsR0FBRyxFQUFFQyxTQUFTLEtBQUssQ0FBQztBQUFBLEVBR2xGLEdBQUcsQ0FBQ0osR0FBRyxDQUFDO0FBRVIsU0FBTztBQUNUO0FBQUNGLEdBWFFGLFVBQVE7QUFBQSxVQUNITixNQUFNO0FBQUE7QUFBQSxLQURYTTtBQWFGLGdCQUFTUyxVQUFVO0FBQUEsRUFDeEJDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBTUYsR0FBRztBQUFBQyxNQUFBO0FBQ0QsUUFBTSxFQUFFQyxFQUFFLElBQUlqQixRQUFRO0FBQ3RCLFFBQU1rQixZQUFZMUIsT0FBaUIsSUFBSTtBQUN2QyxRQUFNLENBQUNZLFVBQVVlLFdBQVcsSUFBSTFCLFNBQTJCcUIsU0FBU0QsTUFBTTtBQUUxRXZCLFlBQVUsTUFBTTtBQUNkLFFBQUksQ0FBQ3dCLE1BQU9LLGFBQVlOLE1BQU07QUFBQSxFQUNoQyxHQUFHLENBQUNBLFFBQVFDLEtBQUssQ0FBQztBQUVsQixRQUFNTSxPQUFPN0I7QUFBQUEsSUFDWCxNQUNFTyxFQUFFdUIsUUFBUTtBQUFBLE1BQ1JDLFdBQVc7QUFBQSxNQUNYQyxNQUFNO0FBQUEsTUFDTkMsVUFBVSxDQUFDLElBQUksRUFBRTtBQUFBLE1BQ2pCQyxZQUFZLENBQUMsSUFBSSxFQUFFO0FBQUEsSUFDckIsQ0FBQztBQUFBLElBQ0g7QUFBQSxFQUNGO0FBRUEsU0FDRSx1QkFBQyxTQUNDO0FBQUEsMkJBQUMsU0FBSSxXQUFVLHFEQUNiLGlDQUFDLGdCQUFhLFFBQVFyQixVQUFVLE1BQU0sSUFBSSxXQUFVLHVCQUNsRDtBQUFBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxhQUFZO0FBQUEsVUFDWixLQUFJO0FBQUEsVUFDSixTQUFTO0FBQUE7QUFBQSxRQUhYO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUdjO0FBQUEsTUFFZCx1QkFBQyxZQUFTLFlBQVY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE2QjtBQUFBLE1BQzdCO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQztBQUFBLFVBQ0EsS0FBS2M7QUFBQUEsVUFDTDtBQUFBLFVBQ0E7QUFBQSxVQUNBLGVBQWU7QUFBQSxZQUNiUSxTQUFTQSxNQUFNO0FBQ2Isb0JBQU1DLE9BQU9ULFVBQVVVLFNBQVNDLFVBQVU7QUFDMUMsa0JBQUksQ0FBQ0YsS0FBTTtBQUNYLG9CQUFNRyxRQUEwQixDQUFDSCxLQUFLSSxLQUFLSixLQUFLSyxHQUFHO0FBQ25EYiwwQkFBWVcsS0FBSztBQUNqQmYsdUJBQVNlLEtBQUs7QUFBQSxZQUNoQjtBQUFBLFVBQ0Y7QUFBQTtBQUFBLFFBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BYUk7QUFBQSxTQXBCTjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBc0JBLEtBdkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F3QkE7QUFBQSxJQUVBLHVCQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxXQUFXNUI7QUFBQUEsWUFDVDtBQUFBLFlBQ0FZLFFBQVEsNEJBQTRCO0FBQUEsVUFDdEM7QUFBQSxVQUVBO0FBQUEsbUNBQUMsVUFBTyxNQUFNLElBQUksZUFBVyxRQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE2QjtBQUFBLFlBQzVCQSxRQUFRRyxFQUFFLFlBQVksSUFBSUEsRUFBRSxhQUFhO0FBQUE7QUFBQTtBQUFBLFFBUDVDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQVFBO0FBQUEsTUFFQ0gsU0FDQyx1QkFBQyxVQUFPLE1BQUssTUFBSyxTQUFRLFNBQVEsU0FBUyxNQUFNQyxTQUFTLElBQUksR0FDM0RFLFlBQUUsYUFBYSxLQURsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxTQWRKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FnQkE7QUFBQSxPQTNDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBNENBO0FBRUo7QUFBQ0QsSUE1RWVKLFdBQVM7QUFBQSxVQVVUWixPQUFPO0FBQUE7QUFBQSxNQVZQWTtBQUFTLElBQUFxQixJQUFBQztBQUFBLGFBQUFELElBQUE7QUFBQSxhQUFBQyxLQUFBIiwibmFtZXMiOlsidXNlRWZmZWN0IiwidXNlTWVtbyIsInVzZVJlZiIsInVzZVN0YXRlIiwiTWFwQ29udGFpbmVyIiwiVGlsZUxheWVyIiwiTWFya2VyIiwidXNlTWFwIiwiTCIsIk1hcFBpbiIsInVzZUkxOG4iLCJCdXR0b24iLCJjbiIsIlJlY2VudHJlIiwicG9zaXRpb24iLCJfcyIsIm1hcCIsImtleSIsImpvaW4iLCJzZXRWaWV3IiwiZ2V0Wm9vbSIsImFuaW1hdGUiLCJQaW5QaWNrZXIiLCJjZW50cmUiLCJ2YWx1ZSIsIm9uQ2hhbmdlIiwiX3MyIiwidCIsIm1hcmtlclJlZiIsInNldFBvc2l0aW9uIiwiaWNvbiIsImRpdkljb24iLCJjbGFzc05hbWUiLCJodG1sIiwiaWNvblNpemUiLCJpY29uQW5jaG9yIiwiZHJhZ2VuZCIsIm5leHQiLCJjdXJyZW50IiwiZ2V0TGF0TG5nIiwicG9pbnQiLCJsYXQiLCJsbmciLCJfYyIsIl9jMiJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJQaW5QaWNrZXIudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUVmZmVjdCwgdXNlTWVtbywgdXNlUmVmLCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgTWFwQ29udGFpbmVyLCBUaWxlTGF5ZXIsIE1hcmtlciwgdXNlTWFwIH0gZnJvbSBcInJlYWN0LWxlYWZsZXRcIjtcbmltcG9ydCBMIGZyb20gXCJsZWFmbGV0XCI7XG5pbXBvcnQgXCJsZWFmbGV0L2Rpc3QvbGVhZmxldC5jc3NcIjtcbmltcG9ydCB7IE1hcFBpbiB9IGZyb20gXCJsdWNpZGUtcmVhY3RcIjtcbmltcG9ydCB7IHVzZUkxOG4gfSBmcm9tIFwiQC9pMThuXCI7XG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tIFwiQC9jb21wb25lbnRzL3VpL0J1dHRvblwiO1xuaW1wb3J0IHsgY24gfSBmcm9tIFwiQC9saWIvY25cIjtcblxuLyoqXG4gKiBXaGVyZSB0aGUgcHJvcGVydHkgYWN0dWFsbHkgaXMuXG4gKlxuICogRHJhZ2dpbmcgYSBtYXJrZXIgYmVhdHMgcGFyc2luZyBhbiBhZGRyZXNzIGhlcmU6IHBsb3QgbnVtYmVyaW5nIGluIERoYWthIGlzXG4gKiBpbmNvbnNpc3RlbnQsIHRoZSBzYW1lIHJvYWQgbmFtZSByZWN1cnMgYWNyb3NzIHRoYW5hcywgYW5kIGFuIG93bmVyIGtub3dzXG4gKiB0aGVpciBvd24gZ2F0ZS4gRml2ZSBzZWNvbmRzIG9mIGRyYWdnaW5nIGlzIGNvcnJlY3QgYnkgY29uc3RydWN0aW9uLlxuICpcbiAqIFNraXBwaW5nIGlzIGFsbG93ZWQsIGFuZCB0aGUgbGlzdGluZyB0aGVuIHNheXMgXCJhcHByb3hpbWF0ZVwiIG9uIHRoZSBtYXBcbiAqIHJhdGhlciB0aGFuIHByZXRlbmRpbmcgdG8gYSBwcmVjaXNpb24gaXQgZG9lc24ndCBoYXZlLlxuICovXG5mdW5jdGlvbiBSZWNlbnRyZSh7IHBvc2l0aW9uIH06IHsgcG9zaXRpb246IFtudW1iZXIsIG51bWJlcl0gfSkge1xuICBjb25zdCBtYXAgPSB1c2VNYXAoKTtcbiAgY29uc3Qga2V5ID0gcG9zaXRpb24uam9pbihcIixcIik7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBtYXAuc2V0Vmlldyhwb3NpdGlvbiwgbWFwLmdldFpvb20oKSA8IDE0ID8gMTUgOiBtYXAuZ2V0Wm9vbSgpLCB7IGFuaW1hdGU6IHRydWUgfSk7XG4gICAgLy8gT25seSB3aGVuIHRoZSBhcmVhIGNoYW5nZXMgdW5kZXJuZWF0aCwgbm90IG9uIGV2ZXJ5IGRyYWcuXG4gICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIHJlYWN0LWhvb2tzL2V4aGF1c3RpdmUtZGVwc1xuICB9LCBba2V5XSk7XG5cbiAgcmV0dXJuIG51bGw7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBQaW5QaWNrZXIoe1xuICBjZW50cmUsXG4gIHZhbHVlLFxuICBvbkNoYW5nZSxcbn06IHtcbiAgLyoqIFRoZSBhcmVhIGNlbnRyZSwgdXNlZCB1bnRpbCB0aGUgb3duZXIgbW92ZXMgdGhlIG1hcmtlci4gKi9cbiAgY2VudHJlOiBbbnVtYmVyLCBudW1iZXJdO1xuICB2YWx1ZTogW251bWJlciwgbnVtYmVyXSB8IG51bGw7XG4gIG9uQ2hhbmdlOiAocG9pbnQ6IFtudW1iZXIsIG51bWJlcl0gfCBudWxsKSA9PiB2b2lkO1xufSkge1xuICBjb25zdCB7IHQgfSA9IHVzZUkxOG4oKTtcbiAgY29uc3QgbWFya2VyUmVmID0gdXNlUmVmPEwuTWFya2VyPihudWxsKTtcbiAgY29uc3QgW3Bvc2l0aW9uLCBzZXRQb3NpdGlvbl0gPSB1c2VTdGF0ZTxbbnVtYmVyLCBudW1iZXJdPih2YWx1ZSA/PyBjZW50cmUpO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKCF2YWx1ZSkgc2V0UG9zaXRpb24oY2VudHJlKTtcbiAgfSwgW2NlbnRyZSwgdmFsdWVdKTtcblxuICBjb25zdCBpY29uID0gdXNlTWVtbyhcbiAgICAoKSA9PlxuICAgICAgTC5kaXZJY29uKHtcbiAgICAgICAgY2xhc3NOYW1lOiBcImhhYml0by1waW5cIixcbiAgICAgICAgaHRtbDogYDxzcGFuIGNsYXNzPVwiYmxvY2sgc2l6ZS01IHJvdW5kZWQtZnVsbCBiZy1hcXVhLTYwMCByaW5nLTQgcmluZy13aGl0ZSBzaGFkb3ctWzBfM3B4XzEwcHhfLTJweF9yZ2IoMTYsMjQsNDAsMC40NSldXCI+PC9zcGFuPmAsXG4gICAgICAgIGljb25TaXplOiBbMjAsIDIwXSxcbiAgICAgICAgaWNvbkFuY2hvcjogWzEwLCAxMF0sXG4gICAgICB9KSxcbiAgICBbXSxcbiAgKTtcblxuICByZXR1cm4gKFxuICAgIDxkaXY+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIm92ZXJmbG93LWhpZGRlbiByb3VuZGVkLWNhcmQgcmluZy0xIHJpbmctaGFpcmxpbmVcIj5cbiAgICAgICAgPE1hcENvbnRhaW5lciBjZW50ZXI9e3Bvc2l0aW9ufSB6b29tPXsxNX0gY2xhc3NOYW1lPVwiaC02NCB3LWZ1bGwgc206aC03MlwiPlxuICAgICAgICAgIDxUaWxlTGF5ZXJcbiAgICAgICAgICAgIGF0dHJpYnV0aW9uPScmY29weTsgPGEgaHJlZj1cImh0dHBzOi8vd3d3Lm9wZW5zdHJlZXRtYXAub3JnL2NvcHlyaWdodFwiPk9wZW5TdHJlZXRNYXA8L2E+IGNvbnRyaWJ1dG9ycydcbiAgICAgICAgICAgIHVybD1cImh0dHBzOi8ve3N9LnRpbGUub3BlbnN0cmVldG1hcC5vcmcve3p9L3t4fS97eX0ucG5nXCJcbiAgICAgICAgICAgIG1heFpvb209ezE5fVxuICAgICAgICAgIC8+XG4gICAgICAgICAgPFJlY2VudHJlIHBvc2l0aW9uPXtwb3NpdGlvbn0gLz5cbiAgICAgICAgICA8TWFya2VyXG4gICAgICAgICAgICBkcmFnZ2FibGVcbiAgICAgICAgICAgIHJlZj17bWFya2VyUmVmfVxuICAgICAgICAgICAgcG9zaXRpb249e3Bvc2l0aW9ufVxuICAgICAgICAgICAgaWNvbj17aWNvbn1cbiAgICAgICAgICAgIGV2ZW50SGFuZGxlcnM9e3tcbiAgICAgICAgICAgICAgZHJhZ2VuZDogKCkgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IG5leHQgPSBtYXJrZXJSZWYuY3VycmVudD8uZ2V0TGF0TG5nKCk7XG4gICAgICAgICAgICAgICAgaWYgKCFuZXh0KSByZXR1cm47XG4gICAgICAgICAgICAgICAgY29uc3QgcG9pbnQ6IFtudW1iZXIsIG51bWJlcl0gPSBbbmV4dC5sYXQsIG5leHQubG5nXTtcbiAgICAgICAgICAgICAgICBzZXRQb3NpdGlvbihwb2ludCk7XG4gICAgICAgICAgICAgICAgb25DaGFuZ2UocG9pbnQpO1xuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgfX1cbiAgICAgICAgICAvPlxuICAgICAgICA8L01hcENvbnRhaW5lcj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTMgZmxleCBmbGV4LXdyYXAgaXRlbXMtY2VudGVyIGdhcC0zXCI+XG4gICAgICAgIDxwXG4gICAgICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgICAgIFwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgdGV4dC1zbVwiLFxuICAgICAgICAgICAgdmFsdWUgPyBcImZvbnQtbWVkaXVtIHRleHQtb2stNjAwXCIgOiBcInRleHQtbXV0ZWRcIixcbiAgICAgICAgICApfVxuICAgICAgICA+XG4gICAgICAgICAgPE1hcFBpbiBzaXplPXsxNH0gYXJpYS1oaWRkZW4gLz5cbiAgICAgICAgICB7dmFsdWUgPyB0KFwibWFwLnBpblNldFwiKSA6IHQoXCJtYXAudXNlQXJlYVwiKX1cbiAgICAgICAgPC9wPlxuXG4gICAgICAgIHt2YWx1ZSAmJiAoXG4gICAgICAgICAgPEJ1dHRvbiBzaXplPVwic21cIiB2YXJpYW50PVwiZ2hvc3RcIiBvbkNsaWNrPXsoKSA9PiBvbkNoYW5nZShudWxsKX0+XG4gICAgICAgICAgICB7dChcIm1hcC5waW5Ta2lwXCIpfVxuICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICApfVxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXSwiZmlsZSI6IkQ6L0kySSBQcm9qZWN0IC0gSGFiaXRvL0FwcCBGb2xkZXIvaGFiaXRvL3NyYy9jb21wb25lbnRzL3NwYWNlL1BpblBpY2tlci50c3gifQ==