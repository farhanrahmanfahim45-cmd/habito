import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/layout/Header.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=9ceb86a3"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("D:/I2I Project - Habito/App Folder/habito/src/components/layout/Header.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import { NavLink, Link } from "/node_modules/.vite/deps/react-router-dom.js?v=9ceb86a3";
import { Bookmark, MessagesSquare, Settings, UserRound } from "/node_modules/.vite/deps/lucide-react.js?v=9ceb86a3";
import { cn } from "/src/lib/cn.ts";
import { useHabito } from "/src/hooks/useHabito.tsx";
import { useAuth } from "/src/hooks/useAuth.tsx";
import { useI18n } from "/src/i18n/index.tsx";
import { Button } from "/src/components/ui/Button.tsx";
import { LanguageToggle } from "/src/components/ui/LanguageToggle.tsx";
export function Wordmark({ className }) {
  return /* @__PURE__ */ jsxDEV(Link, { to: "/", className: cn("inline-flex items-center gap-1.5", className), "aria-label": "Habito", children: [
    /* @__PURE__ */ jsxDEV("span", { "aria-hidden": true, className: "relative inline-block size-4 shrink-0", children: [
      /* @__PURE__ */ jsxDEV("span", { className: "absolute inset-0 rounded-[5px] bg-ink" }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/layout/Header.tsx",
        lineNumber: 33,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("span", { className: "absolute bottom-0.5 right-0.5 size-1.5 rounded-full bg-aqua-400" }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/layout/Header.tsx",
        lineNumber: 34,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/layout/Header.tsx",
      lineNumber: 32,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("span", { className: "font-display text-[1.35em] font-extrabold tracking-tight text-ink", children: "Habito" }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/layout/Header.tsx",
      lineNumber: 36,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/layout/Header.tsx",
    lineNumber: 31,
    columnNumber: 5
  }, this);
}
_c = Wordmark;
const NAV = [
  { to: "/explore", key: "nav.explore" },
  { to: "/search", key: "nav.search" },
  { to: "/portfolio", key: "nav.portfolio" },
  { to: "/bookings", key: "nav.bookings" }
];
export function Header() {
  _s();
  const { savedIds, unreadMessages } = useHabito();
  const { account } = useAuth();
  const { t } = useI18n();
  const nav = account?.role === "admin" ? [...NAV, { to: "/admin", key: "nav.admin" }] : NAV;
  return /* @__PURE__ */ jsxDEV("header", { className: "sticky top-0 z-40 border-b border-hairline bg-ivory/85 backdrop-blur-md", children: /* @__PURE__ */ jsxDEV("div", { className: "container-page flex h-16 items-center gap-7", children: [
    /* @__PURE__ */ jsxDEV(Wordmark, { className: "text-base" }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/layout/Header.tsx",
      lineNumber: 68,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("nav", { "aria-label": "Main", className: "hidden items-center gap-6 md:flex", children: nav.map(
      (item) => /* @__PURE__ */ jsxDEV(
        NavLink,
        {
          to: item.to,
          className: ({ isActive }) => cn(
            "relative py-1 text-sm font-semibold transition-colors",
            isActive ? "text-ink" : "text-muted hover:text-ink",
            isActive && "after:absolute after:-bottom-0.5 after:left-0 after:h-0.5 after:w-full after:rounded-full after:bg-aqua-400"
          ),
          children: t(item.key)
        },
        item.to,
        false,
        {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/layout/Header.tsx",
          lineNumber: 72,
          columnNumber: 11
        },
        this
      )
    ) }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/layout/Header.tsx",
      lineNumber: 70,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "ml-auto flex items-center gap-1.5", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "hidden items-center gap-0.5 md:flex", children: [
        /* @__PURE__ */ jsxDEV(IconLink, { to: "/saved", label: t("nav.saved"), count: savedIds.length, icon: Bookmark }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/layout/Header.tsx",
          lineNumber: 91,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(
          IconLink,
          {
            to: "/messages",
            label: t("nav.messages"),
            count: unreadMessages,
            icon: MessagesSquare
          },
          void 0,
          false,
          {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/layout/Header.tsx",
            lineNumber: 92,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/layout/Header.tsx",
        lineNumber: 90,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "hidden lg:block", children: /* @__PURE__ */ jsxDEV(LanguageToggle, {}, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/layout/Header.tsx",
        lineNumber: 101,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/layout/Header.tsx",
        lineNumber: 100,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(AccountControls, {}, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/layout/Header.tsx",
        lineNumber: 104,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/layout/Header.tsx",
      lineNumber: 89,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/layout/Header.tsx",
    lineNumber: 67,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/layout/Header.tsx",
    lineNumber: 66,
    columnNumber: 5
  }, this);
}
_s(Header, "AOXhncPprnHe30DmcJS7/v/CuWw=", false, function() {
  return [useHabito, useAuth, useI18n];
});
_c2 = Header;
function AccountControls() {
  _s2();
  const { configured, account } = useAuth();
  const { t } = useI18n();
  if (configured && !account) {
    return /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1.5", children: [
      /* @__PURE__ */ jsxDEV(Link, { to: "/signin", className: "hidden sm:block", children: /* @__PURE__ */ jsxDEV(Button, { size: "sm", variant: "ghost", children: t("action.signIn") }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/layout/Header.tsx",
        lineNumber: 119,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/layout/Header.tsx",
        lineNumber: 118,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Link, { to: "/signup", children: /* @__PURE__ */ jsxDEV(Button, { size: "sm", children: t("action.getStarted") }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/layout/Header.tsx",
        lineNumber: 124,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/layout/Header.tsx",
        lineNumber: 123,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/layout/Header.tsx",
      lineNumber: 117,
      columnNumber: 7
    }, this);
  }
  return /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-0.5", children: [
    /* @__PURE__ */ jsxDEV(
      IconLink,
      {
        to: "/account",
        label: account ? account.name.split(" ")[0] : t("nav.profile"),
        icon: UserRound
      },
      void 0,
      false,
      {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/layout/Header.tsx",
        lineNumber: 132,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(IconLink, { to: "/settings", label: t("nav.settings"), icon: Settings, hideLabel: true }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/layout/Header.tsx",
      lineNumber: 137,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/layout/Header.tsx",
    lineNumber: 131,
    columnNumber: 5
  }, this);
}
_s2(AccountControls, "SG0Mzys2XblPX65PYaKuSHsTs/o=", false, function() {
  return [useAuth, useI18n];
});
_c3 = AccountControls;
function IconLink({
  to,
  label,
  count,
  icon: Icon,
  hideLabel
}) {
  return /* @__PURE__ */ jsxDEV(
    NavLink,
    {
      to,
      "aria-label": label,
      className: ({ isActive }) => cn(
        "inline-flex items-center gap-1.5 rounded-full px-2.5 py-2 text-sm font-medium transition-colors",
        isActive ? "bg-ivory-deep text-ink" : "text-muted hover:bg-ivory-deep hover:text-ink"
      ),
      children: [
        /* @__PURE__ */ jsxDEV(Icon, { size: 16, "aria-hidden": true }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/layout/Header.tsx",
          lineNumber: 166,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: cn(hideLabel ? "sr-only" : "sr-only lg:not-sr-only"), children: label }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/layout/Header.tsx",
          lineNumber: 167,
          columnNumber: 7
        }, this),
        count !== void 0 && count > 0 && /* @__PURE__ */ jsxDEV("span", { className: "rounded-full bg-aqua-400 px-1.5 text-[0.65rem] font-bold tnum text-ink", children: count }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/layout/Header.tsx",
          lineNumber: 169,
          columnNumber: 7
        }, this)
      ]
    },
    void 0,
    true,
    {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/layout/Header.tsx",
      lineNumber: 156,
      columnNumber: 5
    },
    this
  );
}
_c4 = IconLink;
var _c, _c2, _c3, _c4;
$RefreshReg$(_c, "Wordmark");
$RefreshReg$(_c2, "Header");
$RefreshReg$(_c3, "AccountControls");
$RefreshReg$(_c4, "IconLink");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/I2I Project - Habito/App Folder/habito/src/components/layout/Header.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/I2I Project - Habito/App Folder/habito/src/components/layout/Header.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBYVE7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBYlIsU0FBU0EsU0FBU0MsWUFBWTtBQUM5QixTQUFTQyxVQUFVQyxnQkFBZ0JDLFVBQVVDLGlCQUFpQjtBQUM5RCxTQUFTQyxVQUFVO0FBQ25CLFNBQVNDLGlCQUFpQjtBQUMxQixTQUFTQyxlQUFlO0FBQ3hCLFNBQVNDLGVBQWU7QUFDeEIsU0FBU0MsY0FBYztBQUN2QixTQUFTQyxzQkFBc0I7QUFFeEIsZ0JBQVNDLFNBQVMsRUFBRUMsVUFBa0MsR0FBRztBQUM5RCxTQUNFLHVCQUFDLFFBQUssSUFBRyxLQUFJLFdBQVdQLEdBQUcsb0NBQW9DTyxTQUFTLEdBQUcsY0FBVyxVQUNwRjtBQUFBLDJCQUFDLFVBQUssZUFBVyxNQUFDLFdBQVUseUNBQzFCO0FBQUEsNkJBQUMsVUFBSyxXQUFVLDJDQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXVEO0FBQUEsTUFDdkQsdUJBQUMsVUFBSyxXQUFVLHFFQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlGO0FBQUEsU0FGbkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdBO0FBQUEsSUFDQSx1QkFBQyxVQUFLLFdBQVUscUVBQW9FLHNCQUFwRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTBGO0FBQUEsT0FMNUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQU1BO0FBRUo7QUFFQUMsS0FaZ0JGO0FBcUJoQixNQUFNRyxNQUFNO0FBQUEsRUFDVixFQUFFQyxJQUFJLFlBQVlDLEtBQUssY0FBYztBQUFBLEVBQ3JDLEVBQUVELElBQUksV0FBV0MsS0FBSyxhQUFhO0FBQUEsRUFDbkMsRUFBRUQsSUFBSSxjQUFjQyxLQUFLLGdCQUFnQjtBQUFBLEVBQ3pDLEVBQUVELElBQUksYUFBYUMsS0FBSyxlQUFlO0FBQUM7QUFHbkMsZ0JBQVNDLFNBQVM7QUFBQUMsS0FBQTtBQUN2QixRQUFNLEVBQUVDLFVBQVVDLGVBQWUsSUFBSWQsVUFBVTtBQUMvQyxRQUFNLEVBQUVlLFFBQVEsSUFBSWQsUUFBUTtBQUM1QixRQUFNLEVBQUVlLEVBQUUsSUFBSWQsUUFBUTtBQUd0QixRQUFNZSxNQUFNRixTQUFTRyxTQUFTLFVBQVUsQ0FBQyxHQUFHVixLQUFLLEVBQUVDLElBQUksVUFBVUMsS0FBSyxZQUFZLENBQVUsSUFBSUY7QUFFaEcsU0FDRSx1QkFBQyxZQUFPLFdBQVUsMkVBQ2hCLGlDQUFDLFNBQUksV0FBVSwrQ0FDYjtBQUFBLDJCQUFDLFlBQVMsV0FBVSxlQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQStCO0FBQUEsSUFFL0IsdUJBQUMsU0FBSSxjQUFXLFFBQU8sV0FBVSxxQ0FDOUJTLGNBQUlFO0FBQUFBLE1BQUksQ0FBQ0MsU0FDUjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBRUMsSUFBSUEsS0FBS1g7QUFBQUEsVUFDVCxXQUFXLENBQUMsRUFBRVksU0FBUyxNQUNyQnRCO0FBQUFBLFlBQ0U7QUFBQSxZQUNBc0IsV0FBVyxhQUFhO0FBQUEsWUFDeEJBLFlBQ0U7QUFBQSxVQUNKO0FBQUEsVUFHREwsWUFBRUksS0FBS1YsR0FBRztBQUFBO0FBQUEsUUFYTlUsS0FBS1g7QUFBQUEsUUFEWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BYUE7QUFBQSxJQUNELEtBaEJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FpQkE7QUFBQSxJQUVBLHVCQUFDLFNBQUksV0FBVSxxQ0FDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSx1Q0FDYjtBQUFBLCtCQUFDLFlBQVMsSUFBRyxVQUFTLE9BQU9PLEVBQUUsV0FBVyxHQUFHLE9BQU9ILFNBQVNTLFFBQVEsTUFBTTNCLFlBQTNFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBb0Y7QUFBQSxRQUNwRjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsSUFBRztBQUFBLFlBQ0gsT0FBT3FCLEVBQUUsY0FBYztBQUFBLFlBQ3ZCLE9BQU9GO0FBQUFBLFlBQ1AsTUFBTWxCO0FBQUFBO0FBQUFBLFVBSlI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBSXVCO0FBQUEsV0FOekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVFBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsbUJBQ2IsaUNBQUMsb0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFlLEtBRGpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BRUEsdUJBQUMscUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFnQjtBQUFBLFNBZmxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FnQkE7QUFBQSxPQXRDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBdUNBLEtBeENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F5Q0E7QUFFSjtBQUFDZ0IsR0FwRGVELFFBQU07QUFBQSxVQUNpQlgsV0FDakJDLFNBQ05DLE9BQU87QUFBQTtBQUFBLE1BSFBTO0FBc0RoQixTQUFTWSxrQkFBa0I7QUFBQUMsTUFBQTtBQUN6QixRQUFNLEVBQUVDLFlBQVlWLFFBQVEsSUFBSWQsUUFBUTtBQUN4QyxRQUFNLEVBQUVlLEVBQUUsSUFBSWQsUUFBUTtBQUV0QixNQUFJdUIsY0FBYyxDQUFDVixTQUFTO0FBQzFCLFdBQ0UsdUJBQUMsU0FBSSxXQUFVLDZCQUNiO0FBQUEsNkJBQUMsUUFBSyxJQUFHLFdBQVUsV0FBVSxtQkFDM0IsaUNBQUMsVUFBTyxNQUFLLE1BQUssU0FBUSxTQUN2QkMsWUFBRSxlQUFlLEtBRHBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFJQTtBQUFBLE1BQ0EsdUJBQUMsUUFBSyxJQUFHLFdBQ1AsaUNBQUMsVUFBTyxNQUFLLE1BQU1BLFlBQUUsbUJBQW1CLEtBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMEMsS0FENUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0FSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBU0E7QUFBQSxFQUVKO0FBRUEsU0FDRSx1QkFBQyxTQUFJLFdBQVUsNkJBQ2I7QUFBQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsSUFBRztBQUFBLFFBQ0gsT0FBT0QsVUFBVUEsUUFBUVcsS0FBS0MsTUFBTSxHQUFHLEVBQUUsQ0FBQyxJQUFJWCxFQUFFLGFBQWE7QUFBQSxRQUM3RCxNQUFNbEI7QUFBQUE7QUFBQUEsTUFIUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFHa0I7QUFBQSxJQUVsQix1QkFBQyxZQUFTLElBQUcsYUFBWSxPQUFPa0IsRUFBRSxjQUFjLEdBQUcsTUFBTW5CLFVBQVUsV0FBUyxRQUE1RTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTRFO0FBQUEsT0FOOUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQU9BO0FBRUo7QUFBQzJCLElBN0JRRCxpQkFBZTtBQUFBLFVBQ1V0QixTQUNsQkMsT0FBTztBQUFBO0FBQUEsTUFGZHFCO0FBK0JULFNBQVNLLFNBQVM7QUFBQSxFQUNoQm5CO0FBQUFBLEVBQ0FvQjtBQUFBQSxFQUNBQztBQUFBQSxFQUNBQyxNQUFNQztBQUFBQSxFQUNOQztBQU9GLEdBQUc7QUFDRCxTQUNFO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDQztBQUFBLE1BQ0EsY0FBWUo7QUFBQUEsTUFDWixXQUFXLENBQUMsRUFBRVIsU0FBUyxNQUNyQnRCO0FBQUFBLFFBQ0U7QUFBQSxRQUNBc0IsV0FBVywyQkFBMkI7QUFBQSxNQUN4QztBQUFBLE1BR0Y7QUFBQSwrQkFBQyxRQUFLLE1BQU0sSUFBSSxlQUFXLFFBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMkI7QUFBQSxRQUMzQix1QkFBQyxVQUFLLFdBQVd0QixHQUFHa0MsWUFBWSxZQUFZLHdCQUF3QixHQUFJSixtQkFBeEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE4RTtBQUFBLFFBQzdFQyxVQUFVSSxVQUFhSixRQUFRLEtBQzlCLHVCQUFDLFVBQUssV0FBVSwwRUFDYkEsbUJBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUE7QUFBQTtBQUFBLElBZko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBaUJBO0FBRUo7QUFBQ0ssTUFqQ1FQO0FBQVEsSUFBQXJCLElBQUE2QixLQUFBQyxLQUFBRjtBQUFBLGFBQUE1QixJQUFBO0FBQUEsYUFBQTZCLEtBQUE7QUFBQSxhQUFBQyxLQUFBO0FBQUEsYUFBQUYsS0FBQSIsIm5hbWVzIjpbIk5hdkxpbmsiLCJMaW5rIiwiQm9va21hcmsiLCJNZXNzYWdlc1NxdWFyZSIsIlNldHRpbmdzIiwiVXNlclJvdW5kIiwiY24iLCJ1c2VIYWJpdG8iLCJ1c2VBdXRoIiwidXNlSTE4biIsIkJ1dHRvbiIsIkxhbmd1YWdlVG9nZ2xlIiwiV29yZG1hcmsiLCJjbGFzc05hbWUiLCJfYyIsIk5BViIsInRvIiwia2V5IiwiSGVhZGVyIiwiX3MiLCJzYXZlZElkcyIsInVucmVhZE1lc3NhZ2VzIiwiYWNjb3VudCIsInQiLCJuYXYiLCJyb2xlIiwibWFwIiwiaXRlbSIsImlzQWN0aXZlIiwibGVuZ3RoIiwiQWNjb3VudENvbnRyb2xzIiwiX3MyIiwiY29uZmlndXJlZCIsIm5hbWUiLCJzcGxpdCIsIkljb25MaW5rIiwibGFiZWwiLCJjb3VudCIsImljb24iLCJJY29uIiwiaGlkZUxhYmVsIiwidW5kZWZpbmVkIiwiX2M0IiwiX2MyIiwiX2MzIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkhlYWRlci50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTmF2TGluaywgTGluayB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XG5pbXBvcnQgeyBCb29rbWFyaywgTWVzc2FnZXNTcXVhcmUsIFNldHRpbmdzLCBVc2VyUm91bmQgfSBmcm9tIFwibHVjaWRlLXJlYWN0XCI7XG5pbXBvcnQgeyBjbiB9IGZyb20gXCJAL2xpYi9jblwiO1xuaW1wb3J0IHsgdXNlSGFiaXRvIH0gZnJvbSBcIkAvaG9va3MvdXNlSGFiaXRvXCI7XG5pbXBvcnQgeyB1c2VBdXRoIH0gZnJvbSBcIkAvaG9va3MvdXNlQXV0aFwiO1xuaW1wb3J0IHsgdXNlSTE4biB9IGZyb20gXCJAL2kxOG5cIjtcbmltcG9ydCB7IEJ1dHRvbiB9IGZyb20gXCJAL2NvbXBvbmVudHMvdWkvQnV0dG9uXCI7XG5pbXBvcnQgeyBMYW5ndWFnZVRvZ2dsZSB9IGZyb20gXCJAL2NvbXBvbmVudHMvdWkvTGFuZ3VhZ2VUb2dnbGVcIjtcblxuZXhwb3J0IGZ1bmN0aW9uIFdvcmRtYXJrKHsgY2xhc3NOYW1lIH06IHsgY2xhc3NOYW1lPzogc3RyaW5nIH0pIHtcbiAgcmV0dXJuIChcbiAgICA8TGluayB0bz1cIi9cIiBjbGFzc05hbWU9e2NuKFwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjVcIiwgY2xhc3NOYW1lKX0gYXJpYS1sYWJlbD1cIkhhYml0b1wiPlxuICAgICAgPHNwYW4gYXJpYS1oaWRkZW4gY2xhc3NOYW1lPVwicmVsYXRpdmUgaW5saW5lLWJsb2NrIHNpemUtNCBzaHJpbmstMFwiPlxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBpbnNldC0wIHJvdW5kZWQtWzVweF0gYmctaW5rXCIgLz5cbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYWJzb2x1dGUgYm90dG9tLTAuNSByaWdodC0wLjUgc2l6ZS0xLjUgcm91bmRlZC1mdWxsIGJnLWFxdWEtNDAwXCIgLz5cbiAgICAgIDwvc3Bhbj5cbiAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtZGlzcGxheSB0ZXh0LVsxLjM1ZW1dIGZvbnQtZXh0cmFib2xkIHRyYWNraW5nLXRpZ2h0IHRleHQtaW5rXCI+SGFiaXRvPC9zcGFuPlxuICAgIDwvTGluaz5cbiAgKTtcbn1cblxuLyoqXG4gKiBPbmUgbmF2aWdhdGlvbiBmb3IgZXZlcnlib2R5LlxuICpcbiAqIFRoZXJlIHVzZWQgdG8gYmUgYSByZW50ZXIvb3duZXIgc3dpdGNoLiBJdCBhc2tlZCBwZW9wbGUgdG8gdW5kZXJzdGFuZCBhIG1vZGVcbiAqIGJlZm9yZSB0aGV5IGNvdWxkIGFjdCwgYW5kIGl0IGJyb2tlIHF1aWV0bHkgd2hlbmV2ZXIgdGhlIGFjY291bnQgc3RhdGUgd2FzXG4gKiBzdGFsZS4gUGxlbnR5IG9mIHBlb3BsZSBoZXJlIGFyZSBib3RoIOKAlCBhIHJlbnRlciB3aG8gc3VibGV0cyBhIHJvb20sIGFcbiAqIHNob3BrZWVwZXIgcmVudGluZyBhIGZsYXQg4oCUIHNvIGJvdGggc2lkZXMgYXJlIHNpbXBseSBhbHdheXMgcHJlc2VudC4gU29tZW9uZVxuICogd2hvIG5ldmVyIGxpc3RzIGFueXRoaW5nIGp1c3QgbmV2ZXIgb3BlbnMgTXkgc3BhY2VzLlxuICovXG5jb25zdCBOQVYgPSBbXG4gIHsgdG86IFwiL2V4cGxvcmVcIiwga2V5OiBcIm5hdi5leHBsb3JlXCIgfSxcbiAgeyB0bzogXCIvc2VhcmNoXCIsIGtleTogXCJuYXYuc2VhcmNoXCIgfSxcbiAgeyB0bzogXCIvcG9ydGZvbGlvXCIsIGtleTogXCJuYXYucG9ydGZvbGlvXCIgfSxcbiAgeyB0bzogXCIvYm9va2luZ3NcIiwga2V5OiBcIm5hdi5ib29raW5nc1wiIH0sXG5dIGFzIGNvbnN0O1xuXG5leHBvcnQgZnVuY3Rpb24gSGVhZGVyKCkge1xuICBjb25zdCB7IHNhdmVkSWRzLCB1bnJlYWRNZXNzYWdlcyB9ID0gdXNlSGFiaXRvKCk7XG4gIGNvbnN0IHsgYWNjb3VudCB9ID0gdXNlQXV0aCgpO1xuICBjb25zdCB7IHQgfSA9IHVzZUkxOG4oKTtcblxuICAvLyBPbmx5IGEgbW9kZXJhdG9yIGV2ZXIgc2VlcyB0aGUgcXVldWUuXG4gIGNvbnN0IG5hdiA9IGFjY291bnQ/LnJvbGUgPT09IFwiYWRtaW5cIiA/IFsuLi5OQVYsIHsgdG86IFwiL2FkbWluXCIsIGtleTogXCJuYXYuYWRtaW5cIiB9IGFzIGNvbnN0XSA6IE5BVjtcblxuICByZXR1cm4gKFxuICAgIDxoZWFkZXIgY2xhc3NOYW1lPVwic3RpY2t5IHRvcC0wIHotNDAgYm9yZGVyLWIgYm9yZGVyLWhhaXJsaW5lIGJnLWl2b3J5Lzg1IGJhY2tkcm9wLWJsdXItbWRcIj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29udGFpbmVyLXBhZ2UgZmxleCBoLTE2IGl0ZW1zLWNlbnRlciBnYXAtN1wiPlxuICAgICAgICA8V29yZG1hcmsgY2xhc3NOYW1lPVwidGV4dC1iYXNlXCIgLz5cblxuICAgICAgICA8bmF2IGFyaWEtbGFiZWw9XCJNYWluXCIgY2xhc3NOYW1lPVwiaGlkZGVuIGl0ZW1zLWNlbnRlciBnYXAtNiBtZDpmbGV4XCI+XG4gICAgICAgICAge25hdi5tYXAoKGl0ZW0pID0+IChcbiAgICAgICAgICAgIDxOYXZMaW5rXG4gICAgICAgICAgICAgIGtleT17aXRlbS50b31cbiAgICAgICAgICAgICAgdG89e2l0ZW0udG99XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT17KHsgaXNBY3RpdmUgfSkgPT5cbiAgICAgICAgICAgICAgICBjbihcbiAgICAgICAgICAgICAgICAgIFwicmVsYXRpdmUgcHktMSB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdHJhbnNpdGlvbi1jb2xvcnNcIixcbiAgICAgICAgICAgICAgICAgIGlzQWN0aXZlID8gXCJ0ZXh0LWlua1wiIDogXCJ0ZXh0LW11dGVkIGhvdmVyOnRleHQtaW5rXCIsXG4gICAgICAgICAgICAgICAgICBpc0FjdGl2ZSAmJlxuICAgICAgICAgICAgICAgICAgICBcImFmdGVyOmFic29sdXRlIGFmdGVyOi1ib3R0b20tMC41IGFmdGVyOmxlZnQtMCBhZnRlcjpoLTAuNSBhZnRlcjp3LWZ1bGwgYWZ0ZXI6cm91bmRlZC1mdWxsIGFmdGVyOmJnLWFxdWEtNDAwXCIsXG4gICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIHt0KGl0ZW0ua2V5KX1cbiAgICAgICAgICAgIDwvTmF2TGluaz5cbiAgICAgICAgICApKX1cbiAgICAgICAgPC9uYXY+XG5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtbC1hdXRvIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjVcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImhpZGRlbiBpdGVtcy1jZW50ZXIgZ2FwLTAuNSBtZDpmbGV4XCI+XG4gICAgICAgICAgICA8SWNvbkxpbmsgdG89XCIvc2F2ZWRcIiBsYWJlbD17dChcIm5hdi5zYXZlZFwiKX0gY291bnQ9e3NhdmVkSWRzLmxlbmd0aH0gaWNvbj17Qm9va21hcmt9IC8+XG4gICAgICAgICAgICA8SWNvbkxpbmtcbiAgICAgICAgICAgICAgdG89XCIvbWVzc2FnZXNcIlxuICAgICAgICAgICAgICBsYWJlbD17dChcIm5hdi5tZXNzYWdlc1wiKX1cbiAgICAgICAgICAgICAgY291bnQ9e3VucmVhZE1lc3NhZ2VzfVxuICAgICAgICAgICAgICBpY29uPXtNZXNzYWdlc1NxdWFyZX1cbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImhpZGRlbiBsZzpibG9ja1wiPlxuICAgICAgICAgICAgPExhbmd1YWdlVG9nZ2xlIC8+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICA8QWNjb3VudENvbnRyb2xzIC8+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgPC9oZWFkZXI+XG4gICk7XG59XG5cbmZ1bmN0aW9uIEFjY291bnRDb250cm9scygpIHtcbiAgY29uc3QgeyBjb25maWd1cmVkLCBhY2NvdW50IH0gPSB1c2VBdXRoKCk7XG4gIGNvbnN0IHsgdCB9ID0gdXNlSTE4bigpO1xuXG4gIGlmIChjb25maWd1cmVkICYmICFhY2NvdW50KSB7XG4gICAgcmV0dXJuIChcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxuICAgICAgICA8TGluayB0bz1cIi9zaWduaW5cIiBjbGFzc05hbWU9XCJoaWRkZW4gc206YmxvY2tcIj5cbiAgICAgICAgICA8QnV0dG9uIHNpemU9XCJzbVwiIHZhcmlhbnQ9XCJnaG9zdFwiPlxuICAgICAgICAgICAge3QoXCJhY3Rpb24uc2lnbkluXCIpfVxuICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICA8L0xpbms+XG4gICAgICAgIDxMaW5rIHRvPVwiL3NpZ251cFwiPlxuICAgICAgICAgIDxCdXR0b24gc2l6ZT1cInNtXCI+e3QoXCJhY3Rpb24uZ2V0U3RhcnRlZFwiKX08L0J1dHRvbj5cbiAgICAgICAgPC9MaW5rPlxuICAgICAgPC9kaXY+XG4gICAgKTtcbiAgfVxuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMC41XCI+XG4gICAgICA8SWNvbkxpbmtcbiAgICAgICAgdG89XCIvYWNjb3VudFwiXG4gICAgICAgIGxhYmVsPXthY2NvdW50ID8gYWNjb3VudC5uYW1lLnNwbGl0KFwiIFwiKVswXSA6IHQoXCJuYXYucHJvZmlsZVwiKX1cbiAgICAgICAgaWNvbj17VXNlclJvdW5kfVxuICAgICAgLz5cbiAgICAgIDxJY29uTGluayB0bz1cIi9zZXR0aW5nc1wiIGxhYmVsPXt0KFwibmF2LnNldHRpbmdzXCIpfSBpY29uPXtTZXR0aW5nc30gaGlkZUxhYmVsIC8+XG4gICAgPC9kaXY+XG4gICk7XG59XG5cbmZ1bmN0aW9uIEljb25MaW5rKHtcbiAgdG8sXG4gIGxhYmVsLFxuICBjb3VudCxcbiAgaWNvbjogSWNvbixcbiAgaGlkZUxhYmVsLFxufToge1xuICB0bzogc3RyaW5nO1xuICBsYWJlbDogc3RyaW5nO1xuICBjb3VudD86IG51bWJlcjtcbiAgaWNvbjogdHlwZW9mIEJvb2ttYXJrO1xuICBoaWRlTGFiZWw/OiBib29sZWFuO1xufSkge1xuICByZXR1cm4gKFxuICAgIDxOYXZMaW5rXG4gICAgICB0bz17dG99XG4gICAgICBhcmlhLWxhYmVsPXtsYWJlbH1cbiAgICAgIGNsYXNzTmFtZT17KHsgaXNBY3RpdmUgfSkgPT5cbiAgICAgICAgY24oXG4gICAgICAgICAgXCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSByb3VuZGVkLWZ1bGwgcHgtMi41IHB5LTIgdGV4dC1zbSBmb250LW1lZGl1bSB0cmFuc2l0aW9uLWNvbG9yc1wiLFxuICAgICAgICAgIGlzQWN0aXZlID8gXCJiZy1pdm9yeS1kZWVwIHRleHQtaW5rXCIgOiBcInRleHQtbXV0ZWQgaG92ZXI6YmctaXZvcnktZGVlcCBob3Zlcjp0ZXh0LWlua1wiLFxuICAgICAgICApXG4gICAgICB9XG4gICAgPlxuICAgICAgPEljb24gc2l6ZT17MTZ9IGFyaWEtaGlkZGVuIC8+XG4gICAgICA8c3BhbiBjbGFzc05hbWU9e2NuKGhpZGVMYWJlbCA/IFwic3Itb25seVwiIDogXCJzci1vbmx5IGxnOm5vdC1zci1vbmx5XCIpfT57bGFiZWx9PC9zcGFuPlxuICAgICAge2NvdW50ICE9PSB1bmRlZmluZWQgJiYgY291bnQgPiAwICYmIChcbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicm91bmRlZC1mdWxsIGJnLWFxdWEtNDAwIHB4LTEuNSB0ZXh0LVswLjY1cmVtXSBmb250LWJvbGQgdG51bSB0ZXh0LWlua1wiPlxuICAgICAgICAgIHtjb3VudH1cbiAgICAgICAgPC9zcGFuPlxuICAgICAgKX1cbiAgICA8L05hdkxpbms+XG4gICk7XG59XG4iXSwiZmlsZSI6IkQ6L0kySSBQcm9qZWN0IC0gSGFiaXRvL0FwcCBGb2xkZXIvaGFiaXRvL3NyYy9jb21wb25lbnRzL2xheW91dC9IZWFkZXIudHN4In0=