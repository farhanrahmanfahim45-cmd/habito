import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/@fs/D:\\I2I Project - Habito\\App Folder\\habito\\src\\pages\\Admin.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=9ceb86a3"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("D:/I2I Project - Habito/App Folder/habito/src/pages/Admin.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9ceb86a3"; const useCallback = __vite__cjsImport3_react["useCallback"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=9ceb86a3";
import {
  ShieldCheck,
  EyeOff,
  Eye,
  Copy,
  Flag,
  Check,
  X,
  ChevronRight,
  ClipboardList
} from "/node_modules/.vite/deps/lucide-react.js?v=9ceb86a3";
import { db } from "/src/lib/api/index.ts";
import { useI18n } from "/src/i18n/index.tsx";
import { PageHeader } from "/src/components/layout/PageHeader.tsx";
import { Button } from "/src/components/ui/Button.tsx";
import { Modal } from "/src/components/ui/Modal.tsx";
import { Skeleton } from "/src/components/ui/Skeleton.tsx";
import { useToast } from "/src/components/ui/Toast.tsx";
import { cn } from "/src/lib/cn.ts";
export default function Admin() {
  _s();
  const { t } = useI18n();
  const { notify } = useToast();
  const [items, setItems] = useState(null);
  const [busy, setBusy] = useState(null);
  const [reviewing, setReviewing] = useState(null);
  const [note, setNote] = useState("");
  const load = useCallback(async () => {
    try {
      setItems(await db.reviewQueue());
    } catch {
      setItems([]);
    }
  }, []);
  useEffect(() => {
    void load();
  }, [load]);
  const act = async (item, run, message) => {
    setBusy(item.spaceId);
    try {
      await run();
      await load();
      notify(message);
    } catch (e) {
      notify(e instanceof Error ? e.message : t("auth.errorGeneric"));
    } finally {
      setBusy(null);
      setReviewing(null);
      setNote("");
    }
  };
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(PageHeader, { title: t("admin.title"), lead: t("admin.lead") }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Admin.tsx",
      lineNumber: 80,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "container-page max-w-4xl py-6 md:py-10", children: items === null ? /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: [0, 1, 2].map(
      (i) => /* @__PURE__ */ jsxDEV(Skeleton, { className: "h-32 w-full rounded-card" }, i, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Admin.tsx",
        lineNumber: 86,
        columnNumber: 11
      }, this)
    ) }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Admin.tsx",
      lineNumber: 84,
      columnNumber: 9
    }, this) : items.length === 0 ? /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col items-center rounded-card bg-surface px-6 py-16 text-center ring-1 ring-hairline", children: [
      /* @__PURE__ */ jsxDEV("span", { className: "mb-4 flex size-12 items-center justify-center rounded-full bg-ok-100 text-ok-600", children: /* @__PURE__ */ jsxDEV(Check, { size: 22, "aria-hidden": true }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Admin.tsx",
        lineNumber: 92,
        columnNumber: 15
      }, this) }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Admin.tsx",
        lineNumber: 91,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("h2", { className: "font-display text-xl font-bold text-ink", children: t("admin.clear") }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Admin.tsx",
        lineNumber: 94,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "mt-2 max-w-sm text-sm text-muted", children: t("admin.clearBody") }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Admin.tsx",
        lineNumber: 95,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Admin.tsx",
      lineNumber: 90,
      columnNumber: 9
    }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV("p", { className: "mb-4 text-sm text-muted", children: t("admin.count", { count: items.length }) }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Admin.tsx",
        lineNumber: 99,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("ul", { className: "space-y-3", children: items.map(
        (item) => /* @__PURE__ */ jsxDEV("li", { children: /* @__PURE__ */ jsxDEV(
          QueueCard,
          {
            item,
            busy: busy === item.spaceId,
            onReview: () => setReviewing(item),
            onHide: () => void act(item, () => db.setListingVisible(item.spaceId, false), t("admin.hidden")),
            onRestore: () => void act(item, () => db.setListingVisible(item.spaceId, true), t("admin.restored")),
            onDismissReports: () => void act(item, () => db.resolveReports(item.spaceId, true), t("admin.reportsDismissed")),
            onUpholdReports: () => void act(item, () => db.resolveReports(item.spaceId, false), t("admin.reportsUpheld")),
            onClearDuplicate: () => void act(item, () => db.clearDuplicate(item.spaceId), t("admin.duplicateCleared"))
          },
          void 0,
          false,
          {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Admin.tsx",
            lineNumber: 103,
            columnNumber: 19
          },
          this
        ) }, item.spaceId, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Admin.tsx",
          lineNumber: 102,
          columnNumber: 13
        }, this)
      ) }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Admin.tsx",
        lineNumber: 100,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Admin.tsx",
      lineNumber: 98,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Admin.tsx",
      lineNumber: 82,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        open: reviewing !== null,
        onClose: () => setReviewing(null),
        title: t("admin.reviewTitle"),
        footer: /* @__PURE__ */ jsxDEV("div", { className: "flex gap-2", children: [
          /* @__PURE__ */ jsxDEV(Button, { variant: "secondary", fullWidth: true, onClick: () => setReviewing(null), children: t("action.cancel") }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Admin.tsx",
            lineNumber: 137,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            Button,
            {
              fullWidth: true,
              disabled: note.trim().length === 0,
              onClick: () => reviewing && void act(
                reviewing,
                () => db.setTrust(reviewing.ownerId, "reviewed", note.trim()),
                t("admin.ownerReviewed")
              ),
              children: t("admin.markReviewed")
            },
            void 0,
            false,
            {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Admin.tsx",
              lineNumber: 140,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Admin.tsx",
          lineNumber: 136,
          columnNumber: 9
        }, this),
        children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-sm leading-relaxed text-ink-soft", children: t("admin.reviewBody") }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Admin.tsx",
            lineNumber: 157,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV("ol", { className: "mt-3 space-y-1.5 text-sm text-ink-soft", children: ["admin.check1", "admin.check2", "admin.check3", "admin.check4"].map(
            (key, i) => /* @__PURE__ */ jsxDEV("li", { className: "flex gap-2.5", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "mt-0.5 flex size-5 shrink-0 items-center justify-center rounded-full bg-ivory-deep text-[0.65rem] font-bold tnum", children: i + 1 }, void 0, false, {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Admin.tsx",
                lineNumber: 162,
                columnNumber: 15
              }, this),
              t(key)
            ] }, key, true, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Admin.tsx",
              lineNumber: 161,
              columnNumber: 11
            }, this)
          ) }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Admin.tsx",
            lineNumber: 159,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "mt-3 rounded-xl bg-warn-100 p-3 text-xs leading-relaxed text-warn-700", children: t("admin.deleteDocument") }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Admin.tsx",
            lineNumber: 170,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV("label", { className: "mt-4 block", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "mb-1.5 block text-sm font-medium text-ink-soft", children: t("admin.note") }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Admin.tsx",
              lineNumber: 175,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV(
              "textarea",
              {
                rows: 3,
                value: note,
                onChange: (e) => setNote(e.target.value),
                placeholder: t("admin.notePlaceholder"),
                className: "w-full rounded-xl bg-ivory p-3 text-[0.9375rem] ring-1 ring-hairline-strong focus:outline-none focus:ring-2 focus:ring-aqua-600"
              },
              void 0,
              false,
              {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Admin.tsx",
                lineNumber: 176,
                columnNumber: 11
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Admin.tsx",
            lineNumber: 174,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-xs text-muted", children: t("admin.noteAudit") }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Admin.tsx",
            lineNumber: 184,
            columnNumber: 9
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Admin.tsx",
        lineNumber: 131,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Admin.tsx",
    lineNumber: 79,
    columnNumber: 5
  }, this);
}
_s(Admin, "HVN4mjVzFH3Nv9f53hxoYm4L724=", false, function() {
  return [useI18n, useToast];
});
_c = Admin;
const PRIORITY_STYLE = [
  "bg-danger-100 text-danger-600",
  "bg-warn-100 text-warn-700",
  "bg-lilac/40 text-ink",
  "bg-ivory-deep text-muted",
  "bg-ivory-deep text-muted"
];
function QueueCard({
  item,
  busy,
  onReview,
  onHide,
  onRestore,
  onDismissReports,
  onUpholdReports,
  onClearDuplicate
}) {
  _s2();
  const { t } = useI18n();
  const reason = item.hiddenAt !== null ? { key: "admin.reasonHidden", icon: EyeOff, level: 0 } : item.openReports > 0 ? { key: "admin.reasonReported", icon: Flag, level: 1 } : item.flaggedDuplicate ? { key: "admin.reasonDuplicate", icon: Copy, level: 2 } : { key: "admin.reasonUnverified", icon: ShieldCheck, level: 3 };
  return /* @__PURE__ */ jsxDEV("article", { className: "rounded-card bg-surface p-4 ring-1 ring-hairline sm:p-5", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-start gap-3", children: [
      /* @__PURE__ */ jsxDEV(
        "span",
        {
          className: cn(
            "inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-semibold",
            PRIORITY_STYLE[reason.level]
          ),
          children: [
            /* @__PURE__ */ jsxDEV(reason.icon, { size: 13, "aria-hidden": true }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Admin.tsx",
              lineNumber: 237,
              columnNumber: 11
            }, this),
            t(reason.key)
          ]
        },
        void 0,
        true,
        {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Admin.tsx",
          lineNumber: 231,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { className: "min-w-0 flex-1", children: [
        /* @__PURE__ */ jsxDEV(
          Link,
          {
            to: `/space/${item.spaceId}`,
            className: "font-display font-bold text-ink hover:text-aqua-700",
            children: item.spaceName
          },
          void 0,
          false,
          {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Admin.tsx",
            lineNumber: 242,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("p", { className: "mt-0.5 text-sm text-muted", children: [
          item.area ?? "—",
          " · ",
          item.ownerName,
          " ·",
          " ",
          /* @__PURE__ */ jsxDEV("span", { className: "font-medium", children: t(`trust.tier.${item.ownerTrust}`) }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Admin.tsx",
            lineNumber: 250,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Admin.tsx",
          lineNumber: 248,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-xs text-muted", children: [
          t("admin.completeness", { score: item.completeness }),
          item.reportCount > 0 && ` · ${t("admin.reporters", { count: item.reportCount })}`
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Admin.tsx",
          lineNumber: 252,
          columnNumber: 11
        }, this),
        item.hiddenReason && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 rounded-xl bg-ivory p-2.5 text-xs text-ink-soft", children: item.hiddenReason }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Admin.tsx",
          lineNumber: 257,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Admin.tsx",
        lineNumber: 241,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Admin.tsx",
      lineNumber: 230,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "mt-4 flex flex-wrap gap-2", children: [
      item.openReports > 0 && /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV(Button, { size: "sm", variant: "secondary", disabled: busy, onClick: onDismissReports, children: [
          /* @__PURE__ */ jsxDEV(X, { size: 14, "aria-hidden": true }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Admin.tsx",
            lineNumber: 266,
            columnNumber: 15
          }, this),
          t("admin.dismissReports")
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Admin.tsx",
          lineNumber: 265,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(Button, { size: "sm", variant: "destructive", disabled: busy, onClick: onUpholdReports, children: [
          /* @__PURE__ */ jsxDEV(Flag, { size: 14, "aria-hidden": true }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Admin.tsx",
            lineNumber: 270,
            columnNumber: 15
          }, this),
          t("admin.upholdReports")
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Admin.tsx",
          lineNumber: 269,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Admin.tsx",
        lineNumber: 264,
        columnNumber: 9
      }, this),
      item.flaggedDuplicate && /* @__PURE__ */ jsxDEV(Button, { size: "sm", variant: "secondary", disabled: busy, onClick: onClearDuplicate, children: [
        /* @__PURE__ */ jsxDEV(Copy, { size: 14, "aria-hidden": true }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Admin.tsx",
          lineNumber: 278,
          columnNumber: 13
        }, this),
        t("admin.notDuplicate")
      ] }, void 0, true, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Admin.tsx",
        lineNumber: 277,
        columnNumber: 9
      }, this),
      item.hiddenAt ? /* @__PURE__ */ jsxDEV(Button, { size: "sm", variant: "secondary", disabled: busy, onClick: onRestore, children: [
        /* @__PURE__ */ jsxDEV(Eye, { size: 14, "aria-hidden": true }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Admin.tsx",
          lineNumber: 285,
          columnNumber: 13
        }, this),
        t("admin.restore")
      ] }, void 0, true, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Admin.tsx",
        lineNumber: 284,
        columnNumber: 9
      }, this) : /* @__PURE__ */ jsxDEV(Button, { size: "sm", variant: "ghost", disabled: busy, onClick: onHide, children: [
        /* @__PURE__ */ jsxDEV(EyeOff, { size: 14, "aria-hidden": true }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Admin.tsx",
          lineNumber: 290,
          columnNumber: 13
        }, this),
        t("admin.hide")
      ] }, void 0, true, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Admin.tsx",
        lineNumber: 289,
        columnNumber: 9
      }, this),
      item.ownerTrust === "unverified" && /* @__PURE__ */ jsxDEV(Button, { size: "sm", disabled: busy, onClick: onReview, children: [
        /* @__PURE__ */ jsxDEV(ClipboardList, { size: 14, "aria-hidden": true }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Admin.tsx",
          lineNumber: 297,
          columnNumber: 13
        }, this),
        t("admin.review"),
        /* @__PURE__ */ jsxDEV(ChevronRight, { size: 14, "aria-hidden": true }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Admin.tsx",
          lineNumber: 299,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Admin.tsx",
        lineNumber: 296,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Admin.tsx",
      lineNumber: 262,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Admin.tsx",
    lineNumber: 229,
    columnNumber: 5
  }, this);
}
_s2(QueueCard, "82N5KF9nLzZ6+2WH7KIjzIXRkLw=", false, function() {
  return [useI18n];
});
_c2 = QueueCard;
var _c, _c2;
$RefreshReg$(_c, "Admin");
$RefreshReg$(_c2, "QueueCard");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/I2I Project - Habito/App Folder/habito/src/pages/Admin.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/I2I Project - Habito/App Folder/habito/src/pages/Admin.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNERNLFNBa0JJLFVBbEJKOzs7Ozs7Ozs7Ozs7Ozs7OztBQTVETixTQUFTQSxhQUFhQyxXQUFXQyxnQkFBZ0I7QUFDakQsU0FBU0MsWUFBWTtBQUNyQjtBQUFBLEVBQ0VDO0FBQUFBLEVBQWFDO0FBQUFBLEVBQVFDO0FBQUFBLEVBQUtDO0FBQUFBLEVBQU1DO0FBQUFBLEVBQU1DO0FBQUFBLEVBQU9DO0FBQUFBLEVBQUdDO0FBQUFBLEVBQWNDO0FBQUFBLE9BQ3pEO0FBQ1AsU0FBU0MsVUFBVTtBQUNuQixTQUFTQyxlQUFlO0FBQ3hCLFNBQVNDLGtCQUFrQjtBQUMzQixTQUFTQyxjQUFjO0FBQ3ZCLFNBQVNDLGFBQWE7QUFDdEIsU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLGdCQUFnQjtBQUV6QixTQUFTQyxVQUFVO0FBU25CLHdCQUF3QkMsUUFBUTtBQUFBQyxLQUFBO0FBQzlCLFFBQU0sRUFBRUMsRUFBRSxJQUFJVCxRQUFRO0FBQ3RCLFFBQU0sRUFBRVUsT0FBTyxJQUFJTCxTQUFTO0FBRTVCLFFBQU0sQ0FBQ00sT0FBT0MsUUFBUSxJQUFJeEIsU0FBOEIsSUFBSTtBQUM1RCxRQUFNLENBQUN5QixNQUFNQyxPQUFPLElBQUkxQixTQUF3QixJQUFJO0FBQ3BELFFBQU0sQ0FBQzJCLFdBQVdDLFlBQVksSUFBSTVCLFNBQTRCLElBQUk7QUFDbEUsUUFBTSxDQUFDNkIsTUFBTUMsT0FBTyxJQUFJOUIsU0FBUyxFQUFFO0FBRW5DLFFBQU0rQixPQUFPakMsWUFBWSxZQUFZO0FBQ25DLFFBQUk7QUFDRjBCLGVBQVMsTUFBTWIsR0FBR3FCLFlBQVksQ0FBQztBQUFBLElBQ2pDLFFBQVE7QUFDTlIsZUFBUyxFQUFFO0FBQUEsSUFDYjtBQUFBLEVBQ0YsR0FBRyxFQUFFO0FBRUx6QixZQUFVLE1BQU07QUFDZCxTQUFLZ0MsS0FBSztBQUFBLEVBQ1osR0FBRyxDQUFDQSxJQUFJLENBQUM7QUFFVCxRQUFNRSxNQUFNLE9BQU9DLE1BQWtCQyxLQUEwQkMsWUFBb0I7QUFDakZWLFlBQVFRLEtBQUtHLE9BQU87QUFDcEIsUUFBSTtBQUNGLFlBQU1GLElBQUk7QUFDVixZQUFNSixLQUFLO0FBQ1hULGFBQU9jLE9BQU87QUFBQSxJQUNoQixTQUFTRSxHQUFHO0FBQ1ZoQixhQUFPZ0IsYUFBYUMsUUFBUUQsRUFBRUYsVUFBVWYsRUFBRSxtQkFBbUIsQ0FBQztBQUFBLElBQ2hFLFVBQUM7QUFDQ0ssY0FBUSxJQUFJO0FBQ1pFLG1CQUFhLElBQUk7QUFDakJFLGNBQVEsRUFBRTtBQUFBLElBQ1o7QUFBQSxFQUNGO0FBRUEsU0FDRSxtQ0FDRTtBQUFBLDJCQUFDLGNBQVcsT0FBT1QsRUFBRSxhQUFhLEdBQUcsTUFBTUEsRUFBRSxZQUFZLEtBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBMkQ7QUFBQSxJQUUzRCx1QkFBQyxTQUFJLFdBQVUsMENBQ1pFLG9CQUFVLE9BQ1QsdUJBQUMsU0FBSSxXQUFVLGFBQ1osV0FBQyxHQUFHLEdBQUcsQ0FBQyxFQUFFaUI7QUFBQUEsTUFBSSxDQUFDQyxNQUNkLHVCQUFDLFlBQWlCLFdBQVUsOEJBQWJBLEdBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFzRDtBQUFBLElBQ3ZELEtBSEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUlBLElBQ0VsQixNQUFNbUIsV0FBVyxJQUNuQix1QkFBQyxTQUFJLFdBQVUsa0dBQ2I7QUFBQSw2QkFBQyxVQUFLLFdBQVUsb0ZBQ2QsaUNBQUMsU0FBTSxNQUFNLElBQUksZUFBVyxRQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTRCLEtBRDlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsUUFBRyxXQUFVLDJDQUEyQ3JCLFlBQUUsYUFBYSxLQUF4RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTBFO0FBQUEsTUFDMUUsdUJBQUMsT0FBRSxXQUFVLG9DQUFvQ0EsWUFBRSxpQkFBaUIsS0FBcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFzRTtBQUFBLFNBTHhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FNQSxJQUVBLG1DQUNFO0FBQUEsNkJBQUMsT0FBRSxXQUFVLDJCQUEyQkEsWUFBRSxlQUFlLEVBQUVzQixPQUFPcEIsTUFBTW1CLE9BQU8sQ0FBQyxLQUFoRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWtGO0FBQUEsTUFDbEYsdUJBQUMsUUFBRyxXQUFVLGFBQ1huQixnQkFBTWlCO0FBQUFBLFFBQUksQ0FBQ04sU0FDVix1QkFBQyxRQUNDO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQztBQUFBLFlBQ0EsTUFBTVQsU0FBU1MsS0FBS0c7QUFBQUEsWUFDcEIsVUFBVSxNQUFNVCxhQUFhTSxJQUFJO0FBQUEsWUFDakMsUUFBUSxNQUNOLEtBQUtELElBQUlDLE1BQU0sTUFBTXZCLEdBQUdpQyxrQkFBa0JWLEtBQUtHLFNBQVMsS0FBSyxHQUFHaEIsRUFBRSxjQUFjLENBQUM7QUFBQSxZQUVuRixXQUFXLE1BQ1QsS0FBS1ksSUFBSUMsTUFBTSxNQUFNdkIsR0FBR2lDLGtCQUFrQlYsS0FBS0csU0FBUyxJQUFJLEdBQUdoQixFQUFFLGdCQUFnQixDQUFDO0FBQUEsWUFFcEYsa0JBQWtCLE1BQ2hCLEtBQUtZLElBQUlDLE1BQU0sTUFBTXZCLEdBQUdrQyxlQUFlWCxLQUFLRyxTQUFTLElBQUksR0FBR2hCLEVBQUUsd0JBQXdCLENBQUM7QUFBQSxZQUV6RixpQkFBaUIsTUFDZixLQUFLWSxJQUFJQyxNQUFNLE1BQU12QixHQUFHa0MsZUFBZVgsS0FBS0csU0FBUyxLQUFLLEdBQUdoQixFQUFFLHFCQUFxQixDQUFDO0FBQUEsWUFFdkYsa0JBQWtCLE1BQ2hCLEtBQUtZLElBQUlDLE1BQU0sTUFBTXZCLEdBQUdtQyxlQUFlWixLQUFLRyxPQUFPLEdBQUdoQixFQUFFLHdCQUF3QixDQUFDO0FBQUE7QUFBQSxVQWpCckY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBa0JHLEtBbkJJYSxLQUFLRyxTQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFxQkE7QUFBQSxNQUNELEtBeEJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF5QkE7QUFBQSxTQTNCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBNEJBLEtBNUNKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E4Q0E7QUFBQSxJQUdBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxNQUFNVixjQUFjO0FBQUEsUUFDcEIsU0FBUyxNQUFNQyxhQUFhLElBQUk7QUFBQSxRQUNoQyxPQUFPUCxFQUFFLG1CQUFtQjtBQUFBLFFBQzVCLFFBQ0UsdUJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSxpQ0FBQyxVQUFPLFNBQVEsYUFBWSxXQUFTLE1BQUMsU0FBUyxNQUFNTyxhQUFhLElBQUksR0FDbkVQLFlBQUUsZUFBZSxLQURwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0M7QUFBQSxjQUNBLFVBQVVRLEtBQUtrQixLQUFLLEVBQUVMLFdBQVc7QUFBQSxjQUNqQyxTQUFTLE1BQ1BmLGFBQ0EsS0FBS007QUFBQUEsZ0JBQ0hOO0FBQUFBLGdCQUNBLE1BQU1oQixHQUFHcUMsU0FBU3JCLFVBQVVzQixTQUFTLFlBQVlwQixLQUFLa0IsS0FBSyxDQUFDO0FBQUEsZ0JBQzVEMUIsRUFBRSxxQkFBcUI7QUFBQSxjQUN6QjtBQUFBLGNBR0RBLFlBQUUsb0JBQW9CO0FBQUE7QUFBQSxZQVp6QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFhQTtBQUFBLGFBakJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFrQkE7QUFBQSxRQUdGO0FBQUEsaUNBQUMsT0FBRSxXQUFVLHlDQUF5Q0EsWUFBRSxrQkFBa0IsS0FBMUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNEU7QUFBQSxVQUU1RSx1QkFBQyxRQUFHLFdBQVUsMENBQ1gsV0FBQyxnQkFBZ0IsZ0JBQWdCLGdCQUFnQixjQUFjLEVBQUVtQjtBQUFBQSxZQUFJLENBQUNVLEtBQUtULE1BQzFFLHVCQUFDLFFBQWEsV0FBVSxnQkFDdEI7QUFBQSxxQ0FBQyxVQUFLLFdBQVUsb0hBQ2JBLGNBQUksS0FEUDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQ3BCLEVBQUU2QixHQUFZO0FBQUEsaUJBSlJBLEtBQVQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFLQTtBQUFBLFVBQ0QsS0FSSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVNBO0FBQUEsVUFFQSx1QkFBQyxPQUFFLFdBQVUseUVBQ1Y3QixZQUFFLHNCQUFzQixLQUQzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFFQSx1QkFBQyxXQUFNLFdBQVUsY0FDZjtBQUFBLG1DQUFDLFVBQUssV0FBVSxrREFBa0RBLFlBQUUsWUFBWSxLQUFoRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFrRjtBQUFBLFlBQ2xGO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBTTtBQUFBLGdCQUNOLE9BQU9RO0FBQUFBLGdCQUNQLFVBQVUsQ0FBQ1MsTUFBTVIsUUFBUVEsRUFBRWEsT0FBT0MsS0FBSztBQUFBLGdCQUN2QyxhQUFhL0IsRUFBRSx1QkFBdUI7QUFBQSxnQkFDdEMsV0FBVTtBQUFBO0FBQUEsY0FMWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFLNkk7QUFBQSxlQVAvSTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVNBO0FBQUEsVUFDQSx1QkFBQyxPQUFFLFdBQVUsMkJBQTJCQSxZQUFFLGlCQUFpQixLQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE2RDtBQUFBO0FBQUE7QUFBQSxNQXJEL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBc0RBO0FBQUEsT0ExR0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTJHQTtBQUVKO0FBQUNELEdBbEp1QkQsT0FBSztBQUFBLFVBQ2JQLFNBQ0tLLFFBQVE7QUFBQTtBQUFBLEtBRkxFO0FBb0p4QixNQUFNa0MsaUJBQWlCO0FBQUEsRUFDckI7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQTBCO0FBRzVCLFNBQVNDLFVBQVU7QUFBQSxFQUNqQnBCO0FBQUFBLEVBQ0FUO0FBQUFBLEVBQ0E4QjtBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQVVGLEdBQUc7QUFBQUMsTUFBQTtBQUNELFFBQU0sRUFBRXhDLEVBQUUsSUFBSVQsUUFBUTtBQUV0QixRQUFNa0QsU0FDSjVCLEtBQUs2QixhQUFhLE9BQ2QsRUFBRWIsS0FBSyxzQkFBc0JjLE1BQU03RCxRQUFROEQsT0FBTyxFQUFFLElBQ3BEL0IsS0FBS2dDLGNBQWMsSUFDakIsRUFBRWhCLEtBQUssd0JBQXdCYyxNQUFNMUQsTUFBTTJELE9BQU8sRUFBRSxJQUNwRC9CLEtBQUtpQyxtQkFDSCxFQUFFakIsS0FBSyx5QkFBeUJjLE1BQU0zRCxNQUFNNEQsT0FBTyxFQUFFLElBQ3JELEVBQUVmLEtBQUssMEJBQTBCYyxNQUFNOUQsYUFBYStELE9BQU8sRUFBRTtBQUV2RSxTQUNFLHVCQUFDLGFBQVEsV0FBVSwyREFDakI7QUFBQSwyQkFBQyxTQUFJLFdBQVUsb0NBQ2I7QUFBQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsV0FBVy9DO0FBQUFBLFlBQ1Q7QUFBQSxZQUNBbUMsZUFBZVMsT0FBT0csS0FBSztBQUFBLFVBQzdCO0FBQUEsVUFFQTtBQUFBLG1DQUFDLE9BQU8sTUFBUCxFQUFZLE1BQU0sSUFBSSxlQUFXLFFBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWtDO0FBQUEsWUFDakM1QyxFQUFFeUMsT0FBT1osR0FBWTtBQUFBO0FBQUE7QUFBQSxRQVB4QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFRQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLGtCQUNiO0FBQUE7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLElBQUksVUFBVWhCLEtBQUtHLE9BQU87QUFBQSxZQUMxQixXQUFVO0FBQUEsWUFFVEgsZUFBS2tDO0FBQUFBO0FBQUFBLFVBSlI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBS0E7QUFBQSxRQUNBLHVCQUFDLE9BQUUsV0FBVSw2QkFDVmxDO0FBQUFBLGVBQUttQyxRQUFRO0FBQUEsVUFBSTtBQUFBLFVBQUluQyxLQUFLb0M7QUFBQUEsVUFBVTtBQUFBLFVBQUc7QUFBQSxVQUN4Qyx1QkFBQyxVQUFLLFdBQVUsZUFBZWpELFlBQUUsY0FBY2EsS0FBS3FDLFVBQVUsRUFBVyxLQUF6RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEyRTtBQUFBLGFBRjdFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBQ0EsdUJBQUMsT0FBRSxXQUFVLDJCQUNWbEQ7QUFBQUEsWUFBRSxzQkFBc0IsRUFBRW1ELE9BQU90QyxLQUFLdUMsYUFBYSxDQUFDO0FBQUEsVUFDcER2QyxLQUFLd0MsY0FBYyxLQUFLLE1BQU1yRCxFQUFFLG1CQUFtQixFQUFFc0IsT0FBT1QsS0FBS3dDLFlBQVksQ0FBQyxDQUFDO0FBQUEsYUFGbEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFDQ3hDLEtBQUt5QyxnQkFDSix1QkFBQyxPQUFFLFdBQVUsd0RBQXdEekMsZUFBS3lDLGdCQUExRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXVGO0FBQUEsV0FoQjNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFrQkE7QUFBQSxTQTdCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBOEJBO0FBQUEsSUFFQSx1QkFBQyxTQUFJLFdBQVUsNkJBQ1p6QztBQUFBQSxXQUFLZ0MsY0FBYyxLQUNsQixtQ0FDRTtBQUFBLCtCQUFDLFVBQU8sTUFBSyxNQUFLLFNBQVEsYUFBWSxVQUFVekMsTUFBTSxTQUFTaUMsa0JBQzdEO0FBQUEsaUNBQUMsS0FBRSxNQUFNLElBQUksZUFBVyxRQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF3QjtBQUFBLFVBQ3ZCckMsRUFBRSxzQkFBc0I7QUFBQSxhQUYzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUNBLHVCQUFDLFVBQU8sTUFBSyxNQUFLLFNBQVEsZUFBYyxVQUFVSSxNQUFNLFNBQVNrQyxpQkFDL0Q7QUFBQSxpQ0FBQyxRQUFLLE1BQU0sSUFBSSxlQUFXLFFBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJCO0FBQUEsVUFDMUJ0QyxFQUFFLHFCQUFxQjtBQUFBLGFBRjFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFdBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVNBO0FBQUEsTUFHRGEsS0FBS2lDLG9CQUNKLHVCQUFDLFVBQU8sTUFBSyxNQUFLLFNBQVEsYUFBWSxVQUFVMUMsTUFBTSxTQUFTbUMsa0JBQzdEO0FBQUEsK0JBQUMsUUFBSyxNQUFNLElBQUksZUFBVyxRQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTJCO0FBQUEsUUFDMUJ2QyxFQUFFLG9CQUFvQjtBQUFBLFdBRnpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BR0RhLEtBQUs2QixXQUNKLHVCQUFDLFVBQU8sTUFBSyxNQUFLLFNBQVEsYUFBWSxVQUFVdEMsTUFBTSxTQUFTZ0MsV0FDN0Q7QUFBQSwrQkFBQyxPQUFJLE1BQU0sSUFBSSxlQUFXLFFBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMEI7QUFBQSxRQUN6QnBDLEVBQUUsZUFBZTtBQUFBLFdBRnBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQSxJQUVBLHVCQUFDLFVBQU8sTUFBSyxNQUFLLFNBQVEsU0FBUSxVQUFVSSxNQUFNLFNBQVMrQixRQUN6RDtBQUFBLCtCQUFDLFVBQU8sTUFBTSxJQUFJLGVBQVcsUUFBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE2QjtBQUFBLFFBQzVCbkMsRUFBRSxZQUFZO0FBQUEsV0FGakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFHRGEsS0FBS3FDLGVBQWUsZ0JBQ25CLHVCQUFDLFVBQU8sTUFBSyxNQUFLLFVBQVU5QyxNQUFNLFNBQVM4QixVQUN6QztBQUFBLCtCQUFDLGlCQUFjLE1BQU0sSUFBSSxlQUFXLFFBQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBb0M7QUFBQSxRQUNuQ2xDLEVBQUUsY0FBYztBQUFBLFFBQ2pCLHVCQUFDLGdCQUFhLE1BQU0sSUFBSSxlQUFXLFFBQW5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbUM7QUFBQSxXQUhyQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBSUE7QUFBQSxTQXRDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBd0NBO0FBQUEsT0F6RUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTBFQTtBQUVKO0FBQUN3QyxJQTNHUVAsV0FBUztBQUFBLFVBbUJGMUMsT0FBTztBQUFBO0FBQUEsTUFuQmQwQztBQUFTLElBQUFzQixJQUFBQztBQUFBLGFBQUFELElBQUE7QUFBQSxhQUFBQyxLQUFBIiwibmFtZXMiOlsidXNlQ2FsbGJhY2siLCJ1c2VFZmZlY3QiLCJ1c2VTdGF0ZSIsIkxpbmsiLCJTaGllbGRDaGVjayIsIkV5ZU9mZiIsIkV5ZSIsIkNvcHkiLCJGbGFnIiwiQ2hlY2siLCJYIiwiQ2hldnJvblJpZ2h0IiwiQ2xpcGJvYXJkTGlzdCIsImRiIiwidXNlSTE4biIsIlBhZ2VIZWFkZXIiLCJCdXR0b24iLCJNb2RhbCIsIlNrZWxldG9uIiwidXNlVG9hc3QiLCJjbiIsIkFkbWluIiwiX3MiLCJ0Iiwibm90aWZ5IiwiaXRlbXMiLCJzZXRJdGVtcyIsImJ1c3kiLCJzZXRCdXN5IiwicmV2aWV3aW5nIiwic2V0UmV2aWV3aW5nIiwibm90ZSIsInNldE5vdGUiLCJsb2FkIiwicmV2aWV3UXVldWUiLCJhY3QiLCJpdGVtIiwicnVuIiwibWVzc2FnZSIsInNwYWNlSWQiLCJlIiwiRXJyb3IiLCJtYXAiLCJpIiwibGVuZ3RoIiwiY291bnQiLCJzZXRMaXN0aW5nVmlzaWJsZSIsInJlc29sdmVSZXBvcnRzIiwiY2xlYXJEdXBsaWNhdGUiLCJ0cmltIiwic2V0VHJ1c3QiLCJvd25lcklkIiwia2V5IiwidGFyZ2V0IiwidmFsdWUiLCJQUklPUklUWV9TVFlMRSIsIlF1ZXVlQ2FyZCIsIm9uUmV2aWV3Iiwib25IaWRlIiwib25SZXN0b3JlIiwib25EaXNtaXNzUmVwb3J0cyIsIm9uVXBob2xkUmVwb3J0cyIsIm9uQ2xlYXJEdXBsaWNhdGUiLCJfczIiLCJyZWFzb24iLCJoaWRkZW5BdCIsImljb24iLCJsZXZlbCIsIm9wZW5SZXBvcnRzIiwiZmxhZ2dlZER1cGxpY2F0ZSIsInNwYWNlTmFtZSIsImFyZWEiLCJvd25lck5hbWUiLCJvd25lclRydXN0Iiwic2NvcmUiLCJjb21wbGV0ZW5lc3MiLCJyZXBvcnRDb3VudCIsImhpZGRlblJlYXNvbiIsIl9jIiwiX2MyIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkFkbWluLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VDYWxsYmFjaywgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgTGluayB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XG5pbXBvcnQge1xuICBTaGllbGRDaGVjaywgRXllT2ZmLCBFeWUsIENvcHksIEZsYWcsIENoZWNrLCBYLCBDaGV2cm9uUmlnaHQsIENsaXBib2FyZExpc3QsXG59IGZyb20gXCJsdWNpZGUtcmVhY3RcIjtcbmltcG9ydCB7IGRiIH0gZnJvbSBcIkAvbGliL2FwaVwiO1xuaW1wb3J0IHsgdXNlSTE4biB9IGZyb20gXCJAL2kxOG5cIjtcbmltcG9ydCB7IFBhZ2VIZWFkZXIgfSBmcm9tIFwiQC9jb21wb25lbnRzL2xheW91dC9QYWdlSGVhZGVyXCI7XG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tIFwiQC9jb21wb25lbnRzL3VpL0J1dHRvblwiO1xuaW1wb3J0IHsgTW9kYWwgfSBmcm9tIFwiQC9jb21wb25lbnRzL3VpL01vZGFsXCI7XG5pbXBvcnQgeyBTa2VsZXRvbiB9IGZyb20gXCJAL2NvbXBvbmVudHMvdWkvU2tlbGV0b25cIjtcbmltcG9ydCB7IHVzZVRvYXN0IH0gZnJvbSBcIkAvY29tcG9uZW50cy91aS9Ub2FzdFwiO1xuaW1wb3J0IHR5cGUgeyBSZXZpZXdJdGVtIH0gZnJvbSBcIkAvdHlwZXMvc3BhY2VcIjtcbmltcG9ydCB7IGNuIH0gZnJvbSBcIkAvbGliL2NuXCI7XG5cbi8qKlxuICogVGhlIHJldmlldyBxdWV1ZS5cbiAqXG4gKiBEZWxpYmVyYXRlbHkgYSBxdWV1ZSBhbmQgbm90IGEgZGFzaGJvYXJkLiBUaGUgam9iIGlzIFwid2hhdCBuZWVkcyBhIGRlY2lzaW9uXG4gKiBuZXh0XCIsIGFuZCBhbnl0aGluZyB0aGF0IGlzbid0IHRoYXQgaXMgYSBkaXN0cmFjdGlvbiBmb3IgdGhlIG9uZSBwZXJzb24gd2hvXG4gKiB3aWxsIGJlIGRvaW5nIHRoaXMgZm9yIGEgZmV3IG1pbnV0ZXMgYSBkYXkuXG4gKi9cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEFkbWluKCkge1xuICBjb25zdCB7IHQgfSA9IHVzZUkxOG4oKTtcbiAgY29uc3QgeyBub3RpZnkgfSA9IHVzZVRvYXN0KCk7XG5cbiAgY29uc3QgW2l0ZW1zLCBzZXRJdGVtc10gPSB1c2VTdGF0ZTxSZXZpZXdJdGVtW10gfCBudWxsPihudWxsKTtcbiAgY29uc3QgW2J1c3ksIHNldEJ1c3ldID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IFtyZXZpZXdpbmcsIHNldFJldmlld2luZ10gPSB1c2VTdGF0ZTxSZXZpZXdJdGVtIHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IFtub3RlLCBzZXROb3RlXSA9IHVzZVN0YXRlKFwiXCIpO1xuXG4gIGNvbnN0IGxvYWQgPSB1c2VDYWxsYmFjayhhc3luYyAoKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIHNldEl0ZW1zKGF3YWl0IGRiLnJldmlld1F1ZXVlKCkpO1xuICAgIH0gY2F0Y2gge1xuICAgICAgc2V0SXRlbXMoW10pO1xuICAgIH1cbiAgfSwgW10pO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgdm9pZCBsb2FkKCk7XG4gIH0sIFtsb2FkXSk7XG5cbiAgY29uc3QgYWN0ID0gYXN5bmMgKGl0ZW06IFJldmlld0l0ZW0sIHJ1bjogKCkgPT4gUHJvbWlzZTx2b2lkPiwgbWVzc2FnZTogc3RyaW5nKSA9PiB7XG4gICAgc2V0QnVzeShpdGVtLnNwYWNlSWQpO1xuICAgIHRyeSB7XG4gICAgICBhd2FpdCBydW4oKTtcbiAgICAgIGF3YWl0IGxvYWQoKTtcbiAgICAgIG5vdGlmeShtZXNzYWdlKTtcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICBub3RpZnkoZSBpbnN0YW5jZW9mIEVycm9yID8gZS5tZXNzYWdlIDogdChcImF1dGguZXJyb3JHZW5lcmljXCIpKTtcbiAgICB9IGZpbmFsbHkge1xuICAgICAgc2V0QnVzeShudWxsKTtcbiAgICAgIHNldFJldmlld2luZyhudWxsKTtcbiAgICAgIHNldE5vdGUoXCJcIik7XG4gICAgfVxuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPD5cbiAgICAgIDxQYWdlSGVhZGVyIHRpdGxlPXt0KFwiYWRtaW4udGl0bGVcIil9IGxlYWQ9e3QoXCJhZG1pbi5sZWFkXCIpfSAvPlxuXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbnRhaW5lci1wYWdlIG1heC13LTR4bCBweS02IG1kOnB5LTEwXCI+XG4gICAgICAgIHtpdGVtcyA9PT0gbnVsbCA/IChcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktM1wiPlxuICAgICAgICAgICAge1swLCAxLCAyXS5tYXAoKGkpID0+IChcbiAgICAgICAgICAgICAgPFNrZWxldG9uIGtleT17aX0gY2xhc3NOYW1lPVwiaC0zMiB3LWZ1bGwgcm91bmRlZC1jYXJkXCIgLz5cbiAgICAgICAgICAgICkpfVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICApIDogaXRlbXMubGVuZ3RoID09PSAwID8gKFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIgcm91bmRlZC1jYXJkIGJnLXN1cmZhY2UgcHgtNiBweS0xNiB0ZXh0LWNlbnRlciByaW5nLTEgcmluZy1oYWlybGluZVwiPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWItNCBmbGV4IHNpemUtMTIgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHJvdW5kZWQtZnVsbCBiZy1vay0xMDAgdGV4dC1vay02MDBcIj5cbiAgICAgICAgICAgICAgPENoZWNrIHNpemU9ezIyfSBhcmlhLWhpZGRlbiAvPlxuICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cImZvbnQtZGlzcGxheSB0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LWlua1wiPnt0KFwiYWRtaW4uY2xlYXJcIil9PC9oMj5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgbWF4LXctc20gdGV4dC1zbSB0ZXh0LW11dGVkXCI+e3QoXCJhZG1pbi5jbGVhckJvZHlcIil9PC9wPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICApIDogKFxuICAgICAgICAgIDw+XG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtYi00IHRleHQtc20gdGV4dC1tdXRlZFwiPnt0KFwiYWRtaW4uY291bnRcIiwgeyBjb3VudDogaXRlbXMubGVuZ3RoIH0pfTwvcD5cbiAgICAgICAgICAgIDx1bCBjbGFzc05hbWU9XCJzcGFjZS15LTNcIj5cbiAgICAgICAgICAgICAge2l0ZW1zLm1hcCgoaXRlbSkgPT4gKFxuICAgICAgICAgICAgICAgIDxsaSBrZXk9e2l0ZW0uc3BhY2VJZH0+XG4gICAgICAgICAgICAgICAgICA8UXVldWVDYXJkXG4gICAgICAgICAgICAgICAgICAgIGl0ZW09e2l0ZW19XG4gICAgICAgICAgICAgICAgICAgIGJ1c3k9e2J1c3kgPT09IGl0ZW0uc3BhY2VJZH1cbiAgICAgICAgICAgICAgICAgICAgb25SZXZpZXc9eygpID0+IHNldFJldmlld2luZyhpdGVtKX1cbiAgICAgICAgICAgICAgICAgICAgb25IaWRlPXsoKSA9PlxuICAgICAgICAgICAgICAgICAgICAgIHZvaWQgYWN0KGl0ZW0sICgpID0+IGRiLnNldExpc3RpbmdWaXNpYmxlKGl0ZW0uc3BhY2VJZCwgZmFsc2UpLCB0KFwiYWRtaW4uaGlkZGVuXCIpKVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIG9uUmVzdG9yZT17KCkgPT5cbiAgICAgICAgICAgICAgICAgICAgICB2b2lkIGFjdChpdGVtLCAoKSA9PiBkYi5zZXRMaXN0aW5nVmlzaWJsZShpdGVtLnNwYWNlSWQsIHRydWUpLCB0KFwiYWRtaW4ucmVzdG9yZWRcIikpXG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgb25EaXNtaXNzUmVwb3J0cz17KCkgPT5cbiAgICAgICAgICAgICAgICAgICAgICB2b2lkIGFjdChpdGVtLCAoKSA9PiBkYi5yZXNvbHZlUmVwb3J0cyhpdGVtLnNwYWNlSWQsIHRydWUpLCB0KFwiYWRtaW4ucmVwb3J0c0Rpc21pc3NlZFwiKSlcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBvblVwaG9sZFJlcG9ydHM9eygpID0+XG4gICAgICAgICAgICAgICAgICAgICAgdm9pZCBhY3QoaXRlbSwgKCkgPT4gZGIucmVzb2x2ZVJlcG9ydHMoaXRlbS5zcGFjZUlkLCBmYWxzZSksIHQoXCJhZG1pbi5yZXBvcnRzVXBoZWxkXCIpKVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIG9uQ2xlYXJEdXBsaWNhdGU9eygpID0+XG4gICAgICAgICAgICAgICAgICAgICAgdm9pZCBhY3QoaXRlbSwgKCkgPT4gZGIuY2xlYXJEdXBsaWNhdGUoaXRlbS5zcGFjZUlkKSwgdChcImFkbWluLmR1cGxpY2F0ZUNsZWFyZWRcIikpXG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICA8L3VsPlxuICAgICAgICAgIDwvPlxuICAgICAgICApfVxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBNYXJraW5nIGFuIG93bmVyIGFzIHJldmlld2VkICovfVxuICAgICAgPE1vZGFsXG4gICAgICAgIG9wZW49e3Jldmlld2luZyAhPT0gbnVsbH1cbiAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0UmV2aWV3aW5nKG51bGwpfVxuICAgICAgICB0aXRsZT17dChcImFkbWluLnJldmlld1RpdGxlXCIpfVxuICAgICAgICBmb290ZXI9e1xuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtMlwiPlxuICAgICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwic2Vjb25kYXJ5XCIgZnVsbFdpZHRoIG9uQ2xpY2s9eygpID0+IHNldFJldmlld2luZyhudWxsKX0+XG4gICAgICAgICAgICAgIHt0KFwiYWN0aW9uLmNhbmNlbFwiKX1cbiAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgICBmdWxsV2lkdGhcbiAgICAgICAgICAgICAgZGlzYWJsZWQ9e25vdGUudHJpbSgpLmxlbmd0aCA9PT0gMH1cbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT5cbiAgICAgICAgICAgICAgICByZXZpZXdpbmcgJiZcbiAgICAgICAgICAgICAgICB2b2lkIGFjdChcbiAgICAgICAgICAgICAgICAgIHJldmlld2luZyxcbiAgICAgICAgICAgICAgICAgICgpID0+IGRiLnNldFRydXN0KHJldmlld2luZy5vd25lcklkLCBcInJldmlld2VkXCIsIG5vdGUudHJpbSgpKSxcbiAgICAgICAgICAgICAgICAgIHQoXCJhZG1pbi5vd25lclJldmlld2VkXCIpLFxuICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICB7dChcImFkbWluLm1hcmtSZXZpZXdlZFwiKX1cbiAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICB9XG4gICAgICA+XG4gICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gbGVhZGluZy1yZWxheGVkIHRleHQtaW5rLXNvZnRcIj57dChcImFkbWluLnJldmlld0JvZHlcIil9PC9wPlxuXG4gICAgICAgIDxvbCBjbGFzc05hbWU9XCJtdC0zIHNwYWNlLXktMS41IHRleHQtc20gdGV4dC1pbmstc29mdFwiPlxuICAgICAgICAgIHtbXCJhZG1pbi5jaGVjazFcIiwgXCJhZG1pbi5jaGVjazJcIiwgXCJhZG1pbi5jaGVjazNcIiwgXCJhZG1pbi5jaGVjazRcIl0ubWFwKChrZXksIGkpID0+IChcbiAgICAgICAgICAgIDxsaSBrZXk9e2tleX0gY2xhc3NOYW1lPVwiZmxleCBnYXAtMi41XCI+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm10LTAuNSBmbGV4IHNpemUtNSBzaHJpbmstMCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC1mdWxsIGJnLWl2b3J5LWRlZXAgdGV4dC1bMC42NXJlbV0gZm9udC1ib2xkIHRudW1cIj5cbiAgICAgICAgICAgICAgICB7aSArIDF9XG4gICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAge3Qoa2V5IGFzIG5ldmVyKX1cbiAgICAgICAgICAgIDwvbGk+XG4gICAgICAgICAgKSl9XG4gICAgICAgIDwvb2w+XG5cbiAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMyByb3VuZGVkLXhsIGJnLXdhcm4tMTAwIHAtMyB0ZXh0LXhzIGxlYWRpbmctcmVsYXhlZCB0ZXh0LXdhcm4tNzAwXCI+XG4gICAgICAgICAge3QoXCJhZG1pbi5kZWxldGVEb2N1bWVudFwiKX1cbiAgICAgICAgPC9wPlxuXG4gICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJtdC00IGJsb2NrXCI+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWItMS41IGJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1pbmstc29mdFwiPnt0KFwiYWRtaW4ubm90ZVwiKX08L3NwYW4+XG4gICAgICAgICAgPHRleHRhcmVhXG4gICAgICAgICAgICByb3dzPXszfVxuICAgICAgICAgICAgdmFsdWU9e25vdGV9XG4gICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldE5vdGUoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgcGxhY2Vob2xkZXI9e3QoXCJhZG1pbi5ub3RlUGxhY2Vob2xkZXJcIil9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcm91bmRlZC14bCBiZy1pdm9yeSBwLTMgdGV4dC1bMC45Mzc1cmVtXSByaW5nLTEgcmluZy1oYWlybGluZS1zdHJvbmcgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWFxdWEtNjAwXCJcbiAgICAgICAgICAvPlxuICAgICAgICA8L2xhYmVsPlxuICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQteHMgdGV4dC1tdXRlZFwiPnt0KFwiYWRtaW4ubm90ZUF1ZGl0XCIpfTwvcD5cbiAgICAgIDwvTW9kYWw+XG4gICAgPC8+XG4gICk7XG59XG5cbmNvbnN0IFBSSU9SSVRZX1NUWUxFID0gW1xuICBcImJnLWRhbmdlci0xMDAgdGV4dC1kYW5nZXItNjAwXCIsXG4gIFwiYmctd2Fybi0xMDAgdGV4dC13YXJuLTcwMFwiLFxuICBcImJnLWxpbGFjLzQwIHRleHQtaW5rXCIsXG4gIFwiYmctaXZvcnktZGVlcCB0ZXh0LW11dGVkXCIsXG4gIFwiYmctaXZvcnktZGVlcCB0ZXh0LW11dGVkXCIsXG5dO1xuXG5mdW5jdGlvbiBRdWV1ZUNhcmQoe1xuICBpdGVtLFxuICBidXN5LFxuICBvblJldmlldyxcbiAgb25IaWRlLFxuICBvblJlc3RvcmUsXG4gIG9uRGlzbWlzc1JlcG9ydHMsXG4gIG9uVXBob2xkUmVwb3J0cyxcbiAgb25DbGVhckR1cGxpY2F0ZSxcbn06IHtcbiAgaXRlbTogUmV2aWV3SXRlbTtcbiAgYnVzeTogYm9vbGVhbjtcbiAgb25SZXZpZXc6ICgpID0+IHZvaWQ7XG4gIG9uSGlkZTogKCkgPT4gdm9pZDtcbiAgb25SZXN0b3JlOiAoKSA9PiB2b2lkO1xuICBvbkRpc21pc3NSZXBvcnRzOiAoKSA9PiB2b2lkO1xuICBvblVwaG9sZFJlcG9ydHM6ICgpID0+IHZvaWQ7XG4gIG9uQ2xlYXJEdXBsaWNhdGU6ICgpID0+IHZvaWQ7XG59KSB7XG4gIGNvbnN0IHsgdCB9ID0gdXNlSTE4bigpO1xuXG4gIGNvbnN0IHJlYXNvbiA9XG4gICAgaXRlbS5oaWRkZW5BdCAhPT0gbnVsbFxuICAgICAgPyB7IGtleTogXCJhZG1pbi5yZWFzb25IaWRkZW5cIiwgaWNvbjogRXllT2ZmLCBsZXZlbDogMCB9XG4gICAgICA6IGl0ZW0ub3BlblJlcG9ydHMgPiAwXG4gICAgICAgID8geyBrZXk6IFwiYWRtaW4ucmVhc29uUmVwb3J0ZWRcIiwgaWNvbjogRmxhZywgbGV2ZWw6IDEgfVxuICAgICAgICA6IGl0ZW0uZmxhZ2dlZER1cGxpY2F0ZVxuICAgICAgICAgID8geyBrZXk6IFwiYWRtaW4ucmVhc29uRHVwbGljYXRlXCIsIGljb246IENvcHksIGxldmVsOiAyIH1cbiAgICAgICAgICA6IHsga2V5OiBcImFkbWluLnJlYXNvblVudmVyaWZpZWRcIiwgaWNvbjogU2hpZWxkQ2hlY2ssIGxldmVsOiAzIH07XG5cbiAgcmV0dXJuIChcbiAgICA8YXJ0aWNsZSBjbGFzc05hbWU9XCJyb3VuZGVkLWNhcmQgYmctc3VyZmFjZSBwLTQgcmluZy0xIHJpbmctaGFpcmxpbmUgc206cC01XCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLXN0YXJ0IGdhcC0zXCI+XG4gICAgICAgIDxzcGFuXG4gICAgICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgICAgIFwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcm91bmRlZC1mdWxsIHB4LTIuNSBweS0xIHRleHQteHMgZm9udC1zZW1pYm9sZFwiLFxuICAgICAgICAgICAgUFJJT1JJVFlfU1RZTEVbcmVhc29uLmxldmVsXSxcbiAgICAgICAgICApfVxuICAgICAgICA+XG4gICAgICAgICAgPHJlYXNvbi5pY29uIHNpemU9ezEzfSBhcmlhLWhpZGRlbiAvPlxuICAgICAgICAgIHt0KHJlYXNvbi5rZXkgYXMgbmV2ZXIpfVxuICAgICAgICA8L3NwYW4+XG5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtaW4tdy0wIGZsZXgtMVwiPlxuICAgICAgICAgIDxMaW5rXG4gICAgICAgICAgICB0bz17YC9zcGFjZS8ke2l0ZW0uc3BhY2VJZH1gfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiZm9udC1kaXNwbGF5IGZvbnQtYm9sZCB0ZXh0LWluayBob3Zlcjp0ZXh0LWFxdWEtNzAwXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICB7aXRlbS5zcGFjZU5hbWV9XG4gICAgICAgICAgPC9MaW5rPlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTAuNSB0ZXh0LXNtIHRleHQtbXV0ZWRcIj5cbiAgICAgICAgICAgIHtpdGVtLmFyZWEgPz8gXCLigJRcIn0gwrcge2l0ZW0ub3duZXJOYW1lfSDCt3tcIiBcIn1cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtXCI+e3QoYHRydXN0LnRpZXIuJHtpdGVtLm93bmVyVHJ1c3R9YCBhcyBuZXZlcil9PC9zcGFuPlxuICAgICAgICAgIDwvcD5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0xIHRleHQteHMgdGV4dC1tdXRlZFwiPlxuICAgICAgICAgICAge3QoXCJhZG1pbi5jb21wbGV0ZW5lc3NcIiwgeyBzY29yZTogaXRlbS5jb21wbGV0ZW5lc3MgfSl9XG4gICAgICAgICAgICB7aXRlbS5yZXBvcnRDb3VudCA+IDAgJiYgYCDCtyAke3QoXCJhZG1pbi5yZXBvcnRlcnNcIiwgeyBjb3VudDogaXRlbS5yZXBvcnRDb3VudCB9KX1gfVxuICAgICAgICAgIDwvcD5cbiAgICAgICAgICB7aXRlbS5oaWRkZW5SZWFzb24gJiYgKFxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiByb3VuZGVkLXhsIGJnLWl2b3J5IHAtMi41IHRleHQteHMgdGV4dC1pbmstc29mdFwiPntpdGVtLmhpZGRlblJlYXNvbn08L3A+XG4gICAgICAgICAgKX1cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC00IGZsZXggZmxleC13cmFwIGdhcC0yXCI+XG4gICAgICAgIHtpdGVtLm9wZW5SZXBvcnRzID4gMCAmJiAoXG4gICAgICAgICAgPD5cbiAgICAgICAgICAgIDxCdXR0b24gc2l6ZT1cInNtXCIgdmFyaWFudD1cInNlY29uZGFyeVwiIGRpc2FibGVkPXtidXN5fSBvbkNsaWNrPXtvbkRpc21pc3NSZXBvcnRzfT5cbiAgICAgICAgICAgICAgPFggc2l6ZT17MTR9IGFyaWEtaGlkZGVuIC8+XG4gICAgICAgICAgICAgIHt0KFwiYWRtaW4uZGlzbWlzc1JlcG9ydHNcIil9XG4gICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgIDxCdXR0b24gc2l6ZT1cInNtXCIgdmFyaWFudD1cImRlc3RydWN0aXZlXCIgZGlzYWJsZWQ9e2J1c3l9IG9uQ2xpY2s9e29uVXBob2xkUmVwb3J0c30+XG4gICAgICAgICAgICAgIDxGbGFnIHNpemU9ezE0fSBhcmlhLWhpZGRlbiAvPlxuICAgICAgICAgICAgICB7dChcImFkbWluLnVwaG9sZFJlcG9ydHNcIil9XG4gICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICA8Lz5cbiAgICAgICAgKX1cblxuICAgICAgICB7aXRlbS5mbGFnZ2VkRHVwbGljYXRlICYmIChcbiAgICAgICAgICA8QnV0dG9uIHNpemU9XCJzbVwiIHZhcmlhbnQ9XCJzZWNvbmRhcnlcIiBkaXNhYmxlZD17YnVzeX0gb25DbGljaz17b25DbGVhckR1cGxpY2F0ZX0+XG4gICAgICAgICAgICA8Q29weSBzaXplPXsxNH0gYXJpYS1oaWRkZW4gLz5cbiAgICAgICAgICAgIHt0KFwiYWRtaW4ubm90RHVwbGljYXRlXCIpfVxuICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICApfVxuXG4gICAgICAgIHtpdGVtLmhpZGRlbkF0ID8gKFxuICAgICAgICAgIDxCdXR0b24gc2l6ZT1cInNtXCIgdmFyaWFudD1cInNlY29uZGFyeVwiIGRpc2FibGVkPXtidXN5fSBvbkNsaWNrPXtvblJlc3RvcmV9PlxuICAgICAgICAgICAgPEV5ZSBzaXplPXsxNH0gYXJpYS1oaWRkZW4gLz5cbiAgICAgICAgICAgIHt0KFwiYWRtaW4ucmVzdG9yZVwiKX1cbiAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgKSA6IChcbiAgICAgICAgICA8QnV0dG9uIHNpemU9XCJzbVwiIHZhcmlhbnQ9XCJnaG9zdFwiIGRpc2FibGVkPXtidXN5fSBvbkNsaWNrPXtvbkhpZGV9PlxuICAgICAgICAgICAgPEV5ZU9mZiBzaXplPXsxNH0gYXJpYS1oaWRkZW4gLz5cbiAgICAgICAgICAgIHt0KFwiYWRtaW4uaGlkZVwiKX1cbiAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgKX1cblxuICAgICAgICB7aXRlbS5vd25lclRydXN0ID09PSBcInVudmVyaWZpZWRcIiAmJiAoXG4gICAgICAgICAgPEJ1dHRvbiBzaXplPVwic21cIiBkaXNhYmxlZD17YnVzeX0gb25DbGljaz17b25SZXZpZXd9PlxuICAgICAgICAgICAgPENsaXBib2FyZExpc3Qgc2l6ZT17MTR9IGFyaWEtaGlkZGVuIC8+XG4gICAgICAgICAgICB7dChcImFkbWluLnJldmlld1wiKX1cbiAgICAgICAgICAgIDxDaGV2cm9uUmlnaHQgc2l6ZT17MTR9IGFyaWEtaGlkZGVuIC8+XG4gICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICl9XG4gICAgICA8L2Rpdj5cbiAgICA8L2FydGljbGU+XG4gICk7XG59XG4iXSwiZmlsZSI6IkQ6L0kySSBQcm9qZWN0IC0gSGFiaXRvL0FwcCBGb2xkZXIvaGFiaXRvL3NyYy9wYWdlcy9BZG1pbi50c3gifQ==