import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/@fs/D:\\I2I Project - Habito\\App Folder\\habito\\src\\pages\\Explore.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=9ceb86a3"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("D:/I2I Project - Habito/App Folder/habito/src/pages/Explore.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9ceb86a3"; const useMemo = __vite__cjsImport3_react["useMemo"];
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=9ceb86a3";
import { ArrowRight } from "/node_modules/.vite/deps/lucide-react.js?v=9ceb86a3";
import { useHabito } from "/src/hooks/useHabito.tsx";
import { PageHeader } from "/src/components/layout/PageHeader.tsx";
import { SpaceCard } from "/src/components/space/SpaceCard.tsx";
import { SpaceCardSkeleton } from "/src/components/ui/Skeleton.tsx";
import { AREAS } from "/src/data/areas.ts";
import { scoreAll } from "/src/lib/matching.ts";
import { daysSince } from "/src/lib/format.ts";
import { useI18n } from "/src/i18n/index.tsx";
export default function Explore() {
  _s();
  const { t } = useI18n();
  const { listings, ready, requirements, hasStatedNeeds, isSaved, toggleSaved, isComparing, toggleCompare } = useHabito();
  const matches = useMemo(() => scoreAll(listings, requirements), [listings, requirements]);
  const nearYou = useMemo(
    () => listings.filter((l) => l.property.area === requirements.area),
    [listings, requirements.area]
  );
  const topMatches = useMemo(
    () => [...listings].sort((a, b) => (matches.get(b.space.id)?.score ?? 0) - (matches.get(a.space.id)?.score ?? 0)).slice(0, 8),
    [listings, matches]
  );
  const newest = useMemo(
    () => [...listings].sort((a, b) => daysSince(a.space.lastUpdated) - daysSince(b.space.lastUpdated)).slice(0, 8),
    [listings]
  );
  const parking = useMemo(
    () => listings.filter((l) => l.space.category === "parking" || l.space.category === "storage"),
    [listings]
  );
  const forSale = useMemo(() => listings.filter((l) => l.space.transaction === "sale"), [listings]);
  const handlers = {
    isSaved,
    isComparing,
    onToggleSave: (id) => void toggleSaved(id),
    onToggleCompare: toggleCompare,
    matches: hasStatedNeeds ? matches : void 0,
    ready
  };
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(
      PageHeader,
      {
        title: t("explore.title"),
        lead: "Wander through what's on the platform — by area, by category, by what's just been added."
      },
      void 0,
      false,
      {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Explore.tsx",
        lineNumber: 74,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { className: "py-6", children: [
      /* @__PURE__ */ jsxDEV(AreaStrip, { listings }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Explore.tsx",
        lineNumber: 80,
        columnNumber: 9
      }, this),
      hasStatedNeeds && /* @__PURE__ */ jsxDEV(Rail, { title: t("explore.closest"), lead: t("explore.closestLead"), to: "/search", items: topMatches, ...handlers }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Explore.tsx",
        lineNumber: 83,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        Rail,
        {
          title: `Around ${requirements.area}`,
          lead: "Spaces in the area you last searched.",
          to: `/search?area=${encodeURIComponent(requirements.area)}`,
          items: nearYou.slice(0, 8),
          ...handlers
        },
        void 0,
        false,
        {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Explore.tsx",
          lineNumber: 86,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(Rail, { title: t("explore.justAdded"), lead: t("explore.justAddedLead"), to: "/search", items: newest, ...handlers }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Explore.tsx",
        lineNumber: 94,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        Rail,
        {
          title: t("explore.parkStore"),
          lead: "Garages, slots and godowns — the spaces nobody else lists properly.",
          to: "/search?category=parking",
          items: parking.slice(0, 8),
          ...handlers
        },
        void 0,
        false,
        {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Explore.tsx",
          lineNumber: 96,
          columnNumber: 9
        },
        this
      ),
      forSale.length > 0 && /* @__PURE__ */ jsxDEV(Rail, { title: t("explore.forSale"), lead: t("explore.forSaleLead"), to: "/search", items: forSale.slice(0, 8), ...handlers }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Explore.tsx",
        lineNumber: 105,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Explore.tsx",
      lineNumber: 79,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Explore.tsx",
    lineNumber: 73,
    columnNumber: 5
  }, this);
}
_s(Explore, "PiHod40U12oz/z4Cl9rdwb6f55E=", false, function() {
  return [useI18n, useHabito];
});
_c = Explore;
function AreaStrip({ listings }) {
  const counts = AREAS.map((a) => ({
    area: a,
    count: listings.filter((l) => l.property.area === a.name).length
  })).filter((x) => x.count > 0).sort((a, b) => b.count - a.count);
  return /* @__PURE__ */ jsxDEV("section", { className: "container-page pb-4", children: [
    /* @__PURE__ */ jsxDEV("h2", { className: "font-display text-xl font-bold text-ink", children: "Where people are looking" }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Explore.tsx",
      lineNumber: 122,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("ul", { className: "mt-4 flex gap-2.5 overflow-x-auto pb-2 hide-scrollbar", children: counts.map(
      ({ area, count }) => /* @__PURE__ */ jsxDEV("li", { className: "shrink-0", children: /* @__PURE__ */ jsxDEV(
        Link,
        {
          to: `/search?area=${encodeURIComponent(area.name)}`,
          className: "flex min-w-40 flex-col gap-1 rounded-2xl bg-surface p-4 ring-1 ring-hairline transition-all hover:-translate-y-0.5 hover:ring-ink",
          children: [
            /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-ink", children: area.name }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Explore.tsx",
              lineNumber: 130,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "text-xs capitalize text-muted", children: area.geography }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Explore.tsx",
              lineNumber: 131,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "mt-1 text-sm font-semibold tnum text-aqua-700", children: [
              count,
              " spaces"
            ] }, void 0, true, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Explore.tsx",
              lineNumber: 132,
              columnNumber: 15
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Explore.tsx",
          lineNumber: 126,
          columnNumber: 13
        },
        this
      ) }, area.id, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Explore.tsx",
        lineNumber: 125,
        columnNumber: 9
      }, this)
    ) }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Explore.tsx",
      lineNumber: 123,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Explore.tsx",
    lineNumber: 121,
    columnNumber: 5
  }, this);
}
_c2 = AreaStrip;
function Rail({
  title,
  lead,
  to,
  items,
  ready,
  matches,
  isSaved,
  isComparing,
  onToggleSave,
  onToggleCompare
}) {
  if (ready && items.length === 0) return null;
  return /* @__PURE__ */ jsxDEV("section", { className: "py-6", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "container-page flex flex-wrap items-end justify-between gap-3", children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "font-display text-2xl font-bold text-ink", children: title }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Explore.tsx",
          lineNumber: 170,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-muted", children: lead }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Explore.tsx",
          lineNumber: 171,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Explore.tsx",
        lineNumber: 169,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Link, { to, className: "inline-flex items-center gap-1.5 text-sm font-semibold text-aqua-700 hover:text-ink", children: [
        "See all",
        /* @__PURE__ */ jsxDEV(ArrowRight, { size: 15, "aria-hidden": true }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Explore.tsx",
          lineNumber: 175,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Explore.tsx",
        lineNumber: 173,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Explore.tsx",
      lineNumber: 168,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "mt-5 flex gap-4 overflow-x-auto px-5 pb-2 hide-scrollbar md:px-8", children: !ready ? Array.from(
      { length: 4 },
      (_, i) => /* @__PURE__ */ jsxDEV("div", { className: "w-68 shrink-0 sm:w-76", children: /* @__PURE__ */ jsxDEV(SpaceCardSkeleton, {}, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Explore.tsx",
        lineNumber: 183,
        columnNumber: 17
      }, this) }, i, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Explore.tsx",
        lineNumber: 182,
        columnNumber: 9
      }, this)
    ) : items.map(
      (l) => /* @__PURE__ */ jsxDEV("div", { className: "w-68 shrink-0 sm:w-76", children: /* @__PURE__ */ jsxDEV(
        SpaceCard,
        {
          listing: l,
          matchScore: matches?.get(l.space.id)?.score,
          saved: isSaved(l.space.id),
          comparing: isComparing(l.space.id),
          onToggleSave,
          onToggleCompare
        },
        void 0,
        false,
        {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Explore.tsx",
          lineNumber: 188,
          columnNumber: 17
        },
        this
      ) }, l.space.id, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Explore.tsx",
        lineNumber: 187,
        columnNumber: 9
      }, this)
    ) }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Explore.tsx",
      lineNumber: 179,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Explore.tsx",
    lineNumber: 167,
    columnNumber: 5
  }, this);
}
_c3 = Rail;
var _c, _c2, _c3;
$RefreshReg$(_c, "Explore");
$RefreshReg$(_c2, "AreaStrip");
$RefreshReg$(_c3, "Rail");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/I2I Project - Habito/App Folder/habito/src/pages/Explore.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/I2I Project - Habito/App Folder/habito/src/pages/Explore.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcURJLG1CQUNFLGNBREY7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBckRKLFNBQVNBLGVBQWU7QUFDeEIsU0FBU0MsWUFBWTtBQUNyQixTQUFTQyxrQkFBa0I7QUFDM0IsU0FBU0MsaUJBQWlCO0FBQzFCLFNBQVNDLGtCQUFrQjtBQUMzQixTQUFTQyxpQkFBaUI7QUFDMUIsU0FBU0MseUJBQXlCO0FBQ2xDLFNBQVNDLGFBQWE7QUFDdEIsU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLGlCQUFpQjtBQUMxQixTQUFTQyxlQUFlO0FBSXhCLHdCQUF3QkMsVUFBVTtBQUFBQyxLQUFBO0FBQ2hDLFFBQU0sRUFBRUMsRUFBRSxJQUFJSCxRQUFRO0FBQ3RCLFFBQU0sRUFBRUksVUFBVUMsT0FBT0MsY0FBY0MsZ0JBQWdCQyxTQUFTQyxhQUFhQyxhQUFhQyxjQUFjLElBQ3RHbEIsVUFBVTtBQUVaLFFBQU1tQixVQUFVdEIsUUFBUSxNQUFNUSxTQUFTTSxVQUFVRSxZQUFZLEdBQUcsQ0FBQ0YsVUFBVUUsWUFBWSxDQUFDO0FBRXhGLFFBQU1PLFVBQVV2QjtBQUFBQSxJQUNkLE1BQU1jLFNBQVNVLE9BQU8sQ0FBQ0MsTUFBTUEsRUFBRUMsU0FBU0MsU0FBU1gsYUFBYVcsSUFBSTtBQUFBLElBQ2xFLENBQUNiLFVBQVVFLGFBQWFXLElBQUk7QUFBQSxFQUM5QjtBQUVBLFFBQU1DLGFBQWE1QjtBQUFBQSxJQUNqQixNQUFNLENBQUMsR0FBR2MsUUFBUSxFQUFFZSxLQUFLLENBQUNDLEdBQUdDLE9BQU9ULFFBQVFVLElBQUlELEVBQUVFLE1BQU1DLEVBQUUsR0FBR0MsU0FBUyxNQUFNYixRQUFRVSxJQUFJRixFQUFFRyxNQUFNQyxFQUFFLEdBQUdDLFNBQVMsRUFBRSxFQUFFQyxNQUFNLEdBQUcsQ0FBQztBQUFBLElBQzVILENBQUN0QixVQUFVUSxPQUFPO0FBQUEsRUFDcEI7QUFFQSxRQUFNZSxTQUFTckM7QUFBQUEsSUFDYixNQUFNLENBQUMsR0FBR2MsUUFBUSxFQUFFZSxLQUFLLENBQUNDLEdBQUdDLE1BQU10QixVQUFVcUIsRUFBRUcsTUFBTUssV0FBVyxJQUFJN0IsVUFBVXNCLEVBQUVFLE1BQU1LLFdBQVcsQ0FBQyxFQUFFRixNQUFNLEdBQUcsQ0FBQztBQUFBLElBQzlHLENBQUN0QixRQUFRO0FBQUEsRUFDWDtBQUVBLFFBQU15QixVQUFVdkM7QUFBQUEsSUFDZCxNQUFNYyxTQUFTVSxPQUFPLENBQUNDLE1BQU1BLEVBQUVRLE1BQU1PLGFBQWEsYUFBYWYsRUFBRVEsTUFBTU8sYUFBYSxTQUFTO0FBQUEsSUFDN0YsQ0FBQzFCLFFBQVE7QUFBQSxFQUNYO0FBRUEsUUFBTTJCLFVBQVV6QyxRQUFRLE1BQU1jLFNBQVNVLE9BQU8sQ0FBQ0MsTUFBTUEsRUFBRVEsTUFBTVMsZ0JBQWdCLE1BQU0sR0FBRyxDQUFDNUIsUUFBUSxDQUFDO0FBRWhHLFFBQU02QixXQUFXO0FBQUEsSUFDZnpCO0FBQUFBLElBQ0FFO0FBQUFBLElBQ0F3QixjQUFjQSxDQUFDVixPQUFlLEtBQUtmLFlBQVllLEVBQUU7QUFBQSxJQUNqRFcsaUJBQWlCeEI7QUFBQUEsSUFDakJDLFNBQVNMLGlCQUFpQkssVUFBVXdCO0FBQUFBLElBQ3BDL0I7QUFBQUEsRUFDRjtBQUVBLFNBQ0UsbUNBQ0U7QUFBQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsT0FBT0YsRUFBRSxlQUFlO0FBQUEsUUFDeEIsTUFBSztBQUFBO0FBQUEsTUFGUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFFaUc7QUFBQSxJQUdqRyx1QkFBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLDZCQUFDLGFBQVUsWUFBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQThCO0FBQUEsTUFFN0JJLGtCQUNDLHVCQUFDLFFBQUssT0FBT0osRUFBRSxpQkFBaUIsR0FBRyxNQUFNQSxFQUFFLHFCQUFxQixHQUFHLElBQUcsV0FBVSxPQUFPZSxZQUFZLEdBQUllLFlBQXZHO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBZ0g7QUFBQSxNQUdsSDtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsT0FBTyxVQUFVM0IsYUFBYVcsSUFBSTtBQUFBLFVBQ2xDLE1BQUs7QUFBQSxVQUNMLElBQUksZ0JBQWdCb0IsbUJBQW1CL0IsYUFBYVcsSUFBSSxDQUFDO0FBQUEsVUFDekQsT0FBT0osUUFBUWEsTUFBTSxHQUFHLENBQUM7QUFBQSxVQUN6QixHQUFJTztBQUFBQTtBQUFBQSxRQUxOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUtlO0FBQUEsTUFHZix1QkFBQyxRQUFLLE9BQU85QixFQUFFLG1CQUFtQixHQUFHLE1BQU1BLEVBQUUsdUJBQXVCLEdBQUcsSUFBRyxXQUFVLE9BQU93QixRQUFRLEdBQUlNLFlBQXZHO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBZ0g7QUFBQSxNQUVoSDtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsT0FBTzlCLEVBQUUsbUJBQW1CO0FBQUEsVUFDNUIsTUFBSztBQUFBLFVBQ0wsSUFBRztBQUFBLFVBQ0gsT0FBTzBCLFFBQVFILE1BQU0sR0FBRyxDQUFDO0FBQUEsVUFDekIsR0FBSU87QUFBQUE7QUFBQUEsUUFMTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFLZTtBQUFBLE1BR2RGLFFBQVFPLFNBQVMsS0FDaEIsdUJBQUMsUUFBSyxPQUFPbkMsRUFBRSxpQkFBaUIsR0FBRyxNQUFNQSxFQUFFLHFCQUFxQixHQUFHLElBQUcsV0FBVSxPQUFPNEIsUUFBUUwsTUFBTSxHQUFHLENBQUMsR0FBRyxHQUFJTyxZQUFoSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXlIO0FBQUEsU0ExQjdIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E0QkE7QUFBQSxPQWxDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBbUNBO0FBRUo7QUFBQy9CLEdBNUV1QkQsU0FBTztBQUFBLFVBQ2ZELFNBRVpQLFNBQVM7QUFBQTtBQUFBLEtBSFdRO0FBOEV4QixTQUFTc0MsVUFBVSxFQUFFbkMsU0FBdUMsR0FBRztBQUM3RCxRQUFNb0MsU0FBUzNDLE1BQU00QyxJQUFJLENBQUNyQixPQUFPO0FBQUEsSUFDL0JILE1BQU1HO0FBQUFBLElBQ05zQixPQUFPdEMsU0FBU1UsT0FBTyxDQUFDQyxNQUFNQSxFQUFFQyxTQUFTQyxTQUFTRyxFQUFFdUIsSUFBSSxFQUFFTDtBQUFBQSxFQUM1RCxFQUFFLEVBQ0N4QixPQUFPLENBQUM4QixNQUFNQSxFQUFFRixRQUFRLENBQUMsRUFDekJ2QixLQUFLLENBQUNDLEdBQUdDLE1BQU1BLEVBQUVxQixRQUFRdEIsRUFBRXNCLEtBQUs7QUFFbkMsU0FDRSx1QkFBQyxhQUFRLFdBQVUsdUJBQ2pCO0FBQUEsMkJBQUMsUUFBRyxXQUFVLDJDQUEwQyx3Q0FBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFnRjtBQUFBLElBQ2hGLHVCQUFDLFFBQUcsV0FBVSx5REFDWEYsaUJBQU9DO0FBQUFBLE1BQUksQ0FBQyxFQUFFeEIsTUFBTXlCLE1BQU0sTUFDekIsdUJBQUMsUUFBaUIsV0FBVSxZQUMxQjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsSUFBSSxnQkFBZ0JMLG1CQUFtQnBCLEtBQUswQixJQUFJLENBQUM7QUFBQSxVQUNqRCxXQUFVO0FBQUEsVUFFVjtBQUFBLG1DQUFDLFVBQUssV0FBVSwwQkFBMEIxQixlQUFLMEIsUUFBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBb0Q7QUFBQSxZQUNwRCx1QkFBQyxVQUFLLFdBQVUsaUNBQWlDMUIsZUFBSzRCLGFBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWdFO0FBQUEsWUFDaEUsdUJBQUMsVUFBSyxXQUFVLGlEQUFpREg7QUFBQUE7QUFBQUEsY0FBTTtBQUFBLGlCQUF2RTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE4RTtBQUFBO0FBQUE7QUFBQSxRQU5oRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFPQSxLQVJPekIsS0FBS08sSUFBZDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBU0E7QUFBQSxJQUNELEtBWkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWFBO0FBQUEsT0FmRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBZ0JBO0FBRUo7QUFBQ3NCLE1BM0JRUDtBQTZCVCxTQUFTUSxLQUFLO0FBQUEsRUFDWkM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQTlDO0FBQUFBLEVBQ0FPO0FBQUFBLEVBQ0FKO0FBQUFBLEVBQ0FFO0FBQUFBLEVBQ0F3QjtBQUFBQSxFQUNBQztBQVlGLEdBQUc7QUFDRCxNQUFJOUIsU0FBUzhDLE1BQU1iLFdBQVcsRUFBRyxRQUFPO0FBRXhDLFNBQ0UsdUJBQUMsYUFBUSxXQUFVLFFBQ2pCO0FBQUEsMkJBQUMsU0FBSSxXQUFVLGlFQUNiO0FBQUEsNkJBQUMsU0FDQztBQUFBLCtCQUFDLFFBQUcsV0FBVSw0Q0FBNENVLG1CQUExRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWdFO0FBQUEsUUFDaEUsdUJBQUMsT0FBRSxXQUFVLDJCQUEyQkMsa0JBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNkM7QUFBQSxXQUYvQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUNBLHVCQUFDLFFBQUssSUFBUSxXQUFVLHVGQUFxRjtBQUFBO0FBQUEsUUFFM0csdUJBQUMsY0FBVyxNQUFNLElBQUksZUFBVyxRQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWlDO0FBQUEsV0FGbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsU0FSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBU0E7QUFBQSxJQUVBLHVCQUFDLFNBQUksV0FBVSxvRUFDWixXQUFDNUMsUUFDRStDLE1BQU1DO0FBQUFBLE1BQUssRUFBRWYsUUFBUSxFQUFFO0FBQUEsTUFBRyxDQUFDZ0IsR0FBR0MsTUFDNUIsdUJBQUMsU0FBWSxXQUFVLHlCQUNyQixpQ0FBQyx1QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWtCLEtBRFZBLEdBQVY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsSUFDRCxJQUNESixNQUFNVjtBQUFBQSxNQUFJLENBQUMxQixNQUNULHVCQUFDLFNBQXFCLFdBQVUseUJBQzlCO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxTQUFTQTtBQUFBQSxVQUNULFlBQVlILFNBQVNVLElBQUlQLEVBQUVRLE1BQU1DLEVBQUUsR0FBR0M7QUFBQUEsVUFDdEMsT0FBT2pCLFFBQVFPLEVBQUVRLE1BQU1DLEVBQUU7QUFBQSxVQUN6QixXQUFXZCxZQUFZSyxFQUFFUSxNQUFNQyxFQUFFO0FBQUEsVUFDakM7QUFBQSxVQUNBO0FBQUE7QUFBQSxRQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQU1tQyxLQVAzQlQsRUFBRVEsTUFBTUMsSUFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVNBO0FBQUEsSUFDRCxLQWxCUDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBbUJBO0FBQUEsT0EvQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWdDQTtBQUVKO0FBQUNnQyxNQTVEUVQ7QUFBSSxJQUFBVSxJQUFBWCxLQUFBVTtBQUFBLGFBQUFDLElBQUE7QUFBQSxhQUFBWCxLQUFBO0FBQUEsYUFBQVUsS0FBQSIsIm5hbWVzIjpbInVzZU1lbW8iLCJMaW5rIiwiQXJyb3dSaWdodCIsInVzZUhhYml0byIsIlBhZ2VIZWFkZXIiLCJTcGFjZUNhcmQiLCJTcGFjZUNhcmRTa2VsZXRvbiIsIkFSRUFTIiwic2NvcmVBbGwiLCJkYXlzU2luY2UiLCJ1c2VJMThuIiwiRXhwbG9yZSIsIl9zIiwidCIsImxpc3RpbmdzIiwicmVhZHkiLCJyZXF1aXJlbWVudHMiLCJoYXNTdGF0ZWROZWVkcyIsImlzU2F2ZWQiLCJ0b2dnbGVTYXZlZCIsImlzQ29tcGFyaW5nIiwidG9nZ2xlQ29tcGFyZSIsIm1hdGNoZXMiLCJuZWFyWW91IiwiZmlsdGVyIiwibCIsInByb3BlcnR5IiwiYXJlYSIsInRvcE1hdGNoZXMiLCJzb3J0IiwiYSIsImIiLCJnZXQiLCJzcGFjZSIsImlkIiwic2NvcmUiLCJzbGljZSIsIm5ld2VzdCIsImxhc3RVcGRhdGVkIiwicGFya2luZyIsImNhdGVnb3J5IiwiZm9yU2FsZSIsInRyYW5zYWN0aW9uIiwiaGFuZGxlcnMiLCJvblRvZ2dsZVNhdmUiLCJvblRvZ2dsZUNvbXBhcmUiLCJ1bmRlZmluZWQiLCJlbmNvZGVVUklDb21wb25lbnQiLCJsZW5ndGgiLCJBcmVhU3RyaXAiLCJjb3VudHMiLCJtYXAiLCJjb3VudCIsIm5hbWUiLCJ4IiwiZ2VvZ3JhcGh5IiwiX2MyIiwiUmFpbCIsInRpdGxlIiwibGVhZCIsInRvIiwiaXRlbXMiLCJBcnJheSIsImZyb20iLCJfIiwiaSIsIl9jMyIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkV4cGxvcmUudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZU1lbW8gfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IExpbmsgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xuaW1wb3J0IHsgQXJyb3dSaWdodCB9IGZyb20gXCJsdWNpZGUtcmVhY3RcIjtcbmltcG9ydCB7IHVzZUhhYml0byB9IGZyb20gXCJAL2hvb2tzL3VzZUhhYml0b1wiO1xuaW1wb3J0IHsgUGFnZUhlYWRlciB9IGZyb20gXCJAL2NvbXBvbmVudHMvbGF5b3V0L1BhZ2VIZWFkZXJcIjtcbmltcG9ydCB7IFNwYWNlQ2FyZCB9IGZyb20gXCJAL2NvbXBvbmVudHMvc3BhY2UvU3BhY2VDYXJkXCI7XG5pbXBvcnQgeyBTcGFjZUNhcmRTa2VsZXRvbiB9IGZyb20gXCJAL2NvbXBvbmVudHMvdWkvU2tlbGV0b25cIjtcbmltcG9ydCB7IEFSRUFTIH0gZnJvbSBcIkAvZGF0YS9hcmVhc1wiO1xuaW1wb3J0IHsgc2NvcmVBbGwgfSBmcm9tIFwiQC9saWIvbWF0Y2hpbmdcIjtcbmltcG9ydCB7IGRheXNTaW5jZSB9IGZyb20gXCJAL2xpYi9mb3JtYXRcIjtcbmltcG9ydCB7IHVzZUkxOG4gfSBmcm9tIFwiQC9pMThuXCI7XG5pbXBvcnQgdHlwZSB7IFNwYWNlTGlzdGluZyB9IGZyb20gXCJAL3R5cGVzL3NwYWNlXCI7XG5cbi8qKiBEaXNjb3ZlcnkgcmF0aGVyIHRoYW4gYSByZXN1bHRzIGdyaWQ6IGVhY2ggcmFpbCBhbnN3ZXJzIGEgZGlmZmVyZW50IHF1ZXN0aW9uLiAqL1xuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gRXhwbG9yZSgpIHtcbiAgY29uc3QgeyB0IH0gPSB1c2VJMThuKCk7XG4gIGNvbnN0IHsgbGlzdGluZ3MsIHJlYWR5LCByZXF1aXJlbWVudHMsIGhhc1N0YXRlZE5lZWRzLCBpc1NhdmVkLCB0b2dnbGVTYXZlZCwgaXNDb21wYXJpbmcsIHRvZ2dsZUNvbXBhcmUgfSA9XG4gICAgdXNlSGFiaXRvKCk7XG5cbiAgY29uc3QgbWF0Y2hlcyA9IHVzZU1lbW8oKCkgPT4gc2NvcmVBbGwobGlzdGluZ3MsIHJlcXVpcmVtZW50cyksIFtsaXN0aW5ncywgcmVxdWlyZW1lbnRzXSk7XG5cbiAgY29uc3QgbmVhcllvdSA9IHVzZU1lbW8oXG4gICAgKCkgPT4gbGlzdGluZ3MuZmlsdGVyKChsKSA9PiBsLnByb3BlcnR5LmFyZWEgPT09IHJlcXVpcmVtZW50cy5hcmVhKSxcbiAgICBbbGlzdGluZ3MsIHJlcXVpcmVtZW50cy5hcmVhXSxcbiAgKTtcblxuICBjb25zdCB0b3BNYXRjaGVzID0gdXNlTWVtbyhcbiAgICAoKSA9PiBbLi4ubGlzdGluZ3NdLnNvcnQoKGEsIGIpID0+IChtYXRjaGVzLmdldChiLnNwYWNlLmlkKT8uc2NvcmUgPz8gMCkgLSAobWF0Y2hlcy5nZXQoYS5zcGFjZS5pZCk/LnNjb3JlID8/IDApKS5zbGljZSgwLCA4KSxcbiAgICBbbGlzdGluZ3MsIG1hdGNoZXNdLFxuICApO1xuXG4gIGNvbnN0IG5ld2VzdCA9IHVzZU1lbW8oXG4gICAgKCkgPT4gWy4uLmxpc3RpbmdzXS5zb3J0KChhLCBiKSA9PiBkYXlzU2luY2UoYS5zcGFjZS5sYXN0VXBkYXRlZCkgLSBkYXlzU2luY2UoYi5zcGFjZS5sYXN0VXBkYXRlZCkpLnNsaWNlKDAsIDgpLFxuICAgIFtsaXN0aW5nc10sXG4gICk7XG5cbiAgY29uc3QgcGFya2luZyA9IHVzZU1lbW8oXG4gICAgKCkgPT4gbGlzdGluZ3MuZmlsdGVyKChsKSA9PiBsLnNwYWNlLmNhdGVnb3J5ID09PSBcInBhcmtpbmdcIiB8fCBsLnNwYWNlLmNhdGVnb3J5ID09PSBcInN0b3JhZ2VcIiksXG4gICAgW2xpc3RpbmdzXSxcbiAgKTtcblxuICBjb25zdCBmb3JTYWxlID0gdXNlTWVtbygoKSA9PiBsaXN0aW5ncy5maWx0ZXIoKGwpID0+IGwuc3BhY2UudHJhbnNhY3Rpb24gPT09IFwic2FsZVwiKSwgW2xpc3RpbmdzXSk7XG5cbiAgY29uc3QgaGFuZGxlcnMgPSB7XG4gICAgaXNTYXZlZCxcbiAgICBpc0NvbXBhcmluZyxcbiAgICBvblRvZ2dsZVNhdmU6IChpZDogc3RyaW5nKSA9PiB2b2lkIHRvZ2dsZVNhdmVkKGlkKSxcbiAgICBvblRvZ2dsZUNvbXBhcmU6IHRvZ2dsZUNvbXBhcmUsXG4gICAgbWF0Y2hlczogaGFzU3RhdGVkTmVlZHMgPyBtYXRjaGVzIDogdW5kZWZpbmVkLFxuICAgIHJlYWR5LFxuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPD5cbiAgICAgIDxQYWdlSGVhZGVyXG4gICAgICAgIHRpdGxlPXt0KFwiZXhwbG9yZS50aXRsZVwiKX1cbiAgICAgICAgbGVhZD1cIldhbmRlciB0aHJvdWdoIHdoYXQncyBvbiB0aGUgcGxhdGZvcm0g4oCUIGJ5IGFyZWEsIGJ5IGNhdGVnb3J5LCBieSB3aGF0J3MganVzdCBiZWVuIGFkZGVkLlwiXG4gICAgICAvPlxuXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInB5LTZcIj5cbiAgICAgICAgPEFyZWFTdHJpcCBsaXN0aW5ncz17bGlzdGluZ3N9IC8+XG5cbiAgICAgICAge2hhc1N0YXRlZE5lZWRzICYmIChcbiAgICAgICAgICA8UmFpbCB0aXRsZT17dChcImV4cGxvcmUuY2xvc2VzdFwiKX0gbGVhZD17dChcImV4cGxvcmUuY2xvc2VzdExlYWRcIil9IHRvPVwiL3NlYXJjaFwiIGl0ZW1zPXt0b3BNYXRjaGVzfSB7Li4uaGFuZGxlcnN9IC8+XG4gICAgICAgICl9XG5cbiAgICAgICAgPFJhaWxcbiAgICAgICAgICB0aXRsZT17YEFyb3VuZCAke3JlcXVpcmVtZW50cy5hcmVhfWB9XG4gICAgICAgICAgbGVhZD1cIlNwYWNlcyBpbiB0aGUgYXJlYSB5b3UgbGFzdCBzZWFyY2hlZC5cIlxuICAgICAgICAgIHRvPXtgL3NlYXJjaD9hcmVhPSR7ZW5jb2RlVVJJQ29tcG9uZW50KHJlcXVpcmVtZW50cy5hcmVhKX1gfVxuICAgICAgICAgIGl0ZW1zPXtuZWFyWW91LnNsaWNlKDAsIDgpfVxuICAgICAgICAgIHsuLi5oYW5kbGVyc31cbiAgICAgICAgLz5cblxuICAgICAgICA8UmFpbCB0aXRsZT17dChcImV4cGxvcmUuanVzdEFkZGVkXCIpfSBsZWFkPXt0KFwiZXhwbG9yZS5qdXN0QWRkZWRMZWFkXCIpfSB0bz1cIi9zZWFyY2hcIiBpdGVtcz17bmV3ZXN0fSB7Li4uaGFuZGxlcnN9IC8+XG5cbiAgICAgICAgPFJhaWxcbiAgICAgICAgICB0aXRsZT17dChcImV4cGxvcmUucGFya1N0b3JlXCIpfVxuICAgICAgICAgIGxlYWQ9XCJHYXJhZ2VzLCBzbG90cyBhbmQgZ29kb3ducyDigJQgdGhlIHNwYWNlcyBub2JvZHkgZWxzZSBsaXN0cyBwcm9wZXJseS5cIlxuICAgICAgICAgIHRvPVwiL3NlYXJjaD9jYXRlZ29yeT1wYXJraW5nXCJcbiAgICAgICAgICBpdGVtcz17cGFya2luZy5zbGljZSgwLCA4KX1cbiAgICAgICAgICB7Li4uaGFuZGxlcnN9XG4gICAgICAgIC8+XG5cbiAgICAgICAge2ZvclNhbGUubGVuZ3RoID4gMCAmJiAoXG4gICAgICAgICAgPFJhaWwgdGl0bGU9e3QoXCJleHBsb3JlLmZvclNhbGVcIil9IGxlYWQ9e3QoXCJleHBsb3JlLmZvclNhbGVMZWFkXCIpfSB0bz1cIi9zZWFyY2hcIiBpdGVtcz17Zm9yU2FsZS5zbGljZSgwLCA4KX0gey4uLmhhbmRsZXJzfSAvPlxuICAgICAgICApfVxuICAgICAgPC9kaXY+XG4gICAgPC8+XG4gICk7XG59XG5cbmZ1bmN0aW9uIEFyZWFTdHJpcCh7IGxpc3RpbmdzIH06IHsgbGlzdGluZ3M6IFNwYWNlTGlzdGluZ1tdIH0pIHtcbiAgY29uc3QgY291bnRzID0gQVJFQVMubWFwKChhKSA9PiAoe1xuICAgIGFyZWE6IGEsXG4gICAgY291bnQ6IGxpc3RpbmdzLmZpbHRlcigobCkgPT4gbC5wcm9wZXJ0eS5hcmVhID09PSBhLm5hbWUpLmxlbmd0aCxcbiAgfSkpXG4gICAgLmZpbHRlcigoeCkgPT4geC5jb3VudCA+IDApXG4gICAgLnNvcnQoKGEsIGIpID0+IGIuY291bnQgLSBhLmNvdW50KTtcblxuICByZXR1cm4gKFxuICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cImNvbnRhaW5lci1wYWdlIHBiLTRcIj5cbiAgICAgIDxoMiBjbGFzc05hbWU9XCJmb250LWRpc3BsYXkgdGV4dC14bCBmb250LWJvbGQgdGV4dC1pbmtcIj5XaGVyZSBwZW9wbGUgYXJlIGxvb2tpbmc8L2gyPlxuICAgICAgPHVsIGNsYXNzTmFtZT1cIm10LTQgZmxleCBnYXAtMi41IG92ZXJmbG93LXgtYXV0byBwYi0yIGhpZGUtc2Nyb2xsYmFyXCI+XG4gICAgICAgIHtjb3VudHMubWFwKCh7IGFyZWEsIGNvdW50IH0pID0+IChcbiAgICAgICAgICA8bGkga2V5PXthcmVhLmlkfSBjbGFzc05hbWU9XCJzaHJpbmstMFwiPlxuICAgICAgICAgICAgPExpbmtcbiAgICAgICAgICAgICAgdG89e2Avc2VhcmNoP2FyZWE9JHtlbmNvZGVVUklDb21wb25lbnQoYXJlYS5uYW1lKX1gfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IG1pbi13LTQwIGZsZXgtY29sIGdhcC0xIHJvdW5kZWQtMnhsIGJnLXN1cmZhY2UgcC00IHJpbmctMSByaW5nLWhhaXJsaW5lIHRyYW5zaXRpb24tYWxsIGhvdmVyOi10cmFuc2xhdGUteS0wLjUgaG92ZXI6cmluZy1pbmtcIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtaW5rXCI+e2FyZWEubmFtZX08L3NwYW4+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgY2FwaXRhbGl6ZSB0ZXh0LW11dGVkXCI+e2FyZWEuZ2VvZ3JhcGh5fTwvc3Bhbj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdG51bSB0ZXh0LWFxdWEtNzAwXCI+e2NvdW50fSBzcGFjZXM8L3NwYW4+XG4gICAgICAgICAgICA8L0xpbms+XG4gICAgICAgICAgPC9saT5cbiAgICAgICAgKSl9XG4gICAgICA8L3VsPlxuICAgIDwvc2VjdGlvbj5cbiAgKTtcbn1cblxuZnVuY3Rpb24gUmFpbCh7XG4gIHRpdGxlLFxuICBsZWFkLFxuICB0byxcbiAgaXRlbXMsXG4gIHJlYWR5LFxuICBtYXRjaGVzLFxuICBpc1NhdmVkLFxuICBpc0NvbXBhcmluZyxcbiAgb25Ub2dnbGVTYXZlLFxuICBvblRvZ2dsZUNvbXBhcmUsXG59OiB7XG4gIHRpdGxlOiBzdHJpbmc7XG4gIGxlYWQ6IHN0cmluZztcbiAgdG86IHN0cmluZztcbiAgaXRlbXM6IFNwYWNlTGlzdGluZ1tdO1xuICByZWFkeTogYm9vbGVhbjtcbiAgbWF0Y2hlcz86IE1hcDxzdHJpbmcsIHsgc2NvcmU6IG51bWJlciB9PjtcbiAgaXNTYXZlZDogKGlkOiBzdHJpbmcpID0+IGJvb2xlYW47XG4gIGlzQ29tcGFyaW5nOiAoaWQ6IHN0cmluZykgPT4gYm9vbGVhbjtcbiAgb25Ub2dnbGVTYXZlOiAoaWQ6IHN0cmluZykgPT4gdm9pZDtcbiAgb25Ub2dnbGVDb21wYXJlOiAoaWQ6IHN0cmluZykgPT4gdm9pZDtcbn0pIHtcbiAgaWYgKHJlYWR5ICYmIGl0ZW1zLmxlbmd0aCA9PT0gMCkgcmV0dXJuIG51bGw7XG5cbiAgcmV0dXJuIChcbiAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJweS02XCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbnRhaW5lci1wYWdlIGZsZXggZmxleC13cmFwIGl0ZW1zLWVuZCBqdXN0aWZ5LWJldHdlZW4gZ2FwLTNcIj5cbiAgICAgICAgPGRpdj5cbiAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwiZm9udC1kaXNwbGF5IHRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LWlua1wiPnt0aXRsZX08L2gyPlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC1zbSB0ZXh0LW11dGVkXCI+e2xlYWR9PC9wPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPExpbmsgdG89e3RvfSBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1hcXVhLTcwMCBob3Zlcjp0ZXh0LWlua1wiPlxuICAgICAgICAgIFNlZSBhbGxcbiAgICAgICAgICA8QXJyb3dSaWdodCBzaXplPXsxNX0gYXJpYS1oaWRkZW4gLz5cbiAgICAgICAgPC9MaW5rPlxuICAgICAgPC9kaXY+XG5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNSBmbGV4IGdhcC00IG92ZXJmbG93LXgtYXV0byBweC01IHBiLTIgaGlkZS1zY3JvbGxiYXIgbWQ6cHgtOFwiPlxuICAgICAgICB7IXJlYWR5XG4gICAgICAgICAgPyBBcnJheS5mcm9tKHsgbGVuZ3RoOiA0IH0sIChfLCBpKSA9PiAoXG4gICAgICAgICAgICAgIDxkaXYga2V5PXtpfSBjbGFzc05hbWU9XCJ3LTY4IHNocmluay0wIHNtOnctNzZcIj5cbiAgICAgICAgICAgICAgICA8U3BhY2VDYXJkU2tlbGV0b24gLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApKVxuICAgICAgICAgIDogaXRlbXMubWFwKChsKSA9PiAoXG4gICAgICAgICAgICAgIDxkaXYga2V5PXtsLnNwYWNlLmlkfSBjbGFzc05hbWU9XCJ3LTY4IHNocmluay0wIHNtOnctNzZcIj5cbiAgICAgICAgICAgICAgICA8U3BhY2VDYXJkXG4gICAgICAgICAgICAgICAgICBsaXN0aW5nPXtsfVxuICAgICAgICAgICAgICAgICAgbWF0Y2hTY29yZT17bWF0Y2hlcz8uZ2V0KGwuc3BhY2UuaWQpPy5zY29yZX1cbiAgICAgICAgICAgICAgICAgIHNhdmVkPXtpc1NhdmVkKGwuc3BhY2UuaWQpfVxuICAgICAgICAgICAgICAgICAgY29tcGFyaW5nPXtpc0NvbXBhcmluZyhsLnNwYWNlLmlkKX1cbiAgICAgICAgICAgICAgICAgIG9uVG9nZ2xlU2F2ZT17b25Ub2dnbGVTYXZlfVxuICAgICAgICAgICAgICAgICAgb25Ub2dnbGVDb21wYXJlPXtvblRvZ2dsZUNvbXBhcmV9XG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApKX1cbiAgICAgIDwvZGl2PlxuICAgIDwvc2VjdGlvbj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiRDovSTJJIFByb2plY3QgLSBIYWJpdG8vQXBwIEZvbGRlci9oYWJpdG8vc3JjL3BhZ2VzL0V4cGxvcmUudHN4In0=