import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/@fs/D:\\I2I Project - Habito\\App Folder\\habito\\src\\components\\ui\\AreaPicker.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=9ceb86a3"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("D:/I2I Project - Habito/App Folder/habito/src/components/ui/AreaPicker.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9ceb86a3"; const useMemo = __vite__cjsImport3_react["useMemo"]; const useState = __vite__cjsImport3_react["useState"];
import { MapPin, Search, X, Check } from "/node_modules/.vite/deps/lucide-react.js?v=9ceb86a3";
import { areaByName, areasByRegion, searchAreas } from "/src/data/areas.ts";
import { useI18n } from "/src/i18n/index.tsx";
import { Modal } from "/src/components/ui/Modal.tsx";
import { cn } from "/src/lib/cn.ts";
export function AreaPicker({
  value,
  onChange,
  label,
  allowAnywhere = false,
  className
}) {
  _s();
  const { t } = useI18n();
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const selected = areaByName(value);
  const anywhere = value === "all";
  const results = useMemo(() => {
    if (!query.trim()) return null;
    return searchAreas(query);
  }, [query]);
  const choose = (name) => {
    onChange(name);
    setOpen(false);
    setQuery("");
  };
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(
      "button",
      {
        type: "button",
        onClick: () => setOpen(true),
        className: cn(
          "flex h-11 w-full items-center gap-2 rounded-xl bg-ivory px-3 text-left text-[0.9375rem] text-ink ring-1 ring-hairline-strong transition-shadow hover:ring-ink focus:outline-none focus:ring-2 focus:ring-aqua-600",
          className
        ),
        children: [
          /* @__PURE__ */ jsxDEV(MapPin, { size: 15, className: "shrink-0 text-muted", "aria-hidden": true }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/ui/AreaPicker.tsx",
            lineNumber: 77,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "min-w-0 flex-1 truncate", children: anywhere ? t("filter.everywhere") : selected?.name ?? value }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/ui/AreaPicker.tsx",
            lineNumber: 78,
            columnNumber: 9
          }, this),
          selected?.district && selected.district !== selected.name && !anywhere && /* @__PURE__ */ jsxDEV("span", { className: "shrink-0 text-xs text-muted", children: selected.district }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/ui/AreaPicker.tsx",
            lineNumber: 82,
            columnNumber: 9
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/ui/AreaPicker.tsx",
        lineNumber: 69,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(Modal, { open, onClose: () => setOpen(false), title: label ?? t("find.where"), children: [
      /* @__PURE__ */ jsxDEV("div", { className: "sticky -top-1 z-10 -mx-1 bg-surface pb-3 pt-1", children: /* @__PURE__ */ jsxDEV("div", { className: "relative", children: [
        /* @__PURE__ */ jsxDEV(Search, { size: 16, className: "absolute left-3 top-1/2 -translate-y-1/2 text-muted", "aria-hidden": true }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/ui/AreaPicker.tsx",
          lineNumber: 89,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            autoFocus: true,
            value: query,
            onChange: (e) => setQuery(e.target.value),
            placeholder: t("area.searchPlaceholder"),
            className: "h-11 w-full rounded-xl bg-ivory pl-9 pr-9 text-[0.9375rem] ring-1 ring-hairline-strong focus:outline-none focus:ring-2 focus:ring-aqua-600"
          },
          void 0,
          false,
          {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/ui/AreaPicker.tsx",
            lineNumber: 90,
            columnNumber: 13
          },
          this
        ),
        query && /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: () => setQuery(""),
            "aria-label": t("action.clear"),
            className: "absolute right-2.5 top-1/2 -translate-y-1/2 rounded-full p-1 text-muted hover:text-ink",
            children: /* @__PURE__ */ jsxDEV(X, { size: 14, "aria-hidden": true }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/ui/AreaPicker.tsx",
              lineNumber: 104,
              columnNumber: 17
            }, this)
          },
          void 0,
          false,
          {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/ui/AreaPicker.tsx",
            lineNumber: 98,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/ui/AreaPicker.tsx",
        lineNumber: 88,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/ui/AreaPicker.tsx",
        lineNumber: 87,
        columnNumber: 9
      }, this),
      allowAnywhere && !query && /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          onClick: () => choose("all"),
          className: cn(
            "mb-3 flex w-full items-center justify-between rounded-xl px-3 py-2.5 text-left text-sm font-semibold transition-colors",
            anywhere ? "bg-aqua-50 text-aqua-700" : "bg-ivory text-ink hover:bg-ivory-deep"
          ),
          children: [
            t("filter.everywhere"),
            anywhere && /* @__PURE__ */ jsxDEV(Check, { size: 15, "aria-hidden": true }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/ui/AreaPicker.tsx",
              lineNumber: 120,
              columnNumber: 26
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/ui/AreaPicker.tsx",
          lineNumber: 111,
          columnNumber: 9
        },
        this
      ),
      results ? results.length === 0 ? /* @__PURE__ */ jsxDEV("p", { className: "py-8 text-center text-sm text-muted", children: t("area.noMatch", { query }) }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/ui/AreaPicker.tsx",
        lineNumber: 126,
        columnNumber: 9
      }, this) : /* @__PURE__ */ jsxDEV("ul", { className: "space-y-1", children: results.map(
        (area) => /* @__PURE__ */ jsxDEV("li", { children: /* @__PURE__ */ jsxDEV(AreaRow, { area, selected: area.name === value, query, onClick: () => choose(area.name) }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/ui/AreaPicker.tsx",
          lineNumber: 131,
          columnNumber: 19
        }, this) }, area.id, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/ui/AreaPicker.tsx",
          lineNumber: 130,
          columnNumber: 11
        }, this)
      ) }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/ui/AreaPicker.tsx",
        lineNumber: 128,
        columnNumber: 9
      }, this) : /* @__PURE__ */ jsxDEV("div", { className: "space-y-5", children: areasByRegion().map(
        (group) => /* @__PURE__ */ jsxDEV("section", { children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "mb-1.5 px-1 text-xs font-bold uppercase tracking-wide text-muted", children: group.region }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/ui/AreaPicker.tsx",
            lineNumber: 140,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("ul", { className: "space-y-1", children: group.areas.map(
            (area) => /* @__PURE__ */ jsxDEV("li", { children: /* @__PURE__ */ jsxDEV(AreaRow, { area, selected: area.name === value, onClick: () => choose(area.name) }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/ui/AreaPicker.tsx",
              lineNumber: 146,
              columnNumber: 23
            }, this) }, area.id, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/ui/AreaPicker.tsx",
              lineNumber: 145,
              columnNumber: 15
            }, this)
          ) }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/ui/AreaPicker.tsx",
            lineNumber: 143,
            columnNumber: 17
          }, this)
        ] }, group.region, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/ui/AreaPicker.tsx",
          lineNumber: 139,
          columnNumber: 11
        }, this)
      ) }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/ui/AreaPicker.tsx",
        lineNumber: 137,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/ui/AreaPicker.tsx",
      lineNumber: 86,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/ui/AreaPicker.tsx",
    lineNumber: 68,
    columnNumber: 5
  }, this);
}
_s(AreaPicker, "WPOH1V5STDrQE7pF6hdyx57uj9c=", false, function() {
  return [useI18n];
});
_c = AreaPicker;
function AreaRow({
  area,
  selected,
  query,
  onClick
}) {
  const matchedHood = query && area.neighborhoods?.find((n) => n.toLowerCase().includes(query.trim().toLowerCase()));
  return /* @__PURE__ */ jsxDEV(
    "button",
    {
      type: "button",
      onClick,
      className: cn(
        "flex w-full items-center justify-between gap-3 rounded-xl px-3 py-2.5 text-left transition-colors",
        selected ? "bg-aqua-50" : "hover:bg-ivory"
      ),
      children: [
        /* @__PURE__ */ jsxDEV("span", { className: "min-w-0", children: [
          /* @__PURE__ */ jsxDEV("span", { className: cn("block truncate text-sm font-semibold", selected ? "text-aqua-700" : "text-ink"), children: area.name }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/ui/AreaPicker.tsx",
            lineNumber: 185,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "block truncate text-xs text-muted", children: matchedHood ? `${matchedHood} · ${area.district}` : area.district }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/ui/AreaPicker.tsx",
            lineNumber: 188,
            columnNumber: 9
          }, this)
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/ui/AreaPicker.tsx",
          lineNumber: 184,
          columnNumber: 7
        }, this),
        selected && /* @__PURE__ */ jsxDEV(Check, { size: 15, className: "shrink-0 text-aqua-700", "aria-hidden": true }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/ui/AreaPicker.tsx",
          lineNumber: 192,
          columnNumber: 20
        }, this)
      ]
    },
    void 0,
    true,
    {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/ui/AreaPicker.tsx",
      lineNumber: 176,
      columnNumber: 5
    },
    this
  );
}
_c2 = AreaRow;
var _c, _c2;
$RefreshReg$(_c, "AreaPicker");
$RefreshReg$(_c2, "AreaRow");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/I2I Project - Habito/App Folder/habito/src/components/ui/AreaPicker.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/I2I Project - Habito/App Folder/habito/src/components/ui/AreaPicker.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0RJLG1CQVNJLGNBVEo7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBaERKLFNBQVNBLFNBQVNDLGdCQUFnQjtBQUNsQyxTQUFTQyxRQUFRQyxRQUFRQyxHQUFHQyxhQUFhO0FBQ3pDLFNBQWdCQyxZQUFZQyxlQUFlQyxtQkFBbUI7QUFDOUQsU0FBU0MsZUFBZTtBQUN4QixTQUFTQyxhQUFhO0FBQ3RCLFNBQVNDLFVBQVU7QUFVWixnQkFBU0MsV0FBVztBQUFBLEVBQ3pCQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQyxnQkFBZ0I7QUFBQSxFQUNoQkM7QUFRRixHQUFHO0FBQUFDLEtBQUE7QUFDRCxRQUFNLEVBQUVDLEVBQUUsSUFBSVYsUUFBUTtBQUN0QixRQUFNLENBQUNXLE1BQU1DLE9BQU8sSUFBSXBCLFNBQVMsS0FBSztBQUN0QyxRQUFNLENBQUNxQixPQUFPQyxRQUFRLElBQUl0QixTQUFTLEVBQUU7QUFFckMsUUFBTXVCLFdBQVdsQixXQUFXTyxLQUFLO0FBQ2pDLFFBQU1ZLFdBQVdaLFVBQVU7QUFFM0IsUUFBTWEsVUFBVTFCLFFBQVEsTUFBTTtBQUM1QixRQUFJLENBQUNzQixNQUFNSyxLQUFLLEVBQUcsUUFBTztBQUMxQixXQUFPbkIsWUFBWWMsS0FBSztBQUFBLEVBQzFCLEdBQUcsQ0FBQ0EsS0FBSyxDQUFDO0FBRVYsUUFBTU0sU0FBU0EsQ0FBQ0MsU0FBaUI7QUFDL0JmLGFBQVNlLElBQUk7QUFDYlIsWUFBUSxLQUFLO0FBQ2JFLGFBQVMsRUFBRTtBQUFBLEVBQ2I7QUFFQSxTQUNFLG1DQUNFO0FBQUE7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLE1BQUs7QUFBQSxRQUNMLFNBQVMsTUFBTUYsUUFBUSxJQUFJO0FBQUEsUUFDM0IsV0FBV1Y7QUFBQUEsVUFDVDtBQUFBLFVBQ0FNO0FBQUFBLFFBQ0Y7QUFBQSxRQUVBO0FBQUEsaUNBQUMsVUFBTyxNQUFNLElBQUksV0FBVSx1QkFBc0IsZUFBVyxRQUE3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE2RDtBQUFBLFVBQzdELHVCQUFDLFVBQUssV0FBVSwyQkFDYlEscUJBQVdOLEVBQUUsbUJBQW1CLElBQUlLLFVBQVVLLFFBQVFoQixTQUR6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQ1csVUFBVU0sWUFBWU4sU0FBU00sYUFBYU4sU0FBU0ssUUFBUSxDQUFDSixZQUM3RCx1QkFBQyxVQUFLLFdBQVUsK0JBQStCRCxtQkFBU00sWUFBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBaUU7QUFBQTtBQUFBO0FBQUEsTUFickU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBZUE7QUFBQSxJQUVBLHVCQUFDLFNBQU0sTUFBWSxTQUFTLE1BQU1ULFFBQVEsS0FBSyxHQUFHLE9BQU9OLFNBQVNJLEVBQUUsWUFBWSxHQUM5RTtBQUFBLDZCQUFDLFNBQUksV0FBVSxpREFDYixpQ0FBQyxTQUFJLFdBQVUsWUFDYjtBQUFBLCtCQUFDLFVBQU8sTUFBTSxJQUFJLFdBQVUsdURBQXNELGVBQVcsUUFBN0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE2RjtBQUFBLFFBQzdGO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQztBQUFBLFlBQ0EsT0FBT0c7QUFBQUEsWUFDUCxVQUFVLENBQUNTLE1BQU1SLFNBQVNRLEVBQUVDLE9BQU9uQixLQUFLO0FBQUEsWUFDeEMsYUFBYU0sRUFBRSx3QkFBd0I7QUFBQSxZQUN2QyxXQUFVO0FBQUE7QUFBQSxVQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUt3SjtBQUFBLFFBRXZKRyxTQUNDO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFLO0FBQUEsWUFDTCxTQUFTLE1BQU1DLFNBQVMsRUFBRTtBQUFBLFlBQzFCLGNBQVlKLEVBQUUsY0FBYztBQUFBLFlBQzVCLFdBQVU7QUFBQSxZQUVWLGlDQUFDLEtBQUUsTUFBTSxJQUFJLGVBQVcsUUFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBd0I7QUFBQTtBQUFBLFVBTjFCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU9BO0FBQUEsV0FqQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQW1CQSxLQXBCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBcUJBO0FBQUEsTUFFQ0gsaUJBQWlCLENBQUNNLFNBQ2pCO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxNQUFLO0FBQUEsVUFDTCxTQUFTLE1BQU1NLE9BQU8sS0FBSztBQUFBLFVBQzNCLFdBQVdqQjtBQUFBQSxZQUNUO0FBQUEsWUFDQWMsV0FBVyw2QkFBNkI7QUFBQSxVQUMxQztBQUFBLFVBRUNOO0FBQUFBLGNBQUUsbUJBQW1CO0FBQUEsWUFDckJNLFlBQVksdUJBQUMsU0FBTSxNQUFNLElBQUksZUFBVyxRQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE0QjtBQUFBO0FBQUE7QUFBQSxRQVQzQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFVQTtBQUFBLE1BR0RDLFVBQ0NBLFFBQVFPLFdBQVcsSUFDakIsdUJBQUMsT0FBRSxXQUFVLHVDQUF1Q2QsWUFBRSxnQkFBZ0IsRUFBRUcsTUFBTSxDQUFDLEtBQS9FO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBaUYsSUFFakYsdUJBQUMsUUFBRyxXQUFVLGFBQ1hJLGtCQUFRUTtBQUFBQSxRQUFJLENBQUNDLFNBQ1osdUJBQUMsUUFDQyxpQ0FBQyxXQUFRLE1BQVksVUFBVUEsS0FBS04sU0FBU2hCLE9BQU8sT0FBYyxTQUFTLE1BQU1lLE9BQU9PLEtBQUtOLElBQUksS0FBakc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFtRyxLQUQ1Rk0sS0FBS0MsSUFBZDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxNQUNELEtBTEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU1BLElBR0YsdUJBQUMsU0FBSSxXQUFVLGFBQ1o3Qix3QkFBYyxFQUFFMkI7QUFBQUEsUUFBSSxDQUFDRyxVQUNwQix1QkFBQyxhQUNDO0FBQUEsaUNBQUMsUUFBRyxXQUFVLG9FQUNYQSxnQkFBTUMsVUFEVDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxRQUFHLFdBQVUsYUFDWEQsZ0JBQU1FLE1BQU1MO0FBQUFBLFlBQUksQ0FBQ0MsU0FDaEIsdUJBQUMsUUFDQyxpQ0FBQyxXQUFRLE1BQVksVUFBVUEsS0FBS04sU0FBU2hCLE9BQU8sU0FBUyxNQUFNZSxPQUFPTyxLQUFLTixJQUFJLEtBQW5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXFGLEtBRDlFTSxLQUFLQyxJQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxVQUNELEtBTEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFNQTtBQUFBLGFBVllDLE1BQU1DLFFBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFXQTtBQUFBLE1BQ0QsS0FkSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBZUE7QUFBQSxTQWxFSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBb0VBO0FBQUEsT0F0RkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXVGQTtBQUVKO0FBQUNwQixHQTFIZU4sWUFBVTtBQUFBLFVBY1ZILE9BQU87QUFBQTtBQUFBLEtBZFBHO0FBNEhoQixTQUFTNEIsUUFBUTtBQUFBLEVBQ2ZMO0FBQUFBLEVBQ0FYO0FBQUFBLEVBQ0FGO0FBQUFBLEVBQ0FtQjtBQU1GLEdBQUc7QUFHRCxRQUFNQyxjQUNKcEIsU0FBU2EsS0FBS1EsZUFBZUMsS0FBSyxDQUFDQyxNQUFNQSxFQUFFQyxZQUFZLEVBQUVDLFNBQVN6QixNQUFNSyxLQUFLLEVBQUVtQixZQUFZLENBQUMsQ0FBQztBQUUvRixTQUNFO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDQyxNQUFLO0FBQUEsTUFDTDtBQUFBLE1BQ0EsV0FBV25DO0FBQUFBLFFBQ1Q7QUFBQSxRQUNBYSxXQUFXLGVBQWU7QUFBQSxNQUM1QjtBQUFBLE1BRUE7QUFBQSwrQkFBQyxVQUFLLFdBQVUsV0FDZDtBQUFBLGlDQUFDLFVBQUssV0FBV2IsR0FBRyx3Q0FBd0NhLFdBQVcsa0JBQWtCLFVBQVUsR0FDaEdXLGVBQUtOLFFBRFI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsVUFBSyxXQUFVLHFDQUNiYSx3QkFBYyxHQUFHQSxXQUFXLE1BQU1QLEtBQUtMLFFBQVEsS0FBS0ssS0FBS0wsWUFENUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU9BO0FBQUEsUUFDQ04sWUFBWSx1QkFBQyxTQUFNLE1BQU0sSUFBSSxXQUFVLDBCQUF5QixlQUFXLFFBQS9EO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBK0Q7QUFBQTtBQUFBO0FBQUEsSUFoQjlFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQWlCQTtBQUVKO0FBQUN3QixNQXBDUVI7QUFBTyxJQUFBUyxJQUFBRDtBQUFBLGFBQUFDLElBQUE7QUFBQSxhQUFBRCxLQUFBIiwibmFtZXMiOlsidXNlTWVtbyIsInVzZVN0YXRlIiwiTWFwUGluIiwiU2VhcmNoIiwiWCIsIkNoZWNrIiwiYXJlYUJ5TmFtZSIsImFyZWFzQnlSZWdpb24iLCJzZWFyY2hBcmVhcyIsInVzZUkxOG4iLCJNb2RhbCIsImNuIiwiQXJlYVBpY2tlciIsInZhbHVlIiwib25DaGFuZ2UiLCJsYWJlbCIsImFsbG93QW55d2hlcmUiLCJjbGFzc05hbWUiLCJfcyIsInQiLCJvcGVuIiwic2V0T3BlbiIsInF1ZXJ5Iiwic2V0UXVlcnkiLCJzZWxlY3RlZCIsImFueXdoZXJlIiwicmVzdWx0cyIsInRyaW0iLCJjaG9vc2UiLCJuYW1lIiwiZGlzdHJpY3QiLCJlIiwidGFyZ2V0IiwibGVuZ3RoIiwibWFwIiwiYXJlYSIsImlkIiwiZ3JvdXAiLCJyZWdpb24iLCJhcmVhcyIsIkFyZWFSb3ciLCJvbkNsaWNrIiwibWF0Y2hlZEhvb2QiLCJuZWlnaGJvcmhvb2RzIiwiZmluZCIsIm4iLCJ0b0xvd2VyQ2FzZSIsImluY2x1ZGVzIiwiX2MyIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQXJlYVBpY2tlci50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlTWVtbywgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IE1hcFBpbiwgU2VhcmNoLCBYLCBDaGVjayB9IGZyb20gXCJsdWNpZGUtcmVhY3RcIjtcbmltcG9ydCB7IEFSRUFTLCBhcmVhQnlOYW1lLCBhcmVhc0J5UmVnaW9uLCBzZWFyY2hBcmVhcyB9IGZyb20gXCJAL2RhdGEvYXJlYXNcIjtcbmltcG9ydCB7IHVzZUkxOG4gfSBmcm9tIFwiQC9pMThuXCI7XG5pbXBvcnQgeyBNb2RhbCB9IGZyb20gXCJAL2NvbXBvbmVudHMvdWkvTW9kYWxcIjtcbmltcG9ydCB7IGNuIH0gZnJvbSBcIkAvbGliL2NuXCI7XG5cbi8qKlxuICogQ2hvb3NpbmcgYW4gYXJlYS5cbiAqXG4gKiBEaGFrYSBhbG9uZSBoYXMgNTAgdGhhbmFzLCB3aGljaCBpcyBmYXIgdG9vIG1hbnkgZm9yIGEgZHJvcGRvd24g4oCUIHNvIHRoaXNcbiAqIG9wZW5zIGEgc2VhcmNoYWJsZSBzaGVldCBncm91cGVkIGJ5IHJlZ2lvbi4gSXQgbWF0Y2hlcyBvbiBuZWlnaGJvdXJob29kcyBhc1xuICogd2VsbCBhcyBhcmVhIG5hbWVzLCBiZWNhdXNlIHBlb3BsZSBzZWFyY2ggZm9yIEthemlwYXJhIG9yIEJhbmFzcmVlLCBub3QgZm9yXG4gKiB0aGUgdGhhbmEgdGhvc2Ugc2l0IGluc2lkZS5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIEFyZWFQaWNrZXIoe1xuICB2YWx1ZSxcbiAgb25DaGFuZ2UsXG4gIGxhYmVsLFxuICBhbGxvd0FueXdoZXJlID0gZmFsc2UsXG4gIGNsYXNzTmFtZSxcbn06IHtcbiAgdmFsdWU6IHN0cmluZztcbiAgb25DaGFuZ2U6IChhcmVhTmFtZTogc3RyaW5nKSA9PiB2b2lkO1xuICBsYWJlbD86IHN0cmluZztcbiAgLyoqIEFkZHMgYW4gXCJldmVyeXdoZXJlXCIgb3B0aW9uLCBmb3IgZmlsdGVycyByYXRoZXIgdGhhbiBmb3Jtcy4gKi9cbiAgYWxsb3dBbnl3aGVyZT86IGJvb2xlYW47XG4gIGNsYXNzTmFtZT86IHN0cmluZztcbn0pIHtcbiAgY29uc3QgeyB0IH0gPSB1c2VJMThuKCk7XG4gIGNvbnN0IFtvcGVuLCBzZXRPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW3F1ZXJ5LCBzZXRRdWVyeV0gPSB1c2VTdGF0ZShcIlwiKTtcblxuICBjb25zdCBzZWxlY3RlZCA9IGFyZWFCeU5hbWUodmFsdWUpO1xuICBjb25zdCBhbnl3aGVyZSA9IHZhbHVlID09PSBcImFsbFwiO1xuXG4gIGNvbnN0IHJlc3VsdHMgPSB1c2VNZW1vKCgpID0+IHtcbiAgICBpZiAoIXF1ZXJ5LnRyaW0oKSkgcmV0dXJuIG51bGw7XG4gICAgcmV0dXJuIHNlYXJjaEFyZWFzKHF1ZXJ5KTtcbiAgfSwgW3F1ZXJ5XSk7XG5cbiAgY29uc3QgY2hvb3NlID0gKG5hbWU6IHN0cmluZykgPT4ge1xuICAgIG9uQ2hhbmdlKG5hbWUpO1xuICAgIHNldE9wZW4oZmFsc2UpO1xuICAgIHNldFF1ZXJ5KFwiXCIpO1xuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPD5cbiAgICAgIDxidXR0b25cbiAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgIG9uQ2xpY2s9eygpID0+IHNldE9wZW4odHJ1ZSl9XG4gICAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgICAgXCJmbGV4IGgtMTEgdy1mdWxsIGl0ZW1zLWNlbnRlciBnYXAtMiByb3VuZGVkLXhsIGJnLWl2b3J5IHB4LTMgdGV4dC1sZWZ0IHRleHQtWzAuOTM3NXJlbV0gdGV4dC1pbmsgcmluZy0xIHJpbmctaGFpcmxpbmUtc3Ryb25nIHRyYW5zaXRpb24tc2hhZG93IGhvdmVyOnJpbmctaW5rIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1hcXVhLTYwMFwiLFxuICAgICAgICAgIGNsYXNzTmFtZSxcbiAgICAgICAgKX1cbiAgICAgID5cbiAgICAgICAgPE1hcFBpbiBzaXplPXsxNX0gY2xhc3NOYW1lPVwic2hyaW5rLTAgdGV4dC1tdXRlZFwiIGFyaWEtaGlkZGVuIC8+XG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1pbi13LTAgZmxleC0xIHRydW5jYXRlXCI+XG4gICAgICAgICAge2FueXdoZXJlID8gdChcImZpbHRlci5ldmVyeXdoZXJlXCIpIDogc2VsZWN0ZWQ/Lm5hbWUgPz8gdmFsdWV9XG4gICAgICAgIDwvc3Bhbj5cbiAgICAgICAge3NlbGVjdGVkPy5kaXN0cmljdCAmJiBzZWxlY3RlZC5kaXN0cmljdCAhPT0gc2VsZWN0ZWQubmFtZSAmJiAhYW55d2hlcmUgJiYgKFxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInNocmluay0wIHRleHQteHMgdGV4dC1tdXRlZFwiPntzZWxlY3RlZC5kaXN0cmljdH08L3NwYW4+XG4gICAgICAgICl9XG4gICAgICA8L2J1dHRvbj5cblxuICAgICAgPE1vZGFsIG9wZW49e29wZW59IG9uQ2xvc2U9eygpID0+IHNldE9wZW4oZmFsc2UpfSB0aXRsZT17bGFiZWwgPz8gdChcImZpbmQud2hlcmVcIil9PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInN0aWNreSAtdG9wLTEgei0xMCAtbXgtMSBiZy1zdXJmYWNlIHBiLTMgcHQtMVwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmVcIj5cbiAgICAgICAgICAgIDxTZWFyY2ggc2l6ZT17MTZ9IGNsYXNzTmFtZT1cImFic29sdXRlIGxlZnQtMyB0b3AtMS8yIC10cmFuc2xhdGUteS0xLzIgdGV4dC1tdXRlZFwiIGFyaWEtaGlkZGVuIC8+XG4gICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgYXV0b0ZvY3VzXG4gICAgICAgICAgICAgIHZhbHVlPXtxdWVyeX1cbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRRdWVyeShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgIHBsYWNlaG9sZGVyPXt0KFwiYXJlYS5zZWFyY2hQbGFjZWhvbGRlclwiKX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC0xMSB3LWZ1bGwgcm91bmRlZC14bCBiZy1pdm9yeSBwbC05IHByLTkgdGV4dC1bMC45Mzc1cmVtXSByaW5nLTEgcmluZy1oYWlybGluZS1zdHJvbmcgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWFxdWEtNjAwXCJcbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgICB7cXVlcnkgJiYgKFxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0UXVlcnkoXCJcIil9XG4gICAgICAgICAgICAgICAgYXJpYS1sYWJlbD17dChcImFjdGlvbi5jbGVhclwiKX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJhYnNvbHV0ZSByaWdodC0yLjUgdG9wLTEvMiAtdHJhbnNsYXRlLXktMS8yIHJvdW5kZWQtZnVsbCBwLTEgdGV4dC1tdXRlZCBob3Zlcjp0ZXh0LWlua1wiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8WCBzaXplPXsxNH0gYXJpYS1oaWRkZW4gLz5cbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICApfVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7YWxsb3dBbnl3aGVyZSAmJiAhcXVlcnkgJiYgKFxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gY2hvb3NlKFwiYWxsXCIpfVxuICAgICAgICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgICAgICAgXCJtYi0zIGZsZXggdy1mdWxsIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcm91bmRlZC14bCBweC0zIHB5LTIuNSB0ZXh0LWxlZnQgdGV4dC1zbSBmb250LXNlbWlib2xkIHRyYW5zaXRpb24tY29sb3JzXCIsXG4gICAgICAgICAgICAgIGFueXdoZXJlID8gXCJiZy1hcXVhLTUwIHRleHQtYXF1YS03MDBcIiA6IFwiYmctaXZvcnkgdGV4dC1pbmsgaG92ZXI6YmctaXZvcnktZGVlcFwiLFxuICAgICAgICAgICAgKX1cbiAgICAgICAgICA+XG4gICAgICAgICAgICB7dChcImZpbHRlci5ldmVyeXdoZXJlXCIpfVxuICAgICAgICAgICAge2FueXdoZXJlICYmIDxDaGVjayBzaXplPXsxNX0gYXJpYS1oaWRkZW4gLz59XG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICl9XG5cbiAgICAgICAge3Jlc3VsdHMgPyAoXG4gICAgICAgICAgcmVzdWx0cy5sZW5ndGggPT09IDAgPyAoXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJweS04IHRleHQtY2VudGVyIHRleHQtc20gdGV4dC1tdXRlZFwiPnt0KFwiYXJlYS5ub01hdGNoXCIsIHsgcXVlcnkgfSl9PC9wPlxuICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICA8dWwgY2xhc3NOYW1lPVwic3BhY2UteS0xXCI+XG4gICAgICAgICAgICAgIHtyZXN1bHRzLm1hcCgoYXJlYSkgPT4gKFxuICAgICAgICAgICAgICAgIDxsaSBrZXk9e2FyZWEuaWR9PlxuICAgICAgICAgICAgICAgICAgPEFyZWFSb3cgYXJlYT17YXJlYX0gc2VsZWN0ZWQ9e2FyZWEubmFtZSA9PT0gdmFsdWV9IHF1ZXJ5PXtxdWVyeX0gb25DbGljaz17KCkgPT4gY2hvb3NlKGFyZWEubmFtZSl9IC8+XG4gICAgICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICA8L3VsPlxuICAgICAgICAgIClcbiAgICAgICAgKSA6IChcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNVwiPlxuICAgICAgICAgICAge2FyZWFzQnlSZWdpb24oKS5tYXAoKGdyb3VwKSA9PiAoXG4gICAgICAgICAgICAgIDxzZWN0aW9uIGtleT17Z3JvdXAucmVnaW9ufT5cbiAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwibWItMS41IHB4LTEgdGV4dC14cyBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGUgdGV4dC1tdXRlZFwiPlxuICAgICAgICAgICAgICAgICAge2dyb3VwLnJlZ2lvbn1cbiAgICAgICAgICAgICAgICA8L2gzPlxuICAgICAgICAgICAgICAgIDx1bCBjbGFzc05hbWU9XCJzcGFjZS15LTFcIj5cbiAgICAgICAgICAgICAgICAgIHtncm91cC5hcmVhcy5tYXAoKGFyZWEpID0+IChcbiAgICAgICAgICAgICAgICAgICAgPGxpIGtleT17YXJlYS5pZH0+XG4gICAgICAgICAgICAgICAgICAgICAgPEFyZWFSb3cgYXJlYT17YXJlYX0gc2VsZWN0ZWQ9e2FyZWEubmFtZSA9PT0gdmFsdWV9IG9uQ2xpY2s9eygpID0+IGNob29zZShhcmVhLm5hbWUpfSAvPlxuICAgICAgICAgICAgICAgICAgICA8L2xpPlxuICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgPC91bD5cbiAgICAgICAgICAgICAgPC9zZWN0aW9uPlxuICAgICAgICAgICAgKSl9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICl9XG4gICAgICA8L01vZGFsPlxuICAgIDwvPlxuICApO1xufVxuXG5mdW5jdGlvbiBBcmVhUm93KHtcbiAgYXJlYSxcbiAgc2VsZWN0ZWQsXG4gIHF1ZXJ5LFxuICBvbkNsaWNrLFxufToge1xuICBhcmVhOiAodHlwZW9mIEFSRUFTKVtudW1iZXJdO1xuICBzZWxlY3RlZDogYm9vbGVhbjtcbiAgcXVlcnk/OiBzdHJpbmc7XG4gIG9uQ2xpY2s6ICgpID0+IHZvaWQ7XG59KSB7XG4gIC8vIFdoZW4gdGhlIG1hdGNoIGNhbWUgZnJvbSBhIG5laWdoYm91cmhvb2QgcmF0aGVyIHRoYW4gdGhlIGFyZWEgbmFtZSwgc2hvd1xuICAvLyB3aGljaCBvbmUg4oCUIG90aGVyd2lzZSB0aGUgcmVzdWx0IGxvb2tzIGFyYml0cmFyeS5cbiAgY29uc3QgbWF0Y2hlZEhvb2QgPVxuICAgIHF1ZXJ5ICYmIGFyZWEubmVpZ2hib3Job29kcz8uZmluZCgobikgPT4gbi50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHF1ZXJ5LnRyaW0oKS50b0xvd2VyQ2FzZSgpKSk7XG5cbiAgcmV0dXJuIChcbiAgICA8YnV0dG9uXG4gICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgIG9uQ2xpY2s9e29uQ2xpY2t9XG4gICAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgICBcImZsZXggdy1mdWxsIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTMgcm91bmRlZC14bCBweC0zIHB5LTIuNSB0ZXh0LWxlZnQgdHJhbnNpdGlvbi1jb2xvcnNcIixcbiAgICAgICAgc2VsZWN0ZWQgPyBcImJnLWFxdWEtNTBcIiA6IFwiaG92ZXI6YmctaXZvcnlcIixcbiAgICAgICl9XG4gICAgPlxuICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWluLXctMFwiPlxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2NuKFwiYmxvY2sgdHJ1bmNhdGUgdGV4dC1zbSBmb250LXNlbWlib2xkXCIsIHNlbGVjdGVkID8gXCJ0ZXh0LWFxdWEtNzAwXCIgOiBcInRleHQtaW5rXCIpfT5cbiAgICAgICAgICB7YXJlYS5uYW1lfVxuICAgICAgICA8L3NwYW4+XG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImJsb2NrIHRydW5jYXRlIHRleHQteHMgdGV4dC1tdXRlZFwiPlxuICAgICAgICAgIHttYXRjaGVkSG9vZCA/IGAke21hdGNoZWRIb29kfSDCtyAke2FyZWEuZGlzdHJpY3R9YCA6IGFyZWEuZGlzdHJpY3R9XG4gICAgICAgIDwvc3Bhbj5cbiAgICAgIDwvc3Bhbj5cbiAgICAgIHtzZWxlY3RlZCAmJiA8Q2hlY2sgc2l6ZT17MTV9IGNsYXNzTmFtZT1cInNocmluay0wIHRleHQtYXF1YS03MDBcIiBhcmlhLWhpZGRlbiAvPn1cbiAgICA8L2J1dHRvbj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiRDovSTJJIFByb2plY3QgLSBIYWJpdG8vQXBwIEZvbGRlci9oYWJpdG8vc3JjL2NvbXBvbmVudHMvdWkvQXJlYVBpY2tlci50c3gifQ==