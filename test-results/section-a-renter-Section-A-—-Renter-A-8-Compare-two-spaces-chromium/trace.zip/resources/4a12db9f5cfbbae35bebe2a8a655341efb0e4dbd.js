import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/layout/AppShell.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=9ceb86a3"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("D:/I2I Project - Habito/App Folder/habito/src/components/layout/AppShell.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { Header } from "/src/components/layout/Header.tsx";
import { MobileNav } from "/src/components/layout/MobileNav.tsx";
import { Footer } from "/src/components/layout/Footer.tsx";
import { PrototypeNotice } from "/src/components/layout/PrototypeNotice.tsx";
import { CompareTray } from "/src/components/space/CompareTray.tsx";
export function AppShell({ children }) {
  return /* @__PURE__ */ jsxDEV("div", { className: "flex min-h-dvh flex-col", children: [
    /* @__PURE__ */ jsxDEV(PrototypeNotice, {}, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/layout/AppShell.tsx",
      lineNumber: 30,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Header, {}, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/layout/AppShell.tsx",
      lineNumber: 31,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("main", { id: "main", className: "flex-1 pb-14 md:pb-0", children }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/layout/AppShell.tsx",
      lineNumber: 32,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Footer, {}, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/layout/AppShell.tsx",
      lineNumber: 35,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(CompareTray, {}, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/layout/AppShell.tsx",
      lineNumber: 36,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(MobileNav, {}, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/layout/AppShell.tsx",
      lineNumber: 37,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/layout/AppShell.tsx",
    lineNumber: 29,
    columnNumber: 5
  }, this);
}
_c = AppShell;
var _c;
$RefreshReg$(_c, "AppShell");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/I2I Project - Habito/App Folder/habito/src/components/layout/AppShell.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/I2I Project - Habito/App Folder/habito/src/components/layout/AppShell.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBVU07Ozs7Ozs7Ozs7Ozs7Ozs7QUFUTixTQUFTQSxjQUFjO0FBQ3ZCLFNBQVNDLGlCQUFpQjtBQUMxQixTQUFTQyxjQUFjO0FBQ3ZCLFNBQVNDLHVCQUF1QjtBQUNoQyxTQUFTQyxtQkFBbUI7QUFFckIsZ0JBQVNDLFNBQVMsRUFBRUMsU0FBa0MsR0FBRztBQUM5RCxTQUNFLHVCQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLDJCQUFDLHFCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBZ0I7QUFBQSxJQUNoQix1QkFBQyxZQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBTztBQUFBLElBQ1AsdUJBQUMsVUFBSyxJQUFHLFFBQU8sV0FBVSx3QkFDdkJBLFlBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsSUFDQSx1QkFBQyxZQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBTztBQUFBLElBQ1AsdUJBQUMsaUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFZO0FBQUEsSUFDWix1QkFBQyxlQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBVTtBQUFBLE9BUlo7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVNBO0FBRUo7QUFBQ0MsS0FiZUY7QUFBUSxJQUFBRTtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJIZWFkZXIiLCJNb2JpbGVOYXYiLCJGb290ZXIiLCJQcm90b3R5cGVOb3RpY2UiLCJDb21wYXJlVHJheSIsIkFwcFNoZWxsIiwiY2hpbGRyZW4iLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJBcHBTaGVsbC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHR5cGUgeyBSZWFjdE5vZGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IEhlYWRlciB9IGZyb20gXCIuL0hlYWRlclwiO1xuaW1wb3J0IHsgTW9iaWxlTmF2IH0gZnJvbSBcIi4vTW9iaWxlTmF2XCI7XG5pbXBvcnQgeyBGb290ZXIgfSBmcm9tIFwiLi9Gb290ZXJcIjtcbmltcG9ydCB7IFByb3RvdHlwZU5vdGljZSB9IGZyb20gXCIuL1Byb3RvdHlwZU5vdGljZVwiO1xuaW1wb3J0IHsgQ29tcGFyZVRyYXkgfSBmcm9tIFwiQC9jb21wb25lbnRzL3NwYWNlL0NvbXBhcmVUcmF5XCI7XG5cbmV4cG9ydCBmdW5jdGlvbiBBcHBTaGVsbCh7IGNoaWxkcmVuIH06IHsgY2hpbGRyZW46IFJlYWN0Tm9kZSB9KSB7XG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG1pbi1oLWR2aCBmbGV4LWNvbFwiPlxuICAgICAgPFByb3RvdHlwZU5vdGljZSAvPlxuICAgICAgPEhlYWRlciAvPlxuICAgICAgPG1haW4gaWQ9XCJtYWluXCIgY2xhc3NOYW1lPVwiZmxleC0xIHBiLTE0IG1kOnBiLTBcIj5cbiAgICAgICAge2NoaWxkcmVufVxuICAgICAgPC9tYWluPlxuICAgICAgPEZvb3RlciAvPlxuICAgICAgPENvbXBhcmVUcmF5IC8+XG4gICAgICA8TW9iaWxlTmF2IC8+XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXSwiZmlsZSI6IkQ6L0kySSBQcm9qZWN0IC0gSGFiaXRvL0FwcCBGb2xkZXIvaGFiaXRvL3NyYy9jb21wb25lbnRzL2xheW91dC9BcHBTaGVsbC50c3gifQ==