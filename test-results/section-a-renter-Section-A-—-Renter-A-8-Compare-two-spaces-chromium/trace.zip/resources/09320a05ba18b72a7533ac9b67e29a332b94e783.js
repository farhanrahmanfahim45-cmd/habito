import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/@fs/D:\\I2I Project - Habito\\App Folder\\habito\\src\\components\\layout\\MobileNav.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=9ceb86a3"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("D:/I2I Project - Habito/App Folder/habito/src/components/layout/MobileNav.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { NavLink } from "/node_modules/.vite/deps/react-router-dom.js?v=9ceb86a3";
import { Compass, Search, Bookmark, MessagesSquare, LayoutGrid } from "/node_modules/.vite/deps/lucide-react.js?v=9ceb86a3";
import { cn } from "/src/lib/cn.ts";
import { useHabito } from "/src/hooks/useHabito.tsx";
import { useI18n } from "/src/i18n/index.tsx";
export function MobileNav() {
  _s();
  const { savedIds, unreadMessages } = useHabito();
  const { t } = useI18n();
  const items = [
    { to: "/", key: "nav.home", icon: Compass, end: true },
    { to: "/search", key: "nav.search", icon: Search, end: false },
    { to: "/saved", key: "nav.saved", icon: Bookmark, end: false, count: savedIds.length },
    { to: "/messages", key: "nav.chats", icon: MessagesSquare, end: false, count: unreadMessages },
    { to: "/portfolio", key: "nav.portfolio", icon: LayoutGrid, end: false }
  ];
  return /* @__PURE__ */ jsxDEV(
    "nav",
    {
      "aria-label": "Main",
      className: "fixed inset-x-0 bottom-0 z-40 border-t border-hairline bg-surface/95 pb-[env(safe-area-inset-bottom)] backdrop-blur md:hidden",
      children: /* @__PURE__ */ jsxDEV("ul", { className: "flex", children: items.map((item) => {
        const count = "count" in item ? item.count : void 0;
        return /* @__PURE__ */ jsxDEV("li", { className: "flex-1", children: /* @__PURE__ */ jsxDEV(
          NavLink,
          {
            to: item.to,
            end: item.end,
            className: ({ isActive }) => cn(
              "flex h-14 flex-col items-center justify-center gap-0.5 px-1 text-[0.62rem] font-semibold transition-colors",
              isActive ? "text-ink" : "text-muted"
            ),
            children: ({ isActive }) => /* @__PURE__ */ jsxDEV(Fragment, { children: [
              /* @__PURE__ */ jsxDEV(
                "span",
                {
                  className: cn(
                    "relative rounded-full px-3 py-1 transition-colors",
                    isActive && "bg-aqua-100"
                  ),
                  children: [
                    /* @__PURE__ */ jsxDEV(item.icon, { size: 18, "aria-hidden": true }, void 0, false, {
                      fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/layout/MobileNav.tsx",
                      lineNumber: 71,
                      columnNumber: 23
                    }, this),
                    count ? /* @__PURE__ */ jsxDEV("span", { className: "absolute -right-0 -top-0.5 min-w-4 rounded-full bg-aqua-600 px-1 text-[0.55rem] font-bold leading-4 tnum text-white", children: count }, void 0, false, {
                      fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/layout/MobileNav.tsx",
                      lineNumber: 73,
                      columnNumber: 21
                    }, this) : null
                  ]
                },
                void 0,
                true,
                {
                  fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/layout/MobileNav.tsx",
                  lineNumber: 65,
                  columnNumber: 21
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("span", { className: "max-w-full truncate", children: t(item.key) }, void 0, false, {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/layout/MobileNav.tsx",
                lineNumber: 78,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/layout/MobileNav.tsx",
              lineNumber: 64,
              columnNumber: 17
            }, this)
          },
          void 0,
          false,
          {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/layout/MobileNav.tsx",
            lineNumber: 53,
            columnNumber: 15
          },
          this
        ) }, item.to, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/layout/MobileNav.tsx",
          lineNumber: 52,
          columnNumber: 13
        }, this);
      }) }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/layout/MobileNav.tsx",
        lineNumber: 48,
        columnNumber: 7
      }, this)
    },
    void 0,
    false,
    {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/layout/MobileNav.tsx",
      lineNumber: 44,
      columnNumber: 5
    },
    this
  );
}
_s(MobileNav, "PA1R8rNR/tkD+z0cJkYa0I9REm4=", false, function() {
  return [useHabito, useI18n];
});
_c = MobileNav;
var _c;
$RefreshReg$(_c, "MobileNav");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/I2I Project - Habito/App Folder/habito/src/components/layout/MobileNav.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/I2I Project - Habito/App Folder/habito/src/components/layout/MobileNav.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNENrQixtQkFPSSxjQVBKOzs7Ozs7Ozs7Ozs7Ozs7OztBQTVDbEIsU0FBU0EsZUFBZTtBQUN4QixTQUFTQyxTQUFTQyxRQUFRQyxVQUFVQyxnQkFBZ0JDLGtCQUFrQjtBQUN0RSxTQUFTQyxVQUFVO0FBQ25CLFNBQVNDLGlCQUFpQjtBQUMxQixTQUFTQyxlQUFlO0FBT2pCLGdCQUFTQyxZQUFZO0FBQUFDLEtBQUE7QUFDMUIsUUFBTSxFQUFFQyxVQUFVQyxlQUFlLElBQUlMLFVBQVU7QUFDL0MsUUFBTSxFQUFFTSxFQUFFLElBQUlMLFFBQVE7QUFFdEIsUUFBTU0sUUFBUTtBQUFBLElBQ1osRUFBRUMsSUFBSSxLQUFLQyxLQUFLLFlBQVlDLE1BQU1oQixTQUFTaUIsS0FBSyxLQUFLO0FBQUEsSUFDckQsRUFBRUgsSUFBSSxXQUFXQyxLQUFLLGNBQWNDLE1BQU1mLFFBQVFnQixLQUFLLE1BQU07QUFBQSxJQUM3RCxFQUFFSCxJQUFJLFVBQVVDLEtBQUssYUFBYUMsTUFBTWQsVUFBVWUsS0FBSyxPQUFPQyxPQUFPUixTQUFTUyxPQUFPO0FBQUEsSUFDckYsRUFBRUwsSUFBSSxhQUFhQyxLQUFLLGFBQWFDLE1BQU1iLGdCQUFnQmMsS0FBSyxPQUFPQyxPQUFPUCxlQUFlO0FBQUEsSUFDN0YsRUFBRUcsSUFBSSxjQUFjQyxLQUFLLGlCQUFpQkMsTUFBTVosWUFBWWEsS0FBSyxNQUFNO0FBQUEsRUFBQztBQUcxRSxTQUNFO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDQyxjQUFXO0FBQUEsTUFDWCxXQUFVO0FBQUEsTUFFVixpQ0FBQyxRQUFHLFdBQVUsUUFDWEosZ0JBQU1PLElBQUksQ0FBQ0MsU0FBUztBQUNuQixjQUFNSCxRQUFRLFdBQVdHLE9BQU9BLEtBQUtILFFBQVFJO0FBQzdDLGVBQ0UsdUJBQUMsUUFBaUIsV0FBVSxVQUMxQjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsSUFBSUQsS0FBS1A7QUFBQUEsWUFDVCxLQUFLTyxLQUFLSjtBQUFBQSxZQUNWLFdBQVcsQ0FBQyxFQUFFTSxTQUFTLE1BQ3JCbEI7QUFBQUEsY0FDRTtBQUFBLGNBQ0FrQixXQUFXLGFBQWE7QUFBQSxZQUMxQjtBQUFBLFlBR0QsV0FBQyxFQUFFQSxTQUFTLE1BQ1gsbUNBQ0U7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFXbEI7QUFBQUEsb0JBQ1Q7QUFBQSxvQkFDQWtCLFlBQVk7QUFBQSxrQkFDZDtBQUFBLGtCQUVBO0FBQUEsMkNBQUMsS0FBSyxNQUFMLEVBQVUsTUFBTSxJQUFJLGVBQVcsUUFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBZ0M7QUFBQSxvQkFDL0JMLFFBQ0MsdUJBQUMsVUFBSyxXQUFVLHVIQUNiQSxtQkFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBLElBQ0U7QUFBQTtBQUFBO0FBQUEsZ0JBWE47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBWUE7QUFBQSxjQUNBLHVCQUFDLFVBQUssV0FBVSx1QkFBdUJOLFlBQUVTLEtBQUtOLEdBQUcsS0FBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBbUQ7QUFBQSxpQkFkckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFlQTtBQUFBO0FBQUEsVUExQko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBNEJBLEtBN0JPTSxLQUFLUCxJQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUE4QkE7QUFBQSxNQUVKLENBQUMsS0FwQ0g7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXFDQTtBQUFBO0FBQUEsSUF6Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBMENBO0FBRUo7QUFBQ0wsR0F6RGVELFdBQVM7QUFBQSxVQUNjRixXQUN2QkMsT0FBTztBQUFBO0FBQUEsS0FGUEM7QUFBUyxJQUFBZ0I7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsiTmF2TGluayIsIkNvbXBhc3MiLCJTZWFyY2giLCJCb29rbWFyayIsIk1lc3NhZ2VzU3F1YXJlIiwiTGF5b3V0R3JpZCIsImNuIiwidXNlSGFiaXRvIiwidXNlSTE4biIsIk1vYmlsZU5hdiIsIl9zIiwic2F2ZWRJZHMiLCJ1bnJlYWRNZXNzYWdlcyIsInQiLCJpdGVtcyIsInRvIiwia2V5IiwiaWNvbiIsImVuZCIsImNvdW50IiwibGVuZ3RoIiwibWFwIiwiaXRlbSIsInVuZGVmaW5lZCIsImlzQWN0aXZlIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiTW9iaWxlTmF2LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBOYXZMaW5rIH0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIjtcbmltcG9ydCB7IENvbXBhc3MsIFNlYXJjaCwgQm9va21hcmssIE1lc3NhZ2VzU3F1YXJlLCBMYXlvdXRHcmlkIH0gZnJvbSBcImx1Y2lkZS1yZWFjdFwiO1xuaW1wb3J0IHsgY24gfSBmcm9tIFwiQC9saWIvY25cIjtcbmltcG9ydCB7IHVzZUhhYml0byB9IGZyb20gXCJAL2hvb2tzL3VzZUhhYml0b1wiO1xuaW1wb3J0IHsgdXNlSTE4biB9IGZyb20gXCJAL2kxOG5cIjtcblxuLyoqXG4gKiBGaXZlIGRlc3RpbmF0aW9ucywgdGhlIHNhbWUgZm9yIGV2ZXJ5b25lLiBNeSBzcGFjZXMgaXMgYWx3YXlzIGhlcmUgcmF0aGVyXG4gKiB0aGFuIGJlaGluZCBhIG1vZGUsIGJlY2F1c2UgbGlzdGluZyBhIHJvb20gaXMgc29tZXRoaW5nIGEgcmVudGVyIG1pZ2h0IGRvXG4gKiBuZXh0IHdlZWsgd2l0aG91dCB3YW50aW5nIHRvIHRoaW5rIGFib3V0IHdoaWNoIGtpbmQgb2YgdXNlciB0aGV5IGFyZS5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIE1vYmlsZU5hdigpIHtcbiAgY29uc3QgeyBzYXZlZElkcywgdW5yZWFkTWVzc2FnZXMgfSA9IHVzZUhhYml0bygpO1xuICBjb25zdCB7IHQgfSA9IHVzZUkxOG4oKTtcblxuICBjb25zdCBpdGVtcyA9IFtcbiAgICB7IHRvOiBcIi9cIiwga2V5OiBcIm5hdi5ob21lXCIsIGljb246IENvbXBhc3MsIGVuZDogdHJ1ZSB9LFxuICAgIHsgdG86IFwiL3NlYXJjaFwiLCBrZXk6IFwibmF2LnNlYXJjaFwiLCBpY29uOiBTZWFyY2gsIGVuZDogZmFsc2UgfSxcbiAgICB7IHRvOiBcIi9zYXZlZFwiLCBrZXk6IFwibmF2LnNhdmVkXCIsIGljb246IEJvb2ttYXJrLCBlbmQ6IGZhbHNlLCBjb3VudDogc2F2ZWRJZHMubGVuZ3RoIH0sXG4gICAgeyB0bzogXCIvbWVzc2FnZXNcIiwga2V5OiBcIm5hdi5jaGF0c1wiLCBpY29uOiBNZXNzYWdlc1NxdWFyZSwgZW5kOiBmYWxzZSwgY291bnQ6IHVucmVhZE1lc3NhZ2VzIH0sXG4gICAgeyB0bzogXCIvcG9ydGZvbGlvXCIsIGtleTogXCJuYXYucG9ydGZvbGlvXCIsIGljb246IExheW91dEdyaWQsIGVuZDogZmFsc2UgfSxcbiAgXSBhcyBjb25zdDtcblxuICByZXR1cm4gKFxuICAgIDxuYXZcbiAgICAgIGFyaWEtbGFiZWw9XCJNYWluXCJcbiAgICAgIGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LXgtMCBib3R0b20tMCB6LTQwIGJvcmRlci10IGJvcmRlci1oYWlybGluZSBiZy1zdXJmYWNlLzk1IHBiLVtlbnYoc2FmZS1hcmVhLWluc2V0LWJvdHRvbSldIGJhY2tkcm9wLWJsdXIgbWQ6aGlkZGVuXCJcbiAgICA+XG4gICAgICA8dWwgY2xhc3NOYW1lPVwiZmxleFwiPlxuICAgICAgICB7aXRlbXMubWFwKChpdGVtKSA9PiB7XG4gICAgICAgICAgY29uc3QgY291bnQgPSBcImNvdW50XCIgaW4gaXRlbSA/IGl0ZW0uY291bnQgOiB1bmRlZmluZWQ7XG4gICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgIDxsaSBrZXk9e2l0ZW0udG99IGNsYXNzTmFtZT1cImZsZXgtMVwiPlxuICAgICAgICAgICAgICA8TmF2TGlua1xuICAgICAgICAgICAgICAgIHRvPXtpdGVtLnRvfVxuICAgICAgICAgICAgICAgIGVuZD17aXRlbS5lbmR9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXsoeyBpc0FjdGl2ZSB9KSA9PlxuICAgICAgICAgICAgICAgICAgY24oXG4gICAgICAgICAgICAgICAgICAgIFwiZmxleCBoLTE0IGZsZXgtY29sIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMC41IHB4LTEgdGV4dC1bMC42MnJlbV0gZm9udC1zZW1pYm9sZCB0cmFuc2l0aW9uLWNvbG9yc1wiLFxuICAgICAgICAgICAgICAgICAgICBpc0FjdGl2ZSA/IFwidGV4dC1pbmtcIiA6IFwidGV4dC1tdXRlZFwiLFxuICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIHsoeyBpc0FjdGl2ZSB9KSA9PiAoXG4gICAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgICA8c3BhblxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgICAgICAgICAgICAgICAgICBcInJlbGF0aXZlIHJvdW5kZWQtZnVsbCBweC0zIHB5LTEgdHJhbnNpdGlvbi1jb2xvcnNcIixcbiAgICAgICAgICAgICAgICAgICAgICAgIGlzQWN0aXZlICYmIFwiYmctYXF1YS0xMDBcIixcbiAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgPGl0ZW0uaWNvbiBzaXplPXsxOH0gYXJpYS1oaWRkZW4gLz5cbiAgICAgICAgICAgICAgICAgICAgICB7Y291bnQgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJhYnNvbHV0ZSAtcmlnaHQtMCAtdG9wLTAuNSBtaW4tdy00IHJvdW5kZWQtZnVsbCBiZy1hcXVhLTYwMCBweC0xIHRleHQtWzAuNTVyZW1dIGZvbnQtYm9sZCBsZWFkaW5nLTQgdG51bSB0ZXh0LXdoaXRlXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtjb3VudH1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICApIDogbnVsbH1cbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtYXgtdy1mdWxsIHRydW5jYXRlXCI+e3QoaXRlbS5rZXkpfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgIDwvTmF2TGluaz5cbiAgICAgICAgICAgIDwvbGk+XG4gICAgICAgICAgKTtcbiAgICAgICAgfSl9XG4gICAgICA8L3VsPlxuICAgIDwvbmF2PlxuICApO1xufVxuIl0sImZpbGUiOiJEOi9JMkkgUHJvamVjdCAtIEhhYml0by9BcHAgRm9sZGVyL2hhYml0by9zcmMvY29tcG9uZW50cy9sYXlvdXQvTW9iaWxlTmF2LnRzeCJ9