import seed from "/src/data/seed.json?import";
const localListeners = /* @__PURE__ */ new Set();
const notifyLocalChange = () => localListeners.forEach((fn) => fn());
const KEY = "habito.db.v2";
const SEED_STAMP = `${seed.generatedOn}:${seed.spaces.length}:${seed.properties.length}`;
const LATENCY_MS = 0;
let receiptCounter = 0;
const TRANSITIONS = {
  requested: ["accepted", "rejected", "cancelled"],
  accepted: ["payment-pending", "confirmed", "cancelled"],
  "payment-pending": ["confirmed", "payment-failed", "cancelled"],
  "payment-failed": ["payment-pending", "cancelled"],
  confirmed: ["completed", "cancelled"],
  completed: [],
  rejected: [],
  cancelled: []
};
const LOCAL_USER_ID = "LOCAL-USER";
export const DEMO_OWNER_ID = "OW-001";
function freshDatabase() {
  return {
    version: 1,
    seedStamp: SEED_STAMP,
    owners: seed.owners,
    properties: seed.properties,
    spaces: seed.spaces,
    inquiries: [],
    requests: [],
    savedIds: [],
    threads: [],
    bookings: [],
    invoices: []
  };
}
function read() {
  if (typeof window === "undefined") return freshDatabase();
  try {
    const raw = window.localStorage.getItem(KEY);
    if (!raw) {
      const fresh = freshDatabase();
      write(fresh);
      return fresh;
    }
    const parsed = JSON.parse(raw);
    if (parsed.version !== 1) throw new Error("schema changed");
    if (parsed.seedStamp !== SEED_STAMP) {
      const merged = freshDatabase();
      merged.properties = [...parsed.properties.filter((p) => !p.synthetic), ...merged.properties];
      merged.spaces = [...parsed.spaces.filter((s) => !s.synthetic), ...merged.spaces];
      merged.inquiries = parsed.inquiries ?? [];
      merged.requests = parsed.requests ?? [];
      merged.savedIds = (parsed.savedIds ?? []).filter((id) => merged.spaces.some((s) => s.id === id));
      merged.threads = parsed.threads ?? [];
      merged.bookings = parsed.bookings ?? [];
      merged.invoices = parsed.invoices ?? [];
      for (const space of merged.spaces) {
        if (!space.status) space.status = "published";
        if (!space.status) space.status = "published";
        if (!space.rules) {
          space.rules = {
            familyAllowed: true,
            bachelorAllowed: true,
            studentFriendly: true,
            genderPreference: "any",
            maxOccupants: null
          };
        }
      }
      write(merged);
      return merged;
    }
    return parsed;
  } catch {
    const fresh = freshDatabase();
    write(fresh);
    return fresh;
  }
}
function write(db) {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(KEY, JSON.stringify(db));
  } catch {
    console.warn("Habito: could not persist changes to local storage.");
  }
}
const settle = (value) => LATENCY_MS ? new Promise((r) => setTimeout(() => r(value), LATENCY_MS)) : Promise.resolve(value);
function join(db, space) {
  const property = db.properties.find((p) => p.id === space.propertyId);
  if (!property) return null;
  const owner = db.owners.find((o) => o.id === property.ownerId);
  if (!owner) return null;
  return { space, property, owner };
}
function nextId(prefix, existing) {
  const max = existing.reduce((m, x) => {
    const n = Number(x.id.split("-")[1]);
    return Number.isFinite(n) && n > m ? n : m;
  }, 0);
  return `${prefix}-${String(max + 1).padStart(4, "0")}`;
}
export const localRepository = {
  kind: "local",
  /* ── Reads ──────────────────────────────────────────────────────── */
  async listings() {
    const data = read();
    return settle(
      data.spaces.filter((s) => s.status !== "archived").map((s) => join(data, s)).filter((x) => x !== null)
    );
  },
  async listing(spaceId) {
    const data = read();
    const space = data.spaces.find((s) => s.id === spaceId);
    return settle(space ? join(data, space) : null);
  },
  async properties(ownerId) {
    const data = read();
    return settle(ownerId ? data.properties.filter((p) => p.ownerId === ownerId) : data.properties);
  },
  async spacesOfProperty(propertyId) {
    const data = read();
    return settle(data.spaces.filter((s) => s.propertyId === propertyId));
  },
  async space(spaceId) {
    return settle(read().spaces.find((s) => s.id === spaceId) ?? null);
  },
  async owner(ownerId) {
    const data = read();
    return settle(data.owners.find((o) => o.id === ownerId) ?? null);
  },
  /* ── Owner writes ───────────────────────────────────────────────── */
  async createProperty(input) {
    const data = read();
    const property = {
      ...input,
      id: nextId("PR", data.properties),
      createdAt: (/* @__PURE__ */ new Date()).toISOString().slice(0, 10),
      synthetic: false
    };
    data.properties = [property, ...data.properties];
    write(data);
    return settle(property);
  },
  async createSpace(input) {
    const data = read();
    const space = {
      ...input,
      id: nextId("SP", data.spaces),
      views: 0,
      inquiryCount: 0,
      synthetic: false
    };
    data.spaces = [space, ...data.spaces];
    write(data);
    return settle(space);
  },
  async updateSpace(spaceId, patch) {
    const data = read();
    const index = data.spaces.findIndex((s) => s.id === spaceId);
    if (index === -1) return settle(null);
    const updated = {
      ...data.spaces[index],
      ...patch,
      lastUpdated: (/* @__PURE__ */ new Date()).toISOString().slice(0, 10)
    };
    data.spaces[index] = updated;
    write(data);
    return settle(updated);
  },
  async deleteSpace(spaceId) {
    const data = read();
    data.spaces = data.spaces.filter((s) => s.id !== spaceId);
    write(data);
    return settle(void 0);
  },
  /* ── Seeker writes ──────────────────────────────────────────────── */
  async saved() {
    return settle(read().savedIds);
  },
  async toggleSaved(spaceId) {
    const data = read();
    const has = data.savedIds.includes(spaceId);
    data.savedIds = has ? data.savedIds.filter((x) => x !== spaceId) : [...data.savedIds, spaceId];
    write(data);
    return settle(!has);
  },
  async inquiries() {
    return settle(read().inquiries);
  },
  async createInquiry(input) {
    const data = read();
    const inquiry = {
      ...input,
      id: nextId("INQ", data.inquiries),
      sentAt: (/* @__PURE__ */ new Date()).toISOString(),
      status: "new"
    };
    data.inquiries = [inquiry, ...data.inquiries];
    let thread = data.threads.find((t) => t.spaceId === input.spaceId);
    if (!thread) {
      thread = { id: `CONV-${Date.now()}`, spaceId: input.spaceId, messages: [] };
      data.threads.push(thread);
    }
    thread.messages.push({
      id: `MSG-${Date.now()}`,
      senderId: LOCAL_USER_ID,
      body: input.message,
      sentAt: (/* @__PURE__ */ new Date()).toISOString(),
      readAt: null
    });
    const index = data.spaces.findIndex((s) => s.id === input.spaceId);
    if (index !== -1) {
      data.spaces[index] = { ...data.spaces[index], inquiryCount: data.spaces[index].inquiryCount + 1 };
    }
    write(data);
    return settle(inquiry);
  },
  async setInquiryStatus(inquiryId, status) {
    const data = read();
    const index = data.inquiries.findIndex((i) => i.id === inquiryId);
    if (index !== -1) {
      data.inquiries[index] = { ...data.inquiries[index], status };
      write(data);
    }
    return settle(void 0);
  },
  async requests() {
    return settle(read().requests);
  },
  async createRequest(input) {
    const data = read();
    const request = {
      ...input,
      id: nextId("REQ", data.requests),
      createdAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    data.requests = [request, ...data.requests];
    write(data);
    return settle(request);
  },
  /* ── Bookings ───────────────────────────────────────────────────── */
  async bookings() {
    const data = read();
    return settle(
      data.bookings.map((b) => {
        const space = data.spaces.find((s) => s.id === b.spaceId);
        const property = space ? data.properties.find((p) => p.id === space.propertyId) : void 0;
        const owner = property ? data.owners.find((o) => o.id === property.ownerId) : void 0;
        return {
          id: b.id,
          spaceId: b.spaceId,
          spaceName: space?.name ?? "A space",
          spaceImage: space?.images[0]?.url ?? null,
          area: property?.area ?? null,
          renterId: LOCAL_USER_ID,
          // Without accounts one person plays both sides, so naming the renter
          // "You" produces "with You" and "You's number". Label it as the demo
          // counterpart instead.
          renterName: "Demo renter",
          ownerId: owner?.id ?? "",
          ownerName: owner?.name ?? "Owner",
          status: b.status,
          moveInDate: b.moveInDate,
          months: b.months,
          amount: b.amount,
          message: b.message,
          phoneShared: b.phoneShared,
          renterPhone: b.phoneShared ? "01700000000" : null,
          ownerPhone: b.phoneShared ? "01800000000" : null,
          declineReason: b.declineReason,
          createdAt: b.createdAt,
          decidedAt: b.decidedAt,
          // Without accounts there is one person, who sees both sides.
          youAreOwner: true
        };
      })
    );
  },
  async requestBooking(input) {
    const data = read();
    const space = data.spaces.find((s) => s.id === input.spaceId);
    if (!space) throw new Error("That space no longer exists.");
    if (space.availability.status === "occupied" || space.availability.status === "maintenance") {
      throw new Error("That space is not available to book.");
    }
    const booking = {
      id: `BK-${Date.now()}`,
      spaceId: input.spaceId,
      status: "requested",
      moveInDate: input.moveInDate,
      months: input.months,
      amount: input.amount,
      message: input.message ?? null,
      phoneShared: false,
      createdAt: (/* @__PURE__ */ new Date()).toISOString(),
      decidedAt: null,
      declineReason: null
    };
    data.bookings = [booking, ...data.bookings];
    write(data);
    const [made] = await this.bookings();
    return made;
  },
  async setBookingStatus(bookingId, status, reason) {
    const data = read();
    const booking = data.bookings.find((b) => b.id === bookingId);
    if (!booking) return settle(void 0);
    if (!TRANSITIONS[booking.status].includes(status)) {
      throw new Error(`A booking cannot go from ${booking.status} to ${status}.`);
    }
    booking.status = status;
    if (reason !== void 0) booking.declineReason = reason;
    if (status === "accepted") {
      booking.phoneShared = true;
      booking.decidedAt = (/* @__PURE__ */ new Date()).toISOString();
    }
    if (status === "rejected") booking.decidedAt = (/* @__PURE__ */ new Date()).toISOString();
    if (status === "confirmed") {
      const start = new Date(booking.moveInDate);
      for (let i = 0; i < Math.max(booking.months, 1); i++) {
        const period = new Date(start.getFullYear(), start.getMonth() + i, start.getDate());
        const iso = period.toISOString().slice(0, 10);
        if (data.invoices.some((x) => x.bookingId === booking.id && x.periodStart === iso)) continue;
        data.invoices.push({
          id: `INV-${booking.id}-${i}`,
          bookingId: booking.id,
          spaceId: booking.spaceId,
          periodStart: iso,
          dueDate: iso,
          amount: booking.amount,
          status: "due",
          paidAt: null,
          receiptNo: null
        });
      }
    }
    const space = data.spaces.find((s) => s.id === booking.spaceId);
    if (space) {
      if (status === "confirmed") space.availability = { ...space.availability, status: "occupied" };
      if (status === "completed" || status === "cancelled") {
        space.availability = { ...space.availability, status: "available" };
      }
    }
    write(data);
    return settle(void 0);
  },
  /* ── Moderation ─────────────────────────────────────────────────── */
  // Moderation is meaningless without accounts to moderate. Rather than
  // simulate a queue, this build says so.
  async reviewQueue() {
    return settle([]);
  },
  async setListingVisible() {
    throw new Error("Moderation needs the database. This build has no accounts.");
  },
  async setTrust() {
    throw new Error("Moderation needs the database. This build has no accounts.");
  },
  async resolveReports() {
    throw new Error("Moderation needs the database. This build has no accounts.");
  },
  async clearDuplicate() {
    throw new Error("Moderation needs the database. This build has no accounts.");
  },
  /* ── Listing fees ───────────────────────────────────────────────── */
  async listingFee(category) {
    const prices = { "living": 200, "business": 500, "storage": 400, "parking": 100, "land": 500 };
    return settle(prices[category] ?? 200);
  },
  async listingAllowance(propertyId) {
    const data = read();
    const month = (/* @__PURE__ */ new Date()).toISOString().slice(0, 7);
    const used = data.spaces.filter(
      (s) => s.propertyId === propertyId && !s.synthetic && (s.publishedAt ?? "").startsWith(month)
    ).length;
    return settle({ used, hasPlan: false });
  },
  async payListingFee(spaceId) {
    const data = read();
    const space = data.spaces.find((s) => s.id === spaceId);
    if (space) {
      space.listingFeePaid = true;
      space.publishedAt = (/* @__PURE__ */ new Date()).toISOString();
      write(data);
    }
    return settle(void 0);
  },
  async buyPropertyPlan() {
    return settle(void 0);
  },
  /* ── Rent ───────────────────────────────────────────────────────── */
  async invoices() {
    const data = read();
    const today = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
    return settle(
      data.invoices.map((inv) => {
        const space = data.spaces.find((s) => s.id === inv.spaceId);
        const property = space ? data.properties.find((p) => p.id === space.propertyId) : void 0;
        const owner = property ? data.owners.find((o) => o.id === property.ownerId) : void 0;
        return {
          id: inv.id,
          bookingId: inv.bookingId,
          spaceId: inv.spaceId,
          spaceName: space?.name ?? "A space",
          area: property?.area ?? null,
          counterpartName: owner?.name ?? "Owner",
          youAreOwner: true,
          periodStart: inv.periodStart,
          periodEnd: inv.periodStart,
          dueDate: inv.dueDate,
          // Overdue is a fact about the date, not something stored.
          status: inv.status === "due" && inv.dueDate < today ? "overdue" : inv.status,
          amount: inv.amount,
          paidAt: inv.paidAt,
          receiptNo: inv.receiptNo,
          simulated: true
        };
      })
    );
  },
  async payInvoice(invoiceId) {
    const data = read();
    const inv = data.invoices.find((i) => i.id === invoiceId);
    if (!inv || inv.status === "paid") return settle(void 0);
    inv.status = "paid";
    inv.paidAt = (/* @__PURE__ */ new Date()).toISOString();
    inv.receiptNo = `HAB-${(/* @__PURE__ */ new Date()).getFullYear()}-${String(++receiptCounter).padStart(6, "0")}`;
    write(data);
    return settle(void 0);
  },
  async waiveInvoice(invoiceId) {
    const data = read();
    const inv = data.invoices.find((i) => i.id === invoiceId);
    if (inv && inv.status !== "paid") inv.status = "waived";
    write(data);
    return settle(void 0);
  },
  async extendSchedule(bookingId, months = 12) {
    const data = read();
    const booking = data.bookings.find((b) => b.id === bookingId);
    if (!booking) return settle(void 0);
    const existing = data.invoices.filter((i) => i.bookingId === bookingId);
    const sorted = existing.map((i) => i.periodStart).sort();
    const lastIso = sorted.length ? sorted[sorted.length - 1] : booking.moveInDate;
    const last = new Date(lastIso);
    for (let i = 1; i <= months; i++) {
      const period = new Date(last.getFullYear(), last.getMonth() + i, last.getDate());
      const iso = period.toISOString().slice(0, 10);
      if (data.invoices.some((x) => x.bookingId === bookingId && x.periodStart === iso)) continue;
      data.invoices.push({
        id: `INV-${bookingId}-${iso}`,
        bookingId,
        spaceId: booking.spaceId,
        periodStart: iso,
        dueDate: iso,
        amount: booking.amount,
        status: "due",
        paidAt: null,
        receiptNo: null
      });
    }
    write(data);
    return settle(void 0);
  },
  /* ── Messaging ──────────────────────────────────────────────────── */
  async conversations() {
    const data = read();
    return settle(
      data.threads.map((thread) => {
        const space = data.spaces.find((s) => s.id === thread.spaceId);
        const property = space ? data.properties.find((p) => p.id === space.propertyId) : void 0;
        const owner = property ? data.owners.find((o) => o.id === property.ownerId) : void 0;
        const last = thread.messages[thread.messages.length - 1];
        return {
          id: thread.id,
          spaceId: thread.spaceId,
          spaceName: space?.name ?? "A space",
          spaceImage: space?.images[0]?.url ?? null,
          propertyArea: property?.area ?? null,
          counterpartId: owner?.id ?? "",
          counterpartName: owner?.name ?? "Owner",
          counterpartTone: owner?.avatarTone ?? "aqua",
          youAreOwner: false,
          lastMessage: last?.body ?? "",
          lastMessageAt: last?.sentAt ?? (/* @__PURE__ */ new Date()).toISOString(),
          unread: thread.messages.filter((m) => m.senderId !== LOCAL_USER_ID && !m.readAt).length
        };
      }).sort((a, b) => b.lastMessageAt.localeCompare(a.lastMessageAt))
    );
  },
  async messages(conversationId) {
    const thread = read().threads.find((t) => t.id === conversationId);
    if (!thread) return settle([]);
    return settle(
      thread.messages.map((m) => ({
        id: m.id,
        conversationId,
        senderId: m.senderId,
        body: m.body,
        sentAt: m.sentAt,
        readAt: m.readAt,
        mine: m.senderId === LOCAL_USER_ID
      }))
    );
  },
  async sendMessage(conversationId, body) {
    const data = read();
    const thread = data.threads.find((t) => t.id === conversationId);
    if (!thread) throw new Error("That conversation no longer exists.");
    const message = {
      id: `MSG-${Date.now()}`,
      senderId: LOCAL_USER_ID,
      body,
      sentAt: (/* @__PURE__ */ new Date()).toISOString(),
      readAt: null
    };
    thread.messages.push(message);
    write(data);
    notifyLocalChange();
    return settle({ ...message, conversationId, mine: true });
  },
  async markRead(conversationId) {
    const data = read();
    const thread = data.threads.find((t) => t.id === conversationId);
    if (!thread) return settle(void 0);
    const now = (/* @__PURE__ */ new Date()).toISOString();
    for (const m of thread.messages) {
      if (m.senderId !== LOCAL_USER_ID && !m.readAt) m.readAt = now;
    }
    write(data);
    return settle(void 0);
  },
  async openConversation(spaceId) {
    const data = read();
    const existing = data.threads.find((t) => t.spaceId === spaceId);
    if (existing) return settle(existing.id);
    const thread = { id: `CONV-${Date.now()}`, spaceId, messages: [] };
    data.threads.push(thread);
    write(data);
    return settle(thread.id);
  },
  subscribeToMessages(onChange) {
    localListeners.add(onChange);
    return () => localListeners.delete(onChange);
  },
  /* ── Maintenance ────────────────────────────────────────────────── */
  async reset() {
    if (typeof window !== "undefined") window.localStorage.removeItem(KEY);
    read();
    return settle(void 0);
  }
};
export const DATASET_NOTICE = seed._notice;

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImxvY2FsLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBzZWVkIGZyb20gXCJAL2RhdGEvc2VlZC5qc29uXCI7XG5pbXBvcnQgdHlwZSB7IFJlcG9zaXRvcnkgfSBmcm9tIFwiLi90eXBlc1wiO1xuXG4vKiogTGlzdGVuZXJzIGZvciBpbi10YWIgY2hhbmdlcywgc28gdGhlIHRocmVhZCB2aWV3IHVwZGF0ZXMgYXMgeW91IHNlbmQuICovXG5jb25zdCBsb2NhbExpc3RlbmVycyA9IG5ldyBTZXQ8KCkgPT4gdm9pZD4oKTtcbmNvbnN0IG5vdGlmeUxvY2FsQ2hhbmdlID0gKCkgPT4gbG9jYWxMaXN0ZW5lcnMuZm9yRWFjaCgoZm4pID0+IGZuKCkpO1xuaW1wb3J0IHR5cGUge1xuICBCb29raW5nLFxuICBCb29raW5nU3RhdHVzLFxuICBDb252ZXJzYXRpb24sXG4gIElucXVpcnksXG4gIElucXVpcnlTdGF0dXMsXG4gIE1lc3NhZ2UsXG4gIFJlbnRJbnZvaWNlLFxuICBSZXZpZXdJdGVtLFxuXG4gIE93bmVyLFxuICBQcm9wZXJ0eSxcbiAgU3BhY2UsXG4gIFNwYWNlTGlzdGluZyxcbiAgU3BhY2VSZXF1ZXN0LFxufSBmcm9tIFwiQC90eXBlcy9zcGFjZVwiO1xuXG4vKipcbiAqIExvY2FsIHJlcG9zaXRvcnkg4oCUIHRoZSBvZmZsaW5lIGZhbGxiYWNrLlxuICpcbiAqIFVzZWQgd2hlbiBTdXBhYmFzZSBjcmVkZW50aWFscyBhcmVuJ3QgY29uZmlndXJlZCwgc28gYSBmcmVzaCBjbG9uZSBydW5zIHdpdGhcbiAqIG5vIHNldHVwIGFuZCBhIG1pc3NpbmcgZW52aXJvbm1lbnQgdmFyaWFibGUgZGVncmFkZXMgaW5zdGVhZCBvZiBicmVha2luZy5cbiAqIERhdGEgbGl2ZXMgaW4gdGhpcyBicm93c2VyIG9ubHkgYW5kIGlzIG5ldmVyIHNoYXJlZCBiZXR3ZWVuIGFjY291bnRzLlxuICovXG5cbmNvbnN0IEtFWSA9IFwiaGFiaXRvLmRiLnYyXCI7XG5cbi8qKlxuICogQ2hhbmdlcyB3aXRoIHRoZSBzZWVkIGZpbGUuIFdoZW4gYSBuZXcgYnVpbGQgc2hpcHMgZnJlc2ggc2VlZCBkYXRhLCByZXR1cm5pbmdcbiAqIHZpc2l0b3JzIHdvdWxkIG90aGVyd2lzZSBrZWVwIHRoZSBvbGQgZGF0YXNldCBmb3JldmVyIOKAlCBzbyB3ZSByZS1zZWVkLCB3aGlsZVxuICogcHJlc2VydmluZyBhbnl0aGluZyB0aGUgcGVyc29uIGNyZWF0ZWQgdGhlbXNlbHZlcy5cbiAqL1xuY29uc3QgU0VFRF9TVEFNUCA9IGAke3NlZWQuZ2VuZXJhdGVkT259OiR7c2VlZC5zcGFjZXMubGVuZ3RofToke3NlZWQucHJvcGVydGllcy5sZW5ndGh9YDtcbmNvbnN0IExBVEVOQ1lfTVMgPSAwO1xuXG5pbnRlcmZhY2UgRGF0YWJhc2Uge1xuICB2ZXJzaW9uOiAxO1xuICBzZWVkU3RhbXA6IHN0cmluZztcbiAgb3duZXJzOiBPd25lcltdO1xuICBwcm9wZXJ0aWVzOiBQcm9wZXJ0eVtdO1xuICBzcGFjZXM6IFNwYWNlW107XG4gIGlucXVpcmllczogSW5xdWlyeVtdO1xuICByZXF1ZXN0czogU3BhY2VSZXF1ZXN0W107XG4gIHNhdmVkSWRzOiBzdHJpbmdbXTtcbiAgdGhyZWFkczogTG9jYWxUaHJlYWRbXTtcbiAgYm9va2luZ3M6IExvY2FsQm9va2luZ1tdO1xuICBpbnZvaWNlczogTG9jYWxJbnZvaWNlW107XG59XG5cbmludGVyZmFjZSBMb2NhbEludm9pY2Uge1xuICBpZDogc3RyaW5nO1xuICBib29raW5nSWQ6IHN0cmluZztcbiAgc3BhY2VJZDogc3RyaW5nO1xuICBwZXJpb2RTdGFydDogc3RyaW5nO1xuICBkdWVEYXRlOiBzdHJpbmc7XG4gIGFtb3VudDogbnVtYmVyO1xuICBzdGF0dXM6IFJlbnRJbnZvaWNlW1wic3RhdHVzXCJdO1xuICBwYWlkQXQ6IHN0cmluZyB8IG51bGw7XG4gIHJlY2VpcHRObzogc3RyaW5nIHwgbnVsbDtcbn1cblxubGV0IHJlY2VpcHRDb3VudGVyID0gMDtcblxuaW50ZXJmYWNlIExvY2FsQm9va2luZyB7XG4gIGlkOiBzdHJpbmc7XG4gIHNwYWNlSWQ6IHN0cmluZztcbiAgc3RhdHVzOiBCb29raW5nU3RhdHVzO1xuICBtb3ZlSW5EYXRlOiBzdHJpbmc7XG4gIG1vbnRoczogbnVtYmVyO1xuICBhbW91bnQ6IG51bWJlcjtcbiAgbWVzc2FnZTogc3RyaW5nIHwgbnVsbDtcbiAgcGhvbmVTaGFyZWQ6IGJvb2xlYW47XG4gIGNyZWF0ZWRBdDogc3RyaW5nO1xuICBkZWNpZGVkQXQ6IHN0cmluZyB8IG51bGw7XG4gIGRlY2xpbmVSZWFzb246IHN0cmluZyB8IG51bGw7XG59XG5cbi8qKiBUaGUgc2FtZSBtb3ZlcyB0aGUgZGF0YWJhc2UgYWxsb3dzLCBtaXJyb3JlZCBzbyBib3RoIGJhY2tlbmRzIGJlaGF2ZSBhbGlrZS4gKi9cbmNvbnN0IFRSQU5TSVRJT05TOiBSZWNvcmQ8Qm9va2luZ1N0YXR1cywgQm9va2luZ1N0YXR1c1tdPiA9IHtcbiAgcmVxdWVzdGVkOiBbXCJhY2NlcHRlZFwiLCBcInJlamVjdGVkXCIsIFwiY2FuY2VsbGVkXCJdLFxuICBhY2NlcHRlZDogW1wicGF5bWVudC1wZW5kaW5nXCIsIFwiY29uZmlybWVkXCIsIFwiY2FuY2VsbGVkXCJdLFxuICBcInBheW1lbnQtcGVuZGluZ1wiOiBbXCJjb25maXJtZWRcIiwgXCJwYXltZW50LWZhaWxlZFwiLCBcImNhbmNlbGxlZFwiXSxcbiAgXCJwYXltZW50LWZhaWxlZFwiOiBbXCJwYXltZW50LXBlbmRpbmdcIiwgXCJjYW5jZWxsZWRcIl0sXG4gIGNvbmZpcm1lZDogW1wiY29tcGxldGVkXCIsIFwiY2FuY2VsbGVkXCJdLFxuICBjb21wbGV0ZWQ6IFtdLFxuICByZWplY3RlZDogW10sXG4gIGNhbmNlbGxlZDogW10sXG59O1xuXG4vKiogTG9jYWwgc3RhbmQtaW4gZm9yIGNvbnZlcnNhdGlvbnMgKyBtZXNzYWdlcy4gKi9cbmludGVyZmFjZSBMb2NhbFRocmVhZCB7XG4gIGlkOiBzdHJpbmc7XG4gIHNwYWNlSWQ6IHN0cmluZztcbiAgbWVzc2FnZXM6IEFycmF5PHsgaWQ6IHN0cmluZzsgc2VuZGVySWQ6IHN0cmluZzsgYm9keTogc3RyaW5nOyBzZW50QXQ6IHN0cmluZzsgcmVhZEF0OiBzdHJpbmcgfCBudWxsIH0+O1xufVxuXG4vKiogVGhlIHBlcnNvbiB5b3UgYXJlIHdoZW4gdGhlcmUgaXMgbm8gc2lnbi1pbi4gKi9cbmNvbnN0IExPQ0FMX1VTRVJfSUQgPSBcIkxPQ0FMLVVTRVJcIjtcblxuLyoqIFRoZSBzaWduZWQtaW4gb3duZXIgaW4gZGVtbyBtb2RlIOKAlCB0aGUgcG9ydGZvbGlvIHlvdSBjYW4gYWN0dWFsbHkgZWRpdC4gKi9cbmV4cG9ydCBjb25zdCBERU1PX09XTkVSX0lEID0gXCJPVy0wMDFcIjtcblxuZnVuY3Rpb24gZnJlc2hEYXRhYmFzZSgpOiBEYXRhYmFzZSB7XG4gIHJldHVybiB7XG4gICAgdmVyc2lvbjogMSxcbiAgICBzZWVkU3RhbXA6IFNFRURfU1RBTVAsXG4gICAgb3duZXJzOiBzZWVkLm93bmVycyBhcyB1bmtub3duIGFzIE93bmVyW10sXG4gICAgcHJvcGVydGllczogc2VlZC5wcm9wZXJ0aWVzIGFzIHVua25vd24gYXMgUHJvcGVydHlbXSxcbiAgICBzcGFjZXM6IHNlZWQuc3BhY2VzIGFzIHVua25vd24gYXMgU3BhY2VbXSxcbiAgICBpbnF1aXJpZXM6IFtdLFxuICAgIHJlcXVlc3RzOiBbXSxcbiAgICBzYXZlZElkczogW10sXG4gICAgdGhyZWFkczogW10sXG4gICAgYm9va2luZ3M6IFtdLFxuICAgIGludm9pY2VzOiBbXSxcbiAgfTtcbn1cblxuZnVuY3Rpb24gcmVhZCgpOiBEYXRhYmFzZSB7XG4gIGlmICh0eXBlb2Ygd2luZG93ID09PSBcInVuZGVmaW5lZFwiKSByZXR1cm4gZnJlc2hEYXRhYmFzZSgpO1xuICB0cnkge1xuICAgIGNvbnN0IHJhdyA9IHdpbmRvdy5sb2NhbFN0b3JhZ2UuZ2V0SXRlbShLRVkpO1xuICAgIGlmICghcmF3KSB7XG4gICAgICBjb25zdCBmcmVzaCA9IGZyZXNoRGF0YWJhc2UoKTtcbiAgICAgIHdyaXRlKGZyZXNoKTtcbiAgICAgIHJldHVybiBmcmVzaDtcbiAgICB9XG4gICAgY29uc3QgcGFyc2VkID0gSlNPTi5wYXJzZShyYXcpIGFzIERhdGFiYXNlO1xuICAgIGlmIChwYXJzZWQudmVyc2lvbiAhPT0gMSkgdGhyb3cgbmV3IEVycm9yKFwic2NoZW1hIGNoYW5nZWRcIik7XG5cbiAgICBpZiAocGFyc2VkLnNlZWRTdGFtcCAhPT0gU0VFRF9TVEFNUCkge1xuICAgICAgY29uc3QgbWVyZ2VkID0gZnJlc2hEYXRhYmFzZSgpO1xuICAgICAgLy8gS2VlcCB0aGUgcGVyc29uJ3Mgb3duIHdvcms7IHJlcGxhY2UgdGhlIHN5bnRoZXRpYyBzZWVkIHVuZGVybmVhdGggaXQuXG4gICAgICBtZXJnZWQucHJvcGVydGllcyA9IFsuLi5wYXJzZWQucHJvcGVydGllcy5maWx0ZXIoKHApID0+ICFwLnN5bnRoZXRpYyksIC4uLm1lcmdlZC5wcm9wZXJ0aWVzXTtcbiAgICAgIG1lcmdlZC5zcGFjZXMgPSBbLi4ucGFyc2VkLnNwYWNlcy5maWx0ZXIoKHMpID0+ICFzLnN5bnRoZXRpYyksIC4uLm1lcmdlZC5zcGFjZXNdO1xuICAgICAgbWVyZ2VkLmlucXVpcmllcyA9IHBhcnNlZC5pbnF1aXJpZXMgPz8gW107XG4gICAgICBtZXJnZWQucmVxdWVzdHMgPSBwYXJzZWQucmVxdWVzdHMgPz8gW107XG4gICAgICBtZXJnZWQuc2F2ZWRJZHMgPSAocGFyc2VkLnNhdmVkSWRzID8/IFtdKS5maWx0ZXIoKGlkKSA9PiBtZXJnZWQuc3BhY2VzLnNvbWUoKHMpID0+IHMuaWQgPT09IGlkKSk7XG4gICAgICBtZXJnZWQudGhyZWFkcyA9IHBhcnNlZC50aHJlYWRzID8/IFtdO1xuICAgICAgbWVyZ2VkLmJvb2tpbmdzID0gcGFyc2VkLmJvb2tpbmdzID8/IFtdO1xuICAgICAgbWVyZ2VkLmludm9pY2VzID0gcGFyc2VkLmludm9pY2VzID8/IFtdO1xuICAgICAgLy8gU3BhY2VzIGNyZWF0ZWQgYmVmb3JlIG9jY3VwYW5jeSBydWxlcyBleGlzdGVkIGRlZmF1bHQgdG8gb3Blbi5cbiAgICAgIGZvciAoY29uc3Qgc3BhY2Ugb2YgbWVyZ2VkLnNwYWNlcykge1xuICAgICAgICBpZiAoIXNwYWNlLnN0YXR1cykgc3BhY2Uuc3RhdHVzID0gXCJwdWJsaXNoZWRcIjtcbiAgICAgICAgaWYgKCFzcGFjZS5zdGF0dXMpIHNwYWNlLnN0YXR1cyA9IFwicHVibGlzaGVkXCI7XG4gICAgICAgIGlmICghc3BhY2UucnVsZXMpIHtcbiAgICAgICAgICBzcGFjZS5ydWxlcyA9IHtcbiAgICAgICAgICAgIGZhbWlseUFsbG93ZWQ6IHRydWUsXG4gICAgICAgICAgICBiYWNoZWxvckFsbG93ZWQ6IHRydWUsXG4gICAgICAgICAgICBzdHVkZW50RnJpZW5kbHk6IHRydWUsXG4gICAgICAgICAgICBnZW5kZXJQcmVmZXJlbmNlOiBcImFueVwiLFxuICAgICAgICAgICAgbWF4T2NjdXBhbnRzOiBudWxsLFxuICAgICAgICAgIH07XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHdyaXRlKG1lcmdlZCk7XG4gICAgICByZXR1cm4gbWVyZ2VkO1xuICAgIH1cblxuICAgIHJldHVybiBwYXJzZWQ7XG4gIH0gY2F0Y2gge1xuICAgIC8vIENvcnJ1cHQgb3Igb3V0ZGF0ZWQgcGF5bG9hZCDigJQgc3RhcnQgY2xlYW4gcmF0aGVyIHRoYW4gY3Jhc2ggdGhlIGFwcC5cbiAgICBjb25zdCBmcmVzaCA9IGZyZXNoRGF0YWJhc2UoKTtcbiAgICB3cml0ZShmcmVzaCk7XG4gICAgcmV0dXJuIGZyZXNoO1xuICB9XG59XG5cbmZ1bmN0aW9uIHdyaXRlKGRiOiBEYXRhYmFzZSk6IHZvaWQge1xuICBpZiAodHlwZW9mIHdpbmRvdyA9PT0gXCJ1bmRlZmluZWRcIikgcmV0dXJuO1xuICB0cnkge1xuICAgIHdpbmRvdy5sb2NhbFN0b3JhZ2Uuc2V0SXRlbShLRVksIEpTT04uc3RyaW5naWZ5KGRiKSk7XG4gIH0gY2F0Y2gge1xuICAgIC8vIFF1b3RhIG9yIHByaXZhdGUtbW9kZSBmYWlsdXJlOiB0aGUgc2Vzc2lvbiBrZWVwcyB3b3JraW5nIGluIG1lbW9yeS5cbiAgICBjb25zb2xlLndhcm4oXCJIYWJpdG86IGNvdWxkIG5vdCBwZXJzaXN0IGNoYW5nZXMgdG8gbG9jYWwgc3RvcmFnZS5cIik7XG4gIH1cbn1cblxuY29uc3Qgc2V0dGxlID0gPFQsPih2YWx1ZTogVCk6IFByb21pc2U8VD4gPT5cbiAgTEFURU5DWV9NUyA/IG5ldyBQcm9taXNlKChyKSA9PiBzZXRUaW1lb3V0KCgpID0+IHIodmFsdWUpLCBMQVRFTkNZX01TKSkgOiBQcm9taXNlLnJlc29sdmUodmFsdWUpO1xuXG5mdW5jdGlvbiBqb2luKGRiOiBEYXRhYmFzZSwgc3BhY2U6IFNwYWNlKTogU3BhY2VMaXN0aW5nIHwgbnVsbCB7XG4gIGNvbnN0IHByb3BlcnR5ID0gZGIucHJvcGVydGllcy5maW5kKChwKSA9PiBwLmlkID09PSBzcGFjZS5wcm9wZXJ0eUlkKTtcbiAgaWYgKCFwcm9wZXJ0eSkgcmV0dXJuIG51bGw7XG4gIGNvbnN0IG93bmVyID0gZGIub3duZXJzLmZpbmQoKG8pID0+IG8uaWQgPT09IHByb3BlcnR5Lm93bmVySWQpO1xuICBpZiAoIW93bmVyKSByZXR1cm4gbnVsbDtcbiAgcmV0dXJuIHsgc3BhY2UsIHByb3BlcnR5LCBvd25lciB9O1xufVxuXG5mdW5jdGlvbiBuZXh0SWQocHJlZml4OiBzdHJpbmcsIGV4aXN0aW5nOiBBcnJheTx7IGlkOiBzdHJpbmcgfT4pOiBzdHJpbmcge1xuICBjb25zdCBtYXggPSBleGlzdGluZy5yZWR1Y2UoKG0sIHgpID0+IHtcbiAgICBjb25zdCBuID0gTnVtYmVyKHguaWQuc3BsaXQoXCItXCIpWzFdKTtcbiAgICByZXR1cm4gTnVtYmVyLmlzRmluaXRlKG4pICYmIG4gPiBtID8gbiA6IG07XG4gIH0sIDApO1xuICByZXR1cm4gYCR7cHJlZml4fS0ke1N0cmluZyhtYXggKyAxKS5wYWRTdGFydCg0LCBcIjBcIil9YDtcbn1cblxuZXhwb3J0IGNvbnN0IGxvY2FsUmVwb3NpdG9yeTogUmVwb3NpdG9yeSA9IHtcbiAga2luZDogXCJsb2NhbFwiLFxuXG4gIC8qIOKUgOKUgCBSZWFkcyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIAgKi9cblxuICBhc3luYyBsaXN0aW5ncygpOiBQcm9taXNlPFNwYWNlTGlzdGluZ1tdPiB7XG4gICAgY29uc3QgZGF0YSA9IHJlYWQoKTtcbiAgICByZXR1cm4gc2V0dGxlKFxuICAgICAgZGF0YS5zcGFjZXNcbiAgICAgICAgLmZpbHRlcigocykgPT4gcy5zdGF0dXMgIT09IFwiYXJjaGl2ZWRcIilcbiAgICAgICAgLm1hcCgocykgPT4gam9pbihkYXRhLCBzKSlcbiAgICAgICAgLmZpbHRlcigoeCk6IHggaXMgU3BhY2VMaXN0aW5nID0+IHggIT09IG51bGwpLFxuICAgICk7XG4gIH0sXG5cbiAgYXN5bmMgbGlzdGluZyhzcGFjZUlkOiBzdHJpbmcpOiBQcm9taXNlPFNwYWNlTGlzdGluZyB8IG51bGw+IHtcbiAgICBjb25zdCBkYXRhID0gcmVhZCgpO1xuICAgIGNvbnN0IHNwYWNlID0gZGF0YS5zcGFjZXMuZmluZCgocykgPT4gcy5pZCA9PT0gc3BhY2VJZCk7XG4gICAgcmV0dXJuIHNldHRsZShzcGFjZSA/IGpvaW4oZGF0YSwgc3BhY2UpIDogbnVsbCk7XG4gIH0sXG5cbiAgYXN5bmMgcHJvcGVydGllcyhvd25lcklkPzogc3RyaW5nKTogUHJvbWlzZTxQcm9wZXJ0eVtdPiB7XG4gICAgY29uc3QgZGF0YSA9IHJlYWQoKTtcbiAgICByZXR1cm4gc2V0dGxlKG93bmVySWQgPyBkYXRhLnByb3BlcnRpZXMuZmlsdGVyKChwKSA9PiBwLm93bmVySWQgPT09IG93bmVySWQpIDogZGF0YS5wcm9wZXJ0aWVzKTtcbiAgfSxcblxuICBhc3luYyBzcGFjZXNPZlByb3BlcnR5KHByb3BlcnR5SWQ6IHN0cmluZyk6IFByb21pc2U8U3BhY2VbXT4ge1xuICAgIGNvbnN0IGRhdGEgPSByZWFkKCk7XG4gICAgcmV0dXJuIHNldHRsZShkYXRhLnNwYWNlcy5maWx0ZXIoKHMpID0+IHMucHJvcGVydHlJZCA9PT0gcHJvcGVydHlJZCkpO1xuICB9LFxuXG4gIGFzeW5jIHNwYWNlKHNwYWNlSWQ6IHN0cmluZyk6IFByb21pc2U8U3BhY2UgfCBudWxsPiB7XG4gICAgcmV0dXJuIHNldHRsZShyZWFkKCkuc3BhY2VzLmZpbmQoKHMpID0+IHMuaWQgPT09IHNwYWNlSWQpID8/IG51bGwpO1xuICB9LFxuXG4gIGFzeW5jIG93bmVyKG93bmVySWQ6IHN0cmluZyk6IFByb21pc2U8T3duZXIgfCBudWxsPiB7XG4gICAgY29uc3QgZGF0YSA9IHJlYWQoKTtcbiAgICByZXR1cm4gc2V0dGxlKGRhdGEub3duZXJzLmZpbmQoKG8pID0+IG8uaWQgPT09IG93bmVySWQpID8/IG51bGwpO1xuICB9LFxuXG4gIC8qIOKUgOKUgCBPd25lciB3cml0ZXMg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAICovXG5cbiAgYXN5bmMgY3JlYXRlUHJvcGVydHkoaW5wdXQ6IE9taXQ8UHJvcGVydHksIFwiaWRcIiB8IFwiY3JlYXRlZEF0XCIgfCBcInN5bnRoZXRpY1wiPik6IFByb21pc2U8UHJvcGVydHk+IHtcbiAgICBjb25zdCBkYXRhID0gcmVhZCgpO1xuICAgIGNvbnN0IHByb3BlcnR5OiBQcm9wZXJ0eSA9IHtcbiAgICAgIC4uLmlucHV0LFxuICAgICAgaWQ6IG5leHRJZChcIlBSXCIsIGRhdGEucHJvcGVydGllcyksXG4gICAgICBjcmVhdGVkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKS5zbGljZSgwLCAxMCksXG4gICAgICBzeW50aGV0aWM6IGZhbHNlLFxuICAgIH07XG4gICAgZGF0YS5wcm9wZXJ0aWVzID0gW3Byb3BlcnR5LCAuLi5kYXRhLnByb3BlcnRpZXNdO1xuICAgIHdyaXRlKGRhdGEpO1xuICAgIHJldHVybiBzZXR0bGUocHJvcGVydHkpO1xuICB9LFxuXG4gIGFzeW5jIGNyZWF0ZVNwYWNlKGlucHV0OiBPbWl0PFNwYWNlLCBcImlkXCIgfCBcInZpZXdzXCIgfCBcImlucXVpcnlDb3VudFwiIHwgXCJzeW50aGV0aWNcIj4pOiBQcm9taXNlPFNwYWNlPiB7XG4gICAgY29uc3QgZGF0YSA9IHJlYWQoKTtcbiAgICBjb25zdCBzcGFjZTogU3BhY2UgPSB7XG4gICAgICAuLi5pbnB1dCxcbiAgICAgIGlkOiBuZXh0SWQoXCJTUFwiLCBkYXRhLnNwYWNlcyksXG4gICAgICB2aWV3czogMCxcbiAgICAgIGlucXVpcnlDb3VudDogMCxcbiAgICAgIHN5bnRoZXRpYzogZmFsc2UsXG4gICAgfTtcbiAgICBkYXRhLnNwYWNlcyA9IFtzcGFjZSwgLi4uZGF0YS5zcGFjZXNdO1xuICAgIHdyaXRlKGRhdGEpO1xuICAgIHJldHVybiBzZXR0bGUoc3BhY2UpO1xuICB9LFxuXG4gIGFzeW5jIHVwZGF0ZVNwYWNlKHNwYWNlSWQ6IHN0cmluZywgcGF0Y2g6IFBhcnRpYWw8U3BhY2U+KTogUHJvbWlzZTxTcGFjZSB8IG51bGw+IHtcbiAgICBjb25zdCBkYXRhID0gcmVhZCgpO1xuICAgIGNvbnN0IGluZGV4ID0gZGF0YS5zcGFjZXMuZmluZEluZGV4KChzKSA9PiBzLmlkID09PSBzcGFjZUlkKTtcbiAgICBpZiAoaW5kZXggPT09IC0xKSByZXR1cm4gc2V0dGxlKG51bGwpO1xuICAgIGNvbnN0IHVwZGF0ZWQ6IFNwYWNlID0ge1xuICAgICAgLi4uZGF0YS5zcGFjZXNbaW5kZXhdLFxuICAgICAgLi4ucGF0Y2gsXG4gICAgICBsYXN0VXBkYXRlZDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLnNsaWNlKDAsIDEwKSxcbiAgICB9O1xuICAgIGRhdGEuc3BhY2VzW2luZGV4XSA9IHVwZGF0ZWQ7XG4gICAgd3JpdGUoZGF0YSk7XG4gICAgcmV0dXJuIHNldHRsZSh1cGRhdGVkKTtcbiAgfSxcblxuICBhc3luYyBkZWxldGVTcGFjZShzcGFjZUlkOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcbiAgICBjb25zdCBkYXRhID0gcmVhZCgpO1xuICAgIGRhdGEuc3BhY2VzID0gZGF0YS5zcGFjZXMuZmlsdGVyKChzKSA9PiBzLmlkICE9PSBzcGFjZUlkKTtcbiAgICB3cml0ZShkYXRhKTtcbiAgICByZXR1cm4gc2V0dGxlKHVuZGVmaW5lZCk7XG4gIH0sXG5cbiAgLyog4pSA4pSAIFNlZWtlciB3cml0ZXMg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAICovXG5cbiAgYXN5bmMgc2F2ZWQoKTogUHJvbWlzZTxzdHJpbmdbXT4ge1xuICAgIHJldHVybiBzZXR0bGUocmVhZCgpLnNhdmVkSWRzKTtcbiAgfSxcblxuICBhc3luYyB0b2dnbGVTYXZlZChzcGFjZUlkOiBzdHJpbmcpOiBQcm9taXNlPGJvb2xlYW4+IHtcbiAgICBjb25zdCBkYXRhID0gcmVhZCgpO1xuICAgIGNvbnN0IGhhcyA9IGRhdGEuc2F2ZWRJZHMuaW5jbHVkZXMoc3BhY2VJZCk7XG4gICAgZGF0YS5zYXZlZElkcyA9IGhhcyA/IGRhdGEuc2F2ZWRJZHMuZmlsdGVyKCh4KSA9PiB4ICE9PSBzcGFjZUlkKSA6IFsuLi5kYXRhLnNhdmVkSWRzLCBzcGFjZUlkXTtcbiAgICB3cml0ZShkYXRhKTtcbiAgICByZXR1cm4gc2V0dGxlKCFoYXMpO1xuICB9LFxuXG4gIGFzeW5jIGlucXVpcmllcygpOiBQcm9taXNlPElucXVpcnlbXT4ge1xuICAgIHJldHVybiBzZXR0bGUocmVhZCgpLmlucXVpcmllcyk7XG4gIH0sXG5cbiAgYXN5bmMgY3JlYXRlSW5xdWlyeShpbnB1dDogT21pdDxJbnF1aXJ5LCBcImlkXCIgfCBcInNlbnRBdFwiIHwgXCJzdGF0dXNcIj4pOiBQcm9taXNlPElucXVpcnk+IHtcbiAgICBjb25zdCBkYXRhID0gcmVhZCgpO1xuICAgIGNvbnN0IGlucXVpcnk6IElucXVpcnkgPSB7XG4gICAgICAuLi5pbnB1dCxcbiAgICAgIGlkOiBuZXh0SWQoXCJJTlFcIiwgZGF0YS5pbnF1aXJpZXMpLFxuICAgICAgc2VudEF0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgICBzdGF0dXM6IFwibmV3XCIsXG4gICAgfTtcbiAgICBkYXRhLmlucXVpcmllcyA9IFtpbnF1aXJ5LCAuLi5kYXRhLmlucXVpcmllc107XG5cbiAgICAvLyBNaXJyb3IgdGhlIGRhdGFiYXNlOiBhbiBpbnF1aXJ5IGlzIHRoZSBmaXJzdCBtZXNzYWdlIG9mIGEgdGhyZWFkLlxuICAgIGxldCB0aHJlYWQgPSBkYXRhLnRocmVhZHMuZmluZCgodCkgPT4gdC5zcGFjZUlkID09PSBpbnB1dC5zcGFjZUlkKTtcbiAgICBpZiAoIXRocmVhZCkge1xuICAgICAgdGhyZWFkID0geyBpZDogYENPTlYtJHtEYXRlLm5vdygpfWAsIHNwYWNlSWQ6IGlucHV0LnNwYWNlSWQsIG1lc3NhZ2VzOiBbXSB9O1xuICAgICAgZGF0YS50aHJlYWRzLnB1c2godGhyZWFkKTtcbiAgICB9XG4gICAgdGhyZWFkLm1lc3NhZ2VzLnB1c2goe1xuICAgICAgaWQ6IGBNU0ctJHtEYXRlLm5vdygpfWAsXG4gICAgICBzZW5kZXJJZDogTE9DQUxfVVNFUl9JRCxcbiAgICAgIGJvZHk6IGlucHV0Lm1lc3NhZ2UsXG4gICAgICBzZW50QXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICAgIHJlYWRBdDogbnVsbCxcbiAgICB9KTtcblxuICAgIGNvbnN0IGluZGV4ID0gZGF0YS5zcGFjZXMuZmluZEluZGV4KChzKSA9PiBzLmlkID09PSBpbnB1dC5zcGFjZUlkKTtcbiAgICBpZiAoaW5kZXggIT09IC0xKSB7XG4gICAgICBkYXRhLnNwYWNlc1tpbmRleF0gPSB7IC4uLmRhdGEuc3BhY2VzW2luZGV4XSwgaW5xdWlyeUNvdW50OiBkYXRhLnNwYWNlc1tpbmRleF0uaW5xdWlyeUNvdW50ICsgMSB9O1xuICAgIH1cblxuICAgIHdyaXRlKGRhdGEpO1xuICAgIHJldHVybiBzZXR0bGUoaW5xdWlyeSk7XG4gIH0sXG5cbiAgYXN5bmMgc2V0SW5xdWlyeVN0YXR1cyhpbnF1aXJ5SWQ6IHN0cmluZywgc3RhdHVzOiBJbnF1aXJ5U3RhdHVzKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgY29uc3QgZGF0YSA9IHJlYWQoKTtcbiAgICBjb25zdCBpbmRleCA9IGRhdGEuaW5xdWlyaWVzLmZpbmRJbmRleCgoaSkgPT4gaS5pZCA9PT0gaW5xdWlyeUlkKTtcbiAgICBpZiAoaW5kZXggIT09IC0xKSB7XG4gICAgICBkYXRhLmlucXVpcmllc1tpbmRleF0gPSB7IC4uLmRhdGEuaW5xdWlyaWVzW2luZGV4XSwgc3RhdHVzIH07XG4gICAgICB3cml0ZShkYXRhKTtcbiAgICB9XG4gICAgcmV0dXJuIHNldHRsZSh1bmRlZmluZWQpO1xuICB9LFxuXG4gIGFzeW5jIHJlcXVlc3RzKCk6IFByb21pc2U8U3BhY2VSZXF1ZXN0W10+IHtcbiAgICByZXR1cm4gc2V0dGxlKHJlYWQoKS5yZXF1ZXN0cyk7XG4gIH0sXG5cbiAgYXN5bmMgY3JlYXRlUmVxdWVzdChpbnB1dDogT21pdDxTcGFjZVJlcXVlc3QsIFwiaWRcIiB8IFwiY3JlYXRlZEF0XCI+KTogUHJvbWlzZTxTcGFjZVJlcXVlc3Q+IHtcbiAgICBjb25zdCBkYXRhID0gcmVhZCgpO1xuICAgIGNvbnN0IHJlcXVlc3Q6IFNwYWNlUmVxdWVzdCA9IHtcbiAgICAgIC4uLmlucHV0LFxuICAgICAgaWQ6IG5leHRJZChcIlJFUVwiLCBkYXRhLnJlcXVlc3RzKSxcbiAgICAgIGNyZWF0ZWRBdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgIH07XG4gICAgZGF0YS5yZXF1ZXN0cyA9IFtyZXF1ZXN0LCAuLi5kYXRhLnJlcXVlc3RzXTtcbiAgICB3cml0ZShkYXRhKTtcbiAgICByZXR1cm4gc2V0dGxlKHJlcXVlc3QpO1xuICB9LFxuXG4gIC8qIOKUgOKUgCBCb29raW5ncyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIAgKi9cblxuICBhc3luYyBib29raW5ncygpOiBQcm9taXNlPEJvb2tpbmdbXT4ge1xuICAgIGNvbnN0IGRhdGEgPSByZWFkKCk7XG5cbiAgICByZXR1cm4gc2V0dGxlKFxuICAgICAgZGF0YS5ib29raW5ncy5tYXAoKGIpID0+IHtcbiAgICAgICAgY29uc3Qgc3BhY2UgPSBkYXRhLnNwYWNlcy5maW5kKChzKSA9PiBzLmlkID09PSBiLnNwYWNlSWQpO1xuICAgICAgICBjb25zdCBwcm9wZXJ0eSA9IHNwYWNlID8gZGF0YS5wcm9wZXJ0aWVzLmZpbmQoKHApID0+IHAuaWQgPT09IHNwYWNlLnByb3BlcnR5SWQpIDogdW5kZWZpbmVkO1xuICAgICAgICBjb25zdCBvd25lciA9IHByb3BlcnR5ID8gZGF0YS5vd25lcnMuZmluZCgobykgPT4gby5pZCA9PT0gcHJvcGVydHkub3duZXJJZCkgOiB1bmRlZmluZWQ7XG5cbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICBpZDogYi5pZCxcbiAgICAgICAgICBzcGFjZUlkOiBiLnNwYWNlSWQsXG4gICAgICAgICAgc3BhY2VOYW1lOiBzcGFjZT8ubmFtZSA/PyBcIkEgc3BhY2VcIixcbiAgICAgICAgICBzcGFjZUltYWdlOiBzcGFjZT8uaW1hZ2VzWzBdPy51cmwgPz8gbnVsbCxcbiAgICAgICAgICBhcmVhOiBwcm9wZXJ0eT8uYXJlYSA/PyBudWxsLFxuICAgICAgICAgIHJlbnRlcklkOiBMT0NBTF9VU0VSX0lELFxuICAgICAgICAgIC8vIFdpdGhvdXQgYWNjb3VudHMgb25lIHBlcnNvbiBwbGF5cyBib3RoIHNpZGVzLCBzbyBuYW1pbmcgdGhlIHJlbnRlclxuICAgICAgICAgIC8vIFwiWW91XCIgcHJvZHVjZXMgXCJ3aXRoIFlvdVwiIGFuZCBcIllvdSdzIG51bWJlclwiLiBMYWJlbCBpdCBhcyB0aGUgZGVtb1xuICAgICAgICAgIC8vIGNvdW50ZXJwYXJ0IGluc3RlYWQuXG4gICAgICAgICAgcmVudGVyTmFtZTogXCJEZW1vIHJlbnRlclwiLFxuICAgICAgICAgIG93bmVySWQ6IG93bmVyPy5pZCA/PyBcIlwiLFxuICAgICAgICAgIG93bmVyTmFtZTogb3duZXI/Lm5hbWUgPz8gXCJPd25lclwiLFxuICAgICAgICAgIHN0YXR1czogYi5zdGF0dXMsXG4gICAgICAgICAgbW92ZUluRGF0ZTogYi5tb3ZlSW5EYXRlLFxuICAgICAgICAgIG1vbnRoczogYi5tb250aHMsXG4gICAgICAgICAgYW1vdW50OiBiLmFtb3VudCxcbiAgICAgICAgICBtZXNzYWdlOiBiLm1lc3NhZ2UsXG4gICAgICAgICAgcGhvbmVTaGFyZWQ6IGIucGhvbmVTaGFyZWQsXG4gICAgICAgICAgcmVudGVyUGhvbmU6IGIucGhvbmVTaGFyZWQgPyBcIjAxNzAwMDAwMDAwXCIgOiBudWxsLFxuICAgICAgICAgIG93bmVyUGhvbmU6IGIucGhvbmVTaGFyZWQgPyBcIjAxODAwMDAwMDAwXCIgOiBudWxsLFxuICAgICAgICAgIGRlY2xpbmVSZWFzb246IGIuZGVjbGluZVJlYXNvbixcbiAgICAgICAgICBjcmVhdGVkQXQ6IGIuY3JlYXRlZEF0LFxuICAgICAgICAgIGRlY2lkZWRBdDogYi5kZWNpZGVkQXQsXG4gICAgICAgICAgLy8gV2l0aG91dCBhY2NvdW50cyB0aGVyZSBpcyBvbmUgcGVyc29uLCB3aG8gc2VlcyBib3RoIHNpZGVzLlxuICAgICAgICAgIHlvdUFyZU93bmVyOiB0cnVlLFxuICAgICAgICB9O1xuICAgICAgfSksXG4gICAgKTtcbiAgfSxcblxuICBhc3luYyByZXF1ZXN0Qm9va2luZyhpbnB1dCk6IFByb21pc2U8Qm9va2luZz4ge1xuICAgIGNvbnN0IGRhdGEgPSByZWFkKCk7XG4gICAgY29uc3Qgc3BhY2UgPSBkYXRhLnNwYWNlcy5maW5kKChzKSA9PiBzLmlkID09PSBpbnB1dC5zcGFjZUlkKTtcblxuICAgIGlmICghc3BhY2UpIHRocm93IG5ldyBFcnJvcihcIlRoYXQgc3BhY2Ugbm8gbG9uZ2VyIGV4aXN0cy5cIik7XG4gICAgaWYgKHNwYWNlLmF2YWlsYWJpbGl0eS5zdGF0dXMgPT09IFwib2NjdXBpZWRcIiB8fCBzcGFjZS5hdmFpbGFiaWxpdHkuc3RhdHVzID09PSBcIm1haW50ZW5hbmNlXCIpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcIlRoYXQgc3BhY2UgaXMgbm90IGF2YWlsYWJsZSB0byBib29rLlwiKTtcbiAgICB9XG5cbiAgICBjb25zdCBib29raW5nOiBMb2NhbEJvb2tpbmcgPSB7XG4gICAgICBpZDogYEJLLSR7RGF0ZS5ub3coKX1gLFxuICAgICAgc3BhY2VJZDogaW5wdXQuc3BhY2VJZCxcbiAgICAgIHN0YXR1czogXCJyZXF1ZXN0ZWRcIixcbiAgICAgIG1vdmVJbkRhdGU6IGlucHV0Lm1vdmVJbkRhdGUsXG4gICAgICBtb250aHM6IGlucHV0Lm1vbnRocyxcbiAgICAgIGFtb3VudDogaW5wdXQuYW1vdW50LFxuICAgICAgbWVzc2FnZTogaW5wdXQubWVzc2FnZSA/PyBudWxsLFxuICAgICAgcGhvbmVTaGFyZWQ6IGZhbHNlLFxuICAgICAgY3JlYXRlZEF0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgICBkZWNpZGVkQXQ6IG51bGwsXG4gICAgICBkZWNsaW5lUmVhc29uOiBudWxsLFxuICAgIH07XG5cbiAgICBkYXRhLmJvb2tpbmdzID0gW2Jvb2tpbmcsIC4uLmRhdGEuYm9va2luZ3NdO1xuICAgIHdyaXRlKGRhdGEpO1xuXG4gICAgY29uc3QgW21hZGVdID0gYXdhaXQgdGhpcy5ib29raW5ncygpO1xuICAgIHJldHVybiBtYWRlO1xuICB9LFxuXG4gIGFzeW5jIHNldEJvb2tpbmdTdGF0dXMoYm9va2luZ0lkOiBzdHJpbmcsIHN0YXR1czogQm9va2luZ1N0YXR1cywgcmVhc29uPzogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgY29uc3QgZGF0YSA9IHJlYWQoKTtcbiAgICBjb25zdCBib29raW5nID0gZGF0YS5ib29raW5ncy5maW5kKChiKSA9PiBiLmlkID09PSBib29raW5nSWQpO1xuICAgIGlmICghYm9va2luZykgcmV0dXJuIHNldHRsZSh1bmRlZmluZWQpO1xuXG4gICAgaWYgKCFUUkFOU0lUSU9OU1tib29raW5nLnN0YXR1c10uaW5jbHVkZXMoc3RhdHVzKSkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKGBBIGJvb2tpbmcgY2Fubm90IGdvIGZyb20gJHtib29raW5nLnN0YXR1c30gdG8gJHtzdGF0dXN9LmApO1xuICAgIH1cblxuICAgIGJvb2tpbmcuc3RhdHVzID0gc3RhdHVzO1xuICAgIGlmIChyZWFzb24gIT09IHVuZGVmaW5lZCkgYm9va2luZy5kZWNsaW5lUmVhc29uID0gcmVhc29uO1xuXG4gICAgaWYgKHN0YXR1cyA9PT0gXCJhY2NlcHRlZFwiKSB7XG4gICAgICBib29raW5nLnBob25lU2hhcmVkID0gdHJ1ZTtcbiAgICAgIGJvb2tpbmcuZGVjaWRlZEF0ID0gbmV3IERhdGUoKS50b0lTT1N0cmluZygpO1xuICAgIH1cbiAgICBpZiAoc3RhdHVzID09PSBcInJlamVjdGVkXCIpIGJvb2tpbmcuZGVjaWRlZEF0ID0gbmV3IERhdGUoKS50b0lTT1N0cmluZygpO1xuXG4gICAgLy8gTWlycm9yIHRoZSBkYXRhYmFzZTogY29uZmlybWluZyByYWlzZXMgdGhlIHJlbnQgc2NoZWR1bGUuXG4gICAgaWYgKHN0YXR1cyA9PT0gXCJjb25maXJtZWRcIikge1xuICAgICAgY29uc3Qgc3RhcnQgPSBuZXcgRGF0ZShib29raW5nLm1vdmVJbkRhdGUpO1xuICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBNYXRoLm1heChib29raW5nLm1vbnRocywgMSk7IGkrKykge1xuICAgICAgICBjb25zdCBwZXJpb2QgPSBuZXcgRGF0ZShzdGFydC5nZXRGdWxsWWVhcigpLCBzdGFydC5nZXRNb250aCgpICsgaSwgc3RhcnQuZ2V0RGF0ZSgpKTtcbiAgICAgICAgY29uc3QgaXNvID0gcGVyaW9kLnRvSVNPU3RyaW5nKCkuc2xpY2UoMCwgMTApO1xuICAgICAgICBpZiAoZGF0YS5pbnZvaWNlcy5zb21lKCh4KSA9PiB4LmJvb2tpbmdJZCA9PT0gYm9va2luZy5pZCAmJiB4LnBlcmlvZFN0YXJ0ID09PSBpc28pKSBjb250aW51ZTtcblxuICAgICAgICBkYXRhLmludm9pY2VzLnB1c2goe1xuICAgICAgICAgIGlkOiBgSU5WLSR7Ym9va2luZy5pZH0tJHtpfWAsXG4gICAgICAgICAgYm9va2luZ0lkOiBib29raW5nLmlkLFxuICAgICAgICAgIHNwYWNlSWQ6IGJvb2tpbmcuc3BhY2VJZCxcbiAgICAgICAgICBwZXJpb2RTdGFydDogaXNvLFxuICAgICAgICAgIGR1ZURhdGU6IGlzbyxcbiAgICAgICAgICBhbW91bnQ6IGJvb2tpbmcuYW1vdW50LFxuICAgICAgICAgIHN0YXR1czogXCJkdWVcIixcbiAgICAgICAgICBwYWlkQXQ6IG51bGwsXG4gICAgICAgICAgcmVjZWlwdE5vOiBudWxsLFxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICAvLyBNaXJyb3IgdGhlIGRhdGFiYXNlOiBhIGNvbmZpcm1lZCBib29raW5nIHRha2VzIHRoZSBzcGFjZSBvZmYgdGhlIG1hcmtldC5cbiAgICBjb25zdCBzcGFjZSA9IGRhdGEuc3BhY2VzLmZpbmQoKHMpID0+IHMuaWQgPT09IGJvb2tpbmcuc3BhY2VJZCk7XG4gICAgaWYgKHNwYWNlKSB7XG4gICAgICBpZiAoc3RhdHVzID09PSBcImNvbmZpcm1lZFwiKSBzcGFjZS5hdmFpbGFiaWxpdHkgPSB7IC4uLnNwYWNlLmF2YWlsYWJpbGl0eSwgc3RhdHVzOiBcIm9jY3VwaWVkXCIgfTtcbiAgICAgIGlmIChzdGF0dXMgPT09IFwiY29tcGxldGVkXCIgfHwgc3RhdHVzID09PSBcImNhbmNlbGxlZFwiKSB7XG4gICAgICAgIHNwYWNlLmF2YWlsYWJpbGl0eSA9IHsgLi4uc3BhY2UuYXZhaWxhYmlsaXR5LCBzdGF0dXM6IFwiYXZhaWxhYmxlXCIgfTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICB3cml0ZShkYXRhKTtcbiAgICByZXR1cm4gc2V0dGxlKHVuZGVmaW5lZCk7XG4gIH0sXG5cbiAgLyog4pSA4pSAIE1vZGVyYXRpb24g4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAICovXG4gIC8vIE1vZGVyYXRpb24gaXMgbWVhbmluZ2xlc3Mgd2l0aG91dCBhY2NvdW50cyB0byBtb2RlcmF0ZS4gUmF0aGVyIHRoYW5cbiAgLy8gc2ltdWxhdGUgYSBxdWV1ZSwgdGhpcyBidWlsZCBzYXlzIHNvLlxuXG4gIGFzeW5jIHJldmlld1F1ZXVlKCk6IFByb21pc2U8UmV2aWV3SXRlbVtdPiB7XG4gICAgcmV0dXJuIHNldHRsZShbXSk7XG4gIH0sXG5cbiAgYXN5bmMgc2V0TGlzdGluZ1Zpc2libGUoKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgdGhyb3cgbmV3IEVycm9yKFwiTW9kZXJhdGlvbiBuZWVkcyB0aGUgZGF0YWJhc2UuIFRoaXMgYnVpbGQgaGFzIG5vIGFjY291bnRzLlwiKTtcbiAgfSxcblxuICBhc3luYyBzZXRUcnVzdCgpOiBQcm9taXNlPHZvaWQ+IHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoXCJNb2RlcmF0aW9uIG5lZWRzIHRoZSBkYXRhYmFzZS4gVGhpcyBidWlsZCBoYXMgbm8gYWNjb3VudHMuXCIpO1xuICB9LFxuXG4gIGFzeW5jIHJlc29sdmVSZXBvcnRzKCk6IFByb21pc2U8dm9pZD4ge1xuICAgIHRocm93IG5ldyBFcnJvcihcIk1vZGVyYXRpb24gbmVlZHMgdGhlIGRhdGFiYXNlLiBUaGlzIGJ1aWxkIGhhcyBubyBhY2NvdW50cy5cIik7XG4gIH0sXG5cbiAgYXN5bmMgY2xlYXJEdXBsaWNhdGUoKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgdGhyb3cgbmV3IEVycm9yKFwiTW9kZXJhdGlvbiBuZWVkcyB0aGUgZGF0YWJhc2UuIFRoaXMgYnVpbGQgaGFzIG5vIGFjY291bnRzLlwiKTtcbiAgfSxcblxuICAvKiDilIDilIAgTGlzdGluZyBmZWVzIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgCAqL1xuXG4gIGFzeW5jIGxpc3RpbmdGZWUoY2F0ZWdvcnk6IHN0cmluZyk6IFByb21pc2U8bnVtYmVyPiB7XG4gICAgY29uc3QgcHJpY2VzOiBSZWNvcmQ8c3RyaW5nLCBudW1iZXI+ID0ge1wibGl2aW5nXCI6IDIwMCwgXCJidXNpbmVzc1wiOiA1MDAsIFwic3RvcmFnZVwiOiA0MDAsIFwicGFya2luZ1wiOiAxMDAsIFwibGFuZFwiOiA1MDB9O1xuICAgIHJldHVybiBzZXR0bGUocHJpY2VzW2NhdGVnb3J5XSA/PyAyMDApO1xuICB9LFxuXG4gIGFzeW5jIGxpc3RpbmdBbGxvd2FuY2UocHJvcGVydHlJZDogc3RyaW5nKTogUHJvbWlzZTx7IHVzZWQ6IG51bWJlcjsgaGFzUGxhbjogYm9vbGVhbiB9PiB7XG4gICAgY29uc3QgZGF0YSA9IHJlYWQoKTtcbiAgICBjb25zdCBtb250aCA9IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKS5zbGljZSgwLCA3KTtcbiAgICBjb25zdCB1c2VkID0gZGF0YS5zcGFjZXMuZmlsdGVyKFxuICAgICAgKHMpID0+IHMucHJvcGVydHlJZCA9PT0gcHJvcGVydHlJZCAmJiAhcy5zeW50aGV0aWMgJiYgKHMucHVibGlzaGVkQXQgPz8gXCJcIikuc3RhcnRzV2l0aChtb250aCksXG4gICAgKS5sZW5ndGg7XG5cbiAgICByZXR1cm4gc2V0dGxlKHsgdXNlZCwgaGFzUGxhbjogZmFsc2UgfSk7XG4gIH0sXG5cbiAgYXN5bmMgcGF5TGlzdGluZ0ZlZShzcGFjZUlkOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcbiAgICBjb25zdCBkYXRhID0gcmVhZCgpO1xuICAgIGNvbnN0IHNwYWNlID0gZGF0YS5zcGFjZXMuZmluZCgocykgPT4gcy5pZCA9PT0gc3BhY2VJZCk7XG4gICAgaWYgKHNwYWNlKSB7XG4gICAgICBzcGFjZS5saXN0aW5nRmVlUGFpZCA9IHRydWU7XG4gICAgICBzcGFjZS5wdWJsaXNoZWRBdCA9IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKTtcbiAgICAgIHdyaXRlKGRhdGEpO1xuICAgIH1cbiAgICByZXR1cm4gc2V0dGxlKHVuZGVmaW5lZCk7XG4gIH0sXG5cbiAgYXN5bmMgYnV5UHJvcGVydHlQbGFuKCk6IFByb21pc2U8dm9pZD4ge1xuICAgIHJldHVybiBzZXR0bGUodW5kZWZpbmVkKTtcbiAgfSxcblxuICAvKiDilIDilIAgUmVudCDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIAgKi9cblxuICBhc3luYyBpbnZvaWNlcygpOiBQcm9taXNlPFJlbnRJbnZvaWNlW10+IHtcbiAgICBjb25zdCBkYXRhID0gcmVhZCgpO1xuICAgIGNvbnN0IHRvZGF5ID0gbmV3IERhdGUoKS50b0lTT1N0cmluZygpLnNsaWNlKDAsIDEwKTtcblxuICAgIHJldHVybiBzZXR0bGUoXG4gICAgICBkYXRhLmludm9pY2VzLm1hcCgoaW52KSA9PiB7XG4gICAgICAgIGNvbnN0IHNwYWNlID0gZGF0YS5zcGFjZXMuZmluZCgocykgPT4gcy5pZCA9PT0gaW52LnNwYWNlSWQpO1xuICAgICAgICBjb25zdCBwcm9wZXJ0eSA9IHNwYWNlID8gZGF0YS5wcm9wZXJ0aWVzLmZpbmQoKHApID0+IHAuaWQgPT09IHNwYWNlLnByb3BlcnR5SWQpIDogdW5kZWZpbmVkO1xuICAgICAgICBjb25zdCBvd25lciA9IHByb3BlcnR5ID8gZGF0YS5vd25lcnMuZmluZCgobykgPT4gby5pZCA9PT0gcHJvcGVydHkub3duZXJJZCkgOiB1bmRlZmluZWQ7XG5cbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICBpZDogaW52LmlkLFxuICAgICAgICAgIGJvb2tpbmdJZDogaW52LmJvb2tpbmdJZCxcbiAgICAgICAgICBzcGFjZUlkOiBpbnYuc3BhY2VJZCxcbiAgICAgICAgICBzcGFjZU5hbWU6IHNwYWNlPy5uYW1lID8/IFwiQSBzcGFjZVwiLFxuICAgICAgICAgIGFyZWE6IHByb3BlcnR5Py5hcmVhID8/IG51bGwsXG4gICAgICAgICAgY291bnRlcnBhcnROYW1lOiBvd25lcj8ubmFtZSA/PyBcIk93bmVyXCIsXG4gICAgICAgICAgeW91QXJlT3duZXI6IHRydWUsXG4gICAgICAgICAgcGVyaW9kU3RhcnQ6IGludi5wZXJpb2RTdGFydCxcbiAgICAgICAgICBwZXJpb2RFbmQ6IGludi5wZXJpb2RTdGFydCxcbiAgICAgICAgICBkdWVEYXRlOiBpbnYuZHVlRGF0ZSxcbiAgICAgICAgICAvLyBPdmVyZHVlIGlzIGEgZmFjdCBhYm91dCB0aGUgZGF0ZSwgbm90IHNvbWV0aGluZyBzdG9yZWQuXG4gICAgICAgICAgc3RhdHVzOiBpbnYuc3RhdHVzID09PSBcImR1ZVwiICYmIGludi5kdWVEYXRlIDwgdG9kYXkgPyBcIm92ZXJkdWVcIiA6IGludi5zdGF0dXMsXG4gICAgICAgICAgYW1vdW50OiBpbnYuYW1vdW50LFxuICAgICAgICAgIHBhaWRBdDogaW52LnBhaWRBdCxcbiAgICAgICAgICByZWNlaXB0Tm86IGludi5yZWNlaXB0Tm8sXG4gICAgICAgICAgc2ltdWxhdGVkOiB0cnVlLFxuICAgICAgICB9O1xuICAgICAgfSksXG4gICAgKTtcbiAgfSxcblxuICBhc3luYyBwYXlJbnZvaWNlKGludm9pY2VJZDogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgY29uc3QgZGF0YSA9IHJlYWQoKTtcbiAgICBjb25zdCBpbnYgPSBkYXRhLmludm9pY2VzLmZpbmQoKGkpID0+IGkuaWQgPT09IGludm9pY2VJZCk7XG4gICAgaWYgKCFpbnYgfHwgaW52LnN0YXR1cyA9PT0gXCJwYWlkXCIpIHJldHVybiBzZXR0bGUodW5kZWZpbmVkKTtcblxuICAgIGludi5zdGF0dXMgPSBcInBhaWRcIjtcbiAgICBpbnYucGFpZEF0ID0gbmV3IERhdGUoKS50b0lTT1N0cmluZygpO1xuICAgIGludi5yZWNlaXB0Tm8gPSBgSEFCLSR7bmV3IERhdGUoKS5nZXRGdWxsWWVhcigpfS0ke1N0cmluZygrK3JlY2VpcHRDb3VudGVyKS5wYWRTdGFydCg2LCBcIjBcIil9YDtcbiAgICB3cml0ZShkYXRhKTtcbiAgICByZXR1cm4gc2V0dGxlKHVuZGVmaW5lZCk7XG4gIH0sXG5cbiAgYXN5bmMgd2FpdmVJbnZvaWNlKGludm9pY2VJZDogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgY29uc3QgZGF0YSA9IHJlYWQoKTtcbiAgICBjb25zdCBpbnYgPSBkYXRhLmludm9pY2VzLmZpbmQoKGkpID0+IGkuaWQgPT09IGludm9pY2VJZCk7XG4gICAgaWYgKGludiAmJiBpbnYuc3RhdHVzICE9PSBcInBhaWRcIikgaW52LnN0YXR1cyA9IFwid2FpdmVkXCI7XG4gICAgd3JpdGUoZGF0YSk7XG4gICAgcmV0dXJuIHNldHRsZSh1bmRlZmluZWQpO1xuICB9LFxuXG4gIGFzeW5jIGV4dGVuZFNjaGVkdWxlKGJvb2tpbmdJZDogc3RyaW5nLCBtb250aHMgPSAxMik6IFByb21pc2U8dm9pZD4ge1xuICAgIGNvbnN0IGRhdGEgPSByZWFkKCk7XG4gICAgY29uc3QgYm9va2luZyA9IGRhdGEuYm9va2luZ3MuZmluZCgoYikgPT4gYi5pZCA9PT0gYm9va2luZ0lkKTtcbiAgICBpZiAoIWJvb2tpbmcpIHJldHVybiBzZXR0bGUodW5kZWZpbmVkKTtcblxuICAgIC8vIENhcnJ5IG9uIGZyb20gdGhlIGxhc3QgbW9udGggYWxyZWFkeSB0aGVyZSwgc28gZXh0ZW5kaW5nIHR3aWNlIG5laXRoZXJcbiAgICAvLyBvdmVybGFwcyBub3IgbGVhdmVzIGEgZ2FwLlxuICAgIGNvbnN0IGV4aXN0aW5nID0gZGF0YS5pbnZvaWNlcy5maWx0ZXIoKGkpID0+IGkuYm9va2luZ0lkID09PSBib29raW5nSWQpO1xuICAgIGNvbnN0IHNvcnRlZCA9IGV4aXN0aW5nLm1hcCgoaSkgPT4gaS5wZXJpb2RTdGFydCkuc29ydCgpO1xuICAgIGNvbnN0IGxhc3RJc28gPSBzb3J0ZWQubGVuZ3RoID8gc29ydGVkW3NvcnRlZC5sZW5ndGggLSAxXSA6IGJvb2tpbmcubW92ZUluRGF0ZTtcbiAgICBjb25zdCBsYXN0ID0gbmV3IERhdGUobGFzdElzbyk7XG5cbiAgICBmb3IgKGxldCBpID0gMTsgaSA8PSBtb250aHM7IGkrKykge1xuICAgICAgY29uc3QgcGVyaW9kID0gbmV3IERhdGUobGFzdC5nZXRGdWxsWWVhcigpLCBsYXN0LmdldE1vbnRoKCkgKyBpLCBsYXN0LmdldERhdGUoKSk7XG4gICAgICBjb25zdCBpc28gPSBwZXJpb2QudG9JU09TdHJpbmcoKS5zbGljZSgwLCAxMCk7XG4gICAgICBpZiAoZGF0YS5pbnZvaWNlcy5zb21lKCh4KSA9PiB4LmJvb2tpbmdJZCA9PT0gYm9va2luZ0lkICYmIHgucGVyaW9kU3RhcnQgPT09IGlzbykpIGNvbnRpbnVlO1xuXG4gICAgICBkYXRhLmludm9pY2VzLnB1c2goe1xuICAgICAgICBpZDogYElOVi0ke2Jvb2tpbmdJZH0tJHtpc299YCxcbiAgICAgICAgYm9va2luZ0lkLFxuICAgICAgICBzcGFjZUlkOiBib29raW5nLnNwYWNlSWQsXG4gICAgICAgIHBlcmlvZFN0YXJ0OiBpc28sXG4gICAgICAgIGR1ZURhdGU6IGlzbyxcbiAgICAgICAgYW1vdW50OiBib29raW5nLmFtb3VudCxcbiAgICAgICAgc3RhdHVzOiBcImR1ZVwiLFxuICAgICAgICBwYWlkQXQ6IG51bGwsXG4gICAgICAgIHJlY2VpcHRObzogbnVsbCxcbiAgICAgIH0pO1xuICAgIH1cblxuICAgIHdyaXRlKGRhdGEpO1xuICAgIHJldHVybiBzZXR0bGUodW5kZWZpbmVkKTtcbiAgfSxcblxuICAvKiDilIDilIAgTWVzc2FnaW5nIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgCAqL1xuXG4gIGFzeW5jIGNvbnZlcnNhdGlvbnMoKTogUHJvbWlzZTxDb252ZXJzYXRpb25bXT4ge1xuICAgIGNvbnN0IGRhdGEgPSByZWFkKCk7XG5cbiAgICByZXR1cm4gc2V0dGxlKFxuICAgICAgZGF0YS50aHJlYWRzXG4gICAgICAgIC5tYXAoKHRocmVhZCkgPT4ge1xuICAgICAgICAgIGNvbnN0IHNwYWNlID0gZGF0YS5zcGFjZXMuZmluZCgocykgPT4gcy5pZCA9PT0gdGhyZWFkLnNwYWNlSWQpO1xuICAgICAgICAgIGNvbnN0IHByb3BlcnR5ID0gc3BhY2UgPyBkYXRhLnByb3BlcnRpZXMuZmluZCgocCkgPT4gcC5pZCA9PT0gc3BhY2UucHJvcGVydHlJZCkgOiB1bmRlZmluZWQ7XG4gICAgICAgICAgY29uc3Qgb3duZXIgPSBwcm9wZXJ0eSA/IGRhdGEub3duZXJzLmZpbmQoKG8pID0+IG8uaWQgPT09IHByb3BlcnR5Lm93bmVySWQpIDogdW5kZWZpbmVkO1xuICAgICAgICAgIGNvbnN0IGxhc3QgPSB0aHJlYWQubWVzc2FnZXNbdGhyZWFkLm1lc3NhZ2VzLmxlbmd0aCAtIDFdO1xuXG4gICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIGlkOiB0aHJlYWQuaWQsXG4gICAgICAgICAgICBzcGFjZUlkOiB0aHJlYWQuc3BhY2VJZCxcbiAgICAgICAgICAgIHNwYWNlTmFtZTogc3BhY2U/Lm5hbWUgPz8gXCJBIHNwYWNlXCIsXG4gICAgICAgICAgICBzcGFjZUltYWdlOiBzcGFjZT8uaW1hZ2VzWzBdPy51cmwgPz8gbnVsbCxcbiAgICAgICAgICAgIHByb3BlcnR5QXJlYTogcHJvcGVydHk/LmFyZWEgPz8gbnVsbCxcbiAgICAgICAgICAgIGNvdW50ZXJwYXJ0SWQ6IG93bmVyPy5pZCA/PyBcIlwiLFxuICAgICAgICAgICAgY291bnRlcnBhcnROYW1lOiBvd25lcj8ubmFtZSA/PyBcIk93bmVyXCIsXG4gICAgICAgICAgICBjb3VudGVycGFydFRvbmU6IG93bmVyPy5hdmF0YXJUb25lID8/IFwiYXF1YVwiLFxuICAgICAgICAgICAgeW91QXJlT3duZXI6IGZhbHNlLFxuICAgICAgICAgICAgbGFzdE1lc3NhZ2U6IGxhc3Q/LmJvZHkgPz8gXCJcIixcbiAgICAgICAgICAgIGxhc3RNZXNzYWdlQXQ6IGxhc3Q/LnNlbnRBdCA/PyBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgICAgICAgICB1bnJlYWQ6IHRocmVhZC5tZXNzYWdlcy5maWx0ZXIoKG0pID0+IG0uc2VuZGVySWQgIT09IExPQ0FMX1VTRVJfSUQgJiYgIW0ucmVhZEF0KS5sZW5ndGgsXG4gICAgICAgICAgfTtcbiAgICAgICAgfSlcbiAgICAgICAgLnNvcnQoKGEsIGIpID0+IGIubGFzdE1lc3NhZ2VBdC5sb2NhbGVDb21wYXJlKGEubGFzdE1lc3NhZ2VBdCkpLFxuICAgICk7XG4gIH0sXG5cbiAgYXN5bmMgbWVzc2FnZXMoY29udmVyc2F0aW9uSWQ6IHN0cmluZyk6IFByb21pc2U8TWVzc2FnZVtdPiB7XG4gICAgY29uc3QgdGhyZWFkID0gcmVhZCgpLnRocmVhZHMuZmluZCgodCkgPT4gdC5pZCA9PT0gY29udmVyc2F0aW9uSWQpO1xuICAgIGlmICghdGhyZWFkKSByZXR1cm4gc2V0dGxlKFtdKTtcblxuICAgIHJldHVybiBzZXR0bGUoXG4gICAgICB0aHJlYWQubWVzc2FnZXMubWFwKChtKSA9PiAoe1xuICAgICAgICBpZDogbS5pZCxcbiAgICAgICAgY29udmVyc2F0aW9uSWQsXG4gICAgICAgIHNlbmRlcklkOiBtLnNlbmRlcklkLFxuICAgICAgICBib2R5OiBtLmJvZHksXG4gICAgICAgIHNlbnRBdDogbS5zZW50QXQsXG4gICAgICAgIHJlYWRBdDogbS5yZWFkQXQsXG4gICAgICAgIG1pbmU6IG0uc2VuZGVySWQgPT09IExPQ0FMX1VTRVJfSUQsXG4gICAgICB9KSksXG4gICAgKTtcbiAgfSxcblxuICBhc3luYyBzZW5kTWVzc2FnZShjb252ZXJzYXRpb25JZDogc3RyaW5nLCBib2R5OiBzdHJpbmcpOiBQcm9taXNlPE1lc3NhZ2U+IHtcbiAgICBjb25zdCBkYXRhID0gcmVhZCgpO1xuICAgIGNvbnN0IHRocmVhZCA9IGRhdGEudGhyZWFkcy5maW5kKCh0KSA9PiB0LmlkID09PSBjb252ZXJzYXRpb25JZCk7XG4gICAgaWYgKCF0aHJlYWQpIHRocm93IG5ldyBFcnJvcihcIlRoYXQgY29udmVyc2F0aW9uIG5vIGxvbmdlciBleGlzdHMuXCIpO1xuXG4gICAgY29uc3QgbWVzc2FnZSA9IHtcbiAgICAgIGlkOiBgTVNHLSR7RGF0ZS5ub3coKX1gLFxuICAgICAgc2VuZGVySWQ6IExPQ0FMX1VTRVJfSUQsXG4gICAgICBib2R5LFxuICAgICAgc2VudEF0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgICByZWFkQXQ6IG51bGwsXG4gICAgfTtcblxuICAgIHRocmVhZC5tZXNzYWdlcy5wdXNoKG1lc3NhZ2UpO1xuICAgIHdyaXRlKGRhdGEpO1xuICAgIG5vdGlmeUxvY2FsQ2hhbmdlKCk7XG5cbiAgICByZXR1cm4gc2V0dGxlKHsgLi4ubWVzc2FnZSwgY29udmVyc2F0aW9uSWQsIG1pbmU6IHRydWUgfSk7XG4gIH0sXG5cbiAgYXN5bmMgbWFya1JlYWQoY29udmVyc2F0aW9uSWQ6IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuICAgIGNvbnN0IGRhdGEgPSByZWFkKCk7XG4gICAgY29uc3QgdGhyZWFkID0gZGF0YS50aHJlYWRzLmZpbmQoKHQpID0+IHQuaWQgPT09IGNvbnZlcnNhdGlvbklkKTtcbiAgICBpZiAoIXRocmVhZCkgcmV0dXJuIHNldHRsZSh1bmRlZmluZWQpO1xuXG4gICAgY29uc3Qgbm93ID0gbmV3IERhdGUoKS50b0lTT1N0cmluZygpO1xuICAgIGZvciAoY29uc3QgbSBvZiB0aHJlYWQubWVzc2FnZXMpIHtcbiAgICAgIGlmIChtLnNlbmRlcklkICE9PSBMT0NBTF9VU0VSX0lEICYmICFtLnJlYWRBdCkgbS5yZWFkQXQgPSBub3c7XG4gICAgfVxuXG4gICAgd3JpdGUoZGF0YSk7XG4gICAgcmV0dXJuIHNldHRsZSh1bmRlZmluZWQpO1xuICB9LFxuXG4gIGFzeW5jIG9wZW5Db252ZXJzYXRpb24oc3BhY2VJZDogc3RyaW5nKTogUHJvbWlzZTxzdHJpbmc+IHtcbiAgICBjb25zdCBkYXRhID0gcmVhZCgpO1xuICAgIGNvbnN0IGV4aXN0aW5nID0gZGF0YS50aHJlYWRzLmZpbmQoKHQpID0+IHQuc3BhY2VJZCA9PT0gc3BhY2VJZCk7XG4gICAgaWYgKGV4aXN0aW5nKSByZXR1cm4gc2V0dGxlKGV4aXN0aW5nLmlkKTtcblxuICAgIGNvbnN0IHRocmVhZDogTG9jYWxUaHJlYWQgPSB7IGlkOiBgQ09OVi0ke0RhdGUubm93KCl9YCwgc3BhY2VJZCwgbWVzc2FnZXM6IFtdIH07XG4gICAgZGF0YS50aHJlYWRzLnB1c2godGhyZWFkKTtcbiAgICB3cml0ZShkYXRhKTtcblxuICAgIHJldHVybiBzZXR0bGUodGhyZWFkLmlkKTtcbiAgfSxcblxuICBzdWJzY3JpYmVUb01lc3NhZ2VzKG9uQ2hhbmdlOiAoKSA9PiB2b2lkKTogKCkgPT4gdm9pZCB7XG4gICAgLy8gTm90aGluZyBlbHNlIGNhbiB3cml0ZSB0byB0aGlzIGJyb3dzZXIncyBzdG9yZSwgc28gdGhlIG9ubHkgY2hhbmdlc1xuICAgIC8vIHdvcnRoIHJlcG9ydGluZyBhcmUgdGhlIG9uZXMgdGhpcyB0YWIgbWFrZXMuXG4gICAgbG9jYWxMaXN0ZW5lcnMuYWRkKG9uQ2hhbmdlKTtcbiAgICByZXR1cm4gKCkgPT4gbG9jYWxMaXN0ZW5lcnMuZGVsZXRlKG9uQ2hhbmdlKTtcbiAgfSxcblxuICAvKiDilIDilIAgTWFpbnRlbmFuY2Ug4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAICovXG5cbiAgYXN5bmMgcmVzZXQoKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgaWYgKHR5cGVvZiB3aW5kb3cgIT09IFwidW5kZWZpbmVkXCIpIHdpbmRvdy5sb2NhbFN0b3JhZ2UucmVtb3ZlSXRlbShLRVkpO1xuICAgIHJlYWQoKTtcbiAgICByZXR1cm4gc2V0dGxlKHVuZGVmaW5lZCk7XG4gIH0sXG59O1xuXG5leHBvcnQgY29uc3QgREFUQVNFVF9OT1RJQ0UgPSBzZWVkLl9ub3RpY2U7XG4iXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sVUFBVTtBQUlqQixNQUFNLGlCQUFpQixvQkFBSSxJQUFnQjtBQUMzQyxNQUFNLG9CQUFvQixNQUFNLGVBQWUsUUFBUSxDQUFDLE9BQU8sR0FBRyxDQUFDO0FBMEJuRSxNQUFNLE1BQU07QUFPWixNQUFNLGFBQWEsR0FBRyxLQUFLLFdBQVcsSUFBSSxLQUFLLE9BQU8sTUFBTSxJQUFJLEtBQUssV0FBVyxNQUFNO0FBQ3RGLE1BQU0sYUFBYTtBQTRCbkIsSUFBSSxpQkFBaUI7QUFpQnJCLE1BQU0sY0FBc0Q7QUFBQSxFQUMxRCxXQUFXLENBQUMsWUFBWSxZQUFZLFdBQVc7QUFBQSxFQUMvQyxVQUFVLENBQUMsbUJBQW1CLGFBQWEsV0FBVztBQUFBLEVBQ3RELG1CQUFtQixDQUFDLGFBQWEsa0JBQWtCLFdBQVc7QUFBQSxFQUM5RCxrQkFBa0IsQ0FBQyxtQkFBbUIsV0FBVztBQUFBLEVBQ2pELFdBQVcsQ0FBQyxhQUFhLFdBQVc7QUFBQSxFQUNwQyxXQUFXLENBQUM7QUFBQSxFQUNaLFVBQVUsQ0FBQztBQUFBLEVBQ1gsV0FBVyxDQUFDO0FBQ2Q7QUFVQSxNQUFNLGdCQUFnQjtBQUdmLGFBQU0sZ0JBQWdCO0FBRTdCLFNBQVMsZ0JBQTBCO0FBQ2pDLFNBQU87QUFBQSxJQUNMLFNBQVM7QUFBQSxJQUNULFdBQVc7QUFBQSxJQUNYLFFBQVEsS0FBSztBQUFBLElBQ2IsWUFBWSxLQUFLO0FBQUEsSUFDakIsUUFBUSxLQUFLO0FBQUEsSUFDYixXQUFXLENBQUM7QUFBQSxJQUNaLFVBQVUsQ0FBQztBQUFBLElBQ1gsVUFBVSxDQUFDO0FBQUEsSUFDWCxTQUFTLENBQUM7QUFBQSxJQUNWLFVBQVUsQ0FBQztBQUFBLElBQ1gsVUFBVSxDQUFDO0FBQUEsRUFDYjtBQUNGO0FBRUEsU0FBUyxPQUFpQjtBQUN4QixNQUFJLE9BQU8sV0FBVyxZQUFhLFFBQU8sY0FBYztBQUN4RCxNQUFJO0FBQ0YsVUFBTSxNQUFNLE9BQU8sYUFBYSxRQUFRLEdBQUc7QUFDM0MsUUFBSSxDQUFDLEtBQUs7QUFDUixZQUFNLFFBQVEsY0FBYztBQUM1QixZQUFNLEtBQUs7QUFDWCxhQUFPO0FBQUEsSUFDVDtBQUNBLFVBQU0sU0FBUyxLQUFLLE1BQU0sR0FBRztBQUM3QixRQUFJLE9BQU8sWUFBWSxFQUFHLE9BQU0sSUFBSSxNQUFNLGdCQUFnQjtBQUUxRCxRQUFJLE9BQU8sY0FBYyxZQUFZO0FBQ25DLFlBQU0sU0FBUyxjQUFjO0FBRTdCLGFBQU8sYUFBYSxDQUFDLEdBQUcsT0FBTyxXQUFXLE9BQU8sQ0FBQyxNQUFNLENBQUMsRUFBRSxTQUFTLEdBQUcsR0FBRyxPQUFPLFVBQVU7QUFDM0YsYUFBTyxTQUFTLENBQUMsR0FBRyxPQUFPLE9BQU8sT0FBTyxDQUFDLE1BQU0sQ0FBQyxFQUFFLFNBQVMsR0FBRyxHQUFHLE9BQU8sTUFBTTtBQUMvRSxhQUFPLFlBQVksT0FBTyxhQUFhLENBQUM7QUFDeEMsYUFBTyxXQUFXLE9BQU8sWUFBWSxDQUFDO0FBQ3RDLGFBQU8sWUFBWSxPQUFPLFlBQVksQ0FBQyxHQUFHLE9BQU8sQ0FBQyxPQUFPLE9BQU8sT0FBTyxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sRUFBRSxDQUFDO0FBQy9GLGFBQU8sVUFBVSxPQUFPLFdBQVcsQ0FBQztBQUNwQyxhQUFPLFdBQVcsT0FBTyxZQUFZLENBQUM7QUFDdEMsYUFBTyxXQUFXLE9BQU8sWUFBWSxDQUFDO0FBRXRDLGlCQUFXLFNBQVMsT0FBTyxRQUFRO0FBQ2pDLFlBQUksQ0FBQyxNQUFNLE9BQVEsT0FBTSxTQUFTO0FBQ2xDLFlBQUksQ0FBQyxNQUFNLE9BQVEsT0FBTSxTQUFTO0FBQ2xDLFlBQUksQ0FBQyxNQUFNLE9BQU87QUFDaEIsZ0JBQU0sUUFBUTtBQUFBLFlBQ1osZUFBZTtBQUFBLFlBQ2YsaUJBQWlCO0FBQUEsWUFDakIsaUJBQWlCO0FBQUEsWUFDakIsa0JBQWtCO0FBQUEsWUFDbEIsY0FBYztBQUFBLFVBQ2hCO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFDQSxZQUFNLE1BQU07QUFDWixhQUFPO0FBQUEsSUFDVDtBQUVBLFdBQU87QUFBQSxFQUNULFFBQVE7QUFFTixVQUFNLFFBQVEsY0FBYztBQUM1QixVQUFNLEtBQUs7QUFDWCxXQUFPO0FBQUEsRUFDVDtBQUNGO0FBRUEsU0FBUyxNQUFNLElBQW9CO0FBQ2pDLE1BQUksT0FBTyxXQUFXLFlBQWE7QUFDbkMsTUFBSTtBQUNGLFdBQU8sYUFBYSxRQUFRLEtBQUssS0FBSyxVQUFVLEVBQUUsQ0FBQztBQUFBLEVBQ3JELFFBQVE7QUFFTixZQUFRLEtBQUsscURBQXFEO0FBQUEsRUFDcEU7QUFDRjtBQUVBLE1BQU0sU0FBUyxDQUFLLFVBQ2xCLGFBQWEsSUFBSSxRQUFRLENBQUMsTUFBTSxXQUFXLE1BQU0sRUFBRSxLQUFLLEdBQUcsVUFBVSxDQUFDLElBQUksUUFBUSxRQUFRLEtBQUs7QUFFakcsU0FBUyxLQUFLLElBQWMsT0FBbUM7QUFDN0QsUUFBTSxXQUFXLEdBQUcsV0FBVyxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sTUFBTSxVQUFVO0FBQ3BFLE1BQUksQ0FBQyxTQUFVLFFBQU87QUFDdEIsUUFBTSxRQUFRLEdBQUcsT0FBTyxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sU0FBUyxPQUFPO0FBQzdELE1BQUksQ0FBQyxNQUFPLFFBQU87QUFDbkIsU0FBTyxFQUFFLE9BQU8sVUFBVSxNQUFNO0FBQ2xDO0FBRUEsU0FBUyxPQUFPLFFBQWdCLFVBQXlDO0FBQ3ZFLFFBQU0sTUFBTSxTQUFTLE9BQU8sQ0FBQyxHQUFHLE1BQU07QUFDcEMsVUFBTSxJQUFJLE9BQU8sRUFBRSxHQUFHLE1BQU0sR0FBRyxFQUFFLENBQUMsQ0FBQztBQUNuQyxXQUFPLE9BQU8sU0FBUyxDQUFDLEtBQUssSUFBSSxJQUFJLElBQUk7QUFBQSxFQUMzQyxHQUFHLENBQUM7QUFDSixTQUFPLEdBQUcsTUFBTSxJQUFJLE9BQU8sTUFBTSxDQUFDLEVBQUUsU0FBUyxHQUFHLEdBQUcsQ0FBQztBQUN0RDtBQUVPLGFBQU0sa0JBQThCO0FBQUEsRUFDekMsTUFBTTtBQUFBO0FBQUEsRUFJTixNQUFNLFdBQW9DO0FBQ3hDLFVBQU0sT0FBTyxLQUFLO0FBQ2xCLFdBQU87QUFBQSxNQUNMLEtBQUssT0FDRixPQUFPLENBQUMsTUFBTSxFQUFFLFdBQVcsVUFBVSxFQUNyQyxJQUFJLENBQUMsTUFBTSxLQUFLLE1BQU0sQ0FBQyxDQUFDLEVBQ3hCLE9BQU8sQ0FBQyxNQUF5QixNQUFNLElBQUk7QUFBQSxJQUNoRDtBQUFBLEVBQ0Y7QUFBQSxFQUVBLE1BQU0sUUFBUSxTQUErQztBQUMzRCxVQUFNLE9BQU8sS0FBSztBQUNsQixVQUFNLFFBQVEsS0FBSyxPQUFPLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxPQUFPO0FBQ3RELFdBQU8sT0FBTyxRQUFRLEtBQUssTUFBTSxLQUFLLElBQUksSUFBSTtBQUFBLEVBQ2hEO0FBQUEsRUFFQSxNQUFNLFdBQVcsU0FBdUM7QUFDdEQsVUFBTSxPQUFPLEtBQUs7QUFDbEIsV0FBTyxPQUFPLFVBQVUsS0FBSyxXQUFXLE9BQU8sQ0FBQyxNQUFNLEVBQUUsWUFBWSxPQUFPLElBQUksS0FBSyxVQUFVO0FBQUEsRUFDaEc7QUFBQSxFQUVBLE1BQU0saUJBQWlCLFlBQXNDO0FBQzNELFVBQU0sT0FBTyxLQUFLO0FBQ2xCLFdBQU8sT0FBTyxLQUFLLE9BQU8sT0FBTyxDQUFDLE1BQU0sRUFBRSxlQUFlLFVBQVUsQ0FBQztBQUFBLEVBQ3RFO0FBQUEsRUFFQSxNQUFNLE1BQU0sU0FBd0M7QUFDbEQsV0FBTyxPQUFPLEtBQUssRUFBRSxPQUFPLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxPQUFPLEtBQUssSUFBSTtBQUFBLEVBQ25FO0FBQUEsRUFFQSxNQUFNLE1BQU0sU0FBd0M7QUFDbEQsVUFBTSxPQUFPLEtBQUs7QUFDbEIsV0FBTyxPQUFPLEtBQUssT0FBTyxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sT0FBTyxLQUFLLElBQUk7QUFBQSxFQUNqRTtBQUFBO0FBQUEsRUFJQSxNQUFNLGVBQWUsT0FBNEU7QUFDL0YsVUFBTSxPQUFPLEtBQUs7QUFDbEIsVUFBTSxXQUFxQjtBQUFBLE1BQ3pCLEdBQUc7QUFBQSxNQUNILElBQUksT0FBTyxNQUFNLEtBQUssVUFBVTtBQUFBLE1BQ2hDLFlBQVcsb0JBQUksS0FBSyxHQUFFLFlBQVksRUFBRSxNQUFNLEdBQUcsRUFBRTtBQUFBLE1BQy9DLFdBQVc7QUFBQSxJQUNiO0FBQ0EsU0FBSyxhQUFhLENBQUMsVUFBVSxHQUFHLEtBQUssVUFBVTtBQUMvQyxVQUFNLElBQUk7QUFDVixXQUFPLE9BQU8sUUFBUTtBQUFBLEVBQ3hCO0FBQUEsRUFFQSxNQUFNLFlBQVksT0FBbUY7QUFDbkcsVUFBTSxPQUFPLEtBQUs7QUFDbEIsVUFBTSxRQUFlO0FBQUEsTUFDbkIsR0FBRztBQUFBLE1BQ0gsSUFBSSxPQUFPLE1BQU0sS0FBSyxNQUFNO0FBQUEsTUFDNUIsT0FBTztBQUFBLE1BQ1AsY0FBYztBQUFBLE1BQ2QsV0FBVztBQUFBLElBQ2I7QUFDQSxTQUFLLFNBQVMsQ0FBQyxPQUFPLEdBQUcsS0FBSyxNQUFNO0FBQ3BDLFVBQU0sSUFBSTtBQUNWLFdBQU8sT0FBTyxLQUFLO0FBQUEsRUFDckI7QUFBQSxFQUVBLE1BQU0sWUFBWSxTQUFpQixPQUE4QztBQUMvRSxVQUFNLE9BQU8sS0FBSztBQUNsQixVQUFNLFFBQVEsS0FBSyxPQUFPLFVBQVUsQ0FBQyxNQUFNLEVBQUUsT0FBTyxPQUFPO0FBQzNELFFBQUksVUFBVSxHQUFJLFFBQU8sT0FBTyxJQUFJO0FBQ3BDLFVBQU0sVUFBaUI7QUFBQSxNQUNyQixHQUFHLEtBQUssT0FBTyxLQUFLO0FBQUEsTUFDcEIsR0FBRztBQUFBLE1BQ0gsY0FBYSxvQkFBSSxLQUFLLEdBQUUsWUFBWSxFQUFFLE1BQU0sR0FBRyxFQUFFO0FBQUEsSUFDbkQ7QUFDQSxTQUFLLE9BQU8sS0FBSyxJQUFJO0FBQ3JCLFVBQU0sSUFBSTtBQUNWLFdBQU8sT0FBTyxPQUFPO0FBQUEsRUFDdkI7QUFBQSxFQUVBLE1BQU0sWUFBWSxTQUFnQztBQUNoRCxVQUFNLE9BQU8sS0FBSztBQUNsQixTQUFLLFNBQVMsS0FBSyxPQUFPLE9BQU8sQ0FBQyxNQUFNLEVBQUUsT0FBTyxPQUFPO0FBQ3hELFVBQU0sSUFBSTtBQUNWLFdBQU8sT0FBTyxNQUFTO0FBQUEsRUFDekI7QUFBQTtBQUFBLEVBSUEsTUFBTSxRQUEyQjtBQUMvQixXQUFPLE9BQU8sS0FBSyxFQUFFLFFBQVE7QUFBQSxFQUMvQjtBQUFBLEVBRUEsTUFBTSxZQUFZLFNBQW1DO0FBQ25ELFVBQU0sT0FBTyxLQUFLO0FBQ2xCLFVBQU0sTUFBTSxLQUFLLFNBQVMsU0FBUyxPQUFPO0FBQzFDLFNBQUssV0FBVyxNQUFNLEtBQUssU0FBUyxPQUFPLENBQUMsTUFBTSxNQUFNLE9BQU8sSUFBSSxDQUFDLEdBQUcsS0FBSyxVQUFVLE9BQU87QUFDN0YsVUFBTSxJQUFJO0FBQ1YsV0FBTyxPQUFPLENBQUMsR0FBRztBQUFBLEVBQ3BCO0FBQUEsRUFFQSxNQUFNLFlBQWdDO0FBQ3BDLFdBQU8sT0FBTyxLQUFLLEVBQUUsU0FBUztBQUFBLEVBQ2hDO0FBQUEsRUFFQSxNQUFNLGNBQWMsT0FBb0U7QUFDdEYsVUFBTSxPQUFPLEtBQUs7QUFDbEIsVUFBTSxVQUFtQjtBQUFBLE1BQ3ZCLEdBQUc7QUFBQSxNQUNILElBQUksT0FBTyxPQUFPLEtBQUssU0FBUztBQUFBLE1BQ2hDLFNBQVEsb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFBQSxNQUMvQixRQUFRO0FBQUEsSUFDVjtBQUNBLFNBQUssWUFBWSxDQUFDLFNBQVMsR0FBRyxLQUFLLFNBQVM7QUFHNUMsUUFBSSxTQUFTLEtBQUssUUFBUSxLQUFLLENBQUMsTUFBTSxFQUFFLFlBQVksTUFBTSxPQUFPO0FBQ2pFLFFBQUksQ0FBQyxRQUFRO0FBQ1gsZUFBUyxFQUFFLElBQUksUUFBUSxLQUFLLElBQUksQ0FBQyxJQUFJLFNBQVMsTUFBTSxTQUFTLFVBQVUsQ0FBQyxFQUFFO0FBQzFFLFdBQUssUUFBUSxLQUFLLE1BQU07QUFBQSxJQUMxQjtBQUNBLFdBQU8sU0FBUyxLQUFLO0FBQUEsTUFDbkIsSUFBSSxPQUFPLEtBQUssSUFBSSxDQUFDO0FBQUEsTUFDckIsVUFBVTtBQUFBLE1BQ1YsTUFBTSxNQUFNO0FBQUEsTUFDWixTQUFRLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQUEsTUFDL0IsUUFBUTtBQUFBLElBQ1YsQ0FBQztBQUVELFVBQU0sUUFBUSxLQUFLLE9BQU8sVUFBVSxDQUFDLE1BQU0sRUFBRSxPQUFPLE1BQU0sT0FBTztBQUNqRSxRQUFJLFVBQVUsSUFBSTtBQUNoQixXQUFLLE9BQU8sS0FBSyxJQUFJLEVBQUUsR0FBRyxLQUFLLE9BQU8sS0FBSyxHQUFHLGNBQWMsS0FBSyxPQUFPLEtBQUssRUFBRSxlQUFlLEVBQUU7QUFBQSxJQUNsRztBQUVBLFVBQU0sSUFBSTtBQUNWLFdBQU8sT0FBTyxPQUFPO0FBQUEsRUFDdkI7QUFBQSxFQUVBLE1BQU0saUJBQWlCLFdBQW1CLFFBQXNDO0FBQzlFLFVBQU0sT0FBTyxLQUFLO0FBQ2xCLFVBQU0sUUFBUSxLQUFLLFVBQVUsVUFBVSxDQUFDLE1BQU0sRUFBRSxPQUFPLFNBQVM7QUFDaEUsUUFBSSxVQUFVLElBQUk7QUFDaEIsV0FBSyxVQUFVLEtBQUssSUFBSSxFQUFFLEdBQUcsS0FBSyxVQUFVLEtBQUssR0FBRyxPQUFPO0FBQzNELFlBQU0sSUFBSTtBQUFBLElBQ1o7QUFDQSxXQUFPLE9BQU8sTUFBUztBQUFBLEVBQ3pCO0FBQUEsRUFFQSxNQUFNLFdBQW9DO0FBQ3hDLFdBQU8sT0FBTyxLQUFLLEVBQUUsUUFBUTtBQUFBLEVBQy9CO0FBQUEsRUFFQSxNQUFNLGNBQWMsT0FBc0U7QUFDeEYsVUFBTSxPQUFPLEtBQUs7QUFDbEIsVUFBTSxVQUF3QjtBQUFBLE1BQzVCLEdBQUc7QUFBQSxNQUNILElBQUksT0FBTyxPQUFPLEtBQUssUUFBUTtBQUFBLE1BQy9CLFlBQVcsb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFBQSxJQUNwQztBQUNBLFNBQUssV0FBVyxDQUFDLFNBQVMsR0FBRyxLQUFLLFFBQVE7QUFDMUMsVUFBTSxJQUFJO0FBQ1YsV0FBTyxPQUFPLE9BQU87QUFBQSxFQUN2QjtBQUFBO0FBQUEsRUFJQSxNQUFNLFdBQStCO0FBQ25DLFVBQU0sT0FBTyxLQUFLO0FBRWxCLFdBQU87QUFBQSxNQUNMLEtBQUssU0FBUyxJQUFJLENBQUMsTUFBTTtBQUN2QixjQUFNLFFBQVEsS0FBSyxPQUFPLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxFQUFFLE9BQU87QUFDeEQsY0FBTSxXQUFXLFFBQVEsS0FBSyxXQUFXLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxNQUFNLFVBQVUsSUFBSTtBQUNsRixjQUFNLFFBQVEsV0FBVyxLQUFLLE9BQU8sS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLFNBQVMsT0FBTyxJQUFJO0FBRTlFLGVBQU87QUFBQSxVQUNMLElBQUksRUFBRTtBQUFBLFVBQ04sU0FBUyxFQUFFO0FBQUEsVUFDWCxXQUFXLE9BQU8sUUFBUTtBQUFBLFVBQzFCLFlBQVksT0FBTyxPQUFPLENBQUMsR0FBRyxPQUFPO0FBQUEsVUFDckMsTUFBTSxVQUFVLFFBQVE7QUFBQSxVQUN4QixVQUFVO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFJVixZQUFZO0FBQUEsVUFDWixTQUFTLE9BQU8sTUFBTTtBQUFBLFVBQ3RCLFdBQVcsT0FBTyxRQUFRO0FBQUEsVUFDMUIsUUFBUSxFQUFFO0FBQUEsVUFDVixZQUFZLEVBQUU7QUFBQSxVQUNkLFFBQVEsRUFBRTtBQUFBLFVBQ1YsUUFBUSxFQUFFO0FBQUEsVUFDVixTQUFTLEVBQUU7QUFBQSxVQUNYLGFBQWEsRUFBRTtBQUFBLFVBQ2YsYUFBYSxFQUFFLGNBQWMsZ0JBQWdCO0FBQUEsVUFDN0MsWUFBWSxFQUFFLGNBQWMsZ0JBQWdCO0FBQUEsVUFDNUMsZUFBZSxFQUFFO0FBQUEsVUFDakIsV0FBVyxFQUFFO0FBQUEsVUFDYixXQUFXLEVBQUU7QUFBQTtBQUFBLFVBRWIsYUFBYTtBQUFBLFFBQ2Y7QUFBQSxNQUNGLENBQUM7QUFBQSxJQUNIO0FBQUEsRUFDRjtBQUFBLEVBRUEsTUFBTSxlQUFlLE9BQXlCO0FBQzVDLFVBQU0sT0FBTyxLQUFLO0FBQ2xCLFVBQU0sUUFBUSxLQUFLLE9BQU8sS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLE1BQU0sT0FBTztBQUU1RCxRQUFJLENBQUMsTUFBTyxPQUFNLElBQUksTUFBTSw4QkFBOEI7QUFDMUQsUUFBSSxNQUFNLGFBQWEsV0FBVyxjQUFjLE1BQU0sYUFBYSxXQUFXLGVBQWU7QUFDM0YsWUFBTSxJQUFJLE1BQU0sc0NBQXNDO0FBQUEsSUFDeEQ7QUFFQSxVQUFNLFVBQXdCO0FBQUEsTUFDNUIsSUFBSSxNQUFNLEtBQUssSUFBSSxDQUFDO0FBQUEsTUFDcEIsU0FBUyxNQUFNO0FBQUEsTUFDZixRQUFRO0FBQUEsTUFDUixZQUFZLE1BQU07QUFBQSxNQUNsQixRQUFRLE1BQU07QUFBQSxNQUNkLFFBQVEsTUFBTTtBQUFBLE1BQ2QsU0FBUyxNQUFNLFdBQVc7QUFBQSxNQUMxQixhQUFhO0FBQUEsTUFDYixZQUFXLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQUEsTUFDbEMsV0FBVztBQUFBLE1BQ1gsZUFBZTtBQUFBLElBQ2pCO0FBRUEsU0FBSyxXQUFXLENBQUMsU0FBUyxHQUFHLEtBQUssUUFBUTtBQUMxQyxVQUFNLElBQUk7QUFFVixVQUFNLENBQUMsSUFBSSxJQUFJLE1BQU0sS0FBSyxTQUFTO0FBQ25DLFdBQU87QUFBQSxFQUNUO0FBQUEsRUFFQSxNQUFNLGlCQUFpQixXQUFtQixRQUF1QixRQUFnQztBQUMvRixVQUFNLE9BQU8sS0FBSztBQUNsQixVQUFNLFVBQVUsS0FBSyxTQUFTLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxTQUFTO0FBQzVELFFBQUksQ0FBQyxRQUFTLFFBQU8sT0FBTyxNQUFTO0FBRXJDLFFBQUksQ0FBQyxZQUFZLFFBQVEsTUFBTSxFQUFFLFNBQVMsTUFBTSxHQUFHO0FBQ2pELFlBQU0sSUFBSSxNQUFNLDRCQUE0QixRQUFRLE1BQU0sT0FBTyxNQUFNLEdBQUc7QUFBQSxJQUM1RTtBQUVBLFlBQVEsU0FBUztBQUNqQixRQUFJLFdBQVcsT0FBVyxTQUFRLGdCQUFnQjtBQUVsRCxRQUFJLFdBQVcsWUFBWTtBQUN6QixjQUFRLGNBQWM7QUFDdEIsY0FBUSxhQUFZLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQUEsSUFDN0M7QUFDQSxRQUFJLFdBQVcsV0FBWSxTQUFRLGFBQVksb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFHdEUsUUFBSSxXQUFXLGFBQWE7QUFDMUIsWUFBTSxRQUFRLElBQUksS0FBSyxRQUFRLFVBQVU7QUFDekMsZUFBUyxJQUFJLEdBQUcsSUFBSSxLQUFLLElBQUksUUFBUSxRQUFRLENBQUMsR0FBRyxLQUFLO0FBQ3BELGNBQU0sU0FBUyxJQUFJLEtBQUssTUFBTSxZQUFZLEdBQUcsTUFBTSxTQUFTLElBQUksR0FBRyxNQUFNLFFBQVEsQ0FBQztBQUNsRixjQUFNLE1BQU0sT0FBTyxZQUFZLEVBQUUsTUFBTSxHQUFHLEVBQUU7QUFDNUMsWUFBSSxLQUFLLFNBQVMsS0FBSyxDQUFDLE1BQU0sRUFBRSxjQUFjLFFBQVEsTUFBTSxFQUFFLGdCQUFnQixHQUFHLEVBQUc7QUFFcEYsYUFBSyxTQUFTLEtBQUs7QUFBQSxVQUNqQixJQUFJLE9BQU8sUUFBUSxFQUFFLElBQUksQ0FBQztBQUFBLFVBQzFCLFdBQVcsUUFBUTtBQUFBLFVBQ25CLFNBQVMsUUFBUTtBQUFBLFVBQ2pCLGFBQWE7QUFBQSxVQUNiLFNBQVM7QUFBQSxVQUNULFFBQVEsUUFBUTtBQUFBLFVBQ2hCLFFBQVE7QUFBQSxVQUNSLFFBQVE7QUFBQSxVQUNSLFdBQVc7QUFBQSxRQUNiLENBQUM7QUFBQSxNQUNIO0FBQUEsSUFDRjtBQUdBLFVBQU0sUUFBUSxLQUFLLE9BQU8sS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLFFBQVEsT0FBTztBQUM5RCxRQUFJLE9BQU87QUFDVCxVQUFJLFdBQVcsWUFBYSxPQUFNLGVBQWUsRUFBRSxHQUFHLE1BQU0sY0FBYyxRQUFRLFdBQVc7QUFDN0YsVUFBSSxXQUFXLGVBQWUsV0FBVyxhQUFhO0FBQ3BELGNBQU0sZUFBZSxFQUFFLEdBQUcsTUFBTSxjQUFjLFFBQVEsWUFBWTtBQUFBLE1BQ3BFO0FBQUEsSUFDRjtBQUVBLFVBQU0sSUFBSTtBQUNWLFdBQU8sT0FBTyxNQUFTO0FBQUEsRUFDekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQU1BLE1BQU0sY0FBcUM7QUFDekMsV0FBTyxPQUFPLENBQUMsQ0FBQztBQUFBLEVBQ2xCO0FBQUEsRUFFQSxNQUFNLG9CQUFtQztBQUN2QyxVQUFNLElBQUksTUFBTSw0REFBNEQ7QUFBQSxFQUM5RTtBQUFBLEVBRUEsTUFBTSxXQUEwQjtBQUM5QixVQUFNLElBQUksTUFBTSw0REFBNEQ7QUFBQSxFQUM5RTtBQUFBLEVBRUEsTUFBTSxpQkFBZ0M7QUFDcEMsVUFBTSxJQUFJLE1BQU0sNERBQTREO0FBQUEsRUFDOUU7QUFBQSxFQUVBLE1BQU0saUJBQWdDO0FBQ3BDLFVBQU0sSUFBSSxNQUFNLDREQUE0RDtBQUFBLEVBQzlFO0FBQUE7QUFBQSxFQUlBLE1BQU0sV0FBVyxVQUFtQztBQUNsRCxVQUFNLFNBQWlDLEVBQUMsVUFBVSxLQUFLLFlBQVksS0FBSyxXQUFXLEtBQUssV0FBVyxLQUFLLFFBQVEsSUFBRztBQUNuSCxXQUFPLE9BQU8sT0FBTyxRQUFRLEtBQUssR0FBRztBQUFBLEVBQ3ZDO0FBQUEsRUFFQSxNQUFNLGlCQUFpQixZQUFpRTtBQUN0RixVQUFNLE9BQU8sS0FBSztBQUNsQixVQUFNLFNBQVEsb0JBQUksS0FBSyxHQUFFLFlBQVksRUFBRSxNQUFNLEdBQUcsQ0FBQztBQUNqRCxVQUFNLE9BQU8sS0FBSyxPQUFPO0FBQUEsTUFDdkIsQ0FBQyxNQUFNLEVBQUUsZUFBZSxjQUFjLENBQUMsRUFBRSxjQUFjLEVBQUUsZUFBZSxJQUFJLFdBQVcsS0FBSztBQUFBLElBQzlGLEVBQUU7QUFFRixXQUFPLE9BQU8sRUFBRSxNQUFNLFNBQVMsTUFBTSxDQUFDO0FBQUEsRUFDeEM7QUFBQSxFQUVBLE1BQU0sY0FBYyxTQUFnQztBQUNsRCxVQUFNLE9BQU8sS0FBSztBQUNsQixVQUFNLFFBQVEsS0FBSyxPQUFPLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxPQUFPO0FBQ3RELFFBQUksT0FBTztBQUNULFlBQU0saUJBQWlCO0FBQ3ZCLFlBQU0sZUFBYyxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUMzQyxZQUFNLElBQUk7QUFBQSxJQUNaO0FBQ0EsV0FBTyxPQUFPLE1BQVM7QUFBQSxFQUN6QjtBQUFBLEVBRUEsTUFBTSxrQkFBaUM7QUFDckMsV0FBTyxPQUFPLE1BQVM7QUFBQSxFQUN6QjtBQUFBO0FBQUEsRUFJQSxNQUFNLFdBQW1DO0FBQ3ZDLFVBQU0sT0FBTyxLQUFLO0FBQ2xCLFVBQU0sU0FBUSxvQkFBSSxLQUFLLEdBQUUsWUFBWSxFQUFFLE1BQU0sR0FBRyxFQUFFO0FBRWxELFdBQU87QUFBQSxNQUNMLEtBQUssU0FBUyxJQUFJLENBQUMsUUFBUTtBQUN6QixjQUFNLFFBQVEsS0FBSyxPQUFPLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxJQUFJLE9BQU87QUFDMUQsY0FBTSxXQUFXLFFBQVEsS0FBSyxXQUFXLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxNQUFNLFVBQVUsSUFBSTtBQUNsRixjQUFNLFFBQVEsV0FBVyxLQUFLLE9BQU8sS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLFNBQVMsT0FBTyxJQUFJO0FBRTlFLGVBQU87QUFBQSxVQUNMLElBQUksSUFBSTtBQUFBLFVBQ1IsV0FBVyxJQUFJO0FBQUEsVUFDZixTQUFTLElBQUk7QUFBQSxVQUNiLFdBQVcsT0FBTyxRQUFRO0FBQUEsVUFDMUIsTUFBTSxVQUFVLFFBQVE7QUFBQSxVQUN4QixpQkFBaUIsT0FBTyxRQUFRO0FBQUEsVUFDaEMsYUFBYTtBQUFBLFVBQ2IsYUFBYSxJQUFJO0FBQUEsVUFDakIsV0FBVyxJQUFJO0FBQUEsVUFDZixTQUFTLElBQUk7QUFBQTtBQUFBLFVBRWIsUUFBUSxJQUFJLFdBQVcsU0FBUyxJQUFJLFVBQVUsUUFBUSxZQUFZLElBQUk7QUFBQSxVQUN0RSxRQUFRLElBQUk7QUFBQSxVQUNaLFFBQVEsSUFBSTtBQUFBLFVBQ1osV0FBVyxJQUFJO0FBQUEsVUFDZixXQUFXO0FBQUEsUUFDYjtBQUFBLE1BQ0YsQ0FBQztBQUFBLElBQ0g7QUFBQSxFQUNGO0FBQUEsRUFFQSxNQUFNLFdBQVcsV0FBa0M7QUFDakQsVUFBTSxPQUFPLEtBQUs7QUFDbEIsVUFBTSxNQUFNLEtBQUssU0FBUyxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sU0FBUztBQUN4RCxRQUFJLENBQUMsT0FBTyxJQUFJLFdBQVcsT0FBUSxRQUFPLE9BQU8sTUFBUztBQUUxRCxRQUFJLFNBQVM7QUFDYixRQUFJLFVBQVMsb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFDcEMsUUFBSSxZQUFZLFFBQU8sb0JBQUksS0FBSyxHQUFFLFlBQVksQ0FBQyxJQUFJLE9BQU8sRUFBRSxjQUFjLEVBQUUsU0FBUyxHQUFHLEdBQUcsQ0FBQztBQUM1RixVQUFNLElBQUk7QUFDVixXQUFPLE9BQU8sTUFBUztBQUFBLEVBQ3pCO0FBQUEsRUFFQSxNQUFNLGFBQWEsV0FBa0M7QUFDbkQsVUFBTSxPQUFPLEtBQUs7QUFDbEIsVUFBTSxNQUFNLEtBQUssU0FBUyxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sU0FBUztBQUN4RCxRQUFJLE9BQU8sSUFBSSxXQUFXLE9BQVEsS0FBSSxTQUFTO0FBQy9DLFVBQU0sSUFBSTtBQUNWLFdBQU8sT0FBTyxNQUFTO0FBQUEsRUFDekI7QUFBQSxFQUVBLE1BQU0sZUFBZSxXQUFtQixTQUFTLElBQW1CO0FBQ2xFLFVBQU0sT0FBTyxLQUFLO0FBQ2xCLFVBQU0sVUFBVSxLQUFLLFNBQVMsS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLFNBQVM7QUFDNUQsUUFBSSxDQUFDLFFBQVMsUUFBTyxPQUFPLE1BQVM7QUFJckMsVUFBTSxXQUFXLEtBQUssU0FBUyxPQUFPLENBQUMsTUFBTSxFQUFFLGNBQWMsU0FBUztBQUN0RSxVQUFNLFNBQVMsU0FBUyxJQUFJLENBQUMsTUFBTSxFQUFFLFdBQVcsRUFBRSxLQUFLO0FBQ3ZELFVBQU0sVUFBVSxPQUFPLFNBQVMsT0FBTyxPQUFPLFNBQVMsQ0FBQyxJQUFJLFFBQVE7QUFDcEUsVUFBTSxPQUFPLElBQUksS0FBSyxPQUFPO0FBRTdCLGFBQVMsSUFBSSxHQUFHLEtBQUssUUFBUSxLQUFLO0FBQ2hDLFlBQU0sU0FBUyxJQUFJLEtBQUssS0FBSyxZQUFZLEdBQUcsS0FBSyxTQUFTLElBQUksR0FBRyxLQUFLLFFBQVEsQ0FBQztBQUMvRSxZQUFNLE1BQU0sT0FBTyxZQUFZLEVBQUUsTUFBTSxHQUFHLEVBQUU7QUFDNUMsVUFBSSxLQUFLLFNBQVMsS0FBSyxDQUFDLE1BQU0sRUFBRSxjQUFjLGFBQWEsRUFBRSxnQkFBZ0IsR0FBRyxFQUFHO0FBRW5GLFdBQUssU0FBUyxLQUFLO0FBQUEsUUFDakIsSUFBSSxPQUFPLFNBQVMsSUFBSSxHQUFHO0FBQUEsUUFDM0I7QUFBQSxRQUNBLFNBQVMsUUFBUTtBQUFBLFFBQ2pCLGFBQWE7QUFBQSxRQUNiLFNBQVM7QUFBQSxRQUNULFFBQVEsUUFBUTtBQUFBLFFBQ2hCLFFBQVE7QUFBQSxRQUNSLFFBQVE7QUFBQSxRQUNSLFdBQVc7QUFBQSxNQUNiLENBQUM7QUFBQSxJQUNIO0FBRUEsVUFBTSxJQUFJO0FBQ1YsV0FBTyxPQUFPLE1BQVM7QUFBQSxFQUN6QjtBQUFBO0FBQUEsRUFJQSxNQUFNLGdCQUF5QztBQUM3QyxVQUFNLE9BQU8sS0FBSztBQUVsQixXQUFPO0FBQUEsTUFDTCxLQUFLLFFBQ0YsSUFBSSxDQUFDLFdBQVc7QUFDZixjQUFNLFFBQVEsS0FBSyxPQUFPLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxPQUFPLE9BQU87QUFDN0QsY0FBTSxXQUFXLFFBQVEsS0FBSyxXQUFXLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxNQUFNLFVBQVUsSUFBSTtBQUNsRixjQUFNLFFBQVEsV0FBVyxLQUFLLE9BQU8sS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLFNBQVMsT0FBTyxJQUFJO0FBQzlFLGNBQU0sT0FBTyxPQUFPLFNBQVMsT0FBTyxTQUFTLFNBQVMsQ0FBQztBQUV2RCxlQUFPO0FBQUEsVUFDTCxJQUFJLE9BQU87QUFBQSxVQUNYLFNBQVMsT0FBTztBQUFBLFVBQ2hCLFdBQVcsT0FBTyxRQUFRO0FBQUEsVUFDMUIsWUFBWSxPQUFPLE9BQU8sQ0FBQyxHQUFHLE9BQU87QUFBQSxVQUNyQyxjQUFjLFVBQVUsUUFBUTtBQUFBLFVBQ2hDLGVBQWUsT0FBTyxNQUFNO0FBQUEsVUFDNUIsaUJBQWlCLE9BQU8sUUFBUTtBQUFBLFVBQ2hDLGlCQUFpQixPQUFPLGNBQWM7QUFBQSxVQUN0QyxhQUFhO0FBQUEsVUFDYixhQUFhLE1BQU0sUUFBUTtBQUFBLFVBQzNCLGVBQWUsTUFBTSxXQUFVLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQUEsVUFDdEQsUUFBUSxPQUFPLFNBQVMsT0FBTyxDQUFDLE1BQU0sRUFBRSxhQUFhLGlCQUFpQixDQUFDLEVBQUUsTUFBTSxFQUFFO0FBQUEsUUFDbkY7QUFBQSxNQUNGLENBQUMsRUFDQSxLQUFLLENBQUMsR0FBRyxNQUFNLEVBQUUsY0FBYyxjQUFjLEVBQUUsYUFBYSxDQUFDO0FBQUEsSUFDbEU7QUFBQSxFQUNGO0FBQUEsRUFFQSxNQUFNLFNBQVMsZ0JBQTRDO0FBQ3pELFVBQU0sU0FBUyxLQUFLLEVBQUUsUUFBUSxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sY0FBYztBQUNqRSxRQUFJLENBQUMsT0FBUSxRQUFPLE9BQU8sQ0FBQyxDQUFDO0FBRTdCLFdBQU87QUFBQSxNQUNMLE9BQU8sU0FBUyxJQUFJLENBQUMsT0FBTztBQUFBLFFBQzFCLElBQUksRUFBRTtBQUFBLFFBQ047QUFBQSxRQUNBLFVBQVUsRUFBRTtBQUFBLFFBQ1osTUFBTSxFQUFFO0FBQUEsUUFDUixRQUFRLEVBQUU7QUFBQSxRQUNWLFFBQVEsRUFBRTtBQUFBLFFBQ1YsTUFBTSxFQUFFLGFBQWE7QUFBQSxNQUN2QixFQUFFO0FBQUEsSUFDSjtBQUFBLEVBQ0Y7QUFBQSxFQUVBLE1BQU0sWUFBWSxnQkFBd0IsTUFBZ0M7QUFDeEUsVUFBTSxPQUFPLEtBQUs7QUFDbEIsVUFBTSxTQUFTLEtBQUssUUFBUSxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sY0FBYztBQUMvRCxRQUFJLENBQUMsT0FBUSxPQUFNLElBQUksTUFBTSxxQ0FBcUM7QUFFbEUsVUFBTSxVQUFVO0FBQUEsTUFDZCxJQUFJLE9BQU8sS0FBSyxJQUFJLENBQUM7QUFBQSxNQUNyQixVQUFVO0FBQUEsTUFDVjtBQUFBLE1BQ0EsU0FBUSxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUFBLE1BQy9CLFFBQVE7QUFBQSxJQUNWO0FBRUEsV0FBTyxTQUFTLEtBQUssT0FBTztBQUM1QixVQUFNLElBQUk7QUFDVixzQkFBa0I7QUFFbEIsV0FBTyxPQUFPLEVBQUUsR0FBRyxTQUFTLGdCQUFnQixNQUFNLEtBQUssQ0FBQztBQUFBLEVBQzFEO0FBQUEsRUFFQSxNQUFNLFNBQVMsZ0JBQXVDO0FBQ3BELFVBQU0sT0FBTyxLQUFLO0FBQ2xCLFVBQU0sU0FBUyxLQUFLLFFBQVEsS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLGNBQWM7QUFDL0QsUUFBSSxDQUFDLE9BQVEsUUFBTyxPQUFPLE1BQVM7QUFFcEMsVUFBTSxPQUFNLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQ25DLGVBQVcsS0FBSyxPQUFPLFVBQVU7QUFDL0IsVUFBSSxFQUFFLGFBQWEsaUJBQWlCLENBQUMsRUFBRSxPQUFRLEdBQUUsU0FBUztBQUFBLElBQzVEO0FBRUEsVUFBTSxJQUFJO0FBQ1YsV0FBTyxPQUFPLE1BQVM7QUFBQSxFQUN6QjtBQUFBLEVBRUEsTUFBTSxpQkFBaUIsU0FBa0M7QUFDdkQsVUFBTSxPQUFPLEtBQUs7QUFDbEIsVUFBTSxXQUFXLEtBQUssUUFBUSxLQUFLLENBQUMsTUFBTSxFQUFFLFlBQVksT0FBTztBQUMvRCxRQUFJLFNBQVUsUUFBTyxPQUFPLFNBQVMsRUFBRTtBQUV2QyxVQUFNLFNBQXNCLEVBQUUsSUFBSSxRQUFRLEtBQUssSUFBSSxDQUFDLElBQUksU0FBUyxVQUFVLENBQUMsRUFBRTtBQUM5RSxTQUFLLFFBQVEsS0FBSyxNQUFNO0FBQ3hCLFVBQU0sSUFBSTtBQUVWLFdBQU8sT0FBTyxPQUFPLEVBQUU7QUFBQSxFQUN6QjtBQUFBLEVBRUEsb0JBQW9CLFVBQWtDO0FBR3BELG1CQUFlLElBQUksUUFBUTtBQUMzQixXQUFPLE1BQU0sZUFBZSxPQUFPLFFBQVE7QUFBQSxFQUM3QztBQUFBO0FBQUEsRUFJQSxNQUFNLFFBQXVCO0FBQzNCLFFBQUksT0FBTyxXQUFXLFlBQWEsUUFBTyxhQUFhLFdBQVcsR0FBRztBQUNyRSxTQUFLO0FBQ0wsV0FBTyxPQUFPLE1BQVM7QUFBQSxFQUN6QjtBQUNGO0FBRU8sYUFBTSxpQkFBaUIsS0FBSzsiLCJuYW1lcyI6W119