import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Saved.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=9ceb86a3"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("D:/I2I Project - Habito/App Folder/habito/src/pages/Saved.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=9ceb86a3";
import { Bookmark } from "/node_modules/.vite/deps/lucide-react.js?v=9ceb86a3";
import { useHabito } from "/src/hooks/useHabito.tsx";
import { PageHeader } from "/src/components/layout/PageHeader.tsx";
import { SpaceCard } from "/src/components/space/SpaceCard.tsx";
import { Button } from "/src/components/ui/Button.tsx";
import { scoreAll } from "/src/lib/matching.ts";
import __vite__cjsImport10_react from "/node_modules/.vite/deps/react.js?v=9ceb86a3"; const useMemo = __vite__cjsImport10_react["useMemo"];
export default function Saved() {
  _s();
  const { listings, savedIds, toggleSaved, isComparing, toggleCompare, requirements, hasStatedNeeds } = useHabito();
  const saved = listings.filter((l) => savedIds.includes(l.space.id));
  const matches = useMemo(() => scoreAll(saved, requirements), [saved, requirements]);
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(
      PageHeader,
      {
        title: "Saved spaces",
        lead: "Kept on this device, so they're still here when you come back.",
        actions: saved.length > 1 ? /* @__PURE__ */ jsxDEV(Link, { to: "/compare", children: /* @__PURE__ */ jsxDEV(Button, { children: "Compare these" }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Saved.tsx",
          lineNumber: 42,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Saved.tsx",
          lineNumber: 41,
          columnNumber: 9
        }, this) : void 0
      },
      void 0,
      false,
      {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Saved.tsx",
        lineNumber: 36,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { className: "container-page py-8 md:py-10", children: saved.length === 0 ? /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col items-center rounded-card bg-surface px-6 py-16 text-center ring-1 ring-hairline", children: [
      /* @__PURE__ */ jsxDEV("span", { className: "mb-4 flex size-12 items-center justify-center rounded-full bg-aqua-100 text-aqua-700", children: /* @__PURE__ */ jsxDEV(Bookmark, { size: 22, "aria-hidden": true }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Saved.tsx",
        lineNumber: 52,
        columnNumber: 15
      }, this) }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Saved.tsx",
        lineNumber: 51,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("h2", { className: "font-display text-xl font-bold text-ink", children: "Nothing saved yet." }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Saved.tsx",
        lineNumber: 54,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "mt-2 max-w-sm text-sm text-muted", children: "Tap the bookmark on any space while you browse and it waits for you here." }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Saved.tsx",
        lineNumber: 55,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(Link, { to: "/explore", className: "mt-5", children: /* @__PURE__ */ jsxDEV(Button, { children: "Start exploring" }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Saved.tsx",
        lineNumber: 59,
        columnNumber: 15
      }, this) }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Saved.tsx",
        lineNumber: 58,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Saved.tsx",
      lineNumber: 50,
      columnNumber: 9
    }, this) : /* @__PURE__ */ jsxDEV("div", { className: "grid gap-5 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4", children: saved.map(
      (l) => /* @__PURE__ */ jsxDEV(
        SpaceCard,
        {
          listing: l,
          matchScore: hasStatedNeeds ? matches.get(l.space.id)?.score : void 0,
          saved: true,
          comparing: isComparing(l.space.id),
          onToggleSave: (id) => void toggleSaved(id),
          onToggleCompare: toggleCompare
        },
        l.space.id,
        false,
        {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Saved.tsx",
          lineNumber: 65,
          columnNumber: 11
        },
        this
      )
    ) }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Saved.tsx",
      lineNumber: 63,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Saved.tsx",
      lineNumber: 48,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Saved.tsx",
    lineNumber: 35,
    columnNumber: 5
  }, this);
}
_s(Saved, "+MH6370iZE7Q6jhTGRPHmkavi5o=", false, function() {
  return [useHabito];
});
_c = Saved;
var _c;
$RefreshReg$(_c, "Saved");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/I2I Project - Habito/App Folder/habito/src/pages/Saved.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/I2I Project - Habito/App Folder/habito/src/pages/Saved.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZUksbUJBT1UsY0FQVjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFmSixTQUFTQSxZQUFZO0FBQ3JCLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxpQkFBaUI7QUFDMUIsU0FBU0Msa0JBQWtCO0FBQzNCLFNBQVNDLGlCQUFpQjtBQUMxQixTQUFTQyxjQUFjO0FBQ3ZCLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxlQUFlO0FBRXhCLHdCQUF3QkMsUUFBUTtBQUFBQyxLQUFBO0FBQzlCLFFBQU0sRUFBRUMsVUFBVUMsVUFBVUMsYUFBYUMsYUFBYUMsZUFBZUMsY0FBY0MsZUFBZSxJQUFJZCxVQUFVO0FBQ2hILFFBQU1lLFFBQVFQLFNBQVNRLE9BQU8sQ0FBQ0MsTUFBTVIsU0FBU1MsU0FBU0QsRUFBRUUsTUFBTUMsRUFBRSxDQUFDO0FBQ2xFLFFBQU1DLFVBQVVoQixRQUFRLE1BQU1ELFNBQVNXLE9BQU9GLFlBQVksR0FBRyxDQUFDRSxPQUFPRixZQUFZLENBQUM7QUFFbEYsU0FDRSxtQ0FDRTtBQUFBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxPQUFNO0FBQUEsUUFDTixNQUFLO0FBQUEsUUFDTCxTQUNFRSxNQUFNTyxTQUFTLElBQ2IsdUJBQUMsUUFBSyxJQUFHLFlBQ1AsaUNBQUMsVUFBTyw2QkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXFCLEtBRHZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQSxJQUNFQztBQUFBQTtBQUFBQSxNQVJSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQVNHO0FBQUEsSUFHSCx1QkFBQyxTQUFJLFdBQVUsZ0NBQ1pSLGdCQUFNTyxXQUFXLElBQ2hCLHVCQUFDLFNBQUksV0FBVSxrR0FDYjtBQUFBLDZCQUFDLFVBQUssV0FBVSx3RkFDZCxpQ0FBQyxZQUFTLE1BQU0sSUFBSSxlQUFXLFFBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBK0IsS0FEakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxRQUFHLFdBQVUsMkNBQTBDLGtDQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTBFO0FBQUEsTUFDMUUsdUJBQUMsT0FBRSxXQUFVLG9DQUFrQyx5RkFBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxRQUFLLElBQUcsWUFBVyxXQUFVLFFBQzVCLGlDQUFDLFVBQU8sK0JBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF1QixLQUR6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxTQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FXQSxJQUVBLHVCQUFDLFNBQUksV0FBVSwyREFDWlAsZ0JBQU1TO0FBQUFBLE1BQUksQ0FBQ1AsTUFDVjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBRUMsU0FBU0E7QUFBQUEsVUFDVCxZQUFZSCxpQkFBaUJPLFFBQVFJLElBQUlSLEVBQUVFLE1BQU1DLEVBQUUsR0FBR00sUUFBUUg7QUFBQUEsVUFDOUQ7QUFBQSxVQUNBLFdBQVdaLFlBQVlNLEVBQUVFLE1BQU1DLEVBQUU7QUFBQSxVQUNqQyxjQUFjLENBQUNBLE9BQU8sS0FBS1YsWUFBWVUsRUFBRTtBQUFBLFVBQ3pDLGlCQUFpQlI7QUFBQUE7QUFBQUEsUUFOWkssRUFBRUUsTUFBTUM7QUFBQUEsUUFEZjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BT2lDO0FBQUEsSUFFbEMsS0FYSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBWUEsS0EzQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTZCQTtBQUFBLE9BMUNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0EyQ0E7QUFFSjtBQUFDYixHQW5EdUJELE9BQUs7QUFBQSxVQUMyRU4sU0FBUztBQUFBO0FBQUEsS0FEekZNO0FBQUssSUFBQXFCO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbIkxpbmsiLCJCb29rbWFyayIsInVzZUhhYml0byIsIlBhZ2VIZWFkZXIiLCJTcGFjZUNhcmQiLCJCdXR0b24iLCJzY29yZUFsbCIsInVzZU1lbW8iLCJTYXZlZCIsIl9zIiwibGlzdGluZ3MiLCJzYXZlZElkcyIsInRvZ2dsZVNhdmVkIiwiaXNDb21wYXJpbmciLCJ0b2dnbGVDb21wYXJlIiwicmVxdWlyZW1lbnRzIiwiaGFzU3RhdGVkTmVlZHMiLCJzYXZlZCIsImZpbHRlciIsImwiLCJpbmNsdWRlcyIsInNwYWNlIiwiaWQiLCJtYXRjaGVzIiwibGVuZ3RoIiwidW5kZWZpbmVkIiwibWFwIiwiZ2V0Iiwic2NvcmUiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJTYXZlZC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTGluayB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XG5pbXBvcnQgeyBCb29rbWFyayB9IGZyb20gXCJsdWNpZGUtcmVhY3RcIjtcbmltcG9ydCB7IHVzZUhhYml0byB9IGZyb20gXCJAL2hvb2tzL3VzZUhhYml0b1wiO1xuaW1wb3J0IHsgUGFnZUhlYWRlciB9IGZyb20gXCJAL2NvbXBvbmVudHMvbGF5b3V0L1BhZ2VIZWFkZXJcIjtcbmltcG9ydCB7IFNwYWNlQ2FyZCB9IGZyb20gXCJAL2NvbXBvbmVudHMvc3BhY2UvU3BhY2VDYXJkXCI7XG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tIFwiQC9jb21wb25lbnRzL3VpL0J1dHRvblwiO1xuaW1wb3J0IHsgc2NvcmVBbGwgfSBmcm9tIFwiQC9saWIvbWF0Y2hpbmdcIjtcbmltcG9ydCB7IHVzZU1lbW8gfSBmcm9tIFwicmVhY3RcIjtcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gU2F2ZWQoKSB7XG4gIGNvbnN0IHsgbGlzdGluZ3MsIHNhdmVkSWRzLCB0b2dnbGVTYXZlZCwgaXNDb21wYXJpbmcsIHRvZ2dsZUNvbXBhcmUsIHJlcXVpcmVtZW50cywgaGFzU3RhdGVkTmVlZHMgfSA9IHVzZUhhYml0bygpO1xuICBjb25zdCBzYXZlZCA9IGxpc3RpbmdzLmZpbHRlcigobCkgPT4gc2F2ZWRJZHMuaW5jbHVkZXMobC5zcGFjZS5pZCkpO1xuICBjb25zdCBtYXRjaGVzID0gdXNlTWVtbygoKSA9PiBzY29yZUFsbChzYXZlZCwgcmVxdWlyZW1lbnRzKSwgW3NhdmVkLCByZXF1aXJlbWVudHNdKTtcblxuICByZXR1cm4gKFxuICAgIDw+XG4gICAgICA8UGFnZUhlYWRlclxuICAgICAgICB0aXRsZT1cIlNhdmVkIHNwYWNlc1wiXG4gICAgICAgIGxlYWQ9XCJLZXB0IG9uIHRoaXMgZGV2aWNlLCBzbyB0aGV5J3JlIHN0aWxsIGhlcmUgd2hlbiB5b3UgY29tZSBiYWNrLlwiXG4gICAgICAgIGFjdGlvbnM9e1xuICAgICAgICAgIHNhdmVkLmxlbmd0aCA+IDEgPyAoXG4gICAgICAgICAgICA8TGluayB0bz1cIi9jb21wYXJlXCI+XG4gICAgICAgICAgICAgIDxCdXR0b24+Q29tcGFyZSB0aGVzZTwvQnV0dG9uPlxuICAgICAgICAgICAgPC9MaW5rPlxuICAgICAgICAgICkgOiB1bmRlZmluZWRcbiAgICAgICAgfVxuICAgICAgLz5cblxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb250YWluZXItcGFnZSBweS04IG1kOnB5LTEwXCI+XG4gICAgICAgIHtzYXZlZC5sZW5ndGggPT09IDAgPyAoXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlciByb3VuZGVkLWNhcmQgYmctc3VyZmFjZSBweC02IHB5LTE2IHRleHQtY2VudGVyIHJpbmctMSByaW5nLWhhaXJsaW5lXCI+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtYi00IGZsZXggc2l6ZS0xMiBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC1mdWxsIGJnLWFxdWEtMTAwIHRleHQtYXF1YS03MDBcIj5cbiAgICAgICAgICAgICAgPEJvb2ttYXJrIHNpemU9ezIyfSBhcmlhLWhpZGRlbiAvPlxuICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cImZvbnQtZGlzcGxheSB0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LWlua1wiPk5vdGhpbmcgc2F2ZWQgeWV0LjwvaDI+XG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIG1heC13LXNtIHRleHQtc20gdGV4dC1tdXRlZFwiPlxuICAgICAgICAgICAgICBUYXAgdGhlIGJvb2ttYXJrIG9uIGFueSBzcGFjZSB3aGlsZSB5b3UgYnJvd3NlIGFuZCBpdCB3YWl0cyBmb3IgeW91IGhlcmUuXG4gICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICA8TGluayB0bz1cIi9leHBsb3JlXCIgY2xhc3NOYW1lPVwibXQtNVwiPlxuICAgICAgICAgICAgICA8QnV0dG9uPlN0YXJ0IGV4cGxvcmluZzwvQnV0dG9uPlxuICAgICAgICAgICAgPC9MaW5rPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICApIDogKFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBnYXAtNSBzbTpncmlkLWNvbHMtMiBsZzpncmlkLWNvbHMtMyB4bDpncmlkLWNvbHMtNFwiPlxuICAgICAgICAgICAge3NhdmVkLm1hcCgobCkgPT4gKFxuICAgICAgICAgICAgICA8U3BhY2VDYXJkXG4gICAgICAgICAgICAgICAga2V5PXtsLnNwYWNlLmlkfVxuICAgICAgICAgICAgICAgIGxpc3Rpbmc9e2x9XG4gICAgICAgICAgICAgICAgbWF0Y2hTY29yZT17aGFzU3RhdGVkTmVlZHMgPyBtYXRjaGVzLmdldChsLnNwYWNlLmlkKT8uc2NvcmUgOiB1bmRlZmluZWR9XG4gICAgICAgICAgICAgICAgc2F2ZWRcbiAgICAgICAgICAgICAgICBjb21wYXJpbmc9e2lzQ29tcGFyaW5nKGwuc3BhY2UuaWQpfVxuICAgICAgICAgICAgICAgIG9uVG9nZ2xlU2F2ZT17KGlkKSA9PiB2b2lkIHRvZ2dsZVNhdmVkKGlkKX1cbiAgICAgICAgICAgICAgICBvblRvZ2dsZUNvbXBhcmU9e3RvZ2dsZUNvbXBhcmV9XG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICApKX1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKX1cbiAgICAgIDwvZGl2PlxuICAgIDwvPlxuICApO1xufVxuIl0sImZpbGUiOiJEOi9JMkkgUHJvamVjdCAtIEhhYml0by9BcHAgRm9sZGVyL2hhYml0by9zcmMvcGFnZXMvU2F2ZWQudHN4In0=