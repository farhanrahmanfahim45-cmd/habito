import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Bookings.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=9ceb86a3"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("D:/I2I Project - Habito/App Folder/habito/src/pages/Bookings.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9ceb86a3"; const useCallback = __vite__cjsImport3_react["useCallback"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=9ceb86a3";
import { CalendarCheck, Phone, Check, X, Clock, Ban } from "/node_modules/.vite/deps/lucide-react.js?v=9ceb86a3";
import { db } from "/src/lib/api/index.ts";
import { useI18n } from "/src/i18n/index.tsx";
import { PageHeader } from "/src/components/layout/PageHeader.tsx";
import { Button } from "/src/components/ui/Button.tsx";
import { Modal } from "/src/components/ui/Modal.tsx";
import { Skeleton } from "/src/components/ui/Skeleton.tsx";
import { useToast } from "/src/components/ui/Toast.tsx";
import { money, longDate } from "/src/lib/format.ts";
import { cn } from "/src/lib/cn.ts";
const STATUS_STYLE = {
  requested: "bg-aqua-100 text-aqua-700",
  accepted: "bg-ok-100 text-ok-600",
  "payment-pending": "bg-sun/45 text-sun-ink",
  confirmed: "bg-ok-100 text-ok-600",
  completed: "bg-ivory-deep text-muted",
  rejected: "bg-danger-100 text-danger-600",
  cancelled: "bg-ivory-deep text-muted",
  "payment-failed": "bg-danger-100 text-danger-600"
};
export default function Bookings() {
  _s();
  const { t } = useI18n();
  const { notify } = useToast();
  const [bookings, setBookings] = useState(null);
  const [busy, setBusy] = useState(null);
  const [declining, setDeclining] = useState(null);
  const [confirming, setConfirming] = useState(null);
  const [reason, setReason] = useState("");
  const load = useCallback(async () => {
    try {
      setBookings(await db.bookings());
    } catch {
      setBookings([]);
    }
  }, []);
  useEffect(() => {
    void load();
  }, [load]);
  const move = async (booking, status, why) => {
    setBusy(booking.id);
    try {
      await db.setBookingStatus(booking.id, status, why);
      await load();
      notify(t(`booking.moved.${status}`));
    } catch (e) {
      notify(e instanceof Error ? e.message : t("auth.errorGeneric"));
    } finally {
      setBusy(null);
      setDeclining(null);
      setReason("");
    }
  };
  const live = (bookings ?? []).filter(
    (b) => !["completed", "rejected", "cancelled"].includes(b.status)
  );
  const past = (bookings ?? []).filter(
    (b) => ["completed", "rejected", "cancelled"].includes(b.status)
  );
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(PageHeader, { title: t("booking.title"), lead: t("booking.lead") }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Bookings.tsx",
      lineNumber: 98,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "container-page max-w-3xl py-6 md:py-10", children: bookings === null ? /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: [0, 1].map(
      (i) => /* @__PURE__ */ jsxDEV(Skeleton, { className: "h-40 w-full rounded-card" }, i, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Bookings.tsx",
        lineNumber: 104,
        columnNumber: 11
      }, this)
    ) }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Bookings.tsx",
      lineNumber: 102,
      columnNumber: 9
    }, this) : bookings.length === 0 ? /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col items-center rounded-card bg-surface px-6 py-16 text-center ring-1 ring-hairline", children: [
      /* @__PURE__ */ jsxDEV("span", { className: "mb-4 flex size-12 items-center justify-center rounded-full bg-aqua-100 text-aqua-700", children: /* @__PURE__ */ jsxDEV(CalendarCheck, { size: 22, "aria-hidden": true }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Bookings.tsx",
        lineNumber: 110,
        columnNumber: 15
      }, this) }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Bookings.tsx",
        lineNumber: 109,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("h2", { className: "font-display text-xl font-bold text-ink", children: t("booking.none") }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Bookings.tsx",
        lineNumber: 112,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "mt-2 max-w-sm text-sm text-muted", children: t("booking.noneBody") }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Bookings.tsx",
        lineNumber: 113,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(Link, { to: "/search", className: "mt-5", children: /* @__PURE__ */ jsxDEV(Button, { children: t("action.browseSpaces") }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Bookings.tsx",
        lineNumber: 115,
        columnNumber: 15
      }, this) }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Bookings.tsx",
        lineNumber: 114,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Bookings.tsx",
      lineNumber: 108,
      columnNumber: 9
    }, this) : /* @__PURE__ */ jsxDEV("div", { className: "space-y-6", children: [
      live.length > 0 && /* @__PURE__ */ jsxDEV("section", { children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "mb-3 font-display text-lg font-bold text-ink", children: t("booking.active") }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Bookings.tsx",
          lineNumber: 122,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("ul", { className: "space-y-3", children: live.map(
          (b) => /* @__PURE__ */ jsxDEV("li", { children: /* @__PURE__ */ jsxDEV(
            BookingCard,
            {
              booking: b,
              busy: busy === b.id,
              onMove: move,
              onDecline: () => setDeclining(b),
              onConfirm: () => setConfirming(b)
            },
            void 0,
            false,
            {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Bookings.tsx",
              lineNumber: 126,
              columnNumber: 23
            },
            this
          ) }, b.id, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Bookings.tsx",
            lineNumber: 125,
            columnNumber: 15
          }, this)
        ) }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Bookings.tsx",
          lineNumber: 123,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Bookings.tsx",
        lineNumber: 121,
        columnNumber: 11
      }, this),
      past.length > 0 && /* @__PURE__ */ jsxDEV("section", { children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "mb-3 font-display text-lg font-bold text-ink", children: t("booking.past") }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Bookings.tsx",
          lineNumber: 141,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("ul", { className: "space-y-3", children: past.map(
          (b) => /* @__PURE__ */ jsxDEV("li", { children: /* @__PURE__ */ jsxDEV(
            BookingCard,
            {
              booking: b,
              busy: false,
              onMove: move,
              onDecline: () => {
              },
              onConfirm: () => {
              }
            },
            void 0,
            false,
            {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Bookings.tsx",
              lineNumber: 145,
              columnNumber: 23
            },
            this
          ) }, b.id, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Bookings.tsx",
            lineNumber: 144,
            columnNumber: 15
          }, this)
        ) }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Bookings.tsx",
          lineNumber: 142,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Bookings.tsx",
        lineNumber: 140,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Bookings.tsx",
      lineNumber: 119,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Bookings.tsx",
      lineNumber: 100,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        open: confirming !== null,
        onClose: () => setConfirming(null),
        title: t("booking.confirmTitle"),
        footer: /* @__PURE__ */ jsxDEV("div", { className: "flex gap-2", children: [
          /* @__PURE__ */ jsxDEV(Button, { variant: "secondary", fullWidth: true, onClick: () => setConfirming(null), children: t("action.cancel") }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Bookings.tsx",
            lineNumber: 167,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            Button,
            {
              fullWidth: true,
              onClick: () => {
                const target = confirming;
                setConfirming(null);
                if (target) void move(target, "confirmed");
              },
              children: t("booking.confirm")
            },
            void 0,
            false,
            {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Bookings.tsx",
              lineNumber: 170,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Bookings.tsx",
          lineNumber: 166,
          columnNumber: 9
        }, this),
        children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-sm leading-relaxed text-ink-soft", children: t("booking.confirmBody") }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Bookings.tsx",
            lineNumber: 183,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "mt-3 rounded-xl bg-warn-100 p-3 text-sm leading-relaxed text-warn-700", children: t("booking.confirmWarning") }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Bookings.tsx",
            lineNumber: 184,
            columnNumber: 9
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Bookings.tsx",
        lineNumber: 161,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        open: declining !== null,
        onClose: () => setDeclining(null),
        title: t("booking.declineTitle"),
        footer: /* @__PURE__ */ jsxDEV("div", { className: "flex gap-2", children: [
          /* @__PURE__ */ jsxDEV(Button, { variant: "secondary", fullWidth: true, onClick: () => setDeclining(null), children: t("action.cancel") }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Bookings.tsx",
            lineNumber: 195,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            Button,
            {
              variant: "destructive",
              fullWidth: true,
              onClick: () => declining && void move(declining, "rejected", reason.trim() || void 0),
              children: t("booking.decline")
            },
            void 0,
            false,
            {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Bookings.tsx",
              lineNumber: 198,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Bookings.tsx",
          lineNumber: 194,
          columnNumber: 9
        }, this),
        children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-sm leading-relaxed text-ink-soft", children: t("booking.declineBody") }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Bookings.tsx",
            lineNumber: 208,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV("label", { className: "mt-4 block", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "mb-1.5 block text-sm font-medium text-ink-soft", children: t("booking.declineReason") }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Bookings.tsx",
              lineNumber: 210,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV(
              "textarea",
              {
                rows: 3,
                value: reason,
                onChange: (e) => setReason(e.target.value),
                placeholder: t("booking.declineHint"),
                className: "w-full rounded-xl bg-ivory p-3 text-[0.9375rem] ring-1 ring-hairline-strong focus:outline-none focus:ring-2 focus:ring-aqua-600"
              },
              void 0,
              false,
              {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Bookings.tsx",
                lineNumber: 213,
                columnNumber: 11
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Bookings.tsx",
            lineNumber: 209,
            columnNumber: 9
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Bookings.tsx",
        lineNumber: 189,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Bookings.tsx",
    lineNumber: 97,
    columnNumber: 5
  }, this);
}
_s(Bookings, "doCh2i8WZUE90xWvDnKoljOne+I=", false, function() {
  return [useI18n, useToast];
});
_c = Bookings;
function BookingCard({
  booking,
  busy,
  onMove,
  onDecline,
  onConfirm
}) {
  _s2();
  const { t } = useI18n();
  const b = booking;
  return /* @__PURE__ */ jsxDEV("article", { className: "rounded-card bg-surface p-4 ring-1 ring-hairline sm:p-5", children: /* @__PURE__ */ jsxDEV("div", { className: "flex gap-4", children: [
    b.spaceImage ? /* @__PURE__ */ jsxDEV("img", { src: b.spaceImage, alt: "", className: "size-16 shrink-0 rounded-xl object-cover" }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Bookings.tsx",
      lineNumber: 246,
      columnNumber: 9
    }, this) : /* @__PURE__ */ jsxDEV("span", { className: "size-16 shrink-0 rounded-xl bg-ivory-deep", "aria-hidden": true }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Bookings.tsx",
      lineNumber: 248,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "min-w-0 flex-1", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center gap-2", children: [
        /* @__PURE__ */ jsxDEV(Link, { to: `/space/${b.spaceId}`, className: "font-display font-bold text-ink hover:text-aqua-700", children: b.spaceName }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Bookings.tsx",
          lineNumber: 253,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: cn("rounded-full px-2.5 py-0.5 text-xs font-semibold", STATUS_STYLE[b.status]), children: t(`booking.status.${b.status}`) }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Bookings.tsx",
          lineNumber: 256,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Bookings.tsx",
        lineNumber: 252,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "mt-0.5 text-sm text-muted", children: [
        b.area ? `${b.area} · ` : "",
        t("booking.withPerson", { name: b.youAreOwner ? b.renterName : b.ownerName })
      ] }, void 0, true, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Bookings.tsx",
        lineNumber: 261,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("dl", { className: "mt-3 flex flex-wrap gap-x-5 gap-y-1 text-sm", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex gap-1.5", children: [
          /* @__PURE__ */ jsxDEV("dt", { className: "text-muted", children: t("booking.moveIn") }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Bookings.tsx",
            lineNumber: 268,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("dd", { className: "font-semibold text-ink", children: longDate(b.moveInDate) }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Bookings.tsx",
            lineNumber: 269,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Bookings.tsx",
          lineNumber: 267,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex gap-1.5", children: [
          /* @__PURE__ */ jsxDEV("dt", { className: "text-muted", children: t("booking.amount") }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Bookings.tsx",
            lineNumber: 272,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("dd", { className: "font-semibold tnum text-ink", children: money(b.amount) }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Bookings.tsx",
            lineNumber: 273,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Bookings.tsx",
          lineNumber: 271,
          columnNumber: 13
        }, this),
        b.months > 1 && /* @__PURE__ */ jsxDEV("div", { className: "flex gap-1.5", children: [
          /* @__PURE__ */ jsxDEV("dt", { className: "text-muted", children: t("booking.scheduled") }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Bookings.tsx",
            lineNumber: 277,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("dd", { className: "font-semibold tnum text-ink", children: t("booking.monthsCount", { count: b.months }) }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Bookings.tsx",
            lineNumber: 278,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Bookings.tsx",
          lineNumber: 276,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Bookings.tsx",
        lineNumber: 266,
        columnNumber: 11
      }, this),
      b.message && /* @__PURE__ */ jsxDEV("p", { className: "mt-3 rounded-xl bg-ivory p-3 text-sm leading-relaxed text-ink-soft", children: b.message }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Bookings.tsx",
        lineNumber: 286,
        columnNumber: 11
      }, this),
      b.declineReason && /* @__PURE__ */ jsxDEV("p", { className: "mt-3 rounded-xl bg-danger-100 p-3 text-sm leading-relaxed text-danger-600", children: b.declineReason }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Bookings.tsx",
        lineNumber: 290,
        columnNumber: 11
      }, this),
      b.phoneShared ? /* @__PURE__ */ jsxDEV("p", { className: "mt-3 inline-flex items-center gap-2 rounded-xl bg-ok-100 px-3 py-2 text-sm font-semibold text-ok-600", children: [
        /* @__PURE__ */ jsxDEV(Phone, { size: 14, "aria-hidden": true }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Bookings.tsx",
          lineNumber: 298,
          columnNumber: 15
        }, this),
        b.youAreOwner ? b.renterPhone : b.ownerPhone,
        /* @__PURE__ */ jsxDEV("span", { className: "font-normal opacity-80", children: t("booking.phoneNow", { name: b.youAreOwner ? b.renterName : b.ownerName }) }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Bookings.tsx",
          lineNumber: 300,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Bookings.tsx",
        lineNumber: 297,
        columnNumber: 11
      }, this) : b.status === "requested" && /* @__PURE__ */ jsxDEV("p", { className: "mt-3 inline-flex items-center gap-2 text-xs text-muted", children: [
        /* @__PURE__ */ jsxDEV(Clock, { size: 13, "aria-hidden": true }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Bookings.tsx",
          lineNumber: 307,
          columnNumber: 17
        }, this),
        t("booking.phoneLater")
      ] }, void 0, true, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Bookings.tsx",
        lineNumber: 306,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mt-4 flex flex-wrap gap-2", children: [
        b.youAreOwner && b.status === "requested" && /* @__PURE__ */ jsxDEV(Fragment, { children: [
          /* @__PURE__ */ jsxDEV(Button, { size: "sm", disabled: busy, onClick: () => onMove(b, "accepted"), children: [
            /* @__PURE__ */ jsxDEV(Check, { size: 15, "aria-hidden": true }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Bookings.tsx",
              lineNumber: 318,
              columnNumber: 19
            }, this),
            t("booking.accept")
          ] }, void 0, true, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Bookings.tsx",
            lineNumber: 317,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Button, { size: "sm", variant: "secondary", disabled: busy, onClick: onDecline, children: [
            /* @__PURE__ */ jsxDEV(X, { size: 15, "aria-hidden": true }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Bookings.tsx",
              lineNumber: 322,
              columnNumber: 19
            }, this),
            t("booking.decline")
          ] }, void 0, true, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Bookings.tsx",
            lineNumber: 321,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Bookings.tsx",
          lineNumber: 316,
          columnNumber: 13
        }, this),
        b.youAreOwner && b.status === "accepted" && /* @__PURE__ */ jsxDEV(Button, { size: "sm", disabled: busy, onClick: onConfirm, children: [
          /* @__PURE__ */ jsxDEV(Check, { size: 15, "aria-hidden": true }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Bookings.tsx",
            lineNumber: 330,
            columnNumber: 17
          }, this),
          t("booking.confirm")
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Bookings.tsx",
          lineNumber: 329,
          columnNumber: 13
        }, this),
        b.youAreOwner && b.status === "confirmed" && /* @__PURE__ */ jsxDEV(Button, { size: "sm", disabled: busy, onClick: () => onMove(b, "completed"), children: t("booking.complete") }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Bookings.tsx",
          lineNumber: 336,
          columnNumber: 13
        }, this),
        ["requested", "accepted", "confirmed"].includes(b.status) && /* @__PURE__ */ jsxDEV(Button, { size: "sm", variant: "ghost", disabled: busy, onClick: () => onMove(b, "cancelled"), children: [
          /* @__PURE__ */ jsxDEV(Ban, { size: 15, "aria-hidden": true }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Bookings.tsx",
            lineNumber: 343,
            columnNumber: 17
          }, this),
          t("booking.cancel")
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Bookings.tsx",
          lineNumber: 342,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Bookings.tsx",
        lineNumber: 314,
        columnNumber: 11
      }, this),
      b.status === "accepted" && /* @__PURE__ */ jsxDEV("p", { className: "mt-3 text-xs leading-relaxed text-muted", children: t("booking.acceptedNote") }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Bookings.tsx",
        lineNumber: 350,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Bookings.tsx",
      lineNumber: 251,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Bookings.tsx",
    lineNumber: 244,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Bookings.tsx",
    lineNumber: 243,
    columnNumber: 5
  }, this);
}
_s2(BookingCard, "82N5KF9nLzZ6+2WH7KIjzIXRkLw=", false, function() {
  return [useI18n];
});
_c2 = BookingCard;
var _c, _c2;
$RefreshReg$(_c, "Bookings");
$RefreshReg$(_c2, "BookingCard");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/I2I Project - Habito/App Folder/habito/src/pages/Bookings.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/I2I Project - Habito/App Folder/habito/src/pages/Bookings.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNkVJLG1CQUNFLGNBREY7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBN0VKLFNBQVNBLGFBQWFDLFdBQVdDLGdCQUFnQjtBQUNqRCxTQUFTQyxZQUFZO0FBQ3JCLFNBQVNDLGVBQWVDLE9BQU9DLE9BQU9DLEdBQUdDLE9BQU9DLFdBQVc7QUFDM0QsU0FBU0MsVUFBVTtBQUNuQixTQUFTQyxlQUFlO0FBQ3hCLFNBQVNDLGtCQUFrQjtBQUMzQixTQUFTQyxjQUFjO0FBQ3ZCLFNBQVNDLGFBQWE7QUFDdEIsU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxPQUFPQyxnQkFBZ0I7QUFFaEMsU0FBU0MsVUFBVTtBQVNuQixNQUFNQyxlQUE4QztBQUFBLEVBQ2xEQyxXQUFXO0FBQUEsRUFDWEMsVUFBVTtBQUFBLEVBQ1YsbUJBQW1CO0FBQUEsRUFDbkJDLFdBQVc7QUFBQSxFQUNYQyxXQUFXO0FBQUEsRUFDWEMsVUFBVTtBQUFBLEVBQ1ZDLFdBQVc7QUFBQSxFQUNYLGtCQUFrQjtBQUNwQjtBQUVBLHdCQUF3QkMsV0FBVztBQUFBQyxLQUFBO0FBQ2pDLFFBQU0sRUFBRUMsRUFBRSxJQUFJbEIsUUFBUTtBQUN0QixRQUFNLEVBQUVtQixPQUFPLElBQUlkLFNBQVM7QUFFNUIsUUFBTSxDQUFDZSxVQUFVQyxXQUFXLElBQUk5QixTQUEyQixJQUFJO0FBQy9ELFFBQU0sQ0FBQytCLE1BQU1DLE9BQU8sSUFBSWhDLFNBQXdCLElBQUk7QUFDcEQsUUFBTSxDQUFDaUMsV0FBV0MsWUFBWSxJQUFJbEMsU0FBeUIsSUFBSTtBQUMvRCxRQUFNLENBQUNtQyxZQUFZQyxhQUFhLElBQUlwQyxTQUF5QixJQUFJO0FBQ2pFLFFBQU0sQ0FBQ3FDLFFBQVFDLFNBQVMsSUFBSXRDLFNBQVMsRUFBRTtBQUV2QyxRQUFNdUMsT0FBT3pDLFlBQVksWUFBWTtBQUNuQyxRQUFJO0FBQ0ZnQyxrQkFBWSxNQUFNdEIsR0FBR3FCLFNBQVMsQ0FBQztBQUFBLElBQ2pDLFFBQVE7QUFDTkMsa0JBQVksRUFBRTtBQUFBLElBQ2hCO0FBQUEsRUFDRixHQUFHLEVBQUU7QUFFTC9CLFlBQVUsTUFBTTtBQUNkLFNBQUt3QyxLQUFLO0FBQUEsRUFDWixHQUFHLENBQUNBLElBQUksQ0FBQztBQUVULFFBQU1DLE9BQU8sT0FBT0MsU0FBa0JDLFFBQXVCQyxRQUFpQjtBQUM1RVgsWUFBUVMsUUFBUUcsRUFBRTtBQUNsQixRQUFJO0FBQ0YsWUFBTXBDLEdBQUdxQyxpQkFBaUJKLFFBQVFHLElBQUlGLFFBQVFDLEdBQUc7QUFDakQsWUFBTUosS0FBSztBQUNYWCxhQUFPRCxFQUFFLGlCQUFpQmUsTUFBTSxFQUFXLENBQUM7QUFBQSxJQUM5QyxTQUFTSSxHQUFHO0FBQ1ZsQixhQUFPa0IsYUFBYUMsUUFBUUQsRUFBRUUsVUFBVXJCLEVBQUUsbUJBQW1CLENBQUM7QUFBQSxJQUNoRSxVQUFDO0FBQ0NLLGNBQVEsSUFBSTtBQUNaRSxtQkFBYSxJQUFJO0FBQ2pCSSxnQkFBVSxFQUFFO0FBQUEsSUFDZDtBQUFBLEVBQ0Y7QUFFQSxRQUFNVyxRQUFRcEIsWUFBWSxJQUFJcUI7QUFBQUEsSUFDNUIsQ0FBQ0MsTUFBTSxDQUFDLENBQUMsYUFBYSxZQUFZLFdBQVcsRUFBRUMsU0FBU0QsRUFBRVQsTUFBTTtBQUFBLEVBQ2xFO0FBQ0EsUUFBTVcsUUFBUXhCLFlBQVksSUFBSXFCO0FBQUFBLElBQU8sQ0FBQ0MsTUFDcEMsQ0FBQyxhQUFhLFlBQVksV0FBVyxFQUFFQyxTQUFTRCxFQUFFVCxNQUFNO0FBQUEsRUFDMUQ7QUFFQSxTQUNFLG1DQUNFO0FBQUEsMkJBQUMsY0FBVyxPQUFPZixFQUFFLGVBQWUsR0FBRyxNQUFNQSxFQUFFLGNBQWMsS0FBN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUErRDtBQUFBLElBRS9ELHVCQUFDLFNBQUksV0FBVSwwQ0FDWkUsdUJBQWEsT0FDWix1QkFBQyxTQUFJLFdBQVUsYUFDWixXQUFDLEdBQUcsQ0FBQyxFQUFFeUI7QUFBQUEsTUFBSSxDQUFDQyxNQUNYLHVCQUFDLFlBQWlCLFdBQVUsOEJBQWJBLEdBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFzRDtBQUFBLElBQ3ZELEtBSEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUlBLElBQ0UxQixTQUFTMkIsV0FBVyxJQUN0Qix1QkFBQyxTQUFJLFdBQVUsa0dBQ2I7QUFBQSw2QkFBQyxVQUFLLFdBQVUsd0ZBQ2QsaUNBQUMsaUJBQWMsTUFBTSxJQUFJLGVBQVcsUUFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFvQyxLQUR0QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLFFBQUcsV0FBVSwyQ0FBMkM3QixZQUFFLGNBQWMsS0FBekU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEyRTtBQUFBLE1BQzNFLHVCQUFDLE9BQUUsV0FBVSxvQ0FBb0NBLFlBQUUsa0JBQWtCLEtBQXJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBdUU7QUFBQSxNQUN2RSx1QkFBQyxRQUFLLElBQUcsV0FBVSxXQUFVLFFBQzNCLGlDQUFDLFVBQVFBLFlBQUUscUJBQXFCLEtBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBa0MsS0FEcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0FSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBU0EsSUFFQSx1QkFBQyxTQUFJLFdBQVUsYUFDWnNCO0FBQUFBLFdBQUtPLFNBQVMsS0FDYix1QkFBQyxhQUNDO0FBQUEsK0JBQUMsUUFBRyxXQUFVLGdEQUFnRDdCLFlBQUUsZ0JBQWdCLEtBQWhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0Y7QUFBQSxRQUNsRix1QkFBQyxRQUFHLFdBQVUsYUFDWHNCLGVBQUtLO0FBQUFBLFVBQUksQ0FBQ0gsTUFDVCx1QkFBQyxRQUNDO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxTQUFTQTtBQUFBQSxjQUNULE1BQU1wQixTQUFTb0IsRUFBRVA7QUFBQUEsY0FDakIsUUFBUUo7QUFBQUEsY0FDUixXQUFXLE1BQU1OLGFBQWFpQixDQUFDO0FBQUEsY0FDL0IsV0FBVyxNQUFNZixjQUFjZSxDQUFDO0FBQUE7QUFBQSxZQUxsQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLb0MsS0FON0JBLEVBQUVQLElBQVg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFRQTtBQUFBLFFBQ0QsS0FYSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBWUE7QUFBQSxXQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFlQTtBQUFBLE1BR0RTLEtBQUtHLFNBQVMsS0FDYix1QkFBQyxhQUNDO0FBQUEsK0JBQUMsUUFBRyxXQUFVLGdEQUFnRDdCLFlBQUUsY0FBYyxLQUE5RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWdGO0FBQUEsUUFDaEYsdUJBQUMsUUFBRyxXQUFVLGFBQ1gwQixlQUFLQztBQUFBQSxVQUFJLENBQUNILE1BQ1QsdUJBQUMsUUFDQztBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsU0FBU0E7QUFBQUEsY0FDVCxNQUFNO0FBQUEsY0FDTixRQUFRWDtBQUFBQSxjQUNSLFdBQVcsTUFBTTtBQUFBLGNBQUM7QUFBQSxjQUNsQixXQUFXLE1BQU07QUFBQSxjQUFDO0FBQUE7QUFBQSxZQUxwQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLc0IsS0FOZlcsRUFBRVAsSUFBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVFBO0FBQUEsUUFDRCxLQVhIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFZQTtBQUFBLFdBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWVBO0FBQUEsU0FwQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXNDQSxLQXpESjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBMkRBO0FBQUEsSUFFQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsTUFBTVQsZUFBZTtBQUFBLFFBQ3JCLFNBQVMsTUFBTUMsY0FBYyxJQUFJO0FBQUEsUUFDakMsT0FBT1QsRUFBRSxzQkFBc0I7QUFBQSxRQUMvQixRQUNFLHVCQUFDLFNBQUksV0FBVSxjQUNiO0FBQUEsaUNBQUMsVUFBTyxTQUFRLGFBQVksV0FBUyxNQUFDLFNBQVMsTUFBTVMsY0FBYyxJQUFJLEdBQ3BFVCxZQUFFLGVBQWUsS0FEcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDO0FBQUEsY0FDQSxTQUFTLE1BQU07QUFDYixzQkFBTThCLFNBQVN0QjtBQUNmQyw4QkFBYyxJQUFJO0FBQ2xCLG9CQUFJcUIsT0FBUSxNQUFLakIsS0FBS2lCLFFBQVEsV0FBVztBQUFBLGNBQzNDO0FBQUEsY0FFQzlCLFlBQUUsaUJBQWlCO0FBQUE7QUFBQSxZQVJ0QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFTQTtBQUFBLGFBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWNBO0FBQUEsUUFHRjtBQUFBLGlDQUFDLE9BQUUsV0FBVSx5Q0FBeUNBLFlBQUUscUJBQXFCLEtBQTdFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQStFO0FBQUEsVUFDL0UsdUJBQUMsT0FBRSxXQUFVLHlFQUNWQSxZQUFFLHdCQUF3QixLQUQ3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUE7QUFBQTtBQUFBLE1BekJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQTBCQTtBQUFBLElBRUE7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLE1BQU1NLGNBQWM7QUFBQSxRQUNwQixTQUFTLE1BQU1DLGFBQWEsSUFBSTtBQUFBLFFBQ2hDLE9BQU9QLEVBQUUsc0JBQXNCO0FBQUEsUUFDL0IsUUFDRSx1QkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLGlDQUFDLFVBQU8sU0FBUSxhQUFZLFdBQVMsTUFBQyxTQUFTLE1BQU1PLGFBQWEsSUFBSSxHQUNuRVAsWUFBRSxlQUFlLEtBRHBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxTQUFRO0FBQUEsY0FDUjtBQUFBLGNBQ0EsU0FBUyxNQUFNTSxhQUFhLEtBQUtPLEtBQUtQLFdBQVcsWUFBWUksT0FBT3FCLEtBQUssS0FBS0MsTUFBUztBQUFBLGNBRXRGaEMsWUFBRSxpQkFBaUI7QUFBQTtBQUFBLFlBTHRCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU1BO0FBQUEsYUFWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBV0E7QUFBQSxRQUdGO0FBQUEsaUNBQUMsT0FBRSxXQUFVLHlDQUF5Q0EsWUFBRSxxQkFBcUIsS0FBN0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBK0U7QUFBQSxVQUMvRSx1QkFBQyxXQUFNLFdBQVUsY0FDZjtBQUFBLG1DQUFDLFVBQUssV0FBVSxrREFDYkEsWUFBRSx1QkFBdUIsS0FENUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFNO0FBQUEsZ0JBQ04sT0FBT1U7QUFBQUEsZ0JBQ1AsVUFBVSxDQUFDUyxNQUFNUixVQUFVUSxFQUFFVyxPQUFPRyxLQUFLO0FBQUEsZ0JBQ3pDLGFBQWFqQyxFQUFFLHFCQUFxQjtBQUFBLGdCQUNwQyxXQUFVO0FBQUE7QUFBQSxjQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUs2STtBQUFBLGVBVC9JO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBV0E7QUFBQTtBQUFBO0FBQUEsTUEvQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBZ0NBO0FBQUEsT0E1SEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTZIQTtBQUVKO0FBQUNELEdBNUt1QkQsVUFBUTtBQUFBLFVBQ2hCaEIsU0FDS0ssUUFBUTtBQUFBO0FBQUEsS0FGTFc7QUE4S3hCLFNBQVNvQyxZQUFZO0FBQUEsRUFDbkJwQjtBQUFBQSxFQUNBVjtBQUFBQSxFQUNBK0I7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFPRixHQUFHO0FBQUFDLE1BQUE7QUFDRCxRQUFNLEVBQUV0QyxFQUFFLElBQUlsQixRQUFRO0FBQ3RCLFFBQU0wQyxJQUFJVjtBQUVWLFNBQ0UsdUJBQUMsYUFBUSxXQUFVLDJEQUNqQixpQ0FBQyxTQUFJLFdBQVUsY0FDWlU7QUFBQUEsTUFBRWUsYUFDRCx1QkFBQyxTQUFJLEtBQUtmLEVBQUVlLFlBQVksS0FBSSxJQUFHLFdBQVUsOENBQXpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBbUYsSUFFbkYsdUJBQUMsVUFBSyxXQUFVLDZDQUE0QyxlQUFXLFFBQXZFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBdUU7QUFBQSxJQUd6RSx1QkFBQyxTQUFJLFdBQVUsa0JBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUscUNBQ2I7QUFBQSwrQkFBQyxRQUFLLElBQUksVUFBVWYsRUFBRWdCLE9BQU8sSUFBSSxXQUFVLHVEQUN4Q2hCLFlBQUVpQixhQURMO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsVUFBSyxXQUFXbkQsR0FBRyxvREFBb0RDLGFBQWFpQyxFQUFFVCxNQUFNLENBQUMsR0FDM0ZmLFlBQUUsa0JBQWtCd0IsRUFBRVQsTUFBTSxFQUFXLEtBRDFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU9BO0FBQUEsTUFFQSx1QkFBQyxPQUFFLFdBQVUsNkJBQ1ZTO0FBQUFBLFVBQUVrQixPQUFPLEdBQUdsQixFQUFFa0IsSUFBSSxRQUFRO0FBQUEsUUFDMUIxQyxFQUFFLHNCQUFzQixFQUFFMkMsTUFBTW5CLEVBQUVvQixjQUFjcEIsRUFBRXFCLGFBQWFyQixFQUFFc0IsVUFBVSxDQUFDO0FBQUEsV0FGL0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFFQSx1QkFBQyxRQUFHLFdBQVUsK0NBQ1o7QUFBQSwrQkFBQyxTQUFJLFdBQVUsZ0JBQ2I7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsY0FBYzlDLFlBQUUsZ0JBQWdCLEtBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWdEO0FBQUEsVUFDaEQsdUJBQUMsUUFBRyxXQUFVLDBCQUEwQlgsbUJBQVNtQyxFQUFFdUIsVUFBVSxLQUE3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUErRDtBQUFBLGFBRmpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLGdCQUNiO0FBQUEsaUNBQUMsUUFBRyxXQUFVLGNBQWMvQyxZQUFFLGdCQUFnQixLQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFnRDtBQUFBLFVBQ2hELHVCQUFDLFFBQUcsV0FBVSwrQkFBK0JaLGdCQUFNb0MsRUFBRXdCLE1BQU0sS0FBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNkQ7QUFBQSxhQUYvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUNDeEIsRUFBRXlCLFNBQVMsS0FDVix1QkFBQyxTQUFJLFdBQVUsZ0JBQ2I7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsY0FBY2pELFlBQUUsbUJBQW1CLEtBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1EO0FBQUEsVUFDbkQsdUJBQUMsUUFBRyxXQUFVLCtCQUNYQSxZQUFFLHVCQUF1QixFQUFFa0QsT0FBTzFCLEVBQUV5QixPQUFPLENBQUMsS0FEL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUtBO0FBQUEsV0FmSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBaUJBO0FBQUEsTUFFQ3pCLEVBQUVILFdBQ0QsdUJBQUMsT0FBRSxXQUFVLHNFQUFzRUcsWUFBRUgsV0FBckY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE2RjtBQUFBLE1BRzlGRyxFQUFFMkIsaUJBQ0QsdUJBQUMsT0FBRSxXQUFVLDZFQUNWM0IsWUFBRTJCLGlCQURMO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BSUQzQixFQUFFNEIsY0FDRCx1QkFBQyxPQUFFLFdBQVUsd0dBQ1g7QUFBQSwrQkFBQyxTQUFNLE1BQU0sSUFBSSxlQUFXLFFBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNEI7QUFBQSxRQUMzQjVCLEVBQUVvQixjQUFjcEIsRUFBRTZCLGNBQWM3QixFQUFFOEI7QUFBQUEsUUFDbkMsdUJBQUMsVUFBSyxXQUFVLDBCQUNidEQsWUFBRSxvQkFBb0IsRUFBRTJDLE1BQU1uQixFQUFFb0IsY0FBY3BCLEVBQUVxQixhQUFhckIsRUFBRXNCLFVBQVUsQ0FBQyxLQUQ3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFNQSxJQUVBdEIsRUFBRVQsV0FBVyxlQUNYLHVCQUFDLE9BQUUsV0FBVSwwREFDWDtBQUFBLCtCQUFDLFNBQU0sTUFBTSxJQUFJLGVBQVcsUUFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE0QjtBQUFBLFFBQzNCZixFQUFFLG9CQUFvQjtBQUFBLFdBRnpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BS0osdUJBQUMsU0FBSSxXQUFVLDZCQUNad0I7QUFBQUEsVUFBRW9CLGVBQWVwQixFQUFFVCxXQUFXLGVBQzdCLG1DQUNFO0FBQUEsaUNBQUMsVUFBTyxNQUFLLE1BQUssVUFBVVgsTUFBTSxTQUFTLE1BQU0rQixPQUFPWCxHQUFHLFVBQVUsR0FDbkU7QUFBQSxtQ0FBQyxTQUFNLE1BQU0sSUFBSSxlQUFXLFFBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTRCO0FBQUEsWUFDM0J4QixFQUFFLGdCQUFnQjtBQUFBLGVBRnJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUNBLHVCQUFDLFVBQU8sTUFBSyxNQUFLLFNBQVEsYUFBWSxVQUFVSSxNQUFNLFNBQVNnQyxXQUM3RDtBQUFBLG1DQUFDLEtBQUUsTUFBTSxJQUFJLGVBQVcsUUFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBd0I7QUFBQSxZQUN2QnBDLEVBQUUsaUJBQWlCO0FBQUEsZUFGdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLGFBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVNBO0FBQUEsUUFHRHdCLEVBQUVvQixlQUFlcEIsRUFBRVQsV0FBVyxjQUM3Qix1QkFBQyxVQUFPLE1BQUssTUFBSyxVQUFVWCxNQUFNLFNBQVNpQyxXQUN6QztBQUFBLGlDQUFDLFNBQU0sTUFBTSxJQUFJLGVBQVcsUUFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNEI7QUFBQSxVQUMzQnJDLEVBQUUsaUJBQWlCO0FBQUEsYUFGdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFHRHdCLEVBQUVvQixlQUFlcEIsRUFBRVQsV0FBVyxlQUM3Qix1QkFBQyxVQUFPLE1BQUssTUFBSyxVQUFVWCxNQUFNLFNBQVMsTUFBTStCLE9BQU9YLEdBQUcsV0FBVyxHQUNuRXhCLFlBQUUsa0JBQWtCLEtBRHZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBR0QsQ0FBQyxhQUFhLFlBQVksV0FBVyxFQUFFeUIsU0FBU0QsRUFBRVQsTUFBTSxLQUN2RCx1QkFBQyxVQUFPLE1BQUssTUFBSyxTQUFRLFNBQVEsVUFBVVgsTUFBTSxTQUFTLE1BQU0rQixPQUFPWCxHQUFHLFdBQVcsR0FDcEY7QUFBQSxpQ0FBQyxPQUFJLE1BQU0sSUFBSSxlQUFXLFFBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTBCO0FBQUEsVUFDekJ4QixFQUFFLGdCQUFnQjtBQUFBLGFBRnJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFdBL0JKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFpQ0E7QUFBQSxNQUVDd0IsRUFBRVQsV0FBVyxjQUNaLHVCQUFDLE9BQUUsV0FBVSwyQ0FBMkNmLFlBQUUsc0JBQXNCLEtBQWhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBa0Y7QUFBQSxTQW5HdEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXFHQTtBQUFBLE9BNUdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0E2R0EsS0E5R0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQStHQTtBQUVKO0FBQUNzQyxJQWxJUUosYUFBVztBQUFBLFVBYUpwRCxPQUFPO0FBQUE7QUFBQSxNQWJkb0Q7QUFBVyxJQUFBcUIsSUFBQUM7QUFBQSxhQUFBRCxJQUFBO0FBQUEsYUFBQUMsS0FBQSIsIm5hbWVzIjpbInVzZUNhbGxiYWNrIiwidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJMaW5rIiwiQ2FsZW5kYXJDaGVjayIsIlBob25lIiwiQ2hlY2siLCJYIiwiQ2xvY2siLCJCYW4iLCJkYiIsInVzZUkxOG4iLCJQYWdlSGVhZGVyIiwiQnV0dG9uIiwiTW9kYWwiLCJTa2VsZXRvbiIsInVzZVRvYXN0IiwibW9uZXkiLCJsb25nRGF0ZSIsImNuIiwiU1RBVFVTX1NUWUxFIiwicmVxdWVzdGVkIiwiYWNjZXB0ZWQiLCJjb25maXJtZWQiLCJjb21wbGV0ZWQiLCJyZWplY3RlZCIsImNhbmNlbGxlZCIsIkJvb2tpbmdzIiwiX3MiLCJ0Iiwibm90aWZ5IiwiYm9va2luZ3MiLCJzZXRCb29raW5ncyIsImJ1c3kiLCJzZXRCdXN5IiwiZGVjbGluaW5nIiwic2V0RGVjbGluaW5nIiwiY29uZmlybWluZyIsInNldENvbmZpcm1pbmciLCJyZWFzb24iLCJzZXRSZWFzb24iLCJsb2FkIiwibW92ZSIsImJvb2tpbmciLCJzdGF0dXMiLCJ3aHkiLCJpZCIsInNldEJvb2tpbmdTdGF0dXMiLCJlIiwiRXJyb3IiLCJtZXNzYWdlIiwibGl2ZSIsImZpbHRlciIsImIiLCJpbmNsdWRlcyIsInBhc3QiLCJtYXAiLCJpIiwibGVuZ3RoIiwidGFyZ2V0IiwidHJpbSIsInVuZGVmaW5lZCIsInZhbHVlIiwiQm9va2luZ0NhcmQiLCJvbk1vdmUiLCJvbkRlY2xpbmUiLCJvbkNvbmZpcm0iLCJfczIiLCJzcGFjZUltYWdlIiwic3BhY2VJZCIsInNwYWNlTmFtZSIsImFyZWEiLCJuYW1lIiwieW91QXJlT3duZXIiLCJyZW50ZXJOYW1lIiwib3duZXJOYW1lIiwibW92ZUluRGF0ZSIsImFtb3VudCIsIm1vbnRocyIsImNvdW50IiwiZGVjbGluZVJlYXNvbiIsInBob25lU2hhcmVkIiwicmVudGVyUGhvbmUiLCJvd25lclBob25lIiwiX2MiLCJfYzIiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQm9va2luZ3MudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUNhbGxiYWNrLCB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBMaW5rIH0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIjtcbmltcG9ydCB7IENhbGVuZGFyQ2hlY2ssIFBob25lLCBDaGVjaywgWCwgQ2xvY2ssIEJhbiB9IGZyb20gXCJsdWNpZGUtcmVhY3RcIjtcbmltcG9ydCB7IGRiIH0gZnJvbSBcIkAvbGliL2FwaVwiO1xuaW1wb3J0IHsgdXNlSTE4biB9IGZyb20gXCJAL2kxOG5cIjtcbmltcG9ydCB7IFBhZ2VIZWFkZXIgfSBmcm9tIFwiQC9jb21wb25lbnRzL2xheW91dC9QYWdlSGVhZGVyXCI7XG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tIFwiQC9jb21wb25lbnRzL3VpL0J1dHRvblwiO1xuaW1wb3J0IHsgTW9kYWwgfSBmcm9tIFwiQC9jb21wb25lbnRzL3VpL01vZGFsXCI7XG5pbXBvcnQgeyBTa2VsZXRvbiB9IGZyb20gXCJAL2NvbXBvbmVudHMvdWkvU2tlbGV0b25cIjtcbmltcG9ydCB7IHVzZVRvYXN0IH0gZnJvbSBcIkAvY29tcG9uZW50cy91aS9Ub2FzdFwiO1xuaW1wb3J0IHsgbW9uZXksIGxvbmdEYXRlIH0gZnJvbSBcIkAvbGliL2Zvcm1hdFwiO1xuaW1wb3J0IHR5cGUgeyBCb29raW5nLCBCb29raW5nU3RhdHVzIH0gZnJvbSBcIkAvdHlwZXMvc3BhY2VcIjtcbmltcG9ydCB7IGNuIH0gZnJvbSBcIkAvbGliL2NuXCI7XG5cbi8qKlxuICogQm9va2luZ3MsIGJvdGggc2lkZXMgaW4gb25lIHBsYWNlLlxuICpcbiAqIFdoaWNoIGJ1dHRvbnMgYXBwZWFyIGlzIGRlY2lkZWQgYnkgd2hvIHlvdSBhcmUgaW4gdGhlIGJvb2tpbmcgYW5kIHdoYXQgc3RhdGVcbiAqIGl0IGlzIGluIOKAlCBidXQgdGhlIGRhdGFiYXNlIGRlY2lkZXMgd2hhdCBpcyBhY3R1YWxseSBwZXJtaXR0ZWQsIHNvIGEgaGlkZGVuXG4gKiBidXR0b24gaXMgYSBjb3VydGVzeSByYXRoZXIgdGhhbiB0aGUgcHJvdGVjdGlvbi5cbiAqL1xuY29uc3QgU1RBVFVTX1NUWUxFOiBSZWNvcmQ8Qm9va2luZ1N0YXR1cywgc3RyaW5nPiA9IHtcbiAgcmVxdWVzdGVkOiBcImJnLWFxdWEtMTAwIHRleHQtYXF1YS03MDBcIixcbiAgYWNjZXB0ZWQ6IFwiYmctb2stMTAwIHRleHQtb2stNjAwXCIsXG4gIFwicGF5bWVudC1wZW5kaW5nXCI6IFwiYmctc3VuLzQ1IHRleHQtc3VuLWlua1wiLFxuICBjb25maXJtZWQ6IFwiYmctb2stMTAwIHRleHQtb2stNjAwXCIsXG4gIGNvbXBsZXRlZDogXCJiZy1pdm9yeS1kZWVwIHRleHQtbXV0ZWRcIixcbiAgcmVqZWN0ZWQ6IFwiYmctZGFuZ2VyLTEwMCB0ZXh0LWRhbmdlci02MDBcIixcbiAgY2FuY2VsbGVkOiBcImJnLWl2b3J5LWRlZXAgdGV4dC1tdXRlZFwiLFxuICBcInBheW1lbnQtZmFpbGVkXCI6IFwiYmctZGFuZ2VyLTEwMCB0ZXh0LWRhbmdlci02MDBcIixcbn07XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEJvb2tpbmdzKCkge1xuICBjb25zdCB7IHQgfSA9IHVzZUkxOG4oKTtcbiAgY29uc3QgeyBub3RpZnkgfSA9IHVzZVRvYXN0KCk7XG5cbiAgY29uc3QgW2Jvb2tpbmdzLCBzZXRCb29raW5nc10gPSB1c2VTdGF0ZTxCb29raW5nW10gfCBudWxsPihudWxsKTtcbiAgY29uc3QgW2J1c3ksIHNldEJ1c3ldID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IFtkZWNsaW5pbmcsIHNldERlY2xpbmluZ10gPSB1c2VTdGF0ZTxCb29raW5nIHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IFtjb25maXJtaW5nLCBzZXRDb25maXJtaW5nXSA9IHVzZVN0YXRlPEJvb2tpbmcgfCBudWxsPihudWxsKTtcbiAgY29uc3QgW3JlYXNvbiwgc2V0UmVhc29uXSA9IHVzZVN0YXRlKFwiXCIpO1xuXG4gIGNvbnN0IGxvYWQgPSB1c2VDYWxsYmFjayhhc3luYyAoKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIHNldEJvb2tpbmdzKGF3YWl0IGRiLmJvb2tpbmdzKCkpO1xuICAgIH0gY2F0Y2gge1xuICAgICAgc2V0Qm9va2luZ3MoW10pO1xuICAgIH1cbiAgfSwgW10pO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgdm9pZCBsb2FkKCk7XG4gIH0sIFtsb2FkXSk7XG5cbiAgY29uc3QgbW92ZSA9IGFzeW5jIChib29raW5nOiBCb29raW5nLCBzdGF0dXM6IEJvb2tpbmdTdGF0dXMsIHdoeT86IHN0cmluZykgPT4ge1xuICAgIHNldEJ1c3koYm9va2luZy5pZCk7XG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IGRiLnNldEJvb2tpbmdTdGF0dXMoYm9va2luZy5pZCwgc3RhdHVzLCB3aHkpO1xuICAgICAgYXdhaXQgbG9hZCgpO1xuICAgICAgbm90aWZ5KHQoYGJvb2tpbmcubW92ZWQuJHtzdGF0dXN9YCBhcyBuZXZlcikpO1xuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIG5vdGlmeShlIGluc3RhbmNlb2YgRXJyb3IgPyBlLm1lc3NhZ2UgOiB0KFwiYXV0aC5lcnJvckdlbmVyaWNcIikpO1xuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRCdXN5KG51bGwpO1xuICAgICAgc2V0RGVjbGluaW5nKG51bGwpO1xuICAgICAgc2V0UmVhc29uKFwiXCIpO1xuICAgIH1cbiAgfTtcblxuICBjb25zdCBsaXZlID0gKGJvb2tpbmdzID8/IFtdKS5maWx0ZXIoXG4gICAgKGIpID0+ICFbXCJjb21wbGV0ZWRcIiwgXCJyZWplY3RlZFwiLCBcImNhbmNlbGxlZFwiXS5pbmNsdWRlcyhiLnN0YXR1cyksXG4gICk7XG4gIGNvbnN0IHBhc3QgPSAoYm9va2luZ3MgPz8gW10pLmZpbHRlcigoYikgPT5cbiAgICBbXCJjb21wbGV0ZWRcIiwgXCJyZWplY3RlZFwiLCBcImNhbmNlbGxlZFwiXS5pbmNsdWRlcyhiLnN0YXR1cyksXG4gICk7XG5cbiAgcmV0dXJuIChcbiAgICA8PlxuICAgICAgPFBhZ2VIZWFkZXIgdGl0bGU9e3QoXCJib29raW5nLnRpdGxlXCIpfSBsZWFkPXt0KFwiYm9va2luZy5sZWFkXCIpfSAvPlxuXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbnRhaW5lci1wYWdlIG1heC13LTN4bCBweS02IG1kOnB5LTEwXCI+XG4gICAgICAgIHtib29raW5ncyA9PT0gbnVsbCA/IChcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktM1wiPlxuICAgICAgICAgICAge1swLCAxXS5tYXAoKGkpID0+IChcbiAgICAgICAgICAgICAgPFNrZWxldG9uIGtleT17aX0gY2xhc3NOYW1lPVwiaC00MCB3LWZ1bGwgcm91bmRlZC1jYXJkXCIgLz5cbiAgICAgICAgICAgICkpfVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICApIDogYm9va2luZ3MubGVuZ3RoID09PSAwID8gKFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIgcm91bmRlZC1jYXJkIGJnLXN1cmZhY2UgcHgtNiBweS0xNiB0ZXh0LWNlbnRlciByaW5nLTEgcmluZy1oYWlybGluZVwiPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWItNCBmbGV4IHNpemUtMTIgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHJvdW5kZWQtZnVsbCBiZy1hcXVhLTEwMCB0ZXh0LWFxdWEtNzAwXCI+XG4gICAgICAgICAgICAgIDxDYWxlbmRhckNoZWNrIHNpemU9ezIyfSBhcmlhLWhpZGRlbiAvPlxuICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cImZvbnQtZGlzcGxheSB0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LWlua1wiPnt0KFwiYm9va2luZy5ub25lXCIpfTwvaDI+XG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIG1heC13LXNtIHRleHQtc20gdGV4dC1tdXRlZFwiPnt0KFwiYm9va2luZy5ub25lQm9keVwiKX08L3A+XG4gICAgICAgICAgICA8TGluayB0bz1cIi9zZWFyY2hcIiBjbGFzc05hbWU9XCJtdC01XCI+XG4gICAgICAgICAgICAgIDxCdXR0b24+e3QoXCJhY3Rpb24uYnJvd3NlU3BhY2VzXCIpfTwvQnV0dG9uPlxuICAgICAgICAgICAgPC9MaW5rPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICApIDogKFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS02XCI+XG4gICAgICAgICAgICB7bGl2ZS5sZW5ndGggPiAwICYmIChcbiAgICAgICAgICAgICAgPHNlY3Rpb24+XG4gICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cIm1iLTMgZm9udC1kaXNwbGF5IHRleHQtbGcgZm9udC1ib2xkIHRleHQtaW5rXCI+e3QoXCJib29raW5nLmFjdGl2ZVwiKX08L2gyPlxuICAgICAgICAgICAgICAgIDx1bCBjbGFzc05hbWU9XCJzcGFjZS15LTNcIj5cbiAgICAgICAgICAgICAgICAgIHtsaXZlLm1hcCgoYikgPT4gKFxuICAgICAgICAgICAgICAgICAgICA8bGkga2V5PXtiLmlkfT5cbiAgICAgICAgICAgICAgICAgICAgICA8Qm9va2luZ0NhcmRcbiAgICAgICAgICAgICAgICAgICAgICAgIGJvb2tpbmc9e2J9XG4gICAgICAgICAgICAgICAgICAgICAgICBidXN5PXtidXN5ID09PSBiLmlkfVxuICAgICAgICAgICAgICAgICAgICAgICAgb25Nb3ZlPXttb3ZlfVxuICAgICAgICAgICAgICAgICAgICAgICAgb25EZWNsaW5lPXsoKSA9PiBzZXREZWNsaW5pbmcoYil9XG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNvbmZpcm09eygpID0+IHNldENvbmZpcm1pbmcoYil9XG4gICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgIDwvdWw+XG4gICAgICAgICAgICAgIDwvc2VjdGlvbj5cbiAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgIHtwYXN0Lmxlbmd0aCA+IDAgJiYgKFxuICAgICAgICAgICAgICA8c2VjdGlvbj5cbiAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwibWItMyBmb250LWRpc3BsYXkgdGV4dC1sZyBmb250LWJvbGQgdGV4dC1pbmtcIj57dChcImJvb2tpbmcucGFzdFwiKX08L2gyPlxuICAgICAgICAgICAgICAgIDx1bCBjbGFzc05hbWU9XCJzcGFjZS15LTNcIj5cbiAgICAgICAgICAgICAgICAgIHtwYXN0Lm1hcCgoYikgPT4gKFxuICAgICAgICAgICAgICAgICAgICA8bGkga2V5PXtiLmlkfT5cbiAgICAgICAgICAgICAgICAgICAgICA8Qm9va2luZ0NhcmRcbiAgICAgICAgICAgICAgICAgICAgICAgIGJvb2tpbmc9e2J9XG4gICAgICAgICAgICAgICAgICAgICAgICBidXN5PXtmYWxzZX1cbiAgICAgICAgICAgICAgICAgICAgICAgIG9uTW92ZT17bW92ZX1cbiAgICAgICAgICAgICAgICAgICAgICAgIG9uRGVjbGluZT17KCkgPT4ge319XG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNvbmZpcm09eygpID0+IHt9fVxuICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgIDwvbGk+XG4gICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICA8L3VsPlxuICAgICAgICAgICAgICA8L3NlY3Rpb24+XG4gICAgICAgICAgICApfVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICApfVxuICAgICAgPC9kaXY+XG5cbiAgICAgIDxNb2RhbFxuICAgICAgICBvcGVuPXtjb25maXJtaW5nICE9PSBudWxsfVxuICAgICAgICBvbkNsb3NlPXsoKSA9PiBzZXRDb25maXJtaW5nKG51bGwpfVxuICAgICAgICB0aXRsZT17dChcImJvb2tpbmcuY29uZmlybVRpdGxlXCIpfVxuICAgICAgICBmb290ZXI9e1xuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtMlwiPlxuICAgICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwic2Vjb25kYXJ5XCIgZnVsbFdpZHRoIG9uQ2xpY2s9eygpID0+IHNldENvbmZpcm1pbmcobnVsbCl9PlxuICAgICAgICAgICAgICB7dChcImFjdGlvbi5jYW5jZWxcIil9XG4gICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgICAgZnVsbFdpZHRoXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCB0YXJnZXQgPSBjb25maXJtaW5nO1xuICAgICAgICAgICAgICAgIHNldENvbmZpcm1pbmcobnVsbCk7XG4gICAgICAgICAgICAgICAgaWYgKHRhcmdldCkgdm9pZCBtb3ZlKHRhcmdldCwgXCJjb25maXJtZWRcIik7XG4gICAgICAgICAgICAgIH19XG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIHt0KFwiYm9va2luZy5jb25maXJtXCIpfVxuICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIH1cbiAgICAgID5cbiAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBsZWFkaW5nLXJlbGF4ZWQgdGV4dC1pbmstc29mdFwiPnt0KFwiYm9va2luZy5jb25maXJtQm9keVwiKX08L3A+XG4gICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTMgcm91bmRlZC14bCBiZy13YXJuLTEwMCBwLTMgdGV4dC1zbSBsZWFkaW5nLXJlbGF4ZWQgdGV4dC13YXJuLTcwMFwiPlxuICAgICAgICAgIHt0KFwiYm9va2luZy5jb25maXJtV2FybmluZ1wiKX1cbiAgICAgICAgPC9wPlxuICAgICAgPC9Nb2RhbD5cblxuICAgICAgPE1vZGFsXG4gICAgICAgIG9wZW49e2RlY2xpbmluZyAhPT0gbnVsbH1cbiAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0RGVjbGluaW5nKG51bGwpfVxuICAgICAgICB0aXRsZT17dChcImJvb2tpbmcuZGVjbGluZVRpdGxlXCIpfVxuICAgICAgICBmb290ZXI9e1xuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtMlwiPlxuICAgICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwic2Vjb25kYXJ5XCIgZnVsbFdpZHRoIG9uQ2xpY2s9eygpID0+IHNldERlY2xpbmluZyhudWxsKX0+XG4gICAgICAgICAgICAgIHt0KFwiYWN0aW9uLmNhbmNlbFwiKX1cbiAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgICB2YXJpYW50PVwiZGVzdHJ1Y3RpdmVcIlxuICAgICAgICAgICAgICBmdWxsV2lkdGhcbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gZGVjbGluaW5nICYmIHZvaWQgbW92ZShkZWNsaW5pbmcsIFwicmVqZWN0ZWRcIiwgcmVhc29uLnRyaW0oKSB8fCB1bmRlZmluZWQpfVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICB7dChcImJvb2tpbmcuZGVjbGluZVwiKX1cbiAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICB9XG4gICAgICA+XG4gICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gbGVhZGluZy1yZWxheGVkIHRleHQtaW5rLXNvZnRcIj57dChcImJvb2tpbmcuZGVjbGluZUJvZHlcIil9PC9wPlxuICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwibXQtNCBibG9ja1wiPlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1iLTEuNSBibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtaW5rLXNvZnRcIj5cbiAgICAgICAgICAgIHt0KFwiYm9va2luZy5kZWNsaW5lUmVhc29uXCIpfVxuICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICA8dGV4dGFyZWFcbiAgICAgICAgICAgIHJvd3M9ezN9XG4gICAgICAgICAgICB2YWx1ZT17cmVhc29ufVxuICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRSZWFzb24oZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgcGxhY2Vob2xkZXI9e3QoXCJib29raW5nLmRlY2xpbmVIaW50XCIpfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHJvdW5kZWQteGwgYmctaXZvcnkgcC0zIHRleHQtWzAuOTM3NXJlbV0gcmluZy0xIHJpbmctaGFpcmxpbmUtc3Ryb25nIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1hcXVhLTYwMFwiXG4gICAgICAgICAgLz5cbiAgICAgICAgPC9sYWJlbD5cbiAgICAgIDwvTW9kYWw+XG4gICAgPC8+XG4gICk7XG59XG5cbmZ1bmN0aW9uIEJvb2tpbmdDYXJkKHtcbiAgYm9va2luZyxcbiAgYnVzeSxcbiAgb25Nb3ZlLFxuICBvbkRlY2xpbmUsXG4gIG9uQ29uZmlybSxcbn06IHtcbiAgYm9va2luZzogQm9va2luZztcbiAgYnVzeTogYm9vbGVhbjtcbiAgb25Nb3ZlOiAoYjogQm9va2luZywgczogQm9va2luZ1N0YXR1cywgd2h5Pzogc3RyaW5nKSA9PiB2b2lkO1xuICBvbkRlY2xpbmU6ICgpID0+IHZvaWQ7XG4gIG9uQ29uZmlybTogKCkgPT4gdm9pZDtcbn0pIHtcbiAgY29uc3QgeyB0IH0gPSB1c2VJMThuKCk7XG4gIGNvbnN0IGIgPSBib29raW5nO1xuXG4gIHJldHVybiAoXG4gICAgPGFydGljbGUgY2xhc3NOYW1lPVwicm91bmRlZC1jYXJkIGJnLXN1cmZhY2UgcC00IHJpbmctMSByaW5nLWhhaXJsaW5lIHNtOnAtNVwiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC00XCI+XG4gICAgICAgIHtiLnNwYWNlSW1hZ2UgPyAoXG4gICAgICAgICAgPGltZyBzcmM9e2Iuc3BhY2VJbWFnZX0gYWx0PVwiXCIgY2xhc3NOYW1lPVwic2l6ZS0xNiBzaHJpbmstMCByb3VuZGVkLXhsIG9iamVjdC1jb3ZlclwiIC8+XG4gICAgICAgICkgOiAoXG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwic2l6ZS0xNiBzaHJpbmstMCByb3VuZGVkLXhsIGJnLWl2b3J5LWRlZXBcIiBhcmlhLWhpZGRlbiAvPlxuICAgICAgICApfVxuXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLXctMCBmbGV4LTFcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgPExpbmsgdG89e2Avc3BhY2UvJHtiLnNwYWNlSWR9YH0gY2xhc3NOYW1lPVwiZm9udC1kaXNwbGF5IGZvbnQtYm9sZCB0ZXh0LWluayBob3Zlcjp0ZXh0LWFxdWEtNzAwXCI+XG4gICAgICAgICAgICAgIHtiLnNwYWNlTmFtZX1cbiAgICAgICAgICAgIDwvTGluaz5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17Y24oXCJyb3VuZGVkLWZ1bGwgcHgtMi41IHB5LTAuNSB0ZXh0LXhzIGZvbnQtc2VtaWJvbGRcIiwgU1RBVFVTX1NUWUxFW2Iuc3RhdHVzXSl9PlxuICAgICAgICAgICAgICB7dChgYm9va2luZy5zdGF0dXMuJHtiLnN0YXR1c31gIGFzIG5ldmVyKX1cbiAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTAuNSB0ZXh0LXNtIHRleHQtbXV0ZWRcIj5cbiAgICAgICAgICAgIHtiLmFyZWEgPyBgJHtiLmFyZWF9IMK3IGAgOiBcIlwifVxuICAgICAgICAgICAge3QoXCJib29raW5nLndpdGhQZXJzb25cIiwgeyBuYW1lOiBiLnlvdUFyZU93bmVyID8gYi5yZW50ZXJOYW1lIDogYi5vd25lck5hbWUgfSl9XG4gICAgICAgICAgPC9wPlxuXG4gICAgICAgICAgPGRsIGNsYXNzTmFtZT1cIm10LTMgZmxleCBmbGV4LXdyYXAgZ2FwLXgtNSBnYXAteS0xIHRleHQtc21cIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtMS41XCI+XG4gICAgICAgICAgICAgIDxkdCBjbGFzc05hbWU9XCJ0ZXh0LW11dGVkXCI+e3QoXCJib29raW5nLm1vdmVJblwiKX08L2R0PlxuICAgICAgICAgICAgICA8ZGQgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWlua1wiPntsb25nRGF0ZShiLm1vdmVJbkRhdGUpfTwvZGQ+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtMS41XCI+XG4gICAgICAgICAgICAgIDxkdCBjbGFzc05hbWU9XCJ0ZXh0LW11dGVkXCI+e3QoXCJib29raW5nLmFtb3VudFwiKX08L2R0PlxuICAgICAgICAgICAgICA8ZGQgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0bnVtIHRleHQtaW5rXCI+e21vbmV5KGIuYW1vdW50KX08L2RkPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICB7Yi5tb250aHMgPiAxICYmIChcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC0xLjVcIj5cbiAgICAgICAgICAgICAgICA8ZHQgY2xhc3NOYW1lPVwidGV4dC1tdXRlZFwiPnt0KFwiYm9va2luZy5zY2hlZHVsZWRcIil9PC9kdD5cbiAgICAgICAgICAgICAgICA8ZGQgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0bnVtIHRleHQtaW5rXCI+XG4gICAgICAgICAgICAgICAgICB7dChcImJvb2tpbmcubW9udGhzQ291bnRcIiwgeyBjb3VudDogYi5tb250aHMgfSl9XG4gICAgICAgICAgICAgICAgPC9kZD5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApfVxuICAgICAgICAgIDwvZGw+XG5cbiAgICAgICAgICB7Yi5tZXNzYWdlICYmIChcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTMgcm91bmRlZC14bCBiZy1pdm9yeSBwLTMgdGV4dC1zbSBsZWFkaW5nLXJlbGF4ZWQgdGV4dC1pbmstc29mdFwiPntiLm1lc3NhZ2V9PC9wPlxuICAgICAgICAgICl9XG5cbiAgICAgICAgICB7Yi5kZWNsaW5lUmVhc29uICYmIChcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTMgcm91bmRlZC14bCBiZy1kYW5nZXItMTAwIHAtMyB0ZXh0LXNtIGxlYWRpbmctcmVsYXhlZCB0ZXh0LWRhbmdlci02MDBcIj5cbiAgICAgICAgICAgICAge2IuZGVjbGluZVJlYXNvbn1cbiAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICApfVxuXG4gICAgICAgICAgey8qIENvbnRhY3QgZGV0YWlscywgb25seSBvbmNlIGFjY2VwdGVkICovfVxuICAgICAgICAgIHtiLnBob25lU2hhcmVkID8gKFxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMyBpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgcm91bmRlZC14bCBiZy1vay0xMDAgcHgtMyBweS0yIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LW9rLTYwMFwiPlxuICAgICAgICAgICAgICA8UGhvbmUgc2l6ZT17MTR9IGFyaWEtaGlkZGVuIC8+XG4gICAgICAgICAgICAgIHtiLnlvdUFyZU93bmVyID8gYi5yZW50ZXJQaG9uZSA6IGIub3duZXJQaG9uZX1cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ub3JtYWwgb3BhY2l0eS04MFwiPlxuICAgICAgICAgICAgICAgIHt0KFwiYm9va2luZy5waG9uZU5vd1wiLCB7IG5hbWU6IGIueW91QXJlT3duZXIgPyBiLnJlbnRlck5hbWUgOiBiLm93bmVyTmFtZSB9KX1cbiAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICBiLnN0YXR1cyA9PT0gXCJyZXF1ZXN0ZWRcIiAmJiAoXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTMgaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQteHMgdGV4dC1tdXRlZFwiPlxuICAgICAgICAgICAgICAgIDxDbG9jayBzaXplPXsxM30gYXJpYS1oaWRkZW4gLz5cbiAgICAgICAgICAgICAgICB7dChcImJvb2tpbmcucGhvbmVMYXRlclwiKX1cbiAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgKVxuICAgICAgICAgICl9XG5cbiAgICAgICAgICB7LyogV2hhdCBlYWNoIHNpZGUgY2FuIGRvIGZyb20gaGVyZSAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTQgZmxleCBmbGV4LXdyYXAgZ2FwLTJcIj5cbiAgICAgICAgICAgIHtiLnlvdUFyZU93bmVyICYmIGIuc3RhdHVzID09PSBcInJlcXVlc3RlZFwiICYmIChcbiAgICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgICA8QnV0dG9uIHNpemU9XCJzbVwiIGRpc2FibGVkPXtidXN5fSBvbkNsaWNrPXsoKSA9PiBvbk1vdmUoYiwgXCJhY2NlcHRlZFwiKX0+XG4gICAgICAgICAgICAgICAgICA8Q2hlY2sgc2l6ZT17MTV9IGFyaWEtaGlkZGVuIC8+XG4gICAgICAgICAgICAgICAgICB7dChcImJvb2tpbmcuYWNjZXB0XCIpfVxuICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgICAgIDxCdXR0b24gc2l6ZT1cInNtXCIgdmFyaWFudD1cInNlY29uZGFyeVwiIGRpc2FibGVkPXtidXN5fSBvbkNsaWNrPXtvbkRlY2xpbmV9PlxuICAgICAgICAgICAgICAgICAgPFggc2l6ZT17MTV9IGFyaWEtaGlkZGVuIC8+XG4gICAgICAgICAgICAgICAgICB7dChcImJvb2tpbmcuZGVjbGluZVwiKX1cbiAgICAgICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICApfVxuXG4gICAgICAgICAgICB7Yi55b3VBcmVPd25lciAmJiBiLnN0YXR1cyA9PT0gXCJhY2NlcHRlZFwiICYmIChcbiAgICAgICAgICAgICAgPEJ1dHRvbiBzaXplPVwic21cIiBkaXNhYmxlZD17YnVzeX0gb25DbGljaz17b25Db25maXJtfT5cbiAgICAgICAgICAgICAgICA8Q2hlY2sgc2l6ZT17MTV9IGFyaWEtaGlkZGVuIC8+XG4gICAgICAgICAgICAgICAge3QoXCJib29raW5nLmNvbmZpcm1cIil9XG4gICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAge2IueW91QXJlT3duZXIgJiYgYi5zdGF0dXMgPT09IFwiY29uZmlybWVkXCIgJiYgKFxuICAgICAgICAgICAgICA8QnV0dG9uIHNpemU9XCJzbVwiIGRpc2FibGVkPXtidXN5fSBvbkNsaWNrPXsoKSA9PiBvbk1vdmUoYiwgXCJjb21wbGV0ZWRcIil9PlxuICAgICAgICAgICAgICAgIHt0KFwiYm9va2luZy5jb21wbGV0ZVwiKX1cbiAgICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgICApfVxuXG4gICAgICAgICAgICB7W1wicmVxdWVzdGVkXCIsIFwiYWNjZXB0ZWRcIiwgXCJjb25maXJtZWRcIl0uaW5jbHVkZXMoYi5zdGF0dXMpICYmIChcbiAgICAgICAgICAgICAgPEJ1dHRvbiBzaXplPVwic21cIiB2YXJpYW50PVwiZ2hvc3RcIiBkaXNhYmxlZD17YnVzeX0gb25DbGljaz17KCkgPT4gb25Nb3ZlKGIsIFwiY2FuY2VsbGVkXCIpfT5cbiAgICAgICAgICAgICAgICA8QmFuIHNpemU9ezE1fSBhcmlhLWhpZGRlbiAvPlxuICAgICAgICAgICAgICAgIHt0KFwiYm9va2luZy5jYW5jZWxcIil9XG4gICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIHtiLnN0YXR1cyA9PT0gXCJhY2NlcHRlZFwiICYmIChcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTMgdGV4dC14cyBsZWFkaW5nLXJlbGF4ZWQgdGV4dC1tdXRlZFwiPnt0KFwiYm9va2luZy5hY2NlcHRlZE5vdGVcIil9PC9wPlxuICAgICAgICAgICl9XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgPC9hcnRpY2xlPlxuICApO1xufVxuIl0sImZpbGUiOiJEOi9JMkkgUHJvamVjdCAtIEhhYml0by9BcHAgRm9sZGVyL2hhYml0by9zcmMvcGFnZXMvQm9va2luZ3MudHN4In0=