import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/layout/Footer.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=9ceb86a3"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("D:/I2I Project - Habito/App Folder/habito/src/components/layout/Footer.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=9ceb86a3";
import { Wordmark } from "/src/components/layout/Header.tsx";
import { useI18n } from "/src/i18n/index.tsx";
import { LanguageToggle } from "/src/components/ui/LanguageToggle.tsx";
const COLUMNS = [
  {
    heading: "footer.findHeading",
    links: [
      { to: "/explore", key: "nav.explore" },
      { to: "/search", key: "nav.search" },
      { to: "/find", key: "nav.find" },
      { to: "/saved", key: "nav.saved" },
      { to: "/messages", key: "nav.messages" }
    ]
  },
  {
    heading: "footer.ownerHeading",
    links: [
      { to: "/list", key: "nav.list" },
      { to: "/portfolio", key: "nav.portfolio" },
      { to: "/signup", key: "auth.createAccount" },
      { to: "/requests", key: "nav.requests" }
    ]
  }
];
export function Footer() {
  _s();
  const { t } = useI18n();
  return /* @__PURE__ */ jsxDEV("footer", { className: "mt-20 border-t border-hairline bg-ivory-deep", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "container-page grid gap-10 py-14 sm:grid-cols-2 lg:grid-cols-4", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "lg:col-span-2", children: [
        /* @__PURE__ */ jsxDEV(Wordmark, { className: "text-base" }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/layout/Footer.tsx",
          lineNumber: 53,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-4 sm:hidden", children: /* @__PURE__ */ jsxDEV(LanguageToggle, {}, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/layout/Footer.tsx",
          lineNumber: 55,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/layout/Footer.tsx",
          lineNumber: 54,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "mt-3 max-w-xs text-sm leading-relaxed text-muted", children: t("footer.blurb") }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/layout/Footer.tsx",
          lineNumber: 57,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/layout/Footer.tsx",
        lineNumber: 52,
        columnNumber: 9
      }, this),
      COLUMNS.map(
        (col) => /* @__PURE__ */ jsxDEV("nav", { "aria-label": t(col.heading), children: [
          /* @__PURE__ */ jsxDEV("h2", { className: "mb-3 font-display text-sm font-bold text-ink", children: t(col.heading) }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/layout/Footer.tsx",
            lineNumber: 62,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("ul", { className: "space-y-2", children: col.links.map(
            (l) => /* @__PURE__ */ jsxDEV("li", { children: /* @__PURE__ */ jsxDEV(Link, { to: l.to, className: "text-sm text-muted transition-colors hover:text-ink", children: t(l.key) }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/layout/Footer.tsx",
              lineNumber: 66,
              columnNumber: 19
            }, this) }, l.to, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/layout/Footer.tsx",
              lineNumber: 65,
              columnNumber: 13
            }, this)
          ) }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/layout/Footer.tsx",
            lineNumber: 63,
            columnNumber: 13
          }, this)
        ] }, col.heading, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/layout/Footer.tsx",
          lineNumber: 61,
          columnNumber: 9
        }, this)
      )
    ] }, void 0, true, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/layout/Footer.tsx",
      lineNumber: 51,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "border-t border-hairline", children: /* @__PURE__ */ jsxDEV("div", { className: "container-page flex flex-col gap-2 py-5 text-xs text-muted sm:flex-row sm:items-center sm:justify-between", children: [
      /* @__PURE__ */ jsxDEV("p", { children: "Prototype built for the Innovation to Impact initiative, Independent University, Bangladesh." }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/layout/Footer.tsx",
        lineNumber: 78,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("p", { children: "All seed data is synthetic. No real identity or ownership verification is performed." }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/layout/Footer.tsx",
        lineNumber: 79,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/layout/Footer.tsx",
      lineNumber: 77,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/layout/Footer.tsx",
      lineNumber: 76,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/layout/Footer.tsx",
    lineNumber: 50,
    columnNumber: 5
  }, this);
}
_s(Footer, "82N5KF9nLzZ6+2WH7KIjzIXRkLw=", false, function() {
  return [useI18n];
});
_c = Footer;
var _c;
$RefreshReg$(_c, "Footer");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/I2I Project - Habito/App Folder/habito/src/components/layout/Footer.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/I2I Project - Habito/App Folder/habito/src/components/layout/Footer.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUNVOzs7Ozs7Ozs7Ozs7Ozs7OztBQWpDVixTQUFTQSxZQUFZO0FBQ3JCLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxlQUFlO0FBQ3hCLFNBQVNDLHNCQUFzQjtBQUUvQixNQUFNQyxVQUFVO0FBQUEsRUFDZDtBQUFBLElBQ0VDLFNBQVM7QUFBQSxJQUNUQyxPQUFPO0FBQUEsTUFDTCxFQUFFQyxJQUFJLFlBQVlDLEtBQUssY0FBdUI7QUFBQSxNQUM5QyxFQUFFRCxJQUFJLFdBQVdDLEtBQUssYUFBc0I7QUFBQSxNQUM1QyxFQUFFRCxJQUFJLFNBQVNDLEtBQUssV0FBb0I7QUFBQSxNQUN4QyxFQUFFRCxJQUFJLFVBQVVDLEtBQUssWUFBcUI7QUFBQSxNQUMxQyxFQUFFRCxJQUFJLGFBQWFDLEtBQUssZUFBd0I7QUFBQSxJQUFDO0FBQUEsRUFFckQ7QUFBQSxFQUNBO0FBQUEsSUFDRUgsU0FBUztBQUFBLElBQ1RDLE9BQU87QUFBQSxNQUNMLEVBQUVDLElBQUksU0FBU0MsS0FBSyxXQUFvQjtBQUFBLE1BQ3hDLEVBQUVELElBQUksY0FBY0MsS0FBSyxnQkFBeUI7QUFBQSxNQUNsRCxFQUFFRCxJQUFJLFdBQVdDLEtBQUsscUJBQThCO0FBQUEsTUFDcEQsRUFBRUQsSUFBSSxhQUFhQyxLQUFLLGVBQXdCO0FBQUEsSUFBQztBQUFBLEVBRXJEO0FBQUM7QUFHSSxnQkFBU0MsU0FBUztBQUFBQyxLQUFBO0FBQ3ZCLFFBQU0sRUFBRUMsRUFBRSxJQUFJVCxRQUFRO0FBQ3RCLFNBQ0UsdUJBQUMsWUFBTyxXQUFVLGdEQUNoQjtBQUFBLDJCQUFDLFNBQUksV0FBVSxrRUFDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBLCtCQUFDLFlBQVMsV0FBVSxlQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQStCO0FBQUEsUUFDL0IsdUJBQUMsU0FBSSxXQUFVLGtCQUNiLGlDQUFDLG9CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZSxLQURqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLE9BQUUsV0FBVSxvREFBb0RTLFlBQUUsY0FBYyxLQUFqRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW1GO0FBQUEsV0FMckY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU1BO0FBQUEsTUFFQ1AsUUFBUVE7QUFBQUEsUUFBSSxDQUFDQyxRQUNaLHVCQUFDLFNBQXNCLGNBQVlGLEVBQUVFLElBQUlSLE9BQU8sR0FDOUM7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsZ0RBQWdETSxZQUFFRSxJQUFJUixPQUFPLEtBQTNFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTZFO0FBQUEsVUFDN0UsdUJBQUMsUUFBRyxXQUFVLGFBQ1hRLGNBQUlQLE1BQU1NO0FBQUFBLFlBQUksQ0FBQ0UsTUFDZCx1QkFBQyxRQUNDLGlDQUFDLFFBQUssSUFBSUEsRUFBRVAsSUFBSSxXQUFVLHVEQUN2QkksWUFBRUcsRUFBRU4sR0FBRyxLQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUEsS0FIT00sRUFBRVAsSUFBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUlBO0FBQUEsVUFDRCxLQVBIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBUUE7QUFBQSxhQVZRTSxJQUFJUixTQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFXQTtBQUFBLE1BQ0Q7QUFBQSxTQXRCSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBdUJBO0FBQUEsSUFFQSx1QkFBQyxTQUFJLFdBQVUsNEJBQ2IsaUNBQUMsU0FBSSxXQUFVLDZHQUNiO0FBQUEsNkJBQUMsT0FBRSw0R0FBSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQStGO0FBQUEsTUFDL0YsdUJBQUMsT0FBRSxvR0FBSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXVGO0FBQUEsU0FGekY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdBLEtBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUtBO0FBQUEsT0EvQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWdDQTtBQUVKO0FBQUNLLEdBckNlRCxRQUFNO0FBQUEsVUFDTlAsT0FBTztBQUFBO0FBQUEsS0FEUE87QUFBTSxJQUFBTTtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJMaW5rIiwiV29yZG1hcmsiLCJ1c2VJMThuIiwiTGFuZ3VhZ2VUb2dnbGUiLCJDT0xVTU5TIiwiaGVhZGluZyIsImxpbmtzIiwidG8iLCJrZXkiLCJGb290ZXIiLCJfcyIsInQiLCJtYXAiLCJjb2wiLCJsIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiRm9vdGVyLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBMaW5rIH0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIjtcbmltcG9ydCB7IFdvcmRtYXJrIH0gZnJvbSBcIi4vSGVhZGVyXCI7XG5pbXBvcnQgeyB1c2VJMThuIH0gZnJvbSBcIkAvaTE4blwiO1xuaW1wb3J0IHsgTGFuZ3VhZ2VUb2dnbGUgfSBmcm9tIFwiQC9jb21wb25lbnRzL3VpL0xhbmd1YWdlVG9nZ2xlXCI7XG5cbmNvbnN0IENPTFVNTlMgPSBbXG4gIHtcbiAgICBoZWFkaW5nOiBcImZvb3Rlci5maW5kSGVhZGluZ1wiIGFzIGNvbnN0LFxuICAgIGxpbmtzOiBbXG4gICAgICB7IHRvOiBcIi9leHBsb3JlXCIsIGtleTogXCJuYXYuZXhwbG9yZVwiIGFzIGNvbnN0IH0sXG4gICAgICB7IHRvOiBcIi9zZWFyY2hcIiwga2V5OiBcIm5hdi5zZWFyY2hcIiBhcyBjb25zdCB9LFxuICAgICAgeyB0bzogXCIvZmluZFwiLCBrZXk6IFwibmF2LmZpbmRcIiBhcyBjb25zdCB9LFxuICAgICAgeyB0bzogXCIvc2F2ZWRcIiwga2V5OiBcIm5hdi5zYXZlZFwiIGFzIGNvbnN0IH0sXG4gICAgICB7IHRvOiBcIi9tZXNzYWdlc1wiLCBrZXk6IFwibmF2Lm1lc3NhZ2VzXCIgYXMgY29uc3QgfSxcbiAgICBdLFxuICB9LFxuICB7XG4gICAgaGVhZGluZzogXCJmb290ZXIub3duZXJIZWFkaW5nXCIgYXMgY29uc3QsXG4gICAgbGlua3M6IFtcbiAgICAgIHsgdG86IFwiL2xpc3RcIiwga2V5OiBcIm5hdi5saXN0XCIgYXMgY29uc3QgfSxcbiAgICAgIHsgdG86IFwiL3BvcnRmb2xpb1wiLCBrZXk6IFwibmF2LnBvcnRmb2xpb1wiIGFzIGNvbnN0IH0sXG4gICAgICB7IHRvOiBcIi9zaWdudXBcIiwga2V5OiBcImF1dGguY3JlYXRlQWNjb3VudFwiIGFzIGNvbnN0IH0sXG4gICAgICB7IHRvOiBcIi9yZXF1ZXN0c1wiLCBrZXk6IFwibmF2LnJlcXVlc3RzXCIgYXMgY29uc3QgfSxcbiAgICBdLFxuICB9LFxuXTtcblxuZXhwb3J0IGZ1bmN0aW9uIEZvb3RlcigpIHtcbiAgY29uc3QgeyB0IH0gPSB1c2VJMThuKCk7XG4gIHJldHVybiAoXG4gICAgPGZvb3RlciBjbGFzc05hbWU9XCJtdC0yMCBib3JkZXItdCBib3JkZXItaGFpcmxpbmUgYmctaXZvcnktZGVlcFwiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb250YWluZXItcGFnZSBncmlkIGdhcC0xMCBweS0xNCBzbTpncmlkLWNvbHMtMiBsZzpncmlkLWNvbHMtNFwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImxnOmNvbC1zcGFuLTJcIj5cbiAgICAgICAgICA8V29yZG1hcmsgY2xhc3NOYW1lPVwidGV4dC1iYXNlXCIgLz5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTQgc206aGlkZGVuXCI+XG4gICAgICAgICAgICA8TGFuZ3VhZ2VUb2dnbGUgLz5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0zIG1heC13LXhzIHRleHQtc20gbGVhZGluZy1yZWxheGVkIHRleHQtbXV0ZWRcIj57dChcImZvb3Rlci5ibHVyYlwiKX08L3A+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHtDT0xVTU5TLm1hcCgoY29sKSA9PiAoXG4gICAgICAgICAgPG5hdiBrZXk9e2NvbC5oZWFkaW5nfSBhcmlhLWxhYmVsPXt0KGNvbC5oZWFkaW5nKX0+XG4gICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwibWItMyBmb250LWRpc3BsYXkgdGV4dC1zbSBmb250LWJvbGQgdGV4dC1pbmtcIj57dChjb2wuaGVhZGluZyl9PC9oMj5cbiAgICAgICAgICAgIDx1bCBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cbiAgICAgICAgICAgICAge2NvbC5saW5rcy5tYXAoKGwpID0+IChcbiAgICAgICAgICAgICAgICA8bGkga2V5PXtsLnRvfT5cbiAgICAgICAgICAgICAgICAgIDxMaW5rIHRvPXtsLnRvfSBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtbXV0ZWQgdHJhbnNpdGlvbi1jb2xvcnMgaG92ZXI6dGV4dC1pbmtcIj5cbiAgICAgICAgICAgICAgICAgICAge3QobC5rZXkpfVxuICAgICAgICAgICAgICAgICAgPC9MaW5rPlxuICAgICAgICAgICAgICAgIDwvbGk+XG4gICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgPC91bD5cbiAgICAgICAgICA8L25hdj5cbiAgICAgICAgKSl9XG4gICAgICA8L2Rpdj5cblxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJib3JkZXItdCBib3JkZXItaGFpcmxpbmVcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb250YWluZXItcGFnZSBmbGV4IGZsZXgtY29sIGdhcC0yIHB5LTUgdGV4dC14cyB0ZXh0LW11dGVkIHNtOmZsZXgtcm93IHNtOml0ZW1zLWNlbnRlciBzbTpqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICA8cD5Qcm90b3R5cGUgYnVpbHQgZm9yIHRoZSBJbm5vdmF0aW9uIHRvIEltcGFjdCBpbml0aWF0aXZlLCBJbmRlcGVuZGVudCBVbml2ZXJzaXR5LCBCYW5nbGFkZXNoLjwvcD5cbiAgICAgICAgICA8cD5BbGwgc2VlZCBkYXRhIGlzIHN5bnRoZXRpYy4gTm8gcmVhbCBpZGVudGl0eSBvciBvd25lcnNoaXAgdmVyaWZpY2F0aW9uIGlzIHBlcmZvcm1lZC48L3A+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgPC9mb290ZXI+XG4gICk7XG59XG4iXSwiZmlsZSI6IkQ6L0kySSBQcm9qZWN0IC0gSGFiaXRvL0FwcCBGb2xkZXIvaGFiaXRvL3NyYy9jb21wb25lbnRzL2xheW91dC9Gb290ZXIudHN4In0=