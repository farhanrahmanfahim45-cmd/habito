import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/Coachmark.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=9ceb86a3"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("D:/I2I Project - Habito/App Folder/habito/src/components/ui/Coachmark.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9ceb86a3"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import { Lightbulb, X } from "/node_modules/.vite/deps/lucide-react.js?v=9ceb86a3";
import { useI18n } from "/src/i18n/index.tsx";
import { cn } from "/src/lib/cn.ts";
export function Coachmark({
  id,
  titleKey,
  bodyKey,
  className
}) {
  _s();
  const { t } = useI18n();
  const [shown, setShown] = useState(false);
  useEffect(() => {
    try {
      setShown(window.localStorage.getItem(`habito.coach.${id}`) !== "seen");
    } catch {
      setShown(false);
    }
  }, [id]);
  if (!shown) return null;
  const dismiss = () => {
    setShown(false);
    try {
      window.localStorage.setItem(`habito.coach.${id}`, "seen");
    } catch {
    }
  };
  return /* @__PURE__ */ jsxDEV(
    "aside",
    {
      className: cn(
        "flex gap-3 rounded-card bg-aqua-50 p-4 text-sm ring-1 ring-aqua-200 rise",
        className
      ),
      children: [
        /* @__PURE__ */ jsxDEV(Lightbulb, { size: 17, className: "mt-0.5 shrink-0 text-aqua-700", "aria-hidden": true }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/ui/Coachmark.tsx",
          lineNumber: 73,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "min-w-0 flex-1", children: [
          /* @__PURE__ */ jsxDEV("p", { className: "font-semibold text-aqua-700", children: t(titleKey) }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/ui/Coachmark.tsx",
            lineNumber: 76,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "mt-1 leading-relaxed text-ink-soft", children: t(bodyKey) }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/ui/Coachmark.tsx",
            lineNumber: 77,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: dismiss,
              className: "mt-2 text-xs font-bold text-aqua-700 hover:underline",
              children: t("coach.gotIt")
            },
            void 0,
            false,
            {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/ui/Coachmark.tsx",
              lineNumber: 78,
              columnNumber: 9
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/ui/Coachmark.tsx",
          lineNumber: 75,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: dismiss,
            "aria-label": t("coach.gotIt"),
            className: "shrink-0 rounded-full p-1 text-aqua-700/60 hover:bg-aqua-100 hover:text-aqua-700",
            children: /* @__PURE__ */ jsxDEV(X, { size: 14, "aria-hidden": true }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/ui/Coachmark.tsx",
              lineNumber: 93,
              columnNumber: 9
            }, this)
          },
          void 0,
          false,
          {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/ui/Coachmark.tsx",
            lineNumber: 87,
            columnNumber: 7
          },
          this
        )
      ]
    },
    void 0,
    true,
    {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/ui/Coachmark.tsx",
      lineNumber: 67,
      columnNumber: 5
    },
    this
  );
}
_s(Coachmark, "POess8JxkKko2nOoaYTGq+F91Ic=", false, function() {
  return [useI18n];
});
_c = Coachmark;
var _c;
$RefreshReg$(_c, "Coachmark");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/I2I Project - Habito/App Folder/habito/src/components/ui/Coachmark.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/I2I Project - Habito/App Folder/habito/src/components/ui/Coachmark.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcURNOzs7Ozs7Ozs7Ozs7Ozs7OztBQXJETixTQUFTQSxXQUFXQyxnQkFBZ0I7QUFDcEMsU0FBU0MsV0FBV0MsU0FBUztBQUM3QixTQUFTQyxlQUFlO0FBQ3hCLFNBQVNDLFVBQVU7QUFTWixnQkFBU0MsVUFBVTtBQUFBLEVBQ3hCQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQU9GLEdBQUc7QUFBQUMsS0FBQTtBQUNELFFBQU0sRUFBRUMsRUFBRSxJQUFJUixRQUFRO0FBQ3RCLFFBQU0sQ0FBQ1MsT0FBT0MsUUFBUSxJQUFJYixTQUFTLEtBQUs7QUFFeENELFlBQVUsTUFBTTtBQUNkLFFBQUk7QUFDRmMsZUFBU0MsT0FBT0MsYUFBYUMsUUFBUSxnQkFBZ0JWLEVBQUUsRUFBRSxNQUFNLE1BQU07QUFBQSxJQUN2RSxRQUFRO0FBQ05PLGVBQVMsS0FBSztBQUFBLElBQ2hCO0FBQUEsRUFDRixHQUFHLENBQUNQLEVBQUUsQ0FBQztBQUVQLE1BQUksQ0FBQ00sTUFBTyxRQUFPO0FBRW5CLFFBQU1LLFVBQVVBLE1BQU07QUFDcEJKLGFBQVMsS0FBSztBQUNkLFFBQUk7QUFDRkMsYUFBT0MsYUFBYUcsUUFBUSxnQkFBZ0JaLEVBQUUsSUFBSSxNQUFNO0FBQUEsSUFDMUQsUUFBUTtBQUFBLElBQ047QUFBQSxFQUVKO0FBRUEsU0FDRTtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0MsV0FBV0Y7QUFBQUEsUUFDVDtBQUFBLFFBQ0FLO0FBQUFBLE1BQ0Y7QUFBQSxNQUVBO0FBQUEsK0JBQUMsYUFBVSxNQUFNLElBQUksV0FBVSxpQ0FBZ0MsZUFBVyxRQUExRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBFO0FBQUEsUUFFMUUsdUJBQUMsU0FBSSxXQUFVLGtCQUNiO0FBQUEsaUNBQUMsT0FBRSxXQUFVLCtCQUErQkUsWUFBRUosUUFBUSxLQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF3RDtBQUFBLFVBQ3hELHVCQUFDLE9BQUUsV0FBVSxzQ0FBc0NJLFlBQUVILE9BQU8sS0FBNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBOEQ7QUFBQSxVQUM5RDtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsU0FBU1M7QUFBQUEsY0FDVCxXQUFVO0FBQUEsY0FFVE4sWUFBRSxhQUFhO0FBQUE7QUFBQSxZQUxsQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFNQTtBQUFBLGFBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVVBO0FBQUEsUUFFQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBSztBQUFBLFlBQ0wsU0FBU007QUFBQUEsWUFDVCxjQUFZTixFQUFFLGFBQWE7QUFBQSxZQUMzQixXQUFVO0FBQUEsWUFFVixpQ0FBQyxLQUFFLE1BQU0sSUFBSSxlQUFXLFFBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXdCO0FBQUE7QUFBQSxVQU4xQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFPQTtBQUFBO0FBQUE7QUFBQSxJQTNCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUE0QkE7QUFFSjtBQUFDRCxHQWpFZUwsV0FBUztBQUFBLFVBWVRGLE9BQU87QUFBQTtBQUFBLEtBWlBFO0FBQVMsSUFBQWM7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJMaWdodGJ1bGIiLCJYIiwidXNlSTE4biIsImNuIiwiQ29hY2htYXJrIiwiaWQiLCJ0aXRsZUtleSIsImJvZHlLZXkiLCJjbGFzc05hbWUiLCJfcyIsInQiLCJzaG93biIsInNldFNob3duIiwid2luZG93IiwibG9jYWxTdG9yYWdlIiwiZ2V0SXRlbSIsImRpc21pc3MiLCJzZXRJdGVtIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQ29hY2htYXJrLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBMaWdodGJ1bGIsIFggfSBmcm9tIFwibHVjaWRlLXJlYWN0XCI7XG5pbXBvcnQgeyB1c2VJMThuIH0gZnJvbSBcIkAvaTE4blwiO1xuaW1wb3J0IHsgY24gfSBmcm9tIFwiQC9saWIvY25cIjtcbmltcG9ydCB0eXBlIHsgVHJhbnNsYXRpb25LZXkgfSBmcm9tIFwiQC9pMThuXCI7XG5cbi8qKlxuICogQSBvbmUtdGltZSBleHBsYW5hdGlvbiwgc2hvd24gd2hlcmUgdGhlIHRoaW5nIGJlaW5nIGV4cGxhaW5lZCBhY3R1YWxseSBpcy5cbiAqXG4gKiBEZWxpYmVyYXRlbHkgbm90IHBhcnQgb2YgYSB3YWxrdGhyb3VnaDogYW4gZXhwbGFuYXRpb24gb2YgdGhlIG1hdGNoIHNjb3JlXG4gKiBtZWFucyBub3RoaW5nIHVudGlsIHlvdSBhcmUgbG9va2luZyBhdCBvbmUuIERpc21pc3NlZCBvbmNlLCBnb25lIGZvciBnb29kLlxuICovXG5leHBvcnQgZnVuY3Rpb24gQ29hY2htYXJrKHtcbiAgaWQsXG4gIHRpdGxlS2V5LFxuICBib2R5S2V5LFxuICBjbGFzc05hbWUsXG59OiB7XG4gIC8qKiBTdGFibGUga2V5IOKAlCBkaXNtaXNzYWwgaXMgcmVtZW1iZXJlZCBhZ2FpbnN0IGl0LiAqL1xuICBpZDogc3RyaW5nO1xuICB0aXRsZUtleTogVHJhbnNsYXRpb25LZXk7XG4gIGJvZHlLZXk6IFRyYW5zbGF0aW9uS2V5O1xuICBjbGFzc05hbWU/OiBzdHJpbmc7XG59KSB7XG4gIGNvbnN0IHsgdCB9ID0gdXNlSTE4bigpO1xuICBjb25zdCBbc2hvd24sIHNldFNob3duXSA9IHVzZVN0YXRlKGZhbHNlKTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIHRyeSB7XG4gICAgICBzZXRTaG93bih3aW5kb3cubG9jYWxTdG9yYWdlLmdldEl0ZW0oYGhhYml0by5jb2FjaC4ke2lkfWApICE9PSBcInNlZW5cIik7XG4gICAgfSBjYXRjaCB7XG4gICAgICBzZXRTaG93bihmYWxzZSk7XG4gICAgfVxuICB9LCBbaWRdKTtcblxuICBpZiAoIXNob3duKSByZXR1cm4gbnVsbDtcblxuICBjb25zdCBkaXNtaXNzID0gKCkgPT4ge1xuICAgIHNldFNob3duKGZhbHNlKTtcbiAgICB0cnkge1xuICAgICAgd2luZG93LmxvY2FsU3RvcmFnZS5zZXRJdGVtKGBoYWJpdG8uY29hY2guJHtpZH1gLCBcInNlZW5cIik7XG4gICAgfSBjYXRjaCB7XG4gICAgICAvLyBOb3RoaW5nIHRvIGRvOyBpdCByZWFwcGVhcnMgbmV4dCB2aXNpdCwgd2hpY2ggaXMgaGFybWxlc3MuXG4gICAgfVxuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPGFzaWRlXG4gICAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgICBcImZsZXggZ2FwLTMgcm91bmRlZC1jYXJkIGJnLWFxdWEtNTAgcC00IHRleHQtc20gcmluZy0xIHJpbmctYXF1YS0yMDAgcmlzZVwiLFxuICAgICAgICBjbGFzc05hbWUsXG4gICAgICApfVxuICAgID5cbiAgICAgIDxMaWdodGJ1bGIgc2l6ZT17MTd9IGNsYXNzTmFtZT1cIm10LTAuNSBzaHJpbmstMCB0ZXh0LWFxdWEtNzAwXCIgYXJpYS1oaWRkZW4gLz5cblxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJtaW4tdy0wIGZsZXgtMVwiPlxuICAgICAgICA8cCBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtYXF1YS03MDBcIj57dCh0aXRsZUtleSl9PC9wPlxuICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0xIGxlYWRpbmctcmVsYXhlZCB0ZXh0LWluay1zb2Z0XCI+e3QoYm9keUtleSl9PC9wPlxuICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgb25DbGljaz17ZGlzbWlzc31cbiAgICAgICAgICBjbGFzc05hbWU9XCJtdC0yIHRleHQteHMgZm9udC1ib2xkIHRleHQtYXF1YS03MDAgaG92ZXI6dW5kZXJsaW5lXCJcbiAgICAgICAgPlxuICAgICAgICAgIHt0KFwiY29hY2guZ290SXRcIil9XG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgPC9kaXY+XG5cbiAgICAgIDxidXR0b25cbiAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgIG9uQ2xpY2s9e2Rpc21pc3N9XG4gICAgICAgIGFyaWEtbGFiZWw9e3QoXCJjb2FjaC5nb3RJdFwiKX1cbiAgICAgICAgY2xhc3NOYW1lPVwic2hyaW5rLTAgcm91bmRlZC1mdWxsIHAtMSB0ZXh0LWFxdWEtNzAwLzYwIGhvdmVyOmJnLWFxdWEtMTAwIGhvdmVyOnRleHQtYXF1YS03MDBcIlxuICAgICAgPlxuICAgICAgICA8WCBzaXplPXsxNH0gYXJpYS1oaWRkZW4gLz5cbiAgICAgIDwvYnV0dG9uPlxuICAgIDwvYXNpZGU+XG4gICk7XG59XG4iXSwiZmlsZSI6IkQ6L0kySSBQcm9qZWN0IC0gSGFiaXRvL0FwcCBGb2xkZXIvaGFiaXRvL3NyYy9jb21wb25lbnRzL3VpL0NvYWNobWFyay50c3gifQ==