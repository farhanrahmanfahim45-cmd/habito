import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/@fs/D:\\I2I Project - Habito\\App Folder\\habito\\src\\pages\\Portfolio.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=9ceb86a3"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9ceb86a3"; const useCallback = __vite__cjsImport3_react["useCallback"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useMemo = __vite__cjsImport3_react["useMemo"]; const useState = __vite__cjsImport3_react["useState"];
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=9ceb86a3";
import {
  Plus,
  ChevronDown,
  Building2,
  Inbox,
  CircleCheck,
  Wrench,
  CircleDot,
  TrendingUp,
  Eye,
  MessagesSquare,
  Pencil
} from "/node_modules/.vite/deps/lucide-react.js?v=9ceb86a3";
import { useHabito } from "/src/hooks/useHabito.tsx";
import { db } from "/src/lib/api/index.ts";
import { PageHeader } from "/src/components/layout/PageHeader.tsx";
import { Button } from "/src/components/ui/Button.tsx";
import { Coachmark } from "/src/components/ui/Coachmark.tsx";
import { AvailabilityBadge, TrustBadge } from "/src/components/space/badges.tsx";
import { CATEGORY_STYLE } from "/src/data/catalog.ts";
import { money, moneyCompact, lastUpdatedShort, isStale, longDate } from "/src/lib/format.ts";
import { SPACE_TYPE_LABEL, AVAILABILITY_LABEL } from "/src/types/space.ts";
import { cn } from "/src/lib/cn.ts";
import { useI18n } from "/src/i18n/index.tsx";
export default function Portfolio() {
  _s();
  const { t } = useI18n();
  const { ownerId, inquiries, refresh, listings } = useHabito();
  const [properties, setProperties] = useState([]);
  const [spaces, setSpaces] = useState([]);
  const [open, setOpen] = useState([]);
  const [busy, setBusy] = useState(null);
  const load = useCallback(async () => {
    const props = await db.properties(ownerId);
    const all = await Promise.all(props.map((p) => db.spacesOfProperty(p.id)));
    setProperties(props);
    setSpaces(all.flat());
    setOpen((prev) => prev.length ? prev : props.slice(0, 2).map((p) => p.id));
  }, [ownerId]);
  useEffect(() => {
    void load();
  }, [load, listings]);
  const stats = useMemo(() => {
    const available = spaces.filter((s) => s.availability.status === "available" || s.availability.status === "partially-available");
    const occupied = spaces.filter((s) => s.availability.status === "occupied");
    const maintenance = spaces.filter((s) => s.availability.status === "maintenance");
    const potential = spaces.filter((s) => s.transaction === "rent").reduce((sum, s) => sum + s.cost.price, 0);
    const needsUpdate = spaces.filter((s) => isStale(s.lastUpdated)).length;
    return {
      available: available.length,
      occupied: occupied.length,
      maintenance: maintenance.length,
      potential,
      needsUpdate,
      views: spaces.reduce((s, x) => s + x.views, 0)
    };
  }, [spaces]);
  const ownInquiries = useMemo(() => {
    const ids = new Set(spaces.map((s) => s.id));
    return inquiries.filter((i) => ids.has(i.spaceId));
  }, [inquiries, spaces]);
  const setStatus = async (spaceId, status) => {
    setBusy(spaceId);
    const space = spaces.find((s) => s.id === spaceId);
    if (space) {
      await db.updateSpace(spaceId, { availability: { ...space.availability, status } });
      await load();
      await refresh();
    }
    setBusy(null);
  };
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(
      PageHeader,
      {
        title: t("portfolio.title"),
        lead: "Every property you hold and every space inside it, in one view.",
        actions: /* @__PURE__ */ jsxDEV(Link, { to: "/list", children: /* @__PURE__ */ jsxDEV(Button, { children: [
          /* @__PURE__ */ jsxDEV(Plus, { size: 16, "aria-hidden": true }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
            lineNumber: 104,
            columnNumber: 15
          }, this),
          "Add a space"
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
          lineNumber: 103,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
          lineNumber: 102,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
        lineNumber: 98,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { className: "container-page py-8 md:py-10", children: [
      /* @__PURE__ */ jsxDEV("dl", { className: "grid gap-3 sm:grid-cols-2 lg:grid-cols-5", children: [
        /* @__PURE__ */ jsxDEV(Stat, { icon: Building2, label: "Properties", value: String(properties.length) }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
          lineNumber: 113,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Stat, { icon: CircleCheck, label: "Available", value: String(stats.available), tone: "ok" }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
          lineNumber: 114,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Stat, { icon: CircleDot, label: "Occupied", value: String(stats.occupied) }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
          lineNumber: 115,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Stat, { icon: Wrench, label: "Maintenance", value: String(stats.maintenance), tone: "warn" }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
          lineNumber: 116,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          Stat,
          {
            icon: TrendingUp,
            label: "Potential monthly",
            value: moneyCompact(stats.potential),
            hint: "If every rentable space were let at its listed price"
          },
          void 0,
          false,
          {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
            lineNumber: 117,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
        lineNumber: 112,
        columnNumber: 9
      }, this),
      stats.needsUpdate > 0 && /* @__PURE__ */ jsxDEV("p", { className: "mt-4 rounded-card bg-warn-100 p-4 text-sm text-warn-700", children: [
        /* @__PURE__ */ jsxDEV("strong", { className: "font-semibold", children: [
          stats.needsUpdate,
          " space",
          stats.needsUpdate > 1 ? "s" : ""
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
          lineNumber: 127,
          columnNumber: 13
        }, this),
        " ",
        stats.needsUpdate === 1 ? "hasn't" : "haven't",
        " been updated in over three weeks. Confirming availability keeps them ranking in search."
      ] }, void 0, true, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
        lineNumber: 126,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        Coachmark,
        {
          id: "property",
          titleKey: "coach.propertyTitle",
          bodyKey: "coach.propertyBody",
          className: "mt-6"
        },
        void 0,
        false,
        {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
          lineNumber: 133,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("h2", { className: "mt-10 font-display text-xl font-bold text-ink", children: "Properties" }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
        lineNumber: 140,
        columnNumber: 9
      }, this),
      properties.length === 0 && /* @__PURE__ */ jsxDEV("div", { className: "mt-3 flex flex-col items-center rounded-card bg-surface px-6 py-12 text-center ring-1 ring-hairline", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "mb-3 flex size-11 items-center justify-center rounded-full bg-aqua-100 text-aqua-700", children: /* @__PURE__ */ jsxDEV(Building2, { size: 20, "aria-hidden": true }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
          lineNumber: 145,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
          lineNumber: 144,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("h3", { className: "font-display font-bold text-ink", children: "You haven't added a property yet." }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
          lineNumber: 147,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "mt-1.5 max-w-sm text-sm leading-relaxed text-muted", children: "A property is the building, house or plot. Inside it you add the spaces people actually rent — flats, a shop, the garage." }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
          lineNumber: 148,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(Link, { to: "/list", className: "mt-4", children: /* @__PURE__ */ jsxDEV(Button, { size: "sm", children: [
          /* @__PURE__ */ jsxDEV(Plus, { size: 15, "aria-hidden": true }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
            lineNumber: 154,
            columnNumber: 17
          }, this),
          "Add your first space"
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
          lineNumber: 153,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
          lineNumber: 152,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
        lineNumber: 143,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("ul", { className: "mt-3 space-y-3", children: properties.map((property) => {
        const own = spaces.filter((s) => s.propertyId === property.id);
        const expanded = open.includes(property.id);
        const free = own.filter((s) => s.availability.status === "available" || s.availability.status === "partially-available").length;
        return /* @__PURE__ */ jsxDEV("li", { className: "overflow-hidden rounded-card bg-surface ring-1 ring-hairline", children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: () => setOpen((o) => expanded ? o.filter((x) => x !== property.id) : [...o, property.id]),
              "aria-expanded": expanded,
              className: "flex w-full items-center gap-4 p-4 text-left transition-colors hover:bg-ivory",
              children: [
                /* @__PURE__ */ jsxDEV("img", { src: property.coverImage, alt: "", className: "size-14 shrink-0 rounded-xl object-cover" }, void 0, false, {
                  fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
                  lineNumber: 175,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "min-w-0 flex-1", children: [
                  /* @__PURE__ */ jsxDEV("p", { className: "truncate font-display font-bold text-ink", children: property.name }, void 0, false, {
                    fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
                    lineNumber: 177,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "truncate text-sm text-muted", children: [
                    property.neighborhood,
                    ", ",
                    property.area,
                    !property.synthetic && /* @__PURE__ */ jsxDEV("span", { className: "ml-2 font-semibold text-aqua-700", children: "· added by you" }, void 0, false, {
                      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
                      lineNumber: 180,
                      columnNumber: 47
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
                    lineNumber: 178,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
                  lineNumber: 176,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "hidden shrink-0 text-right sm:block", children: [
                  /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-semibold tnum text-ink", children: [
                    own.length,
                    " ",
                    own.length === 1 ? "space" : "spaces"
                  ] }, void 0, true, {
                    fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
                    lineNumber: 184,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-xs tnum text-ok-600", children: [
                    free,
                    " available"
                  ] }, void 0, true, {
                    fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
                    lineNumber: 185,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
                  lineNumber: 183,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV(
                  ChevronDown,
                  {
                    size: 18,
                    "aria-hidden": true,
                    className: cn("shrink-0 text-muted transition-transform", expanded && "rotate-180")
                  },
                  void 0,
                  false,
                  {
                    fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
                    lineNumber: 187,
                    columnNumber: 19
                  },
                  this
                )
              ]
            },
            void 0,
            true,
            {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
              lineNumber: 169,
              columnNumber: 17
            },
            this
          ),
          expanded && /* @__PURE__ */ jsxDEV("ul", { className: "border-t border-hairline", children: [
            own.length === 0 && /* @__PURE__ */ jsxDEV("li", { className: "px-4 py-6 text-center text-sm text-muted", children: [
              "No spaces here yet.",
              " ",
              /* @__PURE__ */ jsxDEV(Link, { to: "/list", className: "font-semibold text-aqua-700 hover:underline", children: "Add one" }, void 0, false, {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
                lineNumber: 199,
                columnNumber: 25
              }, this),
              "."
            ] }, void 0, true, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
              lineNumber: 197,
              columnNumber: 19
            }, this),
            own.map((s) => {
              const cat = CATEGORY_STYLE[s.category];
              return /* @__PURE__ */ jsxDEV(
                "li",
                {
                  className: "flex flex-wrap items-center gap-x-4 gap-y-2 border-b border-hairline px-4 py-3 last:border-0",
                  children: [
                    /* @__PURE__ */ jsxDEV("span", { className: cn("flex size-8 shrink-0 items-center justify-center rounded-lg", cat.chip), children: /* @__PURE__ */ jsxDEV(cat.icon, { size: 15, "aria-hidden": true }, void 0, false, {
                      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
                      lineNumber: 213,
                      columnNumber: 29
                    }, this) }, void 0, false, {
                      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
                      lineNumber: 212,
                      columnNumber: 27
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "min-w-0 flex-1", children: [
                      /* @__PURE__ */ jsxDEV(Link, { to: `/space/${s.id}`, className: "font-semibold text-ink hover:text-aqua-700", children: s.name }, void 0, false, {
                        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
                        lineNumber: 217,
                        columnNumber: 29
                      }, this),
                      s.status === "archived" && /* @__PURE__ */ jsxDEV("span", { className: "ml-2 rounded-full bg-ivory-deep px-2 py-0.5 text-[0.65rem] font-semibold text-muted", children: t("edit.archive") }, void 0, false, {
                        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
                        lineNumber: 221,
                        columnNumber: 27
                      }, this),
                      s.status === "archived" && /* @__PURE__ */ jsxDEV("span", { className: "ml-2 rounded-full bg-ivory-deep px-2 py-0.5 text-[0.65rem] font-semibold text-muted", children: "Archived" }, void 0, false, {
                        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
                        lineNumber: 226,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-muted", children: [
                        SPACE_TYPE_LABEL[s.spaceType],
                        " · ",
                        money(s.cost.price),
                        s.transaction === "rent" ? "/mo" : " sale",
                        s.availability.note && ` · ${s.availability.note}`
                      ] }, void 0, true, {
                        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
                        lineNumber: 230,
                        columnNumber: 29
                      }, this)
                    ] }, void 0, true, {
                      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
                      lineNumber: 216,
                      columnNumber: 27
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "inline-flex items-center gap-1 text-xs tnum text-muted", children: [
                      /* @__PURE__ */ jsxDEV(Eye, { size: 13, "aria-hidden": true }, void 0, false, {
                        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
                        lineNumber: 238,
                        columnNumber: 29
                      }, this),
                      s.views
                    ] }, void 0, true, {
                      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
                      lineNumber: 237,
                      columnNumber: 27
                    }, this),
                    /* @__PURE__ */ jsxDEV(AvailabilityBadge, { availability: s.availability }, void 0, false, {
                      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
                      lineNumber: 242,
                      columnNumber: 27
                    }, this),
                    /* @__PURE__ */ jsxDEV(TrustBadge, { verification: s.verification, compact: true }, void 0, false, {
                      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
                      lineNumber: 243,
                      columnNumber: 27
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      "span",
                      {
                        className: cn(
                          "w-16 text-right text-xs",
                          isStale(s.lastUpdated) ? "font-semibold text-warn-700" : "text-muted"
                        ),
                        children: lastUpdatedShort(s.lastUpdated)
                      },
                      void 0,
                      false,
                      {
                        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
                        lineNumber: 245,
                        columnNumber: 27
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(Link, { to: `/list/${s.id}`, className: "shrink-0", children: /* @__PURE__ */ jsxDEV(Button, { size: "sm", variant: "secondary", children: [
                      /* @__PURE__ */ jsxDEV(Pencil, { size: 14, "aria-hidden": true }, void 0, false, {
                        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
                        lineNumber: 256,
                        columnNumber: 31
                      }, this),
                      /* @__PURE__ */ jsxDEV("span", { className: "hidden sm:inline", children: t("edit.editSpace") }, void 0, false, {
                        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
                        lineNumber: 257,
                        columnNumber: 31
                      }, this)
                    ] }, void 0, true, {
                      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
                      lineNumber: 255,
                      columnNumber: 29
                    }, this) }, void 0, false, {
                      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
                      lineNumber: 254,
                      columnNumber: 27
                    }, this),
                    /* @__PURE__ */ jsxDEV("label", { className: "shrink-0", children: [
                      /* @__PURE__ */ jsxDEV("span", { className: "sr-only", children: [
                        "Availability for ",
                        s.name
                      ] }, void 0, true, {
                        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
                        lineNumber: 262,
                        columnNumber: 29
                      }, this),
                      /* @__PURE__ */ jsxDEV(
                        "select",
                        {
                          value: s.availability.status,
                          disabled: busy === s.id,
                          onChange: (e) => void setStatus(s.id, e.target.value),
                          className: "h-9 rounded-full bg-ivory px-3 text-xs font-semibold text-ink ring-1 ring-hairline-strong focus:outline-none focus:ring-2 focus:ring-aqua-600",
                          children: Object.keys(AVAILABILITY_LABEL).map(
                            (st) => /* @__PURE__ */ jsxDEV("option", { value: st, children: AVAILABILITY_LABEL[st] }, st, false, {
                              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
                              lineNumber: 270,
                              columnNumber: 29
                            }, this)
                          )
                        },
                        void 0,
                        false,
                        {
                          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
                          lineNumber: 263,
                          columnNumber: 29
                        },
                        this
                      )
                    ] }, void 0, true, {
                      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
                      lineNumber: 261,
                      columnNumber: 27
                    }, this)
                  ]
                },
                s.id,
                true,
                {
                  fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
                  lineNumber: 208,
                  columnNumber: 23
                },
                this
              );
            })
          ] }, void 0, true, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
            lineNumber: 195,
            columnNumber: 17
          }, this)
        ] }, property.id, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
          lineNumber: 168,
          columnNumber: 15
        }, this);
      }) }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
        lineNumber: 161,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mt-10 flex flex-wrap items-end justify-between gap-3", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("h2", { className: "font-display text-xl font-bold text-ink", children: "Inquiries" }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
            lineNumber: 289,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-muted", children: "Each one arrives with the sender's budget and move-in date." }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
            lineNumber: 290,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
          lineNumber: 288,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Link, { to: "/messages", children: /* @__PURE__ */ jsxDEV(Button, { variant: "secondary", size: "sm", children: [
          /* @__PURE__ */ jsxDEV(MessagesSquare, { size: 15, "aria-hidden": true }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
            lineNumber: 296,
            columnNumber: 15
          }, this),
          "Open messages"
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
          lineNumber: 295,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
          lineNumber: 294,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
        lineNumber: 287,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mt-3", children: ownInquiries.length === 0 ? /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col items-center rounded-card bg-surface px-6 py-12 text-center ring-1 ring-hairline", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "mb-3 flex size-11 items-center justify-center rounded-full bg-aqua-100 text-aqua-700", children: /* @__PURE__ */ jsxDEV(Inbox, { size: 20, "aria-hidden": true }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
          lineNumber: 306,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
          lineNumber: 305,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("h3", { className: "font-display font-bold text-ink", children: "No inquiries yet." }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
          lineNumber: 308,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "mt-1.5 max-w-xs text-sm text-muted", children: "Switch to seeker mode, open one of your spaces and send an inquiry — it lands here." }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
          lineNumber: 309,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(Link, { to: "/messages", className: "mt-4", children: /* @__PURE__ */ jsxDEV(Button, { variant: "secondary", size: "sm", children: "Open messages" }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
          lineNumber: 313,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
          lineNumber: 312,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
        lineNumber: 304,
        columnNumber: 11
      }, this) : /* @__PURE__ */ jsxDEV("ul", { className: "space-y-3", children: ownInquiries.map(
        (inq) => /* @__PURE__ */ jsxDEV(InquiryRow, { inquiry: inq, spaces, onChanged: refresh }, inq.id, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
          lineNumber: 321,
          columnNumber: 13
        }, this)
      ) }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
        lineNumber: 319,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
        lineNumber: 302,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "mt-8 rounded-card bg-surface/70 p-4 text-sm leading-relaxed text-ink-soft ring-1 ring-hairline-strong", children: "Everything you change here is stored on this device and survives a refresh. Seed properties are synthetic; anything you add is marked as yours." }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
        lineNumber: 327,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
      lineNumber: 111,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
    lineNumber: 97,
    columnNumber: 5
  }, this);
}
_s(Portfolio, "9Bi9Udt56UyM//8XGBc9ENmBfp4=", false, function() {
  return [useI18n, useHabito];
});
_c = Portfolio;
function Stat({
  icon: Icon,
  label,
  value,
  hint,
  tone
}) {
  return /* @__PURE__ */ jsxDEV("div", { className: "rounded-card bg-surface p-5 ring-1 ring-hairline", children: [
    /* @__PURE__ */ jsxDEV("dt", { className: "flex items-center gap-2 text-sm text-muted", children: [
      /* @__PURE__ */ jsxDEV(
        Icon,
        {
          size: 15,
          "aria-hidden": true,
          className: tone === "ok" ? "text-ok-600" : tone === "warn" ? "text-warn-700" : "text-aqua-600"
        },
        void 0,
        false,
        {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
          lineNumber: 352,
          columnNumber: 9
        },
        this
      ),
      label
    ] }, void 0, true, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
      lineNumber: 351,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("dd", { className: "mt-2 font-display text-2xl font-bold tnum text-ink", children: value }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
      lineNumber: 359,
      columnNumber: 7
    }, this),
    hint && /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-xs leading-snug text-muted", children: hint }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
      lineNumber: 360,
      columnNumber: 16
    }, this)
  ] }, void 0, true, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
    lineNumber: 350,
    columnNumber: 5
  }, this);
}
_c2 = Stat;
const STATUS_FLOW = ["new", "contacted", "interested", "closed"];
function InquiryRow({
  inquiry,
  spaces,
  onChanged
}) {
  const space = spaces.find((s) => s.id === inquiry.spaceId);
  return /* @__PURE__ */ jsxDEV("li", { className: "rounded-card bg-surface p-4 ring-1 ring-hairline", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-start justify-between gap-3", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "min-w-0", children: [
        /* @__PURE__ */ jsxDEV("p", { className: "font-semibold text-ink", children: [
          inquiry.name,
          /* @__PURE__ */ jsxDEV("span", { className: "ml-2 font-normal text-muted", children: [
            "on ",
            space?.name ?? inquiry.spaceId
          ] }, void 0, true, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
            lineNumber: 384,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
          lineNumber: 382,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm leading-relaxed text-ink-soft", children: inquiry.message }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
          lineNumber: 386,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
        lineNumber: 381,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("label", { className: "shrink-0", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "sr-only", children: "Status for this inquiry" }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
          lineNumber: 390,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          "select",
          {
            value: inquiry.status,
            onChange: async (e) => {
              await db.setInquiryStatus(inquiry.id, e.target.value);
              await onChanged();
            },
            className: "h-9 rounded-full bg-ivory px-3 text-xs font-semibold capitalize text-ink ring-1 ring-hairline-strong focus:outline-none focus:ring-2 focus:ring-aqua-600",
            children: STATUS_FLOW.map(
              (s) => /* @__PURE__ */ jsxDEV("option", { value: s, children: s }, s, false, {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
                lineNumber: 400,
                columnNumber: 13
              }, this)
            )
          },
          void 0,
          false,
          {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
            lineNumber: 391,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
        lineNumber: 389,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
      lineNumber: 380,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("ul", { className: "mt-3 flex flex-wrap gap-1.5 text-xs", children: [
      /* @__PURE__ */ jsxDEV("li", { className: "rounded-full bg-ivory-deep px-2.5 py-1 font-semibold text-ink-soft", children: [
        "Budget ",
        money(inquiry.budgetMin),
        "–",
        money(inquiry.budgetMax)
      ] }, void 0, true, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
        lineNumber: 409,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("li", { className: "rounded-full bg-ivory-deep px-2.5 py-1 font-semibold text-ink-soft", children: [
        "Moving ",
        longDate(inquiry.moveInDate)
      ] }, void 0, true, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
        lineNumber: 412,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
      lineNumber: 408,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx",
    lineNumber: 379,
    columnNumber: 5
  }, this);
}
_c3 = InquiryRow;
var _c, _c2, _c3;
$RefreshReg$(_c, "Portfolio");
$RefreshReg$(_c2, "Stat");
$RefreshReg$(_c3, "InquiryRow");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/I2I Project - Habito/App Folder/habito/src/pages/Portfolio.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNkVJLG1CQU9VLGNBUFY7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBN0VKLFNBQVNBLGFBQWFDLFdBQVdDLFNBQVNDLGdCQUFnQjtBQUMxRCxTQUFTQyxZQUFZO0FBQ3JCO0FBQUEsRUFDRUM7QUFBQUEsRUFBTUM7QUFBQUEsRUFBYUM7QUFBQUEsRUFBV0M7QUFBQUEsRUFBT0M7QUFBQUEsRUFBYUM7QUFBQUEsRUFBUUM7QUFBQUEsRUFBV0M7QUFBQUEsRUFBWUM7QUFBQUEsRUFBS0M7QUFBQUEsRUFBZ0JDO0FBQUFBLE9BQ2pHO0FBQ1AsU0FBU0MsaUJBQWlCO0FBQzFCLFNBQVNDLFVBQVU7QUFDbkIsU0FBU0Msa0JBQWtCO0FBQzNCLFNBQVNDLGNBQWM7QUFDdkIsU0FBU0MsaUJBQWlCO0FBQzFCLFNBQVNDLG1CQUFtQkMsa0JBQWtCO0FBQzlDLFNBQVNDLHNCQUFzQjtBQUMvQixTQUFTQyxPQUFPQyxjQUFjQyxrQkFBa0JDLFNBQVNDLGdCQUFnQjtBQUN6RSxTQUFTQyxrQkFBa0JDLDBCQUEwQjtBQUVyRCxTQUFTQyxVQUFVO0FBQ25CLFNBQVNDLGVBQWU7QUFNeEIsd0JBQXdCQyxZQUFZO0FBQUFDLEtBQUE7QUFDbEMsUUFBTSxFQUFFQyxFQUFFLElBQUlILFFBQVE7QUFDdEIsUUFBTSxFQUFFSSxTQUFTQyxXQUFXQyxTQUFTQyxTQUFTLElBQUl2QixVQUFVO0FBQzVELFFBQU0sQ0FBQ3dCLFlBQVlDLGFBQWEsSUFBSXRDLFNBQXFCLEVBQUU7QUFDM0QsUUFBTSxDQUFDdUMsUUFBUUMsU0FBUyxJQUFJeEMsU0FBa0IsRUFBRTtBQUNoRCxRQUFNLENBQUN5QyxNQUFNQyxPQUFPLElBQUkxQyxTQUFtQixFQUFFO0FBQzdDLFFBQU0sQ0FBQzJDLE1BQU1DLE9BQU8sSUFBSTVDLFNBQXdCLElBQUk7QUFFcEQsUUFBTTZDLE9BQU9oRCxZQUFZLFlBQVk7QUFDbkMsVUFBTWlELFFBQVEsTUFBTWhDLEdBQUd1QixXQUFXSixPQUFPO0FBQ3pDLFVBQU1jLE1BQU0sTUFBTUMsUUFBUUQsSUFBSUQsTUFBTUcsSUFBSSxDQUFDQyxNQUFNcEMsR0FBR3FDLGlCQUFpQkQsRUFBRUUsRUFBRSxDQUFDLENBQUM7QUFDekVkLGtCQUFjUSxLQUFLO0FBQ25CTixjQUFVTyxJQUFJTSxLQUFLLENBQUM7QUFDcEJYLFlBQVEsQ0FBQ1ksU0FBVUEsS0FBS0MsU0FBU0QsT0FBT1IsTUFBTVUsTUFBTSxHQUFHLENBQUMsRUFBRVAsSUFBSSxDQUFDQyxNQUFNQSxFQUFFRSxFQUFFLENBQUU7QUFBQSxFQUM3RSxHQUFHLENBQUNuQixPQUFPLENBQUM7QUFFWm5DLFlBQVUsTUFBTTtBQUNkLFNBQUsrQyxLQUFLO0FBQUEsRUFDWixHQUFHLENBQUNBLE1BQU1ULFFBQVEsQ0FBQztBQUVuQixRQUFNcUIsUUFBUTFELFFBQVEsTUFBTTtBQUMxQixVQUFNMkQsWUFBWW5CLE9BQU9vQixPQUFPLENBQUNDLE1BQU1BLEVBQUVDLGFBQWFDLFdBQVcsZUFBZUYsRUFBRUMsYUFBYUMsV0FBVyxxQkFBcUI7QUFDL0gsVUFBTUMsV0FBV3hCLE9BQU9vQixPQUFPLENBQUNDLE1BQU1BLEVBQUVDLGFBQWFDLFdBQVcsVUFBVTtBQUMxRSxVQUFNRSxjQUFjekIsT0FBT29CLE9BQU8sQ0FBQ0MsTUFBTUEsRUFBRUMsYUFBYUMsV0FBVyxhQUFhO0FBQ2hGLFVBQU1HLFlBQVkxQixPQUNmb0IsT0FBTyxDQUFDQyxNQUFNQSxFQUFFTSxnQkFBZ0IsTUFBTSxFQUN0Q0MsT0FBTyxDQUFDQyxLQUFLUixNQUFNUSxNQUFNUixFQUFFUyxLQUFLQyxPQUFPLENBQUM7QUFDM0MsVUFBTUMsY0FBY2hDLE9BQU9vQixPQUFPLENBQUNDLE1BQU1wQyxRQUFRb0MsRUFBRVksV0FBVyxDQUFDLEVBQUVqQjtBQUNqRSxXQUFPO0FBQUEsTUFDTEcsV0FBV0EsVUFBVUg7QUFBQUEsTUFDckJRLFVBQVVBLFNBQVNSO0FBQUFBLE1BQ25CUyxhQUFhQSxZQUFZVDtBQUFBQSxNQUN6QlU7QUFBQUEsTUFDQU07QUFBQUEsTUFDQUUsT0FBT2xDLE9BQU80QixPQUFPLENBQUNQLEdBQUdjLE1BQU1kLElBQUljLEVBQUVELE9BQU8sQ0FBQztBQUFBLElBQy9DO0FBQUEsRUFDRixHQUFHLENBQUNsQyxNQUFNLENBQUM7QUFFWCxRQUFNb0MsZUFBZTVFLFFBQVEsTUFBTTtBQUNqQyxVQUFNNkUsTUFBTSxJQUFJQyxJQUFJdEMsT0FBT1UsSUFBSSxDQUFDVyxNQUFNQSxFQUFFUixFQUFFLENBQUM7QUFDM0MsV0FBT2xCLFVBQVV5QixPQUFPLENBQUNtQixNQUFNRixJQUFJRyxJQUFJRCxFQUFFRSxPQUFPLENBQUM7QUFBQSxFQUNuRCxHQUFHLENBQUM5QyxXQUFXSyxNQUFNLENBQUM7QUFFdEIsUUFBTTBDLFlBQVksT0FBT0QsU0FBaUJsQixXQUErQjtBQUN2RWxCLFlBQVFvQyxPQUFPO0FBQ2YsVUFBTUUsUUFBUTNDLE9BQU80QyxLQUFLLENBQUN2QixNQUFNQSxFQUFFUixPQUFPNEIsT0FBTztBQUNqRCxRQUFJRSxPQUFPO0FBQ1QsWUFBTXBFLEdBQUdzRSxZQUFZSixTQUFTLEVBQUVuQixjQUFjLEVBQUUsR0FBR3FCLE1BQU1yQixjQUFjQyxPQUFPLEVBQUUsQ0FBQztBQUNqRixZQUFNakIsS0FBSztBQUNYLFlBQU1WLFFBQVE7QUFBQSxJQUNoQjtBQUNBUyxZQUFRLElBQUk7QUFBQSxFQUNkO0FBRUEsU0FDRSxtQ0FDRTtBQUFBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxPQUFPWixFQUFFLGlCQUFpQjtBQUFBLFFBQzFCLE1BQUs7QUFBQSxRQUNMLFNBQ0UsdUJBQUMsUUFBSyxJQUFHLFNBQ1AsaUNBQUMsVUFDQztBQUFBLGlDQUFDLFFBQUssTUFBTSxJQUFJLGVBQVcsUUFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMkI7QUFBQTtBQUFBLGFBRDdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQSxLQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFLQTtBQUFBO0FBQUEsTUFUSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFVRztBQUFBLElBR0gsdUJBQUMsU0FBSSxXQUFVLGdDQUNiO0FBQUEsNkJBQUMsUUFBRyxXQUFVLDRDQUNaO0FBQUEsK0JBQUMsUUFBSyxNQUFNNUIsV0FBVyxPQUFNLGNBQWEsT0FBT2lGLE9BQU9oRCxXQUFXa0IsTUFBTSxLQUF6RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTJFO0FBQUEsUUFDM0UsdUJBQUMsUUFBSyxNQUFNakQsYUFBYSxPQUFNLGFBQVksT0FBTytFLE9BQU81QixNQUFNQyxTQUFTLEdBQUcsTUFBSyxRQUFoRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW9GO0FBQUEsUUFDcEYsdUJBQUMsUUFBSyxNQUFNbEQsV0FBVyxPQUFNLFlBQVcsT0FBTzZFLE9BQU81QixNQUFNTSxRQUFRLEtBQXBFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc0U7QUFBQSxRQUN0RSx1QkFBQyxRQUFLLE1BQU14RCxRQUFRLE9BQU0sZUFBYyxPQUFPOEUsT0FBTzVCLE1BQU1PLFdBQVcsR0FBRyxNQUFLLFVBQS9FO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBcUY7QUFBQSxRQUNyRjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBTXZEO0FBQUFBLFlBQ04sT0FBTTtBQUFBLFlBQ04sT0FBT2EsYUFBYW1DLE1BQU1RLFNBQVM7QUFBQSxZQUNuQyxNQUFLO0FBQUE7QUFBQSxVQUpQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUk2RDtBQUFBLFdBVC9EO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFXQTtBQUFBLE1BRUNSLE1BQU1jLGNBQWMsS0FDbkIsdUJBQUMsT0FBRSxXQUFVLDJEQUNYO0FBQUEsK0JBQUMsWUFBTyxXQUFVLGlCQUFpQmQ7QUFBQUEsZ0JBQU1jO0FBQUFBLFVBQVk7QUFBQSxVQUFPZCxNQUFNYyxjQUFjLElBQUksTUFBTTtBQUFBLGFBQTFGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNkY7QUFBQSxRQUFVO0FBQUEsUUFDdEdkLE1BQU1jLGdCQUFnQixJQUFJLFdBQVc7QUFBQSxRQUFVO0FBQUEsV0FGbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFJRjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsSUFBRztBQUFBLFVBQ0gsVUFBUztBQUFBLFVBQ1QsU0FBUTtBQUFBLFVBQ1IsV0FBVTtBQUFBO0FBQUEsUUFKWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFJa0I7QUFBQSxNQUdsQix1QkFBQyxRQUFHLFdBQVUsaURBQWdELDBCQUE5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXdFO0FBQUEsTUFFdkVsQyxXQUFXa0IsV0FBVyxLQUNyQix1QkFBQyxTQUFJLFdBQVUsdUdBQ2I7QUFBQSwrQkFBQyxVQUFLLFdBQVUsd0ZBQ2QsaUNBQUMsYUFBVSxNQUFNLElBQUksZUFBVyxRQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWdDLEtBRGxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsUUFBRyxXQUFVLG1DQUFrQyxpREFBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpRjtBQUFBLFFBQ2pGLHVCQUFDLE9BQUUsV0FBVSxzREFBb0QseUlBQWpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBQ0EsdUJBQUMsUUFBSyxJQUFHLFNBQVEsV0FBVSxRQUN6QixpQ0FBQyxVQUFPLE1BQUssTUFDWDtBQUFBLGlDQUFDLFFBQUssTUFBTSxJQUFJLGVBQVcsUUFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMkI7QUFBQTtBQUFBLGFBRDdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQSxLQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFLQTtBQUFBLFdBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWVBO0FBQUEsTUFHRix1QkFBQyxRQUFHLFdBQVUsa0JBQ1hsQixxQkFBV1ksSUFBSSxDQUFDcUMsYUFBYTtBQUM1QixjQUFNQyxNQUFNaEQsT0FBT29CLE9BQU8sQ0FBQ0MsTUFBTUEsRUFBRTRCLGVBQWVGLFNBQVNsQyxFQUFFO0FBQzdELGNBQU1xQyxXQUFXaEQsS0FBS2lELFNBQVNKLFNBQVNsQyxFQUFFO0FBQzFDLGNBQU11QyxPQUFPSixJQUFJNUIsT0FBTyxDQUFDQyxNQUFNQSxFQUFFQyxhQUFhQyxXQUFXLGVBQWVGLEVBQUVDLGFBQWFDLFdBQVcscUJBQXFCLEVBQUVQO0FBRXpILGVBQ0UsdUJBQUMsUUFBcUIsV0FBVSxnRUFDOUI7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsU0FBUyxNQUFNYixRQUFRLENBQUNrRCxNQUFPSCxXQUFXRyxFQUFFakMsT0FBTyxDQUFDZSxNQUFNQSxNQUFNWSxTQUFTbEMsRUFBRSxJQUFJLENBQUMsR0FBR3dDLEdBQUdOLFNBQVNsQyxFQUFFLENBQUU7QUFBQSxjQUNuRyxpQkFBZXFDO0FBQUFBLGNBQ2YsV0FBVTtBQUFBLGNBRVY7QUFBQSx1Q0FBQyxTQUFJLEtBQUtILFNBQVNPLFlBQVksS0FBSSxJQUFHLFdBQVUsOENBQWhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTBGO0FBQUEsZ0JBQzFGLHVCQUFDLFNBQUksV0FBVSxrQkFDYjtBQUFBLHlDQUFDLE9BQUUsV0FBVSw0Q0FBNENQLG1CQUFTUSxRQUFsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF1RTtBQUFBLGtCQUN2RSx1QkFBQyxPQUFFLFdBQVUsK0JBQ1ZSO0FBQUFBLDZCQUFTUztBQUFBQSxvQkFBYTtBQUFBLG9CQUFHVCxTQUFTVTtBQUFBQSxvQkFDbEMsQ0FBQ1YsU0FBU1csYUFBYSx1QkFBQyxVQUFLLFdBQVUsb0NBQW1DLDhCQUFuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFpRTtBQUFBLHVCQUYzRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUdBO0FBQUEscUJBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFNQTtBQUFBLGdCQUNBLHVCQUFDLFNBQUksV0FBVSx1Q0FDYjtBQUFBLHlDQUFDLE9BQUUsV0FBVSx1Q0FBdUNWO0FBQUFBLHdCQUFJaEM7QUFBQUEsb0JBQU87QUFBQSxvQkFBRWdDLElBQUloQyxXQUFXLElBQUksVUFBVTtBQUFBLHVCQUE5RjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF1RztBQUFBLGtCQUN2Ryx1QkFBQyxPQUFFLFdBQVUsNEJBQTRCb0M7QUFBQUE7QUFBQUEsb0JBQUs7QUFBQSx1QkFBOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBd0Q7QUFBQSxxQkFGMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFHQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQU07QUFBQSxvQkFDTjtBQUFBLG9CQUNBLFdBQVcvRCxHQUFHLDRDQUE0QzZELFlBQVksWUFBWTtBQUFBO0FBQUEsa0JBSHBGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFHc0Y7QUFBQTtBQUFBO0FBQUEsWUFyQnhGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQXVCQTtBQUFBLFVBRUNBLFlBQ0MsdUJBQUMsUUFBRyxXQUFVLDRCQUNYRjtBQUFBQSxnQkFBSWhDLFdBQVcsS0FDZCx1QkFBQyxRQUFHLFdBQVUsNENBQTBDO0FBQUE7QUFBQSxjQUNsQztBQUFBLGNBQ3BCLHVCQUFDLFFBQUssSUFBRyxTQUFRLFdBQVUsK0NBQTZDLHVCQUF4RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FBTTtBQUFBLGlCQUpSO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBTUE7QUFBQSxZQUVEZ0MsSUFBSXRDLElBQUksQ0FBQ1csTUFBTTtBQUNkLG9CQUFNc0MsTUFBTTlFLGVBQWV3QyxFQUFFdUMsUUFBUTtBQUNyQyxxQkFDRTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFFQyxXQUFVO0FBQUEsa0JBRVY7QUFBQSwyQ0FBQyxVQUFLLFdBQVd2RSxHQUFHLCtEQUErRHNFLElBQUlFLElBQUksR0FDekYsaUNBQUMsSUFBSSxNQUFKLEVBQVMsTUFBTSxJQUFJLGVBQVcsUUFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBK0IsS0FEakM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUVBLHVCQUFDLFNBQUksV0FBVSxrQkFDYjtBQUFBLDZDQUFDLFFBQUssSUFBSSxVQUFVeEMsRUFBRVIsRUFBRSxJQUFJLFdBQVUsOENBQ25DUSxZQUFFa0MsUUFETDtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEsc0JBQ0NsQyxFQUFFRSxXQUFXLGNBQ1osdUJBQUMsVUFBSyxXQUFVLHVGQUNiOUIsWUFBRSxjQUFjLEtBRG5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSxzQkFFRDRCLEVBQUVFLFdBQVcsY0FDWix1QkFBQyxVQUFLLFdBQVUsdUZBQXFGLHdCQUFyRztBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEsc0JBRUYsdUJBQUMsT0FBRSxXQUFVLHNCQUNWcEM7QUFBQUEseUNBQWlCa0MsRUFBRXlDLFNBQVM7QUFBQSx3QkFBRTtBQUFBLHdCQUFJaEYsTUFBTXVDLEVBQUVTLEtBQUtDLEtBQUs7QUFBQSx3QkFDcERWLEVBQUVNLGdCQUFnQixTQUFTLFFBQVE7QUFBQSx3QkFDbkNOLEVBQUVDLGFBQWF5QyxRQUFRLE1BQU0xQyxFQUFFQyxhQUFheUMsSUFBSTtBQUFBLDJCQUhuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUlBO0FBQUEseUJBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBbUJBO0FBQUEsb0JBRUEsdUJBQUMsVUFBSyxXQUFVLDBEQUNkO0FBQUEsNkNBQUMsT0FBSSxNQUFNLElBQUksZUFBVyxRQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUEwQjtBQUFBLHNCQUN6QjFDLEVBQUVhO0FBQUFBLHlCQUZMO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBR0E7QUFBQSxvQkFFQSx1QkFBQyxxQkFBa0IsY0FBY2IsRUFBRUMsZ0JBQW5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWdEO0FBQUEsb0JBQ2hELHVCQUFDLGNBQVcsY0FBY0QsRUFBRTJDLGNBQWMsU0FBTyxRQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFpRDtBQUFBLG9CQUVqRDtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxXQUFXM0U7QUFBQUEsMEJBQ1Q7QUFBQSwwQkFDQUosUUFBUW9DLEVBQUVZLFdBQVcsSUFBSSxnQ0FBZ0M7QUFBQSx3QkFDM0Q7QUFBQSx3QkFFQ2pELDJCQUFpQnFDLEVBQUVZLFdBQVc7QUFBQTtBQUFBLHNCQU5qQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBT0E7QUFBQSxvQkFFQSx1QkFBQyxRQUFLLElBQUksU0FBU1osRUFBRVIsRUFBRSxJQUFJLFdBQVUsWUFDbkMsaUNBQUMsVUFBTyxNQUFLLE1BQUssU0FBUSxhQUN4QjtBQUFBLDZDQUFDLFVBQU8sTUFBTSxJQUFJLGVBQVcsUUFBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBNkI7QUFBQSxzQkFDN0IsdUJBQUMsVUFBSyxXQUFVLG9CQUFvQnBCLFlBQUUsZ0JBQWdCLEtBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQXdEO0FBQUEseUJBRjFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBR0EsS0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUtBO0FBQUEsb0JBRUEsdUJBQUMsV0FBTSxXQUFVLFlBQ2Y7QUFBQSw2Q0FBQyxVQUFLLFdBQVUsV0FBVTtBQUFBO0FBQUEsd0JBQWtCNEIsRUFBRWtDO0FBQUFBLDJCQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFtRDtBQUFBLHNCQUNuRDtBQUFBLHdCQUFDO0FBQUE7QUFBQSwwQkFDQyxPQUFPbEMsRUFBRUMsYUFBYUM7QUFBQUEsMEJBQ3RCLFVBQVVuQixTQUFTaUIsRUFBRVI7QUFBQUEsMEJBQ3JCLFVBQVUsQ0FBQ29ELE1BQU0sS0FBS3ZCLFVBQVVyQixFQUFFUixJQUFJb0QsRUFBRUMsT0FBT0MsS0FBMkI7QUFBQSwwQkFDMUUsV0FBVTtBQUFBLDBCQUVSQyxpQkFBT0MsS0FBS2pGLGtCQUFrQixFQUEyQnNCO0FBQUFBLDRCQUFJLENBQUM0RCxPQUM5RCx1QkFBQyxZQUFnQixPQUFPQSxJQUNyQmxGLDZCQUFtQmtGLEVBQUUsS0FEWEEsSUFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1DQUVBO0FBQUEsMEJBQ0Q7QUFBQTtBQUFBLHdCQVZIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFXQTtBQUFBLHlCQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBY0E7QUFBQTtBQUFBO0FBQUEsZ0JBbEVLakQsRUFBRVI7QUFBQUEsZ0JBRFQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQW9FQTtBQUFBLFlBRUosQ0FBQztBQUFBLGVBbkZIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBb0ZBO0FBQUEsYUEvR0trQyxTQUFTbEMsSUFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWlIQTtBQUFBLE1BRUosQ0FBQyxLQTFISDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBMkhBO0FBQUEsTUFHQSx1QkFBQyxTQUFJLFdBQVUsd0RBQ2I7QUFBQSwrQkFBQyxTQUNDO0FBQUEsaUNBQUMsUUFBRyxXQUFVLDJDQUEwQyx5QkFBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBaUU7QUFBQSxVQUNqRSx1QkFBQyxPQUFFLFdBQVUsMkJBQXlCLDJFQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBS0E7QUFBQSxRQUNBLHVCQUFDLFFBQUssSUFBRyxhQUNQLGlDQUFDLFVBQU8sU0FBUSxhQUFZLE1BQUssTUFDL0I7QUFBQSxpQ0FBQyxrQkFBZSxNQUFNLElBQUksZUFBVyxRQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFxQztBQUFBO0FBQUEsYUFEdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBLEtBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUtBO0FBQUEsV0FaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBYUE7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSxRQUNadUIsdUJBQWFwQixXQUFXLElBQ3ZCLHVCQUFDLFNBQUksV0FBVSxrR0FDYjtBQUFBLCtCQUFDLFVBQUssV0FBVSx3RkFDZCxpQ0FBQyxTQUFNLE1BQU0sSUFBSSxlQUFXLFFBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNEIsS0FEOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxRQUFHLFdBQVUsbUNBQWtDLGlDQUFoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWlFO0FBQUEsUUFDakUsdUJBQUMsT0FBRSxXQUFVLHNDQUFvQyxtR0FBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxRQUFLLElBQUcsYUFBWSxXQUFVLFFBQzdCLGlDQUFDLFVBQU8sU0FBUSxhQUFZLE1BQUssTUFBSSw2QkFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUlBO0FBQUEsV0FaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBYUEsSUFFQSx1QkFBQyxRQUFHLFdBQVUsYUFDWG9CLHVCQUFhMUI7QUFBQUEsUUFBSSxDQUFDNkQsUUFDakIsdUJBQUMsY0FBd0IsU0FBU0EsS0FBSyxRQUFnQixXQUFXM0UsV0FBakQyRSxJQUFJMUQsSUFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwRTtBQUFBLE1BQzNFLEtBSEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUlBLEtBckJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF1QkE7QUFBQSxNQUVBLHVCQUFDLE9BQUUsV0FBVSx5R0FBdUcsK0pBQXBIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLFNBM05GO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E0TkE7QUFBQSxPQTFPRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBMk9BO0FBRUo7QUFBQ3JCLEdBcFN1QkQsV0FBUztBQUFBLFVBQ2pCRCxTQUNvQ2hCLFNBQVM7QUFBQTtBQUFBLEtBRnJDaUI7QUFzU3hCLFNBQVNpRixLQUFLO0FBQUEsRUFDWkMsTUFBTUM7QUFBQUEsRUFDTkM7QUFBQUEsRUFDQVI7QUFBQUEsRUFDQVM7QUFBQUEsRUFDQUM7QUFPRixHQUFHO0FBQ0QsU0FDRSx1QkFBQyxTQUFJLFdBQVUsb0RBQ2I7QUFBQSwyQkFBQyxRQUFHLFdBQVUsOENBQ1o7QUFBQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsTUFBTTtBQUFBLFVBQ047QUFBQSxVQUNBLFdBQVdBLFNBQVMsT0FBTyxnQkFBZ0JBLFNBQVMsU0FBUyxrQkFBa0I7QUFBQTtBQUFBLFFBSGpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUdpRztBQUFBLE1BRWhHRjtBQUFBQSxTQU5IO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FPQTtBQUFBLElBQ0EsdUJBQUMsUUFBRyxXQUFVLHNEQUFzRFIsbUJBQXBFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBMEU7QUFBQSxJQUN6RVMsUUFBUSx1QkFBQyxPQUFFLFdBQVUsd0NBQXdDQSxrQkFBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEwRDtBQUFBLE9BVnJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FXQTtBQUVKO0FBQUNFLE1BM0JRTjtBQTZCVCxNQUFNTyxjQUFtQyxDQUFDLE9BQU8sYUFBYSxjQUFjLFFBQVE7QUFFcEYsU0FBU0MsV0FBVztBQUFBLEVBQ2xCQztBQUFBQSxFQUNBakY7QUFBQUEsRUFDQWtGO0FBS0YsR0FBRztBQUNELFFBQU12QyxRQUFRM0MsT0FBTzRDLEtBQUssQ0FBQ3ZCLE1BQU1BLEVBQUVSLE9BQU9vRSxRQUFReEMsT0FBTztBQUV6RCxTQUNFLHVCQUFDLFFBQUcsV0FBVSxvREFDWjtBQUFBLDJCQUFDLFNBQUksV0FBVSxvREFDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSxXQUNiO0FBQUEsK0JBQUMsT0FBRSxXQUFVLDBCQUNWd0M7QUFBQUEsa0JBQVExQjtBQUFBQSxVQUNULHVCQUFDLFVBQUssV0FBVSwrQkFBOEI7QUFBQTtBQUFBLFlBQUlaLE9BQU9ZLFFBQVEwQixRQUFReEM7QUFBQUEsZUFBekU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBaUY7QUFBQSxhQUZuRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUNBLHVCQUFDLE9BQUUsV0FBVSw4Q0FBOEN3QyxrQkFBUUUsV0FBbkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEyRTtBQUFBLFdBTDdFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFNQTtBQUFBLE1BRUEsdUJBQUMsV0FBTSxXQUFVLFlBQ2Y7QUFBQSwrQkFBQyxVQUFLLFdBQVUsV0FBVSx1Q0FBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpRDtBQUFBLFFBQ2pEO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxPQUFPRixRQUFRMUQ7QUFBQUEsWUFDZixVQUFVLE9BQU8wQyxNQUFNO0FBQ3JCLG9CQUFNMUYsR0FBRzZHLGlCQUFpQkgsUUFBUXBFLElBQUlvRCxFQUFFQyxPQUFPQyxLQUEwQjtBQUN6RSxvQkFBTWUsVUFBVTtBQUFBLFlBQ2xCO0FBQUEsWUFDQSxXQUFVO0FBQUEsWUFFVEgsc0JBQVlyRTtBQUFBQSxjQUFJLENBQUNXLE1BQ2hCLHVCQUFDLFlBQWUsT0FBT0EsR0FDcEJBLGVBRFVBLEdBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLFlBQ0Q7QUFBQTtBQUFBLFVBWkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBYUE7QUFBQSxXQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFnQkE7QUFBQSxTQXpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBMEJBO0FBQUEsSUFFQSx1QkFBQyxRQUFHLFdBQVUsdUNBQ1o7QUFBQSw2QkFBQyxRQUFHLFdBQVUsc0VBQW9FO0FBQUE7QUFBQSxRQUN4RXZDLE1BQU1tRyxRQUFRSSxTQUFTO0FBQUEsUUFBRTtBQUFBLFFBQUV2RyxNQUFNbUcsUUFBUUssU0FBUztBQUFBLFdBRDVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsUUFBRyxXQUFVLHNFQUFvRTtBQUFBO0FBQUEsUUFDeEVwRyxTQUFTK0YsUUFBUU0sVUFBVTtBQUFBLFdBRHJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU9BO0FBQUEsT0FwQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXFDQTtBQUVKO0FBQUNDLE1BbkRRUjtBQUFVLElBQUFTLElBQUFYLEtBQUFVO0FBQUEsYUFBQUMsSUFBQTtBQUFBLGFBQUFYLEtBQUE7QUFBQSxhQUFBVSxLQUFBIiwibmFtZXMiOlsidXNlQ2FsbGJhY2siLCJ1c2VFZmZlY3QiLCJ1c2VNZW1vIiwidXNlU3RhdGUiLCJMaW5rIiwiUGx1cyIsIkNoZXZyb25Eb3duIiwiQnVpbGRpbmcyIiwiSW5ib3giLCJDaXJjbGVDaGVjayIsIldyZW5jaCIsIkNpcmNsZURvdCIsIlRyZW5kaW5nVXAiLCJFeWUiLCJNZXNzYWdlc1NxdWFyZSIsIlBlbmNpbCIsInVzZUhhYml0byIsImRiIiwiUGFnZUhlYWRlciIsIkJ1dHRvbiIsIkNvYWNobWFyayIsIkF2YWlsYWJpbGl0eUJhZGdlIiwiVHJ1c3RCYWRnZSIsIkNBVEVHT1JZX1NUWUxFIiwibW9uZXkiLCJtb25leUNvbXBhY3QiLCJsYXN0VXBkYXRlZFNob3J0IiwiaXNTdGFsZSIsImxvbmdEYXRlIiwiU1BBQ0VfVFlQRV9MQUJFTCIsIkFWQUlMQUJJTElUWV9MQUJFTCIsImNuIiwidXNlSTE4biIsIlBvcnRmb2xpbyIsIl9zIiwidCIsIm93bmVySWQiLCJpbnF1aXJpZXMiLCJyZWZyZXNoIiwibGlzdGluZ3MiLCJwcm9wZXJ0aWVzIiwic2V0UHJvcGVydGllcyIsInNwYWNlcyIsInNldFNwYWNlcyIsIm9wZW4iLCJzZXRPcGVuIiwiYnVzeSIsInNldEJ1c3kiLCJsb2FkIiwicHJvcHMiLCJhbGwiLCJQcm9taXNlIiwibWFwIiwicCIsInNwYWNlc09mUHJvcGVydHkiLCJpZCIsImZsYXQiLCJwcmV2IiwibGVuZ3RoIiwic2xpY2UiLCJzdGF0cyIsImF2YWlsYWJsZSIsImZpbHRlciIsInMiLCJhdmFpbGFiaWxpdHkiLCJzdGF0dXMiLCJvY2N1cGllZCIsIm1haW50ZW5hbmNlIiwicG90ZW50aWFsIiwidHJhbnNhY3Rpb24iLCJyZWR1Y2UiLCJzdW0iLCJjb3N0IiwicHJpY2UiLCJuZWVkc1VwZGF0ZSIsImxhc3RVcGRhdGVkIiwidmlld3MiLCJ4Iiwib3duSW5xdWlyaWVzIiwiaWRzIiwiU2V0IiwiaSIsImhhcyIsInNwYWNlSWQiLCJzZXRTdGF0dXMiLCJzcGFjZSIsImZpbmQiLCJ1cGRhdGVTcGFjZSIsIlN0cmluZyIsInByb3BlcnR5Iiwib3duIiwicHJvcGVydHlJZCIsImV4cGFuZGVkIiwiaW5jbHVkZXMiLCJmcmVlIiwibyIsImNvdmVySW1hZ2UiLCJuYW1lIiwibmVpZ2hib3Job29kIiwiYXJlYSIsInN5bnRoZXRpYyIsImNhdCIsImNhdGVnb3J5IiwiY2hpcCIsInNwYWNlVHlwZSIsIm5vdGUiLCJ2ZXJpZmljYXRpb24iLCJlIiwidGFyZ2V0IiwidmFsdWUiLCJPYmplY3QiLCJrZXlzIiwic3QiLCJpbnEiLCJTdGF0IiwiaWNvbiIsIkljb24iLCJsYWJlbCIsImhpbnQiLCJ0b25lIiwiX2MyIiwiU1RBVFVTX0ZMT1ciLCJJbnF1aXJ5Um93IiwiaW5xdWlyeSIsIm9uQ2hhbmdlZCIsIm1lc3NhZ2UiLCJzZXRJbnF1aXJ5U3RhdHVzIiwiYnVkZ2V0TWluIiwiYnVkZ2V0TWF4IiwibW92ZUluRGF0ZSIsIl9jMyIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlBvcnRmb2xpby50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlQ2FsbGJhY2ssIHVzZUVmZmVjdCwgdXNlTWVtbywgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IExpbmsgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xuaW1wb3J0IHtcbiAgUGx1cywgQ2hldnJvbkRvd24sIEJ1aWxkaW5nMiwgSW5ib3gsIENpcmNsZUNoZWNrLCBXcmVuY2gsIENpcmNsZURvdCwgVHJlbmRpbmdVcCwgRXllLCBNZXNzYWdlc1NxdWFyZSwgUGVuY2lsLFxufSBmcm9tIFwibHVjaWRlLXJlYWN0XCI7XG5pbXBvcnQgeyB1c2VIYWJpdG8gfSBmcm9tIFwiQC9ob29rcy91c2VIYWJpdG9cIjtcbmltcG9ydCB7IGRiIH0gZnJvbSBcIkAvbGliL2FwaVwiO1xuaW1wb3J0IHsgUGFnZUhlYWRlciB9IGZyb20gXCJAL2NvbXBvbmVudHMvbGF5b3V0L1BhZ2VIZWFkZXJcIjtcbmltcG9ydCB7IEJ1dHRvbiB9IGZyb20gXCJAL2NvbXBvbmVudHMvdWkvQnV0dG9uXCI7XG5pbXBvcnQgeyBDb2FjaG1hcmsgfSBmcm9tIFwiQC9jb21wb25lbnRzL3VpL0NvYWNobWFya1wiO1xuaW1wb3J0IHsgQXZhaWxhYmlsaXR5QmFkZ2UsIFRydXN0QmFkZ2UgfSBmcm9tIFwiQC9jb21wb25lbnRzL3NwYWNlL2JhZGdlc1wiO1xuaW1wb3J0IHsgQ0FURUdPUllfU1RZTEUgfSBmcm9tIFwiQC9kYXRhL2NhdGFsb2dcIjtcbmltcG9ydCB7IG1vbmV5LCBtb25leUNvbXBhY3QsIGxhc3RVcGRhdGVkU2hvcnQsIGlzU3RhbGUsIGxvbmdEYXRlIH0gZnJvbSBcIkAvbGliL2Zvcm1hdFwiO1xuaW1wb3J0IHsgU1BBQ0VfVFlQRV9MQUJFTCwgQVZBSUxBQklMSVRZX0xBQkVMIH0gZnJvbSBcIkAvdHlwZXMvc3BhY2VcIjtcbmltcG9ydCB0eXBlIHsgQXZhaWxhYmlsaXR5U3RhdHVzLCBJbnF1aXJ5LCBQcm9wZXJ0eSwgU3BhY2UgfSBmcm9tIFwiQC90eXBlcy9zcGFjZVwiO1xuaW1wb3J0IHsgY24gfSBmcm9tIFwiQC9saWIvY25cIjtcbmltcG9ydCB7IHVzZUkxOG4gfSBmcm9tIFwiQC9pMThuXCI7XG5cbi8qKlxuICogVGhlIHBvcnRmb2xpbyBpcyB0aGUgY2VudHJlIG9mIHRoZSBvd25lciBzdG9yeTogb25lIG93bmVyLCBzZXZlcmFsXG4gKiBwcm9wZXJ0aWVzLCBtYW55IGtpbmRzIG9mIHNwYWNlIGluc2lkZSBlYWNoIOKAlCBhbGwgdmlzaWJsZSBhdCBvbmNlLlxuICovXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBQb3J0Zm9saW8oKSB7XG4gIGNvbnN0IHsgdCB9ID0gdXNlSTE4bigpO1xuICBjb25zdCB7IG93bmVySWQsIGlucXVpcmllcywgcmVmcmVzaCwgbGlzdGluZ3MgfSA9IHVzZUhhYml0bygpO1xuICBjb25zdCBbcHJvcGVydGllcywgc2V0UHJvcGVydGllc10gPSB1c2VTdGF0ZTxQcm9wZXJ0eVtdPihbXSk7XG4gIGNvbnN0IFtzcGFjZXMsIHNldFNwYWNlc10gPSB1c2VTdGF0ZTxTcGFjZVtdPihbXSk7XG4gIGNvbnN0IFtvcGVuLCBzZXRPcGVuXSA9IHVzZVN0YXRlPHN0cmluZ1tdPihbXSk7XG4gIGNvbnN0IFtidXN5LCBzZXRCdXN5XSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xuXG4gIGNvbnN0IGxvYWQgPSB1c2VDYWxsYmFjayhhc3luYyAoKSA9PiB7XG4gICAgY29uc3QgcHJvcHMgPSBhd2FpdCBkYi5wcm9wZXJ0aWVzKG93bmVySWQpO1xuICAgIGNvbnN0IGFsbCA9IGF3YWl0IFByb21pc2UuYWxsKHByb3BzLm1hcCgocCkgPT4gZGIuc3BhY2VzT2ZQcm9wZXJ0eShwLmlkKSkpO1xuICAgIHNldFByb3BlcnRpZXMocHJvcHMpO1xuICAgIHNldFNwYWNlcyhhbGwuZmxhdCgpKTtcbiAgICBzZXRPcGVuKChwcmV2KSA9PiAocHJldi5sZW5ndGggPyBwcmV2IDogcHJvcHMuc2xpY2UoMCwgMikubWFwKChwKSA9PiBwLmlkKSkpO1xuICB9LCBbb3duZXJJZF0pO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgdm9pZCBsb2FkKCk7XG4gIH0sIFtsb2FkLCBsaXN0aW5nc10pO1xuXG4gIGNvbnN0IHN0YXRzID0gdXNlTWVtbygoKSA9PiB7XG4gICAgY29uc3QgYXZhaWxhYmxlID0gc3BhY2VzLmZpbHRlcigocykgPT4gcy5hdmFpbGFiaWxpdHkuc3RhdHVzID09PSBcImF2YWlsYWJsZVwiIHx8IHMuYXZhaWxhYmlsaXR5LnN0YXR1cyA9PT0gXCJwYXJ0aWFsbHktYXZhaWxhYmxlXCIpO1xuICAgIGNvbnN0IG9jY3VwaWVkID0gc3BhY2VzLmZpbHRlcigocykgPT4gcy5hdmFpbGFiaWxpdHkuc3RhdHVzID09PSBcIm9jY3VwaWVkXCIpO1xuICAgIGNvbnN0IG1haW50ZW5hbmNlID0gc3BhY2VzLmZpbHRlcigocykgPT4gcy5hdmFpbGFiaWxpdHkuc3RhdHVzID09PSBcIm1haW50ZW5hbmNlXCIpO1xuICAgIGNvbnN0IHBvdGVudGlhbCA9IHNwYWNlc1xuICAgICAgLmZpbHRlcigocykgPT4gcy50cmFuc2FjdGlvbiA9PT0gXCJyZW50XCIpXG4gICAgICAucmVkdWNlKChzdW0sIHMpID0+IHN1bSArIHMuY29zdC5wcmljZSwgMCk7XG4gICAgY29uc3QgbmVlZHNVcGRhdGUgPSBzcGFjZXMuZmlsdGVyKChzKSA9PiBpc1N0YWxlKHMubGFzdFVwZGF0ZWQpKS5sZW5ndGg7XG4gICAgcmV0dXJuIHtcbiAgICAgIGF2YWlsYWJsZTogYXZhaWxhYmxlLmxlbmd0aCxcbiAgICAgIG9jY3VwaWVkOiBvY2N1cGllZC5sZW5ndGgsXG4gICAgICBtYWludGVuYW5jZTogbWFpbnRlbmFuY2UubGVuZ3RoLFxuICAgICAgcG90ZW50aWFsLFxuICAgICAgbmVlZHNVcGRhdGUsXG4gICAgICB2aWV3czogc3BhY2VzLnJlZHVjZSgocywgeCkgPT4gcyArIHgudmlld3MsIDApLFxuICAgIH07XG4gIH0sIFtzcGFjZXNdKTtcblxuICBjb25zdCBvd25JbnF1aXJpZXMgPSB1c2VNZW1vKCgpID0+IHtcbiAgICBjb25zdCBpZHMgPSBuZXcgU2V0KHNwYWNlcy5tYXAoKHMpID0+IHMuaWQpKTtcbiAgICByZXR1cm4gaW5xdWlyaWVzLmZpbHRlcigoaSkgPT4gaWRzLmhhcyhpLnNwYWNlSWQpKTtcbiAgfSwgW2lucXVpcmllcywgc3BhY2VzXSk7XG5cbiAgY29uc3Qgc2V0U3RhdHVzID0gYXN5bmMgKHNwYWNlSWQ6IHN0cmluZywgc3RhdHVzOiBBdmFpbGFiaWxpdHlTdGF0dXMpID0+IHtcbiAgICBzZXRCdXN5KHNwYWNlSWQpO1xuICAgIGNvbnN0IHNwYWNlID0gc3BhY2VzLmZpbmQoKHMpID0+IHMuaWQgPT09IHNwYWNlSWQpO1xuICAgIGlmIChzcGFjZSkge1xuICAgICAgYXdhaXQgZGIudXBkYXRlU3BhY2Uoc3BhY2VJZCwgeyBhdmFpbGFiaWxpdHk6IHsgLi4uc3BhY2UuYXZhaWxhYmlsaXR5LCBzdGF0dXMgfSB9KTtcbiAgICAgIGF3YWl0IGxvYWQoKTtcbiAgICAgIGF3YWl0IHJlZnJlc2goKTtcbiAgICB9XG4gICAgc2V0QnVzeShudWxsKTtcbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDw+XG4gICAgICA8UGFnZUhlYWRlclxuICAgICAgICB0aXRsZT17dChcInBvcnRmb2xpby50aXRsZVwiKX1cbiAgICAgICAgbGVhZD1cIkV2ZXJ5IHByb3BlcnR5IHlvdSBob2xkIGFuZCBldmVyeSBzcGFjZSBpbnNpZGUgaXQsIGluIG9uZSB2aWV3LlwiXG4gICAgICAgIGFjdGlvbnM9e1xuICAgICAgICAgIDxMaW5rIHRvPVwiL2xpc3RcIj5cbiAgICAgICAgICAgIDxCdXR0b24+XG4gICAgICAgICAgICAgIDxQbHVzIHNpemU9ezE2fSBhcmlhLWhpZGRlbiAvPlxuICAgICAgICAgICAgICBBZGQgYSBzcGFjZVxuICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgPC9MaW5rPlxuICAgICAgICB9XG4gICAgICAvPlxuXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbnRhaW5lci1wYWdlIHB5LTggbWQ6cHktMTBcIj5cbiAgICAgICAgPGRsIGNsYXNzTmFtZT1cImdyaWQgZ2FwLTMgc206Z3JpZC1jb2xzLTIgbGc6Z3JpZC1jb2xzLTVcIj5cbiAgICAgICAgICA8U3RhdCBpY29uPXtCdWlsZGluZzJ9IGxhYmVsPVwiUHJvcGVydGllc1wiIHZhbHVlPXtTdHJpbmcocHJvcGVydGllcy5sZW5ndGgpfSAvPlxuICAgICAgICAgIDxTdGF0IGljb249e0NpcmNsZUNoZWNrfSBsYWJlbD1cIkF2YWlsYWJsZVwiIHZhbHVlPXtTdHJpbmcoc3RhdHMuYXZhaWxhYmxlKX0gdG9uZT1cIm9rXCIgLz5cbiAgICAgICAgICA8U3RhdCBpY29uPXtDaXJjbGVEb3R9IGxhYmVsPVwiT2NjdXBpZWRcIiB2YWx1ZT17U3RyaW5nKHN0YXRzLm9jY3VwaWVkKX0gLz5cbiAgICAgICAgICA8U3RhdCBpY29uPXtXcmVuY2h9IGxhYmVsPVwiTWFpbnRlbmFuY2VcIiB2YWx1ZT17U3RyaW5nKHN0YXRzLm1haW50ZW5hbmNlKX0gdG9uZT1cIndhcm5cIiAvPlxuICAgICAgICAgIDxTdGF0XG4gICAgICAgICAgICBpY29uPXtUcmVuZGluZ1VwfVxuICAgICAgICAgICAgbGFiZWw9XCJQb3RlbnRpYWwgbW9udGhseVwiXG4gICAgICAgICAgICB2YWx1ZT17bW9uZXlDb21wYWN0KHN0YXRzLnBvdGVudGlhbCl9XG4gICAgICAgICAgICBoaW50PVwiSWYgZXZlcnkgcmVudGFibGUgc3BhY2Ugd2VyZSBsZXQgYXQgaXRzIGxpc3RlZCBwcmljZVwiXG4gICAgICAgICAgLz5cbiAgICAgICAgPC9kbD5cblxuICAgICAgICB7c3RhdHMubmVlZHNVcGRhdGUgPiAwICYmIChcbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC00IHJvdW5kZWQtY2FyZCBiZy13YXJuLTEwMCBwLTQgdGV4dC1zbSB0ZXh0LXdhcm4tNzAwXCI+XG4gICAgICAgICAgICA8c3Ryb25nIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGRcIj57c3RhdHMubmVlZHNVcGRhdGV9IHNwYWNle3N0YXRzLm5lZWRzVXBkYXRlID4gMSA/IFwic1wiIDogXCJcIn08L3N0cm9uZz57XCIgXCJ9XG4gICAgICAgICAgICB7c3RhdHMubmVlZHNVcGRhdGUgPT09IDEgPyBcImhhc24ndFwiIDogXCJoYXZlbid0XCJ9IGJlZW4gdXBkYXRlZCBpbiBvdmVyIHRocmVlIHdlZWtzLiBDb25maXJtaW5nIGF2YWlsYWJpbGl0eSBrZWVwcyB0aGVtIHJhbmtpbmcgaW4gc2VhcmNoLlxuICAgICAgICAgIDwvcD5cbiAgICAgICAgKX1cblxuICAgICAgICB7LyogSGllcmFyY2h5ICovfVxuICAgICAgICA8Q29hY2htYXJrXG4gICAgICAgICAgaWQ9XCJwcm9wZXJ0eVwiXG4gICAgICAgICAgdGl0bGVLZXk9XCJjb2FjaC5wcm9wZXJ0eVRpdGxlXCJcbiAgICAgICAgICBib2R5S2V5PVwiY29hY2gucHJvcGVydHlCb2R5XCJcbiAgICAgICAgICBjbGFzc05hbWU9XCJtdC02XCJcbiAgICAgICAgLz5cblxuICAgICAgICA8aDIgY2xhc3NOYW1lPVwibXQtMTAgZm9udC1kaXNwbGF5IHRleHQteGwgZm9udC1ib2xkIHRleHQtaW5rXCI+UHJvcGVydGllczwvaDI+XG5cbiAgICAgICAge3Byb3BlcnRpZXMubGVuZ3RoID09PSAwICYmIChcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTMgZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIgcm91bmRlZC1jYXJkIGJnLXN1cmZhY2UgcHgtNiBweS0xMiB0ZXh0LWNlbnRlciByaW5nLTEgcmluZy1oYWlybGluZVwiPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWItMyBmbGV4IHNpemUtMTEgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHJvdW5kZWQtZnVsbCBiZy1hcXVhLTEwMCB0ZXh0LWFxdWEtNzAwXCI+XG4gICAgICAgICAgICAgIDxCdWlsZGluZzIgc2l6ZT17MjB9IGFyaWEtaGlkZGVuIC8+XG4gICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwiZm9udC1kaXNwbGF5IGZvbnQtYm9sZCB0ZXh0LWlua1wiPllvdSBoYXZlbid0IGFkZGVkIGEgcHJvcGVydHkgeWV0LjwvaDM+XG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0xLjUgbWF4LXctc20gdGV4dC1zbSBsZWFkaW5nLXJlbGF4ZWQgdGV4dC1tdXRlZFwiPlxuICAgICAgICAgICAgICBBIHByb3BlcnR5IGlzIHRoZSBidWlsZGluZywgaG91c2Ugb3IgcGxvdC4gSW5zaWRlIGl0IHlvdSBhZGQgdGhlIHNwYWNlcyBwZW9wbGVcbiAgICAgICAgICAgICAgYWN0dWFsbHkgcmVudCDigJQgZmxhdHMsIGEgc2hvcCwgdGhlIGdhcmFnZS5cbiAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgIDxMaW5rIHRvPVwiL2xpc3RcIiBjbGFzc05hbWU9XCJtdC00XCI+XG4gICAgICAgICAgICAgIDxCdXR0b24gc2l6ZT1cInNtXCI+XG4gICAgICAgICAgICAgICAgPFBsdXMgc2l6ZT17MTV9IGFyaWEtaGlkZGVuIC8+XG4gICAgICAgICAgICAgICAgQWRkIHlvdXIgZmlyc3Qgc3BhY2VcbiAgICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgICA8L0xpbms+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICl9XG5cbiAgICAgICAgPHVsIGNsYXNzTmFtZT1cIm10LTMgc3BhY2UteS0zXCI+XG4gICAgICAgICAge3Byb3BlcnRpZXMubWFwKChwcm9wZXJ0eSkgPT4ge1xuICAgICAgICAgICAgY29uc3Qgb3duID0gc3BhY2VzLmZpbHRlcigocykgPT4gcy5wcm9wZXJ0eUlkID09PSBwcm9wZXJ0eS5pZCk7XG4gICAgICAgICAgICBjb25zdCBleHBhbmRlZCA9IG9wZW4uaW5jbHVkZXMocHJvcGVydHkuaWQpO1xuICAgICAgICAgICAgY29uc3QgZnJlZSA9IG93bi5maWx0ZXIoKHMpID0+IHMuYXZhaWxhYmlsaXR5LnN0YXR1cyA9PT0gXCJhdmFpbGFibGVcIiB8fCBzLmF2YWlsYWJpbGl0eS5zdGF0dXMgPT09IFwicGFydGlhbGx5LWF2YWlsYWJsZVwiKS5sZW5ndGg7XG5cbiAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgIDxsaSBrZXk9e3Byb3BlcnR5LmlkfSBjbGFzc05hbWU9XCJvdmVyZmxvdy1oaWRkZW4gcm91bmRlZC1jYXJkIGJnLXN1cmZhY2UgcmluZy0xIHJpbmctaGFpcmxpbmVcIj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldE9wZW4oKG8pID0+IChleHBhbmRlZCA/IG8uZmlsdGVyKCh4KSA9PiB4ICE9PSBwcm9wZXJ0eS5pZCkgOiBbLi4ubywgcHJvcGVydHkuaWRdKSl9XG4gICAgICAgICAgICAgICAgICBhcmlhLWV4cGFuZGVkPXtleHBhbmRlZH1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggdy1mdWxsIGl0ZW1zLWNlbnRlciBnYXAtNCBwLTQgdGV4dC1sZWZ0IHRyYW5zaXRpb24tY29sb3JzIGhvdmVyOmJnLWl2b3J5XCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8aW1nIHNyYz17cHJvcGVydHkuY292ZXJJbWFnZX0gYWx0PVwiXCIgY2xhc3NOYW1lPVwic2l6ZS0xNCBzaHJpbmstMCByb3VuZGVkLXhsIG9iamVjdC1jb3ZlclwiIC8+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi13LTAgZmxleC0xXCI+XG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRydW5jYXRlIGZvbnQtZGlzcGxheSBmb250LWJvbGQgdGV4dC1pbmtcIj57cHJvcGVydHkubmFtZX08L3A+XG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRydW5jYXRlIHRleHQtc20gdGV4dC1tdXRlZFwiPlxuICAgICAgICAgICAgICAgICAgICAgIHtwcm9wZXJ0eS5uZWlnaGJvcmhvb2R9LCB7cHJvcGVydHkuYXJlYX1cbiAgICAgICAgICAgICAgICAgICAgICB7IXByb3BlcnR5LnN5bnRoZXRpYyAmJiA8c3BhbiBjbGFzc05hbWU9XCJtbC0yIGZvbnQtc2VtaWJvbGQgdGV4dC1hcXVhLTcwMFwiPsK3IGFkZGVkIGJ5IHlvdTwvc3Bhbj59XG4gICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoaWRkZW4gc2hyaW5rLTAgdGV4dC1yaWdodCBzbTpibG9ja1wiPlxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdG51bSB0ZXh0LWlua1wiPntvd24ubGVuZ3RofSB7b3duLmxlbmd0aCA9PT0gMSA/IFwic3BhY2VcIiA6IFwic3BhY2VzXCJ9PC9wPlxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRudW0gdGV4dC1vay02MDBcIj57ZnJlZX0gYXZhaWxhYmxlPC9wPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8Q2hldnJvbkRvd25cbiAgICAgICAgICAgICAgICAgICAgc2l6ZT17MTh9XG4gICAgICAgICAgICAgICAgICAgIGFyaWEtaGlkZGVuXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17Y24oXCJzaHJpbmstMCB0ZXh0LW11dGVkIHRyYW5zaXRpb24tdHJhbnNmb3JtXCIsIGV4cGFuZGVkICYmIFwicm90YXRlLTE4MFwiKX1cbiAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICAgICAgICB7ZXhwYW5kZWQgJiYgKFxuICAgICAgICAgICAgICAgICAgPHVsIGNsYXNzTmFtZT1cImJvcmRlci10IGJvcmRlci1oYWlybGluZVwiPlxuICAgICAgICAgICAgICAgICAgICB7b3duLmxlbmd0aCA9PT0gMCAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgPGxpIGNsYXNzTmFtZT1cInB4LTQgcHktNiB0ZXh0LWNlbnRlciB0ZXh0LXNtIHRleHQtbXV0ZWRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIE5vIHNwYWNlcyBoZXJlIHlldC57XCIgXCJ9XG4gICAgICAgICAgICAgICAgICAgICAgICA8TGluayB0bz1cIi9saXN0XCIgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWFxdWEtNzAwIGhvdmVyOnVuZGVybGluZVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICBBZGQgb25lXG4gICAgICAgICAgICAgICAgICAgICAgICA8L0xpbms+XG4gICAgICAgICAgICAgICAgICAgICAgICAuXG4gICAgICAgICAgICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAge293bi5tYXAoKHMpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICBjb25zdCBjYXQgPSBDQVRFR09SWV9TVFlMRVtzLmNhdGVnb3J5XTtcbiAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgPGxpXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17cy5pZH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgaXRlbXMtY2VudGVyIGdhcC14LTQgZ2FwLXktMiBib3JkZXItYiBib3JkZXItaGFpcmxpbmUgcHgtNCBweS0zIGxhc3Q6Ym9yZGVyLTBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2NuKFwiZmxleCBzaXplLTggc2hyaW5rLTAgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHJvdW5kZWQtbGdcIiwgY2F0LmNoaXApfT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Y2F0Lmljb24gc2l6ZT17MTV9IGFyaWEtaGlkZGVuIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi13LTAgZmxleC0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPExpbmsgdG89e2Avc3BhY2UvJHtzLmlkfWB9IGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1pbmsgaG92ZXI6dGV4dC1hcXVhLTcwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3MubmFtZX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0xpbms+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3Muc3RhdHVzID09PSBcImFyY2hpdmVkXCIgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWwtMiByb3VuZGVkLWZ1bGwgYmctaXZvcnktZGVlcCBweC0yIHB5LTAuNSB0ZXh0LVswLjY1cmVtXSBmb250LXNlbWlib2xkIHRleHQtbXV0ZWRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3QoXCJlZGl0LmFyY2hpdmVcIil9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cy5zdGF0dXMgPT09IFwiYXJjaGl2ZWRcIiAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtbC0yIHJvdW5kZWQtZnVsbCBiZy1pdm9yeS1kZWVwIHB4LTIgcHktMC41IHRleHQtWzAuNjVyZW1dIGZvbnQtc2VtaWJvbGQgdGV4dC1tdXRlZFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBBcmNoaXZlZFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LW11dGVkXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7U1BBQ0VfVFlQRV9MQUJFTFtzLnNwYWNlVHlwZV19IMK3IHttb25leShzLmNvc3QucHJpY2UpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3MudHJhbnNhY3Rpb24gPT09IFwicmVudFwiID8gXCIvbW9cIiA6IFwiIHNhbGVcIn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtzLmF2YWlsYWJpbGl0eS5ub3RlICYmIGAgwrcgJHtzLmF2YWlsYWJpbGl0eS5ub3RlfWB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgdGV4dC14cyB0bnVtIHRleHQtbXV0ZWRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RXllIHNpemU9ezEzfSBhcmlhLWhpZGRlbiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtzLnZpZXdzfVxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPEF2YWlsYWJpbGl0eUJhZGdlIGF2YWlsYWJpbGl0eT17cy5hdmFpbGFiaWxpdHl9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxUcnVzdEJhZGdlIHZlcmlmaWNhdGlvbj17cy52ZXJpZmljYXRpb259IGNvbXBhY3QgLz5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcInctMTYgdGV4dC1yaWdodCB0ZXh0LXhzXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpc1N0YWxlKHMubGFzdFVwZGF0ZWQpID8gXCJmb250LXNlbWlib2xkIHRleHQtd2Fybi03MDBcIiA6IFwidGV4dC1tdXRlZFwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7bGFzdFVwZGF0ZWRTaG9ydChzLmxhc3RVcGRhdGVkKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxMaW5rIHRvPXtgL2xpc3QvJHtzLmlkfWB9IGNsYXNzTmFtZT1cInNocmluay0wXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJ1dHRvbiBzaXplPVwic21cIiB2YXJpYW50PVwic2Vjb25kYXJ5XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8UGVuY2lsIHNpemU9ezE0fSBhcmlhLWhpZGRlbiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaGlkZGVuIHNtOmlubGluZVwiPnt0KFwiZWRpdC5lZGl0U3BhY2VcIil9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L0xpbms+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInNocmluay0wXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwic3Itb25seVwiPkF2YWlsYWJpbGl0eSBmb3Ige3MubmFtZX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNlbGVjdFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3MuYXZhaWxhYmlsaXR5LnN0YXR1c31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtidXN5ID09PSBzLmlkfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB2b2lkIHNldFN0YXR1cyhzLmlkLCBlLnRhcmdldC52YWx1ZSBhcyBBdmFpbGFiaWxpdHlTdGF0dXMpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC05IHJvdW5kZWQtZnVsbCBiZy1pdm9yeSBweC0zIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LWluayByaW5nLTEgcmluZy1oYWlybGluZS1zdHJvbmcgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWFxdWEtNjAwXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7KE9iamVjdC5rZXlzKEFWQUlMQUJJTElUWV9MQUJFTCkgYXMgQXZhaWxhYmlsaXR5U3RhdHVzW10pLm1hcCgoc3QpID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiBrZXk9e3N0fSB2YWx1ZT17c3R9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtBVkFJTEFCSUxJVFlfTEFCRUxbc3RdfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgICAgICB9KX1cbiAgICAgICAgICAgICAgICAgIDwvdWw+XG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICAgICk7XG4gICAgICAgICAgfSl9XG4gICAgICAgIDwvdWw+XG5cbiAgICAgICAgey8qIElucXVpcmllcyAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0xMCBmbGV4IGZsZXgtd3JhcCBpdGVtcy1lbmQganVzdGlmeS1iZXR3ZWVuIGdhcC0zXCI+XG4gICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJmb250LWRpc3BsYXkgdGV4dC14bCBmb250LWJvbGQgdGV4dC1pbmtcIj5JbnF1aXJpZXM8L2gyPlxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXNtIHRleHQtbXV0ZWRcIj5cbiAgICAgICAgICAgICAgRWFjaCBvbmUgYXJyaXZlcyB3aXRoIHRoZSBzZW5kZXIncyBidWRnZXQgYW5kIG1vdmUtaW4gZGF0ZS5cbiAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8TGluayB0bz1cIi9tZXNzYWdlc1wiPlxuICAgICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwic2Vjb25kYXJ5XCIgc2l6ZT1cInNtXCI+XG4gICAgICAgICAgICAgIDxNZXNzYWdlc1NxdWFyZSBzaXplPXsxNX0gYXJpYS1oaWRkZW4gLz5cbiAgICAgICAgICAgICAgT3BlbiBtZXNzYWdlc1xuICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgPC9MaW5rPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTNcIj5cbiAgICAgICAgICB7b3duSW5xdWlyaWVzLmxlbmd0aCA9PT0gMCA/IChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIgcm91bmRlZC1jYXJkIGJnLXN1cmZhY2UgcHgtNiBweS0xMiB0ZXh0LWNlbnRlciByaW5nLTEgcmluZy1oYWlybGluZVwiPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtYi0zIGZsZXggc2l6ZS0xMSBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC1mdWxsIGJnLWFxdWEtMTAwIHRleHQtYXF1YS03MDBcIj5cbiAgICAgICAgICAgICAgICA8SW5ib3ggc2l6ZT17MjB9IGFyaWEtaGlkZGVuIC8+XG4gICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cImZvbnQtZGlzcGxheSBmb250LWJvbGQgdGV4dC1pbmtcIj5ObyBpbnF1aXJpZXMgeWV0LjwvaDM+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEuNSBtYXgtdy14cyB0ZXh0LXNtIHRleHQtbXV0ZWRcIj5cbiAgICAgICAgICAgICAgICBTd2l0Y2ggdG8gc2Vla2VyIG1vZGUsIG9wZW4gb25lIG9mIHlvdXIgc3BhY2VzIGFuZCBzZW5kIGFuIGlucXVpcnkg4oCUIGl0IGxhbmRzIGhlcmUuXG4gICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgPExpbmsgdG89XCIvbWVzc2FnZXNcIiBjbGFzc05hbWU9XCJtdC00XCI+XG4gICAgICAgICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwic2Vjb25kYXJ5XCIgc2l6ZT1cInNtXCI+XG4gICAgICAgICAgICAgICAgICBPcGVuIG1lc3NhZ2VzXG4gICAgICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgICAgIDwvTGluaz5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICA8dWwgY2xhc3NOYW1lPVwic3BhY2UteS0zXCI+XG4gICAgICAgICAgICAgIHtvd25JbnF1aXJpZXMubWFwKChpbnEpID0+IChcbiAgICAgICAgICAgICAgICA8SW5xdWlyeVJvdyBrZXk9e2lucS5pZH0gaW5xdWlyeT17aW5xfSBzcGFjZXM9e3NwYWNlc30gb25DaGFuZ2VkPXtyZWZyZXNofSAvPlxuICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgIDwvdWw+XG4gICAgICAgICAgKX1cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtOCByb3VuZGVkLWNhcmQgYmctc3VyZmFjZS83MCBwLTQgdGV4dC1zbSBsZWFkaW5nLXJlbGF4ZWQgdGV4dC1pbmstc29mdCByaW5nLTEgcmluZy1oYWlybGluZS1zdHJvbmdcIj5cbiAgICAgICAgICBFdmVyeXRoaW5nIHlvdSBjaGFuZ2UgaGVyZSBpcyBzdG9yZWQgb24gdGhpcyBkZXZpY2UgYW5kIHN1cnZpdmVzIGEgcmVmcmVzaC4gU2VlZFxuICAgICAgICAgIHByb3BlcnRpZXMgYXJlIHN5bnRoZXRpYzsgYW55dGhpbmcgeW91IGFkZCBpcyBtYXJrZWQgYXMgeW91cnMuXG4gICAgICAgIDwvcD5cbiAgICAgIDwvZGl2PlxuICAgIDwvPlxuICApO1xufVxuXG5mdW5jdGlvbiBTdGF0KHtcbiAgaWNvbjogSWNvbixcbiAgbGFiZWwsXG4gIHZhbHVlLFxuICBoaW50LFxuICB0b25lLFxufToge1xuICBpY29uOiB0eXBlb2YgQnVpbGRpbmcyO1xuICBsYWJlbDogc3RyaW5nO1xuICB2YWx1ZTogc3RyaW5nO1xuICBoaW50Pzogc3RyaW5nO1xuICB0b25lPzogXCJva1wiIHwgXCJ3YXJuXCI7XG59KSB7XG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJyb3VuZGVkLWNhcmQgYmctc3VyZmFjZSBwLTUgcmluZy0xIHJpbmctaGFpcmxpbmVcIj5cbiAgICAgIDxkdCBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LXNtIHRleHQtbXV0ZWRcIj5cbiAgICAgICAgPEljb25cbiAgICAgICAgICBzaXplPXsxNX1cbiAgICAgICAgICBhcmlhLWhpZGRlblxuICAgICAgICAgIGNsYXNzTmFtZT17dG9uZSA9PT0gXCJva1wiID8gXCJ0ZXh0LW9rLTYwMFwiIDogdG9uZSA9PT0gXCJ3YXJuXCIgPyBcInRleHQtd2Fybi03MDBcIiA6IFwidGV4dC1hcXVhLTYwMFwifVxuICAgICAgICAvPlxuICAgICAgICB7bGFiZWx9XG4gICAgICA8L2R0PlxuICAgICAgPGRkIGNsYXNzTmFtZT1cIm10LTIgZm9udC1kaXNwbGF5IHRleHQtMnhsIGZvbnQtYm9sZCB0bnVtIHRleHQtaW5rXCI+e3ZhbHVlfTwvZGQ+XG4gICAgICB7aGludCAmJiA8cCBjbGFzc05hbWU9XCJtdC0xIHRleHQteHMgbGVhZGluZy1zbnVnIHRleHQtbXV0ZWRcIj57aGludH08L3A+fVxuICAgIDwvZGl2PlxuICApO1xufVxuXG5jb25zdCBTVEFUVVNfRkxPVzogSW5xdWlyeVtcInN0YXR1c1wiXVtdID0gW1wibmV3XCIsIFwiY29udGFjdGVkXCIsIFwiaW50ZXJlc3RlZFwiLCBcImNsb3NlZFwiXTtcblxuZnVuY3Rpb24gSW5xdWlyeVJvdyh7XG4gIGlucXVpcnksXG4gIHNwYWNlcyxcbiAgb25DaGFuZ2VkLFxufToge1xuICBpbnF1aXJ5OiBJbnF1aXJ5O1xuICBzcGFjZXM6IFNwYWNlW107XG4gIG9uQ2hhbmdlZDogKCkgPT4gUHJvbWlzZTx2b2lkPjtcbn0pIHtcbiAgY29uc3Qgc3BhY2UgPSBzcGFjZXMuZmluZCgocykgPT4gcy5pZCA9PT0gaW5xdWlyeS5zcGFjZUlkKTtcblxuICByZXR1cm4gKFxuICAgIDxsaSBjbGFzc05hbWU9XCJyb3VuZGVkLWNhcmQgYmctc3VyZmFjZSBwLTQgcmluZy0xIHJpbmctaGFpcmxpbmVcIj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgaXRlbXMtc3RhcnQganVzdGlmeS1iZXR3ZWVuIGdhcC0zXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLXctMFwiPlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1pbmtcIj5cbiAgICAgICAgICAgIHtpbnF1aXJ5Lm5hbWV9XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtbC0yIGZvbnQtbm9ybWFsIHRleHQtbXV0ZWRcIj5vbiB7c3BhY2U/Lm5hbWUgPz8gaW5xdWlyeS5zcGFjZUlkfTwvc3Bhbj5cbiAgICAgICAgICA8L3A+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXNtIGxlYWRpbmctcmVsYXhlZCB0ZXh0LWluay1zb2Z0XCI+e2lucXVpcnkubWVzc2FnZX08L3A+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJzaHJpbmstMFwiPlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInNyLW9ubHlcIj5TdGF0dXMgZm9yIHRoaXMgaW5xdWlyeTwvc3Bhbj5cbiAgICAgICAgICA8c2VsZWN0XG4gICAgICAgICAgICB2YWx1ZT17aW5xdWlyeS5zdGF0dXN9XG4gICAgICAgICAgICBvbkNoYW5nZT17YXN5bmMgKGUpID0+IHtcbiAgICAgICAgICAgICAgYXdhaXQgZGIuc2V0SW5xdWlyeVN0YXR1cyhpbnF1aXJ5LmlkLCBlLnRhcmdldC52YWx1ZSBhcyBJbnF1aXJ5W1wic3RhdHVzXCJdKTtcbiAgICAgICAgICAgICAgYXdhaXQgb25DaGFuZ2VkKCk7XG4gICAgICAgICAgICB9fVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC05IHJvdW5kZWQtZnVsbCBiZy1pdm9yeSBweC0zIHRleHQteHMgZm9udC1zZW1pYm9sZCBjYXBpdGFsaXplIHRleHQtaW5rIHJpbmctMSByaW5nLWhhaXJsaW5lLXN0cm9uZyBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctYXF1YS02MDBcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIHtTVEFUVVNfRkxPVy5tYXAoKHMpID0+IChcbiAgICAgICAgICAgICAgPG9wdGlvbiBrZXk9e3N9IHZhbHVlPXtzfT5cbiAgICAgICAgICAgICAgICB7c31cbiAgICAgICAgICAgICAgPC9vcHRpb24+XG4gICAgICAgICAgICApKX1cbiAgICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAgPC9sYWJlbD5cbiAgICAgIDwvZGl2PlxuXG4gICAgICA8dWwgY2xhc3NOYW1lPVwibXQtMyBmbGV4IGZsZXgtd3JhcCBnYXAtMS41IHRleHQteHNcIj5cbiAgICAgICAgPGxpIGNsYXNzTmFtZT1cInJvdW5kZWQtZnVsbCBiZy1pdm9yeS1kZWVwIHB4LTIuNSBweS0xIGZvbnQtc2VtaWJvbGQgdGV4dC1pbmstc29mdFwiPlxuICAgICAgICAgIEJ1ZGdldCB7bW9uZXkoaW5xdWlyeS5idWRnZXRNaW4pfeKAk3ttb25leShpbnF1aXJ5LmJ1ZGdldE1heCl9XG4gICAgICAgIDwvbGk+XG4gICAgICAgIDxsaSBjbGFzc05hbWU9XCJyb3VuZGVkLWZ1bGwgYmctaXZvcnktZGVlcCBweC0yLjUgcHktMSBmb250LXNlbWlib2xkIHRleHQtaW5rLXNvZnRcIj5cbiAgICAgICAgICBNb3Zpbmcge2xvbmdEYXRlKGlucXVpcnkubW92ZUluRGF0ZSl9XG4gICAgICAgIDwvbGk+XG4gICAgICA8L3VsPlxuICAgIDwvbGk+XG4gICk7XG59XG4iXSwiZmlsZSI6IkQ6L0kySSBQcm9qZWN0IC0gSGFiaXRvL0FwcCBGb2xkZXIvaGFiaXRvL3NyYy9wYWdlcy9Qb3J0Zm9saW8udHN4In0=