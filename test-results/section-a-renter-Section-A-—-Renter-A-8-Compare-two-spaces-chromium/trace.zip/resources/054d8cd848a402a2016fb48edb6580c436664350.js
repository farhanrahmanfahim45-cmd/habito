import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/@fs/D:\\I2I Project - Habito\\App Folder\\habito\\src\\components\\space\\SpaceCard.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=9ceb86a3"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("D:/I2I Project - Habito/App Folder/habito/src/components/space/SpaceCard.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=9ceb86a3";
import { Bookmark, Scale } from "/node_modules/.vite/deps/lucide-react.js?v=9ceb86a3";
import { money, moneyCompact, lastUpdatedShort, isStale } from "/src/lib/format.ts";
import { CATEGORY_STYLE } from "/src/data/catalog.ts";
import { cn } from "/src/lib/cn.ts";
import { useI18n } from "/src/i18n/index.tsx";
import { spaceName, displayImage } from "/src/lib/localize.ts";
import { MatchPill } from "/src/components/space/MatchRing.tsx";
import { TrustBadge, AvailabilityBadge } from "/src/components/space/badges.tsx";
import { SpacePhoto } from "/src/components/space/SpacePhoto.tsx";
export function keySpec(listing) {
  const { attributes: a, category, availability } = listing.space;
  switch (category) {
    case "living": {
      const parts = [];
      if (a.bedrooms) parts.push(`${a.bedrooms} bed`);
      if (a.bathrooms) parts.push(`${a.bathrooms} bath`);
      if (a.sizeSqft) parts.push(`${a.sizeSqft} sqft`);
      return parts.join(" · ");
    }
    case "business": {
      const parts = [];
      if (a.sizeSqft) parts.push(`${a.sizeSqft} sqft`);
      if (a.frontageFt) parts.push(`${a.frontageFt} ft frontage`);
      if (a.workstations) parts.push(`${a.workstations} desks`);
      return parts.join(" · ");
    }
    case "storage": {
      const parts = [];
      if (a.sizeSqft) parts.push(`${a.sizeSqft} sqft`);
      if (a.ceilingHeightFt) parts.push(`${a.ceilingHeightFt} ft ceiling`);
      if (a.loadingAccess) parts.push("loading access");
      return parts.join(" · ");
    }
    case "parking": {
      if (availability.note) return availability.note;
      const parts = [];
      if (a.carSlots) parts.push(`${a.carSlots} car`);
      if (a.motorcycleSlots) parts.push(`${a.motorcycleSlots} motorcycle`);
      parts.push(a.covered ? "covered" : "open");
      return parts.join(" · ");
    }
    case "land": {
      const parts = [];
      if (a.landAreaDecimal) parts.push(`${a.landAreaDecimal} decimal`);
      if (a.landUse) parts.push(a.landUse.toLowerCase());
      if (a.roadAccess) parts.push("road access");
      return parts.join(" · ");
    }
  }
}
export function SpaceCard({
  listing,
  matchScore,
  saved = false,
  comparing = false,
  onToggleSave,
  onToggleCompare,
  size = "default"
}) {
  _s();
  const { t, language } = useI18n();
  const { space, property } = listing;
  const cat = CATEGORY_STYLE[space.category];
  const cover = space.images[0];
  const occupied = space.availability.status === "occupied";
  const isSale = space.transaction === "sale";
  return /* @__PURE__ */ jsxDEV(
    "article",
    {
      className: cn(
        "group lift relative flex flex-col overflow-hidden rounded-card bg-surface",
        "ring-1 ring-hairline",
        "focus-within:ring-2 focus-within:ring-aqua-600",
        occupied && "opacity-75"
      ),
      children: [
        /* @__PURE__ */ jsxDEV(
          "div",
          {
            className: cn(
              "relative",
              size === "large" ? "aspect-16/10" : size === "compact" ? "aspect-3/2" : "aspect-4/3"
            ),
            children: [
              /* @__PURE__ */ jsxDEV(
                SpacePhoto,
                {
                  src: displayImage(cover),
                  alt: cover.alt,
                  category: space.category,
                  demo: cover.demo,
                  bandPosition: "bottom",
                  className: "size-full",
                  imgClassName: "zoom"
                },
                void 0,
                false,
                {
                  fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/SpaceCard.tsx",
                  lineNumber: 119,
                  columnNumber: 9
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("div", { className: "pointer-events-none absolute inset-x-0 bottom-0 h-2/3 img-scrim", "aria-hidden": true }, void 0, false, {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/SpaceCard.tsx",
                lineNumber: 128,
                columnNumber: 9
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "absolute inset-x-3 top-3 flex items-start justify-between gap-2", children: [
                matchScore !== void 0 ? /* @__PURE__ */ jsxDEV(MatchPill, { score: matchScore }, void 0, false, {
                  fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/SpaceCard.tsx",
                  lineNumber: 132,
                  columnNumber: 11
                }, this) : /* @__PURE__ */ jsxDEV("span", { className: cn("rounded-full px-2.5 py-1 text-xs font-semibold", cat.chip), children: t(`category.${space.category}`) }, void 0, false, {
                  fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/SpaceCard.tsx",
                  lineNumber: 134,
                  columnNumber: 11
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex gap-1.5", children: [
                  onToggleCompare && /* @__PURE__ */ jsxDEV(
                    "button",
                    {
                      type: "button",
                      "aria-label": comparing ? `Remove ${spaceName(space, language)} from compare` : `Add ${spaceName(space, language)} to compare`,
                      "aria-pressed": comparing,
                      onClick: () => onToggleCompare(space.id),
                      className: cn(
                        "press rounded-full p-2 backdrop-blur-sm transition-colors",
                        comparing ? "bg-aqua-600 text-white" : "bg-surface/90 text-ink-soft hover:bg-surface"
                      ),
                      children: /* @__PURE__ */ jsxDEV(Scale, { size: 15, "aria-hidden": true }, void 0, false, {
                        fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/SpaceCard.tsx",
                        lineNumber: 151,
                        columnNumber: 17
                      }, this)
                    },
                    void 0,
                    false,
                    {
                      fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/SpaceCard.tsx",
                      lineNumber: 141,
                      columnNumber: 13
                    },
                    this
                  ),
                  onToggleSave && /* @__PURE__ */ jsxDEV(
                    "button",
                    {
                      type: "button",
                      "aria-label": saved ? `Remove ${spaceName(space, language)} from saved` : `Save ${spaceName(space, language)}`,
                      "aria-pressed": saved,
                      onClick: () => onToggleSave(space.id),
                      className: "rounded-full bg-surface/90 p-2 text-ink-soft backdrop-blur-sm transition-colors hover:bg-surface hover:text-aqua-700",
                      children: /* @__PURE__ */ jsxDEV(Bookmark, { size: 15, className: cn(saved && "fill-aqua-600 text-aqua-600"), "aria-hidden": true }, void 0, false, {
                        fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/SpaceCard.tsx",
                        lineNumber: 162,
                        columnNumber: 17
                      }, this)
                    },
                    void 0,
                    false,
                    {
                      fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/SpaceCard.tsx",
                      lineNumber: 155,
                      columnNumber: 13
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/SpaceCard.tsx",
                  lineNumber: 139,
                  columnNumber: 11
                }, this)
              ] }, void 0, true, {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/SpaceCard.tsx",
                lineNumber: 130,
                columnNumber: 9
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "absolute inset-x-3.5 bottom-3", children: [
                /* @__PURE__ */ jsxDEV("p", { className: "font-display text-xl font-bold leading-none text-white tnum", children: [
                  isSale ? money(space.cost.price) : moneyCompact(space.cost.price),
                  /* @__PURE__ */ jsxDEV("span", { className: "ml-1 text-sm font-medium text-white/75", children: isSale ? "" : t("transaction.perMonth") }, void 0, false, {
                    fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/SpaceCard.tsx",
                    lineNumber: 171,
                    columnNumber: 13
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/SpaceCard.tsx",
                  lineNumber: 169,
                  columnNumber: 11
                }, this),
                /* @__PURE__ */ jsxDEV("h3", { className: "mt-1 truncate font-semibold text-white", children: /* @__PURE__ */ jsxDEV(Link, { to: `/space/${space.id}`, className: "after:absolute after:inset-0 focus:outline-none", children: spaceName(space, language) }, void 0, false, {
                  fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/SpaceCard.tsx",
                  lineNumber: 176,
                  columnNumber: 13
                }, this) }, void 0, false, {
                  fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/SpaceCard.tsx",
                  lineNumber: 175,
                  columnNumber: 11
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "truncate text-sm text-white/75", children: [
                  property.neighborhood,
                  ", ",
                  property.area
                ] }, void 0, true, {
                  fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/SpaceCard.tsx",
                  lineNumber: 180,
                  columnNumber: 11
                }, this)
              ] }, void 0, true, {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/SpaceCard.tsx",
                lineNumber: 168,
                columnNumber: 9
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "pointer-events-none absolute bottom-3 right-3.5 rounded bg-ink/55 px-1.5 py-0.5 text-[0.6rem] font-semibold uppercase tracking-wide text-white/90", children: t("misc.demo") }, void 0, false, {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/SpaceCard.tsx",
                lineNumber: 185,
                columnNumber: 9
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/SpaceCard.tsx",
            lineNumber: 113,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-1 flex-col gap-2 p-3.5", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center gap-1.5", children: [
            /* @__PURE__ */ jsxDEV("span", { className: cn("rounded px-1.5 py-0.5 text-xs font-semibold", cat.chip), children: t(`type.${space.spaceType}`) }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/SpaceCard.tsx",
              lineNumber: 192,
              columnNumber: 11
            }, this),
            isSale && /* @__PURE__ */ jsxDEV("span", { className: "rounded bg-ink px-1.5 py-0.5 text-xs font-semibold text-ivory", children: t("transaction.forSale") }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/SpaceCard.tsx",
              lineNumber: 196,
              columnNumber: 11
            }, this),
            space.sponsoredUntil && /* @__PURE__ */ jsxDEV(
              "span",
              {
                title: t("sponsored.explain"),
                className: "rounded bg-sun/60 px-1.5 py-0.5 text-xs font-semibold text-sun-ink",
                children: t("sponsored.label")
              },
              void 0,
              false,
              {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/SpaceCard.tsx",
                lineNumber: 204,
                columnNumber: 11
              },
              this
            ),
            space.availability.status !== "available" && /* @__PURE__ */ jsxDEV(AvailabilityBadge, { availability: space.availability }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/SpaceCard.tsx",
              lineNumber: 214,
              columnNumber: 11
            }, this)
          ] }, void 0, true, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/SpaceCard.tsx",
            lineNumber: 191,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-ink-soft", children: keySpec(listing) }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/SpaceCard.tsx",
            lineNumber: 218,
            columnNumber: 9
          }, this),
          space.transaction === "rent" && (space.cost.estimatedMonthly ? /* @__PURE__ */ jsxDEV("p", { className: "text-[0.8125rem] text-muted tnum", children: t("misc.aboutAllIn", { price: money(space.cost.estimatedMonthly) }) }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/SpaceCard.tsx",
            lineNumber: 222,
            columnNumber: 9
          }, this) : /* @__PURE__ */ jsxDEV("p", { className: "text-[0.8125rem] font-medium text-warn-700", children: t("misc.fullCostNotListed") }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/SpaceCard.tsx",
            lineNumber: 226,
            columnNumber: 9
          }, this)),
          /* @__PURE__ */ jsxDEV("div", { className: "mt-auto hidden items-center gap-2 border-t border-hairline pt-2.5 sm:flex", children: [
            /* @__PURE__ */ jsxDEV(TrustBadge, { verification: space.verification, compact: true }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/SpaceCard.tsx",
              lineNumber: 230,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV(
              "span",
              {
                className: cn(
                  "ml-auto text-xs",
                  isStale(space.lastUpdated) ? "font-medium text-warn-700" : "text-muted"
                ),
                children: lastUpdatedShort(space.lastUpdated)
              },
              void 0,
              false,
              {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/SpaceCard.tsx",
                lineNumber: 231,
                columnNumber: 11
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/SpaceCard.tsx",
            lineNumber: 229,
            columnNumber: 9
          }, this)
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/SpaceCard.tsx",
          lineNumber: 190,
          columnNumber: 7
        }, this)
      ]
    },
    void 0,
    true,
    {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/SpaceCard.tsx",
      lineNumber: 105,
      columnNumber: 5
    },
    this
  );
}
_s(SpaceCard, "t5dlNeYFVJWhLlLy3xB1IAoIKPQ=", false, function() {
  return [useI18n];
});
_c = SpaceCard;
var _c;
$RefreshReg$(_c, "SpaceCard");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/I2I Project - Habito/App Folder/habito/src/components/space/SpaceCard.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/I2I Project - Habito/App Folder/habito/src/components/space/SpaceCard.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbUdROzs7Ozs7Ozs7Ozs7Ozs7OztBQW5HUixTQUFTQSxZQUFZO0FBQ3JCLFNBQVNDLFVBQVVDLGFBQWE7QUFHaEMsU0FBU0MsT0FBT0MsY0FBY0Msa0JBQWtCQyxlQUFlO0FBQy9ELFNBQVNDLHNCQUFzQjtBQUMvQixTQUFTQyxVQUFVO0FBQ25CLFNBQVNDLGVBQWU7QUFDeEIsU0FBU0MsV0FBV0Msb0JBQW9CO0FBQ3hDLFNBQVNDLGlCQUFpQjtBQUMxQixTQUFTQyxZQUFZQyx5QkFBeUI7QUFDOUMsU0FBU0Msa0JBQWtCO0FBTXBCLGdCQUFTQyxRQUFRQyxTQUErQjtBQUNyRCxRQUFNLEVBQUVDLFlBQVlDLEdBQUdDLFVBQVVDLGFBQWEsSUFBSUosUUFBUUs7QUFFMUQsVUFBUUYsVUFBUTtBQUFBLElBQ2QsS0FBSyxVQUFVO0FBQ2IsWUFBTUcsUUFBa0I7QUFDeEIsVUFBSUosRUFBRUssU0FBVUQsT0FBTUUsS0FBSyxHQUFHTixFQUFFSyxRQUFRLE1BQU07QUFDOUMsVUFBSUwsRUFBRU8sVUFBV0gsT0FBTUUsS0FBSyxHQUFHTixFQUFFTyxTQUFTLE9BQU87QUFDakQsVUFBSVAsRUFBRVEsU0FBVUosT0FBTUUsS0FBSyxHQUFHTixFQUFFUSxRQUFRLE9BQU87QUFDL0MsYUFBT0osTUFBTUssS0FBSyxLQUFLO0FBQUEsSUFDekI7QUFBQSxJQUNBLEtBQUssWUFBWTtBQUNmLFlBQU1MLFFBQWtCO0FBQ3hCLFVBQUlKLEVBQUVRLFNBQVVKLE9BQU1FLEtBQUssR0FBR04sRUFBRVEsUUFBUSxPQUFPO0FBQy9DLFVBQUlSLEVBQUVVLFdBQVlOLE9BQU1FLEtBQUssR0FBR04sRUFBRVUsVUFBVSxjQUFjO0FBQzFELFVBQUlWLEVBQUVXLGFBQWNQLE9BQU1FLEtBQUssR0FBR04sRUFBRVcsWUFBWSxRQUFRO0FBQ3hELGFBQU9QLE1BQU1LLEtBQUssS0FBSztBQUFBLElBQ3pCO0FBQUEsSUFDQSxLQUFLLFdBQVc7QUFDZCxZQUFNTCxRQUFrQjtBQUN4QixVQUFJSixFQUFFUSxTQUFVSixPQUFNRSxLQUFLLEdBQUdOLEVBQUVRLFFBQVEsT0FBTztBQUMvQyxVQUFJUixFQUFFWSxnQkFBaUJSLE9BQU1FLEtBQUssR0FBR04sRUFBRVksZUFBZSxhQUFhO0FBQ25FLFVBQUlaLEVBQUVhLGNBQWVULE9BQU1FLEtBQUssZ0JBQWdCO0FBQ2hELGFBQU9GLE1BQU1LLEtBQUssS0FBSztBQUFBLElBQ3pCO0FBQUEsSUFDQSxLQUFLLFdBQVc7QUFDZCxVQUFJUCxhQUFhWSxLQUFNLFFBQU9aLGFBQWFZO0FBQzNDLFlBQU1WLFFBQWtCO0FBQ3hCLFVBQUlKLEVBQUVlLFNBQVVYLE9BQU1FLEtBQUssR0FBR04sRUFBRWUsUUFBUSxNQUFNO0FBQzlDLFVBQUlmLEVBQUVnQixnQkFBaUJaLE9BQU1FLEtBQUssR0FBR04sRUFBRWdCLGVBQWUsYUFBYTtBQUNuRVosWUFBTUUsS0FBS04sRUFBRWlCLFVBQVUsWUFBWSxNQUFNO0FBQ3pDLGFBQU9iLE1BQU1LLEtBQUssS0FBSztBQUFBLElBQ3pCO0FBQUEsSUFDQSxLQUFLLFFBQVE7QUFDWCxZQUFNTCxRQUFrQjtBQUN4QixVQUFJSixFQUFFa0IsZ0JBQWlCZCxPQUFNRSxLQUFLLEdBQUdOLEVBQUVrQixlQUFlLFVBQVU7QUFDaEUsVUFBSWxCLEVBQUVtQixRQUFTZixPQUFNRSxLQUFLTixFQUFFbUIsUUFBUUMsWUFBWSxDQUFDO0FBQ2pELFVBQUlwQixFQUFFcUIsV0FBWWpCLE9BQU1FLEtBQUssYUFBYTtBQUMxQyxhQUFPRixNQUFNSyxLQUFLLEtBQUs7QUFBQSxJQUN6QjtBQUFBLEVBQ0Y7QUFDRjtBQUVPLGdCQUFTYSxVQUFVO0FBQUEsRUFDeEJ4QjtBQUFBQSxFQUNBeUI7QUFBQUEsRUFDQUMsUUFBUTtBQUFBLEVBQ1JDLFlBQVk7QUFBQSxFQUNaQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQyxPQUFPO0FBU1QsR0FBRztBQUFBQyxLQUFBO0FBQ0QsUUFBTSxFQUFFQyxHQUFHQyxTQUFTLElBQUl6QyxRQUFRO0FBQ2hDLFFBQU0sRUFBRWEsT0FBTzZCLFNBQVMsSUFBSWxDO0FBQzVCLFFBQU1tQyxNQUFNN0MsZUFBZWUsTUFBTUYsUUFBUTtBQUN6QyxRQUFNaUMsUUFBUS9CLE1BQU1nQyxPQUFPLENBQUM7QUFDNUIsUUFBTUMsV0FBV2pDLE1BQU1ELGFBQWFtQyxXQUFXO0FBQy9DLFFBQU1DLFNBQVNuQyxNQUFNb0MsZ0JBQWdCO0FBRXJDLFNBQ0U7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNDLFdBQVdsRDtBQUFBQSxRQUNUO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBK0MsWUFBWTtBQUFBLE1BQ2Q7QUFBQSxNQUVBO0FBQUE7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFdBQVcvQztBQUFBQSxjQUNUO0FBQUEsY0FDQXVDLFNBQVMsVUFBVSxpQkFBaUJBLFNBQVMsWUFBWSxlQUFlO0FBQUEsWUFDMUU7QUFBQSxZQUVBO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsS0FBS3BDLGFBQWEwQyxLQUFLO0FBQUEsa0JBQ3ZCLEtBQUtBLE1BQU1NO0FBQUFBLGtCQUNYLFVBQVVyQyxNQUFNRjtBQUFBQSxrQkFDaEIsTUFBTWlDLE1BQU1PO0FBQUFBLGtCQUNaLGNBQWE7QUFBQSxrQkFDYixXQUFVO0FBQUEsa0JBQ1YsY0FBYTtBQUFBO0FBQUEsZ0JBUGY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBT3FCO0FBQUEsY0FFckIsdUJBQUMsU0FBSSxXQUFVLG1FQUFrRSxlQUFXLFFBQTVGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTRGO0FBQUEsY0FFNUYsdUJBQUMsU0FBSSxXQUFVLG1FQUNabEI7QUFBQUEsK0JBQWVtQixTQUNkLHVCQUFDLGFBQVUsT0FBT25CLGNBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTZCLElBRTdCLHVCQUFDLFVBQUssV0FBV2xDLEdBQUcsa0RBQWtENEMsSUFBSVUsSUFBSSxHQUMzRWIsWUFBRSxZQUFZM0IsTUFBTUYsUUFBUSxFQUFXLEtBRDFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFHRix1QkFBQyxTQUFJLFdBQVUsZ0JBQ1owQjtBQUFBQSxxQ0FDQztBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxNQUFLO0FBQUEsc0JBQ0wsY0FBWUYsWUFBWSxVQUFVbEMsVUFBVVksT0FBTzRCLFFBQVEsQ0FBQyxrQkFBa0IsT0FBT3hDLFVBQVVZLE9BQU80QixRQUFRLENBQUM7QUFBQSxzQkFDL0csZ0JBQWNOO0FBQUFBLHNCQUNkLFNBQVMsTUFBTUUsZ0JBQWdCeEIsTUFBTXlDLEVBQUU7QUFBQSxzQkFDdkMsV0FBV3ZEO0FBQUFBLHdCQUNUO0FBQUEsd0JBQ0FvQyxZQUFZLDJCQUEyQjtBQUFBLHNCQUN6QztBQUFBLHNCQUVBLGlDQUFDLFNBQU0sTUFBTSxJQUFJLGVBQVcsUUFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBNEI7QUFBQTtBQUFBLG9CQVY5QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBV0E7QUFBQSxrQkFFREMsZ0JBQ0M7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsTUFBSztBQUFBLHNCQUNMLGNBQVlGLFFBQVEsVUFBVWpDLFVBQVVZLE9BQU80QixRQUFRLENBQUMsZ0JBQWdCLFFBQVF4QyxVQUFVWSxPQUFPNEIsUUFBUSxDQUFDO0FBQUEsc0JBQzFHLGdCQUFjUDtBQUFBQSxzQkFDZCxTQUFTLE1BQU1FLGFBQWF2QixNQUFNeUMsRUFBRTtBQUFBLHNCQUNwQyxXQUFVO0FBQUEsc0JBRVYsaUNBQUMsWUFBUyxNQUFNLElBQUksV0FBV3ZELEdBQUdtQyxTQUFTLDZCQUE2QixHQUFHLGVBQVcsUUFBdEY7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBc0Y7QUFBQTtBQUFBLG9CQVB4RjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBUUE7QUFBQSxxQkF4Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkEwQkE7QUFBQSxtQkFuQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFvQ0E7QUFBQSxjQUVBLHVCQUFDLFNBQUksV0FBVSxpQ0FDYjtBQUFBLHVDQUFDLE9BQUUsV0FBVSwrREFDVmM7QUFBQUEsMkJBQVN0RCxNQUFNbUIsTUFBTTBDLEtBQUtDLEtBQUssSUFBSTdELGFBQWFrQixNQUFNMEMsS0FBS0MsS0FBSztBQUFBLGtCQUNqRSx1QkFBQyxVQUFLLFdBQVUsMENBQ2JSLG1CQUFTLEtBQUtSLEVBQUUsc0JBQXNCLEtBRHpDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxxQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUtBO0FBQUEsZ0JBQ0EsdUJBQUMsUUFBRyxXQUFVLDBDQUNaLGlDQUFDLFFBQUssSUFBSSxVQUFVM0IsTUFBTXlDLEVBQUUsSUFBSSxXQUFVLG1EQUN2Q3JELG9CQUFVWSxPQUFPNEIsUUFBUSxLQUQ1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFJQTtBQUFBLGdCQUNBLHVCQUFDLE9BQUUsV0FBVSxrQ0FDVkM7QUFBQUEsMkJBQVNlO0FBQUFBLGtCQUFhO0FBQUEsa0JBQUdmLFNBQVNnQjtBQUFBQSxxQkFEckM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBZUE7QUFBQSxjQUVBLHVCQUFDLFVBQUssV0FBVSxxSkFDYmxCLFlBQUUsV0FBVyxLQURoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUE7QUFBQTtBQUFBLFVBMUVGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQTJFQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLG9DQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLHVDQUNiO0FBQUEsbUNBQUMsVUFBSyxXQUFXekMsR0FBRywrQ0FBK0M0QyxJQUFJVSxJQUFJLEdBQ3hFYixZQUFFLFFBQVEzQixNQUFNOEMsU0FBUyxFQUFXLEtBRHZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNDWCxVQUNDLHVCQUFDLFVBQUssV0FBVSxpRUFDYlIsWUFBRSxxQkFBcUIsS0FEMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBS0QzQixNQUFNK0Msa0JBQ0w7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxPQUFPcEIsRUFBRSxtQkFBbUI7QUFBQSxnQkFDNUIsV0FBVTtBQUFBLGdCQUVUQSxZQUFFLGlCQUFpQjtBQUFBO0FBQUEsY0FKdEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBS0E7QUFBQSxZQUlEM0IsTUFBTUQsYUFBYW1DLFdBQVcsZUFDN0IsdUJBQUMscUJBQWtCLGNBQWNsQyxNQUFNRCxnQkFBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBb0Q7QUFBQSxlQXZCeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkF5QkE7QUFBQSxVQUVBLHVCQUFDLE9BQUUsV0FBVSx5QkFBeUJMLGtCQUFRQyxPQUFPLEtBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXVEO0FBQUEsVUFFdERLLE1BQU1vQyxnQkFBZ0IsV0FDcEJwQyxNQUFNMEMsS0FBS00sbUJBQ1YsdUJBQUMsT0FBRSxXQUFVLG9DQUNWckIsWUFBRSxtQkFBbUIsRUFBRWdCLE9BQU85RCxNQUFNbUIsTUFBTTBDLEtBQUtNLGdCQUFnQixFQUFFLENBQUMsS0FEckU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQSxJQUVBLHVCQUFDLE9BQUUsV0FBVSw4Q0FBOENyQixZQUFFLHdCQUF3QixLQUFyRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF1RjtBQUFBLFVBRzNGLHVCQUFDLFNBQUksV0FBVSw2RUFDYjtBQUFBLG1DQUFDLGNBQVcsY0FBYzNCLE1BQU1pRCxjQUFjLFNBQU8sUUFBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBcUQ7QUFBQSxZQUNyRDtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFdBQVcvRDtBQUFBQSxrQkFDVDtBQUFBLGtCQUNBRixRQUFRZ0IsTUFBTWtELFdBQVcsSUFBSSw4QkFBOEI7QUFBQSxnQkFDN0Q7QUFBQSxnQkFFQ25FLDJCQUFpQmlCLE1BQU1rRCxXQUFXO0FBQUE7QUFBQSxjQU5yQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFPQTtBQUFBLGVBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFVQTtBQUFBLGFBakRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFrREE7QUFBQTtBQUFBO0FBQUEsSUF2SUY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBd0lBO0FBRUo7QUFBQ3hCLEdBbktlUCxXQUFTO0FBQUEsVUFpQkNoQyxPQUFPO0FBQUE7QUFBQSxLQWpCakJnQztBQUFTLElBQUFnQztBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJMaW5rIiwiQm9va21hcmsiLCJTY2FsZSIsIm1vbmV5IiwibW9uZXlDb21wYWN0IiwibGFzdFVwZGF0ZWRTaG9ydCIsImlzU3RhbGUiLCJDQVRFR09SWV9TVFlMRSIsImNuIiwidXNlSTE4biIsInNwYWNlTmFtZSIsImRpc3BsYXlJbWFnZSIsIk1hdGNoUGlsbCIsIlRydXN0QmFkZ2UiLCJBdmFpbGFiaWxpdHlCYWRnZSIsIlNwYWNlUGhvdG8iLCJrZXlTcGVjIiwibGlzdGluZyIsImF0dHJpYnV0ZXMiLCJhIiwiY2F0ZWdvcnkiLCJhdmFpbGFiaWxpdHkiLCJzcGFjZSIsInBhcnRzIiwiYmVkcm9vbXMiLCJwdXNoIiwiYmF0aHJvb21zIiwic2l6ZVNxZnQiLCJqb2luIiwiZnJvbnRhZ2VGdCIsIndvcmtzdGF0aW9ucyIsImNlaWxpbmdIZWlnaHRGdCIsImxvYWRpbmdBY2Nlc3MiLCJub3RlIiwiY2FyU2xvdHMiLCJtb3RvcmN5Y2xlU2xvdHMiLCJjb3ZlcmVkIiwibGFuZEFyZWFEZWNpbWFsIiwibGFuZFVzZSIsInRvTG93ZXJDYXNlIiwicm9hZEFjY2VzcyIsIlNwYWNlQ2FyZCIsIm1hdGNoU2NvcmUiLCJzYXZlZCIsImNvbXBhcmluZyIsIm9uVG9nZ2xlU2F2ZSIsIm9uVG9nZ2xlQ29tcGFyZSIsInNpemUiLCJfcyIsInQiLCJsYW5ndWFnZSIsInByb3BlcnR5IiwiY2F0IiwiY292ZXIiLCJpbWFnZXMiLCJvY2N1cGllZCIsInN0YXR1cyIsImlzU2FsZSIsInRyYW5zYWN0aW9uIiwiYWx0IiwiZGVtbyIsInVuZGVmaW5lZCIsImNoaXAiLCJpZCIsImNvc3QiLCJwcmljZSIsIm5laWdoYm9yaG9vZCIsImFyZWEiLCJzcGFjZVR5cGUiLCJzcG9uc29yZWRVbnRpbCIsImVzdGltYXRlZE1vbnRobHkiLCJ2ZXJpZmljYXRpb24iLCJsYXN0VXBkYXRlZCIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlNwYWNlQ2FyZC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTGluayB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XG5pbXBvcnQgeyBCb29rbWFyaywgU2NhbGUgfSBmcm9tIFwibHVjaWRlLXJlYWN0XCI7XG5pbXBvcnQgdHlwZSB7IFNwYWNlTGlzdGluZyB9IGZyb20gXCJAL3R5cGVzL3NwYWNlXCI7XG5cbmltcG9ydCB7IG1vbmV5LCBtb25leUNvbXBhY3QsIGxhc3RVcGRhdGVkU2hvcnQsIGlzU3RhbGUgfSBmcm9tIFwiQC9saWIvZm9ybWF0XCI7XG5pbXBvcnQgeyBDQVRFR09SWV9TVFlMRSB9IGZyb20gXCJAL2RhdGEvY2F0YWxvZ1wiO1xuaW1wb3J0IHsgY24gfSBmcm9tIFwiQC9saWIvY25cIjtcbmltcG9ydCB7IHVzZUkxOG4gfSBmcm9tIFwiQC9pMThuXCI7XG5pbXBvcnQgeyBzcGFjZU5hbWUsIGRpc3BsYXlJbWFnZSB9IGZyb20gXCJAL2xpYi9sb2NhbGl6ZVwiO1xuaW1wb3J0IHsgTWF0Y2hQaWxsIH0gZnJvbSBcIi4vTWF0Y2hSaW5nXCI7XG5pbXBvcnQgeyBUcnVzdEJhZGdlLCBBdmFpbGFiaWxpdHlCYWRnZSB9IGZyb20gXCIuL2JhZGdlc1wiO1xuaW1wb3J0IHsgU3BhY2VQaG90byB9IGZyb20gXCIuL1NwYWNlUGhvdG9cIjtcblxuLyoqXG4gKiBUaGUga2V5IHNwZWNpZmljYXRpb24gbGluZSBjaGFuZ2VzIHBlciBjYXRlZ29yeS4gQSBnYXJhZ2UgaGFzIG5vIGJlZHJvb21zXG4gKiBhbmQgYSBwb25kIGhhcyBubyBiYXRocm9vbXMsIHNvIG5vdGhpbmcgcmVuZGVycyBhIGJsYW5rIG9yIGEgZGFzaC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGtleVNwZWMobGlzdGluZzogU3BhY2VMaXN0aW5nKTogc3RyaW5nIHtcbiAgY29uc3QgeyBhdHRyaWJ1dGVzOiBhLCBjYXRlZ29yeSwgYXZhaWxhYmlsaXR5IH0gPSBsaXN0aW5nLnNwYWNlO1xuXG4gIHN3aXRjaCAoY2F0ZWdvcnkpIHtcbiAgICBjYXNlIFwibGl2aW5nXCI6IHtcbiAgICAgIGNvbnN0IHBhcnRzOiBzdHJpbmdbXSA9IFtdO1xuICAgICAgaWYgKGEuYmVkcm9vbXMpIHBhcnRzLnB1c2goYCR7YS5iZWRyb29tc30gYmVkYCk7XG4gICAgICBpZiAoYS5iYXRocm9vbXMpIHBhcnRzLnB1c2goYCR7YS5iYXRocm9vbXN9IGJhdGhgKTtcbiAgICAgIGlmIChhLnNpemVTcWZ0KSBwYXJ0cy5wdXNoKGAke2Euc2l6ZVNxZnR9IHNxZnRgKTtcbiAgICAgIHJldHVybiBwYXJ0cy5qb2luKFwiIMK3IFwiKTtcbiAgICB9XG4gICAgY2FzZSBcImJ1c2luZXNzXCI6IHtcbiAgICAgIGNvbnN0IHBhcnRzOiBzdHJpbmdbXSA9IFtdO1xuICAgICAgaWYgKGEuc2l6ZVNxZnQpIHBhcnRzLnB1c2goYCR7YS5zaXplU3FmdH0gc3FmdGApO1xuICAgICAgaWYgKGEuZnJvbnRhZ2VGdCkgcGFydHMucHVzaChgJHthLmZyb250YWdlRnR9IGZ0IGZyb250YWdlYCk7XG4gICAgICBpZiAoYS53b3Jrc3RhdGlvbnMpIHBhcnRzLnB1c2goYCR7YS53b3Jrc3RhdGlvbnN9IGRlc2tzYCk7XG4gICAgICByZXR1cm4gcGFydHMuam9pbihcIiDCtyBcIik7XG4gICAgfVxuICAgIGNhc2UgXCJzdG9yYWdlXCI6IHtcbiAgICAgIGNvbnN0IHBhcnRzOiBzdHJpbmdbXSA9IFtdO1xuICAgICAgaWYgKGEuc2l6ZVNxZnQpIHBhcnRzLnB1c2goYCR7YS5zaXplU3FmdH0gc3FmdGApO1xuICAgICAgaWYgKGEuY2VpbGluZ0hlaWdodEZ0KSBwYXJ0cy5wdXNoKGAke2EuY2VpbGluZ0hlaWdodEZ0fSBmdCBjZWlsaW5nYCk7XG4gICAgICBpZiAoYS5sb2FkaW5nQWNjZXNzKSBwYXJ0cy5wdXNoKFwibG9hZGluZyBhY2Nlc3NcIik7XG4gICAgICByZXR1cm4gcGFydHMuam9pbihcIiDCtyBcIik7XG4gICAgfVxuICAgIGNhc2UgXCJwYXJraW5nXCI6IHtcbiAgICAgIGlmIChhdmFpbGFiaWxpdHkubm90ZSkgcmV0dXJuIGF2YWlsYWJpbGl0eS5ub3RlO1xuICAgICAgY29uc3QgcGFydHM6IHN0cmluZ1tdID0gW107XG4gICAgICBpZiAoYS5jYXJTbG90cykgcGFydHMucHVzaChgJHthLmNhclNsb3RzfSBjYXJgKTtcbiAgICAgIGlmIChhLm1vdG9yY3ljbGVTbG90cykgcGFydHMucHVzaChgJHthLm1vdG9yY3ljbGVTbG90c30gbW90b3JjeWNsZWApO1xuICAgICAgcGFydHMucHVzaChhLmNvdmVyZWQgPyBcImNvdmVyZWRcIiA6IFwib3BlblwiKTtcbiAgICAgIHJldHVybiBwYXJ0cy5qb2luKFwiIMK3IFwiKTtcbiAgICB9XG4gICAgY2FzZSBcImxhbmRcIjoge1xuICAgICAgY29uc3QgcGFydHM6IHN0cmluZ1tdID0gW107XG4gICAgICBpZiAoYS5sYW5kQXJlYURlY2ltYWwpIHBhcnRzLnB1c2goYCR7YS5sYW5kQXJlYURlY2ltYWx9IGRlY2ltYWxgKTtcbiAgICAgIGlmIChhLmxhbmRVc2UpIHBhcnRzLnB1c2goYS5sYW5kVXNlLnRvTG93ZXJDYXNlKCkpO1xuICAgICAgaWYgKGEucm9hZEFjY2VzcykgcGFydHMucHVzaChcInJvYWQgYWNjZXNzXCIpO1xuICAgICAgcmV0dXJuIHBhcnRzLmpvaW4oXCIgwrcgXCIpO1xuICAgIH1cbiAgfVxufVxuXG5leHBvcnQgZnVuY3Rpb24gU3BhY2VDYXJkKHtcbiAgbGlzdGluZyxcbiAgbWF0Y2hTY29yZSxcbiAgc2F2ZWQgPSBmYWxzZSxcbiAgY29tcGFyaW5nID0gZmFsc2UsXG4gIG9uVG9nZ2xlU2F2ZSxcbiAgb25Ub2dnbGVDb21wYXJlLFxuICBzaXplID0gXCJkZWZhdWx0XCIsXG59OiB7XG4gIGxpc3Rpbmc6IFNwYWNlTGlzdGluZztcbiAgbWF0Y2hTY29yZT86IG51bWJlcjtcbiAgc2F2ZWQ/OiBib29sZWFuO1xuICBjb21wYXJpbmc/OiBib29sZWFuO1xuICBvblRvZ2dsZVNhdmU/OiAoaWQ6IHN0cmluZykgPT4gdm9pZDtcbiAgb25Ub2dnbGVDb21wYXJlPzogKGlkOiBzdHJpbmcpID0+IHZvaWQ7XG4gIHNpemU/OiBcImRlZmF1bHRcIiB8IFwibGFyZ2VcIiB8IFwiY29tcGFjdFwiO1xufSkge1xuICBjb25zdCB7IHQsIGxhbmd1YWdlIH0gPSB1c2VJMThuKCk7XG4gIGNvbnN0IHsgc3BhY2UsIHByb3BlcnR5IH0gPSBsaXN0aW5nO1xuICBjb25zdCBjYXQgPSBDQVRFR09SWV9TVFlMRVtzcGFjZS5jYXRlZ29yeV07XG4gIGNvbnN0IGNvdmVyID0gc3BhY2UuaW1hZ2VzWzBdO1xuICBjb25zdCBvY2N1cGllZCA9IHNwYWNlLmF2YWlsYWJpbGl0eS5zdGF0dXMgPT09IFwib2NjdXBpZWRcIjtcbiAgY29uc3QgaXNTYWxlID0gc3BhY2UudHJhbnNhY3Rpb24gPT09IFwic2FsZVwiO1xuXG4gIHJldHVybiAoXG4gICAgPGFydGljbGVcbiAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgIFwiZ3JvdXAgbGlmdCByZWxhdGl2ZSBmbGV4IGZsZXgtY29sIG92ZXJmbG93LWhpZGRlbiByb3VuZGVkLWNhcmQgYmctc3VyZmFjZVwiLFxuICAgICAgICBcInJpbmctMSByaW5nLWhhaXJsaW5lXCIsXG4gICAgICAgIFwiZm9jdXMtd2l0aGluOnJpbmctMiBmb2N1cy13aXRoaW46cmluZy1hcXVhLTYwMFwiLFxuICAgICAgICBvY2N1cGllZCAmJiBcIm9wYWNpdHktNzVcIixcbiAgICAgICl9XG4gICAgPlxuICAgICAgPGRpdlxuICAgICAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgICAgIFwicmVsYXRpdmVcIixcbiAgICAgICAgICBzaXplID09PSBcImxhcmdlXCIgPyBcImFzcGVjdC0xNi8xMFwiIDogc2l6ZSA9PT0gXCJjb21wYWN0XCIgPyBcImFzcGVjdC0zLzJcIiA6IFwiYXNwZWN0LTQvM1wiLFxuICAgICAgICApfVxuICAgICAgPlxuICAgICAgICA8U3BhY2VQaG90b1xuICAgICAgICAgIHNyYz17ZGlzcGxheUltYWdlKGNvdmVyKX1cbiAgICAgICAgICBhbHQ9e2NvdmVyLmFsdH1cbiAgICAgICAgICBjYXRlZ29yeT17c3BhY2UuY2F0ZWdvcnl9XG4gICAgICAgICAgZGVtbz17Y292ZXIuZGVtb31cbiAgICAgICAgICBiYW5kUG9zaXRpb249XCJib3R0b21cIlxuICAgICAgICAgIGNsYXNzTmFtZT1cInNpemUtZnVsbFwiXG4gICAgICAgICAgaW1nQ2xhc3NOYW1lPVwiem9vbVwiXG4gICAgICAgIC8+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicG9pbnRlci1ldmVudHMtbm9uZSBhYnNvbHV0ZSBpbnNldC14LTAgYm90dG9tLTAgaC0yLzMgaW1nLXNjcmltXCIgYXJpYS1oaWRkZW4gLz5cblxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIGluc2V0LXgtMyB0b3AtMyBmbGV4IGl0ZW1zLXN0YXJ0IGp1c3RpZnktYmV0d2VlbiBnYXAtMlwiPlxuICAgICAgICAgIHttYXRjaFNjb3JlICE9PSB1bmRlZmluZWQgPyAoXG4gICAgICAgICAgICA8TWF0Y2hQaWxsIHNjb3JlPXttYXRjaFNjb3JlfSAvPlxuICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2NuKFwicm91bmRlZC1mdWxsIHB4LTIuNSBweS0xIHRleHQteHMgZm9udC1zZW1pYm9sZFwiLCBjYXQuY2hpcCl9PlxuICAgICAgICAgICAgICB7dChgY2F0ZWdvcnkuJHtzcGFjZS5jYXRlZ29yeX1gIGFzIG5ldmVyKX1cbiAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICApfVxuXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC0xLjVcIj5cbiAgICAgICAgICAgIHtvblRvZ2dsZUNvbXBhcmUgJiYgKFxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgYXJpYS1sYWJlbD17Y29tcGFyaW5nID8gYFJlbW92ZSAke3NwYWNlTmFtZShzcGFjZSwgbGFuZ3VhZ2UpfSBmcm9tIGNvbXBhcmVgIDogYEFkZCAke3NwYWNlTmFtZShzcGFjZSwgbGFuZ3VhZ2UpfSB0byBjb21wYXJlYH1cbiAgICAgICAgICAgICAgICBhcmlhLXByZXNzZWQ9e2NvbXBhcmluZ31cbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBvblRvZ2dsZUNvbXBhcmUoc3BhY2UuaWQpfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgICAgICAgICAgICBcInByZXNzIHJvdW5kZWQtZnVsbCBwLTIgYmFja2Ryb3AtYmx1ci1zbSB0cmFuc2l0aW9uLWNvbG9yc1wiLFxuICAgICAgICAgICAgICAgICAgY29tcGFyaW5nID8gXCJiZy1hcXVhLTYwMCB0ZXh0LXdoaXRlXCIgOiBcImJnLXN1cmZhY2UvOTAgdGV4dC1pbmstc29mdCBob3ZlcjpiZy1zdXJmYWNlXCIsXG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxTY2FsZSBzaXplPXsxNX0gYXJpYS1oaWRkZW4gLz5cbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICApfVxuICAgICAgICAgICAge29uVG9nZ2xlU2F2ZSAmJiAoXG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICBhcmlhLWxhYmVsPXtzYXZlZCA/IGBSZW1vdmUgJHtzcGFjZU5hbWUoc3BhY2UsIGxhbmd1YWdlKX0gZnJvbSBzYXZlZGAgOiBgU2F2ZSAke3NwYWNlTmFtZShzcGFjZSwgbGFuZ3VhZ2UpfWB9XG4gICAgICAgICAgICAgICAgYXJpYS1wcmVzc2VkPXtzYXZlZH1cbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBvblRvZ2dsZVNhdmUoc3BhY2UuaWQpfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQtZnVsbCBiZy1zdXJmYWNlLzkwIHAtMiB0ZXh0LWluay1zb2Z0IGJhY2tkcm9wLWJsdXItc20gdHJhbnNpdGlvbi1jb2xvcnMgaG92ZXI6Ymctc3VyZmFjZSBob3Zlcjp0ZXh0LWFxdWEtNzAwXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxCb29rbWFyayBzaXplPXsxNX0gY2xhc3NOYW1lPXtjbihzYXZlZCAmJiBcImZpbGwtYXF1YS02MDAgdGV4dC1hcXVhLTYwMFwiKX0gYXJpYS1oaWRkZW4gLz5cbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICApfVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIGluc2V0LXgtMy41IGJvdHRvbS0zXCI+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwiZm9udC1kaXNwbGF5IHRleHQteGwgZm9udC1ib2xkIGxlYWRpbmctbm9uZSB0ZXh0LXdoaXRlIHRudW1cIj5cbiAgICAgICAgICAgIHtpc1NhbGUgPyBtb25leShzcGFjZS5jb3N0LnByaWNlKSA6IG1vbmV5Q29tcGFjdChzcGFjZS5jb3N0LnByaWNlKX1cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1sLTEgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXdoaXRlLzc1XCI+XG4gICAgICAgICAgICAgIHtpc1NhbGUgPyBcIlwiIDogdChcInRyYW5zYWN0aW9uLnBlck1vbnRoXCIpfVxuICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgIDwvcD5cbiAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwibXQtMSB0cnVuY2F0ZSBmb250LXNlbWlib2xkIHRleHQtd2hpdGVcIj5cbiAgICAgICAgICAgIDxMaW5rIHRvPXtgL3NwYWNlLyR7c3BhY2UuaWR9YH0gY2xhc3NOYW1lPVwiYWZ0ZXI6YWJzb2x1dGUgYWZ0ZXI6aW5zZXQtMCBmb2N1czpvdXRsaW5lLW5vbmVcIj5cbiAgICAgICAgICAgICAge3NwYWNlTmFtZShzcGFjZSwgbGFuZ3VhZ2UpfVxuICAgICAgICAgICAgPC9MaW5rPlxuICAgICAgICAgIDwvaDM+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidHJ1bmNhdGUgdGV4dC1zbSB0ZXh0LXdoaXRlLzc1XCI+XG4gICAgICAgICAgICB7cHJvcGVydHkubmVpZ2hib3Job29kfSwge3Byb3BlcnR5LmFyZWF9XG4gICAgICAgICAgPC9wPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJwb2ludGVyLWV2ZW50cy1ub25lIGFic29sdXRlIGJvdHRvbS0zIHJpZ2h0LTMuNSByb3VuZGVkIGJnLWluay81NSBweC0xLjUgcHktMC41IHRleHQtWzAuNnJlbV0gZm9udC1zZW1pYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZSB0ZXh0LXdoaXRlLzkwXCI+XG4gICAgICAgICAge3QoXCJtaXNjLmRlbW9cIil9XG4gICAgICAgIDwvc3Bhbj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC0xIGZsZXgtY29sIGdhcC0yIHAtMy41XCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgaXRlbXMtY2VudGVyIGdhcC0xLjVcIj5cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2NuKFwicm91bmRlZCBweC0xLjUgcHktMC41IHRleHQteHMgZm9udC1zZW1pYm9sZFwiLCBjYXQuY2hpcCl9PlxuICAgICAgICAgICAge3QoYHR5cGUuJHtzcGFjZS5zcGFjZVR5cGV9YCBhcyBuZXZlcil9XG4gICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgIHtpc1NhbGUgJiYgKFxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicm91bmRlZCBiZy1pbmsgcHgtMS41IHB5LTAuNSB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1pdm9yeVwiPlxuICAgICAgICAgICAgICB7dChcInRyYW5zYWN0aW9uLmZvclNhbGVcIil9XG4gICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgKX1cbiAgICAgICAgICB7LyogUGFpZCBwbGFjZW1lbnQgc2F5cyBzby4gQW4gYWR2ZXJ0aXNlbWVudCB0aGF0IGxvb2tzIGxpa2UgYSByZXN1bHRcbiAgICAgICAgICAgICAgaXMgZXhhY3RseSB3aGF0IG1ha2VzIGEgbGlzdGluZyBzaXRlIHVudHJ1c3R3b3J0aHksIGFuZCBiZWluZ1xuICAgICAgICAgICAgICB0cnVzdHdvcnRoeSBpcyB0aGUgd2hvbGUgYXJndW1lbnQgaGVyZS4gKi99XG4gICAgICAgICAge3NwYWNlLnNwb25zb3JlZFVudGlsICYmIChcbiAgICAgICAgICAgIDxzcGFuXG4gICAgICAgICAgICAgIHRpdGxlPXt0KFwic3BvbnNvcmVkLmV4cGxhaW5cIil9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQgYmctc3VuLzYwIHB4LTEuNSBweS0wLjUgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc3VuLWlua1wiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIHt0KFwic3BvbnNvcmVkLmxhYmVsXCIpfVxuICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICl9XG4gICAgICAgICAgey8qIEF2YWlsYWJpbGl0eSBvbmx5IHdoZW4gaXQgaXMgbm90IHRoZSBleHBlY3RlZCBcImZyZWVcIiDigJQgYSBiYWRnZVxuICAgICAgICAgICAgICB0aGF0IGFwcGVhcnMgb24gbmluZSBjYXJkcyBpbiB0ZW4gY2FycmllcyBubyBpbmZvcm1hdGlvbi4gKi99XG4gICAgICAgICAge3NwYWNlLmF2YWlsYWJpbGl0eS5zdGF0dXMgIT09IFwiYXZhaWxhYmxlXCIgJiYgKFxuICAgICAgICAgICAgPEF2YWlsYWJpbGl0eUJhZGdlIGF2YWlsYWJpbGl0eT17c3BhY2UuYXZhaWxhYmlsaXR5fSAvPlxuICAgICAgICAgICl9XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1pbmstc29mdFwiPntrZXlTcGVjKGxpc3RpbmcpfTwvcD5cblxuICAgICAgICB7c3BhY2UudHJhbnNhY3Rpb24gPT09IFwicmVudFwiICYmXG4gICAgICAgICAgKHNwYWNlLmNvc3QuZXN0aW1hdGVkTW9udGhseSA/IChcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzAuODEyNXJlbV0gdGV4dC1tdXRlZCB0bnVtXCI+XG4gICAgICAgICAgICAgIHt0KFwibWlzYy5hYm91dEFsbEluXCIsIHsgcHJpY2U6IG1vbmV5KHNwYWNlLmNvc3QuZXN0aW1hdGVkTW9udGhseSkgfSl9XG4gICAgICAgICAgICA8L3A+XG4gICAgICAgICAgKSA6IChcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzAuODEyNXJlbV0gZm9udC1tZWRpdW0gdGV4dC13YXJuLTcwMFwiPnt0KFwibWlzYy5mdWxsQ29zdE5vdExpc3RlZFwiKX08L3A+XG4gICAgICAgICAgKSl9XG5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC1hdXRvIGhpZGRlbiBpdGVtcy1jZW50ZXIgZ2FwLTIgYm9yZGVyLXQgYm9yZGVyLWhhaXJsaW5lIHB0LTIuNSBzbTpmbGV4XCI+XG4gICAgICAgICAgPFRydXN0QmFkZ2UgdmVyaWZpY2F0aW9uPXtzcGFjZS52ZXJpZmljYXRpb259IGNvbXBhY3QgLz5cbiAgICAgICAgICA8c3BhblxuICAgICAgICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgICAgICAgXCJtbC1hdXRvIHRleHQteHNcIixcbiAgICAgICAgICAgICAgaXNTdGFsZShzcGFjZS5sYXN0VXBkYXRlZCkgPyBcImZvbnQtbWVkaXVtIHRleHQtd2Fybi03MDBcIiA6IFwidGV4dC1tdXRlZFwiLFxuICAgICAgICAgICAgKX1cbiAgICAgICAgICA+XG4gICAgICAgICAgICB7bGFzdFVwZGF0ZWRTaG9ydChzcGFjZS5sYXN0VXBkYXRlZCl9XG4gICAgICAgICAgPC9zcGFuPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgIDwvYXJ0aWNsZT5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiRDovSTJJIFByb2plY3QgLSBIYWJpdG8vQXBwIEZvbGRlci9oYWJpdG8vc3JjL2NvbXBvbmVudHMvc3BhY2UvU3BhY2VDYXJkLnRzeCJ9