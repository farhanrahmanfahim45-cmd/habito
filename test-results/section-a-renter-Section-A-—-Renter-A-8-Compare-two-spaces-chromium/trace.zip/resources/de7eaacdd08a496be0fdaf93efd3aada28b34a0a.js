import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Find.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=9ceb86a3"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("D:/I2I Project - Habito/App Folder/habito/src/pages/Find.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9ceb86a3"; const useState = __vite__cjsImport3_react["useState"];
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=9ceb86a3";
import { ArrowRight } from "/node_modules/.vite/deps/lucide-react.js?v=9ceb86a3";
import { useHabito } from "/src/hooks/useHabito.tsx";
import { Button } from "/src/components/ui/Button.tsx";
import { CATEGORY_STYLE, TYPES_BY_CATEGORY, AMENITIES, AMENITIES_BY_CATEGORY } from "/src/data/catalog.ts";
import { AreaPicker } from "/src/components/ui/AreaPicker.tsx";
import { SPACE_TYPE_LABEL } from "/src/types/space.ts";
import { cn } from "/src/lib/cn.ts";
import { useI18n } from "/src/i18n/index.tsx";
const CATEGORIES = Object.keys(CATEGORY_STYLE);
export default function Find() {
  _s();
  const { t } = useI18n();
  const navigate = useNavigate();
  const { requirements, setRequirements } = useHabito();
  const [draft, setDraft] = useState(requirements);
  const set = (k, v) => setDraft((d) => ({ ...d, [k]: v }));
  const amenityPool = draft.category === "any" ? Object.keys(AMENITIES).slice(0, 12) : AMENITIES_BY_CATEGORY[draft.category];
  const typePool = draft.category === "any" ? [] : TYPES_BY_CATEGORY[draft.category];
  const budgetInvalid = draft.budgetMax < draft.budgetMin;
  return /* @__PURE__ */ jsxDEV("div", { className: "container-page max-w-3xl py-10 md:py-14", children: [
    /* @__PURE__ */ jsxDEV("header", { children: [
      /* @__PURE__ */ jsxDEV("h1", { className: "font-display text-3xl font-extrabold text-ink sm:text-5xl", children: "Tell us what you need." }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Find.tsx",
        lineNumber: 55,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "mt-3 text-base leading-relaxed text-ink-soft", children: "A few answers, and every space afterwards arrives with a score and the reasons behind it." }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Find.tsx",
        lineNumber: 58,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Find.tsx",
      lineNumber: 54,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "mt-9 space-y-5", children: [
      /* @__PURE__ */ jsxDEV(Card, { title: t("find.rentOrBuy"), children: /* @__PURE__ */ jsxDEV("div", { className: "inline-flex rounded-full bg-ivory-deep p-0.5", children: ["rent", "sale"].map(
        (t2) => /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            "aria-pressed": draft.transaction === t2,
            onClick: () => set("transaction", t2),
            className: cn(
              "rounded-full px-5 py-2 text-sm font-bold transition-colors",
              draft.transaction === t2 ? "bg-ink text-ivory" : "text-muted hover:text-ink"
            ),
            children: t2 === "rent" ? "Renting" : "Buying"
          },
          t2,
          false,
          {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Find.tsx",
            lineNumber: 67,
            columnNumber: 13
          },
          this
        )
      ) }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Find.tsx",
        lineNumber: 65,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Find.tsx",
        lineNumber: 64,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Card, { title: t("find.whatKind"), children: [
        /* @__PURE__ */ jsxDEV("ul", { className: "flex flex-wrap gap-2", children: [
          /* @__PURE__ */ jsxDEV("li", { children: /* @__PURE__ */ jsxDEV(Chip, { active: draft.category === "any", onClick: () => {
            set("category", "any");
            set("spaceType", "any");
          }, children: "Anything" }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Find.tsx",
            lineNumber: 86,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Find.tsx",
            lineNumber: 85,
            columnNumber: 13
          }, this),
          CATEGORIES.map((c) => {
            const Icon = CATEGORY_STYLE[c].icon;
            return /* @__PURE__ */ jsxDEV("li", { children: /* @__PURE__ */ jsxDEV(Chip, { active: draft.category === c, onClick: () => {
              set("category", c);
              set("spaceType", "any");
            }, children: [
              /* @__PURE__ */ jsxDEV(Icon, { size: 14, "aria-hidden": true }, void 0, false, {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Find.tsx",
                lineNumber: 95,
                columnNumber: 21
              }, this),
              CATEGORY_STYLE[c].label
            ] }, void 0, true, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Find.tsx",
              lineNumber: 94,
              columnNumber: 19
            }, this) }, c, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Find.tsx",
              lineNumber: 93,
              columnNumber: 17
            }, this);
          })
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Find.tsx",
          lineNumber: 84,
          columnNumber: 11
        }, this),
        typePool.length > 1 && /* @__PURE__ */ jsxDEV(Fragment, { children: [
          /* @__PURE__ */ jsxDEV("p", { className: "mb-2 mt-5 text-sm font-medium text-ink-soft", children: "Anything more specific?" }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Find.tsx",
            lineNumber: 105,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("ul", { className: "flex flex-wrap gap-2", children: [
            /* @__PURE__ */ jsxDEV("li", { children: /* @__PURE__ */ jsxDEV(Chip, { small: true, active: draft.spaceType === "any", onClick: () => set("spaceType", "any"), children: [
              "Any ",
              CATEGORY_STYLE[draft.category].label.toLowerCase(),
              " space"
            ] }, void 0, true, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Find.tsx",
              lineNumber: 108,
              columnNumber: 19
            }, this) }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Find.tsx",
              lineNumber: 107,
              columnNumber: 17
            }, this),
            typePool.map(
              (t2) => /* @__PURE__ */ jsxDEV("li", { children: /* @__PURE__ */ jsxDEV(Chip, { small: true, active: draft.spaceType === t2, onClick: () => set("spaceType", t2), children: SPACE_TYPE_LABEL[t2] }, void 0, false, {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Find.tsx",
                lineNumber: 114,
                columnNumber: 21
              }, this) }, t2, false, {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Find.tsx",
                lineNumber: 113,
                columnNumber: 15
              }, this)
            )
          ] }, void 0, true, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Find.tsx",
            lineNumber: 106,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Find.tsx",
          lineNumber: 104,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Find.tsx",
        lineNumber: 83,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Card, { title: t("find.where"), children: [
        /* @__PURE__ */ jsxDEV("div", { className: "sm:max-w-sm", children: /* @__PURE__ */ jsxDEV(AreaPicker, { value: draft.area, onChange: (v) => set("area", v) }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Find.tsx",
          lineNumber: 126,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Find.tsx",
          lineNumber: 125,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-xs text-muted", children: "Spaces nearby still appear, ranked by how far they are from here." }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Find.tsx",
          lineNumber: 128,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Find.tsx",
        lineNumber: 124,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Card, { title: draft.transaction === "rent" ? "Monthly budget" : "Price range", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "grid max-w-md grid-cols-2 gap-3", children: [
          /* @__PURE__ */ jsxDEV(NumberField, { label: "Minimum", value: draft.budgetMin, onChange: (v) => set("budgetMin", v) }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Find.tsx",
            lineNumber: 135,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(NumberField, { label: "Maximum", value: draft.budgetMax, onChange: (v) => set("budgetMax", v) }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Find.tsx",
            lineNumber: 136,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Find.tsx",
          lineNumber: 134,
          columnNumber: 11
        }, this),
        budgetInvalid && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm font-medium text-danger-600", children: "Your maximum is below your minimum." }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Find.tsx",
          lineNumber: 139,
          columnNumber: 11
        }, this),
        draft.transaction === "rent" && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-xs leading-relaxed text-muted", children: "Where an owner has listed every cost, we score against the full monthly figure — rent plus service charge and utilities — not rent alone." }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Find.tsx",
          lineNumber: 142,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Find.tsx",
        lineNumber: 133,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Card, { title: t("find.whenNeed"), children: /* @__PURE__ */ jsxDEV(
        "input",
        {
          type: "date",
          "aria-label": "Move-in date",
          value: draft.moveInDate,
          onChange: (e) => set("moveInDate", e.target.value),
          className: "h-11 rounded-xl bg-ivory px-3 text-[0.9375rem] text-ink ring-1 ring-hairline-strong focus:outline-none focus:ring-2 focus:ring-aqua-600"
        },
        void 0,
        false,
        {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Find.tsx",
          lineNumber: 150,
          columnNumber: 11
        },
        this
      ) }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Find.tsx",
        lineNumber: 149,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(CapacityCard, { draft, set }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Find.tsx",
        lineNumber: 159,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Card, { title: t("find.essential"), optional: true, children: /* @__PURE__ */ jsxDEV("ul", { className: "flex flex-wrap gap-2", children: amenityPool.map((key) => {
        const { icon: Icon } = AMENITIES[key];
        const label = t(`amenity.${key}`);
        const on = draft.amenities.includes(key);
        return /* @__PURE__ */ jsxDEV("li", { children: /* @__PURE__ */ jsxDEV(
          Chip,
          {
            small: true,
            active: on,
            onClick: () => set("amenities", on ? draft.amenities.filter((a) => a !== key) : [...draft.amenities, key]),
            children: [
              /* @__PURE__ */ jsxDEV(Icon, { size: 13, "aria-hidden": true }, void 0, false, {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Find.tsx",
                lineNumber: 176,
                columnNumber: 21
              }, this),
              label
            ]
          },
          void 0,
          true,
          {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Find.tsx",
            lineNumber: 169,
            columnNumber: 19
          },
          this
        ) }, key, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Find.tsx",
          lineNumber: 168,
          columnNumber: 17
        }, this);
      }) }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Find.tsx",
        lineNumber: 162,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Find.tsx",
        lineNumber: 161,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Find.tsx",
      lineNumber: 63,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "sticky bottom-16 mt-8 rounded-full bg-surface/90 p-2 shadow-[0_16px_40px_-20px_rgb(16_24_40/0.5)] ring-1 ring-hairline backdrop-blur md:bottom-5", children: /* @__PURE__ */ jsxDEV(
      Button,
      {
        size: "lg",
        fullWidth: true,
        disabled: budgetInvalid,
        onClick: () => {
          setRequirements(draft);
          navigate("/search");
        },
        children: [
          "Show my matches",
          /* @__PURE__ */ jsxDEV(ArrowRight, { size: 17, "aria-hidden": true }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Find.tsx",
            lineNumber: 197,
            columnNumber: 11
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Find.tsx",
        lineNumber: 187,
        columnNumber: 9
      },
      this
    ) }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Find.tsx",
      lineNumber: 186,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Find.tsx",
    lineNumber: 53,
    columnNumber: 5
  }, this);
}
_s(Find, "bxsDoBcXaEaoAOkINghgH9889eE=", false, function() {
  return [useI18n, useNavigate, useHabito];
});
_c = Find;
function CapacityCard({
  draft,
  set
}) {
  _s2();
  const { t } = useI18n();
  const cap = draft.capacity;
  const put = (patch) => set("capacity", { ...cap, ...patch });
  if (draft.category === "any") return null;
  const CONFIG = {
    living: {
      label: t("find.minBedrooms"),
      key: "minBedrooms",
      choices: [
        { v: null, label: t("find.noMinimum") },
        { v: 1, label: "1+" },
        { v: 2, label: "2+" },
        { v: 3, label: "3+" },
        { v: 4, label: "4+" }
      ]
    },
    business: {
      label: t("find.minSize"),
      key: "minSizeSqft",
      choices: [
        { v: null, label: t("find.noMinimum") },
        { v: 200, label: "200+ sqft" },
        { v: 500, label: "500+ sqft" },
        { v: 1e3, label: "1,000+ sqft" },
        { v: 2e3, label: "2,000+ sqft" }
      ]
    },
    storage: {
      label: t("find.minStorage"),
      key: "minSizeSqft",
      choices: [
        { v: null, label: t("find.noMinimum") },
        { v: 500, label: "500+ sqft" },
        { v: 1e3, label: "1,000+ sqft" },
        { v: 2e3, label: "2,000+ sqft" },
        { v: 4e3, label: "4,000+ sqft" }
      ]
    },
    parking: {
      label: t("find.slotsNeeded"),
      key: "carSlots",
      choices: [
        { v: null, label: t("find.noMinimum") },
        { v: 1, label: "1" },
        { v: 2, label: "2" },
        { v: 3, label: "3+" }
      ]
    },
    land: {
      label: t("find.minLand"),
      key: "minLandDecimal",
      choices: [
        { v: null, label: t("find.noMinimum") },
        { v: 10, label: "10+ decimal" },
        { v: 30, label: "30+ decimal" },
        { v: 60, label: "60+ decimal" },
        { v: 100, label: "100+ decimal" }
      ]
    }
  };
  const config = CONFIG[draft.category];
  if (!config) return null;
  const current = cap[config.key] ?? null;
  return /* @__PURE__ */ jsxDEV(Card, { title: config.label, optional: true, children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-2", children: config.choices.map(
      (choice) => /* @__PURE__ */ jsxDEV(
        Chip,
        {
          small: true,
          active: current === choice.v,
          onClick: () => put({ [config.key]: choice.v }),
          children: choice.label
        },
        String(choice.v),
        false,
        {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Find.tsx",
          lineNumber: 298,
          columnNumber: 9
        },
        this
      )
    ) }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Find.tsx",
      lineNumber: 296,
      columnNumber: 7
    }, this),
    draft.category === "storage" && /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV("p", { className: "mb-2 mt-5 text-sm font-medium text-ink-soft", children: t("find.minCeiling") }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Find.tsx",
        lineNumber: 311,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-2", children: [null, 10, 14, 18].map(
        (v) => /* @__PURE__ */ jsxDEV(
          Chip,
          {
            small: true,
            active: (cap.minCeilingFt ?? null) === v,
            onClick: () => put({ minCeilingFt: v }),
            children: v === null ? t("find.noMinimum") : `${v}+ ft`
          },
          String(v),
          false,
          {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Find.tsx",
            lineNumber: 314,
            columnNumber: 11
          },
          this
        )
      ) }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Find.tsx",
        lineNumber: 312,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Find.tsx",
      lineNumber: 310,
      columnNumber: 7
    }, this),
    draft.category === "parking" && /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV("p", { className: "mb-2 mt-5 text-sm font-medium text-ink-soft", children: t("find.motorcycleSlots") }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Find.tsx",
        lineNumber: 329,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-2", children: [null, 1, 2, 4].map(
        (v) => /* @__PURE__ */ jsxDEV(
          Chip,
          {
            small: true,
            active: (cap.motorcycleSlots ?? null) === v,
            onClick: () => put({ motorcycleSlots: v }),
            children: v === null ? t("find.noMinimum") : String(v)
          },
          String(v),
          false,
          {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Find.tsx",
            lineNumber: 332,
            columnNumber: 11
          },
          this
        )
      ) }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Find.tsx",
        lineNumber: 330,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Find.tsx",
      lineNumber: 328,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("p", { className: "mt-4 text-xs leading-relaxed text-muted", children: t("find.capacityNote") }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Find.tsx",
      lineNumber: 345,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Find.tsx",
    lineNumber: 295,
    columnNumber: 5
  }, this);
}
_s2(CapacityCard, "82N5KF9nLzZ6+2WH7KIjzIXRkLw=", false, function() {
  return [useI18n];
});
_c2 = CapacityCard;
function Card({ title, optional, children }) {
  return /* @__PURE__ */ jsxDEV("section", { className: "rounded-card bg-surface p-5 ring-1 ring-hairline sm:p-6", children: [
    /* @__PURE__ */ jsxDEV("h2", { className: "mb-4 font-display text-lg font-bold text-ink", children: [
      title,
      optional && /* @__PURE__ */ jsxDEV("span", { className: "ml-2 text-xs font-medium text-muted", children: "optional" }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Find.tsx",
        lineNumber: 355,
        columnNumber: 22
      }, this)
    ] }, void 0, true, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Find.tsx",
      lineNumber: 353,
      columnNumber: 7
    }, this),
    children
  ] }, void 0, true, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Find.tsx",
    lineNumber: 352,
    columnNumber: 5
  }, this);
}
_c3 = Card;
function Chip({
  active,
  small,
  onClick,
  children
}) {
  return /* @__PURE__ */ jsxDEV(
    "button",
    {
      type: "button",
      "aria-pressed": active,
      onClick,
      className: cn(
        "inline-flex items-center gap-1.5 rounded-full font-semibold transition-all duration-150",
        small ? "px-3 py-1.5 text-xs" : "px-4 py-2 text-sm",
        active ? "bg-ink text-ivory" : "bg-ivory-deep text-ink-soft hover:bg-hairline"
      ),
      children
    },
    void 0,
    false,
    {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Find.tsx",
      lineNumber: 374,
      columnNumber: 5
    },
    this
  );
}
_c4 = Chip;
function NumberField({ label, value, onChange }) {
  return /* @__PURE__ */ jsxDEV("label", { className: "block", children: [
    /* @__PURE__ */ jsxDEV("span", { className: "mb-1.5 block text-sm font-medium text-ink-soft", children: label }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Find.tsx",
      lineNumber: 392,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "relative", children: [
      /* @__PURE__ */ jsxDEV("span", { className: "pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-muted", children: "৳" }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Find.tsx",
        lineNumber: 394,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        "input",
        {
          type: "number",
          inputMode: "numeric",
          step: 500,
          min: 0,
          value,
          onChange: (e) => onChange(Number(e.target.value)),
          className: "h-11 w-full rounded-xl bg-ivory pl-7 pr-3 text-[0.9375rem] tnum text-ink ring-1 ring-hairline-strong focus:outline-none focus:ring-2 focus:ring-aqua-600"
        },
        void 0,
        false,
        {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Find.tsx",
          lineNumber: 395,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Find.tsx",
      lineNumber: 393,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Find.tsx",
    lineNumber: 391,
    columnNumber: 5
  }, this);
}
_c5 = NumberField;
var _c, _c2, _c3, _c4, _c5;
$RefreshReg$(_c, "Find");
$RefreshReg$(_c2, "CapacityCard");
$RefreshReg$(_c3, "Card");
$RefreshReg$(_c4, "Chip");
$RefreshReg$(_c5, "NumberField");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/I2I Project - Habito/App Folder/habito/src/pages/Find.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/I2I Project - Habito/App Folder/habito/src/pages/Find.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbUNRLFNBaURJLFVBakRKOzs7Ozs7Ozs7Ozs7Ozs7OztBQW5DUixTQUFTQSxnQkFBZ0I7QUFDekIsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLGtCQUFrQjtBQUMzQixTQUFTQyxpQkFBaUI7QUFDMUIsU0FBU0MsY0FBYztBQUN2QixTQUFTQyxnQkFBZ0JDLG1CQUFtQkMsV0FBV0MsNkJBQTZCO0FBQ3BGLFNBQVNDLGtCQUFrQjtBQUMzQixTQUFTQyx3QkFBd0I7QUFFakMsU0FBU0MsVUFBVTtBQUNuQixTQUFTQyxlQUFlO0FBRXhCLE1BQU1DLGFBQWFDLE9BQU9DLEtBQUtWLGNBQWM7QUFHN0Msd0JBQXdCVyxPQUFPO0FBQUFDLEtBQUE7QUFDN0IsUUFBTSxFQUFFQyxFQUFFLElBQUlOLFFBQVE7QUFDdEIsUUFBTU8sV0FBV2xCLFlBQVk7QUFDN0IsUUFBTSxFQUFFbUIsY0FBY0MsZ0JBQWdCLElBQUlsQixVQUFVO0FBQ3BELFFBQU0sQ0FBQ21CLE9BQU9DLFFBQVEsSUFBSXZCLFNBQTZCb0IsWUFBWTtBQUVuRSxRQUFNSSxNQUFNLENBQXFDQyxHQUFNQyxNQUNyREgsU0FBUyxDQUFDSSxPQUFPLEVBQUUsR0FBR0EsR0FBRyxDQUFDRixDQUFDLEdBQUdDLEVBQUUsRUFBRTtBQUVwQyxRQUFNRSxjQUNKTixNQUFNTyxhQUFhLFFBQ2RmLE9BQU9DLEtBQUtSLFNBQVMsRUFBbUJ1QixNQUFNLEdBQUcsRUFBRSxJQUNwRHRCLHNCQUFzQmMsTUFBTU8sUUFBUTtBQUUxQyxRQUFNRSxXQUF3QlQsTUFBTU8sYUFBYSxRQUFRLEtBQUt2QixrQkFBa0JnQixNQUFNTyxRQUFRO0FBQzlGLFFBQU1HLGdCQUFnQlYsTUFBTVcsWUFBWVgsTUFBTVk7QUFFOUMsU0FDRSx1QkFBQyxTQUFJLFdBQVUsMkNBQ2I7QUFBQSwyQkFBQyxZQUNDO0FBQUEsNkJBQUMsUUFBRyxXQUFVLDZEQUEyRCxzQ0FBekU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxPQUFFLFdBQVUsZ0RBQThDLHlHQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxTQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FPQTtBQUFBLElBRUEsdUJBQUMsU0FBSSxXQUFVLGtCQUNiO0FBQUEsNkJBQUMsUUFBSyxPQUFPaEIsRUFBRSxnQkFBZ0IsR0FDN0IsaUNBQUMsU0FBSSxXQUFVLGdEQUNYLFdBQUMsUUFBUSxNQUFNLEVBQXdCaUI7QUFBQUEsUUFBSSxDQUFDakIsT0FDNUM7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUVDLE1BQUs7QUFBQSxZQUNMLGdCQUFjSSxNQUFNYyxnQkFBZ0JsQjtBQUFBQSxZQUNwQyxTQUFTLE1BQU1NLElBQUksZUFBZU4sRUFBQztBQUFBLFlBQ25DLFdBQVdQO0FBQUFBLGNBQ1Q7QUFBQSxjQUNBVyxNQUFNYyxnQkFBZ0JsQixLQUFJLHNCQUFzQjtBQUFBLFlBQ2xEO0FBQUEsWUFFQ0EsaUJBQU0sU0FBUyxZQUFZO0FBQUE7QUFBQSxVQVR2QkE7QUFBQUEsVUFEUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBV0E7QUFBQSxNQUNELEtBZEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWVBLEtBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFpQkE7QUFBQSxNQUVBLHVCQUFDLFFBQUssT0FBT0EsRUFBRSxlQUFlLEdBQzVCO0FBQUEsK0JBQUMsUUFBRyxXQUFVLHdCQUNaO0FBQUEsaUNBQUMsUUFDQyxpQ0FBQyxRQUFLLFFBQVFJLE1BQU1PLGFBQWEsT0FBTyxTQUFTLE1BQU07QUFBRUwsZ0JBQUksWUFBWSxLQUFLO0FBQUdBLGdCQUFJLGFBQWEsS0FBSztBQUFBLFVBQUcsR0FBRSx3QkFBNUc7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBSUE7QUFBQSxVQUNDWCxXQUFXc0IsSUFBSSxDQUFDRSxNQUFNO0FBQ3JCLGtCQUFNQyxPQUFPakMsZUFBZWdDLENBQUMsRUFBRUU7QUFDL0IsbUJBQ0UsdUJBQUMsUUFDQyxpQ0FBQyxRQUFLLFFBQVFqQixNQUFNTyxhQUFhUSxHQUFHLFNBQVMsTUFBTTtBQUFFYixrQkFBSSxZQUFZYSxDQUFDO0FBQUdiLGtCQUFJLGFBQWEsS0FBSztBQUFBLFlBQUcsR0FDaEc7QUFBQSxxQ0FBQyxRQUFLLE1BQU0sSUFBSSxlQUFXLFFBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTJCO0FBQUEsY0FDMUJuQixlQUFlZ0MsQ0FBQyxFQUFFRztBQUFBQSxpQkFGckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQSxLQUpPSCxHQUFUO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBS0E7QUFBQSxVQUVKLENBQUM7QUFBQSxhQWhCSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBaUJBO0FBQUEsUUFFQ04sU0FBU1UsU0FBUyxLQUNqQixtQ0FDRTtBQUFBLGlDQUFDLE9BQUUsV0FBVSwrQ0FBOEMsdUNBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWtGO0FBQUEsVUFDbEYsdUJBQUMsUUFBRyxXQUFVLHdCQUNaO0FBQUEsbUNBQUMsUUFDQyxpQ0FBQyxRQUFLLE9BQUssTUFBQyxRQUFRbkIsTUFBTW9CLGNBQWMsT0FBTyxTQUFTLE1BQU1sQixJQUFJLGFBQWEsS0FBSyxHQUFFO0FBQUE7QUFBQSxjQUMvRW5CLGVBQWVpQixNQUFNTyxRQUF5QixFQUFFVyxNQUFNRyxZQUFZO0FBQUEsY0FBRTtBQUFBLGlCQUQzRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFJQTtBQUFBLFlBQ0NaLFNBQVNJO0FBQUFBLGNBQUksQ0FBQ2pCLE9BQ2IsdUJBQUMsUUFDQyxpQ0FBQyxRQUFLLE9BQUssTUFBQyxRQUFRSSxNQUFNb0IsY0FBY3hCLElBQUcsU0FBUyxNQUFNTSxJQUFJLGFBQWFOLEVBQUMsR0FDekVSLDJCQUFpQlEsRUFBQyxLQURyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBLEtBSE9BLElBQVQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFJQTtBQUFBLFlBQ0Q7QUFBQSxlQVpIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBYUE7QUFBQSxhQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFnQkE7QUFBQSxXQXJDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBdUNBO0FBQUEsTUFFQSx1QkFBQyxRQUFLLE9BQU9BLEVBQUUsWUFBWSxHQUN6QjtBQUFBLCtCQUFDLFNBQUksV0FBVSxlQUNiLGlDQUFDLGNBQVcsT0FBT0ksTUFBTXNCLE1BQU0sVUFBVSxDQUFDbEIsTUFBTUYsSUFBSSxRQUFRRSxDQUFDLEtBQTdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBK0QsS0FEakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxPQUFFLFdBQVUsMkJBQXlCLGlGQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFPQTtBQUFBLE1BRUEsdUJBQUMsUUFBSyxPQUFPSixNQUFNYyxnQkFBZ0IsU0FBUyxtQkFBbUIsZUFDN0Q7QUFBQSwrQkFBQyxTQUFJLFdBQVUsbUNBQ2I7QUFBQSxpQ0FBQyxlQUFZLE9BQU0sV0FBVSxPQUFPZCxNQUFNWSxXQUFXLFVBQVUsQ0FBQ1IsTUFBTUYsSUFBSSxhQUFhRSxDQUFDLEtBQXhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTBGO0FBQUEsVUFDMUYsdUJBQUMsZUFBWSxPQUFNLFdBQVUsT0FBT0osTUFBTVcsV0FBVyxVQUFVLENBQUNQLE1BQU1GLElBQUksYUFBYUUsQ0FBQyxLQUF4RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEwRjtBQUFBLGFBRjVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBQ0NNLGlCQUNDLHVCQUFDLE9BQUUsV0FBVSw0Q0FBMkMsbURBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMkY7QUFBQSxRQUU1RlYsTUFBTWMsZ0JBQWdCLFVBQ3JCLHVCQUFDLE9BQUUsV0FBVSwyQ0FBeUMseUpBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFdBWko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWNBO0FBQUEsTUFFQSx1QkFBQyxRQUFLLE9BQU9sQixFQUFFLGVBQWUsR0FDNUI7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE1BQUs7QUFBQSxVQUNMLGNBQVc7QUFBQSxVQUNYLE9BQU9JLE1BQU11QjtBQUFBQSxVQUNiLFVBQVUsQ0FBQ0MsTUFBTXRCLElBQUksY0FBY3NCLEVBQUVDLE9BQU9DLEtBQUs7QUFBQSxVQUNqRCxXQUFVO0FBQUE7QUFBQSxRQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUtxSixLQU52SjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBUUE7QUFBQSxNQUVBLHVCQUFDLGdCQUFhLE9BQWMsT0FBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFxQztBQUFBLE1BRXJDLHVCQUFDLFFBQUssT0FBTzlCLEVBQUUsZ0JBQWdCLEdBQUcsVUFBUSxNQUN4QyxpQ0FBQyxRQUFHLFdBQVUsd0JBQ1hVLHNCQUFZTyxJQUFJLENBQUNjLFFBQVE7QUFDeEIsY0FBTSxFQUFFVixNQUFNRCxLQUFLLElBQUkvQixVQUFVMEMsR0FBRztBQUNwQyxjQUFNVCxRQUFRdEIsRUFBRSxXQUFXK0IsR0FBRyxFQUFXO0FBQ3pDLGNBQU1DLEtBQUs1QixNQUFNNkIsVUFBVUMsU0FBU0gsR0FBRztBQUN2QyxlQUNFLHVCQUFDLFFBQ0M7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDO0FBQUEsWUFDQSxRQUFRQztBQUFBQSxZQUNSLFNBQVMsTUFDUDFCLElBQUksYUFBYTBCLEtBQUs1QixNQUFNNkIsVUFBVUUsT0FBTyxDQUFDQyxNQUFNQSxNQUFNTCxHQUFHLElBQUksQ0FBQyxHQUFHM0IsTUFBTTZCLFdBQVdGLEdBQUcsQ0FBQztBQUFBLFlBRzVGO0FBQUEscUNBQUMsUUFBSyxNQUFNLElBQUksZUFBVyxRQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEyQjtBQUFBLGNBQzFCVDtBQUFBQTtBQUFBQTtBQUFBQSxVQVJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQVNBLEtBVk9TLEtBQVQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVdBO0FBQUEsTUFFSixDQUFDLEtBbkJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFvQkEsS0FyQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXNCQTtBQUFBLFNBeEhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F5SEE7QUFBQSxJQUVBLHVCQUFDLFNBQUksV0FBVSxvSkFDYjtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsTUFBSztBQUFBLFFBQ0w7QUFBQSxRQUNBLFVBQVVqQjtBQUFBQSxRQUNWLFNBQVMsTUFBTTtBQUNiWCwwQkFBZ0JDLEtBQUs7QUFDckJILG1CQUFTLFNBQVM7QUFBQSxRQUNwQjtBQUFBLFFBQUU7QUFBQTtBQUFBLFVBR0YsdUJBQUMsY0FBVyxNQUFNLElBQUksZUFBVyxRQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFpQztBQUFBO0FBQUE7QUFBQSxNQVZuQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFXQSxLQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FhQTtBQUFBLE9BbEpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FtSkE7QUFFSjtBQUVBRixHQXpLd0JELE1BQUk7QUFBQSxVQUNaSixTQUNHWCxhQUN5QkUsU0FBUztBQUFBO0FBQUEsS0FIN0JhO0FBOEt4QixTQUFTdUMsYUFBYTtBQUFBLEVBQ3BCakM7QUFBQUEsRUFDQUU7QUFJRixHQUFHO0FBQUFnQyxNQUFBO0FBQ0QsUUFBTSxFQUFFdEMsRUFBRSxJQUFJTixRQUFRO0FBQ3RCLFFBQU02QyxNQUFNbkMsTUFBTW9DO0FBQ2xCLFFBQU1DLE1BQU1BLENBQUNDLFVBQW1EcEMsSUFBSSxZQUFZLEVBQUUsR0FBR2lDLEtBQUssR0FBR0csTUFBTSxDQUFDO0FBR3BHLE1BQUl0QyxNQUFNTyxhQUFhLE1BQU8sUUFBTztBQUVyQyxRQUFNZ0MsU0FTRjtBQUFBLElBQ0ZDLFFBQVE7QUFBQSxNQUNOdEIsT0FBT3RCLEVBQUUsa0JBQWtCO0FBQUEsTUFDM0IrQixLQUFLO0FBQUEsTUFDTGMsU0FBUztBQUFBLFFBQ1AsRUFBRXJDLEdBQUcsTUFBTWMsT0FBT3RCLEVBQUUsZ0JBQWdCLEVBQUU7QUFBQSxRQUN0QyxFQUFFUSxHQUFHLEdBQUdjLE9BQU8sS0FBSztBQUFBLFFBQ3BCLEVBQUVkLEdBQUcsR0FBR2MsT0FBTyxLQUFLO0FBQUEsUUFDcEIsRUFBRWQsR0FBRyxHQUFHYyxPQUFPLEtBQUs7QUFBQSxRQUNwQixFQUFFZCxHQUFHLEdBQUdjLE9BQU8sS0FBSztBQUFBLE1BQUM7QUFBQSxJQUV6QjtBQUFBLElBQ0F3QixVQUFVO0FBQUEsTUFDUnhCLE9BQU90QixFQUFFLGNBQWM7QUFBQSxNQUN2QitCLEtBQUs7QUFBQSxNQUNMYyxTQUFTO0FBQUEsUUFDUCxFQUFFckMsR0FBRyxNQUFNYyxPQUFPdEIsRUFBRSxnQkFBZ0IsRUFBRTtBQUFBLFFBQ3RDLEVBQUVRLEdBQUcsS0FBS2MsT0FBTyxZQUFZO0FBQUEsUUFDN0IsRUFBRWQsR0FBRyxLQUFLYyxPQUFPLFlBQVk7QUFBQSxRQUM3QixFQUFFZCxHQUFHLEtBQU1jLE9BQU8sY0FBYztBQUFBLFFBQ2hDLEVBQUVkLEdBQUcsS0FBTWMsT0FBTyxjQUFjO0FBQUEsTUFBQztBQUFBLElBRXJDO0FBQUEsSUFDQXlCLFNBQVM7QUFBQSxNQUNQekIsT0FBT3RCLEVBQUUsaUJBQWlCO0FBQUEsTUFDMUIrQixLQUFLO0FBQUEsTUFDTGMsU0FBUztBQUFBLFFBQ1AsRUFBRXJDLEdBQUcsTUFBTWMsT0FBT3RCLEVBQUUsZ0JBQWdCLEVBQUU7QUFBQSxRQUN0QyxFQUFFUSxHQUFHLEtBQUtjLE9BQU8sWUFBWTtBQUFBLFFBQzdCLEVBQUVkLEdBQUcsS0FBTWMsT0FBTyxjQUFjO0FBQUEsUUFDaEMsRUFBRWQsR0FBRyxLQUFNYyxPQUFPLGNBQWM7QUFBQSxRQUNoQyxFQUFFZCxHQUFHLEtBQU1jLE9BQU8sY0FBYztBQUFBLE1BQUM7QUFBQSxJQUVyQztBQUFBLElBQ0EwQixTQUFTO0FBQUEsTUFDUDFCLE9BQU90QixFQUFFLGtCQUFrQjtBQUFBLE1BQzNCK0IsS0FBSztBQUFBLE1BQ0xjLFNBQVM7QUFBQSxRQUNQLEVBQUVyQyxHQUFHLE1BQU1jLE9BQU90QixFQUFFLGdCQUFnQixFQUFFO0FBQUEsUUFDdEMsRUFBRVEsR0FBRyxHQUFHYyxPQUFPLElBQUk7QUFBQSxRQUNuQixFQUFFZCxHQUFHLEdBQUdjLE9BQU8sSUFBSTtBQUFBLFFBQ25CLEVBQUVkLEdBQUcsR0FBR2MsT0FBTyxLQUFLO0FBQUEsTUFBQztBQUFBLElBRXpCO0FBQUEsSUFDQTJCLE1BQU07QUFBQSxNQUNKM0IsT0FBT3RCLEVBQUUsY0FBYztBQUFBLE1BQ3ZCK0IsS0FBSztBQUFBLE1BQ0xjLFNBQVM7QUFBQSxRQUNQLEVBQUVyQyxHQUFHLE1BQU1jLE9BQU90QixFQUFFLGdCQUFnQixFQUFFO0FBQUEsUUFDdEMsRUFBRVEsR0FBRyxJQUFJYyxPQUFPLGNBQWM7QUFBQSxRQUM5QixFQUFFZCxHQUFHLElBQUljLE9BQU8sY0FBYztBQUFBLFFBQzlCLEVBQUVkLEdBQUcsSUFBSWMsT0FBTyxjQUFjO0FBQUEsUUFDOUIsRUFBRWQsR0FBRyxLQUFLYyxPQUFPLGVBQWU7QUFBQSxNQUFDO0FBQUEsSUFFckM7QUFBQSxFQUNGO0FBRUEsUUFBTTRCLFNBQVNQLE9BQU92QyxNQUFNTyxRQUFRO0FBQ3BDLE1BQUksQ0FBQ3VDLE9BQVEsUUFBTztBQUVwQixRQUFNQyxVQUFVWixJQUFJVyxPQUFPbkIsR0FBRyxLQUFLO0FBRW5DLFNBQ0UsdUJBQUMsUUFBSyxPQUFPbUIsT0FBTzVCLE9BQU8sVUFBUSxNQUNqQztBQUFBLDJCQUFDLFNBQUksV0FBVSx3QkFDWjRCLGlCQUFPTCxRQUFRNUI7QUFBQUEsTUFBSSxDQUFDbUMsV0FDbkI7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUVDO0FBQUEsVUFDQSxRQUFRRCxZQUFZQyxPQUFPNUM7QUFBQUEsVUFDM0IsU0FBUyxNQUFNaUMsSUFBSSxFQUFFLENBQUNTLE9BQU9uQixHQUFHLEdBQUdxQixPQUFPNUMsRUFBRSxDQUFDO0FBQUEsVUFFNUM0QyxpQkFBTzlCO0FBQUFBO0FBQUFBLFFBTEgrQixPQUFPRCxPQUFPNUMsQ0FBQztBQUFBLFFBRHRCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFPQTtBQUFBLElBQ0QsS0FWSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBV0E7QUFBQSxJQUVDSixNQUFNTyxhQUFhLGFBQ2xCLG1DQUNFO0FBQUEsNkJBQUMsT0FBRSxXQUFVLCtDQUErQ1gsWUFBRSxpQkFBaUIsS0FBL0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpRjtBQUFBLE1BQ2pGLHVCQUFDLFNBQUksV0FBVSx3QkFDWixXQUFDLE1BQU0sSUFBSSxJQUFJLEVBQUUsRUFBRWlCO0FBQUFBLFFBQUksQ0FBQ1QsTUFDdkI7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUVDO0FBQUEsWUFDQSxTQUFTK0IsSUFBSWUsZ0JBQWdCLFVBQVU5QztBQUFBQSxZQUN2QyxTQUFTLE1BQU1pQyxJQUFJLEVBQUVhLGNBQWM5QyxFQUFFLENBQUM7QUFBQSxZQUVyQ0EsZ0JBQU0sT0FBT1IsRUFBRSxnQkFBZ0IsSUFBSSxHQUFHUSxDQUFDO0FBQUE7QUFBQSxVQUxuQzZDLE9BQU83QyxDQUFDO0FBQUEsVUFEZjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBT0E7QUFBQSxNQUNELEtBVkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVdBO0FBQUEsU0FiRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBY0E7QUFBQSxJQUdESixNQUFNTyxhQUFhLGFBQ2xCLG1DQUNFO0FBQUEsNkJBQUMsT0FBRSxXQUFVLCtDQUErQ1gsWUFBRSxzQkFBc0IsS0FBcEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFzRjtBQUFBLE1BQ3RGLHVCQUFDLFNBQUksV0FBVSx3QkFDWixXQUFDLE1BQU0sR0FBRyxHQUFHLENBQUMsRUFBRWlCO0FBQUFBLFFBQUksQ0FBQ1QsTUFDcEI7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUVDO0FBQUEsWUFDQSxTQUFTK0IsSUFBSWdCLG1CQUFtQixVQUFVL0M7QUFBQUEsWUFDMUMsU0FBUyxNQUFNaUMsSUFBSSxFQUFFYyxpQkFBaUIvQyxFQUFFLENBQUM7QUFBQSxZQUV4Q0EsZ0JBQU0sT0FBT1IsRUFBRSxnQkFBZ0IsSUFBSXFELE9BQU83QyxDQUFDO0FBQUE7QUFBQSxVQUx2QzZDLE9BQU83QyxDQUFDO0FBQUEsVUFEZjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBT0E7QUFBQSxNQUNELEtBVkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVdBO0FBQUEsU0FiRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBY0E7QUFBQSxJQUdGLHVCQUFDLE9BQUUsV0FBVSwyQ0FBMkNSLFlBQUUsbUJBQW1CLEtBQTdFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBK0U7QUFBQSxPQWxEakY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQW1EQTtBQUVKO0FBQUNzQyxJQTNJUUQsY0FBWTtBQUFBLFVBT0wzQyxPQUFPO0FBQUE7QUFBQSxNQVBkMkM7QUE2SVQsU0FBU21CLEtBQUssRUFBRUMsT0FBT0MsVUFBVUMsU0FBMkUsR0FBRztBQUM3RyxTQUNFLHVCQUFDLGFBQVEsV0FBVSwyREFDakI7QUFBQSwyQkFBQyxRQUFHLFdBQVUsZ0RBQ1hGO0FBQUFBO0FBQUFBLE1BQ0FDLFlBQVksdUJBQUMsVUFBSyxXQUFVLHVDQUFzQyx3QkFBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE4RDtBQUFBLFNBRjdFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQTtBQUFBLElBQ0NDO0FBQUFBLE9BTEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQU1BO0FBRUo7QUFBQ0MsTUFWUUo7QUFZVCxTQUFTSyxLQUFLO0FBQUEsRUFDWkM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUw7QUFNRixHQUFHO0FBQ0QsU0FDRTtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0MsTUFBSztBQUFBLE1BQ0wsZ0JBQWNHO0FBQUFBLE1BQ2Q7QUFBQSxNQUNBLFdBQVdyRTtBQUFBQSxRQUNUO0FBQUEsUUFDQXNFLFFBQVEsd0JBQXdCO0FBQUEsUUFDaENELFNBQVMsc0JBQXNCO0FBQUEsTUFDakM7QUFBQSxNQUVDSDtBQUFBQTtBQUFBQSxJQVZIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQVdBO0FBRUo7QUFBQ00sTUF6QlFKO0FBMkJULFNBQVNLLFlBQVksRUFBRTVDLE9BQU9RLE9BQU9xQyxTQUEwRSxHQUFHO0FBQ2hILFNBQ0UsdUJBQUMsV0FBTSxXQUFVLFNBQ2Y7QUFBQSwyQkFBQyxVQUFLLFdBQVUsa0RBQWtEN0MsbUJBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBd0U7QUFBQSxJQUN4RSx1QkFBQyxTQUFJLFdBQVUsWUFDYjtBQUFBLDZCQUFDLFVBQUssV0FBVSwyRUFBMEUsaUJBQTFGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMkY7QUFBQSxNQUMzRjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsTUFBSztBQUFBLFVBQ0wsV0FBVTtBQUFBLFVBQ1YsTUFBTTtBQUFBLFVBQ04sS0FBSztBQUFBLFVBQ0w7QUFBQSxVQUNBLFVBQVUsQ0FBQ00sTUFBTXVDLFNBQVNDLE9BQU94QyxFQUFFQyxPQUFPQyxLQUFLLENBQUM7QUFBQSxVQUNoRCxXQUFVO0FBQUE7QUFBQSxRQVBaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQU9zSztBQUFBLFNBVHhLO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FXQTtBQUFBLE9BYkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWNBO0FBRUo7QUFBQ3VDLE1BbEJRSDtBQUFXLElBQUFJLElBQUFDLEtBQUFYLEtBQUFLLEtBQUFJO0FBQUEsYUFBQUMsSUFBQTtBQUFBLGFBQUFDLEtBQUE7QUFBQSxhQUFBWCxLQUFBO0FBQUEsYUFBQUssS0FBQTtBQUFBLGFBQUFJLEtBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsInVzZU5hdmlnYXRlIiwiQXJyb3dSaWdodCIsInVzZUhhYml0byIsIkJ1dHRvbiIsIkNBVEVHT1JZX1NUWUxFIiwiVFlQRVNfQllfQ0FURUdPUlkiLCJBTUVOSVRJRVMiLCJBTUVOSVRJRVNfQllfQ0FURUdPUlkiLCJBcmVhUGlja2VyIiwiU1BBQ0VfVFlQRV9MQUJFTCIsImNuIiwidXNlSTE4biIsIkNBVEVHT1JJRVMiLCJPYmplY3QiLCJrZXlzIiwiRmluZCIsIl9zIiwidCIsIm5hdmlnYXRlIiwicmVxdWlyZW1lbnRzIiwic2V0UmVxdWlyZW1lbnRzIiwiZHJhZnQiLCJzZXREcmFmdCIsInNldCIsImsiLCJ2IiwiZCIsImFtZW5pdHlQb29sIiwiY2F0ZWdvcnkiLCJzbGljZSIsInR5cGVQb29sIiwiYnVkZ2V0SW52YWxpZCIsImJ1ZGdldE1heCIsImJ1ZGdldE1pbiIsIm1hcCIsInRyYW5zYWN0aW9uIiwiYyIsIkljb24iLCJpY29uIiwibGFiZWwiLCJsZW5ndGgiLCJzcGFjZVR5cGUiLCJ0b0xvd2VyQ2FzZSIsImFyZWEiLCJtb3ZlSW5EYXRlIiwiZSIsInRhcmdldCIsInZhbHVlIiwia2V5Iiwib24iLCJhbWVuaXRpZXMiLCJpbmNsdWRlcyIsImZpbHRlciIsImEiLCJDYXBhY2l0eUNhcmQiLCJfczIiLCJjYXAiLCJjYXBhY2l0eSIsInB1dCIsInBhdGNoIiwiQ09ORklHIiwibGl2aW5nIiwiY2hvaWNlcyIsImJ1c2luZXNzIiwic3RvcmFnZSIsInBhcmtpbmciLCJsYW5kIiwiY29uZmlnIiwiY3VycmVudCIsImNob2ljZSIsIlN0cmluZyIsIm1pbkNlaWxpbmdGdCIsIm1vdG9yY3ljbGVTbG90cyIsIkNhcmQiLCJ0aXRsZSIsIm9wdGlvbmFsIiwiY2hpbGRyZW4iLCJfYzMiLCJDaGlwIiwiYWN0aXZlIiwic21hbGwiLCJvbkNsaWNrIiwiX2M0IiwiTnVtYmVyRmllbGQiLCJvbkNoYW5nZSIsIk51bWJlciIsIl9jNSIsIl9jIiwiX2MyIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkZpbmQudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyB1c2VOYXZpZ2F0ZSB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XG5pbXBvcnQgeyBBcnJvd1JpZ2h0IH0gZnJvbSBcImx1Y2lkZS1yZWFjdFwiO1xuaW1wb3J0IHsgdXNlSGFiaXRvIH0gZnJvbSBcIkAvaG9va3MvdXNlSGFiaXRvXCI7XG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tIFwiQC9jb21wb25lbnRzL3VpL0J1dHRvblwiO1xuaW1wb3J0IHsgQ0FURUdPUllfU1RZTEUsIFRZUEVTX0JZX0NBVEVHT1JZLCBBTUVOSVRJRVMsIEFNRU5JVElFU19CWV9DQVRFR09SWSB9IGZyb20gXCJAL2RhdGEvY2F0YWxvZ1wiO1xuaW1wb3J0IHsgQXJlYVBpY2tlciB9IGZyb20gXCJAL2NvbXBvbmVudHMvdWkvQXJlYVBpY2tlclwiO1xuaW1wb3J0IHsgU1BBQ0VfVFlQRV9MQUJFTCB9IGZyb20gXCJAL3R5cGVzL3NwYWNlXCI7XG5pbXBvcnQgdHlwZSB7IEFtZW5pdHlLZXksIFNlYXJjaFJlcXVpcmVtZW50cywgU3BhY2VDYXRlZ29yeSwgU3BhY2VUeXBlLCBUcmFuc2FjdGlvblR5cGUgfSBmcm9tIFwiQC90eXBlcy9zcGFjZVwiO1xuaW1wb3J0IHsgY24gfSBmcm9tIFwiQC9saWIvY25cIjtcbmltcG9ydCB7IHVzZUkxOG4gfSBmcm9tIFwiQC9pMThuXCI7XG5cbmNvbnN0IENBVEVHT1JJRVMgPSBPYmplY3Qua2V5cyhDQVRFR09SWV9TVFlMRSkgYXMgU3BhY2VDYXRlZ29yeVtdO1xuXG4vKiogUmVxdWlyZW1lbnQgaW50YWtlLiBXaGF0IHlvdSBhbnN3ZXIgaGVyZSBkcml2ZXMgZXZlcnkgc2NvcmUgeW91IHNlZSBhZnRlci4gKi9cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEZpbmQoKSB7XG4gIGNvbnN0IHsgdCB9ID0gdXNlSTE4bigpO1xuICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XG4gIGNvbnN0IHsgcmVxdWlyZW1lbnRzLCBzZXRSZXF1aXJlbWVudHMgfSA9IHVzZUhhYml0bygpO1xuICBjb25zdCBbZHJhZnQsIHNldERyYWZ0XSA9IHVzZVN0YXRlPFNlYXJjaFJlcXVpcmVtZW50cz4ocmVxdWlyZW1lbnRzKTtcblxuICBjb25zdCBzZXQgPSA8SyBleHRlbmRzIGtleW9mIFNlYXJjaFJlcXVpcmVtZW50cz4oazogSywgdjogU2VhcmNoUmVxdWlyZW1lbnRzW0tdKSA9PlxuICAgIHNldERyYWZ0KChkKSA9PiAoeyAuLi5kLCBba106IHYgfSkpO1xuXG4gIGNvbnN0IGFtZW5pdHlQb29sOiBBbWVuaXR5S2V5W10gPVxuICAgIGRyYWZ0LmNhdGVnb3J5ID09PSBcImFueVwiXG4gICAgICA/IChPYmplY3Qua2V5cyhBTUVOSVRJRVMpIGFzIEFtZW5pdHlLZXlbXSkuc2xpY2UoMCwgMTIpXG4gICAgICA6IEFNRU5JVElFU19CWV9DQVRFR09SWVtkcmFmdC5jYXRlZ29yeV07XG5cbiAgY29uc3QgdHlwZVBvb2w6IFNwYWNlVHlwZVtdID0gZHJhZnQuY2F0ZWdvcnkgPT09IFwiYW55XCIgPyBbXSA6IFRZUEVTX0JZX0NBVEVHT1JZW2RyYWZ0LmNhdGVnb3J5XTtcbiAgY29uc3QgYnVkZ2V0SW52YWxpZCA9IGRyYWZ0LmJ1ZGdldE1heCA8IGRyYWZ0LmJ1ZGdldE1pbjtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiY29udGFpbmVyLXBhZ2UgbWF4LXctM3hsIHB5LTEwIG1kOnB5LTE0XCI+XG4gICAgICA8aGVhZGVyPlxuICAgICAgICA8aDEgY2xhc3NOYW1lPVwiZm9udC1kaXNwbGF5IHRleHQtM3hsIGZvbnQtZXh0cmFib2xkIHRleHQtaW5rIHNtOnRleHQtNXhsXCI+XG4gICAgICAgICAgVGVsbCB1cyB3aGF0IHlvdSBuZWVkLlxuICAgICAgICA8L2gxPlxuICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0zIHRleHQtYmFzZSBsZWFkaW5nLXJlbGF4ZWQgdGV4dC1pbmstc29mdFwiPlxuICAgICAgICAgIEEgZmV3IGFuc3dlcnMsIGFuZCBldmVyeSBzcGFjZSBhZnRlcndhcmRzIGFycml2ZXMgd2l0aCBhIHNjb3JlIGFuZCB0aGUgcmVhc29ucyBiZWhpbmQgaXQuXG4gICAgICAgIDwvcD5cbiAgICAgIDwvaGVhZGVyPlxuXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTkgc3BhY2UteS01XCI+XG4gICAgICAgIDxDYXJkIHRpdGxlPXt0KFwiZmluZC5yZW50T3JCdXlcIil9PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggcm91bmRlZC1mdWxsIGJnLWl2b3J5LWRlZXAgcC0wLjVcIj5cbiAgICAgICAgICAgIHsoW1wicmVudFwiLCBcInNhbGVcIl0gYXMgVHJhbnNhY3Rpb25UeXBlW10pLm1hcCgodCkgPT4gKFxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAga2V5PXt0fVxuICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgIGFyaWEtcHJlc3NlZD17ZHJhZnQudHJhbnNhY3Rpb24gPT09IHR9XG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0KFwidHJhbnNhY3Rpb25cIiwgdCl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgICAgICAgICAgIFwicm91bmRlZC1mdWxsIHB4LTUgcHktMiB0ZXh0LXNtIGZvbnQtYm9sZCB0cmFuc2l0aW9uLWNvbG9yc1wiLFxuICAgICAgICAgICAgICAgICAgZHJhZnQudHJhbnNhY3Rpb24gPT09IHQgPyBcImJnLWluayB0ZXh0LWl2b3J5XCIgOiBcInRleHQtbXV0ZWQgaG92ZXI6dGV4dC1pbmtcIixcbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAge3QgPT09IFwicmVudFwiID8gXCJSZW50aW5nXCIgOiBcIkJ1eWluZ1wifVxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICkpfVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L0NhcmQ+XG5cbiAgICAgICAgPENhcmQgdGl0bGU9e3QoXCJmaW5kLndoYXRLaW5kXCIpfT5cbiAgICAgICAgICA8dWwgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgZ2FwLTJcIj5cbiAgICAgICAgICAgIDxsaT5cbiAgICAgICAgICAgICAgPENoaXAgYWN0aXZlPXtkcmFmdC5jYXRlZ29yeSA9PT0gXCJhbnlcIn0gb25DbGljaz17KCkgPT4geyBzZXQoXCJjYXRlZ29yeVwiLCBcImFueVwiKTsgc2V0KFwic3BhY2VUeXBlXCIsIFwiYW55XCIpOyB9fT5cbiAgICAgICAgICAgICAgICBBbnl0aGluZ1xuICAgICAgICAgICAgICA8L0NoaXA+XG4gICAgICAgICAgICA8L2xpPlxuICAgICAgICAgICAge0NBVEVHT1JJRVMubWFwKChjKSA9PiB7XG4gICAgICAgICAgICAgIGNvbnN0IEljb24gPSBDQVRFR09SWV9TVFlMRVtjXS5pY29uO1xuICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgIDxsaSBrZXk9e2N9PlxuICAgICAgICAgICAgICAgICAgPENoaXAgYWN0aXZlPXtkcmFmdC5jYXRlZ29yeSA9PT0gY30gb25DbGljaz17KCkgPT4geyBzZXQoXCJjYXRlZ29yeVwiLCBjKTsgc2V0KFwic3BhY2VUeXBlXCIsIFwiYW55XCIpOyB9fT5cbiAgICAgICAgICAgICAgICAgICAgPEljb24gc2l6ZT17MTR9IGFyaWEtaGlkZGVuIC8+XG4gICAgICAgICAgICAgICAgICAgIHtDQVRFR09SWV9TVFlMRVtjXS5sYWJlbH1cbiAgICAgICAgICAgICAgICAgIDwvQ2hpcD5cbiAgICAgICAgICAgICAgICA8L2xpPlxuICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgfSl9XG4gICAgICAgICAgPC91bD5cblxuICAgICAgICAgIHt0eXBlUG9vbC5sZW5ndGggPiAxICYmIChcbiAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm1iLTIgbXQtNSB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtaW5rLXNvZnRcIj5Bbnl0aGluZyBtb3JlIHNwZWNpZmljPzwvcD5cbiAgICAgICAgICAgICAgPHVsIGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgPGxpPlxuICAgICAgICAgICAgICAgICAgPENoaXAgc21hbGwgYWN0aXZlPXtkcmFmdC5zcGFjZVR5cGUgPT09IFwiYW55XCJ9IG9uQ2xpY2s9eygpID0+IHNldChcInNwYWNlVHlwZVwiLCBcImFueVwiKX0+XG4gICAgICAgICAgICAgICAgICAgIEFueSB7Q0FURUdPUllfU1RZTEVbZHJhZnQuY2F0ZWdvcnkgYXMgU3BhY2VDYXRlZ29yeV0ubGFiZWwudG9Mb3dlckNhc2UoKX0gc3BhY2VcbiAgICAgICAgICAgICAgICAgIDwvQ2hpcD5cbiAgICAgICAgICAgICAgICA8L2xpPlxuICAgICAgICAgICAgICAgIHt0eXBlUG9vbC5tYXAoKHQpID0+IChcbiAgICAgICAgICAgICAgICAgIDxsaSBrZXk9e3R9PlxuICAgICAgICAgICAgICAgICAgICA8Q2hpcCBzbWFsbCBhY3RpdmU9e2RyYWZ0LnNwYWNlVHlwZSA9PT0gdH0gb25DbGljaz17KCkgPT4gc2V0KFwic3BhY2VUeXBlXCIsIHQpfT5cbiAgICAgICAgICAgICAgICAgICAgICB7U1BBQ0VfVFlQRV9MQUJFTFt0XX1cbiAgICAgICAgICAgICAgICAgICAgPC9DaGlwPlxuICAgICAgICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgPC91bD5cbiAgICAgICAgICAgIDwvPlxuICAgICAgICAgICl9XG4gICAgICAgIDwvQ2FyZD5cblxuICAgICAgICA8Q2FyZCB0aXRsZT17dChcImZpbmQud2hlcmVcIil9PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic206bWF4LXctc21cIj5cbiAgICAgICAgICAgIDxBcmVhUGlja2VyIHZhbHVlPXtkcmFmdC5hcmVhfSBvbkNoYW5nZT17KHYpID0+IHNldChcImFyZWFcIiwgdil9IC8+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXhzIHRleHQtbXV0ZWRcIj5cbiAgICAgICAgICAgIFNwYWNlcyBuZWFyYnkgc3RpbGwgYXBwZWFyLCByYW5rZWQgYnkgaG93IGZhciB0aGV5IGFyZSBmcm9tIGhlcmUuXG4gICAgICAgICAgPC9wPlxuICAgICAgICA8L0NhcmQ+XG5cbiAgICAgICAgPENhcmQgdGl0bGU9e2RyYWZ0LnRyYW5zYWN0aW9uID09PSBcInJlbnRcIiA/IFwiTW9udGhseSBidWRnZXRcIiA6IFwiUHJpY2UgcmFuZ2VcIn0+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIG1heC13LW1kIGdyaWQtY29scy0yIGdhcC0zXCI+XG4gICAgICAgICAgICA8TnVtYmVyRmllbGQgbGFiZWw9XCJNaW5pbXVtXCIgdmFsdWU9e2RyYWZ0LmJ1ZGdldE1pbn0gb25DaGFuZ2U9eyh2KSA9PiBzZXQoXCJidWRnZXRNaW5cIiwgdil9IC8+XG4gICAgICAgICAgICA8TnVtYmVyRmllbGQgbGFiZWw9XCJNYXhpbXVtXCIgdmFsdWU9e2RyYWZ0LmJ1ZGdldE1heH0gb25DaGFuZ2U9eyh2KSA9PiBzZXQoXCJidWRnZXRNYXhcIiwgdil9IC8+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAge2J1ZGdldEludmFsaWQgJiYgKFxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZGFuZ2VyLTYwMFwiPllvdXIgbWF4aW11bSBpcyBiZWxvdyB5b3VyIG1pbmltdW0uPC9wPlxuICAgICAgICAgICl9XG4gICAgICAgICAge2RyYWZ0LnRyYW5zYWN0aW9uID09PSBcInJlbnRcIiAmJiAoXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQteHMgbGVhZGluZy1yZWxheGVkIHRleHQtbXV0ZWRcIj5cbiAgICAgICAgICAgICAgV2hlcmUgYW4gb3duZXIgaGFzIGxpc3RlZCBldmVyeSBjb3N0LCB3ZSBzY29yZSBhZ2FpbnN0IHRoZSBmdWxsIG1vbnRobHkgZmlndXJlIOKAlCByZW50XG4gICAgICAgICAgICAgIHBsdXMgc2VydmljZSBjaGFyZ2UgYW5kIHV0aWxpdGllcyDigJQgbm90IHJlbnQgYWxvbmUuXG4gICAgICAgICAgICA8L3A+XG4gICAgICAgICAgKX1cbiAgICAgICAgPC9DYXJkPlxuXG4gICAgICAgIDxDYXJkIHRpdGxlPXt0KFwiZmluZC53aGVuTmVlZFwiKX0+XG4gICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICB0eXBlPVwiZGF0ZVwiXG4gICAgICAgICAgICBhcmlhLWxhYmVsPVwiTW92ZS1pbiBkYXRlXCJcbiAgICAgICAgICAgIHZhbHVlPXtkcmFmdC5tb3ZlSW5EYXRlfVxuICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXQoXCJtb3ZlSW5EYXRlXCIsIGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImgtMTEgcm91bmRlZC14bCBiZy1pdm9yeSBweC0zIHRleHQtWzAuOTM3NXJlbV0gdGV4dC1pbmsgcmluZy0xIHJpbmctaGFpcmxpbmUtc3Ryb25nIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1hcXVhLTYwMFwiXG4gICAgICAgICAgLz5cbiAgICAgICAgPC9DYXJkPlxuXG4gICAgICAgIDxDYXBhY2l0eUNhcmQgZHJhZnQ9e2RyYWZ0fSBzZXQ9e3NldH0gLz5cblxuICAgICAgICA8Q2FyZCB0aXRsZT17dChcImZpbmQuZXNzZW50aWFsXCIpfSBvcHRpb25hbD5cbiAgICAgICAgICA8dWwgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgZ2FwLTJcIj5cbiAgICAgICAgICAgIHthbWVuaXR5UG9vbC5tYXAoKGtleSkgPT4ge1xuICAgICAgICAgICAgICBjb25zdCB7IGljb246IEljb24gfSA9IEFNRU5JVElFU1trZXldO1xuICAgICAgICAgICAgICBjb25zdCBsYWJlbCA9IHQoYGFtZW5pdHkuJHtrZXl9YCBhcyBuZXZlcik7XG4gICAgICAgICAgICAgIGNvbnN0IG9uID0gZHJhZnQuYW1lbml0aWVzLmluY2x1ZGVzKGtleSk7XG4gICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgPGxpIGtleT17a2V5fT5cbiAgICAgICAgICAgICAgICAgIDxDaGlwXG4gICAgICAgICAgICAgICAgICAgIHNtYWxsXG4gICAgICAgICAgICAgICAgICAgIGFjdGl2ZT17b259XG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+XG4gICAgICAgICAgICAgICAgICAgICAgc2V0KFwiYW1lbml0aWVzXCIsIG9uID8gZHJhZnQuYW1lbml0aWVzLmZpbHRlcigoYSkgPT4gYSAhPT0ga2V5KSA6IFsuLi5kcmFmdC5hbWVuaXRpZXMsIGtleV0pXG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgPEljb24gc2l6ZT17MTN9IGFyaWEtaGlkZGVuIC8+XG4gICAgICAgICAgICAgICAgICAgIHtsYWJlbH1cbiAgICAgICAgICAgICAgICAgIDwvQ2hpcD5cbiAgICAgICAgICAgICAgICA8L2xpPlxuICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgfSl9XG4gICAgICAgICAgPC91bD5cbiAgICAgICAgPC9DYXJkPlxuICAgICAgPC9kaXY+XG5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3RpY2t5IGJvdHRvbS0xNiBtdC04IHJvdW5kZWQtZnVsbCBiZy1zdXJmYWNlLzkwIHAtMiBzaGFkb3ctWzBfMTZweF80MHB4Xy0yMHB4X3JnYigxNl8yNF80MC8wLjUpXSByaW5nLTEgcmluZy1oYWlybGluZSBiYWNrZHJvcC1ibHVyIG1kOmJvdHRvbS01XCI+XG4gICAgICAgIDxCdXR0b25cbiAgICAgICAgICBzaXplPVwibGdcIlxuICAgICAgICAgIGZ1bGxXaWR0aFxuICAgICAgICAgIGRpc2FibGVkPXtidWRnZXRJbnZhbGlkfVxuICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgIHNldFJlcXVpcmVtZW50cyhkcmFmdCk7XG4gICAgICAgICAgICBuYXZpZ2F0ZShcIi9zZWFyY2hcIik7XG4gICAgICAgICAgfX1cbiAgICAgICAgPlxuICAgICAgICAgIFNob3cgbXkgbWF0Y2hlc1xuICAgICAgICAgIDxBcnJvd1JpZ2h0IHNpemU9ezE3fSBhcmlhLWhpZGRlbiAvPlxuICAgICAgICA8L0J1dHRvbj5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufVxuXG4vKipcbiAqIFwiQmlnIGVub3VnaFwiIG1lYW5zIHNvbWV0aGluZyBkaWZmZXJlbnQgcGVyIGNhdGVnb3J5LCBzbyB0aGUgcXVlc3Rpb24gY2hhbmdlc1xuICogd2l0aCBpdDogYmVkcm9vbXMgZm9yIGEgaG9tZSwgZmxvb3IgYXJlYSBmb3IgYSBzaG9wLCBoZWFkcm9vbSBmb3IgYSBnb2Rvd24sXG4gKiBzbG90cyBmb3IgcGFya2luZywgZGVjaW1hbHMgZm9yIGxhbmQuXG4gKi9cbmZ1bmN0aW9uIENhcGFjaXR5Q2FyZCh7XG4gIGRyYWZ0LFxuICBzZXQsXG59OiB7XG4gIGRyYWZ0OiBTZWFyY2hSZXF1aXJlbWVudHM7XG4gIHNldDogPEsgZXh0ZW5kcyBrZXlvZiBTZWFyY2hSZXF1aXJlbWVudHM+KGs6IEssIHY6IFNlYXJjaFJlcXVpcmVtZW50c1tLXSkgPT4gdm9pZDtcbn0pIHtcbiAgY29uc3QgeyB0IH0gPSB1c2VJMThuKCk7XG4gIGNvbnN0IGNhcCA9IGRyYWZ0LmNhcGFjaXR5O1xuICBjb25zdCBwdXQgPSAocGF0Y2g6IFBhcnRpYWw8U2VhcmNoUmVxdWlyZW1lbnRzW1wiY2FwYWNpdHlcIl0+KSA9PiBzZXQoXCJjYXBhY2l0eVwiLCB7IC4uLmNhcCwgLi4ucGF0Y2ggfSk7XG5cbiAgLy8gVW50aWwgYSBjYXRlZ29yeSBpcyBjaG9zZW4gdGhlcmUgaXMgbm8gc2Vuc2libGUgdW5pdCB0byBhc2sgaW4uXG4gIGlmIChkcmFmdC5jYXRlZ29yeSA9PT0gXCJhbnlcIikgcmV0dXJuIG51bGw7XG5cbiAgY29uc3QgQ09ORklHOiBQYXJ0aWFsPFxuICAgIFJlY29yZDxcbiAgICAgIFNwYWNlQ2F0ZWdvcnksXG4gICAgICB7XG4gICAgICAgIGxhYmVsOiBzdHJpbmc7XG4gICAgICAgIGtleToga2V5b2YgU2VhcmNoUmVxdWlyZW1lbnRzW1wiY2FwYWNpdHlcIl07XG4gICAgICAgIGNob2ljZXM6IEFycmF5PHsgdjogbnVtYmVyIHwgbnVsbDsgbGFiZWw6IHN0cmluZyB9PjtcbiAgICAgIH1cbiAgICA+XG4gID4gPSB7XG4gICAgbGl2aW5nOiB7XG4gICAgICBsYWJlbDogdChcImZpbmQubWluQmVkcm9vbXNcIiksXG4gICAgICBrZXk6IFwibWluQmVkcm9vbXNcIixcbiAgICAgIGNob2ljZXM6IFtcbiAgICAgICAgeyB2OiBudWxsLCBsYWJlbDogdChcImZpbmQubm9NaW5pbXVtXCIpIH0sXG4gICAgICAgIHsgdjogMSwgbGFiZWw6IFwiMStcIiB9LFxuICAgICAgICB7IHY6IDIsIGxhYmVsOiBcIjIrXCIgfSxcbiAgICAgICAgeyB2OiAzLCBsYWJlbDogXCIzK1wiIH0sXG4gICAgICAgIHsgdjogNCwgbGFiZWw6IFwiNCtcIiB9LFxuICAgICAgXSxcbiAgICB9LFxuICAgIGJ1c2luZXNzOiB7XG4gICAgICBsYWJlbDogdChcImZpbmQubWluU2l6ZVwiKSxcbiAgICAgIGtleTogXCJtaW5TaXplU3FmdFwiLFxuICAgICAgY2hvaWNlczogW1xuICAgICAgICB7IHY6IG51bGwsIGxhYmVsOiB0KFwiZmluZC5ub01pbmltdW1cIikgfSxcbiAgICAgICAgeyB2OiAyMDAsIGxhYmVsOiBcIjIwMCsgc3FmdFwiIH0sXG4gICAgICAgIHsgdjogNTAwLCBsYWJlbDogXCI1MDArIHNxZnRcIiB9LFxuICAgICAgICB7IHY6IDEwMDAsIGxhYmVsOiBcIjEsMDAwKyBzcWZ0XCIgfSxcbiAgICAgICAgeyB2OiAyMDAwLCBsYWJlbDogXCIyLDAwMCsgc3FmdFwiIH0sXG4gICAgICBdLFxuICAgIH0sXG4gICAgc3RvcmFnZToge1xuICAgICAgbGFiZWw6IHQoXCJmaW5kLm1pblN0b3JhZ2VcIiksXG4gICAgICBrZXk6IFwibWluU2l6ZVNxZnRcIixcbiAgICAgIGNob2ljZXM6IFtcbiAgICAgICAgeyB2OiBudWxsLCBsYWJlbDogdChcImZpbmQubm9NaW5pbXVtXCIpIH0sXG4gICAgICAgIHsgdjogNTAwLCBsYWJlbDogXCI1MDArIHNxZnRcIiB9LFxuICAgICAgICB7IHY6IDEwMDAsIGxhYmVsOiBcIjEsMDAwKyBzcWZ0XCIgfSxcbiAgICAgICAgeyB2OiAyMDAwLCBsYWJlbDogXCIyLDAwMCsgc3FmdFwiIH0sXG4gICAgICAgIHsgdjogNDAwMCwgbGFiZWw6IFwiNCwwMDArIHNxZnRcIiB9LFxuICAgICAgXSxcbiAgICB9LFxuICAgIHBhcmtpbmc6IHtcbiAgICAgIGxhYmVsOiB0KFwiZmluZC5zbG90c05lZWRlZFwiKSxcbiAgICAgIGtleTogXCJjYXJTbG90c1wiLFxuICAgICAgY2hvaWNlczogW1xuICAgICAgICB7IHY6IG51bGwsIGxhYmVsOiB0KFwiZmluZC5ub01pbmltdW1cIikgfSxcbiAgICAgICAgeyB2OiAxLCBsYWJlbDogXCIxXCIgfSxcbiAgICAgICAgeyB2OiAyLCBsYWJlbDogXCIyXCIgfSxcbiAgICAgICAgeyB2OiAzLCBsYWJlbDogXCIzK1wiIH0sXG4gICAgICBdLFxuICAgIH0sXG4gICAgbGFuZDoge1xuICAgICAgbGFiZWw6IHQoXCJmaW5kLm1pbkxhbmRcIiksXG4gICAgICBrZXk6IFwibWluTGFuZERlY2ltYWxcIixcbiAgICAgIGNob2ljZXM6IFtcbiAgICAgICAgeyB2OiBudWxsLCBsYWJlbDogdChcImZpbmQubm9NaW5pbXVtXCIpIH0sXG4gICAgICAgIHsgdjogMTAsIGxhYmVsOiBcIjEwKyBkZWNpbWFsXCIgfSxcbiAgICAgICAgeyB2OiAzMCwgbGFiZWw6IFwiMzArIGRlY2ltYWxcIiB9LFxuICAgICAgICB7IHY6IDYwLCBsYWJlbDogXCI2MCsgZGVjaW1hbFwiIH0sXG4gICAgICAgIHsgdjogMTAwLCBsYWJlbDogXCIxMDArIGRlY2ltYWxcIiB9LFxuICAgICAgXSxcbiAgICB9LFxuICB9O1xuXG4gIGNvbnN0IGNvbmZpZyA9IENPTkZJR1tkcmFmdC5jYXRlZ29yeV07XG4gIGlmICghY29uZmlnKSByZXR1cm4gbnVsbDtcblxuICBjb25zdCBjdXJyZW50ID0gY2FwW2NvbmZpZy5rZXldID8/IG51bGw7XG5cbiAgcmV0dXJuIChcbiAgICA8Q2FyZCB0aXRsZT17Y29uZmlnLmxhYmVsfSBvcHRpb25hbD5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgZ2FwLTJcIj5cbiAgICAgICAge2NvbmZpZy5jaG9pY2VzLm1hcCgoY2hvaWNlKSA9PiAoXG4gICAgICAgICAgPENoaXBcbiAgICAgICAgICAgIGtleT17U3RyaW5nKGNob2ljZS52KX1cbiAgICAgICAgICAgIHNtYWxsXG4gICAgICAgICAgICBhY3RpdmU9e2N1cnJlbnQgPT09IGNob2ljZS52fVxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gcHV0KHsgW2NvbmZpZy5rZXldOiBjaG9pY2UudiB9KX1cbiAgICAgICAgICA+XG4gICAgICAgICAgICB7Y2hvaWNlLmxhYmVsfVxuICAgICAgICAgIDwvQ2hpcD5cbiAgICAgICAgKSl9XG4gICAgICA8L2Rpdj5cblxuICAgICAge2RyYWZ0LmNhdGVnb3J5ID09PSBcInN0b3JhZ2VcIiAmJiAoXG4gICAgICAgIDw+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwibWItMiBtdC01IHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1pbmstc29mdFwiPnt0KFwiZmluZC5taW5DZWlsaW5nXCIpfTwvcD5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGdhcC0yXCI+XG4gICAgICAgICAgICB7W251bGwsIDEwLCAxNCwgMThdLm1hcCgodikgPT4gKFxuICAgICAgICAgICAgICA8Q2hpcFxuICAgICAgICAgICAgICAgIGtleT17U3RyaW5nKHYpfVxuICAgICAgICAgICAgICAgIHNtYWxsXG4gICAgICAgICAgICAgICAgYWN0aXZlPXsoY2FwLm1pbkNlaWxpbmdGdCA/PyBudWxsKSA9PT0gdn1cbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBwdXQoeyBtaW5DZWlsaW5nRnQ6IHYgfSl9XG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICB7diA9PT0gbnVsbCA/IHQoXCJmaW5kLm5vTWluaW11bVwiKSA6IGAke3Z9KyBmdGB9XG4gICAgICAgICAgICAgIDwvQ2hpcD5cbiAgICAgICAgICAgICkpfVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8Lz5cbiAgICAgICl9XG5cbiAgICAgIHtkcmFmdC5jYXRlZ29yeSA9PT0gXCJwYXJraW5nXCIgJiYgKFxuICAgICAgICA8PlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm1iLTIgbXQtNSB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtaW5rLXNvZnRcIj57dChcImZpbmQubW90b3JjeWNsZVNsb3RzXCIpfTwvcD5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGdhcC0yXCI+XG4gICAgICAgICAgICB7W251bGwsIDEsIDIsIDRdLm1hcCgodikgPT4gKFxuICAgICAgICAgICAgICA8Q2hpcFxuICAgICAgICAgICAgICAgIGtleT17U3RyaW5nKHYpfVxuICAgICAgICAgICAgICAgIHNtYWxsXG4gICAgICAgICAgICAgICAgYWN0aXZlPXsoY2FwLm1vdG9yY3ljbGVTbG90cyA/PyBudWxsKSA9PT0gdn1cbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBwdXQoeyBtb3RvcmN5Y2xlU2xvdHM6IHYgfSl9XG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICB7diA9PT0gbnVsbCA/IHQoXCJmaW5kLm5vTWluaW11bVwiKSA6IFN0cmluZyh2KX1cbiAgICAgICAgICAgICAgPC9DaGlwPlxuICAgICAgICAgICAgKSl9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvPlxuICAgICAgKX1cblxuICAgICAgPHAgY2xhc3NOYW1lPVwibXQtNCB0ZXh0LXhzIGxlYWRpbmctcmVsYXhlZCB0ZXh0LW11dGVkXCI+e3QoXCJmaW5kLmNhcGFjaXR5Tm90ZVwiKX08L3A+XG4gICAgPC9DYXJkPlxuICApO1xufVxuXG5mdW5jdGlvbiBDYXJkKHsgdGl0bGUsIG9wdGlvbmFsLCBjaGlsZHJlbiB9OiB7IHRpdGxlOiBzdHJpbmc7IG9wdGlvbmFsPzogYm9vbGVhbjsgY2hpbGRyZW46IFJlYWN0LlJlYWN0Tm9kZSB9KSB7XG4gIHJldHVybiAoXG4gICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwicm91bmRlZC1jYXJkIGJnLXN1cmZhY2UgcC01IHJpbmctMSByaW5nLWhhaXJsaW5lIHNtOnAtNlwiPlxuICAgICAgPGgyIGNsYXNzTmFtZT1cIm1iLTQgZm9udC1kaXNwbGF5IHRleHQtbGcgZm9udC1ib2xkIHRleHQtaW5rXCI+XG4gICAgICAgIHt0aXRsZX1cbiAgICAgICAge29wdGlvbmFsICYmIDxzcGFuIGNsYXNzTmFtZT1cIm1sLTIgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LW11dGVkXCI+b3B0aW9uYWw8L3NwYW4+fVxuICAgICAgPC9oMj5cbiAgICAgIHtjaGlsZHJlbn1cbiAgICA8L3NlY3Rpb24+XG4gICk7XG59XG5cbmZ1bmN0aW9uIENoaXAoe1xuICBhY3RpdmUsXG4gIHNtYWxsLFxuICBvbkNsaWNrLFxuICBjaGlsZHJlbixcbn06IHtcbiAgYWN0aXZlOiBib29sZWFuO1xuICBzbWFsbD86IGJvb2xlYW47XG4gIG9uQ2xpY2s6ICgpID0+IHZvaWQ7XG4gIGNoaWxkcmVuOiBSZWFjdC5SZWFjdE5vZGU7XG59KSB7XG4gIHJldHVybiAoXG4gICAgPGJ1dHRvblxuICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICBhcmlhLXByZXNzZWQ9e2FjdGl2ZX1cbiAgICAgIG9uQ2xpY2s9e29uQ2xpY2t9XG4gICAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgICBcImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHJvdW5kZWQtZnVsbCBmb250LXNlbWlib2xkIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTE1MFwiLFxuICAgICAgICBzbWFsbCA/IFwicHgtMyBweS0xLjUgdGV4dC14c1wiIDogXCJweC00IHB5LTIgdGV4dC1zbVwiLFxuICAgICAgICBhY3RpdmUgPyBcImJnLWluayB0ZXh0LWl2b3J5XCIgOiBcImJnLWl2b3J5LWRlZXAgdGV4dC1pbmstc29mdCBob3ZlcjpiZy1oYWlybGluZVwiLFxuICAgICAgKX1cbiAgICA+XG4gICAgICB7Y2hpbGRyZW59XG4gICAgPC9idXR0b24+XG4gICk7XG59XG5cbmZ1bmN0aW9uIE51bWJlckZpZWxkKHsgbGFiZWwsIHZhbHVlLCBvbkNoYW5nZSB9OiB7IGxhYmVsOiBzdHJpbmc7IHZhbHVlOiBudW1iZXI7IG9uQ2hhbmdlOiAodjogbnVtYmVyKSA9PiB2b2lkIH0pIHtcbiAgcmV0dXJuIChcbiAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2tcIj5cbiAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1iLTEuNSBibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtaW5rLXNvZnRcIj57bGFiZWx9PC9zcGFuPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZVwiPlxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJwb2ludGVyLWV2ZW50cy1ub25lIGFic29sdXRlIGxlZnQtMyB0b3AtMS8yIC10cmFuc2xhdGUteS0xLzIgdGV4dC1tdXRlZFwiPuCnszwvc3Bhbj5cbiAgICAgICAgPGlucHV0XG4gICAgICAgICAgdHlwZT1cIm51bWJlclwiXG4gICAgICAgICAgaW5wdXRNb2RlPVwibnVtZXJpY1wiXG4gICAgICAgICAgc3RlcD17NTAwfVxuICAgICAgICAgIG1pbj17MH1cbiAgICAgICAgICB2YWx1ZT17dmFsdWV9XG4gICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBvbkNoYW5nZShOdW1iZXIoZS50YXJnZXQudmFsdWUpKX1cbiAgICAgICAgICBjbGFzc05hbWU9XCJoLTExIHctZnVsbCByb3VuZGVkLXhsIGJnLWl2b3J5IHBsLTcgcHItMyB0ZXh0LVswLjkzNzVyZW1dIHRudW0gdGV4dC1pbmsgcmluZy0xIHJpbmctaGFpcmxpbmUtc3Ryb25nIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1hcXVhLTYwMFwiXG4gICAgICAgIC8+XG4gICAgICA8L2Rpdj5cbiAgICA8L2xhYmVsPlxuICApO1xufVxuIl0sImZpbGUiOiJEOi9JMkkgUHJvamVjdCAtIEhhYml0by9BcHAgRm9sZGVyL2hhYml0by9zcmMvcGFnZXMvRmluZC50c3gifQ==