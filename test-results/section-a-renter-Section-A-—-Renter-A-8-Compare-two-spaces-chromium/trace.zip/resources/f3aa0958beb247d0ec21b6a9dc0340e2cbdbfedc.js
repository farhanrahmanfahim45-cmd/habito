import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=9ceb86a3"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("D:/I2I Project - Habito/App Folder/habito/src/App.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { BrowserRouter } from "/node_modules/.vite/deps/react-router-dom.js?v=9ceb86a3";
import { AppShell } from "/src/components/layout/AppShell.tsx";
import { AppRoutes } from "/src/routes/AppRoutes.tsx";
import { AuthProvider } from "/src/hooks/useAuth.tsx";
import { I18nProvider } from "/src/i18n/index.tsx";
import { HabitoProvider } from "/src/hooks/useHabito.tsx";
import { ToastProvider } from "/src/components/ui/Toast.tsx";
import { ScrollToTop } from "/src/components/layout/ScrollToTop.tsx";
import { FirstRun } from "/src/components/onboarding/FirstRun.tsx";
export default function App() {
  return /* @__PURE__ */ jsxDEV(BrowserRouter, { children: /* @__PURE__ */ jsxDEV(I18nProvider, { children: /* @__PURE__ */ jsxDEV(AuthProvider, { children: /* @__PURE__ */ jsxDEV(HabitoProvider, { children: /* @__PURE__ */ jsxDEV(ToastProvider, { children: [
    /* @__PURE__ */ jsxDEV(ScrollToTop, {}, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/App.tsx",
      lineNumber: 37,
      columnNumber: 15
    }, this),
    /* @__PURE__ */ jsxDEV(FirstRun, {}, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/App.tsx",
      lineNumber: 38,
      columnNumber: 15
    }, this),
    /* @__PURE__ */ jsxDEV(AppShell, { children: /* @__PURE__ */ jsxDEV(AppRoutes, {}, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/App.tsx",
      lineNumber: 40,
      columnNumber: 17
    }, this) }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/App.tsx",
      lineNumber: 39,
      columnNumber: 15
    }, this)
  ] }, void 0, true, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/App.tsx",
    lineNumber: 36,
    columnNumber: 13
  }, this) }, void 0, false, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/App.tsx",
    lineNumber: 35,
    columnNumber: 11
  }, this) }, void 0, false, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/App.tsx",
    lineNumber: 34,
    columnNumber: 9
  }, this) }, void 0, false, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/App.tsx",
    lineNumber: 33,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/App.tsx",
    lineNumber: 32,
    columnNumber: 5
  }, this);
}
_c = App;
var _c;
$RefreshReg$(_c, "App");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/I2I Project - Habito/App Folder/habito/src/App.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/I2I Project - Habito/App Folder/habito/src/App.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUJjOzs7Ozs7Ozs7Ozs7Ozs7O0FBakJkLFNBQVNBLHFCQUFxQjtBQUM5QixTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0MsaUJBQWlCO0FBQzFCLFNBQVNDLG9CQUFvQjtBQUM3QixTQUFTQyxvQkFBb0I7QUFDN0IsU0FBU0Msc0JBQXNCO0FBQy9CLFNBQVNDLHFCQUFxQjtBQUM5QixTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0MsZ0JBQWdCO0FBRXpCLHdCQUF3QkMsTUFBTTtBQUM1QixTQUNFLHVCQUFDLGlCQUNDLGlDQUFDLGdCQUNDLGlDQUFDLGdCQUNDLGlDQUFDLGtCQUNDLGlDQUFDLGlCQUNDO0FBQUEsMkJBQUMsaUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFZO0FBQUEsSUFDWix1QkFBQyxjQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBUztBQUFBLElBQ1QsdUJBQUMsWUFDQyxpQ0FBQyxlQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBVSxLQURaO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLE9BTEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQU1BLEtBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVFBLEtBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVVBLEtBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVlBLEtBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWNBO0FBRUo7QUFBQ0MsS0FsQnVCRDtBQUFHLElBQUFDO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbIkJyb3dzZXJSb3V0ZXIiLCJBcHBTaGVsbCIsIkFwcFJvdXRlcyIsIkF1dGhQcm92aWRlciIsIkkxOG5Qcm92aWRlciIsIkhhYml0b1Byb3ZpZGVyIiwiVG9hc3RQcm92aWRlciIsIlNjcm9sbFRvVG9wIiwiRmlyc3RSdW4iLCJBcHAiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJBcHAudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEJyb3dzZXJSb3V0ZXIgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xuaW1wb3J0IHsgQXBwU2hlbGwgfSBmcm9tIFwiQC9jb21wb25lbnRzL2xheW91dC9BcHBTaGVsbFwiO1xuaW1wb3J0IHsgQXBwUm91dGVzIH0gZnJvbSBcIkAvcm91dGVzL0FwcFJvdXRlc1wiO1xuaW1wb3J0IHsgQXV0aFByb3ZpZGVyIH0gZnJvbSBcIkAvaG9va3MvdXNlQXV0aFwiO1xuaW1wb3J0IHsgSTE4blByb3ZpZGVyIH0gZnJvbSBcIkAvaTE4blwiO1xuaW1wb3J0IHsgSGFiaXRvUHJvdmlkZXIgfSBmcm9tIFwiQC9ob29rcy91c2VIYWJpdG9cIjtcbmltcG9ydCB7IFRvYXN0UHJvdmlkZXIgfSBmcm9tIFwiQC9jb21wb25lbnRzL3VpL1RvYXN0XCI7XG5pbXBvcnQgeyBTY3JvbGxUb1RvcCB9IGZyb20gXCJAL2NvbXBvbmVudHMvbGF5b3V0L1Njcm9sbFRvVG9wXCI7XG5pbXBvcnQgeyBGaXJzdFJ1biB9IGZyb20gXCJAL2NvbXBvbmVudHMvb25ib2FyZGluZy9GaXJzdFJ1blwiO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBBcHAoKSB7XG4gIHJldHVybiAoXG4gICAgPEJyb3dzZXJSb3V0ZXI+XG4gICAgICA8STE4blByb3ZpZGVyPlxuICAgICAgICA8QXV0aFByb3ZpZGVyPlxuICAgICAgICAgIDxIYWJpdG9Qcm92aWRlcj5cbiAgICAgICAgICAgIDxUb2FzdFByb3ZpZGVyPlxuICAgICAgICAgICAgICA8U2Nyb2xsVG9Ub3AgLz5cbiAgICAgICAgICAgICAgPEZpcnN0UnVuIC8+XG4gICAgICAgICAgICAgIDxBcHBTaGVsbD5cbiAgICAgICAgICAgICAgICA8QXBwUm91dGVzIC8+XG4gICAgICAgICAgICAgIDwvQXBwU2hlbGw+XG4gICAgICAgICAgICA8L1RvYXN0UHJvdmlkZXI+XG4gICAgICAgICAgPC9IYWJpdG9Qcm92aWRlcj5cbiAgICAgICAgPC9BdXRoUHJvdmlkZXI+XG4gICAgICA8L0kxOG5Qcm92aWRlcj5cbiAgICA8L0Jyb3dzZXJSb3V0ZXI+XG4gICk7XG59XG4iXSwiZmlsZSI6IkQ6L0kySSBQcm9qZWN0IC0gSGFiaXRvL0FwcCBGb2xkZXIvaGFiaXRvL3NyYy9BcHAudHN4In0=