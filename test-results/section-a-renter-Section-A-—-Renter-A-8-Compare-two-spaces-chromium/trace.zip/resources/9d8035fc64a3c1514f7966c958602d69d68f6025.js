import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/@fs/D:\\I2I Project - Habito\\App Folder\\habito\\src\\components\\space\\CompareTray.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=9ceb86a3"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("D:/I2I Project - Habito/App Folder/habito/src/components/space/CompareTray.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { Link, useLocation } from "/node_modules/.vite/deps/react-router-dom.js?v=9ceb86a3";
import { X, ArrowRight } from "/node_modules/.vite/deps/lucide-react.js?v=9ceb86a3";
import { useHabito } from "/src/hooks/useHabito.tsx";
import { Button } from "/src/components/ui/Button.tsx";
import { moneyCompact } from "/src/lib/format.ts";
import { displayImage } from "/src/lib/localize.ts";
export function CompareTray() {
  _s();
  const { compareIds, listings, toggleCompare, clearCompare } = useHabito();
  const { pathname } = useLocation();
  if (pathname.startsWith("/compare") || compareIds.length === 0) return null;
  const selected = listings.filter((l) => compareIds.includes(l.space.id));
  return /* @__PURE__ */ jsxDEV("div", { className: "pointer-events-none fixed inset-x-0 bottom-14 z-40 px-4 pb-3 md:bottom-0 md:pb-5", children: /* @__PURE__ */ jsxDEV("div", { className: "pointer-events-auto mx-auto flex max-w-3xl items-center gap-3 rounded-2xl bg-ink/95 p-2.5 pl-4 text-ivory shadow-[0_20px_50px_-20px_rgb(16_24_40/0.7)] backdrop-blur rise", children: [
    /* @__PURE__ */ jsxDEV("p", { className: "hidden text-sm font-semibold sm:block", children: [
      "Compare ",
      selected.length
    ] }, void 0, true, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/CompareTray.tsx",
      lineNumber: 39,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("ul", { className: "flex flex-1 gap-2 overflow-x-auto hide-scrollbar", children: selected.map(
      (l) => /* @__PURE__ */ jsxDEV("li", { className: "flex shrink-0 items-center gap-2 rounded-xl bg-white/10 py-1 pl-1 pr-2", children: [
        /* @__PURE__ */ jsxDEV("img", { src: displayImage(l.space.images[0]), alt: "", className: "size-8 rounded-lg object-cover" }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/CompareTray.tsx",
          lineNumber: 46,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "max-w-28 truncate text-xs font-medium", children: l.space.name }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/CompareTray.tsx",
          lineNumber: 47,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "text-xs text-ivory/60 tnum", children: moneyCompact(l.space.cost.price) }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/CompareTray.tsx",
          lineNumber: 48,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: () => toggleCompare(l.space.id),
            "aria-label": `Remove ${l.space.name} from compare`,
            className: "rounded-full p-0.5 text-ivory/60 hover:bg-white/15 hover:text-ivory",
            children: /* @__PURE__ */ jsxDEV(X, { size: 13, "aria-hidden": true }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/CompareTray.tsx",
              lineNumber: 55,
              columnNumber: 17
            }, this)
          },
          void 0,
          false,
          {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/CompareTray.tsx",
            lineNumber: 49,
            columnNumber: 15
          },
          this
        )
      ] }, l.space.id, true, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/CompareTray.tsx",
        lineNumber: 45,
        columnNumber: 11
      }, this)
    ) }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/CompareTray.tsx",
      lineNumber: 43,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(
      "button",
      {
        type: "button",
        onClick: clearCompare,
        className: "hidden shrink-0 px-2 text-xs font-medium text-ivory/60 hover:text-ivory sm:block",
        children: "Clear"
      },
      void 0,
      false,
      {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/CompareTray.tsx",
        lineNumber: 61,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(Link, { to: "/compare", className: "shrink-0", children: /* @__PURE__ */ jsxDEV(Button, { size: "sm", className: "bg-aqua-400 text-ink hover:bg-aqua-200", children: [
      "Compare",
      /* @__PURE__ */ jsxDEV(ArrowRight, { size: 15, "aria-hidden": true }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/CompareTray.tsx",
        lineNumber: 72,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/CompareTray.tsx",
      lineNumber: 70,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/CompareTray.tsx",
      lineNumber: 69,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/CompareTray.tsx",
    lineNumber: 38,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/CompareTray.tsx",
    lineNumber: 37,
    columnNumber: 5
  }, this);
}
_s(CompareTray, "KXVAebjleQ/MNfr5BpnAwxBYG28=", false, function() {
  return [useHabito, useLocation];
});
_c = CompareTray;
var _c;
$RefreshReg$(_c, "CompareTray");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/I2I Project - Habito/App Folder/habito/src/components/space/CompareTray.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/I2I Project - Habito/App Folder/habito/src/components/space/CompareTray.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbUJROzs7Ozs7Ozs7Ozs7Ozs7OztBQW5CUixTQUFTQSxNQUFNQyxtQkFBbUI7QUFDbEMsU0FBU0MsR0FBR0Msa0JBQWtCO0FBQzlCLFNBQVNDLGlCQUFpQjtBQUMxQixTQUFTQyxjQUFjO0FBQ3ZCLFNBQVNDLG9CQUFvQjtBQUM3QixTQUFTQyxvQkFBb0I7QUFHdEIsZ0JBQVNDLGNBQWM7QUFBQUMsS0FBQTtBQUM1QixRQUFNLEVBQUVDLFlBQVlDLFVBQVVDLGVBQWVDLGFBQWEsSUFBSVQsVUFBVTtBQUN4RSxRQUFNLEVBQUVVLFNBQVMsSUFBSWIsWUFBWTtBQUVqQyxNQUFJYSxTQUFTQyxXQUFXLFVBQVUsS0FBS0wsV0FBV00sV0FBVyxFQUFHLFFBQU87QUFFdkUsUUFBTUMsV0FBV04sU0FBU08sT0FBTyxDQUFDQyxNQUFNVCxXQUFXVSxTQUFTRCxFQUFFRSxNQUFNQyxFQUFFLENBQUM7QUFFdkUsU0FDRSx1QkFBQyxTQUFJLFdBQVUsb0ZBQ2IsaUNBQUMsU0FBSSxXQUFVLDZLQUNiO0FBQUEsMkJBQUMsT0FBRSxXQUFVLHlDQUF1QztBQUFBO0FBQUEsTUFDekNMLFNBQVNEO0FBQUFBLFNBRHBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLElBRUEsdUJBQUMsUUFBRyxXQUFVLG9EQUNYQyxtQkFBU007QUFBQUEsTUFBSSxDQUFDSixNQUNiLHVCQUFDLFFBQW9CLFdBQVUsMEVBQzdCO0FBQUEsK0JBQUMsU0FBSSxLQUFLWixhQUFhWSxFQUFFRSxNQUFNRyxPQUFPLENBQUMsQ0FBQyxHQUFHLEtBQUksSUFBRyxXQUFVLG9DQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTRGO0FBQUEsUUFDNUYsdUJBQUMsVUFBSyxXQUFVLHlDQUF5Q0wsWUFBRUUsTUFBTUksUUFBakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzRTtBQUFBLFFBQ3RFLHVCQUFDLFVBQUssV0FBVSw4QkFBOEJuQix1QkFBYWEsRUFBRUUsTUFBTUssS0FBS0MsS0FBSyxLQUE3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQStFO0FBQUEsUUFDL0U7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE1BQUs7QUFBQSxZQUNMLFNBQVMsTUFBTWYsY0FBY08sRUFBRUUsTUFBTUMsRUFBRTtBQUFBLFlBQ3ZDLGNBQVksVUFBVUgsRUFBRUUsTUFBTUksSUFBSTtBQUFBLFlBQ2xDLFdBQVU7QUFBQSxZQUVWLGlDQUFDLEtBQUUsTUFBTSxJQUFJLGVBQVcsUUFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBd0I7QUFBQTtBQUFBLFVBTjFCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU9BO0FBQUEsV0FYT04sRUFBRUUsTUFBTUMsSUFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVlBO0FBQUEsSUFDRCxLQWZIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FnQkE7QUFBQSxJQUVBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxNQUFLO0FBQUEsUUFDTCxTQUFTVDtBQUFBQSxRQUNULFdBQVU7QUFBQSxRQUFrRjtBQUFBO0FBQUEsTUFIOUY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBTUE7QUFBQSxJQUVBLHVCQUFDLFFBQUssSUFBRyxZQUFXLFdBQVUsWUFDNUIsaUNBQUMsVUFBTyxNQUFLLE1BQUssV0FBVSwwQ0FBd0M7QUFBQTtBQUFBLE1BRWxFLHVCQUFDLGNBQVcsTUFBTSxJQUFJLGVBQVcsUUFBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpQztBQUFBLFNBRm5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQSxLQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FLQTtBQUFBLE9BcENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FxQ0EsS0F0Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXVDQTtBQUVKO0FBQUNKLEdBbERlRCxhQUFXO0FBQUEsVUFDcUNKLFdBQ3pDSCxXQUFXO0FBQUE7QUFBQSxLQUZsQk87QUFBVyxJQUFBb0I7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsiTGluayIsInVzZUxvY2F0aW9uIiwiWCIsIkFycm93UmlnaHQiLCJ1c2VIYWJpdG8iLCJCdXR0b24iLCJtb25leUNvbXBhY3QiLCJkaXNwbGF5SW1hZ2UiLCJDb21wYXJlVHJheSIsIl9zIiwiY29tcGFyZUlkcyIsImxpc3RpbmdzIiwidG9nZ2xlQ29tcGFyZSIsImNsZWFyQ29tcGFyZSIsInBhdGhuYW1lIiwic3RhcnRzV2l0aCIsImxlbmd0aCIsInNlbGVjdGVkIiwiZmlsdGVyIiwibCIsImluY2x1ZGVzIiwic3BhY2UiLCJpZCIsIm1hcCIsImltYWdlcyIsIm5hbWUiLCJjb3N0IiwicHJpY2UiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJDb21wYXJlVHJheS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTGluaywgdXNlTG9jYXRpb24gfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xuaW1wb3J0IHsgWCwgQXJyb3dSaWdodCB9IGZyb20gXCJsdWNpZGUtcmVhY3RcIjtcbmltcG9ydCB7IHVzZUhhYml0byB9IGZyb20gXCJAL2hvb2tzL3VzZUhhYml0b1wiO1xuaW1wb3J0IHsgQnV0dG9uIH0gZnJvbSBcIkAvY29tcG9uZW50cy91aS9CdXR0b25cIjtcbmltcG9ydCB7IG1vbmV5Q29tcGFjdCB9IGZyb20gXCJAL2xpYi9mb3JtYXRcIjtcbmltcG9ydCB7IGRpc3BsYXlJbWFnZSB9IGZyb20gXCJAL2xpYi9sb2NhbGl6ZVwiO1xuXG4vKiogU2xpZGVzIHVwIG9uY2UgdHdvIG9yIG1vcmUgc3BhY2VzIGFyZSBzZWxlY3RlZC4gSGlkZGVuIG9uIHRoZSBjb21wYXJlIHBhZ2UgaXRzZWxmLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIENvbXBhcmVUcmF5KCkge1xuICBjb25zdCB7IGNvbXBhcmVJZHMsIGxpc3RpbmdzLCB0b2dnbGVDb21wYXJlLCBjbGVhckNvbXBhcmUgfSA9IHVzZUhhYml0bygpO1xuICBjb25zdCB7IHBhdGhuYW1lIH0gPSB1c2VMb2NhdGlvbigpO1xuXG4gIGlmIChwYXRobmFtZS5zdGFydHNXaXRoKFwiL2NvbXBhcmVcIikgfHwgY29tcGFyZUlkcy5sZW5ndGggPT09IDApIHJldHVybiBudWxsO1xuXG4gIGNvbnN0IHNlbGVjdGVkID0gbGlzdGluZ3MuZmlsdGVyKChsKSA9PiBjb21wYXJlSWRzLmluY2x1ZGVzKGwuc3BhY2UuaWQpKTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwicG9pbnRlci1ldmVudHMtbm9uZSBmaXhlZCBpbnNldC14LTAgYm90dG9tLTE0IHotNDAgcHgtNCBwYi0zIG1kOmJvdHRvbS0wIG1kOnBiLTVcIj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicG9pbnRlci1ldmVudHMtYXV0byBteC1hdXRvIGZsZXggbWF4LXctM3hsIGl0ZW1zLWNlbnRlciBnYXAtMyByb3VuZGVkLTJ4bCBiZy1pbmsvOTUgcC0yLjUgcGwtNCB0ZXh0LWl2b3J5IHNoYWRvdy1bMF8yMHB4XzUwcHhfLTIwcHhfcmdiKDE2XzI0XzQwLzAuNyldIGJhY2tkcm9wLWJsdXIgcmlzZVwiPlxuICAgICAgICA8cCBjbGFzc05hbWU9XCJoaWRkZW4gdGV4dC1zbSBmb250LXNlbWlib2xkIHNtOmJsb2NrXCI+XG4gICAgICAgICAgQ29tcGFyZSB7c2VsZWN0ZWQubGVuZ3RofVxuICAgICAgICA8L3A+XG5cbiAgICAgICAgPHVsIGNsYXNzTmFtZT1cImZsZXggZmxleC0xIGdhcC0yIG92ZXJmbG93LXgtYXV0byBoaWRlLXNjcm9sbGJhclwiPlxuICAgICAgICAgIHtzZWxlY3RlZC5tYXAoKGwpID0+IChcbiAgICAgICAgICAgIDxsaSBrZXk9e2wuc3BhY2UuaWR9IGNsYXNzTmFtZT1cImZsZXggc2hyaW5rLTAgaXRlbXMtY2VudGVyIGdhcC0yIHJvdW5kZWQteGwgYmctd2hpdGUvMTAgcHktMSBwbC0xIHByLTJcIj5cbiAgICAgICAgICAgICAgPGltZyBzcmM9e2Rpc3BsYXlJbWFnZShsLnNwYWNlLmltYWdlc1swXSl9IGFsdD1cIlwiIGNsYXNzTmFtZT1cInNpemUtOCByb3VuZGVkLWxnIG9iamVjdC1jb3ZlclwiIC8+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1heC13LTI4IHRydW5jYXRlIHRleHQteHMgZm9udC1tZWRpdW1cIj57bC5zcGFjZS5uYW1lfTwvc3Bhbj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWl2b3J5LzYwIHRudW1cIj57bW9uZXlDb21wYWN0KGwuc3BhY2UuY29zdC5wcmljZSl9PC9zcGFuPlxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gdG9nZ2xlQ29tcGFyZShsLnNwYWNlLmlkKX1cbiAgICAgICAgICAgICAgICBhcmlhLWxhYmVsPXtgUmVtb3ZlICR7bC5zcGFjZS5uYW1lfSBmcm9tIGNvbXBhcmVgfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQtZnVsbCBwLTAuNSB0ZXh0LWl2b3J5LzYwIGhvdmVyOmJnLXdoaXRlLzE1IGhvdmVyOnRleHQtaXZvcnlcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPFggc2l6ZT17MTN9IGFyaWEtaGlkZGVuIC8+XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICApKX1cbiAgICAgICAgPC91bD5cblxuICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgb25DbGljaz17Y2xlYXJDb21wYXJlfVxuICAgICAgICAgIGNsYXNzTmFtZT1cImhpZGRlbiBzaHJpbmstMCBweC0yIHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1pdm9yeS82MCBob3Zlcjp0ZXh0LWl2b3J5IHNtOmJsb2NrXCJcbiAgICAgICAgPlxuICAgICAgICAgIENsZWFyXG4gICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgIDxMaW5rIHRvPVwiL2NvbXBhcmVcIiBjbGFzc05hbWU9XCJzaHJpbmstMFwiPlxuICAgICAgICAgIDxCdXR0b24gc2l6ZT1cInNtXCIgY2xhc3NOYW1lPVwiYmctYXF1YS00MDAgdGV4dC1pbmsgaG92ZXI6YmctYXF1YS0yMDBcIj5cbiAgICAgICAgICAgIENvbXBhcmVcbiAgICAgICAgICAgIDxBcnJvd1JpZ2h0IHNpemU9ezE1fSBhcmlhLWhpZGRlbiAvPlxuICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICA8L0xpbms+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiRDovSTJJIFByb2plY3QgLSBIYWJpdG8vQXBwIEZvbGRlci9oYWJpdG8vc3JjL2NvbXBvbmVudHMvc3BhY2UvQ29tcGFyZVRyYXkudHN4In0=