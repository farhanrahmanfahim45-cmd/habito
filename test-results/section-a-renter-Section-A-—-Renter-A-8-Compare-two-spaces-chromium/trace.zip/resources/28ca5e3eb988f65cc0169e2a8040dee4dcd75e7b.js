import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/hooks/useHabito.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=9ceb86a3"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("D:/I2I Project - Habito/App Folder/habito/src/hooks/useHabito.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9ceb86a3"; const createContext = __vite__cjsImport3_react["createContext"]; const useCallback = __vite__cjsImport3_react["useCallback"]; const useContext = __vite__cjsImport3_react["useContext"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useMemo = __vite__cjsImport3_react["useMemo"]; const useState = __vite__cjsImport3_react["useState"];
import { db, DEMO_OWNER_ID, usingDatabase } from "/src/lib/api/index.ts";
import { useAuth } from "/src/hooks/useAuth.tsx";
import { DEFAULT_REQUIREMENTS } from "/src/lib/matching.ts";
const MAX_COMPARE = 4;
const Ctx = createContext(null);
export function HabitoProvider({ children }) {
  _s();
  const { account, ready: authReady } = useAuth();
  const [ready, setReady] = useState(false);
  const [listings, setListings] = useState([]);
  const [savedIds, setSavedIds] = useState([]);
  const [inquiries, setInquiries] = useState([]);
  const [requests, setRequests] = useState([]);
  const [mode, setMode] = useState("seeker");
  const canOwn = usingDatabase ? account?.canOwn ?? false : true;
  const role = mode === "owner" && canOwn ? "owner" : "seeker";
  const setRole = setMode;
  const ownerId = account?.id ?? DEMO_OWNER_ID;
  const [requirements, setRequirementsState] = useState(DEFAULT_REQUIREMENTS);
  const [hasStatedNeeds, setHasStated] = useState(false);
  const [compareIds, setCompareIds] = useState([]);
  const [unreadMessages, setUnreadMessages] = useState(0);
  const refresh = useCallback(async () => {
    const [l, s, i, r] = await Promise.all([db.listings(), db.saved(), db.inquiries(), db.requests()]);
    setListings(l);
    setSavedIds(s);
    setInquiries(i);
    setRequests(r);
    setReady(true);
  }, []);
  useEffect(() => {
    if (usingDatabase && !authReady) return;
    void refresh();
  }, [refresh, authReady, account?.id]);
  useEffect(() => {
    if (!canOwn && mode === "owner") setMode("seeker");
  }, [canOwn, mode]);
  useEffect(() => {
    if (usingDatabase && !account) {
      setUnreadMessages(0);
      return;
    }
    let inFlight = false;
    const count = async () => {
      if (inFlight) return;
      inFlight = true;
      try {
        const threads = await db.conversations();
        setUnreadMessages(threads.reduce((sum, c) => sum + c.unread, 0));
      } catch {
        setUnreadMessages(0);
      } finally {
        inFlight = false;
      }
    };
    void count();
    try {
      return db.subscribeToMessages(() => void count());
    } catch {
      return void 0;
    }
  }, [account]);
  const setRequirements = useCallback((r) => {
    setRequirementsState(r);
    setHasStated(true);
  }, []);
  const toggleSaved = useCallback(async (id) => {
    const nowSaved = await db.toggleSaved(id);
    setSavedIds(await db.saved());
    return nowSaved;
  }, []);
  const toggleCompare = useCallback((id) => {
    let added = false;
    setCompareIds((prev) => {
      if (prev.includes(id)) return prev.filter((x) => x !== id);
      if (prev.length >= MAX_COMPARE) return prev;
      added = true;
      return [...prev, id];
    });
    return added;
  }, []);
  const sendInquiry = useCallback(
    async (input) => {
      await db.createInquiry(input);
      await refresh();
    },
    [refresh]
  );
  const addRequest = useCallback(
    async (input) => {
      await db.createRequest(input);
      setRequests(await db.requests());
    },
    []
  );
  const value = useMemo(
    () => ({
      ready,
      listings,
      refresh,
      role,
      setRole,
      ownerId,
      requirements,
      setRequirements,
      hasStatedNeeds,
      savedIds,
      isSaved: (id) => savedIds.includes(id),
      toggleSaved,
      compareIds,
      isComparing: (id) => compareIds.includes(id),
      toggleCompare,
      clearCompare: () => setCompareIds([]),
      inquiries,
      sendInquiry,
      requests,
      addRequest,
      unreadMessages,
      canOwn
    }),
    [ready, listings, refresh, role, setRole, ownerId, requirements, setRequirements, hasStatedNeeds, savedIds, toggleSaved, compareIds, toggleCompare, inquiries, sendInquiry, requests, addRequest, unreadMessages, canOwn]
  );
  return /* @__PURE__ */ jsxDEV(Ctx.Provider, { value, children }, void 0, false, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/hooks/useHabito.tsx",
    lineNumber: 211,
    columnNumber: 10
  }, this);
}
_s(HabitoProvider, "gcWJpKqCnx1sPMfJLXZEhnJM684=", false, function() {
  return [useAuth];
});
_c = HabitoProvider;
export function useHabito() {
  _s2();
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useHabito must be used inside HabitoProvider");
  return ctx;
}
_s2(useHabito, "/dMy7t63NXD4eYACoT93CePwGrg=");
export { MAX_COMPARE };
var _c;
$RefreshReg$(_c, "HabitoProvider");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/I2I Project - Habito/App Folder/habito/src/hooks/useHabito.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/I2I Project - Habito/App Folder/habito/src/hooks/useHabito.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBK0xTOzs7Ozs7Ozs7Ozs7Ozs7OztBQS9MVCxTQUFTQSxlQUFlQyxhQUFhQyxZQUFZQyxXQUFXQyxTQUFTQyxnQkFBZ0I7QUFFckYsU0FBU0MsSUFBSUMsZUFBZUMscUJBQXFCO0FBQ2pELFNBQVNDLGVBQWU7QUFDeEIsU0FBU0MsNEJBQTRCO0FBU3JDLE1BQU1DLGNBQWM7QUFxQ3BCLE1BQU1DLE1BQU1aLGNBQWtDLElBQUk7QUFFM0MsZ0JBQVNhLGVBQWUsRUFBRUMsU0FBa0MsR0FBRztBQUFBQyxLQUFBO0FBQ3BFLFFBQU0sRUFBRUMsU0FBU0MsT0FBT0MsVUFBVSxJQUFJVCxRQUFRO0FBQzlDLFFBQU0sQ0FBQ1EsT0FBT0UsUUFBUSxJQUFJZCxTQUFTLEtBQUs7QUFDeEMsUUFBTSxDQUFDZSxVQUFVQyxXQUFXLElBQUloQixTQUF5QixFQUFFO0FBQzNELFFBQU0sQ0FBQ2lCLFVBQVVDLFdBQVcsSUFBSWxCLFNBQW1CLEVBQUU7QUFDckQsUUFBTSxDQUFDbUIsV0FBV0MsWUFBWSxJQUFJcEIsU0FBb0IsRUFBRTtBQUN4RCxRQUFNLENBQUNxQixVQUFVQyxXQUFXLElBQUl0QixTQUF5QixFQUFFO0FBSTNELFFBQU0sQ0FBQ3VCLE1BQU1DLE9BQU8sSUFBSXhCLFNBQW1CLFFBQVE7QUFDbkQsUUFBTXlCLFNBQVN0QixnQkFBaUJRLFNBQVNjLFVBQVUsUUFBUztBQUM1RCxRQUFNQyxPQUFpQkgsU0FBUyxXQUFXRSxTQUFTLFVBQVU7QUFDOUQsUUFBTUUsVUFBVUg7QUFDaEIsUUFBTUksVUFBVWpCLFNBQVNrQixNQUFNM0I7QUFDL0IsUUFBTSxDQUFDNEIsY0FBY0Msb0JBQW9CLElBQUkvQixTQUE2Qkssb0JBQW9CO0FBQzlGLFFBQU0sQ0FBQzJCLGdCQUFnQkMsWUFBWSxJQUFJakMsU0FBUyxLQUFLO0FBQ3JELFFBQU0sQ0FBQ2tDLFlBQVlDLGFBQWEsSUFBSW5DLFNBQW1CLEVBQUU7QUFDekQsUUFBTSxDQUFDb0MsZ0JBQWdCQyxpQkFBaUIsSUFBSXJDLFNBQVMsQ0FBQztBQUV0RCxRQUFNc0MsVUFBVTFDLFlBQVksWUFBWTtBQUN0QyxVQUFNLENBQUMyQyxHQUFHQyxHQUFHQyxHQUFHQyxDQUFDLElBQUksTUFBTUMsUUFBUUMsSUFBSSxDQUFDM0MsR0FBR2MsU0FBUyxHQUFHZCxHQUFHNEMsTUFBTSxHQUFHNUMsR0FBR2tCLFVBQVUsR0FBR2xCLEdBQUdvQixTQUFTLENBQUMsQ0FBQztBQUNqR0wsZ0JBQVl1QixDQUFDO0FBQ2JyQixnQkFBWXNCLENBQUM7QUFDYnBCLGlCQUFhcUIsQ0FBQztBQUNkbkIsZ0JBQVlvQixDQUFDO0FBQ2I1QixhQUFTLElBQUk7QUFBQSxFQUNmLEdBQUcsRUFBRTtBQUVMaEIsWUFBVSxNQUFNO0FBR2QsUUFBSUssaUJBQWlCLENBQUNVLFVBQVc7QUFDakMsU0FBS3lCLFFBQVE7QUFBQSxFQUNmLEdBQUcsQ0FBQ0EsU0FBU3pCLFdBQVdGLFNBQVNrQixFQUFFLENBQUM7QUFHcEMvQixZQUFVLE1BQU07QUFDZCxRQUFJLENBQUMyQixVQUFVRixTQUFTLFFBQVNDLFNBQVEsUUFBUTtBQUFBLEVBQ25ELEdBQUcsQ0FBQ0MsUUFBUUYsSUFBSSxDQUFDO0FBR2pCekIsWUFBVSxNQUFNO0FBQ2QsUUFBSUssaUJBQWlCLENBQUNRLFNBQVM7QUFDN0IwQix3QkFBa0IsQ0FBQztBQUNuQjtBQUFBLElBQ0Y7QUFJQSxRQUFJUyxXQUFXO0FBRWYsVUFBTUMsUUFBUSxZQUFZO0FBQ3hCLFVBQUlELFNBQVU7QUFDZEEsaUJBQVc7QUFDWCxVQUFJO0FBQ0YsY0FBTUUsVUFBVSxNQUFNL0MsR0FBR2dELGNBQWM7QUFDdkNaLDBCQUFrQlcsUUFBUUUsT0FBTyxDQUFDQyxLQUFLQyxNQUFNRCxNQUFNQyxFQUFFQyxRQUFRLENBQUMsQ0FBQztBQUFBLE1BQ2pFLFFBQVE7QUFDTmhCLDBCQUFrQixDQUFDO0FBQUEsTUFDckIsVUFBQztBQUNDUyxtQkFBVztBQUFBLE1BQ2I7QUFBQSxJQUNGO0FBRUEsU0FBS0MsTUFBTTtBQUNYLFFBQUk7QUFDRixhQUFPOUMsR0FBR3FELG9CQUFvQixNQUFNLEtBQUtQLE1BQU0sQ0FBQztBQUFBLElBQ2xELFFBQVE7QUFDTixhQUFPUTtBQUFBQSxJQUNUO0FBQUEsRUFDRixHQUFHLENBQUM1QyxPQUFPLENBQUM7QUFFWixRQUFNNkMsa0JBQWtCNUQsWUFBWSxDQUFDOEMsTUFBMEI7QUFDN0RYLHlCQUFxQlcsQ0FBQztBQUN0QlQsaUJBQWEsSUFBSTtBQUFBLEVBQ25CLEdBQUcsRUFBRTtBQUVMLFFBQU13QixjQUFjN0QsWUFBWSxPQUFPaUMsT0FBZTtBQUNwRCxVQUFNNkIsV0FBVyxNQUFNekQsR0FBR3dELFlBQVk1QixFQUFFO0FBQ3hDWCxnQkFBWSxNQUFNakIsR0FBRzRDLE1BQU0sQ0FBQztBQUM1QixXQUFPYTtBQUFBQSxFQUNULEdBQUcsRUFBRTtBQUVMLFFBQU1DLGdCQUFnQi9ELFlBQVksQ0FBQ2lDLE9BQWU7QUFDaEQsUUFBSStCLFFBQVE7QUFDWnpCLGtCQUFjLENBQUMwQixTQUFTO0FBQ3RCLFVBQUlBLEtBQUtDLFNBQVNqQyxFQUFFLEVBQUcsUUFBT2dDLEtBQUtFLE9BQU8sQ0FBQ0MsTUFBTUEsTUFBTW5DLEVBQUU7QUFDekQsVUFBSWdDLEtBQUtJLFVBQVUzRCxZQUFhLFFBQU91RDtBQUN2Q0QsY0FBUTtBQUNSLGFBQU8sQ0FBQyxHQUFHQyxNQUFNaEMsRUFBRTtBQUFBLElBQ3JCLENBQUM7QUFDRCxXQUFPK0I7QUFBQUEsRUFDVCxHQUFHLEVBQUU7QUFFTCxRQUFNTSxjQUFjdEU7QUFBQUEsSUFDbEIsT0FBT3VFLFVBQXFEO0FBQzFELFlBQU1sRSxHQUFHbUUsY0FBY0QsS0FBSztBQUM1QixZQUFNN0IsUUFBUTtBQUFBLElBQ2hCO0FBQUEsSUFDQSxDQUFDQSxPQUFPO0FBQUEsRUFDVjtBQUVBLFFBQU0rQixhQUFhekU7QUFBQUEsSUFDakIsT0FBT3VFLFVBQWtEO0FBQ3ZELFlBQU1sRSxHQUFHcUUsY0FBY0gsS0FBSztBQUM1QjdDLGtCQUFZLE1BQU1yQixHQUFHb0IsU0FBUyxDQUFDO0FBQUEsSUFDakM7QUFBQSxJQUNBO0FBQUEsRUFDRjtBQUVBLFFBQU1rRCxRQUFReEU7QUFBQUEsSUFDWixPQUFPO0FBQUEsTUFDTGE7QUFBQUEsTUFDQUc7QUFBQUEsTUFDQXVCO0FBQUFBLE1BQ0FaO0FBQUFBLE1BQ0FDO0FBQUFBLE1BQ0FDO0FBQUFBLE1BQ0FFO0FBQUFBLE1BQ0EwQjtBQUFBQSxNQUNBeEI7QUFBQUEsTUFDQWY7QUFBQUEsTUFDQXVELFNBQVNBLENBQUMzQyxPQUFPWixTQUFTNkMsU0FBU2pDLEVBQUU7QUFBQSxNQUNyQzRCO0FBQUFBLE1BQ0F2QjtBQUFBQSxNQUNBdUMsYUFBYUEsQ0FBQzVDLE9BQU9LLFdBQVc0QixTQUFTakMsRUFBRTtBQUFBLE1BQzNDOEI7QUFBQUEsTUFDQWUsY0FBY0EsTUFBTXZDLGNBQWMsRUFBRTtBQUFBLE1BQ3BDaEI7QUFBQUEsTUFDQStDO0FBQUFBLE1BQ0E3QztBQUFBQSxNQUNBZ0Q7QUFBQUEsTUFDQWpDO0FBQUFBLE1BQ0FYO0FBQUFBLElBQ0Y7QUFBQSxJQUNBLENBQUNiLE9BQU9HLFVBQVV1QixTQUFTWixNQUFNQyxTQUFTQyxTQUFTRSxjQUFjMEIsaUJBQWlCeEIsZ0JBQWdCZixVQUFVd0MsYUFBYXZCLFlBQVl5QixlQUFleEMsV0FBVytDLGFBQWE3QyxVQUFVZ0QsWUFBWWpDLGdCQUFnQlgsTUFBTTtBQUFBLEVBQzFOO0FBRUEsU0FBTyx1QkFBQyxJQUFJLFVBQUosRUFBYSxPQUFlaEIsWUFBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFzQztBQUMvQztBQUFDQyxHQTVJZUYsZ0JBQWM7QUFBQSxVQUNVSixPQUFPO0FBQUE7QUFBQSxLQUQvQkk7QUE4SVQsZ0JBQVNtRSxZQUF5QjtBQUFBQyxNQUFBO0FBQ3ZDLFFBQU1DLE1BQU1oRixXQUFXVSxHQUFHO0FBQzFCLE1BQUksQ0FBQ3NFLElBQUssT0FBTSxJQUFJQyxNQUFNLDhDQUE4QztBQUN4RSxTQUFPRDtBQUNUO0FBQUNELElBSmVELFdBQVM7QUFNekIsU0FBU3JFO0FBQWMsSUFBQXlFO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbImNyZWF0ZUNvbnRleHQiLCJ1c2VDYWxsYmFjayIsInVzZUNvbnRleHQiLCJ1c2VFZmZlY3QiLCJ1c2VNZW1vIiwidXNlU3RhdGUiLCJkYiIsIkRFTU9fT1dORVJfSUQiLCJ1c2luZ0RhdGFiYXNlIiwidXNlQXV0aCIsIkRFRkFVTFRfUkVRVUlSRU1FTlRTIiwiTUFYX0NPTVBBUkUiLCJDdHgiLCJIYWJpdG9Qcm92aWRlciIsImNoaWxkcmVuIiwiX3MiLCJhY2NvdW50IiwicmVhZHkiLCJhdXRoUmVhZHkiLCJzZXRSZWFkeSIsImxpc3RpbmdzIiwic2V0TGlzdGluZ3MiLCJzYXZlZElkcyIsInNldFNhdmVkSWRzIiwiaW5xdWlyaWVzIiwic2V0SW5xdWlyaWVzIiwicmVxdWVzdHMiLCJzZXRSZXF1ZXN0cyIsIm1vZGUiLCJzZXRNb2RlIiwiY2FuT3duIiwicm9sZSIsInNldFJvbGUiLCJvd25lcklkIiwiaWQiLCJyZXF1aXJlbWVudHMiLCJzZXRSZXF1aXJlbWVudHNTdGF0ZSIsImhhc1N0YXRlZE5lZWRzIiwic2V0SGFzU3RhdGVkIiwiY29tcGFyZUlkcyIsInNldENvbXBhcmVJZHMiLCJ1bnJlYWRNZXNzYWdlcyIsInNldFVucmVhZE1lc3NhZ2VzIiwicmVmcmVzaCIsImwiLCJzIiwiaSIsInIiLCJQcm9taXNlIiwiYWxsIiwic2F2ZWQiLCJpbkZsaWdodCIsImNvdW50IiwidGhyZWFkcyIsImNvbnZlcnNhdGlvbnMiLCJyZWR1Y2UiLCJzdW0iLCJjIiwidW5yZWFkIiwic3Vic2NyaWJlVG9NZXNzYWdlcyIsInVuZGVmaW5lZCIsInNldFJlcXVpcmVtZW50cyIsInRvZ2dsZVNhdmVkIiwibm93U2F2ZWQiLCJ0b2dnbGVDb21wYXJlIiwiYWRkZWQiLCJwcmV2IiwiaW5jbHVkZXMiLCJmaWx0ZXIiLCJ4IiwibGVuZ3RoIiwic2VuZElucXVpcnkiLCJpbnB1dCIsImNyZWF0ZUlucXVpcnkiLCJhZGRSZXF1ZXN0IiwiY3JlYXRlUmVxdWVzdCIsInZhbHVlIiwiaXNTYXZlZCIsImlzQ29tcGFyaW5nIiwiY2xlYXJDb21wYXJlIiwidXNlSGFiaXRvIiwiX3MyIiwiY3R4IiwiRXJyb3IiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJ1c2VIYWJpdG8udHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGNyZWF0ZUNvbnRleHQsIHVzZUNhbGxiYWNrLCB1c2VDb250ZXh0LCB1c2VFZmZlY3QsIHVzZU1lbW8sIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgdHlwZSB7IFJlYWN0Tm9kZSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgZGIsIERFTU9fT1dORVJfSUQsIHVzaW5nRGF0YWJhc2UgfSBmcm9tIFwiQC9saWIvYXBpXCI7XG5pbXBvcnQgeyB1c2VBdXRoIH0gZnJvbSBcIi4vdXNlQXV0aFwiO1xuaW1wb3J0IHsgREVGQVVMVF9SRVFVSVJFTUVOVFMgfSBmcm9tIFwiQC9saWIvbWF0Y2hpbmdcIjtcbmltcG9ydCB0eXBlIHtcbiAgRGVtb1JvbGUsXG4gIElucXVpcnksXG4gIFNlYXJjaFJlcXVpcmVtZW50cyxcbiAgU3BhY2VMaXN0aW5nLFxuICBTcGFjZVJlcXVlc3QsXG59IGZyb20gXCJAL3R5cGVzL3NwYWNlXCI7XG5cbmNvbnN0IE1BWF9DT01QQVJFID0gNDtcblxuaW50ZXJmYWNlIEhhYml0b1N0YXRlIHtcbiAgcmVhZHk6IGJvb2xlYW47XG4gIGxpc3RpbmdzOiBTcGFjZUxpc3RpbmdbXTtcbiAgcmVmcmVzaDogKCkgPT4gUHJvbWlzZTx2b2lkPjtcblxuICByb2xlOiBEZW1vUm9sZTtcbiAgc2V0Um9sZTogKHJvbGU6IERlbW9Sb2xlKSA9PiB2b2lkO1xuICBvd25lcklkOiBzdHJpbmc7XG5cbiAgcmVxdWlyZW1lbnRzOiBTZWFyY2hSZXF1aXJlbWVudHM7XG4gIHNldFJlcXVpcmVtZW50czogKHI6IFNlYXJjaFJlcXVpcmVtZW50cykgPT4gdm9pZDtcbiAgaGFzU3RhdGVkTmVlZHM6IGJvb2xlYW47XG5cbiAgc2F2ZWRJZHM6IHN0cmluZ1tdO1xuICBpc1NhdmVkOiAoaWQ6IHN0cmluZykgPT4gYm9vbGVhbjtcbiAgdG9nZ2xlU2F2ZWQ6IChpZDogc3RyaW5nKSA9PiBQcm9taXNlPGJvb2xlYW4+O1xuXG4gIGNvbXBhcmVJZHM6IHN0cmluZ1tdO1xuICBpc0NvbXBhcmluZzogKGlkOiBzdHJpbmcpID0+IGJvb2xlYW47XG4gIHRvZ2dsZUNvbXBhcmU6IChpZDogc3RyaW5nKSA9PiBib29sZWFuO1xuICBjbGVhckNvbXBhcmU6ICgpID0+IHZvaWQ7XG5cbiAgaW5xdWlyaWVzOiBJbnF1aXJ5W107XG4gIHNlbmRJbnF1aXJ5OiAoaW5wdXQ6IE9taXQ8SW5xdWlyeSwgXCJpZFwiIHwgXCJzZW50QXRcIiB8IFwic3RhdHVzXCI+KSA9PiBQcm9taXNlPHZvaWQ+O1xuXG4gIHJlcXVlc3RzOiBTcGFjZVJlcXVlc3RbXTtcbiAgYWRkUmVxdWVzdDogKGlucHV0OiBPbWl0PFNwYWNlUmVxdWVzdCwgXCJpZFwiIHwgXCJjcmVhdGVkQXRcIj4pID0+IFByb21pc2U8dm9pZD47XG5cbiAgLyoqIFRvdGFsIHVucmVhZCBtZXNzYWdlcyBhY3Jvc3MgZXZlcnkgdGhyZWFkLCBmb3IgdGhlIG5hdmlnYXRpb24gYmFkZ2UuICovXG4gIHVucmVhZE1lc3NhZ2VzOiBudW1iZXI7XG5cbiAgLyoqIFdoZXRoZXIgdGhpcyBhY2NvdW50IG1heSB1c2Ugb3duZXIgdG9vbHMgYXQgYWxsLiAqL1xuICBjYW5Pd246IGJvb2xlYW47XG59XG5cbmNvbnN0IEN0eCA9IGNyZWF0ZUNvbnRleHQ8SGFiaXRvU3RhdGUgfCBudWxsPihudWxsKTtcblxuZXhwb3J0IGZ1bmN0aW9uIEhhYml0b1Byb3ZpZGVyKHsgY2hpbGRyZW4gfTogeyBjaGlsZHJlbjogUmVhY3ROb2RlIH0pIHtcbiAgY29uc3QgeyBhY2NvdW50LCByZWFkeTogYXV0aFJlYWR5IH0gPSB1c2VBdXRoKCk7XG4gIGNvbnN0IFtyZWFkeSwgc2V0UmVhZHldID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbbGlzdGluZ3MsIHNldExpc3RpbmdzXSA9IHVzZVN0YXRlPFNwYWNlTGlzdGluZ1tdPihbXSk7XG4gIGNvbnN0IFtzYXZlZElkcywgc2V0U2F2ZWRJZHNdID0gdXNlU3RhdGU8c3RyaW5nW10+KFtdKTtcbiAgY29uc3QgW2lucXVpcmllcywgc2V0SW5xdWlyaWVzXSA9IHVzZVN0YXRlPElucXVpcnlbXT4oW10pO1xuICBjb25zdCBbcmVxdWVzdHMsIHNldFJlcXVlc3RzXSA9IHVzZVN0YXRlPFNwYWNlUmVxdWVzdFtdPihbXSk7XG5cbiAgLy8gT25lIGFjY291bnQgY2FuIGJlIGJvdGggc2lkZXMuIFRoZSBtb2RlIGlzIHdoaWNoIGhhdCB5b3UgYXJlIHdlYXJpbmcgbm93O1xuICAvLyB3aGF0IHlvdSBhcmUgcGVybWl0dGVkIHRvIGRvIGlzIHN0aWxsIGRlY2lkZWQgYnkgdGhlIGRhdGFiYXNlLlxuICBjb25zdCBbbW9kZSwgc2V0TW9kZV0gPSB1c2VTdGF0ZTxEZW1vUm9sZT4oXCJzZWVrZXJcIik7XG4gIGNvbnN0IGNhbk93biA9IHVzaW5nRGF0YWJhc2UgPyAoYWNjb3VudD8uY2FuT3duID8/IGZhbHNlKSA6IHRydWU7XG4gIGNvbnN0IHJvbGU6IERlbW9Sb2xlID0gbW9kZSA9PT0gXCJvd25lclwiICYmIGNhbk93biA/IFwib3duZXJcIiA6IFwic2Vla2VyXCI7XG4gIGNvbnN0IHNldFJvbGUgPSBzZXRNb2RlO1xuICBjb25zdCBvd25lcklkID0gYWNjb3VudD8uaWQgPz8gREVNT19PV05FUl9JRDtcbiAgY29uc3QgW3JlcXVpcmVtZW50cywgc2V0UmVxdWlyZW1lbnRzU3RhdGVdID0gdXNlU3RhdGU8U2VhcmNoUmVxdWlyZW1lbnRzPihERUZBVUxUX1JFUVVJUkVNRU5UUyk7XG4gIGNvbnN0IFtoYXNTdGF0ZWROZWVkcywgc2V0SGFzU3RhdGVkXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW2NvbXBhcmVJZHMsIHNldENvbXBhcmVJZHNdID0gdXNlU3RhdGU8c3RyaW5nW10+KFtdKTtcbiAgY29uc3QgW3VucmVhZE1lc3NhZ2VzLCBzZXRVbnJlYWRNZXNzYWdlc10gPSB1c2VTdGF0ZSgwKTtcblxuICBjb25zdCByZWZyZXNoID0gdXNlQ2FsbGJhY2soYXN5bmMgKCkgPT4ge1xuICAgIGNvbnN0IFtsLCBzLCBpLCByXSA9IGF3YWl0IFByb21pc2UuYWxsKFtkYi5saXN0aW5ncygpLCBkYi5zYXZlZCgpLCBkYi5pbnF1aXJpZXMoKSwgZGIucmVxdWVzdHMoKV0pO1xuICAgIHNldExpc3RpbmdzKGwpO1xuICAgIHNldFNhdmVkSWRzKHMpO1xuICAgIHNldElucXVpcmllcyhpKTtcbiAgICBzZXRSZXF1ZXN0cyhyKTtcbiAgICBzZXRSZWFkeSh0cnVlKTtcbiAgfSwgW10pO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgLy8gV2FpdCBmb3IgdGhlIHNlc3Npb24gYmVmb3JlIHRoZSBmaXJzdCByZWFkOiBmYXZvdXJpdGVzIGFuZCBpbnF1aXJpZXMgYXJlXG4gICAgLy8gc2NvcGVkIHRvIHRoZSBzaWduZWQtaW4gdXNlciBhbmQgd291bGQgY29tZSBiYWNrIGVtcHR5IG90aGVyd2lzZS5cbiAgICBpZiAodXNpbmdEYXRhYmFzZSAmJiAhYXV0aFJlYWR5KSByZXR1cm47XG4gICAgdm9pZCByZWZyZXNoKCk7XG4gIH0sIFtyZWZyZXNoLCBhdXRoUmVhZHksIGFjY291bnQ/LmlkXSk7XG5cbiAgLy8gSWYgb3duZXIgdG9vbHMgYXJlbid0IGF2YWlsYWJsZSwgbmV2ZXIgc2l0IGluIG93bmVyIG1vZGUuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKCFjYW5Pd24gJiYgbW9kZSA9PT0gXCJvd25lclwiKSBzZXRNb2RlKFwic2Vla2VyXCIpO1xuICB9LCBbY2FuT3duLCBtb2RlXSk7XG5cbiAgLy8gS2VlcCB0aGUgdW5yZWFkIGJhZGdlIGN1cnJlbnQgd2hlcmV2ZXIgdGhlIHBlcnNvbiBpcyBpbiB0aGUgYXBwLlxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmICh1c2luZ0RhdGFiYXNlICYmICFhY2NvdW50KSB7XG4gICAgICBzZXRVbnJlYWRNZXNzYWdlcygwKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICAvLyBHdWFyZCBhZ2FpbnN0IG92ZXJsYXBwaW5nIHJ1bnM6IHRoZSBzdWJzY3JpcHRpb24gYW5kIHRoZSBwb2xsIGNhbiBib3RoXG4gICAgLy8gZmlyZSB3aGlsZSBhIHF1ZXJ5IGlzIHN0aWxsIGluIGZsaWdodCwgd2hpY2ggdHJpcGxlZCB0aGUgcmVxdWVzdCBjb3VudC5cbiAgICBsZXQgaW5GbGlnaHQgPSBmYWxzZTtcblxuICAgIGNvbnN0IGNvdW50ID0gYXN5bmMgKCkgPT4ge1xuICAgICAgaWYgKGluRmxpZ2h0KSByZXR1cm47XG4gICAgICBpbkZsaWdodCA9IHRydWU7XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCB0aHJlYWRzID0gYXdhaXQgZGIuY29udmVyc2F0aW9ucygpO1xuICAgICAgICBzZXRVbnJlYWRNZXNzYWdlcyh0aHJlYWRzLnJlZHVjZSgoc3VtLCBjKSA9PiBzdW0gKyBjLnVucmVhZCwgMCkpO1xuICAgICAgfSBjYXRjaCB7XG4gICAgICAgIHNldFVucmVhZE1lc3NhZ2VzKDApO1xuICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgaW5GbGlnaHQgPSBmYWxzZTtcbiAgICAgIH1cbiAgICB9O1xuXG4gICAgdm9pZCBjb3VudCgpO1xuICAgIHRyeSB7XG4gICAgICByZXR1cm4gZGIuc3Vic2NyaWJlVG9NZXNzYWdlcygoKSA9PiB2b2lkIGNvdW50KCkpO1xuICAgIH0gY2F0Y2gge1xuICAgICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgICB9XG4gIH0sIFthY2NvdW50XSk7XG5cbiAgY29uc3Qgc2V0UmVxdWlyZW1lbnRzID0gdXNlQ2FsbGJhY2soKHI6IFNlYXJjaFJlcXVpcmVtZW50cykgPT4ge1xuICAgIHNldFJlcXVpcmVtZW50c1N0YXRlKHIpO1xuICAgIHNldEhhc1N0YXRlZCh0cnVlKTtcbiAgfSwgW10pO1xuXG4gIGNvbnN0IHRvZ2dsZVNhdmVkID0gdXNlQ2FsbGJhY2soYXN5bmMgKGlkOiBzdHJpbmcpID0+IHtcbiAgICBjb25zdCBub3dTYXZlZCA9IGF3YWl0IGRiLnRvZ2dsZVNhdmVkKGlkKTtcbiAgICBzZXRTYXZlZElkcyhhd2FpdCBkYi5zYXZlZCgpKTtcbiAgICByZXR1cm4gbm93U2F2ZWQ7XG4gIH0sIFtdKTtcblxuICBjb25zdCB0b2dnbGVDb21wYXJlID0gdXNlQ2FsbGJhY2soKGlkOiBzdHJpbmcpID0+IHtcbiAgICBsZXQgYWRkZWQgPSBmYWxzZTtcbiAgICBzZXRDb21wYXJlSWRzKChwcmV2KSA9PiB7XG4gICAgICBpZiAocHJldi5pbmNsdWRlcyhpZCkpIHJldHVybiBwcmV2LmZpbHRlcigoeCkgPT4geCAhPT0gaWQpO1xuICAgICAgaWYgKHByZXYubGVuZ3RoID49IE1BWF9DT01QQVJFKSByZXR1cm4gcHJldjtcbiAgICAgIGFkZGVkID0gdHJ1ZTtcbiAgICAgIHJldHVybiBbLi4ucHJldiwgaWRdO1xuICAgIH0pO1xuICAgIHJldHVybiBhZGRlZDtcbiAgfSwgW10pO1xuXG4gIGNvbnN0IHNlbmRJbnF1aXJ5ID0gdXNlQ2FsbGJhY2soXG4gICAgYXN5bmMgKGlucHV0OiBPbWl0PElucXVpcnksIFwiaWRcIiB8IFwic2VudEF0XCIgfCBcInN0YXR1c1wiPikgPT4ge1xuICAgICAgYXdhaXQgZGIuY3JlYXRlSW5xdWlyeShpbnB1dCk7XG4gICAgICBhd2FpdCByZWZyZXNoKCk7XG4gICAgfSxcbiAgICBbcmVmcmVzaF0sXG4gICk7XG5cbiAgY29uc3QgYWRkUmVxdWVzdCA9IHVzZUNhbGxiYWNrKFxuICAgIGFzeW5jIChpbnB1dDogT21pdDxTcGFjZVJlcXVlc3QsIFwiaWRcIiB8IFwiY3JlYXRlZEF0XCI+KSA9PiB7XG4gICAgICBhd2FpdCBkYi5jcmVhdGVSZXF1ZXN0KGlucHV0KTtcbiAgICAgIHNldFJlcXVlc3RzKGF3YWl0IGRiLnJlcXVlc3RzKCkpO1xuICAgIH0sXG4gICAgW10sXG4gICk7XG5cbiAgY29uc3QgdmFsdWUgPSB1c2VNZW1vPEhhYml0b1N0YXRlPihcbiAgICAoKSA9PiAoe1xuICAgICAgcmVhZHksXG4gICAgICBsaXN0aW5ncyxcbiAgICAgIHJlZnJlc2gsXG4gICAgICByb2xlLFxuICAgICAgc2V0Um9sZSxcbiAgICAgIG93bmVySWQsXG4gICAgICByZXF1aXJlbWVudHMsXG4gICAgICBzZXRSZXF1aXJlbWVudHMsXG4gICAgICBoYXNTdGF0ZWROZWVkcyxcbiAgICAgIHNhdmVkSWRzLFxuICAgICAgaXNTYXZlZDogKGlkKSA9PiBzYXZlZElkcy5pbmNsdWRlcyhpZCksXG4gICAgICB0b2dnbGVTYXZlZCxcbiAgICAgIGNvbXBhcmVJZHMsXG4gICAgICBpc0NvbXBhcmluZzogKGlkKSA9PiBjb21wYXJlSWRzLmluY2x1ZGVzKGlkKSxcbiAgICAgIHRvZ2dsZUNvbXBhcmUsXG4gICAgICBjbGVhckNvbXBhcmU6ICgpID0+IHNldENvbXBhcmVJZHMoW10pLFxuICAgICAgaW5xdWlyaWVzLFxuICAgICAgc2VuZElucXVpcnksXG4gICAgICByZXF1ZXN0cyxcbiAgICAgIGFkZFJlcXVlc3QsXG4gICAgICB1bnJlYWRNZXNzYWdlcyxcbiAgICAgIGNhbk93bixcbiAgICB9KSxcbiAgICBbcmVhZHksIGxpc3RpbmdzLCByZWZyZXNoLCByb2xlLCBzZXRSb2xlLCBvd25lcklkLCByZXF1aXJlbWVudHMsIHNldFJlcXVpcmVtZW50cywgaGFzU3RhdGVkTmVlZHMsIHNhdmVkSWRzLCB0b2dnbGVTYXZlZCwgY29tcGFyZUlkcywgdG9nZ2xlQ29tcGFyZSwgaW5xdWlyaWVzLCBzZW5kSW5xdWlyeSwgcmVxdWVzdHMsIGFkZFJlcXVlc3QsIHVucmVhZE1lc3NhZ2VzLCBjYW5Pd25dLFxuICApO1xuXG4gIHJldHVybiA8Q3R4LlByb3ZpZGVyIHZhbHVlPXt2YWx1ZX0+e2NoaWxkcmVufTwvQ3R4LlByb3ZpZGVyPjtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHVzZUhhYml0bygpOiBIYWJpdG9TdGF0ZSB7XG4gIGNvbnN0IGN0eCA9IHVzZUNvbnRleHQoQ3R4KTtcbiAgaWYgKCFjdHgpIHRocm93IG5ldyBFcnJvcihcInVzZUhhYml0byBtdXN0IGJlIHVzZWQgaW5zaWRlIEhhYml0b1Byb3ZpZGVyXCIpO1xuICByZXR1cm4gY3R4O1xufVxuXG5leHBvcnQgeyBNQVhfQ09NUEFSRSB9O1xuIl0sImZpbGUiOiJEOi9JMkkgUHJvamVjdCAtIEhhYml0by9BcHAgRm9sZGVyL2hhYml0by9zcmMvaG9va3MvdXNlSGFiaXRvLnRzeCJ9