import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/@fs/D:\\I2I Project - Habito\\App Folder\\habito\\src\\pages\\Settings.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=9ceb86a3"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("D:/I2I Project - Habito/App Folder/habito/src/pages/Settings.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9ceb86a3"; const useState = __vite__cjsImport3_react["useState"];
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=9ceb86a3";
import { Languages, Bell, UserRound, Info, LogOut, FlaskConical, ShieldQuestion } from "/node_modules/.vite/deps/lucide-react.js?v=9ceb86a3";
import { useAuth } from "/src/hooks/useAuth.tsx";
import { useI18n } from "/src/i18n/index.tsx";
import { usingDatabase } from "/src/lib/api/index.ts";
import { PageHeader } from "/src/components/layout/PageHeader.tsx";
import { Button } from "/src/components/ui/Button.tsx";
import { LanguageToggle } from "/src/components/ui/LanguageToggle.tsx";
import { useToast } from "/src/components/ui/Toast.tsx";
import { cn } from "/src/lib/cn.ts";
export default function Settings() {
  _s();
  const { t } = useI18n();
  const { account, configured, signOut } = useAuth();
  const { notify } = useToast();
  const [prefs, setPrefs] = useState({ messages: true, inquiries: true, availability: true });
  const toggle = (key) => {
    setPrefs((p) => ({ ...p, [key]: !p[key] }));
    notify(t("account.updated"));
  };
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(PageHeader, { title: t("settings.title"), lead: t("settings.lead") }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Settings.tsx",
      lineNumber: 55,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "container-page max-w-2xl space-y-4 py-8 md:py-10", children: [
      /* @__PURE__ */ jsxDEV(Section, { icon: Languages, title: t("account.language"), children: [
        /* @__PURE__ */ jsxDEV("p", { className: "mb-4 text-sm leading-relaxed text-muted", children: t("account.languageBody") }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Settings.tsx",
          lineNumber: 60,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(LanguageToggle, {}, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Settings.tsx",
          lineNumber: 61,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Settings.tsx",
        lineNumber: 59,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Section, { icon: Bell, title: t("settings.notifications"), children: [
        /* @__PURE__ */ jsxDEV("ul", { className: "divide-y divide-hairline", children: [
          { key: "messages", label: t("settings.notifyMessages") },
          { key: "inquiries", label: t("settings.notifyInquiries") },
          { key: "availability", label: t("settings.notifyAvailability") }
        ].map(
          (row) => /* @__PURE__ */ jsxDEV("li", { className: "flex items-center justify-between gap-4 py-3 first:pt-0", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-ink", children: row.label }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Settings.tsx",
              lineNumber: 73,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(Switch, { on: prefs[row.key], onClick: () => toggle(row.key), label: row.label }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Settings.tsx",
              lineNumber: 74,
              columnNumber: 17
            }, this)
          ] }, row.key, true, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Settings.tsx",
            lineNumber: 72,
            columnNumber: 13
          }, this)
        ) }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Settings.tsx",
          lineNumber: 66,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "mt-3 text-xs leading-relaxed text-muted", children: t("settings.notifyNote") }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Settings.tsx",
          lineNumber: 78,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Settings.tsx",
        lineNumber: 65,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Section, { icon: UserRound, title: t("settings.account"), children: account ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV("dl", { className: "space-y-2 text-sm", children: [
          /* @__PURE__ */ jsxDEV(Row, { label: t("account.name"), value: account.name }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Settings.tsx",
            lineNumber: 86,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Row, { label: t("auth.email"), value: account.email ?? "—" }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Settings.tsx",
            lineNumber: 87,
            columnNumber: 17
          }, this),
          account.phone && /* @__PURE__ */ jsxDEV(Row, { label: t("auth.phone"), value: account.phone }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Settings.tsx",
            lineNumber: 88,
            columnNumber: 35
          }, this)
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Settings.tsx",
          lineNumber: 85,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-4 flex flex-wrap gap-2", children: [
          /* @__PURE__ */ jsxDEV(Link, { to: "/account", children: /* @__PURE__ */ jsxDEV(Button, { size: "sm", variant: "secondary", children: t("account.profile") }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Settings.tsx",
            lineNumber: 93,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Settings.tsx",
            lineNumber: 92,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Button, { size: "sm", variant: "secondary", onClick: () => void signOut(), children: [
            /* @__PURE__ */ jsxDEV(LogOut, { size: 14, "aria-hidden": true }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Settings.tsx",
              lineNumber: 98,
              columnNumber: 19
            }, this),
            t("settings.signOut")
          ] }, void 0, true, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Settings.tsx",
            lineNumber: 97,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Settings.tsx",
          lineNumber: 91,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Settings.tsx",
        lineNumber: 84,
        columnNumber: 11
      }, this) : configured ? /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-2", children: [
        /* @__PURE__ */ jsxDEV(Link, { to: "/signin", children: /* @__PURE__ */ jsxDEV(Button, { size: "sm", variant: "secondary", children: t("action.signIn") }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Settings.tsx",
          lineNumber: 106,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Settings.tsx",
          lineNumber: 105,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(Link, { to: "/signup", children: /* @__PURE__ */ jsxDEV(Button, { size: "sm", children: t("action.getStarted") }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Settings.tsx",
          lineNumber: 111,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Settings.tsx",
          lineNumber: 110,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Settings.tsx",
        lineNumber: 104,
        columnNumber: 11
      }, this) : /* @__PURE__ */ jsxDEV("p", { className: "text-sm leading-relaxed text-muted", children: t("auth.noDatabase") }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Settings.tsx",
        lineNumber: 115,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Settings.tsx",
        lineNumber: 82,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Section, { icon: Info, title: t("settings.about"), children: [
        /* @__PURE__ */ jsxDEV("ul", { className: "space-y-3", children: [
          /* @__PURE__ */ jsxDEV("li", { className: "flex gap-2.5", children: [
            /* @__PURE__ */ jsxDEV(FlaskConical, { size: 15, className: "mt-0.5 shrink-0 text-aqua-600", "aria-hidden": true }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Settings.tsx",
              lineNumber: 123,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-sm leading-relaxed text-ink-soft", children: t("settings.aboutData") }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Settings.tsx",
              lineNumber: 124,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Settings.tsx",
            lineNumber: 122,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("li", { className: "flex gap-2.5", children: [
            /* @__PURE__ */ jsxDEV(ShieldQuestion, { size: 15, className: "mt-0.5 shrink-0 text-warn-700", "aria-hidden": true }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Settings.tsx",
              lineNumber: 127,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-sm leading-relaxed text-ink-soft", children: t("settings.aboutVerification") }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Settings.tsx",
              lineNumber: 128,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Settings.tsx",
            lineNumber: 126,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Settings.tsx",
          lineNumber: 121,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "mt-4 border-t border-hairline pt-3 text-xs text-muted", children: usingDatabase ? t("account.yourData") : t("account.thisDevice") }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Settings.tsx",
          lineNumber: 132,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Settings.tsx",
        lineNumber: 120,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Settings.tsx",
      lineNumber: 57,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Settings.tsx",
    lineNumber: 54,
    columnNumber: 5
  }, this);
}
_s(Settings, "kyEScA6mCGyt46p/aoVAu0UNtgg=", false, function() {
  return [useI18n, useAuth, useToast];
});
_c = Settings;
function Section({
  icon: Icon,
  title,
  children
}) {
  return /* @__PURE__ */ jsxDEV("section", { className: "rounded-card bg-surface p-5 ring-1 ring-hairline sm:p-6", children: [
    /* @__PURE__ */ jsxDEV("h2", { className: "mb-4 flex items-center gap-2 font-display text-lg font-bold text-ink", children: [
      /* @__PURE__ */ jsxDEV(Icon, { size: 17, className: "text-muted", "aria-hidden": true }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Settings.tsx",
        lineNumber: 153,
        columnNumber: 9
      }, this),
      title
    ] }, void 0, true, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Settings.tsx",
      lineNumber: 152,
      columnNumber: 7
    }, this),
    children
  ] }, void 0, true, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Settings.tsx",
    lineNumber: 151,
    columnNumber: 5
  }, this);
}
_c2 = Section;
function Row({ label, value }) {
  return /* @__PURE__ */ jsxDEV("div", { className: "flex items-baseline justify-between gap-3", children: [
    /* @__PURE__ */ jsxDEV("dt", { className: "text-ink-soft", children: label }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Settings.tsx",
      lineNumber: 164,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("dd", { className: "truncate font-semibold text-ink", children: value }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Settings.tsx",
      lineNumber: 165,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Settings.tsx",
    lineNumber: 163,
    columnNumber: 5
  }, this);
}
_c3 = Row;
function Switch({ on, onClick, label }) {
  return /* @__PURE__ */ jsxDEV(
    "button",
    {
      type: "button",
      role: "switch",
      "aria-checked": on,
      "aria-label": label,
      onClick,
      className: cn(
        "relative h-7 w-12 shrink-0 rounded-full transition-colors",
        on ? "bg-aqua-600" : "bg-hairline-strong"
      ),
      children: /* @__PURE__ */ jsxDEV(
        "span",
        {
          "aria-hidden": true,
          className: cn(
            "absolute top-0.5 left-0.5 size-6 rounded-full bg-white shadow-sm transition-transform duration-150",
            on ? "translate-x-5" : "translate-x-0"
          )
        },
        void 0,
        false,
        {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Settings.tsx",
          lineNumber: 184,
          columnNumber: 7
        },
        this
      )
    },
    void 0,
    false,
    {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Settings.tsx",
      lineNumber: 173,
      columnNumber: 5
    },
    this
  );
}
_c4 = Switch;
var _c, _c2, _c3, _c4;
$RefreshReg$(_c, "Settings");
$RefreshReg$(_c2, "Section");
$RefreshReg$(_c3, "Row");
$RefreshReg$(_c4, "Switch");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/I2I Project - Habito/App Folder/habito/src/pages/Settings.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/I2I Project - Habito/App Folder/habito/src/pages/Settings.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbUNNLFNBNkJNLFVBN0JOOzs7Ozs7Ozs7Ozs7Ozs7OztBQW5DTixTQUFTQSxnQkFBZ0I7QUFDekIsU0FBU0MsWUFBWTtBQUNyQixTQUFTQyxXQUFXQyxNQUFNQyxXQUFXQyxNQUFNQyxRQUFRQyxjQUFjQyxzQkFBc0I7QUFDdkYsU0FBU0MsZUFBZTtBQUN4QixTQUFTQyxlQUFlO0FBQ3hCLFNBQVNDLHFCQUFxQjtBQUM5QixTQUFTQyxrQkFBa0I7QUFDM0IsU0FBU0MsY0FBYztBQUN2QixTQUFTQyxzQkFBc0I7QUFDL0IsU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLFVBQVU7QUFTbkIsd0JBQXdCQyxXQUFXO0FBQUFDLEtBQUE7QUFDakMsUUFBTSxFQUFFQyxFQUFFLElBQUlULFFBQVE7QUFDdEIsUUFBTSxFQUFFVSxTQUFTQyxZQUFZQyxRQUFRLElBQUliLFFBQVE7QUFDakQsUUFBTSxFQUFFYyxPQUFPLElBQUlSLFNBQVM7QUFJNUIsUUFBTSxDQUFDUyxPQUFPQyxRQUFRLElBQUl6QixTQUFTLEVBQUUwQixVQUFVLE1BQU1DLFdBQVcsTUFBTUMsY0FBYyxLQUFLLENBQUM7QUFFMUYsUUFBTUMsU0FBU0EsQ0FBQ0MsUUFBNEI7QUFDMUNMLGFBQVMsQ0FBQ00sT0FBTyxFQUFFLEdBQUdBLEdBQUcsQ0FBQ0QsR0FBRyxHQUFHLENBQUNDLEVBQUVELEdBQUcsRUFBRSxFQUFFO0FBQzFDUCxXQUFPSixFQUFFLGlCQUFpQixDQUFDO0FBQUEsRUFDN0I7QUFFQSxTQUNFLG1DQUNFO0FBQUEsMkJBQUMsY0FBVyxPQUFPQSxFQUFFLGdCQUFnQixHQUFHLE1BQU1BLEVBQUUsZUFBZSxLQUEvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWlFO0FBQUEsSUFFakUsdUJBQUMsU0FBSSxXQUFVLG9EQUViO0FBQUEsNkJBQUMsV0FBUSxNQUFNakIsV0FBVyxPQUFPaUIsRUFBRSxrQkFBa0IsR0FDbkQ7QUFBQSwrQkFBQyxPQUFFLFdBQVUsMkNBQTJDQSxZQUFFLHNCQUFzQixLQUFoRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtGO0FBQUEsUUFDbEYsdUJBQUMsb0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFlO0FBQUEsV0FGakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFHQSx1QkFBQyxXQUFRLE1BQU1oQixNQUFNLE9BQU9nQixFQUFFLHdCQUF3QixHQUNwRDtBQUFBLCtCQUFDLFFBQUcsV0FBVSw0QkFDVjtBQUFBLFVBQ0EsRUFBRVcsS0FBSyxZQUFxQkUsT0FBT2IsRUFBRSx5QkFBeUIsRUFBRTtBQUFBLFVBQ2hFLEVBQUVXLEtBQUssYUFBc0JFLE9BQU9iLEVBQUUsMEJBQTBCLEVBQUU7QUFBQSxVQUNsRSxFQUFFVyxLQUFLLGdCQUF5QkUsT0FBT2IsRUFBRSw2QkFBNkIsRUFBRTtBQUFBLFFBQUMsRUFDeEVjO0FBQUFBLFVBQUksQ0FBQ0MsUUFDTix1QkFBQyxRQUFpQixXQUFVLDJEQUMxQjtBQUFBLG1DQUFDLFVBQUssV0FBVSxvQkFBb0JBLGNBQUlGLFNBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQThDO0FBQUEsWUFDOUMsdUJBQUMsVUFBTyxJQUFJUixNQUFNVSxJQUFJSixHQUFHLEdBQUcsU0FBUyxNQUFNRCxPQUFPSyxJQUFJSixHQUFHLEdBQUcsT0FBT0ksSUFBSUYsU0FBdkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNkU7QUFBQSxlQUZ0RUUsSUFBSUosS0FBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsUUFDRCxLQVZIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFXQTtBQUFBLFFBQ0EsdUJBQUMsT0FBRSxXQUFVLDJDQUEyQ1gsWUFBRSxxQkFBcUIsS0FBL0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpRjtBQUFBLFdBYm5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFjQTtBQUFBLE1BR0EsdUJBQUMsV0FBUSxNQUFNZixXQUFXLE9BQU9lLEVBQUUsa0JBQWtCLEdBQ2xEQyxvQkFDQyxtQ0FDRTtBQUFBLCtCQUFDLFFBQUcsV0FBVSxxQkFDWjtBQUFBLGlDQUFDLE9BQUksT0FBT0QsRUFBRSxjQUFjLEdBQUcsT0FBT0MsUUFBUWUsUUFBOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbUQ7QUFBQSxVQUNuRCx1QkFBQyxPQUFJLE9BQU9oQixFQUFFLFlBQVksR0FBRyxPQUFPQyxRQUFRZ0IsU0FBUyxPQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF5RDtBQUFBLFVBQ3hEaEIsUUFBUWlCLFNBQVMsdUJBQUMsT0FBSSxPQUFPbEIsRUFBRSxZQUFZLEdBQUcsT0FBT0MsUUFBUWlCLFNBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWtEO0FBQUEsYUFIdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUlBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsNkJBQ2I7QUFBQSxpQ0FBQyxRQUFLLElBQUcsWUFDUCxpQ0FBQyxVQUFPLE1BQUssTUFBSyxTQUFRLGFBQ3ZCbEIsWUFBRSxpQkFBaUIsS0FEdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBSUE7QUFBQSxVQUNBLHVCQUFDLFVBQU8sTUFBSyxNQUFLLFNBQVEsYUFBWSxTQUFTLE1BQU0sS0FBS0csUUFBUSxHQUNoRTtBQUFBLG1DQUFDLFVBQU8sTUFBTSxJQUFJLGVBQVcsUUFBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNkI7QUFBQSxZQUM1QkgsRUFBRSxrQkFBa0I7QUFBQSxlQUZ2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsYUFURjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBVUE7QUFBQSxXQWpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBa0JBLElBQ0VFLGFBQ0YsdUJBQUMsU0FBSSxXQUFVLHdCQUNiO0FBQUEsK0JBQUMsUUFBSyxJQUFHLFdBQ1AsaUNBQUMsVUFBTyxNQUFLLE1BQUssU0FBUSxhQUN2QkYsWUFBRSxlQUFlLEtBRHBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFJQTtBQUFBLFFBQ0EsdUJBQUMsUUFBSyxJQUFHLFdBQ1AsaUNBQUMsVUFBTyxNQUFLLE1BQU1BLFlBQUUsbUJBQW1CLEtBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMEMsS0FENUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBU0EsSUFFQSx1QkFBQyxPQUFFLFdBQVUsc0NBQXNDQSxZQUFFLGlCQUFpQixLQUF0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXdFLEtBakM1RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBbUNBO0FBQUEsTUFHQSx1QkFBQyxXQUFRLE1BQU1kLE1BQU0sT0FBT2MsRUFBRSxnQkFBZ0IsR0FDNUM7QUFBQSwrQkFBQyxRQUFHLFdBQVUsYUFDWjtBQUFBLGlDQUFDLFFBQUcsV0FBVSxnQkFDWjtBQUFBLG1DQUFDLGdCQUFhLE1BQU0sSUFBSSxXQUFVLGlDQUFnQyxlQUFXLFFBQTdFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTZFO0FBQUEsWUFDN0UsdUJBQUMsT0FBRSxXQUFVLHlDQUF5Q0EsWUFBRSxvQkFBb0IsS0FBNUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBOEU7QUFBQSxlQUZoRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFDQSx1QkFBQyxRQUFHLFdBQVUsZ0JBQ1o7QUFBQSxtQ0FBQyxrQkFBZSxNQUFNLElBQUksV0FBVSxpQ0FBZ0MsZUFBVyxRQUEvRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUErRTtBQUFBLFlBQy9FLHVCQUFDLE9BQUUsV0FBVSx5Q0FBeUNBLFlBQUUsNEJBQTRCLEtBQXBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXNGO0FBQUEsZUFGeEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLGFBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVNBO0FBQUEsUUFFQSx1QkFBQyxPQUFFLFdBQVUseURBQ1ZSLDBCQUFnQlEsRUFBRSxrQkFBa0IsSUFBSUEsRUFBRSxvQkFBb0IsS0FEakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBZUE7QUFBQSxTQTlFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBK0VBO0FBQUEsT0FsRkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQW1GQTtBQUVKO0FBQUNELEdBcEd1QkQsVUFBUTtBQUFBLFVBQ2hCUCxTQUMyQkQsU0FDdEJNLFFBQVE7QUFBQTtBQUFBLEtBSExFO0FBc0d4QixTQUFTcUIsUUFBUTtBQUFBLEVBQ2ZDLE1BQU1DO0FBQUFBLEVBQ05DO0FBQUFBLEVBQ0FDO0FBS0YsR0FBRztBQUNELFNBQ0UsdUJBQUMsYUFBUSxXQUFVLDJEQUNqQjtBQUFBLDJCQUFDLFFBQUcsV0FBVSx3RUFDWjtBQUFBLDZCQUFDLFFBQUssTUFBTSxJQUFJLFdBQVUsY0FBYSxlQUFXLFFBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBa0Q7QUFBQSxNQUNqREQ7QUFBQUEsU0FGSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR0E7QUFBQSxJQUNDQztBQUFBQSxPQUxIO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FNQTtBQUVKO0FBQUNDLE1BbEJRTDtBQW9CVCxTQUFTTSxJQUFJLEVBQUVaLE9BQU9hLE1BQXdDLEdBQUc7QUFDL0QsU0FDRSx1QkFBQyxTQUFJLFdBQVUsNkNBQ2I7QUFBQSwyQkFBQyxRQUFHLFdBQVUsaUJBQWlCYixtQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFxQztBQUFBLElBQ3JDLHVCQUFDLFFBQUcsV0FBVSxtQ0FBbUNhLG1CQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXVEO0FBQUEsT0FGekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUdBO0FBRUo7QUFFQUMsTUFUU0Y7QUFVVCxTQUFTRyxPQUFPLEVBQUVDLElBQUlDLFNBQVNqQixNQUEyRCxHQUFHO0FBQzNGLFNBQ0U7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNDLE1BQUs7QUFBQSxNQUNMLE1BQUs7QUFBQSxNQUNMLGdCQUFjZ0I7QUFBQUEsTUFDZCxjQUFZaEI7QUFBQUEsTUFDWjtBQUFBLE1BQ0EsV0FBV2hCO0FBQUFBLFFBQ1Q7QUFBQSxRQUNBZ0MsS0FBSyxnQkFBZ0I7QUFBQSxNQUN2QjtBQUFBLE1BRUE7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDO0FBQUEsVUFDQSxXQUFXaEM7QUFBQUEsWUFDVDtBQUFBLFlBQ0FnQyxLQUFLLGtCQUFrQjtBQUFBLFVBQ3pCO0FBQUE7QUFBQSxRQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUtJO0FBQUE7QUFBQSxJQWhCTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFrQkE7QUFFSjtBQUFDRSxNQXRCUUg7QUFBTSxJQUFBSSxJQUFBUixLQUFBRyxLQUFBSTtBQUFBLGFBQUFDLElBQUE7QUFBQSxhQUFBUixLQUFBO0FBQUEsYUFBQUcsS0FBQTtBQUFBLGFBQUFJLEtBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsIkxpbmsiLCJMYW5ndWFnZXMiLCJCZWxsIiwiVXNlclJvdW5kIiwiSW5mbyIsIkxvZ091dCIsIkZsYXNrQ29uaWNhbCIsIlNoaWVsZFF1ZXN0aW9uIiwidXNlQXV0aCIsInVzZUkxOG4iLCJ1c2luZ0RhdGFiYXNlIiwiUGFnZUhlYWRlciIsIkJ1dHRvbiIsIkxhbmd1YWdlVG9nZ2xlIiwidXNlVG9hc3QiLCJjbiIsIlNldHRpbmdzIiwiX3MiLCJ0IiwiYWNjb3VudCIsImNvbmZpZ3VyZWQiLCJzaWduT3V0Iiwibm90aWZ5IiwicHJlZnMiLCJzZXRQcmVmcyIsIm1lc3NhZ2VzIiwiaW5xdWlyaWVzIiwiYXZhaWxhYmlsaXR5IiwidG9nZ2xlIiwia2V5IiwicCIsImxhYmVsIiwibWFwIiwicm93IiwibmFtZSIsImVtYWlsIiwicGhvbmUiLCJTZWN0aW9uIiwiaWNvbiIsIkljb24iLCJ0aXRsZSIsImNoaWxkcmVuIiwiX2MyIiwiUm93IiwidmFsdWUiLCJfYzMiLCJTd2l0Y2giLCJvbiIsIm9uQ2xpY2siLCJfYzQiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJTZXR0aW5ncy50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IExpbmsgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xuaW1wb3J0IHsgTGFuZ3VhZ2VzLCBCZWxsLCBVc2VyUm91bmQsIEluZm8sIExvZ091dCwgRmxhc2tDb25pY2FsLCBTaGllbGRRdWVzdGlvbiB9IGZyb20gXCJsdWNpZGUtcmVhY3RcIjtcbmltcG9ydCB7IHVzZUF1dGggfSBmcm9tIFwiQC9ob29rcy91c2VBdXRoXCI7XG5pbXBvcnQgeyB1c2VJMThuIH0gZnJvbSBcIkAvaTE4blwiO1xuaW1wb3J0IHsgdXNpbmdEYXRhYmFzZSB9IGZyb20gXCJAL2xpYi9hcGlcIjtcbmltcG9ydCB7IFBhZ2VIZWFkZXIgfSBmcm9tIFwiQC9jb21wb25lbnRzL2xheW91dC9QYWdlSGVhZGVyXCI7XG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tIFwiQC9jb21wb25lbnRzL3VpL0J1dHRvblwiO1xuaW1wb3J0IHsgTGFuZ3VhZ2VUb2dnbGUgfSBmcm9tIFwiQC9jb21wb25lbnRzL3VpL0xhbmd1YWdlVG9nZ2xlXCI7XG5pbXBvcnQgeyB1c2VUb2FzdCB9IGZyb20gXCJAL2NvbXBvbmVudHMvdWkvVG9hc3RcIjtcbmltcG9ydCB7IGNuIH0gZnJvbSBcIkAvbGliL2NuXCI7XG5cbi8qKlxuICogU2V0dGluZ3MuXG4gKlxuICogT24gYSBwaG9uZSB0aGlzIGlzIHdoZXJlIHBlb3BsZSBsb29rIGZvciBsYW5ndWFnZSwgbm90aWZpY2F0aW9ucyBhbmQgdGhlIHdheVxuICogb3V0LiBJdCBhbHNvIGNhcnJpZXMgdGhlIHR3byBob25lc3Qgc3RhdGVtZW50cyBhYm91dCB3aGF0IEhhYml0bydzIGRhdGEgYW5kXG4gKiBiYWRnZXMgYWN0dWFsbHkgbWVhbiDigJQgZmluZGFibGUgcmF0aGVyIHRoYW4gYnVyaWVkIGluIGEgZm9vdGVyLlxuICovXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBTZXR0aW5ncygpIHtcbiAgY29uc3QgeyB0IH0gPSB1c2VJMThuKCk7XG4gIGNvbnN0IHsgYWNjb3VudCwgY29uZmlndXJlZCwgc2lnbk91dCB9ID0gdXNlQXV0aCgpO1xuICBjb25zdCB7IG5vdGlmeSB9ID0gdXNlVG9hc3QoKTtcblxuICAvLyBOb3RpZmljYXRpb24gY2hhbm5lbHMgZG9uJ3QgZXhpc3QgeWV0LCBzbyB0aGVzZSBhcmUgc3RvcmVkIHByZWZlcmVuY2VzXG4gIC8vIHJhdGhlciB0aGFuIHN3aXRjaGVzIHRoYXQgcHJldGVuZCB0byBkbyBzb21ldGhpbmcuXG4gIGNvbnN0IFtwcmVmcywgc2V0UHJlZnNdID0gdXNlU3RhdGUoeyBtZXNzYWdlczogdHJ1ZSwgaW5xdWlyaWVzOiB0cnVlLCBhdmFpbGFiaWxpdHk6IHRydWUgfSk7XG5cbiAgY29uc3QgdG9nZ2xlID0gKGtleToga2V5b2YgdHlwZW9mIHByZWZzKSA9PiB7XG4gICAgc2V0UHJlZnMoKHApID0+ICh7IC4uLnAsIFtrZXldOiAhcFtrZXldIH0pKTtcbiAgICBub3RpZnkodChcImFjY291bnQudXBkYXRlZFwiKSk7XG4gIH07XG5cbiAgcmV0dXJuIChcbiAgICA8PlxuICAgICAgPFBhZ2VIZWFkZXIgdGl0bGU9e3QoXCJzZXR0aW5ncy50aXRsZVwiKX0gbGVhZD17dChcInNldHRpbmdzLmxlYWRcIil9IC8+XG5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29udGFpbmVyLXBhZ2UgbWF4LXctMnhsIHNwYWNlLXktNCBweS04IG1kOnB5LTEwXCI+XG4gICAgICAgIHsvKiBMYW5ndWFnZSAqL31cbiAgICAgICAgPFNlY3Rpb24gaWNvbj17TGFuZ3VhZ2VzfSB0aXRsZT17dChcImFjY291bnQubGFuZ3VhZ2VcIil9PlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm1iLTQgdGV4dC1zbSBsZWFkaW5nLXJlbGF4ZWQgdGV4dC1tdXRlZFwiPnt0KFwiYWNjb3VudC5sYW5ndWFnZUJvZHlcIil9PC9wPlxuICAgICAgICAgIDxMYW5ndWFnZVRvZ2dsZSAvPlxuICAgICAgICA8L1NlY3Rpb24+XG5cbiAgICAgICAgey8qIE5vdGlmaWNhdGlvbnMgKi99XG4gICAgICAgIDxTZWN0aW9uIGljb249e0JlbGx9IHRpdGxlPXt0KFwic2V0dGluZ3Mubm90aWZpY2F0aW9uc1wiKX0+XG4gICAgICAgICAgPHVsIGNsYXNzTmFtZT1cImRpdmlkZS15IGRpdmlkZS1oYWlybGluZVwiPlxuICAgICAgICAgICAgeyhbXG4gICAgICAgICAgICAgIHsga2V5OiBcIm1lc3NhZ2VzXCIgYXMgY29uc3QsIGxhYmVsOiB0KFwic2V0dGluZ3Mubm90aWZ5TWVzc2FnZXNcIikgfSxcbiAgICAgICAgICAgICAgeyBrZXk6IFwiaW5xdWlyaWVzXCIgYXMgY29uc3QsIGxhYmVsOiB0KFwic2V0dGluZ3Mubm90aWZ5SW5xdWlyaWVzXCIpIH0sXG4gICAgICAgICAgICAgIHsga2V5OiBcImF2YWlsYWJpbGl0eVwiIGFzIGNvbnN0LCBsYWJlbDogdChcInNldHRpbmdzLm5vdGlmeUF2YWlsYWJpbGl0eVwiKSB9LFxuICAgICAgICAgICAgXSkubWFwKChyb3cpID0+IChcbiAgICAgICAgICAgICAgPGxpIGtleT17cm93LmtleX0gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC00IHB5LTMgZmlyc3Q6cHQtMFwiPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1pbmtcIj57cm93LmxhYmVsfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8U3dpdGNoIG9uPXtwcmVmc1tyb3cua2V5XX0gb25DbGljaz17KCkgPT4gdG9nZ2xlKHJvdy5rZXkpfSBsYWJlbD17cm93LmxhYmVsfSAvPlxuICAgICAgICAgICAgICA8L2xpPlxuICAgICAgICAgICAgKSl9XG4gICAgICAgICAgPC91bD5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0zIHRleHQteHMgbGVhZGluZy1yZWxheGVkIHRleHQtbXV0ZWRcIj57dChcInNldHRpbmdzLm5vdGlmeU5vdGVcIil9PC9wPlxuICAgICAgICA8L1NlY3Rpb24+XG5cbiAgICAgICAgey8qIEFjY291bnQgKi99XG4gICAgICAgIDxTZWN0aW9uIGljb249e1VzZXJSb3VuZH0gdGl0bGU9e3QoXCJzZXR0aW5ncy5hY2NvdW50XCIpfT5cbiAgICAgICAgICB7YWNjb3VudCA/IChcbiAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgIDxkbCBjbGFzc05hbWU9XCJzcGFjZS15LTIgdGV4dC1zbVwiPlxuICAgICAgICAgICAgICAgIDxSb3cgbGFiZWw9e3QoXCJhY2NvdW50Lm5hbWVcIil9IHZhbHVlPXthY2NvdW50Lm5hbWV9IC8+XG4gICAgICAgICAgICAgICAgPFJvdyBsYWJlbD17dChcImF1dGguZW1haWxcIil9IHZhbHVlPXthY2NvdW50LmVtYWlsID8/IFwi4oCUXCJ9IC8+XG4gICAgICAgICAgICAgICAge2FjY291bnQucGhvbmUgJiYgPFJvdyBsYWJlbD17dChcImF1dGgucGhvbmVcIil9IHZhbHVlPXthY2NvdW50LnBob25lfSAvPn1cbiAgICAgICAgICAgICAgPC9kbD5cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTQgZmxleCBmbGV4LXdyYXAgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICA8TGluayB0bz1cIi9hY2NvdW50XCI+XG4gICAgICAgICAgICAgICAgICA8QnV0dG9uIHNpemU9XCJzbVwiIHZhcmlhbnQ9XCJzZWNvbmRhcnlcIj5cbiAgICAgICAgICAgICAgICAgICAge3QoXCJhY2NvdW50LnByb2ZpbGVcIil9XG4gICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgICAgICA8L0xpbms+XG4gICAgICAgICAgICAgICAgPEJ1dHRvbiBzaXplPVwic21cIiB2YXJpYW50PVwic2Vjb25kYXJ5XCIgb25DbGljaz17KCkgPT4gdm9pZCBzaWduT3V0KCl9PlxuICAgICAgICAgICAgICAgICAgPExvZ091dCBzaXplPXsxNH0gYXJpYS1oaWRkZW4gLz5cbiAgICAgICAgICAgICAgICAgIHt0KFwic2V0dGluZ3Muc2lnbk91dFwiKX1cbiAgICAgICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8Lz5cbiAgICAgICAgICApIDogY29uZmlndXJlZCA/IChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgPExpbmsgdG89XCIvc2lnbmluXCI+XG4gICAgICAgICAgICAgICAgPEJ1dHRvbiBzaXplPVwic21cIiB2YXJpYW50PVwic2Vjb25kYXJ5XCI+XG4gICAgICAgICAgICAgICAgICB7dChcImFjdGlvbi5zaWduSW5cIil9XG4gICAgICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgICAgIDwvTGluaz5cbiAgICAgICAgICAgICAgPExpbmsgdG89XCIvc2lnbnVwXCI+XG4gICAgICAgICAgICAgICAgPEJ1dHRvbiBzaXplPVwic21cIj57dChcImFjdGlvbi5nZXRTdGFydGVkXCIpfTwvQnV0dG9uPlxuICAgICAgICAgICAgICA8L0xpbms+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApIDogKFxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBsZWFkaW5nLXJlbGF4ZWQgdGV4dC1tdXRlZFwiPnt0KFwiYXV0aC5ub0RhdGFiYXNlXCIpfTwvcD5cbiAgICAgICAgICApfVxuICAgICAgICA8L1NlY3Rpb24+XG5cbiAgICAgICAgey8qIEhvbmVzdCBzdGF0ZW1lbnRzICovfVxuICAgICAgICA8U2VjdGlvbiBpY29uPXtJbmZvfSB0aXRsZT17dChcInNldHRpbmdzLmFib3V0XCIpfT5cbiAgICAgICAgICA8dWwgY2xhc3NOYW1lPVwic3BhY2UteS0zXCI+XG4gICAgICAgICAgICA8bGkgY2xhc3NOYW1lPVwiZmxleCBnYXAtMi41XCI+XG4gICAgICAgICAgICAgIDxGbGFza0NvbmljYWwgc2l6ZT17MTV9IGNsYXNzTmFtZT1cIm10LTAuNSBzaHJpbmstMCB0ZXh0LWFxdWEtNjAwXCIgYXJpYS1oaWRkZW4gLz5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBsZWFkaW5nLXJlbGF4ZWQgdGV4dC1pbmstc29mdFwiPnt0KFwic2V0dGluZ3MuYWJvdXREYXRhXCIpfTwvcD5cbiAgICAgICAgICAgIDwvbGk+XG4gICAgICAgICAgICA8bGkgY2xhc3NOYW1lPVwiZmxleCBnYXAtMi41XCI+XG4gICAgICAgICAgICAgIDxTaGllbGRRdWVzdGlvbiBzaXplPXsxNX0gY2xhc3NOYW1lPVwibXQtMC41IHNocmluay0wIHRleHQtd2Fybi03MDBcIiBhcmlhLWhpZGRlbiAvPlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGxlYWRpbmctcmVsYXhlZCB0ZXh0LWluay1zb2Z0XCI+e3QoXCJzZXR0aW5ncy5hYm91dFZlcmlmaWNhdGlvblwiKX08L3A+XG4gICAgICAgICAgICA8L2xpPlxuICAgICAgICAgIDwvdWw+XG5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC00IGJvcmRlci10IGJvcmRlci1oYWlybGluZSBwdC0zIHRleHQteHMgdGV4dC1tdXRlZFwiPlxuICAgICAgICAgICAge3VzaW5nRGF0YWJhc2UgPyB0KFwiYWNjb3VudC55b3VyRGF0YVwiKSA6IHQoXCJhY2NvdW50LnRoaXNEZXZpY2VcIil9XG4gICAgICAgICAgPC9wPlxuICAgICAgICA8L1NlY3Rpb24+XG4gICAgICA8L2Rpdj5cbiAgICA8Lz5cbiAgKTtcbn1cblxuZnVuY3Rpb24gU2VjdGlvbih7XG4gIGljb246IEljb24sXG4gIHRpdGxlLFxuICBjaGlsZHJlbixcbn06IHtcbiAgaWNvbjogdHlwZW9mIEJlbGw7XG4gIHRpdGxlOiBzdHJpbmc7XG4gIGNoaWxkcmVuOiBSZWFjdC5SZWFjdE5vZGU7XG59KSB7XG4gIHJldHVybiAoXG4gICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwicm91bmRlZC1jYXJkIGJnLXN1cmZhY2UgcC01IHJpbmctMSByaW5nLWhhaXJsaW5lIHNtOnAtNlwiPlxuICAgICAgPGgyIGNsYXNzTmFtZT1cIm1iLTQgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgZm9udC1kaXNwbGF5IHRleHQtbGcgZm9udC1ib2xkIHRleHQtaW5rXCI+XG4gICAgICAgIDxJY29uIHNpemU9ezE3fSBjbGFzc05hbWU9XCJ0ZXh0LW11dGVkXCIgYXJpYS1oaWRkZW4gLz5cbiAgICAgICAge3RpdGxlfVxuICAgICAgPC9oMj5cbiAgICAgIHtjaGlsZHJlbn1cbiAgICA8L3NlY3Rpb24+XG4gICk7XG59XG5cbmZ1bmN0aW9uIFJvdyh7IGxhYmVsLCB2YWx1ZSB9OiB7IGxhYmVsOiBzdHJpbmc7IHZhbHVlOiBzdHJpbmcgfSkge1xuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1iYXNlbGluZSBqdXN0aWZ5LWJldHdlZW4gZ2FwLTNcIj5cbiAgICAgIDxkdCBjbGFzc05hbWU9XCJ0ZXh0LWluay1zb2Z0XCI+e2xhYmVsfTwvZHQ+XG4gICAgICA8ZGQgY2xhc3NOYW1lPVwidHJ1bmNhdGUgZm9udC1zZW1pYm9sZCB0ZXh0LWlua1wiPnt2YWx1ZX08L2RkPlxuICAgIDwvZGl2PlxuICApO1xufVxuXG4vKiogTGFyZ2UgZW5vdWdoIHRvIGhpdCB3aXRoIGEgdGh1bWIuICovXG5mdW5jdGlvbiBTd2l0Y2goeyBvbiwgb25DbGljaywgbGFiZWwgfTogeyBvbjogYm9vbGVhbjsgb25DbGljazogKCkgPT4gdm9pZDsgbGFiZWw6IHN0cmluZyB9KSB7XG4gIHJldHVybiAoXG4gICAgPGJ1dHRvblxuICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICByb2xlPVwic3dpdGNoXCJcbiAgICAgIGFyaWEtY2hlY2tlZD17b259XG4gICAgICBhcmlhLWxhYmVsPXtsYWJlbH1cbiAgICAgIG9uQ2xpY2s9e29uQ2xpY2t9XG4gICAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgICBcInJlbGF0aXZlIGgtNyB3LTEyIHNocmluay0wIHJvdW5kZWQtZnVsbCB0cmFuc2l0aW9uLWNvbG9yc1wiLFxuICAgICAgICBvbiA/IFwiYmctYXF1YS02MDBcIiA6IFwiYmctaGFpcmxpbmUtc3Ryb25nXCIsXG4gICAgICApfVxuICAgID5cbiAgICAgIDxzcGFuXG4gICAgICAgIGFyaWEtaGlkZGVuXG4gICAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgICAgXCJhYnNvbHV0ZSB0b3AtMC41IGxlZnQtMC41IHNpemUtNiByb3VuZGVkLWZ1bGwgYmctd2hpdGUgc2hhZG93LXNtIHRyYW5zaXRpb24tdHJhbnNmb3JtIGR1cmF0aW9uLTE1MFwiLFxuICAgICAgICAgIG9uID8gXCJ0cmFuc2xhdGUteC01XCIgOiBcInRyYW5zbGF0ZS14LTBcIixcbiAgICAgICAgKX1cbiAgICAgIC8+XG4gICAgPC9idXR0b24+XG4gICk7XG59XG4iXSwiZmlsZSI6IkQ6L0kySSBQcm9qZWN0IC0gSGFiaXRvL0FwcCBGb2xkZXIvaGFiaXRvL3NyYy9wYWdlcy9TZXR0aW5ncy50c3gifQ==