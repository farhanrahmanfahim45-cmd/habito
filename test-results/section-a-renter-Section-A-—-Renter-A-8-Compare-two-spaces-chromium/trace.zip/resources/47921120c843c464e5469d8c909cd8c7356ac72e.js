import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/onboarding/Onboarding.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=9ceb86a3"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("D:/I2I Project - Habito/App Folder/habito/src/components/onboarding/Onboarding.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9ceb86a3"; const useState = __vite__cjsImport3_react["useState"];
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=9ceb86a3";
import { ArrowRight, Home, Store, Compass, Check } from "/node_modules/.vite/deps/lucide-react.js?v=9ceb86a3";
import { useI18n } from "/src/i18n/index.tsx";
import { useHabito } from "/src/hooks/useHabito.tsx";
import { Button } from "/src/components/ui/Button.tsx";
import { AREAS } from "/src/data/areas.ts";
import { cn } from "/src/lib/cn.ts";
const SEEN_KEY = "habito.onboarded";
export function hasOnboarded() {
  try {
    return window.localStorage.getItem(SEEN_KEY) === "true";
  } catch {
    return true;
  }
}
function markOnboarded() {
  try {
    window.localStorage.setItem(SEEN_KEY, "true");
  } catch {
  }
}
export function Onboarding({ onDone }) {
  _s();
  const { t, language, setLanguage } = useI18n();
  const { requirements, setRequirements } = useHabito();
  const navigate = useNavigate();
  const [step, setStep] = useState(0);
  const [intent, setIntent] = useState(null);
  const finish = (area) => {
    markOnboarded();
    if (area) {
      setRequirements({ ...requirements, area });
    }
    onDone();
    if (intent === "listing") navigate("/list");
    else if (intent === "renting") navigate("/search");
  };
  const skip = () => {
    markOnboarded();
    onDone();
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 z-50 flex flex-col bg-ivory", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "container-page flex items-center justify-between py-5", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex gap-1.5", "aria-hidden": true, children: [0, 1, 2].map(
        (i) => /* @__PURE__ */ jsxDEV(
          "span",
          {
            className: cn(
              "h-1.5 rounded-full transition-all",
              i === step ? "w-6 bg-ink" : i < step ? "w-1.5 bg-ink" : "w-1.5 bg-hairline"
            )
          },
          i,
          false,
          {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/onboarding/Onboarding.tsx",
            lineNumber: 93,
            columnNumber: 11
          },
          this
        )
      ) }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/onboarding/Onboarding.tsx",
        lineNumber: 91,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          onClick: skip,
          className: "text-sm font-semibold text-muted transition-colors hover:text-ink",
          children: t("onboarding.skip")
        },
        void 0,
        false,
        {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/onboarding/Onboarding.tsx",
          lineNumber: 103,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/onboarding/Onboarding.tsx",
      lineNumber: 90,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "container-page flex flex-1 flex-col justify-center pb-16 sm:max-w-lg", children: [
      step === 0 && /* @__PURE__ */ jsxDEV(
        Step,
        {
          title: t("onboarding.languageTitle"),
          body: t("onboarding.languageBody"),
          children: /* @__PURE__ */ jsxDEV("div", { className: "grid gap-3", children: [
            { code: "en", label: "English", sample: "Find the space that fits." },
            { code: "bn", label: "বাংলা", sample: "আপনার উপযুক্ত জায়গা খুঁজে নিন।" }
          ].map(
            (option) => /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                lang: option.code,
                onClick: () => {
                  setLanguage(option.code);
                  setStep(1);
                },
                className: cn(
                  "flex items-center justify-between rounded-card p-5 text-left ring-1 transition-all",
                  language === option.code ? "bg-surface ring-2 ring-aqua-600" : "bg-surface ring-hairline hover:ring-hairline-strong"
                ),
                children: [
                  /* @__PURE__ */ jsxDEV("span", { children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "block font-display text-lg font-bold text-ink", children: option.label }, void 0, false, {
                      fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/onboarding/Onboarding.tsx",
                      lineNumber: 139,
                      columnNumber: 21
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "mt-0.5 block text-sm text-muted", children: option.sample }, void 0, false, {
                      fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/onboarding/Onboarding.tsx",
                      lineNumber: 140,
                      columnNumber: 21
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/onboarding/Onboarding.tsx",
                    lineNumber: 138,
                    columnNumber: 19
                  }, this),
                  language === option.code && /* @__PURE__ */ jsxDEV(Check, { size: 18, className: "shrink-0 text-aqua-600", "aria-hidden": true }, void 0, false, {
                    fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/onboarding/Onboarding.tsx",
                    lineNumber: 143,
                    columnNumber: 15
                  }, this)
                ]
              },
              option.code,
              true,
              {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/onboarding/Onboarding.tsx",
                lineNumber: 123,
                columnNumber: 13
              },
              this
            )
          ) }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/onboarding/Onboarding.tsx",
            lineNumber: 118,
            columnNumber: 13
          }, this)
        },
        void 0,
        false,
        {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/onboarding/Onboarding.tsx",
          lineNumber: 114,
          columnNumber: 9
        },
        this
      ),
      step === 1 && /* @__PURE__ */ jsxDEV(Step, { title: t("onboarding.intentTitle"), body: t("onboarding.intentBody"), children: [
        /* @__PURE__ */ jsxDEV("div", { className: "grid gap-3", children: [
          /* @__PURE__ */ jsxDEV(
            IntentCard,
            {
              icon: Home,
              title: t("onboarding.intentRenting"),
              body: t("onboarding.intentRentingBody"),
              onClick: () => {
                setIntent("renting");
                setStep(2);
              }
            },
            void 0,
            false,
            {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/onboarding/Onboarding.tsx",
              lineNumber: 154,
              columnNumber: 15
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            IntentCard,
            {
              icon: Store,
              title: t("onboarding.intentListing"),
              body: t("onboarding.intentListingBody"),
              onClick: () => {
                setIntent("listing");
                setStep(2);
              }
            },
            void 0,
            false,
            {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/onboarding/Onboarding.tsx",
              lineNumber: 163,
              columnNumber: 15
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            IntentCard,
            {
              icon: Compass,
              title: t("onboarding.intentLooking"),
              body: t("onboarding.intentLookingBody"),
              onClick: () => {
                setIntent("looking");
                finish();
              }
            },
            void 0,
            false,
            {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/onboarding/Onboarding.tsx",
              lineNumber: 172,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/onboarding/Onboarding.tsx",
          lineNumber: 153,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "mt-5 text-center text-xs leading-relaxed text-muted", children: t("onboarding.intentNote") }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/onboarding/Onboarding.tsx",
          lineNumber: 183,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/onboarding/Onboarding.tsx",
        lineNumber: 152,
        columnNumber: 9
      }, this),
      step === 2 && /* @__PURE__ */ jsxDEV(Step, { title: t("onboarding.areaTitle"), body: t("onboarding.areaBody"), children: [
        /* @__PURE__ */ jsxDEV("ul", { className: "grid max-h-80 grid-cols-2 gap-2 overflow-y-auto pb-2", children: AREAS.map(
          (area) => /* @__PURE__ */ jsxDEV("li", { children: /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: () => finish(area.name),
              className: "w-full rounded-2xl bg-surface p-3.5 text-left ring-1 ring-hairline transition-all hover:ring-ink",
              children: [
                /* @__PURE__ */ jsxDEV("span", { className: "block font-semibold text-ink", children: area.name }, void 0, false, {
                  fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/onboarding/Onboarding.tsx",
                  lineNumber: 199,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "block text-xs capitalize text-muted", children: area.geography }, void 0, false, {
                  fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/onboarding/Onboarding.tsx",
                  lineNumber: 200,
                  columnNumber: 21
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/onboarding/Onboarding.tsx",
              lineNumber: 194,
              columnNumber: 19
            },
            this
          ) }, area.id, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/onboarding/Onboarding.tsx",
            lineNumber: 193,
            columnNumber: 13
          }, this)
        ) }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/onboarding/Onboarding.tsx",
          lineNumber: 191,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(Button, { variant: "secondary", fullWidth: true, className: "mt-4", onClick: () => finish(), children: [
          t("onboarding.areaSkip"),
          /* @__PURE__ */ jsxDEV(ArrowRight, { size: 16, "aria-hidden": true }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/onboarding/Onboarding.tsx",
            lineNumber: 208,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/onboarding/Onboarding.tsx",
          lineNumber: 206,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/onboarding/Onboarding.tsx",
        lineNumber: 190,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/onboarding/Onboarding.tsx",
      lineNumber: 112,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/onboarding/Onboarding.tsx",
    lineNumber: 88,
    columnNumber: 5
  }, this);
}
_s(Onboarding, "8zIQjcyn8ggnw4qsYskpT0tNJ6U=", false, function() {
  return [useI18n, useHabito, useNavigate];
});
_c = Onboarding;
function Step({ title, body, children }) {
  return /* @__PURE__ */ jsxDEV("div", { className: "rise", children: [
    /* @__PURE__ */ jsxDEV("h1", { className: "font-display text-3xl font-extrabold leading-tight text-ink sm:text-4xl", children: title }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/onboarding/Onboarding.tsx",
      lineNumber: 220,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("p", { className: "mt-2.5 text-base leading-relaxed text-ink-soft", children: body }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/onboarding/Onboarding.tsx",
      lineNumber: 221,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "mt-8", children }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/onboarding/Onboarding.tsx",
      lineNumber: 222,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/onboarding/Onboarding.tsx",
    lineNumber: 219,
    columnNumber: 5
  }, this);
}
_c2 = Step;
function IntentCard({
  icon: Icon,
  title,
  body,
  onClick
}) {
  return /* @__PURE__ */ jsxDEV(
    "button",
    {
      type: "button",
      onClick,
      className: "flex items-start gap-4 rounded-card bg-surface p-5 text-left ring-1 ring-hairline transition-all hover:-translate-y-0.5 hover:ring-ink",
      children: [
        /* @__PURE__ */ jsxDEV("span", { className: "flex size-10 shrink-0 items-center justify-center rounded-xl bg-aqua-100 text-aqua-700", children: /* @__PURE__ */ jsxDEV(Icon, { size: 19, "aria-hidden": true }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/onboarding/Onboarding.tsx",
          lineNumber: 245,
          columnNumber: 9
        }, this) }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/onboarding/Onboarding.tsx",
          lineNumber: 244,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "min-w-0", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "block font-display font-bold text-ink", children: title }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/onboarding/Onboarding.tsx",
            lineNumber: 248,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "mt-0.5 block text-sm leading-snug text-muted", children: body }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/onboarding/Onboarding.tsx",
            lineNumber: 249,
            columnNumber: 9
          }, this)
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/onboarding/Onboarding.tsx",
          lineNumber: 247,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV(ArrowRight, { size: 17, className: "ml-auto mt-2.5 shrink-0 text-muted", "aria-hidden": true }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/onboarding/Onboarding.tsx",
          lineNumber: 251,
          columnNumber: 7
        }, this)
      ]
    },
    void 0,
    true,
    {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/onboarding/Onboarding.tsx",
      lineNumber: 239,
      columnNumber: 5
    },
    this
  );
}
_c3 = IntentCard;
var _c, _c2, _c3;
$RefreshReg$(_c, "Onboarding");
$RefreshReg$(_c2, "Step");
$RefreshReg$(_c3, "IntentCard");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/I2I Project - Habito/App Folder/habito/src/components/onboarding/Onboarding.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/I2I Project - Habito/App Folder/habito/src/components/onboarding/Onboarding.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBeUVZOzs7Ozs7Ozs7Ozs7Ozs7OztBQXpFWixTQUFTQSxnQkFBZ0I7QUFDekIsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLFlBQVlDLE1BQU1DLE9BQU9DLFNBQVNDLGFBQWE7QUFDeEQsU0FBU0MsZUFBZTtBQUN4QixTQUFTQyxpQkFBaUI7QUFDMUIsU0FBU0MsY0FBYztBQUN2QixTQUFTQyxhQUFhO0FBQ3RCLFNBQVNDLFVBQVU7QUFHbkIsTUFBTUMsV0FBVztBQUlWLGdCQUFTQyxlQUF3QjtBQUN0QyxNQUFJO0FBQ0YsV0FBT0MsT0FBT0MsYUFBYUMsUUFBUUosUUFBUSxNQUFNO0FBQUEsRUFDbkQsUUFBUTtBQUNOLFdBQU87QUFBQSxFQUNUO0FBQ0Y7QUFFQSxTQUFTSyxnQkFBZ0I7QUFDdkIsTUFBSTtBQUNGSCxXQUFPQyxhQUFhRyxRQUFRTixVQUFVLE1BQU07QUFBQSxFQUM5QyxRQUFRO0FBQUEsRUFDTjtBQUVKO0FBV08sZ0JBQVNPLFdBQVcsRUFBRUMsT0FBK0IsR0FBRztBQUFBQyxLQUFBO0FBQzdELFFBQU0sRUFBRUMsR0FBR0MsVUFBVUMsWUFBWSxJQUFJakIsUUFBUTtBQUM3QyxRQUFNLEVBQUVrQixjQUFjQyxnQkFBZ0IsSUFBSWxCLFVBQVU7QUFDcEQsUUFBTW1CLFdBQVcxQixZQUFZO0FBRTdCLFFBQU0sQ0FBQzJCLE1BQU1DLE9BQU8sSUFBSTdCLFNBQVMsQ0FBQztBQUNsQyxRQUFNLENBQUM4QixRQUFRQyxTQUFTLElBQUkvQixTQUF3QixJQUFJO0FBRXhELFFBQU1nQyxTQUFTQSxDQUFDQyxTQUFrQjtBQUNoQ2hCLGtCQUFjO0FBRWQsUUFBSWdCLE1BQU07QUFDUlAsc0JBQWdCLEVBQUUsR0FBR0QsY0FBY1EsS0FBSyxDQUFDO0FBQUEsSUFDM0M7QUFFQWIsV0FBTztBQUlQLFFBQUlVLFdBQVcsVUFBV0gsVUFBUyxPQUFPO0FBQUEsYUFDakNHLFdBQVcsVUFBV0gsVUFBUyxTQUFTO0FBQUEsRUFDbkQ7QUFFQSxRQUFNTyxPQUFPQSxNQUFNO0FBQ2pCakIsa0JBQWM7QUFDZEcsV0FBTztBQUFBLEVBQ1Q7QUFFQSxTQUNFLHVCQUFDLFNBQUksV0FBVSw2Q0FFYjtBQUFBLDJCQUFDLFNBQUksV0FBVSx5REFDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSxnQkFBZSxlQUFXLE1BQ3RDLFdBQUMsR0FBRyxHQUFHLENBQUMsRUFBRWU7QUFBQUEsUUFBSSxDQUFDQyxNQUNkO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFFQyxXQUFXekI7QUFBQUEsY0FDVDtBQUFBLGNBQ0F5QixNQUFNUixPQUFPLGVBQWVRLElBQUlSLE9BQU8saUJBQWlCO0FBQUEsWUFDMUQ7QUFBQTtBQUFBLFVBSktRO0FBQUFBLFVBRFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUtJO0FBQUEsTUFFTCxLQVRIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFVQTtBQUFBLE1BRUE7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE1BQUs7QUFBQSxVQUNMLFNBQVNGO0FBQUFBLFVBQ1QsV0FBVTtBQUFBLFVBRVRaLFlBQUUsaUJBQWlCO0FBQUE7QUFBQSxRQUx0QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFNQTtBQUFBLFNBbkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FvQkE7QUFBQSxJQUVBLHVCQUFDLFNBQUksV0FBVSx3RUFDWk07QUFBQUEsZUFBUyxLQUNSO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxPQUFPTixFQUFFLDBCQUEwQjtBQUFBLFVBQ25DLE1BQU1BLEVBQUUseUJBQXlCO0FBQUEsVUFFakMsaUNBQUMsU0FBSSxXQUFVLGNBQ1g7QUFBQSxZQUNBLEVBQUVlLE1BQU0sTUFBa0JDLE9BQU8sV0FBV0MsUUFBUSw0QkFBNEI7QUFBQSxZQUNoRixFQUFFRixNQUFNLE1BQWtCQyxPQUFPLFNBQVNDLFFBQVEsa0NBQWtDO0FBQUEsVUFBQyxFQUNwRko7QUFBQUEsWUFBSSxDQUFDSyxXQUNOO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBRUMsTUFBSztBQUFBLGdCQUNMLE1BQU1BLE9BQU9IO0FBQUFBLGdCQUNiLFNBQVMsTUFBTTtBQUNiYiw4QkFBWWdCLE9BQU9ILElBQUk7QUFDdkJSLDBCQUFRLENBQUM7QUFBQSxnQkFDWDtBQUFBLGdCQUNBLFdBQVdsQjtBQUFBQSxrQkFDVDtBQUFBLGtCQUNBWSxhQUFhaUIsT0FBT0gsT0FDaEIsb0NBQ0E7QUFBQSxnQkFDTjtBQUFBLGdCQUVBO0FBQUEseUNBQUMsVUFDQztBQUFBLDJDQUFDLFVBQUssV0FBVSxpREFBaURHLGlCQUFPRixTQUF4RTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUE4RTtBQUFBLG9CQUM5RSx1QkFBQyxVQUFLLFdBQVUsbUNBQW1DRSxpQkFBT0QsVUFBMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBaUU7QUFBQSx1QkFGbkU7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFHQTtBQUFBLGtCQUNDaEIsYUFBYWlCLE9BQU9ILFFBQ25CLHVCQUFDLFNBQU0sTUFBTSxJQUFJLFdBQVUsMEJBQXlCLGVBQVcsUUFBL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBK0Q7QUFBQTtBQUFBO0FBQUEsY0FuQjVERyxPQUFPSDtBQUFBQSxjQURkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFzQkE7QUFBQSxVQUNELEtBNUJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBNkJBO0FBQUE7QUFBQSxRQWpDRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFrQ0E7QUFBQSxNQUdEVCxTQUFTLEtBQ1IsdUJBQUMsUUFBSyxPQUFPTixFQUFFLHdCQUF3QixHQUFHLE1BQU1BLEVBQUUsdUJBQXVCLEdBQ3ZFO0FBQUEsK0JBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBTW5CO0FBQUFBLGNBQ04sT0FBT21CLEVBQUUsMEJBQTBCO0FBQUEsY0FDbkMsTUFBTUEsRUFBRSw4QkFBOEI7QUFBQSxjQUN0QyxTQUFTLE1BQU07QUFDYlMsMEJBQVUsU0FBUztBQUNuQkYsd0JBQVEsQ0FBQztBQUFBLGNBQ1g7QUFBQTtBQUFBLFlBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBT0k7QUFBQSxVQUVKO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFNekI7QUFBQUEsY0FDTixPQUFPa0IsRUFBRSwwQkFBMEI7QUFBQSxjQUNuQyxNQUFNQSxFQUFFLDhCQUE4QjtBQUFBLGNBQ3RDLFNBQVMsTUFBTTtBQUNiUywwQkFBVSxTQUFTO0FBQ25CRix3QkFBUSxDQUFDO0FBQUEsY0FDWDtBQUFBO0FBQUEsWUFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFPSTtBQUFBLFVBRUo7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQU14QjtBQUFBQSxjQUNOLE9BQU9pQixFQUFFLDBCQUEwQjtBQUFBLGNBQ25DLE1BQU1BLEVBQUUsOEJBQThCO0FBQUEsY0FDdEMsU0FBUyxNQUFNO0FBQ2JTLDBCQUFVLFNBQVM7QUFDbkJDLHVCQUFPO0FBQUEsY0FDVDtBQUFBO0FBQUEsWUFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFPSTtBQUFBLGFBMUJOO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUE0QkE7QUFBQSxRQUVBLHVCQUFDLE9BQUUsV0FBVSx1REFDVlYsWUFBRSx1QkFBdUIsS0FENUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FqQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWtDQTtBQUFBLE1BR0RNLFNBQVMsS0FDUix1QkFBQyxRQUFLLE9BQU9OLEVBQUUsc0JBQXNCLEdBQUcsTUFBTUEsRUFBRSxxQkFBcUIsR0FDbkU7QUFBQSwrQkFBQyxRQUFHLFdBQVUsd0RBQ1haLGdCQUFNeUI7QUFBQUEsVUFBSSxDQUFDRixTQUNWLHVCQUFDLFFBQ0M7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLFNBQVMsTUFBTUQsT0FBT0MsS0FBS1EsSUFBSTtBQUFBLGNBQy9CLFdBQVU7QUFBQSxjQUVWO0FBQUEsdUNBQUMsVUFBSyxXQUFVLGdDQUFnQ1IsZUFBS1EsUUFBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBMEQ7QUFBQSxnQkFDMUQsdUJBQUMsVUFBSyxXQUFVLHVDQUF1Q1IsZUFBS1MsYUFBNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBc0U7QUFBQTtBQUFBO0FBQUEsWUFOeEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBT0EsS0FST1QsS0FBS1UsSUFBZDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVNBO0FBQUEsUUFDRCxLQVpIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFhQTtBQUFBLFFBRUEsdUJBQUMsVUFBTyxTQUFRLGFBQVksV0FBUyxNQUFDLFdBQVUsUUFBTyxTQUFTLE1BQU1YLE9BQU8sR0FDMUVWO0FBQUFBLFlBQUUscUJBQXFCO0FBQUEsVUFDeEIsdUJBQUMsY0FBVyxNQUFNLElBQUksZUFBVyxRQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFpQztBQUFBLGFBRm5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFdBbkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFvQkE7QUFBQSxTQWxHSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBb0dBO0FBQUEsT0E1SEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTZIQTtBQUVKO0FBQUNELEdBNUplRixZQUFVO0FBQUEsVUFDYVosU0FDS0MsV0FDekJQLFdBQVc7QUFBQTtBQUFBLEtBSGRrQjtBQThKaEIsU0FBU3lCLEtBQUssRUFBRUMsT0FBT0MsTUFBTUMsU0FBcUUsR0FBRztBQUNuRyxTQUNFLHVCQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEsMkJBQUMsUUFBRyxXQUFVLDJFQUEyRUYsbUJBQXpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBK0Y7QUFBQSxJQUMvRix1QkFBQyxPQUFFLFdBQVUsa0RBQWtEQyxrQkFBL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFvRTtBQUFBLElBQ3BFLHVCQUFDLFNBQUksV0FBVSxRQUFRQyxZQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWdDO0FBQUEsT0FIbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUlBO0FBRUo7QUFBQ0MsTUFSUUo7QUFVVCxTQUFTSyxXQUFXO0FBQUEsRUFDbEJDLE1BQU1DO0FBQUFBLEVBQ05OO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FNO0FBTUYsR0FBRztBQUNELFNBQ0U7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNDLE1BQUs7QUFBQSxNQUNMO0FBQUEsTUFDQSxXQUFVO0FBQUEsTUFFVjtBQUFBLCtCQUFDLFVBQUssV0FBVSwwRkFDZCxpQ0FBQyxRQUFLLE1BQU0sSUFBSSxlQUFXLFFBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMkIsS0FEN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxVQUFLLFdBQVUsV0FDZDtBQUFBLGlDQUFDLFVBQUssV0FBVSx5Q0FBeUNQLG1CQUF6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUErRDtBQUFBLFVBQy9ELHVCQUFDLFVBQUssV0FBVSxnREFBZ0RDLGtCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFxRTtBQUFBLGFBRnZFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBQ0EsdUJBQUMsY0FBVyxNQUFNLElBQUksV0FBVSxzQ0FBcUMsZUFBVyxRQUFoRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWdGO0FBQUE7QUFBQTtBQUFBLElBWmxGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQWFBO0FBRUo7QUFBQ08sTUEzQlFKO0FBQVUsSUFBQUssSUFBQU4sS0FBQUs7QUFBQSxhQUFBQyxJQUFBO0FBQUEsYUFBQU4sS0FBQTtBQUFBLGFBQUFLLEtBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsInVzZU5hdmlnYXRlIiwiQXJyb3dSaWdodCIsIkhvbWUiLCJTdG9yZSIsIkNvbXBhc3MiLCJDaGVjayIsInVzZUkxOG4iLCJ1c2VIYWJpdG8iLCJCdXR0b24iLCJBUkVBUyIsImNuIiwiU0VFTl9LRVkiLCJoYXNPbmJvYXJkZWQiLCJ3aW5kb3ciLCJsb2NhbFN0b3JhZ2UiLCJnZXRJdGVtIiwibWFya09uYm9hcmRlZCIsInNldEl0ZW0iLCJPbmJvYXJkaW5nIiwib25Eb25lIiwiX3MiLCJ0IiwibGFuZ3VhZ2UiLCJzZXRMYW5ndWFnZSIsInJlcXVpcmVtZW50cyIsInNldFJlcXVpcmVtZW50cyIsIm5hdmlnYXRlIiwic3RlcCIsInNldFN0ZXAiLCJpbnRlbnQiLCJzZXRJbnRlbnQiLCJmaW5pc2giLCJhcmVhIiwic2tpcCIsIm1hcCIsImkiLCJjb2RlIiwibGFiZWwiLCJzYW1wbGUiLCJvcHRpb24iLCJuYW1lIiwiZ2VvZ3JhcGh5IiwiaWQiLCJTdGVwIiwidGl0bGUiLCJib2R5IiwiY2hpbGRyZW4iLCJfYzIiLCJJbnRlbnRDYXJkIiwiaWNvbiIsIkljb24iLCJvbkNsaWNrIiwiX2MzIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiT25ib2FyZGluZy50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IHVzZU5hdmlnYXRlIH0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIjtcbmltcG9ydCB7IEFycm93UmlnaHQsIEhvbWUsIFN0b3JlLCBDb21wYXNzLCBDaGVjayB9IGZyb20gXCJsdWNpZGUtcmVhY3RcIjtcbmltcG9ydCB7IHVzZUkxOG4gfSBmcm9tIFwiQC9pMThuXCI7XG5pbXBvcnQgeyB1c2VIYWJpdG8gfSBmcm9tIFwiQC9ob29rcy91c2VIYWJpdG9cIjtcbmltcG9ydCB7IEJ1dHRvbiB9IGZyb20gXCJAL2NvbXBvbmVudHMvdWkvQnV0dG9uXCI7XG5pbXBvcnQgeyBBUkVBUyB9IGZyb20gXCJAL2RhdGEvYXJlYXNcIjtcbmltcG9ydCB7IGNuIH0gZnJvbSBcIkAvbGliL2NuXCI7XG5pbXBvcnQgdHlwZSB7IExhbmd1YWdlIH0gZnJvbSBcIkAvaTE4blwiO1xuXG5jb25zdCBTRUVOX0tFWSA9IFwiaGFiaXRvLm9uYm9hcmRlZFwiO1xuXG5leHBvcnQgdHlwZSBJbnRlbnQgPSBcInJlbnRpbmdcIiB8IFwibGlzdGluZ1wiIHwgXCJsb29raW5nXCI7XG5cbmV4cG9ydCBmdW5jdGlvbiBoYXNPbmJvYXJkZWQoKTogYm9vbGVhbiB7XG4gIHRyeSB7XG4gICAgcmV0dXJuIHdpbmRvdy5sb2NhbFN0b3JhZ2UuZ2V0SXRlbShTRUVOX0tFWSkgPT09IFwidHJ1ZVwiO1xuICB9IGNhdGNoIHtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxufVxuXG5mdW5jdGlvbiBtYXJrT25ib2FyZGVkKCkge1xuICB0cnkge1xuICAgIHdpbmRvdy5sb2NhbFN0b3JhZ2Uuc2V0SXRlbShTRUVOX0tFWSwgXCJ0cnVlXCIpO1xuICB9IGNhdGNoIHtcbiAgICAvLyBQcml2YXRlIG1vZGUuIFRoZXknbGwgc2VlIGl0IGFnYWluLCB3aGljaCBpcyBzdXJ2aXZhYmxlLlxuICB9XG59XG5cbi8qKlxuICogRmlyc3QgcnVuLlxuICpcbiAqIFRocmVlIHF1ZXN0aW9ucywgZWFjaCBza2lwcGFibGUsIHRoZW4gc3RyYWlnaHQgaW50byByZXN1bHRzIOKAlCBub3QgYSB0dXRvcmlhbC5cbiAqIEhhYml0bydzIHVzZXJzIGFyZSBvZnRlbiBtZWV0aW5nIGEgcHJvZHVjdCBsaWtlIHRoaXMgZm9yIHRoZSBmaXJzdCB0aW1lLCBhbmRcbiAqIHBlb3BsZSB3aG8gYXJlIHVuc3VyZSBvZiB0aGVtc2VsdmVzIHRhcCB0aHJvdWdoIHdhbGt0aHJvdWdocyB3aXRob3V0IHJlYWRpbmdcbiAqIGFuZCBhcnJpdmUgbW9yZSBjb25mdXNlZCB0aGFuIHRoZXkgc3RhcnRlZC4gU2hvcnQgYmVhdHMgdGhvcm91Z2gsIGFuZCB0aGVcbiAqIHJlYWwgZXhwbGFpbmluZyBoYXBwZW5zIGluIGNvbnRleHQgbGF0ZXIuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBPbmJvYXJkaW5nKHsgb25Eb25lIH06IHsgb25Eb25lOiAoKSA9PiB2b2lkIH0pIHtcbiAgY29uc3QgeyB0LCBsYW5ndWFnZSwgc2V0TGFuZ3VhZ2UgfSA9IHVzZUkxOG4oKTtcbiAgY29uc3QgeyByZXF1aXJlbWVudHMsIHNldFJlcXVpcmVtZW50cyB9ID0gdXNlSGFiaXRvKCk7XG4gIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcblxuICBjb25zdCBbc3RlcCwgc2V0U3RlcF0gPSB1c2VTdGF0ZSgwKTtcbiAgY29uc3QgW2ludGVudCwgc2V0SW50ZW50XSA9IHVzZVN0YXRlPEludGVudCB8IG51bGw+KG51bGwpO1xuXG4gIGNvbnN0IGZpbmlzaCA9IChhcmVhPzogc3RyaW5nKSA9PiB7XG4gICAgbWFya09uYm9hcmRlZCgpO1xuXG4gICAgaWYgKGFyZWEpIHtcbiAgICAgIHNldFJlcXVpcmVtZW50cyh7IC4uLnJlcXVpcmVtZW50cywgYXJlYSB9KTtcbiAgICB9XG5cbiAgICBvbkRvbmUoKTtcblxuICAgIC8vIExhbmQgdGhlbSB3aGVyZSB0aGVpciBhbnN3ZXIgcG9pbnRlZCwgcmF0aGVyIHRoYW4gYmFjayBhdCBhIGhvbWVwYWdlXG4gICAgLy8gdGhleSBoYXZlIGFscmVhZHkgcmVhZC5cbiAgICBpZiAoaW50ZW50ID09PSBcImxpc3RpbmdcIikgbmF2aWdhdGUoXCIvbGlzdFwiKTtcbiAgICBlbHNlIGlmIChpbnRlbnQgPT09IFwicmVudGluZ1wiKSBuYXZpZ2F0ZShcIi9zZWFyY2hcIik7XG4gIH07XG5cbiAgY29uc3Qgc2tpcCA9ICgpID0+IHtcbiAgICBtYXJrT25ib2FyZGVkKCk7XG4gICAgb25Eb25lKCk7XG4gIH07XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgei01MCBmbGV4IGZsZXgtY29sIGJnLWl2b3J5XCI+XG4gICAgICB7LyogUHJvZ3Jlc3Mg4oCUIHRocmVlIGRvdHMsIHNvIHRoZSBlbmQgaXMgdmlzaWJsZSBmcm9tIHRoZSBzdGFydCAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29udGFpbmVyLXBhZ2UgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHB5LTVcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC0xLjVcIiBhcmlhLWhpZGRlbj5cbiAgICAgICAgICB7WzAsIDEsIDJdLm1hcCgoaSkgPT4gKFxuICAgICAgICAgICAgPHNwYW5cbiAgICAgICAgICAgICAga2V5PXtpfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgICAgICAgICAgIFwiaC0xLjUgcm91bmRlZC1mdWxsIHRyYW5zaXRpb24tYWxsXCIsXG4gICAgICAgICAgICAgICAgaSA9PT0gc3RlcCA/IFwidy02IGJnLWlua1wiIDogaSA8IHN0ZXAgPyBcInctMS41IGJnLWlua1wiIDogXCJ3LTEuNSBiZy1oYWlybGluZVwiLFxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgLz5cbiAgICAgICAgICApKX1cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPGJ1dHRvblxuICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgIG9uQ2xpY2s9e3NraXB9XG4gICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtbXV0ZWQgdHJhbnNpdGlvbi1jb2xvcnMgaG92ZXI6dGV4dC1pbmtcIlxuICAgICAgICA+XG4gICAgICAgICAge3QoXCJvbmJvYXJkaW5nLnNraXBcIil9XG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgPC9kaXY+XG5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29udGFpbmVyLXBhZ2UgZmxleCBmbGV4LTEgZmxleC1jb2wganVzdGlmeS1jZW50ZXIgcGItMTYgc206bWF4LXctbGdcIj5cbiAgICAgICAge3N0ZXAgPT09IDAgJiYgKFxuICAgICAgICAgIDxTdGVwXG4gICAgICAgICAgICB0aXRsZT17dChcIm9uYm9hcmRpbmcubGFuZ3VhZ2VUaXRsZVwiKX1cbiAgICAgICAgICAgIGJvZHk9e3QoXCJvbmJvYXJkaW5nLmxhbmd1YWdlQm9keVwiKX1cbiAgICAgICAgICA+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ2FwLTNcIj5cbiAgICAgICAgICAgICAgeyhbXG4gICAgICAgICAgICAgICAgeyBjb2RlOiBcImVuXCIgYXMgTGFuZ3VhZ2UsIGxhYmVsOiBcIkVuZ2xpc2hcIiwgc2FtcGxlOiBcIkZpbmQgdGhlIHNwYWNlIHRoYXQgZml0cy5cIiB9LFxuICAgICAgICAgICAgICAgIHsgY29kZTogXCJiblwiIGFzIExhbmd1YWdlLCBsYWJlbDogXCLgpqzgpr7gpoLgprLgpr5cIiwgc2FtcGxlOiBcIuCmhuCmquCmqOCmvuCmsCDgpongpqrgpq/gp4HgppXgp43gpqQg4Kac4Ka+4Kav4Ka84KaX4Ka+IOCmluCngeCmgeCmnOCnhyDgpqjgpr/gpqjgpaRcIiB9LFxuICAgICAgICAgICAgICBdKS5tYXAoKG9wdGlvbikgPT4gKFxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIGtleT17b3B0aW9uLmNvZGV9XG4gICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgIGxhbmc9e29wdGlvbi5jb2RlfVxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICBzZXRMYW5ndWFnZShvcHRpb24uY29kZSk7XG4gICAgICAgICAgICAgICAgICAgIHNldFN0ZXAoMSk7XG4gICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgICAgICAgICAgICAgXCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcm91bmRlZC1jYXJkIHAtNSB0ZXh0LWxlZnQgcmluZy0xIHRyYW5zaXRpb24tYWxsXCIsXG4gICAgICAgICAgICAgICAgICAgIGxhbmd1YWdlID09PSBvcHRpb24uY29kZVxuICAgICAgICAgICAgICAgICAgICAgID8gXCJiZy1zdXJmYWNlIHJpbmctMiByaW5nLWFxdWEtNjAwXCJcbiAgICAgICAgICAgICAgICAgICAgICA6IFwiYmctc3VyZmFjZSByaW5nLWhhaXJsaW5lIGhvdmVyOnJpbmctaGFpcmxpbmUtc3Ryb25nXCIsXG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxzcGFuPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJibG9jayBmb250LWRpc3BsYXkgdGV4dC1sZyBmb250LWJvbGQgdGV4dC1pbmtcIj57b3B0aW9uLmxhYmVsfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibXQtMC41IGJsb2NrIHRleHQtc20gdGV4dC1tdXRlZFwiPntvcHRpb24uc2FtcGxlfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIHtsYW5ndWFnZSA9PT0gb3B0aW9uLmNvZGUgJiYgKFxuICAgICAgICAgICAgICAgICAgICA8Q2hlY2sgc2l6ZT17MTh9IGNsYXNzTmFtZT1cInNocmluay0wIHRleHQtYXF1YS02MDBcIiBhcmlhLWhpZGRlbiAvPlxuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L1N0ZXA+XG4gICAgICAgICl9XG5cbiAgICAgICAge3N0ZXAgPT09IDEgJiYgKFxuICAgICAgICAgIDxTdGVwIHRpdGxlPXt0KFwib25ib2FyZGluZy5pbnRlbnRUaXRsZVwiKX0gYm9keT17dChcIm9uYm9hcmRpbmcuaW50ZW50Qm9keVwiKX0+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ2FwLTNcIj5cbiAgICAgICAgICAgICAgPEludGVudENhcmRcbiAgICAgICAgICAgICAgICBpY29uPXtIb21lfVxuICAgICAgICAgICAgICAgIHRpdGxlPXt0KFwib25ib2FyZGluZy5pbnRlbnRSZW50aW5nXCIpfVxuICAgICAgICAgICAgICAgIGJvZHk9e3QoXCJvbmJvYXJkaW5nLmludGVudFJlbnRpbmdCb2R5XCIpfVxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgICAgIHNldEludGVudChcInJlbnRpbmdcIik7XG4gICAgICAgICAgICAgICAgICBzZXRTdGVwKDIpO1xuICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDxJbnRlbnRDYXJkXG4gICAgICAgICAgICAgICAgaWNvbj17U3RvcmV9XG4gICAgICAgICAgICAgICAgdGl0bGU9e3QoXCJvbmJvYXJkaW5nLmludGVudExpc3RpbmdcIil9XG4gICAgICAgICAgICAgICAgYm9keT17dChcIm9uYm9hcmRpbmcuaW50ZW50TGlzdGluZ0JvZHlcIil9XG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgc2V0SW50ZW50KFwibGlzdGluZ1wiKTtcbiAgICAgICAgICAgICAgICAgIHNldFN0ZXAoMik7XG4gICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPEludGVudENhcmRcbiAgICAgICAgICAgICAgICBpY29uPXtDb21wYXNzfVxuICAgICAgICAgICAgICAgIHRpdGxlPXt0KFwib25ib2FyZGluZy5pbnRlbnRMb29raW5nXCIpfVxuICAgICAgICAgICAgICAgIGJvZHk9e3QoXCJvbmJvYXJkaW5nLmludGVudExvb2tpbmdCb2R5XCIpfVxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgICAgIHNldEludGVudChcImxvb2tpbmdcIik7XG4gICAgICAgICAgICAgICAgICBmaW5pc2goKTtcbiAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTUgdGV4dC1jZW50ZXIgdGV4dC14cyBsZWFkaW5nLXJlbGF4ZWQgdGV4dC1tdXRlZFwiPlxuICAgICAgICAgICAgICB7dChcIm9uYm9hcmRpbmcuaW50ZW50Tm90ZVwiKX1cbiAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICA8L1N0ZXA+XG4gICAgICAgICl9XG5cbiAgICAgICAge3N0ZXAgPT09IDIgJiYgKFxuICAgICAgICAgIDxTdGVwIHRpdGxlPXt0KFwib25ib2FyZGluZy5hcmVhVGl0bGVcIil9IGJvZHk9e3QoXCJvbmJvYXJkaW5nLmFyZWFCb2R5XCIpfT5cbiAgICAgICAgICAgIDx1bCBjbGFzc05hbWU9XCJncmlkIG1heC1oLTgwIGdyaWQtY29scy0yIGdhcC0yIG92ZXJmbG93LXktYXV0byBwYi0yXCI+XG4gICAgICAgICAgICAgIHtBUkVBUy5tYXAoKGFyZWEpID0+IChcbiAgICAgICAgICAgICAgICA8bGkga2V5PXthcmVhLmlkfT5cbiAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGZpbmlzaChhcmVhLm5hbWUpfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcm91bmRlZC0yeGwgYmctc3VyZmFjZSBwLTMuNSB0ZXh0LWxlZnQgcmluZy0xIHJpbmctaGFpcmxpbmUgdHJhbnNpdGlvbi1hbGwgaG92ZXI6cmluZy1pbmtcIlxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJibG9jayBmb250LXNlbWlib2xkIHRleHQtaW5rXCI+e2FyZWEubmFtZX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgY2FwaXRhbGl6ZSB0ZXh0LW11dGVkXCI+e2FyZWEuZ2VvZ3JhcGh5fTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDwvbGk+XG4gICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgPC91bD5cblxuICAgICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwic2Vjb25kYXJ5XCIgZnVsbFdpZHRoIGNsYXNzTmFtZT1cIm10LTRcIiBvbkNsaWNrPXsoKSA9PiBmaW5pc2goKX0+XG4gICAgICAgICAgICAgIHt0KFwib25ib2FyZGluZy5hcmVhU2tpcFwiKX1cbiAgICAgICAgICAgICAgPEFycm93UmlnaHQgc2l6ZT17MTZ9IGFyaWEtaGlkZGVuIC8+XG4gICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICA8L1N0ZXA+XG4gICAgICAgICl9XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cblxuZnVuY3Rpb24gU3RlcCh7IHRpdGxlLCBib2R5LCBjaGlsZHJlbiB9OiB7IHRpdGxlOiBzdHJpbmc7IGJvZHk6IHN0cmluZzsgY2hpbGRyZW46IFJlYWN0LlJlYWN0Tm9kZSB9KSB7XG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJyaXNlXCI+XG4gICAgICA8aDEgY2xhc3NOYW1lPVwiZm9udC1kaXNwbGF5IHRleHQtM3hsIGZvbnQtZXh0cmFib2xkIGxlYWRpbmctdGlnaHQgdGV4dC1pbmsgc206dGV4dC00eGxcIj57dGl0bGV9PC9oMT5cbiAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIuNSB0ZXh0LWJhc2UgbGVhZGluZy1yZWxheGVkIHRleHQtaW5rLXNvZnRcIj57Ym9keX08L3A+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LThcIj57Y2hpbGRyZW59PC9kaXY+XG4gICAgPC9kaXY+XG4gICk7XG59XG5cbmZ1bmN0aW9uIEludGVudENhcmQoe1xuICBpY29uOiBJY29uLFxuICB0aXRsZSxcbiAgYm9keSxcbiAgb25DbGljayxcbn06IHtcbiAgaWNvbjogdHlwZW9mIEhvbWU7XG4gIHRpdGxlOiBzdHJpbmc7XG4gIGJvZHk6IHN0cmluZztcbiAgb25DbGljazogKCkgPT4gdm9pZDtcbn0pIHtcbiAgcmV0dXJuIChcbiAgICA8YnV0dG9uXG4gICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgIG9uQ2xpY2s9e29uQ2xpY2t9XG4gICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLXN0YXJ0IGdhcC00IHJvdW5kZWQtY2FyZCBiZy1zdXJmYWNlIHAtNSB0ZXh0LWxlZnQgcmluZy0xIHJpbmctaGFpcmxpbmUgdHJhbnNpdGlvbi1hbGwgaG92ZXI6LXRyYW5zbGF0ZS15LTAuNSBob3ZlcjpyaW5nLWlua1wiXG4gICAgPlxuICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZmxleCBzaXplLTEwIHNocmluay0wIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciByb3VuZGVkLXhsIGJnLWFxdWEtMTAwIHRleHQtYXF1YS03MDBcIj5cbiAgICAgICAgPEljb24gc2l6ZT17MTl9IGFyaWEtaGlkZGVuIC8+XG4gICAgICA8L3NwYW4+XG4gICAgICA8c3BhbiBjbGFzc05hbWU9XCJtaW4tdy0wXCI+XG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImJsb2NrIGZvbnQtZGlzcGxheSBmb250LWJvbGQgdGV4dC1pbmtcIj57dGl0bGV9PC9zcGFuPlxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtdC0wLjUgYmxvY2sgdGV4dC1zbSBsZWFkaW5nLXNudWcgdGV4dC1tdXRlZFwiPntib2R5fTwvc3Bhbj5cbiAgICAgIDwvc3Bhbj5cbiAgICAgIDxBcnJvd1JpZ2h0IHNpemU9ezE3fSBjbGFzc05hbWU9XCJtbC1hdXRvIG10LTIuNSBzaHJpbmstMCB0ZXh0LW11dGVkXCIgYXJpYS1oaWRkZW4gLz5cbiAgICA8L2J1dHRvbj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiRDovSTJJIFByb2plY3QgLSBIYWJpdG8vQXBwIEZvbGRlci9oYWJpdG8vc3JjL2NvbXBvbmVudHMvb25ib2FyZGluZy9PbmJvYXJkaW5nLnRzeCJ9