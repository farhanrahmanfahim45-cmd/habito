import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/SpaceDetail.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=9ceb86a3"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$(), _s3 = $RefreshSig$(), _s4 = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9ceb86a3"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useMemo = __vite__cjsImport3_react["useMemo"]; const useState = __vite__cjsImport3_react["useState"];
import { Link, useNavigate, useParams } from "/node_modules/.vite/deps/react-router-dom.js?v=9ceb86a3";
import { ArrowLeft, Bookmark, Scale, MapPin, Check, Minus, X, Building2, Flag, ChevronRight, Pencil, CalendarCheck, Clock } from "/node_modules/.vite/deps/lucide-react.js?v=9ceb86a3";
import { useHabito } from "/src/hooks/useHabito.tsx";
import { db } from "/src/lib/api/index.ts";
import { useAuth } from "/src/hooks/useAuth.tsx";
import { Button } from "/src/components/ui/Button.tsx";
import { Modal } from "/src/components/ui/Modal.tsx";
import { Coachmark } from "/src/components/ui/Coachmark.tsx";
import { SpacePhoto } from "/src/components/space/SpacePhoto.tsx";
import { MatchRing } from "/src/components/space/MatchRing.tsx";
import { TrustBadge, AvailabilityBadge } from "/src/components/space/badges.tsx";
import { keySpec } from "/src/components/space/SpaceCard.tsx";
import { scoreListing } from "/src/lib/matching.ts";
import { AMENITIES, CATEGORY_STYLE } from "/src/data/catalog.ts";
import { money, longDate, lastUpdatedLabel, isStale, availabilityLine } from "/src/lib/format.ts";
import { SPACE_TYPE_LABEL } from "/src/types/space.ts";
import { cn } from "/src/lib/cn.ts";
import { useI18n } from "/src/i18n/index.tsx";
import { spaceName, spaceDescription, displayImage } from "/src/lib/localize.ts";
export default function SpaceDetail() {
  _s();
  const { id = "" } = useParams();
  const navigate = useNavigate();
  const { listings, ready, requirements, hasStatedNeeds, isSaved, toggleSaved, isComparing, toggleCompare, sendInquiry } = useHabito();
  const { account } = useAuth();
  const { t, language } = useI18n();
  const [active, setActive] = useState(0);
  const [lightbox, setLightbox] = useState(false);
  const [inquiryOpen, setInquiryOpen] = useState(false);
  const [bookingOpen, setBookingOpen] = useState(false);
  const [siblings, setSiblings] = useState([]);
  const listing = useMemo(() => listings.find((l) => l.space.id === id) ?? null, [listings, id]);
  useEffect(() => {
    setActive(0);
    if (!listing) return;
    void db.spacesOfProperty(listing.property.id).then((all) => setSiblings(all.filter((s) => s.id !== id)));
  }, [listing, id]);
  if (!ready) {
    return /* @__PURE__ */ jsxDEV("div", { className: "container-page py-20 text-sm text-muted", children: "Loading space…" }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
      lineNumber: 65,
      columnNumber: 12
    }, this);
  }
  if (!listing) {
    return /* @__PURE__ */ jsxDEV("div", { className: "container-page py-20 text-center", children: [
      /* @__PURE__ */ jsxDEV("h1", { className: "font-display text-2xl font-bold text-ink", children: "That space isn't here." }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
        lineNumber: 71,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-muted", children: "It may have been removed, or the link is out of date." }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
        lineNumber: 72,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Button, { className: "mt-5", onClick: () => navigate("/search"), children: "Back to search" }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
        lineNumber: 73,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
      lineNumber: 70,
      columnNumber: 7
    }, this);
  }
  const { space, property, owner } = listing;
  const isMine = Boolean(account && property.ownerId === account.id);
  const match = hasStatedNeeds ? scoreListing(listing, requirements) : null;
  const saved = isSaved(space.id);
  const bookable = space.availability.status !== "occupied" && space.availability.status !== "maintenance";
  const comparing = isComparing(space.id);
  const isSale = space.transaction === "sale";
  const cat = CATEGORY_STYLE[space.category];
  return /* @__PURE__ */ jsxDEV("div", { className: "pb-24 md:pb-0", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "container-page pt-4 md:pt-6", children: [
      /* @__PURE__ */ jsxDEV(
        Link,
        {
          to: "/search",
          className: "mb-4 inline-flex items-center gap-1.5 text-sm font-semibold text-ink-soft hover:text-ink",
          children: [
            /* @__PURE__ */ jsxDEV(ArrowLeft, { size: 15, "aria-hidden": true }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
              lineNumber: 102,
              columnNumber: 11
            }, this),
            "Back to results"
          ]
        },
        void 0,
        true,
        {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
          lineNumber: 98,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { className: "grid gap-2 md:grid-cols-[1.9fr_1fr] md:gap-3", children: [
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: () => setLightbox(true),
            className: "group lift relative overflow-hidden rounded-card bg-ivory-deep",
            children: [
              /* @__PURE__ */ jsxDEV(
                SpacePhoto,
                {
                  src: displayImage(space.images[active]),
                  alt: space.images[active].alt,
                  category: space.category,
                  demo: space.images[active].demo,
                  priority: true,
                  className: "aspect-4/3 w-full md:aspect-16/10",
                  imgClassName: "zoom"
                },
                void 0,
                false,
                {
                  fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
                  lineNumber: 112,
                  columnNumber: 13
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("span", { className: "absolute bottom-3 left-3 rounded-full bg-ink/70 px-2.5 py-1 text-xs font-semibold text-white backdrop-blur", children: [
                space.images[active].label,
                " · view all"
              ] }, void 0, true, {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
                lineNumber: 121,
                columnNumber: 13
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
            lineNumber: 107,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-4 gap-2 md:grid-cols-1 md:grid-rows-3", children: space.images.slice(0, 3).map(
          (img, i) => /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: () => setActive(i),
              "aria-label": `Show ${img.label}`,
              "aria-current": i === active,
              className: cn(
                "overflow-hidden rounded-2xl bg-ivory-deep ring-2 transition-all",
                i === active ? "ring-ink" : "ring-transparent hover:ring-hairline-strong"
              ),
              children: /* @__PURE__ */ jsxDEV(
                SpacePhoto,
                {
                  src: displayImage(img),
                  alt: "",
                  category: space.category,
                  className: "aspect-4/3 size-full md:aspect-auto md:h-full"
                },
                void 0,
                false,
                {
                  fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
                  lineNumber: 139,
                  columnNumber: 17
                },
                this
              )
            },
            img.url + i,
            false,
            {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
              lineNumber: 128,
              columnNumber: 13
            },
            this
          )
        ) }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
          lineNumber: 126,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
        lineNumber: 106,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-xs text-muted", children: space.synthetic ? "Illustrative demo images. These are not photographs of a real space." : "Photographs provided by the owner." }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
        lineNumber: 150,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
      lineNumber: 97,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "container-page grid gap-10 py-8 lg:grid-cols-[1fr_22rem] lg:gap-14", children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center gap-2", children: [
          /* @__PURE__ */ jsxDEV("span", { className: cn("rounded-full px-2.5 py-1 text-xs font-semibold", cat.chip), children: SPACE_TYPE_LABEL[space.spaceType] }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
            lineNumber: 161,
            columnNumber: 13
          }, this),
          isSale && /* @__PURE__ */ jsxDEV("span", { className: "rounded-full bg-ink px-2.5 py-1 text-xs font-semibold text-ivory", children: "For sale" }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
            lineNumber: 164,
            columnNumber: 24
          }, this),
          /* @__PURE__ */ jsxDEV(AvailabilityBadge, { availability: space.availability }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
            lineNumber: 165,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(TrustBadge, { verification: space.verification }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
            lineNumber: 166,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
          lineNumber: 160,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("h1", { className: "mt-4 font-display text-3xl font-extrabold text-ink sm:text-4xl", children: spaceName(space, language) }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
          lineNumber: 169,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          Link,
          {
            to: `/property/${property.id}`,
            className: "mt-2 inline-flex items-center gap-1.5 text-sm text-ink-soft hover:text-ink",
            children: [
              /* @__PURE__ */ jsxDEV(Building2, { size: 15, "aria-hidden": true }, void 0, false, {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
                lineNumber: 175,
                columnNumber: 13
              }, this),
              property.name,
              /* @__PURE__ */ jsxDEV("span", { className: "text-muted", children: [
                "· ",
                property.address
              ] }, void 0, true, {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
                lineNumber: 177,
                columnNumber: 13
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
            lineNumber: 171,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("p", { className: "mt-1 inline-flex items-center gap-1.5 text-sm text-muted", children: [
          /* @__PURE__ */ jsxDEV(MapPin, { size: 14, "aria-hidden": true }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
            lineNumber: 181,
            columnNumber: 13
          }, this),
          property.area,
          ", ",
          property.district,
          " · ",
          property.geography
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
          lineNumber: 180,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "mt-6 leading-relaxed text-ink-soft", children: spaceDescription(space, language) }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
          lineNumber: 185,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Section, { title: "The space", children: /* @__PURE__ */ jsxDEV("dl", { className: "grid grid-cols-2 gap-px overflow-hidden rounded-card bg-hairline ring-1 ring-hairline sm:grid-cols-3", children: specRows(listing).map(
          (row) => /* @__PURE__ */ jsxDEV("div", { className: "bg-surface px-4 py-3", children: [
            /* @__PURE__ */ jsxDEV("dt", { className: "text-xs text-muted", children: row.label }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
              lineNumber: 192,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("dd", { className: "mt-0.5 font-bold tnum text-ink", children: row.value }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
              lineNumber: 193,
              columnNumber: 19
            }, this)
          ] }, row.label, true, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
            lineNumber: 191,
            columnNumber: 15
          }, this)
        ) }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
          lineNumber: 189,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
          lineNumber: 188,
          columnNumber: 11
        }, this),
        space.amenities.length > 0 && /* @__PURE__ */ jsxDEV(Section, { title: "What's included", children: /* @__PURE__ */ jsxDEV("ul", { className: "flex flex-wrap gap-2", children: space.amenities.map((key) => {
          const { label, icon: Icon } = AMENITIES[key];
          return /* @__PURE__ */ jsxDEV(
            "li",
            {
              className: "inline-flex items-center gap-1.5 rounded-full bg-surface px-3 py-1.5 text-sm text-ink-soft ring-1 ring-hairline",
              children: [
                /* @__PURE__ */ jsxDEV(Icon, { size: 14, className: "text-muted", "aria-hidden": true }, void 0, false, {
                  fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
                  lineNumber: 209,
                  columnNumber: 23
                }, this),
                label
              ]
            },
            key,
            true,
            {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
              lineNumber: 205,
              columnNumber: 19
            },
            this
          );
        }) }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
          lineNumber: 201,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
          lineNumber: 200,
          columnNumber: 11
        }, this),
        space.category === "living" && space.rules && /* @__PURE__ */ jsxDEV(Section, { title: "Who this is for", children: /* @__PURE__ */ jsxDEV("ul", { className: "flex flex-wrap gap-2", children: [
          /* @__PURE__ */ jsxDEV(RuleChip, { ok: space.rules.familyAllowed, yes: "Families welcome", no: "Not for families" }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
            lineNumber: 221,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(RuleChip, { ok: space.rules.bachelorAllowed, yes: "Bachelors welcome", no: "No bachelors" }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
            lineNumber: 222,
            columnNumber: 17
          }, this),
          space.rules.studentFriendly && /* @__PURE__ */ jsxDEV(RuleChip, { ok: true, yes: "Student friendly", no: "" }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
            lineNumber: 223,
            columnNumber: 49
          }, this),
          space.rules.genderPreference !== "any" && /* @__PURE__ */ jsxDEV(
            RuleChip,
            {
              ok: true,
              yes: space.rules.genderPreference === "male" ? "Men only" : "Women only",
              no: ""
            },
            void 0,
            false,
            {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
              lineNumber: 225,
              columnNumber: 15
            },
            this
          ),
          space.rules.maxOccupants && /* @__PURE__ */ jsxDEV(RuleChip, { ok: true, yes: `Up to ${space.rules.maxOccupants} people`, no: "" }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
            lineNumber: 232,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
          lineNumber: 220,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
          lineNumber: 219,
          columnNumber: 11
        }, this),
        property.nearby.length > 0 && /* @__PURE__ */ jsxDEV(Section, { title: "Getting around", children: /* @__PURE__ */ jsxDEV("ul", { className: "grid gap-px overflow-hidden rounded-card bg-hairline ring-1 ring-hairline sm:grid-cols-2", children: property.nearby.map(
          (n) => /* @__PURE__ */ jsxDEV("li", { className: "flex items-center justify-between bg-surface px-4 py-3 text-sm", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "text-ink-soft", children: n.label }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
              lineNumber: 243,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "font-semibold tnum text-ink", children: [
              n.km,
              " km"
            ] }, void 0, true, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
              lineNumber: 244,
              columnNumber: 21
            }, this)
          ] }, n.label, true, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
            lineNumber: 242,
            columnNumber: 15
          }, this)
        ) }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
          lineNumber: 240,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
          lineNumber: 239,
          columnNumber: 11
        }, this),
        siblings.length > 0 && /* @__PURE__ */ jsxDEV(Section, { title: `More at ${property.name}`, children: /* @__PURE__ */ jsxDEV("ul", { className: "space-y-2", children: siblings.slice(0, 5).map(
          (s) => /* @__PURE__ */ jsxDEV("li", { children: /* @__PURE__ */ jsxDEV(
            Link,
            {
              to: `/space/${s.id}`,
              className: "flex items-center gap-3 rounded-2xl bg-surface p-2.5 ring-1 ring-hairline transition-colors hover:ring-ink",
              children: [
                /* @__PURE__ */ jsxDEV("img", { src: s.images[0].url, alt: "", className: "size-12 shrink-0 rounded-xl object-cover" }, void 0, false, {
                  fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
                  lineNumber: 260,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "min-w-0 flex-1", children: [
                  /* @__PURE__ */ jsxDEV("p", { className: "truncate font-semibold text-ink", children: s.name }, void 0, false, {
                    fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
                    lineNumber: 262,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "truncate text-xs text-muted", children: SPACE_TYPE_LABEL[s.spaceType] }, void 0, false, {
                    fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
                    lineNumber: 263,
                    columnNumber: 25
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
                  lineNumber: 261,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "shrink-0 font-bold tnum text-ink", children: money(s.cost.price) }, void 0, false, {
                  fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
                  lineNumber: 265,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV(ChevronRight, { size: 16, className: "shrink-0 text-muted", "aria-hidden": true }, void 0, false, {
                  fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
                  lineNumber: 266,
                  columnNumber: 23
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
              lineNumber: 256,
              columnNumber: 21
            },
            this
          ) }, s.id, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
            lineNumber: 255,
            columnNumber: 15
          }, this)
        ) }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
          lineNumber: 253,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
          lineNumber: 252,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Section, { title: "Owner", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-start gap-4 rounded-card bg-surface p-5 ring-1 ring-hairline", children: [
            /* @__PURE__ */ jsxDEV(
              "span",
              {
                className: cn(
                  "flex size-12 shrink-0 items-center justify-center rounded-full font-display text-lg font-bold",
                  owner.avatarTone === "mint" && "bg-mint text-mint-ink",
                  owner.avatarTone === "sun" && "bg-sun text-sun-ink",
                  owner.avatarTone === "lilac" && "bg-lilac text-lilac-ink",
                  owner.avatarTone === "coral" && "bg-coral/60 text-coral-ink",
                  owner.avatarTone === "aqua" && "bg-aqua-200 text-aqua-700"
                ),
                children: owner.name.charAt(0)
              },
              void 0,
              false,
              {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
                lineNumber: 276,
                columnNumber: 15
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: [
              /* @__PURE__ */ jsxDEV("p", { className: "font-semibold text-ink", children: owner.name }, void 0, false, {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
                lineNumber: 289,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-sm capitalize text-muted", children: owner.role }, void 0, false, {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
                lineNumber: 290,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm tnum text-ink-soft", children: [
                "Replies to ",
                owner.responseRate,
                "% of inquiries · usually within ",
                owner.responseTimeHours,
                "h"
              ] }, void 0, true, {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
                lineNumber: 291,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "mt-3 text-xs leading-relaxed text-muted", children: [
                "Owner state: ",
                owner.verification.replace("-", " "),
                " (demo). Habito has not carried out a real identity or ownership check."
              ] }, void 0, true, {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
                lineNumber: 294,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
              lineNumber: 288,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
            lineNumber: 275,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              className: "mt-3 inline-flex items-center gap-1.5 text-xs font-semibold text-muted hover:text-danger-600",
              onClick: () => alert("Reporting is part of the trust workflow and is not wired up in this prototype."),
              children: [
                /* @__PURE__ */ jsxDEV(Flag, { size: 12, "aria-hidden": true }, void 0, false, {
                  fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
                  lineNumber: 306,
                  columnNumber: 15
                }, this),
                "Report this listing"
              ]
            },
            void 0,
            true,
            {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
              lineNumber: 301,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
          lineNumber: 274,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
        lineNumber: 159,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("aside", { className: "lg:sticky lg:top-24 lg:self-start", children: [
        match && /* @__PURE__ */ jsxDEV("div", { className: "mb-4 rounded-card bg-surface p-5 ring-1 ring-hairline", children: [
          /* @__PURE__ */ jsxDEV(MatchRing, { score: match.score }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
            lineNumber: 316,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("h2", { className: "mt-5 text-sm font-bold text-ink", children: "Why this scores as it does" }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
            lineNumber: 317,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("ul", { className: "mt-2.5 space-y-2", children: match.factors.map(
            (f) => /* @__PURE__ */ jsxDEV(FactorRow, { factor: f }, f.key, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
              lineNumber: 320,
              columnNumber: 15
            }, this)
          ) }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
            lineNumber: 318,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "mt-4 border-t border-hairline pt-3 text-xs leading-relaxed text-muted", children: "Weighted arithmetic over what you told us — budget 30, location 24, type 20, availability 12, size 7, amenities 7. No machine learning involved." }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
            lineNumber: 323,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
          lineNumber: 315,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "rounded-card bg-surface p-5 ring-1 ring-hairline", children: [
          /* @__PURE__ */ jsxDEV("p", { className: "font-display text-3xl font-extrabold tnum text-ink", children: [
            money(space.cost.price),
            !isSale && /* @__PURE__ */ jsxDEV("span", { className: "text-base font-medium text-muted", children: "/month" }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
              lineNumber: 333,
              columnNumber: 27
            }, this)
          ] }, void 0, true, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
            lineNumber: 331,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-muted", children: availabilityLine(space.availability.availableFrom) }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
            lineNumber: 335,
            columnNumber: 13
          }, this),
          space.availability.note && /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm font-semibold text-aqua-700", children: space.availability.note }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
            lineNumber: 337,
            columnNumber: 13
          }, this),
          !isSale && /* @__PURE__ */ jsxDEV(Fragment, { children: [
            /* @__PURE__ */ jsxDEV("h2", { className: "mt-5 text-sm font-bold text-ink", children: "Monthly cost" }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
              lineNumber: 342,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("dl", { className: "mt-2 space-y-1.5 text-sm", children: [
              /* @__PURE__ */ jsxDEV(CostRow, { label: "Rent", value: money(space.cost.price) }, void 0, false, {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
                lineNumber: 344,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(
                CostRow,
                {
                  label: "Service charge",
                  value: space.cost.serviceCharge !== null ? money(space.cost.serviceCharge) : "Not listed",
                  muted: space.cost.serviceCharge === null
                },
                void 0,
                false,
                {
                  fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
                  lineNumber: 345,
                  columnNumber: 19
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                CostRow,
                {
                  label: "Utilities",
                  value: space.cost.utilities !== null ? money(space.cost.utilities) : "Not listed",
                  muted: space.cost.utilities === null
                },
                void 0,
                false,
                {
                  fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
                  lineNumber: 350,
                  columnNumber: 19
                },
                this
              )
            ] }, void 0, true, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
              lineNumber: 343,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mt-3 border-t border-hairline pt-3", children: space.cost.estimatedMonthly ? /* @__PURE__ */ jsxDEV("div", { className: "flex items-baseline justify-between", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-semibold text-ink", children: "Estimated total" }, void 0, false, {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
                lineNumber: 360,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "font-display text-lg font-bold tnum text-aqua-700", children: money(space.cost.estimatedMonthly) }, void 0, false, {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
                lineNumber: 361,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
              lineNumber: 359,
              columnNumber: 17
            }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
              /* @__PURE__ */ jsxDEV("p", { className: "rounded-xl bg-warn-100 px-3 py-2 text-xs leading-relaxed text-warn-700", children: "This owner hasn't listed every cost, so a monthly total can't be shown." }, void 0, false, {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
                lineNumber: 367,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV(
                Coachmark,
                {
                  id: "cost",
                  titleKey: "coach.costTitle",
                  bodyKey: "coach.costBody",
                  className: "mt-3"
                },
                void 0,
                false,
                {
                  fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
                  lineNumber: 370,
                  columnNumber: 23
                },
                this
              )
            ] }, void 0, true, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
              lineNumber: 366,
              columnNumber: 17
            }, this) }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
              lineNumber: 357,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("dl", { className: "mt-4 space-y-1.5 border-t border-hairline pt-3 text-sm", children: [
              space.cost.advanceMonths !== null && /* @__PURE__ */ jsxDEV(
                CostRow,
                {
                  label: "Advance",
                  value: `${space.cost.advanceMonths} month${space.cost.advanceMonths > 1 ? "s" : ""}`
                },
                void 0,
                false,
                {
                  fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
                  lineNumber: 382,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                CostRow,
                {
                  label: "Deposit",
                  value: space.cost.securityDeposit !== null ? money(space.cost.securityDeposit) : "Not listed",
                  muted: space.cost.securityDeposit === null
                },
                void 0,
                false,
                {
                  fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
                  lineNumber: 387,
                  columnNumber: 19
                },
                this
              )
            ] }, void 0, true, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
              lineNumber: 380,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
            lineNumber: 341,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "mt-5 hidden gap-2 md:flex md:flex-col", children: [
            isMine ? /* @__PURE__ */ jsxDEV(Link, { to: `/space/${space.id}/edit`, children: /* @__PURE__ */ jsxDEV(Button, { fullWidth: true, variant: "secondary", children: [
              /* @__PURE__ */ jsxDEV(Pencil, { size: 15, "aria-hidden": true }, void 0, false, {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
                lineNumber: 400,
                columnNumber: 21
              }, this),
              t("edit.action")
            ] }, void 0, true, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
              lineNumber: 399,
              columnNumber: 19
            }, this) }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
              lineNumber: 398,
              columnNumber: 15
            }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
              /* @__PURE__ */ jsxDEV(Button, { fullWidth: true, onClick: () => setBookingOpen(true), disabled: !bookable, children: [
                /* @__PURE__ */ jsxDEV(CalendarCheck, { size: 15, "aria-hidden": true }, void 0, false, {
                  fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
                  lineNumber: 407,
                  columnNumber: 21
                }, this),
                t("booking.request")
              ] }, void 0, true, {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
                lineNumber: 406,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(Button, { fullWidth: true, variant: "secondary", onClick: () => setInquiryOpen(true), children: t("action.sendInquiry") }, void 0, false, {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
                lineNumber: 410,
                columnNumber: 19
              }, this),
              !bookable && /* @__PURE__ */ jsxDEV("p", { className: "text-center text-xs text-muted", children: t("booking.notAvailable") }, void 0, false, {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
                lineNumber: 414,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
              lineNumber: 405,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-2", children: [
              /* @__PURE__ */ jsxDEV(Button, { variant: "secondary", onClick: () => void toggleSaved(space.id), children: [
                /* @__PURE__ */ jsxDEV(Bookmark, { size: 15, className: cn(saved && "fill-aqua-600 text-aqua-600"), "aria-hidden": true }, void 0, false, {
                  fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
                  lineNumber: 420,
                  columnNumber: 19
                }, this),
                saved ? "Saved" : "Save"
              ] }, void 0, true, {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
                lineNumber: 419,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV(Button, { variant: "secondary", onClick: () => toggleCompare(space.id), children: [
                /* @__PURE__ */ jsxDEV(Scale, { size: 15, "aria-hidden": true }, void 0, false, {
                  fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
                  lineNumber: 424,
                  columnNumber: 19
                }, this),
                comparing ? "Added" : "Compare"
              ] }, void 0, true, {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
                lineNumber: 423,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
              lineNumber: 418,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
            lineNumber: 396,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: cn("mt-4 text-xs", isStale(space.lastUpdated) ? "font-medium text-warn-700" : "text-muted"), children: [
            lastUpdatedLabel(space.lastUpdated),
            " · ",
            space.views,
            " views · ",
            space.inquiryCount,
            " inquiries"
          ] }, void 0, true, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
            lineNumber: 430,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
          lineNumber: 330,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
        lineNumber: 313,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
      lineNumber: 158,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-x-0 bottom-14 z-30 border-t border-hairline bg-surface/95 p-3 backdrop-blur md:hidden", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "min-w-0 flex-1", children: [
        /* @__PURE__ */ jsxDEV("p", { className: "truncate font-display text-lg font-bold tnum text-ink", children: [
          money(space.cost.price),
          !isSale && /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-medium text-muted", children: "/mo" }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
            lineNumber: 443,
            columnNumber: 27
          }, this)
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
          lineNumber: 441,
          columnNumber: 13
        }, this),
        match && /* @__PURE__ */ jsxDEV("p", { className: "text-xs tnum text-aqua-700", children: [
          match.score,
          "% match"
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
          lineNumber: 445,
          columnNumber: 23
        }, this)
      ] }, void 0, true, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
        lineNumber: 440,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Button, { variant: "secondary", size: "sm", onClick: () => void toggleSaved(space.id), "aria-label": "Save", children: /* @__PURE__ */ jsxDEV(Bookmark, { size: 16, className: cn(saved && "fill-aqua-600 text-aqua-600"), "aria-hidden": true }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
        lineNumber: 448,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
        lineNumber: 447,
        columnNumber: 11
      }, this),
      isMine ? /* @__PURE__ */ jsxDEV(Link, { to: `/space/${space.id}/edit`, children: /* @__PURE__ */ jsxDEV(Button, { size: "sm", variant: "secondary", children: [
        /* @__PURE__ */ jsxDEV(Pencil, { size: 15, "aria-hidden": true }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
          lineNumber: 453,
          columnNumber: 17
        }, this),
        t("edit.action")
      ] }, void 0, true, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
        lineNumber: 452,
        columnNumber: 15
      }, this) }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
        lineNumber: 451,
        columnNumber: 11
      }, this) : /* @__PURE__ */ jsxDEV(Button, { size: "sm", onClick: () => setInquiryOpen(true), children: t("action.sendInquiry") }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
        lineNumber: 458,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
      lineNumber: 439,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
      lineNumber: 438,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      Lightbox,
      {
        open: lightbox,
        onClose: () => setLightbox(false),
        listing,
        active,
        setActive
      },
      void 0,
      false,
      {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
        lineNumber: 465,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      BookingModal,
      {
        open: bookingOpen,
        onClose: () => setBookingOpen(false),
        listing,
        requirements
      },
      void 0,
      false,
      {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
        lineNumber: 473,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      InquiryModal,
      {
        open: inquiryOpen,
        onClose: () => setInquiryOpen(false),
        listing,
        onSend: sendInquiry,
        requirements
      },
      void 0,
      false,
      {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
        lineNumber: 480,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
    lineNumber: 95,
    columnNumber: 5
  }, this);
}
_s(SpaceDetail, "AV/m4xe3AMuTMSDwQGVmA9yKljQ=", false, function() {
  return [useParams, useNavigate, useHabito, useAuth, useI18n];
});
_c = SpaceDetail;
function RuleChip({ ok, yes, no }) {
  return /* @__PURE__ */ jsxDEV(
    "li",
    {
      className: cn(
        "inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 text-sm font-medium",
        ok ? "bg-ok-100 text-ok-600" : "bg-ivory-deep text-muted"
      ),
      children: [
        ok ? /* @__PURE__ */ jsxDEV(Check, { size: 14, "aria-hidden": true }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
          lineNumber: 502,
          columnNumber: 13
        }, this) : /* @__PURE__ */ jsxDEV(X, { size: 14, "aria-hidden": true }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
          lineNumber: 502,
          columnNumber: 47
        }, this),
        ok ? yes : no
      ]
    },
    void 0,
    true,
    {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
      lineNumber: 496,
      columnNumber: 5
    },
    this
  );
}
_c2 = RuleChip;
function Section({ title, children }) {
  return /* @__PURE__ */ jsxDEV("section", { className: "mt-9", children: [
    /* @__PURE__ */ jsxDEV("h2", { className: "mb-3 font-display text-xl font-bold text-ink", children: title }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
      lineNumber: 511,
      columnNumber: 7
    }, this),
    children
  ] }, void 0, true, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
    lineNumber: 510,
    columnNumber: 5
  }, this);
}
_c3 = Section;
function specRows(listing) {
  const a = listing.space.attributes;
  const rows = [];
  const add = (label, value) => {
    if (value === void 0 || value === null || value === false) return;
    rows.push({ label, value: typeof value === "boolean" ? "Yes" : String(value) });
  };
  switch (listing.space.category) {
    case "living":
      add("Bedrooms", a.bedrooms);
      add("Bathrooms", a.bathrooms);
      add("Size", a.sizeSqft ? `${a.sizeSqft} sqft` : void 0);
      add("Floor", a.floor);
      add("Furnishing", a.furnishing?.replace("-", " "));
      add("Balcony", a.balcony);
      break;
    case "business":
      add("Size", a.sizeSqft ? `${a.sizeSqft} sqft` : void 0);
      add("Floor", a.floor === 0 ? "Ground" : a.floor);
      add("Frontage", a.frontageFt ? `${a.frontageFt} ft` : void 0);
      add("Workstations", a.workstations);
      add("Meeting room", a.meetingRoom);
      add("Suits", a.suitableFor);
      break;
    case "storage":
      add("Storage area", a.sizeSqft ? `${a.sizeSqft} sqft` : void 0);
      add("Ceiling", a.ceilingHeightFt ? `${a.ceilingHeightFt} ft` : void 0);
      add("Loading access", a.loadingAccess);
      add("Vehicle access", a.vehicleAccess);
      add("Suits", a.suitableFor);
      break;
    case "parking":
      add("Car slots", a.carSlots);
      add("Motorcycle slots", a.motorcycleSlots);
      add("Cover", a.covered ? "Covered" : "Open");
      add("Access", a.accessHours);
      break;
    case "land":
      add("Land area", a.landAreaDecimal ? `${a.landAreaDecimal} decimal` : void 0);
      add("Use", a.landUse);
      add("Road access", a.roadAccess);
      add("Water source", a.waterSource);
      add("Lease", a.leaseYears ? `${a.leaseYears} years` : void 0);
      break;
  }
  if (rows.length === 0) rows.push({ label: "Summary", value: keySpec(listing) });
  return rows;
}
const VERDICT = {
  met: { Icon: Check, className: "text-ok-600" },
  partial: { Icon: Minus, className: "text-warn-700" },
  missed: { Icon: X, className: "text-danger-600" }
};
function FactorRow({ factor }) {
  const { Icon, className } = VERDICT[factor.verdict];
  const points = factor.score * factor.weight;
  const label = Math.abs(points - Math.round(points)) < 0.05 ? String(Math.round(points)) : points.toFixed(1);
  return /* @__PURE__ */ jsxDEV("li", { className: "flex gap-2.5 text-sm", children: [
    /* @__PURE__ */ jsxDEV(Icon, { size: 15, className: cn("mt-0.5 shrink-0", className), "aria-hidden": true }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
      lineNumber: 581,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("span", { className: "flex-1 leading-snug text-ink-soft", children: [
      /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-ink", children: factor.label }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
        lineNumber: 583,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("span", { className: "mx-1.5 text-hairline-strong", "aria-hidden": true, children: "·" }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
        lineNumber: 584,
        columnNumber: 9
      }, this),
      factor.detail
    ] }, void 0, true, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
      lineNumber: 582,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("span", { className: "shrink-0 text-xs font-semibold tnum text-muted", children: [
      label,
      "/",
      factor.weight
    ] }, void 0, true, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
      lineNumber: 587,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
    lineNumber: 580,
    columnNumber: 5
  }, this);
}
_c4 = FactorRow;
function CostRow({ label, value, muted }) {
  return /* @__PURE__ */ jsxDEV("div", { className: "flex items-baseline justify-between gap-3", children: [
    /* @__PURE__ */ jsxDEV("dt", { className: "text-ink-soft", children: label }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
      lineNumber: 597,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("dd", { className: cn("font-semibold tnum", muted ? "text-muted" : "text-ink"), children: value }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
      lineNumber: 598,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
    lineNumber: 596,
    columnNumber: 5
  }, this);
}
_c5 = CostRow;
function Lightbox({
  open,
  onClose,
  listing,
  active,
  setActive
}) {
  _s2();
  useEffect(() => {
    if (!open) return;
    const onKey = (e) => {
      if (e.key === "Escape") onClose();
      if (e.key === "ArrowRight") setActive((active + 1) % listing.space.images.length);
      if (e.key === "ArrowLeft") setActive((active - 1 + listing.space.images.length) % listing.space.images.length);
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [open, onClose, active, setActive, listing.space.images.length]);
  if (!open) return null;
  return /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 z-50 flex flex-col bg-ink/95 p-4", role: "dialog", "aria-modal": "true", "aria-label": "Images", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between text-ivory", children: [
      /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-semibold", children: [
        listing.space.images[active].label,
        /* @__PURE__ */ jsxDEV("span", { className: "ml-2 font-normal text-ivory/60 tnum", children: [
          active + 1,
          " / ",
          listing.space.images.length
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
          lineNumber: 634,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
        lineNumber: 632,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: onClose, "aria-label": "Close", className: "rounded-full p-2 hover:bg-white/10", children: /* @__PURE__ */ jsxDEV(X, { size: 20 }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
        lineNumber: 639,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
        lineNumber: 638,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
      lineNumber: 631,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex flex-1 items-center justify-center py-4", children: /* @__PURE__ */ jsxDEV(
      "img",
      {
        src: listing.space.images[active].url,
        alt: listing.space.images[active].alt,
        className: "max-h-full max-w-4xl rounded-card object-contain"
      },
      void 0,
      false,
      {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
        lineNumber: 644,
        columnNumber: 9
      },
      this
    ) }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
      lineNumber: 643,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center gap-2", children: listing.space.images.map(
      (img, i) => /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          onClick: () => setActive(i),
          "aria-label": `Show ${img.label}`,
          className: cn(
            "overflow-hidden rounded-xl ring-2 transition-all",
            i === active ? "ring-aqua-400" : "ring-transparent opacity-60 hover:opacity-100"
          ),
          children: /* @__PURE__ */ jsxDEV("img", { src: img.url, alt: "", className: "size-16 object-cover" }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
            lineNumber: 663,
            columnNumber: 13
          }, this)
        },
        img.url + i,
        false,
        {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
          lineNumber: 653,
          columnNumber: 9
        },
        this
      )
    ) }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
      lineNumber: 651,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
    lineNumber: 630,
    columnNumber: 5
  }, this);
}
_s2(Lightbox, "OD7bBpZva5O2jO+Puf00hKivP7c=");
_c6 = Lightbox;
function BookingModal({
  open,
  onClose,
  listing,
  requirements
}) {
  _s3();
  const { t } = useI18n();
  const navigate = useNavigate();
  const { account, configured } = useAuth();
  const [moveIn, setMoveIn] = useState(requirements.moveInDate);
  const [months, setMonths] = useState(12);
  const [message, setMessage] = useState("");
  const [sending, setSending] = useState(false);
  const [error, setError] = useState(null);
  const amount = listing.space.cost.price;
  const submit = async () => {
    setSending(true);
    setError(null);
    try {
      await db.requestBooking({
        spaceId: listing.space.id,
        moveInDate: moveIn,
        months,
        amount,
        message: message.trim() || void 0
      });
      onClose();
      navigate("/bookings");
    } catch (e) {
      setError(e instanceof Error ? e.message : t("auth.errorGeneric"));
    } finally {
      setSending(false);
    }
  };
  return /* @__PURE__ */ jsxDEV(
    Modal,
    {
      open,
      onClose,
      title: t("booking.requestTitle"),
      footer: /* @__PURE__ */ jsxDEV("div", { className: "flex gap-2", children: [
        /* @__PURE__ */ jsxDEV(Button, { variant: "secondary", fullWidth: true, onClick: onClose, children: t("action.cancel") }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
          lineNumber: 731,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Button, { fullWidth: true, disabled: sending, onClick: () => void submit(), children: sending ? t("action.sending") : t("booking.request") }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
          lineNumber: 734,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
        lineNumber: 730,
        columnNumber: 7
      }, this),
      children: [
        /* @__PURE__ */ jsxDEV("p", { className: "text-sm leading-relaxed text-ink-soft", children: t("booking.requestBody") }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
          lineNumber: 740,
          columnNumber: 7
        }, this),
        configured && !account && /* @__PURE__ */ jsxDEV("p", { className: "mt-3 rounded-xl bg-warn-100 p-3 text-sm leading-relaxed text-warn-700", children: t("inquiry.signInFirst") }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
          lineNumber: 743,
          columnNumber: 7
        }, this),
        error && /* @__PURE__ */ jsxDEV("p", { className: "mt-3 rounded-xl bg-danger-100 p-3 text-sm text-danger-600", children: error }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
          lineNumber: 749,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-4 grid gap-4 sm:grid-cols-2", children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "mb-1.5 block text-sm font-medium text-ink-soft", children: t("booking.moveIn") }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
              lineNumber: 754,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "date",
                value: moveIn,
                onChange: (e) => setMoveIn(e.target.value),
                className: "h-11 w-full rounded-xl bg-ivory px-3 text-[0.9375rem] ring-1 ring-hairline-strong focus:outline-none focus:ring-2 focus:ring-aqua-600"
              },
              void 0,
              false,
              {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
                lineNumber: 755,
                columnNumber: 11
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
            lineNumber: 753,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV("label", { className: "block", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "mb-1.5 block text-sm font-medium text-ink-soft", children: t("booking.howLong") }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
              lineNumber: 764,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV(
              "select",
              {
                value: months,
                onChange: (e) => setMonths(Number(e.target.value)),
                className: "h-11 w-full rounded-xl bg-ivory px-3 text-[0.9375rem] ring-1 ring-hairline-strong focus:outline-none focus:ring-2 focus:ring-aqua-600",
                children: [
                  /* @__PURE__ */ jsxDEV("option", { value: 3, children: t("booking.span3") }, void 0, false, {
                    fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
                    lineNumber: 772,
                    columnNumber: 13
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { value: 6, children: t("booking.span6") }, void 0, false, {
                    fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
                    lineNumber: 773,
                    columnNumber: 13
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { value: 12, children: t("booking.span12") }, void 0, false, {
                    fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
                    lineNumber: 774,
                    columnNumber: 13
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { value: 24, children: t("booking.span24") }, void 0, false, {
                    fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
                    lineNumber: 775,
                    columnNumber: 13
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
                lineNumber: 767,
                columnNumber: 11
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
            lineNumber: 763,
            columnNumber: 9
          }, this)
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
          lineNumber: 752,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV("label", { className: "mt-4 block", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "mb-1.5 block text-sm font-medium text-ink-soft", children: t("inquiry.yourMessage") }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
            lineNumber: 781,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV(
            "textarea",
            {
              rows: 3,
              value: message,
              onChange: (e) => setMessage(e.target.value),
              placeholder: t("inquiry.default"),
              className: "w-full rounded-xl bg-ivory p-3 text-[0.9375rem] ring-1 ring-hairline-strong focus:outline-none focus:ring-2 focus:ring-aqua-600"
            },
            void 0,
            false,
            {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
              lineNumber: 782,
              columnNumber: 9
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
          lineNumber: 780,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV("dl", { className: "mt-4 flex justify-between rounded-xl bg-ivory p-3 text-sm", children: [
          /* @__PURE__ */ jsxDEV("dt", { className: "text-muted", children: t("booking.amount") }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
            lineNumber: 792,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV("dd", { className: "font-semibold tnum text-ink", children: [
            money(amount),
            listing.space.transaction === "rent" && t("transaction.perMonth")
          ] }, void 0, true, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
            lineNumber: 793,
            columnNumber: 9
          }, this)
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
          lineNumber: 791,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "mt-3 text-xs leading-relaxed text-muted", children: t("booking.howLongNote") }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
          lineNumber: 799,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "mt-2 flex items-start gap-2 text-xs leading-relaxed text-muted", children: [
          /* @__PURE__ */ jsxDEV(Clock, { size: 13, className: "mt-0.5 shrink-0", "aria-hidden": true }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
            lineNumber: 802,
            columnNumber: 9
          }, this),
          t("booking.phoneLater")
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
          lineNumber: 801,
          columnNumber: 7
        }, this)
      ]
    },
    void 0,
    true,
    {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
      lineNumber: 725,
      columnNumber: 5
    },
    this
  );
}
_s3(BookingModal, "s1u++jwTMuzBRquXrwZbRH8AWw0=", false, function() {
  return [useI18n, useNavigate, useAuth];
});
_c7 = BookingModal;
function InquiryModal({
  open,
  onClose,
  listing,
  onSend,
  requirements
}) {
  _s4();
  const navigate = useNavigate();
  const { account, configured } = useAuth();
  const [name, setName] = useState("");
  const [message, setMessage] = useState("Hi, I'm interested in this space. Is it still available?");
  const [moveIn, setMoveIn] = useState(requirements.moveInDate);
  const [sent, setSent] = useState(false);
  const [sending, setSending] = useState(false);
  const [error, setError] = useState(null);
  useEffect(() => {
    if (account?.name) setName(account.name);
  }, [account]);
  const send = async () => {
    setSending(true);
    setError(null);
    try {
      await onSend({
        spaceId: listing.space.id,
        name: name.trim() || account?.name || "Habito user",
        message,
        moveInDate: moveIn,
        budgetMin: requirements.budgetMin,
        budgetMax: requirements.budgetMax
      });
      setSent(true);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Your inquiry didn't send.");
    } finally {
      setSending(false);
    }
  };
  const openThread = async () => {
    try {
      const id = await db.openConversation(listing.space.id);
      navigate(`/messages/${id}`);
    } catch {
      navigate("/messages");
    }
  };
  const close = () => {
    onClose();
    window.setTimeout(() => setSent(false), 250);
  };
  return /* @__PURE__ */ jsxDEV(
    Modal,
    {
      open,
      onClose: close,
      title: sent ? "Inquiry sent" : "Send an inquiry",
      footer: sent ? /* @__PURE__ */ jsxDEV("div", { className: "flex gap-2", children: [
        /* @__PURE__ */ jsxDEV(Button, { variant: "secondary", fullWidth: true, onClick: close, children: "Done" }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
          lineNumber: 877,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(Button, { fullWidth: true, onClick: () => void openThread(), children: "Open conversation" }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
          lineNumber: 880,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
        lineNumber: 876,
        columnNumber: 7
      }, this) : /* @__PURE__ */ jsxDEV("div", { className: "flex gap-2", children: [
        /* @__PURE__ */ jsxDEV(Button, { variant: "secondary", fullWidth: true, onClick: close, children: "Cancel" }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
          lineNumber: 886,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(
          Button,
          {
            fullWidth: true,
            onClick: () => void send(),
            disabled: sending || message.trim().length === 0,
            children: sending ? "Sending…" : "Send"
          },
          void 0,
          false,
          {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
            lineNumber: 889,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
        lineNumber: 885,
        columnNumber: 7
      }, this),
      children: sent ? /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: /* @__PURE__ */ jsxDEV("p", { className: "text-sm leading-relaxed text-ink-soft", children: [
        listing.owner.name,
        " now has your message, budget and move-in date. Replies arrive in Messages, and you'll see a badge when one lands."
      ] }, void 0, true, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
        lineNumber: 902,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
        lineNumber: 901,
        columnNumber: 7
      }, this) : /* @__PURE__ */ jsxDEV("div", { className: "space-y-4", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 rounded-2xl bg-ivory-deep p-3", children: [
          /* @__PURE__ */ jsxDEV("img", { src: listing.space.images[0].url, alt: "", className: "size-12 rounded-xl object-cover" }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
            lineNumber: 910,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "min-w-0", children: [
            /* @__PURE__ */ jsxDEV("p", { className: "truncate font-semibold text-ink", children: listing.space.name }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
              lineNumber: 912,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "truncate text-sm text-muted", children: [
              listing.property.area,
              " · ",
              money(listing.space.cost.price),
              listing.space.transaction === "rent" && "/month"
            ] }, void 0, true, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
              lineNumber: 913,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
            lineNumber: 911,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
          lineNumber: 909,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Field, { label: "Your name", children: /* @__PURE__ */ jsxDEV(
          "input",
          {
            value: name,
            onChange: (e) => setName(e.target.value),
            placeholder: "So the owner knows who's asking",
            className: "h-11 w-full rounded-xl bg-ivory px-3 text-[0.9375rem] ring-1 ring-hairline-strong focus:outline-none focus:ring-2 focus:ring-aqua-600"
          },
          void 0,
          false,
          {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
            lineNumber: 921,
            columnNumber: 13
          },
          this
        ) }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
          lineNumber: 920,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Field, { label: "Message", children: /* @__PURE__ */ jsxDEV(
          "textarea",
          {
            rows: 3,
            value: message,
            onChange: (e) => setMessage(e.target.value),
            className: "w-full rounded-xl bg-ivory p-3 text-[0.9375rem] ring-1 ring-hairline-strong focus:outline-none focus:ring-2 focus:ring-aqua-600"
          },
          void 0,
          false,
          {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
            lineNumber: 930,
            columnNumber: 13
          },
          this
        ) }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
          lineNumber: 929,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Field, { label: "When you'd move in", children: /* @__PURE__ */ jsxDEV(
          "input",
          {
            type: "date",
            value: moveIn,
            onChange: (e) => setMoveIn(e.target.value),
            className: "h-11 w-full rounded-xl bg-ivory px-3 text-[0.9375rem] ring-1 ring-hairline-strong focus:outline-none focus:ring-2 focus:ring-aqua-600"
          },
          void 0,
          false,
          {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
            lineNumber: 939,
            columnNumber: 13
          },
          this
        ) }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
          lineNumber: 938,
          columnNumber: 11
        }, this),
        error && /* @__PURE__ */ jsxDEV("p", { className: "rounded-xl bg-danger-100 p-3 text-sm text-danger-600", children: error }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
          lineNumber: 947,
          columnNumber: 21
        }, this),
        configured && !account && /* @__PURE__ */ jsxDEV("p", { className: "rounded-xl bg-warn-100 p-3 text-sm leading-relaxed text-warn-700", children: [
          "You'll need to",
          " ",
          /* @__PURE__ */ jsxDEV(Link, { to: "/signin", className: "font-semibold underline", children: "sign in" }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
            lineNumber: 952,
            columnNumber: 15
          }, this),
          " ",
          "before an owner can reply to you."
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
          lineNumber: 950,
          columnNumber: 9
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("p", { className: "mb-2 text-sm font-medium text-ink-soft", children: "Sent with your inquiry" }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
            lineNumber: 960,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("ul", { className: "flex flex-wrap gap-1.5 text-xs", children: [
            /* @__PURE__ */ jsxDEV("li", { className: "rounded-full bg-aqua-100 px-2.5 py-1 font-semibold text-aqua-700", children: [
              "Budget ",
              money(requirements.budgetMin),
              "–",
              money(requirements.budgetMax)
            ] }, void 0, true, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
              lineNumber: 962,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("li", { className: "rounded-full bg-aqua-100 px-2.5 py-1 font-semibold text-aqua-700", children: [
              "Moving ",
              longDate(moveIn)
            ] }, void 0, true, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
              lineNumber: 965,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
            lineNumber: 961,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-xs text-muted", children: "Your phone number isn't shared until you choose to." }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
            lineNumber: 969,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
          lineNumber: 959,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
        lineNumber: 908,
        columnNumber: 7
      }, this)
    },
    void 0,
    false,
    {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
      lineNumber: 870,
      columnNumber: 5
    },
    this
  );
}
_s4(InquiryModal, "mf77pC1htAK395SMwxghWMtDV4M=", false, function() {
  return [useNavigate, useAuth];
});
_c8 = InquiryModal;
function Field({ label, children }) {
  return /* @__PURE__ */ jsxDEV("label", { className: "block", children: [
    /* @__PURE__ */ jsxDEV("span", { className: "mb-1.5 block text-sm font-medium text-ink-soft", children: label }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
      lineNumber: 980,
      columnNumber: 7
    }, this),
    children
  ] }, void 0, true, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx",
    lineNumber: 979,
    columnNumber: 5
  }, this);
}
_c9 = Field;
var _c, _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9;
$RefreshReg$(_c, "SpaceDetail");
$RefreshReg$(_c2, "RuleChip");
$RefreshReg$(_c3, "Section");
$RefreshReg$(_c4, "FactorRow");
$RefreshReg$(_c5, "CostRow");
$RefreshReg$(_c6, "Lightbox");
$RefreshReg$(_c7, "BookingModal");
$RefreshReg$(_c8, "InquiryModal");
$RefreshReg$(_c9, "Field");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/I2I Project - Habito/App Folder/habito/src/pages/SpaceDetail.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNkNXLFNBNlNTLFVBN1NUOzs7Ozs7Ozs7Ozs7Ozs7OztBQTdDWCxTQUFTQSxXQUFXQyxTQUFTQyxnQkFBZ0I7QUFDN0MsU0FBU0MsTUFBTUMsYUFBYUMsaUJBQWlCO0FBQzdDLFNBQVNDLFdBQVdDLFVBQVVDLE9BQU9DLFFBQVFDLE9BQU9DLE9BQU9DLEdBQUdDLFdBQVdDLE1BQU1DLGNBQWNDLFFBQVFDLGVBQWVDLGFBQWE7QUFDakksU0FBU0MsaUJBQWlCO0FBQzFCLFNBQVNDLFVBQVU7QUFDbkIsU0FBU0MsZUFBZTtBQUN4QixTQUFTQyxjQUFjO0FBQ3ZCLFNBQVNDLGFBQWE7QUFDdEIsU0FBU0MsaUJBQWlCO0FBQzFCLFNBQVNDLGtCQUFrQjtBQUMzQixTQUFTQyxpQkFBaUI7QUFDMUIsU0FBU0MsWUFBWUMseUJBQXlCO0FBQzlDLFNBQVNDLGVBQWU7QUFDeEIsU0FBU0Msb0JBQW9CO0FBQzdCLFNBQVNDLFdBQVdDLHNCQUFzQjtBQUMxQyxTQUFTQyxPQUFPQyxVQUFVQyxrQkFBa0JDLFNBQVNDLHdCQUF3QjtBQUM3RSxTQUFTQyx3QkFBd0I7QUFFakMsU0FBU0MsVUFBVTtBQUNuQixTQUFTQyxlQUFlO0FBQ3hCLFNBQVNDLFdBQVdDLGtCQUFrQkMsb0JBQW9CO0FBRTFELHdCQUF3QkMsY0FBYztBQUFBQyxLQUFBO0FBQ3BDLFFBQU0sRUFBRUMsS0FBSyxHQUFHLElBQUl6QyxVQUFVO0FBQzlCLFFBQU0wQyxXQUFXM0MsWUFBWTtBQUM3QixRQUFNLEVBQUU0QyxVQUFVQyxPQUFPQyxjQUFjQyxnQkFBZ0JDLFNBQVNDLGFBQWFDLGFBQWFDLGVBQWVDLFlBQVksSUFDbkhyQyxVQUFVO0FBQ1osUUFBTSxFQUFFc0MsUUFBUSxJQUFJcEMsUUFBUTtBQUM1QixRQUFNLEVBQUVxQyxHQUFHQyxTQUFTLElBQUluQixRQUFRO0FBRWhDLFFBQU0sQ0FBQ29CLFFBQVFDLFNBQVMsSUFBSTNELFNBQVMsQ0FBQztBQUN0QyxRQUFNLENBQUM0RCxVQUFVQyxXQUFXLElBQUk3RCxTQUFTLEtBQUs7QUFDOUMsUUFBTSxDQUFDOEQsYUFBYUMsY0FBYyxJQUFJL0QsU0FBUyxLQUFLO0FBQ3BELFFBQU0sQ0FBQ2dFLGFBQWFDLGNBQWMsSUFBSWpFLFNBQVMsS0FBSztBQUNwRCxRQUFNLENBQUNrRSxVQUFVQyxXQUFXLElBQUluRSxTQUFrQixFQUFFO0FBRXBELFFBQU1vRSxVQUFVckUsUUFBUSxNQUFNK0MsU0FBU3VCLEtBQUssQ0FBQ0MsTUFBTUEsRUFBRUMsTUFBTTNCLE9BQU9BLEVBQUUsS0FBSyxNQUFNLENBQUNFLFVBQVVGLEVBQUUsQ0FBQztBQUU3RjlDLFlBQVUsTUFBTTtBQUNkNkQsY0FBVSxDQUFDO0FBQ1gsUUFBSSxDQUFDUyxRQUFTO0FBQ2QsU0FBS2xELEdBQUdzRCxpQkFBaUJKLFFBQVFLLFNBQVM3QixFQUFFLEVBQUU4QixLQUFLLENBQUNDLFFBQVFSLFlBQVlRLElBQUlDLE9BQU8sQ0FBQ0MsTUFBTUEsRUFBRWpDLE9BQU9BLEVBQUUsQ0FBQyxDQUFDO0FBQUEsRUFDekcsR0FBRyxDQUFDd0IsU0FBU3hCLEVBQUUsQ0FBQztBQUVoQixNQUFJLENBQUNHLE9BQU87QUFDVixXQUFPLHVCQUFDLFNBQUksV0FBVSwyQ0FBMEMsOEJBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBdUU7QUFBQSxFQUNoRjtBQUVBLE1BQUksQ0FBQ3FCLFNBQVM7QUFDWixXQUNFLHVCQUFDLFNBQUksV0FBVSxvQ0FDYjtBQUFBLDZCQUFDLFFBQUcsV0FBVSw0Q0FBMkMsc0NBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBK0U7QUFBQSxNQUMvRSx1QkFBQyxPQUFFLFdBQVUsMkJBQTBCLHFFQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTRGO0FBQUEsTUFDNUYsdUJBQUMsVUFBTyxXQUFVLFFBQU8sU0FBUyxNQUFNdkIsU0FBUyxTQUFTLEdBQUUsOEJBQTVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU1BO0FBQUEsRUFFSjtBQUVBLFFBQU0sRUFBRTBCLE9BQU9FLFVBQVVLLE1BQU0sSUFBSVY7QUFFbkMsUUFBTVcsU0FBU0MsUUFBUXpCLFdBQVdrQixTQUFTUSxZQUFZMUIsUUFBUVgsRUFBRTtBQUNqRSxRQUFNc0MsUUFBUWpDLGlCQUFpQnJCLGFBQWF3QyxTQUFTcEIsWUFBWSxJQUFJO0FBQ3JFLFFBQU1tQyxRQUFRakMsUUFBUXFCLE1BQU0zQixFQUFFO0FBSTlCLFFBQU13QyxXQUNKYixNQUFNYyxhQUFhQyxXQUFXLGNBQWNmLE1BQU1jLGFBQWFDLFdBQVc7QUFDNUUsUUFBTUMsWUFBWW5DLFlBQVltQixNQUFNM0IsRUFBRTtBQUN0QyxRQUFNNEMsU0FBU2pCLE1BQU1rQixnQkFBZ0I7QUFDckMsUUFBTUMsTUFBTTVELGVBQWV5QyxNQUFNb0IsUUFBUTtBQUV6QyxTQUNFLHVCQUFDLFNBQUksV0FBVSxpQkFFYjtBQUFBLDJCQUFDLFNBQUksV0FBVSwrQkFDYjtBQUFBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxJQUFHO0FBQUEsVUFDSCxXQUFVO0FBQUEsVUFFVjtBQUFBLG1DQUFDLGFBQVUsTUFBTSxJQUFJLGVBQVcsUUFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBZ0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUpsQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFNQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLGdEQUNiO0FBQUE7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE1BQUs7QUFBQSxZQUNMLFNBQVMsTUFBTTlCLFlBQVksSUFBSTtBQUFBLFlBQy9CLFdBQVU7QUFBQSxZQUVWO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsS0FBS3BCLGFBQWE4QixNQUFNcUIsT0FBT2xDLE1BQU0sQ0FBQztBQUFBLGtCQUN0QyxLQUFLYSxNQUFNcUIsT0FBT2xDLE1BQU0sRUFBRW1DO0FBQUFBLGtCQUMxQixVQUFVdEIsTUFBTW9CO0FBQUFBLGtCQUNoQixNQUFNcEIsTUFBTXFCLE9BQU9sQyxNQUFNLEVBQUVvQztBQUFBQSxrQkFDM0I7QUFBQSxrQkFDQSxXQUFVO0FBQUEsa0JBQ1YsY0FBYTtBQUFBO0FBQUEsZ0JBUGY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBT3FCO0FBQUEsY0FFckIsdUJBQUMsVUFBSyxXQUFVLDhHQUNidkI7QUFBQUEsc0JBQU1xQixPQUFPbEMsTUFBTSxFQUFFcUM7QUFBQUEsZ0JBQU07QUFBQSxtQkFEOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBO0FBQUE7QUFBQSxVQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFpQkE7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSx3REFDWnhCLGdCQUFNcUIsT0FBT0ksTUFBTSxHQUFHLENBQUMsRUFBRUM7QUFBQUEsVUFBSSxDQUFDQyxLQUFLQyxNQUNsQztBQUFBLFlBQUM7QUFBQTtBQUFBLGNBRUMsTUFBSztBQUFBLGNBQ0wsU0FBUyxNQUFNeEMsVUFBVXdDLENBQUM7QUFBQSxjQUMxQixjQUFZLFFBQVFELElBQUlILEtBQUs7QUFBQSxjQUM3QixnQkFBY0ksTUFBTXpDO0FBQUFBLGNBQ3BCLFdBQVdyQjtBQUFBQSxnQkFDVDtBQUFBLGdCQUNBOEQsTUFBTXpDLFNBQVMsYUFBYTtBQUFBLGNBQzlCO0FBQUEsY0FFQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxLQUFLakIsYUFBYXlELEdBQUc7QUFBQSxrQkFDckIsS0FBSTtBQUFBLGtCQUNKLFVBQVUzQixNQUFNb0I7QUFBQUEsa0JBQ2hCLFdBQVU7QUFBQTtBQUFBLGdCQUpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUkyRDtBQUFBO0FBQUEsWUFkdERPLElBQUlFLE1BQU1EO0FBQUFBLFlBRGpCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFpQkE7QUFBQSxRQUNELEtBcEJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFxQkE7QUFBQSxXQXpDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBMENBO0FBQUEsTUFFQSx1QkFBQyxPQUFFLFdBQVUsMkJBQ1Y1QixnQkFBTThCLFlBQ0gseUVBQ0Esd0NBSE47QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUlBO0FBQUEsU0F6REY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTBEQTtBQUFBLElBR0EsdUJBQUMsU0FBSSxXQUFVLHNFQUNiO0FBQUEsNkJBQUMsU0FDQztBQUFBLCtCQUFDLFNBQUksV0FBVSxxQ0FDYjtBQUFBLGlDQUFDLFVBQUssV0FBV2hFLEdBQUcsa0RBQWtEcUQsSUFBSVksSUFBSSxHQUMzRWxFLDJCQUFpQm1DLE1BQU1nQyxTQUFTLEtBRG5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNDZixVQUFVLHVCQUFDLFVBQUssV0FBVSxvRUFBbUUsd0JBQW5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJGO0FBQUEsVUFDdEcsdUJBQUMscUJBQWtCLGNBQWNqQixNQUFNYyxnQkFBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBb0Q7QUFBQSxVQUNwRCx1QkFBQyxjQUFXLGNBQWNkLE1BQU1pQyxnQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNkM7QUFBQSxhQU4vQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBT0E7QUFBQSxRQUVBLHVCQUFDLFFBQUcsV0FBVSxrRUFBa0VqRSxvQkFBVWdDLE9BQU9kLFFBQVEsS0FBekc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEyRztBQUFBLFFBRTNHO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxJQUFJLGFBQWFnQixTQUFTN0IsRUFBRTtBQUFBLFlBQzVCLFdBQVU7QUFBQSxZQUVWO0FBQUEscUNBQUMsYUFBVSxNQUFNLElBQUksZUFBVyxRQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFnQztBQUFBLGNBQy9CNkIsU0FBU2dDO0FBQUFBLGNBQ1YsdUJBQUMsVUFBSyxXQUFVLGNBQWE7QUFBQTtBQUFBLGdCQUFHaEMsU0FBU2lDO0FBQUFBLG1CQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFpRDtBQUFBO0FBQUE7QUFBQSxVQU5uRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFPQTtBQUFBLFFBRUEsdUJBQUMsT0FBRSxXQUFVLDREQUNYO0FBQUEsaUNBQUMsVUFBTyxNQUFNLElBQUksZUFBVyxRQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE2QjtBQUFBLFVBQzVCakMsU0FBU2tDO0FBQUFBLFVBQUs7QUFBQSxVQUFHbEMsU0FBU21DO0FBQUFBLFVBQVM7QUFBQSxVQUFJbkMsU0FBU29DO0FBQUFBLGFBRm5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBRUEsdUJBQUMsT0FBRSxXQUFVLHNDQUFzQ3JFLDJCQUFpQitCLE9BQU9kLFFBQVEsS0FBbkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFxRjtBQUFBLFFBR3JGLHVCQUFDLFdBQVEsT0FBTSxhQUNiLGlDQUFDLFFBQUcsV0FBVSx3R0FDWHFELG1CQUFTMUMsT0FBTyxFQUFFNkI7QUFBQUEsVUFBSSxDQUFDYyxRQUN0Qix1QkFBQyxTQUFvQixXQUFVLHdCQUM3QjtBQUFBLG1DQUFDLFFBQUcsV0FBVSxzQkFBc0JBLGNBQUloQixTQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE4QztBQUFBLFlBQzlDLHVCQUFDLFFBQUcsV0FBVSxrQ0FBa0NnQixjQUFJQyxTQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEwRDtBQUFBLGVBRmxERCxJQUFJaEIsT0FBZDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsUUFDRCxLQU5IO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFPQSxLQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFTQTtBQUFBLFFBRUN4QixNQUFNMEMsVUFBVUMsU0FBUyxLQUN4Qix1QkFBQyxXQUFRLE9BQU0sbUJBQ2IsaUNBQUMsUUFBRyxXQUFVLHdCQUNYM0MsZ0JBQU0wQyxVQUFVaEIsSUFBSSxDQUFDa0IsUUFBUTtBQUM1QixnQkFBTSxFQUFFcEIsT0FBT3FCLE1BQU1DLEtBQUssSUFBSXhGLFVBQVVzRixHQUFHO0FBQzNDLGlCQUNFO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FFQyxXQUFVO0FBQUEsY0FFVjtBQUFBLHVDQUFDLFFBQUssTUFBTSxJQUFJLFdBQVUsY0FBYSxlQUFXLFFBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWtEO0FBQUEsZ0JBQ2pEcEI7QUFBQUE7QUFBQUE7QUFBQUEsWUFKSW9CO0FBQUFBLFlBRFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU1BO0FBQUEsUUFFSixDQUFDLEtBWkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWFBLEtBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWVBO0FBQUEsUUFHRDVDLE1BQU1vQixhQUFhLFlBQVlwQixNQUFNK0MsU0FDcEMsdUJBQUMsV0FBUSxPQUFNLG1CQUNiLGlDQUFDLFFBQUcsV0FBVSx3QkFDWjtBQUFBLGlDQUFDLFlBQVMsSUFBSS9DLE1BQU0rQyxNQUFNQyxlQUFlLEtBQUksb0JBQW1CLElBQUcsc0JBQW5FO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXFGO0FBQUEsVUFDckYsdUJBQUMsWUFBUyxJQUFJaEQsTUFBTStDLE1BQU1FLGlCQUFpQixLQUFJLHFCQUFvQixJQUFHLGtCQUF0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFvRjtBQUFBLFVBQ25GakQsTUFBTStDLE1BQU1HLG1CQUFtQix1QkFBQyxZQUFTLElBQUUsTUFBQyxLQUFJLG9CQUFtQixJQUFHLE1BQXZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXlDO0FBQUEsVUFDeEVsRCxNQUFNK0MsTUFBTUkscUJBQXFCLFNBQ2hDO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQztBQUFBLGNBQ0EsS0FBS25ELE1BQU0rQyxNQUFNSSxxQkFBcUIsU0FBUyxhQUFhO0FBQUEsY0FDNUQsSUFBRztBQUFBO0FBQUEsWUFITDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFHTztBQUFBLFVBR1JuRCxNQUFNK0MsTUFBTUssZ0JBQ1gsdUJBQUMsWUFBUyxJQUFFLE1BQUMsS0FBSyxTQUFTcEQsTUFBTStDLE1BQU1LLFlBQVksV0FBVyxJQUFHLE1BQWpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1FO0FBQUEsYUFadkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWNBLEtBZkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWdCQTtBQUFBLFFBR0RsRCxTQUFTbUQsT0FBT1YsU0FBUyxLQUN4Qix1QkFBQyxXQUFRLE9BQU0sa0JBQ2IsaUNBQUMsUUFBRyxXQUFVLDRGQUNYekMsbUJBQVNtRCxPQUFPM0I7QUFBQUEsVUFBSSxDQUFDNEIsTUFDcEIsdUJBQUMsUUFBaUIsV0FBVSxrRUFDMUI7QUFBQSxtQ0FBQyxVQUFLLFdBQVUsaUJBQWlCQSxZQUFFOUIsU0FBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBeUM7QUFBQSxZQUN6Qyx1QkFBQyxVQUFLLFdBQVUsK0JBQStCOEI7QUFBQUEsZ0JBQUVDO0FBQUFBLGNBQUc7QUFBQSxpQkFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBdUQ7QUFBQSxlQUZoREQsRUFBRTlCLE9BQVg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFFBQ0QsS0FOSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBT0EsS0FSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBU0E7QUFBQSxRQUdEN0IsU0FBU2dELFNBQVMsS0FDakIsdUJBQUMsV0FBUSxPQUFPLFdBQVd6QyxTQUFTZ0MsSUFBSSxJQUN0QyxpQ0FBQyxRQUFHLFdBQVUsYUFDWHZDLG1CQUFTOEIsTUFBTSxHQUFHLENBQUMsRUFBRUM7QUFBQUEsVUFBSSxDQUFDcEIsTUFDekIsdUJBQUMsUUFDQztBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsSUFBSSxVQUFVQSxFQUFFakMsRUFBRTtBQUFBLGNBQ2xCLFdBQVU7QUFBQSxjQUVWO0FBQUEsdUNBQUMsU0FBSSxLQUFLaUMsRUFBRWUsT0FBTyxDQUFDLEVBQUVRLEtBQUssS0FBSSxJQUFHLFdBQVUsOENBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXNGO0FBQUEsZ0JBQ3RGLHVCQUFDLFNBQUksV0FBVSxrQkFDYjtBQUFBLHlDQUFDLE9BQUUsV0FBVSxtQ0FBbUN2QixZQUFFNEIsUUFBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBdUQ7QUFBQSxrQkFDdkQsdUJBQUMsT0FBRSxXQUFVLCtCQUErQnJFLDJCQUFpQnlDLEVBQUUwQixTQUFTLEtBQXhFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTBFO0FBQUEscUJBRjVFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBR0E7QUFBQSxnQkFDQSx1QkFBQyxVQUFLLFdBQVUsb0NBQW9DeEUsZ0JBQU04QyxFQUFFa0QsS0FBS0MsS0FBSyxLQUF0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF3RTtBQUFBLGdCQUN4RSx1QkFBQyxnQkFBYSxNQUFNLElBQUksV0FBVSx1QkFBc0IsZUFBVyxRQUFuRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFtRTtBQUFBO0FBQUE7QUFBQSxZQVZyRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFXQSxLQVpPbkQsRUFBRWpDLElBQVg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFhQTtBQUFBLFFBQ0QsS0FoQkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWlCQSxLQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBbUJBO0FBQUEsUUFHRix1QkFBQyxXQUFRLE9BQU0sU0FDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSwyRUFDYjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsV0FBV1A7QUFBQUEsa0JBQ1Q7QUFBQSxrQkFDQXlDLE1BQU1tRCxlQUFlLFVBQVU7QUFBQSxrQkFDL0JuRCxNQUFNbUQsZUFBZSxTQUFTO0FBQUEsa0JBQzlCbkQsTUFBTW1ELGVBQWUsV0FBVztBQUFBLGtCQUNoQ25ELE1BQU1tRCxlQUFlLFdBQVc7QUFBQSxrQkFDaENuRCxNQUFNbUQsZUFBZSxVQUFVO0FBQUEsZ0JBQ2pDO0FBQUEsZ0JBRUNuRCxnQkFBTTJCLEtBQUt5QixPQUFPLENBQUM7QUFBQTtBQUFBLGNBVnRCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVdBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsVUFDYjtBQUFBLHFDQUFDLE9BQUUsV0FBVSwwQkFBMEJwRCxnQkFBTTJCLFFBQTdDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWtEO0FBQUEsY0FDbEQsdUJBQUMsT0FBRSxXQUFVLGlDQUFpQzNCLGdCQUFNcUQsUUFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBeUQ7QUFBQSxjQUN6RCx1QkFBQyxPQUFFLFdBQVUsbUNBQWlDO0FBQUE7QUFBQSxnQkFDaENyRCxNQUFNc0Q7QUFBQUEsZ0JBQWE7QUFBQSxnQkFBaUN0RCxNQUFNdUQ7QUFBQUEsZ0JBQWtCO0FBQUEsbUJBRDFGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLE9BQUUsV0FBVSwyQ0FBeUM7QUFBQTtBQUFBLGdCQUN0Q3ZELE1BQU0wQixhQUFhOEIsUUFBUSxLQUFLLEdBQUc7QUFBQSxnQkFBRTtBQUFBLG1CQURyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUdBO0FBQUEsaUJBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFVQTtBQUFBLGVBdkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBd0JBO0FBQUEsVUFFQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsV0FBVTtBQUFBLGNBQ1YsU0FBUyxNQUFNQyxNQUFNLGdGQUFnRjtBQUFBLGNBRXJHO0FBQUEsdUNBQUMsUUFBSyxNQUFNLElBQUksZUFBVyxRQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUEyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBTDdCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU9BO0FBQUEsYUFsQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQW1DQTtBQUFBLFdBdEpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF1SkE7QUFBQSxNQUdBLHVCQUFDLFdBQU0sV0FBVSxxQ0FDZHJEO0FBQUFBLGlCQUNDLHVCQUFDLFNBQUksV0FBVSx5REFDYjtBQUFBLGlDQUFDLGFBQVUsT0FBT0EsTUFBTXNELFNBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQThCO0FBQUEsVUFDOUIsdUJBQUMsUUFBRyxXQUFVLG1DQUFrQywwQ0FBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMEU7QUFBQSxVQUMxRSx1QkFBQyxRQUFHLFdBQVUsb0JBQ1h0RCxnQkFBTXVELFFBQVF4QztBQUFBQSxZQUFJLENBQUN5QyxNQUNsQix1QkFBQyxhQUFzQixRQUFRQSxLQUFmQSxFQUFFdkIsS0FBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBaUM7QUFBQSxVQUNsQyxLQUhIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBSUE7QUFBQSxVQUNBLHVCQUFDLE9BQUUsV0FBVSx5RUFBdUUsZ0tBQXBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxhQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFZQTtBQUFBLFFBR0YsdUJBQUMsU0FBSSxXQUFVLG9EQUNiO0FBQUEsaUNBQUMsT0FBRSxXQUFVLHNEQUNWcEY7QUFBQUEsa0JBQU13QyxNQUFNd0QsS0FBS0MsS0FBSztBQUFBLFlBQ3RCLENBQUN4QyxVQUFVLHVCQUFDLFVBQUssV0FBVSxvQ0FBbUMsc0JBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXlEO0FBQUEsZUFGdkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFVBQ0EsdUJBQUMsT0FBRSxXQUFVLDJCQUEyQnJELDJCQUFpQm9DLE1BQU1jLGFBQWFzRCxhQUFhLEtBQXpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJGO0FBQUEsVUFDMUZwRSxNQUFNYyxhQUFhdUQsUUFDbEIsdUJBQUMsT0FBRSxXQUFVLDRDQUE0Q3JFLGdCQUFNYyxhQUFhdUQsUUFBNUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBaUY7QUFBQSxVQUdsRixDQUFDcEQsVUFDQSxtQ0FDRTtBQUFBLG1DQUFDLFFBQUcsV0FBVSxtQ0FBa0MsNEJBQWhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTREO0FBQUEsWUFDNUQsdUJBQUMsUUFBRyxXQUFVLDRCQUNaO0FBQUEscUNBQUMsV0FBUSxPQUFNLFFBQU8sT0FBT3pELE1BQU13QyxNQUFNd0QsS0FBS0MsS0FBSyxLQUFuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFxRDtBQUFBLGNBQ3JEO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE9BQU07QUFBQSxrQkFDTixPQUFPekQsTUFBTXdELEtBQUtjLGtCQUFrQixPQUFPOUcsTUFBTXdDLE1BQU13RCxLQUFLYyxhQUFhLElBQUk7QUFBQSxrQkFDN0UsT0FBT3RFLE1BQU13RCxLQUFLYyxrQkFBa0I7QUFBQTtBQUFBLGdCQUh0QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FHMkM7QUFBQSxjQUUzQztBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxPQUFNO0FBQUEsa0JBQ04sT0FBT3RFLE1BQU13RCxLQUFLZSxjQUFjLE9BQU8vRyxNQUFNd0MsTUFBTXdELEtBQUtlLFNBQVMsSUFBSTtBQUFBLGtCQUNyRSxPQUFPdkUsTUFBTXdELEtBQUtlLGNBQWM7QUFBQTtBQUFBLGdCQUhsQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FHdUM7QUFBQSxpQkFWekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFZQTtBQUFBLFlBRUEsdUJBQUMsU0FBSSxXQUFVLHNDQUNadkUsZ0JBQU13RCxLQUFLZ0IsbUJBQ1YsdUJBQUMsU0FBSSxXQUFVLHVDQUNiO0FBQUEscUNBQUMsVUFBSyxXQUFVLGtDQUFpQywrQkFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBZ0U7QUFBQSxjQUNoRSx1QkFBQyxVQUFLLFdBQVUscURBQ2JoSCxnQkFBTXdDLE1BQU13RCxLQUFLZ0IsZ0JBQWdCLEtBRHBDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUtBLElBRUEsbUNBQ0U7QUFBQSxxQ0FBQyxPQUFFLFdBQVUsMEVBQXdFLHVGQUFyRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxJQUFHO0FBQUEsa0JBQ0gsVUFBUztBQUFBLGtCQUNULFNBQVE7QUFBQSxrQkFDUixXQUFVO0FBQUE7QUFBQSxnQkFKWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FJa0I7QUFBQSxpQkFScEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFVQSxLQW5CSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXFCQTtBQUFBLFlBRUEsdUJBQUMsUUFBRyxXQUFVLDBEQUNYeEU7QUFBQUEsb0JBQU13RCxLQUFLaUIsa0JBQWtCLFFBQzVCO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE9BQU07QUFBQSxrQkFDTixPQUFPLEdBQUd6RSxNQUFNd0QsS0FBS2lCLGFBQWEsU0FBU3pFLE1BQU13RCxLQUFLaUIsZ0JBQWdCLElBQUksTUFBTSxFQUFFO0FBQUE7QUFBQSxnQkFGcEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBRXVGO0FBQUEsY0FHekY7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsT0FBTTtBQUFBLGtCQUNOLE9BQU96RSxNQUFNd0QsS0FBS2tCLG9CQUFvQixPQUFPbEgsTUFBTXdDLE1BQU13RCxLQUFLa0IsZUFBZSxJQUFJO0FBQUEsa0JBQ2pGLE9BQU8xRSxNQUFNd0QsS0FBS2tCLG9CQUFvQjtBQUFBO0FBQUEsZ0JBSHhDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUc2QztBQUFBLGlCQVYvQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVlBO0FBQUEsZUFuREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFvREE7QUFBQSxVQUdGLHVCQUFDLFNBQUksV0FBVSx5Q0FDWmxFO0FBQUFBLHFCQUNDLHVCQUFDLFFBQUssSUFBSSxVQUFVUixNQUFNM0IsRUFBRSxTQUMxQixpQ0FBQyxVQUFPLFdBQVMsTUFBQyxTQUFRLGFBQ3hCO0FBQUEscUNBQUMsVUFBTyxNQUFNLElBQUksZUFBVyxRQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE2QjtBQUFBLGNBQzVCWSxFQUFFLGFBQWE7QUFBQSxpQkFGbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQSxLQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBS0EsSUFFQSxtQ0FDRTtBQUFBLHFDQUFDLFVBQU8sV0FBUyxNQUFDLFNBQVMsTUFBTVMsZUFBZSxJQUFJLEdBQUcsVUFBVSxDQUFDbUIsVUFDaEU7QUFBQSx1Q0FBQyxpQkFBYyxNQUFNLElBQUksZUFBVyxRQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFvQztBQUFBLGdCQUNuQzVCLEVBQUUsaUJBQWlCO0FBQUEsbUJBRnRCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0E7QUFBQSxjQUNBLHVCQUFDLFVBQU8sV0FBUyxNQUFDLFNBQVEsYUFBWSxTQUFTLE1BQU1PLGVBQWUsSUFBSSxHQUNyRVAsWUFBRSxvQkFBb0IsS0FEekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0MsQ0FBQzRCLFlBQ0EsdUJBQUMsT0FBRSxXQUFVLGtDQUFrQzVCLFlBQUUsc0JBQXNCLEtBQXZFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXlFO0FBQUEsaUJBVDdFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBV0E7QUFBQSxZQUVGLHVCQUFDLFNBQUksV0FBVSwwQkFDYjtBQUFBLHFDQUFDLFVBQU8sU0FBUSxhQUFZLFNBQVMsTUFBTSxLQUFLTCxZQUFZb0IsTUFBTTNCLEVBQUUsR0FDbEU7QUFBQSx1Q0FBQyxZQUFTLE1BQU0sSUFBSSxXQUFXUCxHQUFHOEMsU0FBUyw2QkFBNkIsR0FBRyxlQUFXLFFBQXRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXNGO0FBQUEsZ0JBQ3JGQSxRQUFRLFVBQVU7QUFBQSxtQkFGckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFHQTtBQUFBLGNBQ0EsdUJBQUMsVUFBTyxTQUFRLGFBQVksU0FBUyxNQUFNOUIsY0FBY2tCLE1BQU0zQixFQUFFLEdBQy9EO0FBQUEsdUNBQUMsU0FBTSxNQUFNLElBQUksZUFBVyxRQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUE0QjtBQUFBLGdCQUMzQjJDLFlBQVksVUFBVTtBQUFBLG1CQUZ6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUdBO0FBQUEsaUJBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFTQTtBQUFBLGVBL0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBZ0NBO0FBQUEsVUFFQSx1QkFBQyxPQUFFLFdBQVdsRCxHQUFHLGdCQUFnQkgsUUFBUXFDLE1BQU0yRSxXQUFXLElBQUksOEJBQThCLFlBQVksR0FDckdqSDtBQUFBQSw2QkFBaUJzQyxNQUFNMkUsV0FBVztBQUFBLFlBQUU7QUFBQSxZQUFJM0UsTUFBTTRFO0FBQUFBLFlBQU07QUFBQSxZQUFVNUUsTUFBTTZFO0FBQUFBLFlBQWE7QUFBQSxlQURwRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUF0R0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXVHQTtBQUFBLFdBeEhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF5SEE7QUFBQSxTQXBSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBcVJBO0FBQUEsSUFHQSx1QkFBQyxTQUFJLFdBQVUscUdBQ2IsaUNBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLGtCQUNiO0FBQUEsK0JBQUMsT0FBRSxXQUFVLHlEQUNWckg7QUFBQUEsZ0JBQU13QyxNQUFNd0QsS0FBS0MsS0FBSztBQUFBLFVBQ3RCLENBQUN4QyxVQUFVLHVCQUFDLFVBQUssV0FBVSxrQ0FBaUMsbUJBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW9EO0FBQUEsYUFGbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFDQ04sU0FBUyx1QkFBQyxPQUFFLFdBQVUsOEJBQThCQTtBQUFBQSxnQkFBTXNEO0FBQUFBLFVBQU07QUFBQSxhQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQThEO0FBQUEsV0FMMUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU1BO0FBQUEsTUFDQSx1QkFBQyxVQUFPLFNBQVEsYUFBWSxNQUFLLE1BQUssU0FBUyxNQUFNLEtBQUtyRixZQUFZb0IsTUFBTTNCLEVBQUUsR0FBRyxjQUFXLFFBQzFGLGlDQUFDLFlBQVMsTUFBTSxJQUFJLFdBQVdQLEdBQUc4QyxTQUFTLDZCQUE2QixHQUFHLGVBQVcsUUFBdEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFzRixLQUR4RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNDSixTQUNDLHVCQUFDLFFBQUssSUFBSSxVQUFVUixNQUFNM0IsRUFBRSxTQUMxQixpQ0FBQyxVQUFPLE1BQUssTUFBSyxTQUFRLGFBQ3hCO0FBQUEsK0JBQUMsVUFBTyxNQUFNLElBQUksZUFBVyxRQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTZCO0FBQUEsUUFDNUJZLEVBQUUsYUFBYTtBQUFBLFdBRmxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQSxLQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLQSxJQUVBLHVCQUFDLFVBQU8sTUFBSyxNQUFLLFNBQVMsTUFBTU8sZUFBZSxJQUFJLEdBQ2pEUCxZQUFFLG9CQUFvQixLQUR6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxTQXJCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBdUJBLEtBeEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F5QkE7QUFBQSxJQUVBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxNQUFNSTtBQUFBQSxRQUNOLFNBQVMsTUFBTUMsWUFBWSxLQUFLO0FBQUEsUUFDaEM7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBO0FBQUEsTUFMRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFLdUI7QUFBQSxJQUd2QjtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsTUFBTUc7QUFBQUEsUUFDTixTQUFTLE1BQU1DLGVBQWUsS0FBSztBQUFBLFFBQ25DO0FBQUEsUUFDQTtBQUFBO0FBQUEsTUFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFJNkI7QUFBQSxJQUc3QjtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsTUFBTUg7QUFBQUEsUUFDTixTQUFTLE1BQU1DLGVBQWUsS0FBSztBQUFBLFFBQ25DO0FBQUEsUUFDQSxRQUFRVDtBQUFBQSxRQUNSO0FBQUE7QUFBQSxNQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUs2QjtBQUFBLE9BdFkvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBd1lBO0FBRUo7QUFJQVgsR0FuY3dCRCxhQUFXO0FBQUEsVUFDYnZDLFdBQ0hELGFBRWZlLFdBQ2tCRSxTQUNJbUIsT0FBTztBQUFBO0FBQUEsS0FOVEk7QUFvY3hCLFNBQVMyRyxTQUFTLEVBQUVDLElBQUlDLEtBQUtDLEdBQTZDLEdBQUc7QUFDM0UsU0FDRTtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0MsV0FBV25IO0FBQUFBLFFBQ1Q7QUFBQSxRQUNBaUgsS0FBSywwQkFBMEI7QUFBQSxNQUNqQztBQUFBLE1BRUNBO0FBQUFBLGFBQUssdUJBQUMsU0FBTSxNQUFNLElBQUksZUFBVyxRQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTRCLElBQU0sdUJBQUMsS0FBRSxNQUFNLElBQUksZUFBVyxRQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXdCO0FBQUEsUUFDL0RBLEtBQUtDLE1BQU1DO0FBQUFBO0FBQUFBO0FBQUFBLElBUGQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBUUE7QUFFSjtBQUFDQyxNQVpRSjtBQWNULFNBQVNLLFFBQVEsRUFBRUMsT0FBT0MsU0FBdUQsR0FBRztBQUNsRixTQUNFLHVCQUFDLGFBQVEsV0FBVSxRQUNqQjtBQUFBLDJCQUFDLFFBQUcsV0FBVSxnREFBZ0RELG1CQUE5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQW9FO0FBQUEsSUFDbkVDO0FBQUFBLE9BRkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUdBO0FBRUo7QUFBQ0MsTUFQUUg7QUFTVCxTQUFTNUMsU0FBUzFDLFNBQWdFO0FBQ2hGLFFBQU0wRixJQUFJMUYsUUFBUUcsTUFBTXdGO0FBQ3hCLFFBQU1DLE9BQWdEO0FBQ3RELFFBQU1DLE1BQU1BLENBQUNsRSxPQUFlaUIsVUFBaUQ7QUFDM0UsUUFBSUEsVUFBVWtELFVBQWFsRCxVQUFVLFFBQVFBLFVBQVUsTUFBTztBQUM5RGdELFNBQUtHLEtBQUssRUFBRXBFLE9BQU9pQixPQUFPLE9BQU9BLFVBQVUsWUFBWSxRQUFRb0QsT0FBT3BELEtBQUssRUFBRSxDQUFDO0FBQUEsRUFDaEY7QUFFQSxVQUFRNUMsUUFBUUcsTUFBTW9CLFVBQVE7QUFBQSxJQUM1QixLQUFLO0FBQ0hzRSxVQUFJLFlBQVlILEVBQUVPLFFBQVE7QUFDMUJKLFVBQUksYUFBYUgsRUFBRVEsU0FBUztBQUM1QkwsVUFBSSxRQUFRSCxFQUFFUyxXQUFXLEdBQUdULEVBQUVTLFFBQVEsVUFBVUwsTUFBUztBQUN6REQsVUFBSSxTQUFTSCxFQUFFVSxLQUFLO0FBQ3BCUCxVQUFJLGNBQWNILEVBQUVXLFlBQVluQyxRQUFRLEtBQUssR0FBRyxDQUFDO0FBQ2pEMkIsVUFBSSxXQUFXSCxFQUFFWSxPQUFPO0FBQ3hCO0FBQUEsSUFDRixLQUFLO0FBQ0hULFVBQUksUUFBUUgsRUFBRVMsV0FBVyxHQUFHVCxFQUFFUyxRQUFRLFVBQVVMLE1BQVM7QUFDekRELFVBQUksU0FBU0gsRUFBRVUsVUFBVSxJQUFJLFdBQVdWLEVBQUVVLEtBQUs7QUFDL0NQLFVBQUksWUFBWUgsRUFBRWEsYUFBYSxHQUFHYixFQUFFYSxVQUFVLFFBQVFULE1BQVM7QUFDL0RELFVBQUksZ0JBQWdCSCxFQUFFYyxZQUFZO0FBQ2xDWCxVQUFJLGdCQUFnQkgsRUFBRWUsV0FBVztBQUNqQ1osVUFBSSxTQUFTSCxFQUFFZ0IsV0FBVztBQUMxQjtBQUFBLElBQ0YsS0FBSztBQUNIYixVQUFJLGdCQUFnQkgsRUFBRVMsV0FBVyxHQUFHVCxFQUFFUyxRQUFRLFVBQVVMLE1BQVM7QUFDakVELFVBQUksV0FBV0gsRUFBRWlCLGtCQUFrQixHQUFHakIsRUFBRWlCLGVBQWUsUUFBUWIsTUFBUztBQUN4RUQsVUFBSSxrQkFBa0JILEVBQUVrQixhQUFhO0FBQ3JDZixVQUFJLGtCQUFrQkgsRUFBRW1CLGFBQWE7QUFDckNoQixVQUFJLFNBQVNILEVBQUVnQixXQUFXO0FBQzFCO0FBQUEsSUFDRixLQUFLO0FBQ0hiLFVBQUksYUFBYUgsRUFBRW9CLFFBQVE7QUFDM0JqQixVQUFJLG9CQUFvQkgsRUFBRXFCLGVBQWU7QUFDekNsQixVQUFJLFNBQVNILEVBQUVzQixVQUFVLFlBQVksTUFBTTtBQUMzQ25CLFVBQUksVUFBVUgsRUFBRXVCLFdBQVc7QUFDM0I7QUFBQSxJQUNGLEtBQUs7QUFDSHBCLFVBQUksYUFBYUgsRUFBRXdCLGtCQUFrQixHQUFHeEIsRUFBRXdCLGVBQWUsYUFBYXBCLE1BQVM7QUFDL0VELFVBQUksT0FBT0gsRUFBRXlCLE9BQU87QUFDcEJ0QixVQUFJLGVBQWVILEVBQUUwQixVQUFVO0FBQy9CdkIsVUFBSSxnQkFBZ0JILEVBQUUyQixXQUFXO0FBQ2pDeEIsVUFBSSxTQUFTSCxFQUFFNEIsYUFBYSxHQUFHNUIsRUFBRTRCLFVBQVUsV0FBV3hCLE1BQVM7QUFDL0Q7QUFBQSxFQUNKO0FBRUEsTUFBSUYsS0FBSzlDLFdBQVcsRUFBRzhDLE1BQUtHLEtBQUssRUFBRXBFLE9BQU8sV0FBV2lCLE9BQU9yRixRQUFReUMsT0FBTyxFQUFFLENBQUM7QUFDOUUsU0FBTzRGO0FBQ1Q7QUFFQSxNQUFNMkIsVUFBVTtBQUFBLEVBQ2RDLEtBQUssRUFBRXZFLE1BQU03RyxPQUFPcUwsV0FBVyxjQUFjO0FBQUEsRUFDN0NDLFNBQVMsRUFBRXpFLE1BQU01RyxPQUFPb0wsV0FBVyxnQkFBZ0I7QUFBQSxFQUNuREUsUUFBUSxFQUFFMUUsTUFBTTNHLEdBQUdtTCxXQUFXLGtCQUFrQjtBQUNsRDtBQUVBLFNBQVNHLFVBQVUsRUFBRUMsT0FBZ0MsR0FBRztBQUN0RCxRQUFNLEVBQUU1RSxNQUFNd0UsVUFBVSxJQUFJRixRQUFRTSxPQUFPQyxPQUFPO0FBQ2xELFFBQU1DLFNBQVNGLE9BQU96RCxRQUFReUQsT0FBT0c7QUFDckMsUUFBTXJHLFFBQVFzRyxLQUFLQyxJQUFJSCxTQUFTRSxLQUFLRSxNQUFNSixNQUFNLENBQUMsSUFBSSxPQUFPL0IsT0FBT2lDLEtBQUtFLE1BQU1KLE1BQU0sQ0FBQyxJQUFJQSxPQUFPSyxRQUFRLENBQUM7QUFFMUcsU0FDRSx1QkFBQyxRQUFHLFdBQVUsd0JBQ1o7QUFBQSwyQkFBQyxRQUFLLE1BQU0sSUFBSSxXQUFXbkssR0FBRyxtQkFBbUJ3SixTQUFTLEdBQUcsZUFBVyxRQUF4RTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXdFO0FBQUEsSUFDeEUsdUJBQUMsVUFBSyxXQUFVLHFDQUNkO0FBQUEsNkJBQUMsVUFBSyxXQUFVLDBCQUEwQkksaUJBQU9sRyxTQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXVEO0FBQUEsTUFDdkQsdUJBQUMsVUFBSyxXQUFVLCtCQUE4QixlQUFXLE1BQUMsaUJBQTFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMkQ7QUFBQSxNQUMxRGtHLE9BQU9RO0FBQUFBLFNBSFY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUlBO0FBQUEsSUFDQSx1QkFBQyxVQUFLLFdBQVUsa0RBQ2IxRztBQUFBQTtBQUFBQSxNQUFNO0FBQUEsTUFBRWtHLE9BQU9HO0FBQUFBLFNBRGxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLE9BVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVVBO0FBRUo7QUFBQ00sTUFsQlFWO0FBb0JULFNBQVNXLFFBQVEsRUFBRTVHLE9BQU9pQixPQUFPNEYsTUFBeUQsR0FBRztBQUMzRixTQUNFLHVCQUFDLFNBQUksV0FBVSw2Q0FDYjtBQUFBLDJCQUFDLFFBQUcsV0FBVSxpQkFBaUI3RyxtQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFxQztBQUFBLElBQ3JDLHVCQUFDLFFBQUcsV0FBVzFELEdBQUcsc0JBQXNCdUssUUFBUSxlQUFlLFVBQVUsR0FBSTVGLG1CQUE3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQW1GO0FBQUEsT0FGckY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUdBO0FBRUo7QUFBQzZGLE1BUFFGO0FBU1QsU0FBU0csU0FBUztBQUFBLEVBQ2hCQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBNUk7QUFBQUEsRUFDQVY7QUFBQUEsRUFDQUM7QUFPRixHQUFHO0FBQUFzSixNQUFBO0FBQ0RuTixZQUFVLE1BQU07QUFDZCxRQUFJLENBQUNpTixLQUFNO0FBQ1gsVUFBTUcsUUFBUUEsQ0FBQ0MsTUFBcUI7QUFDbEMsVUFBSUEsRUFBRWhHLFFBQVEsU0FBVTZGLFNBQVE7QUFDaEMsVUFBSUcsRUFBRWhHLFFBQVEsYUFBY3hELFlBQVdELFNBQVMsS0FBS1UsUUFBUUcsTUFBTXFCLE9BQU9zQixNQUFNO0FBQ2hGLFVBQUlpRyxFQUFFaEcsUUFBUSxZQUFheEQsWUFBV0QsU0FBUyxJQUFJVSxRQUFRRyxNQUFNcUIsT0FBT3NCLFVBQVU5QyxRQUFRRyxNQUFNcUIsT0FBT3NCLE1BQU07QUFBQSxJQUMvRztBQUNBa0csYUFBU0MsaUJBQWlCLFdBQVdILEtBQUs7QUFDMUMsV0FBTyxNQUFNRSxTQUFTRSxvQkFBb0IsV0FBV0osS0FBSztBQUFBLEVBQzVELEdBQUcsQ0FBQ0gsTUFBTUMsU0FBU3RKLFFBQVFDLFdBQVdTLFFBQVFHLE1BQU1xQixPQUFPc0IsTUFBTSxDQUFDO0FBRWxFLE1BQUksQ0FBQzZGLEtBQU0sUUFBTztBQUVsQixTQUNFLHVCQUFDLFNBQUksV0FBVSxrREFBaUQsTUFBSyxVQUFTLGNBQVcsUUFBTyxjQUFXLFVBQ3pHO0FBQUEsMkJBQUMsU0FBSSxXQUFVLGdEQUNiO0FBQUEsNkJBQUMsT0FBRSxXQUFVLHlCQUNWM0k7QUFBQUEsZ0JBQVFHLE1BQU1xQixPQUFPbEMsTUFBTSxFQUFFcUM7QUFBQUEsUUFDOUIsdUJBQUMsVUFBSyxXQUFVLHVDQUNickM7QUFBQUEsbUJBQVM7QUFBQSxVQUFFO0FBQUEsVUFBSVUsUUFBUUcsTUFBTXFCLE9BQU9zQjtBQUFBQSxhQUR2QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLQTtBQUFBLE1BQ0EsdUJBQUMsWUFBTyxNQUFLLFVBQVMsU0FBUzhGLFNBQVMsY0FBVyxTQUFRLFdBQVUsc0NBQ25FLGlDQUFDLEtBQUUsTUFBTSxNQUFUO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBWSxLQURkO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVVBO0FBQUEsSUFFQSx1QkFBQyxTQUFJLFdBQVUsZ0RBQ2I7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLEtBQUs1SSxRQUFRRyxNQUFNcUIsT0FBT2xDLE1BQU0sRUFBRTBDO0FBQUFBLFFBQ2xDLEtBQUtoQyxRQUFRRyxNQUFNcUIsT0FBT2xDLE1BQU0sRUFBRW1DO0FBQUFBLFFBQ2xDLFdBQVU7QUFBQTtBQUFBLE1BSFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBRzhELEtBSmhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FNQTtBQUFBLElBRUEsdUJBQUMsU0FBSSxXQUFVLDZCQUNaekIsa0JBQVFHLE1BQU1xQixPQUFPSztBQUFBQSxNQUFJLENBQUNDLEtBQUtDLE1BQzlCO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFFQyxNQUFLO0FBQUEsVUFDTCxTQUFTLE1BQU14QyxVQUFVd0MsQ0FBQztBQUFBLFVBQzFCLGNBQVksUUFBUUQsSUFBSUgsS0FBSztBQUFBLFVBQzdCLFdBQVcxRDtBQUFBQSxZQUNUO0FBQUEsWUFDQThELE1BQU16QyxTQUFTLGtCQUFrQjtBQUFBLFVBQ25DO0FBQUEsVUFFQSxpQ0FBQyxTQUFJLEtBQUt3QyxJQUFJRSxLQUFLLEtBQUksSUFBRyxXQUFVLDBCQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEwRDtBQUFBO0FBQUEsUUFUckRGLElBQUlFLE1BQU1EO0FBQUFBLFFBRGpCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFXQTtBQUFBLElBQ0QsS0FkSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBZUE7QUFBQSxPQXBDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBcUNBO0FBRUo7QUFFQThHLElBcEVTSCxVQUFRO0FBQUEsTUFBUkE7QUEyRVQsU0FBU1MsYUFBYTtBQUFBLEVBQ3BCUjtBQUFBQSxFQUNBQztBQUFBQSxFQUNBNUk7QUFBQUEsRUFDQXBCO0FBTUYsR0FBRztBQUFBd0ssTUFBQTtBQUNELFFBQU0sRUFBRWhLLEVBQUUsSUFBSWxCLFFBQVE7QUFDdEIsUUFBTU8sV0FBVzNDLFlBQVk7QUFDN0IsUUFBTSxFQUFFcUQsU0FBU2tLLFdBQVcsSUFBSXRNLFFBQVE7QUFFeEMsUUFBTSxDQUFDdU0sUUFBUUMsU0FBUyxJQUFJM04sU0FBU2dELGFBQWE0SyxVQUFVO0FBRzVELFFBQU0sQ0FBQ0MsUUFBUUMsU0FBUyxJQUFJOU4sU0FBUyxFQUFFO0FBQ3ZDLFFBQU0sQ0FBQytOLFNBQVNDLFVBQVUsSUFBSWhPLFNBQVMsRUFBRTtBQUN6QyxRQUFNLENBQUNpTyxTQUFTQyxVQUFVLElBQUlsTyxTQUFTLEtBQUs7QUFDNUMsUUFBTSxDQUFDbU8sT0FBT0MsUUFBUSxJQUFJcE8sU0FBd0IsSUFBSTtBQUV0RCxRQUFNcU8sU0FBU2pLLFFBQVFHLE1BQU13RCxLQUFLQztBQUVsQyxRQUFNc0csU0FBUyxZQUFZO0FBQ3pCSixlQUFXLElBQUk7QUFDZkUsYUFBUyxJQUFJO0FBRWIsUUFBSTtBQUNGLFlBQU1sTixHQUFHcU4sZUFBZTtBQUFBLFFBQ3RCQyxTQUFTcEssUUFBUUcsTUFBTTNCO0FBQUFBLFFBQ3ZCZ0wsWUFBWUY7QUFBQUEsUUFDWkc7QUFBQUEsUUFDQVE7QUFBQUEsUUFDQU4sU0FBU0EsUUFBUVUsS0FBSyxLQUFLdkU7QUFBQUEsTUFDN0IsQ0FBQztBQUNEOEMsY0FBUTtBQUNSbkssZUFBUyxXQUFXO0FBQUEsSUFDdEIsU0FBU3NLLEdBQUc7QUFDVmlCLGVBQVNqQixhQUFhdUIsUUFBUXZCLEVBQUVZLFVBQVV2SyxFQUFFLG1CQUFtQixDQUFDO0FBQUEsSUFDbEUsVUFBQztBQUNDMEssaUJBQVcsS0FBSztBQUFBLElBQ2xCO0FBQUEsRUFDRjtBQUVBLFNBQ0U7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNDO0FBQUEsTUFDQTtBQUFBLE1BQ0EsT0FBTzFLLEVBQUUsc0JBQXNCO0FBQUEsTUFDL0IsUUFDRSx1QkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLCtCQUFDLFVBQU8sU0FBUSxhQUFZLFdBQVMsTUFBQyxTQUFTd0osU0FDNUN4SixZQUFFLGVBQWUsS0FEcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxVQUFPLFdBQVMsTUFBQyxVQUFVeUssU0FBUyxTQUFTLE1BQU0sS0FBS0ssT0FBTyxHQUM3REwsb0JBQVV6SyxFQUFFLGdCQUFnQixJQUFJQSxFQUFFLGlCQUFpQixLQUR0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFPQTtBQUFBLE1BR0Y7QUFBQSwrQkFBQyxPQUFFLFdBQVUseUNBQXlDQSxZQUFFLHFCQUFxQixLQUE3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQStFO0FBQUEsUUFFOUVpSyxjQUFjLENBQUNsSyxXQUNkLHVCQUFDLE9BQUUsV0FBVSx5RUFDVkMsWUFBRSxxQkFBcUIsS0FEMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFHRDJLLFNBQ0MsdUJBQUMsT0FBRSxXQUFVLDZEQUE2REEsbUJBQTFFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ0Y7QUFBQSxRQUdsRix1QkFBQyxTQUFJLFdBQVUsa0NBQ2I7QUFBQSxpQ0FBQyxXQUFNLFdBQVUsU0FDZjtBQUFBLG1DQUFDLFVBQUssV0FBVSxrREFBa0QzSyxZQUFFLGdCQUFnQixLQUFwRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFzRjtBQUFBLFlBQ3RGO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLE9BQU9rSztBQUFBQSxnQkFDUCxVQUFVLENBQUNQLE1BQU1RLFVBQVVSLEVBQUV3QixPQUFPM0gsS0FBSztBQUFBLGdCQUN6QyxXQUFVO0FBQUE7QUFBQSxjQUpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUltSjtBQUFBLGVBTnJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBUUE7QUFBQSxVQUVBLHVCQUFDLFdBQU0sV0FBVSxTQUNmO0FBQUEsbUNBQUMsVUFBSyxXQUFVLGtEQUNieEQsWUFBRSxpQkFBaUIsS0FEdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxPQUFPcUs7QUFBQUEsZ0JBQ1AsVUFBVSxDQUFDVixNQUFNVyxVQUFVYyxPQUFPekIsRUFBRXdCLE9BQU8zSCxLQUFLLENBQUM7QUFBQSxnQkFDakQsV0FBVTtBQUFBLGdCQUVWO0FBQUEseUNBQUMsWUFBTyxPQUFPLEdBQUl4RCxZQUFFLGVBQWUsS0FBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBc0M7QUFBQSxrQkFDdEMsdUJBQUMsWUFBTyxPQUFPLEdBQUlBLFlBQUUsZUFBZSxLQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFzQztBQUFBLGtCQUN0Qyx1QkFBQyxZQUFPLE9BQU8sSUFBS0EsWUFBRSxnQkFBZ0IsS0FBdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBd0M7QUFBQSxrQkFDeEMsdUJBQUMsWUFBTyxPQUFPLElBQUtBLFlBQUUsZ0JBQWdCLEtBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXdDO0FBQUE7QUFBQTtBQUFBLGNBUjFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVNBO0FBQUEsZUFiRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWNBO0FBQUEsYUF6QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTBCQTtBQUFBLFFBRUEsdUJBQUMsV0FBTSxXQUFVLGNBQ2Y7QUFBQSxpQ0FBQyxVQUFLLFdBQVUsa0RBQWtEQSxZQUFFLHFCQUFxQixLQUF6RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEyRjtBQUFBLFVBQzNGO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFNO0FBQUEsY0FDTixPQUFPdUs7QUFBQUEsY0FDUCxVQUFVLENBQUNaLE1BQU1hLFdBQVdiLEVBQUV3QixPQUFPM0gsS0FBSztBQUFBLGNBQzFDLGFBQWF4RCxFQUFFLGlCQUFpQjtBQUFBLGNBQ2hDLFdBQVU7QUFBQTtBQUFBLFlBTFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBSzZJO0FBQUEsYUFQL0k7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVNBO0FBQUEsUUFFQSx1QkFBQyxRQUFHLFdBQVUsNkRBQ1o7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsY0FBY0EsWUFBRSxnQkFBZ0IsS0FBOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0Q7QUFBQSxVQUNoRCx1QkFBQyxRQUFHLFdBQVUsK0JBQ1h6QjtBQUFBQSxrQkFBTXNNLE1BQU07QUFBQSxZQUNaakssUUFBUUcsTUFBTWtCLGdCQUFnQixVQUFVakMsRUFBRSxzQkFBc0I7QUFBQSxlQUZuRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsYUFMRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBTUE7QUFBQSxRQUVBLHVCQUFDLE9BQUUsV0FBVSwyQ0FBMkNBLFlBQUUscUJBQXFCLEtBQS9FO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaUY7QUFBQSxRQUVqRix1QkFBQyxPQUFFLFdBQVUsa0VBQ1g7QUFBQSxpQ0FBQyxTQUFNLE1BQU0sSUFBSSxXQUFVLG1CQUFrQixlQUFXLFFBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdEO0FBQUEsVUFDdkRBLEVBQUUsb0JBQW9CO0FBQUEsYUFGekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUE7QUFBQTtBQUFBLElBL0VGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQWdGQTtBQUVKO0FBQUNnSyxJQWpJUUQsY0FBWTtBQUFBLFVBV0xqTCxTQUNHcEMsYUFDZWlCLE9BQU87QUFBQTtBQUFBLE1BYmhDb007QUFtSVQsU0FBU3NCLGFBQWE7QUFBQSxFQUNwQjlCO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0E1STtBQUFBQSxFQUNBMEs7QUFBQUEsRUFDQTlMO0FBT0YsR0FBRztBQUFBK0wsTUFBQTtBQUNELFFBQU1sTSxXQUFXM0MsWUFBWTtBQUM3QixRQUFNLEVBQUVxRCxTQUFTa0ssV0FBVyxJQUFJdE0sUUFBUTtBQUN4QyxRQUFNLENBQUNzRixNQUFNdUksT0FBTyxJQUFJaFAsU0FBUyxFQUFFO0FBQ25DLFFBQU0sQ0FBQytOLFNBQVNDLFVBQVUsSUFBSWhPLFNBQVMsMERBQTBEO0FBQ2pHLFFBQU0sQ0FBQzBOLFFBQVFDLFNBQVMsSUFBSTNOLFNBQVNnRCxhQUFhNEssVUFBVTtBQUM1RCxRQUFNLENBQUNxQixNQUFNQyxPQUFPLElBQUlsUCxTQUFTLEtBQUs7QUFDdEMsUUFBTSxDQUFDaU8sU0FBU0MsVUFBVSxJQUFJbE8sU0FBUyxLQUFLO0FBQzVDLFFBQU0sQ0FBQ21PLE9BQU9DLFFBQVEsSUFBSXBPLFNBQXdCLElBQUk7QUFFdERGLFlBQVUsTUFBTTtBQUNkLFFBQUl5RCxTQUFTa0QsS0FBTXVJLFNBQVF6TCxRQUFRa0QsSUFBSTtBQUFBLEVBQ3pDLEdBQUcsQ0FBQ2xELE9BQU8sQ0FBQztBQUVaLFFBQU00TCxPQUFPLFlBQVk7QUFDdkJqQixlQUFXLElBQUk7QUFDZkUsYUFBUyxJQUFJO0FBQ2IsUUFBSTtBQUNGLFlBQU1VLE9BQU87QUFBQSxRQUNYTixTQUFTcEssUUFBUUcsTUFBTTNCO0FBQUFBLFFBQ3ZCNkQsTUFBTUEsS0FBS2dJLEtBQUssS0FBS2xMLFNBQVNrRCxRQUFRO0FBQUEsUUFDdENzSDtBQUFBQSxRQUNBSCxZQUFZRjtBQUFBQSxRQUNaMEIsV0FBV3BNLGFBQWFvTTtBQUFBQSxRQUN4QkMsV0FBV3JNLGFBQWFxTTtBQUFBQSxNQUMxQixDQUFDO0FBQ0RILGNBQVEsSUFBSTtBQUFBLElBQ2QsU0FBUy9CLEdBQUc7QUFDVmlCLGVBQVNqQixhQUFhdUIsUUFBUXZCLEVBQUVZLFVBQVUsMkJBQTJCO0FBQUEsSUFDdkUsVUFBQztBQUNDRyxpQkFBVyxLQUFLO0FBQUEsSUFDbEI7QUFBQSxFQUNGO0FBRUEsUUFBTW9CLGFBQWEsWUFBWTtBQUM3QixRQUFJO0FBQ0YsWUFBTTFNLEtBQUssTUFBTTFCLEdBQUdxTyxpQkFBaUJuTCxRQUFRRyxNQUFNM0IsRUFBRTtBQUNyREMsZUFBUyxhQUFhRCxFQUFFLEVBQUU7QUFBQSxJQUM1QixRQUFRO0FBQ05DLGVBQVMsV0FBVztBQUFBLElBQ3RCO0FBQUEsRUFDRjtBQUVBLFFBQU0yTSxRQUFRQSxNQUFNO0FBQ2xCeEMsWUFBUTtBQUNSeUMsV0FBT0MsV0FBVyxNQUFNUixRQUFRLEtBQUssR0FBRyxHQUFHO0FBQUEsRUFDN0M7QUFFQSxTQUNFO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDQztBQUFBLE1BQ0EsU0FBU007QUFBQUEsTUFDVCxPQUFPUCxPQUFPLGlCQUFpQjtBQUFBLE1BQy9CLFFBQ0VBLE9BQ0UsdUJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSwrQkFBQyxVQUFPLFNBQVEsYUFBWSxXQUFTLE1BQUMsU0FBU08sT0FBTSxvQkFBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxVQUFPLFdBQVMsTUFBQyxTQUFTLE1BQU0sS0FBS0YsV0FBVyxHQUFFLGlDQUFuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFPQSxJQUVBLHVCQUFDLFNBQUksV0FBVSxjQUNiO0FBQUEsK0JBQUMsVUFBTyxTQUFRLGFBQVksV0FBUyxNQUFDLFNBQVNFLE9BQU0sc0JBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0E7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDO0FBQUEsWUFDQSxTQUFTLE1BQU0sS0FBS0wsS0FBSztBQUFBLFlBQ3pCLFVBQVVsQixXQUFXRixRQUFRVSxLQUFLLEVBQUV2SCxXQUFXO0FBQUEsWUFFOUMrRyxvQkFBVSxhQUFhO0FBQUE7QUFBQSxVQUwxQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFNQTtBQUFBLFdBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVdBO0FBQUEsTUFJSGdCLGlCQUNDLHVCQUFDLFNBQUksV0FBVSxhQUNiLGlDQUFDLE9BQUUsV0FBVSx5Q0FDVjdLO0FBQUFBLGdCQUFRVSxNQUFNMkI7QUFBQUEsUUFBSztBQUFBLFdBRHRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQSxLQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLQSxJQUVBLHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLHlEQUNiO0FBQUEsaUNBQUMsU0FBSSxLQUFLckMsUUFBUUcsTUFBTXFCLE9BQU8sQ0FBQyxFQUFFUSxLQUFLLEtBQUksSUFBRyxXQUFVLHFDQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF5RjtBQUFBLFVBQ3pGLHVCQUFDLFNBQUksV0FBVSxXQUNiO0FBQUEsbUNBQUMsT0FBRSxXQUFVLG1DQUFtQ2hDLGtCQUFRRyxNQUFNa0MsUUFBOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBbUU7QUFBQSxZQUNuRSx1QkFBQyxPQUFFLFdBQVUsK0JBQ1ZyQztBQUFBQSxzQkFBUUssU0FBU2tDO0FBQUFBLGNBQUs7QUFBQSxjQUFJNUUsTUFBTXFDLFFBQVFHLE1BQU13RCxLQUFLQyxLQUFLO0FBQUEsY0FDeEQ1RCxRQUFRRyxNQUFNa0IsZ0JBQWdCLFVBQVU7QUFBQSxpQkFGM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLGVBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFNQTtBQUFBLGFBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVNBO0FBQUEsUUFFQSx1QkFBQyxTQUFNLE9BQU0sYUFDWDtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsT0FBT2dCO0FBQUFBLFlBQ1AsVUFBVSxDQUFDMEcsTUFBTTZCLFFBQVE3QixFQUFFd0IsT0FBTzNILEtBQUs7QUFBQSxZQUN2QyxhQUFZO0FBQUEsWUFDWixXQUFVO0FBQUE7QUFBQSxVQUpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUltSixLQUxySjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBT0E7QUFBQSxRQUVBLHVCQUFDLFNBQU0sT0FBTSxXQUNYO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFNO0FBQUEsWUFDTixPQUFPK0c7QUFBQUEsWUFDUCxVQUFVLENBQUNaLE1BQU1hLFdBQVdiLEVBQUV3QixPQUFPM0gsS0FBSztBQUFBLFlBQzFDLFdBQVU7QUFBQTtBQUFBLFVBSlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBSTZJLEtBTC9JO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFPQTtBQUFBLFFBRUEsdUJBQUMsU0FBTSxPQUFNLHNCQUNYO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFLO0FBQUEsWUFDTCxPQUFPMEc7QUFBQUEsWUFDUCxVQUFVLENBQUNQLE1BQU1RLFVBQVVSLEVBQUV3QixPQUFPM0gsS0FBSztBQUFBLFlBQ3pDLFdBQVU7QUFBQTtBQUFBLFVBSlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBSW1KLEtBTHJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFPQTtBQUFBLFFBRUNtSCxTQUFTLHVCQUFDLE9BQUUsV0FBVSx3REFBd0RBLG1CQUFyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTJFO0FBQUEsUUFFcEZWLGNBQWMsQ0FBQ2xLLFdBQ2QsdUJBQUMsT0FBRSxXQUFVLG9FQUFrRTtBQUFBO0FBQUEsVUFDOUQ7QUFBQSxVQUNmLHVCQUFDLFFBQUssSUFBRyxXQUFVLFdBQVUsMkJBQXlCLHVCQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFBUTtBQUFBLFVBQUc7QUFBQSxhQUpiO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFNQTtBQUFBLFFBR0YsdUJBQUMsU0FDQztBQUFBLGlDQUFDLE9BQUUsV0FBVSwwQ0FBeUMsc0NBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTRFO0FBQUEsVUFDNUUsdUJBQUMsUUFBRyxXQUFVLGtDQUNaO0FBQUEsbUNBQUMsUUFBRyxXQUFVLG9FQUFrRTtBQUFBO0FBQUEsY0FDdEV4QixNQUFNaUIsYUFBYW9NLFNBQVM7QUFBQSxjQUFFO0FBQUEsY0FBRXJOLE1BQU1pQixhQUFhcU0sU0FBUztBQUFBLGlCQUR0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxRQUFHLFdBQVUsb0VBQWtFO0FBQUE7QUFBQSxjQUN0RXJOLFNBQVMwTCxNQUFNO0FBQUEsaUJBRHpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBT0E7QUFBQSxVQUNBLHVCQUFDLE9BQUUsV0FBVSwyQkFBMEIsbUVBQXZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTBGO0FBQUEsYUFWNUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVdBO0FBQUEsV0E5REY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQStEQTtBQUFBO0FBQUEsSUFyR0o7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBdUdBO0FBRUo7QUFBQ3FCLElBdEtRRixjQUFZO0FBQUEsVUFhRjNPLGFBQ2VpQixPQUFPO0FBQUE7QUFBQSxNQWRoQzBOO0FBd0tULFNBQVNjLE1BQU0sRUFBRTVKLE9BQU82RCxTQUF1RCxHQUFHO0FBQ2hGLFNBQ0UsdUJBQUMsV0FBTSxXQUFVLFNBQ2Y7QUFBQSwyQkFBQyxVQUFLLFdBQVUsa0RBQWtEN0QsbUJBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBd0U7QUFBQSxJQUN2RTZEO0FBQUFBLE9BRkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUdBO0FBRUo7QUFBQ2dHLE1BUFFEO0FBQUssSUFBQUUsSUFBQXBHLEtBQUFJLEtBQUE2QyxLQUFBRyxLQUFBaUQsS0FBQUMsS0FBQUMsS0FBQUo7QUFBQSxhQUFBQyxJQUFBO0FBQUEsYUFBQXBHLEtBQUE7QUFBQSxhQUFBSSxLQUFBO0FBQUEsYUFBQTZDLEtBQUE7QUFBQSxhQUFBRyxLQUFBO0FBQUEsYUFBQWlELEtBQUE7QUFBQSxhQUFBQyxLQUFBO0FBQUEsYUFBQUMsS0FBQTtBQUFBLGFBQUFKLEtBQUEiLCJuYW1lcyI6WyJ1c2VFZmZlY3QiLCJ1c2VNZW1vIiwidXNlU3RhdGUiLCJMaW5rIiwidXNlTmF2aWdhdGUiLCJ1c2VQYXJhbXMiLCJBcnJvd0xlZnQiLCJCb29rbWFyayIsIlNjYWxlIiwiTWFwUGluIiwiQ2hlY2siLCJNaW51cyIsIlgiLCJCdWlsZGluZzIiLCJGbGFnIiwiQ2hldnJvblJpZ2h0IiwiUGVuY2lsIiwiQ2FsZW5kYXJDaGVjayIsIkNsb2NrIiwidXNlSGFiaXRvIiwiZGIiLCJ1c2VBdXRoIiwiQnV0dG9uIiwiTW9kYWwiLCJDb2FjaG1hcmsiLCJTcGFjZVBob3RvIiwiTWF0Y2hSaW5nIiwiVHJ1c3RCYWRnZSIsIkF2YWlsYWJpbGl0eUJhZGdlIiwia2V5U3BlYyIsInNjb3JlTGlzdGluZyIsIkFNRU5JVElFUyIsIkNBVEVHT1JZX1NUWUxFIiwibW9uZXkiLCJsb25nRGF0ZSIsImxhc3RVcGRhdGVkTGFiZWwiLCJpc1N0YWxlIiwiYXZhaWxhYmlsaXR5TGluZSIsIlNQQUNFX1RZUEVfTEFCRUwiLCJjbiIsInVzZUkxOG4iLCJzcGFjZU5hbWUiLCJzcGFjZURlc2NyaXB0aW9uIiwiZGlzcGxheUltYWdlIiwiU3BhY2VEZXRhaWwiLCJfcyIsImlkIiwibmF2aWdhdGUiLCJsaXN0aW5ncyIsInJlYWR5IiwicmVxdWlyZW1lbnRzIiwiaGFzU3RhdGVkTmVlZHMiLCJpc1NhdmVkIiwidG9nZ2xlU2F2ZWQiLCJpc0NvbXBhcmluZyIsInRvZ2dsZUNvbXBhcmUiLCJzZW5kSW5xdWlyeSIsImFjY291bnQiLCJ0IiwibGFuZ3VhZ2UiLCJhY3RpdmUiLCJzZXRBY3RpdmUiLCJsaWdodGJveCIsInNldExpZ2h0Ym94IiwiaW5xdWlyeU9wZW4iLCJzZXRJbnF1aXJ5T3BlbiIsImJvb2tpbmdPcGVuIiwic2V0Qm9va2luZ09wZW4iLCJzaWJsaW5ncyIsInNldFNpYmxpbmdzIiwibGlzdGluZyIsImZpbmQiLCJsIiwic3BhY2UiLCJzcGFjZXNPZlByb3BlcnR5IiwicHJvcGVydHkiLCJ0aGVuIiwiYWxsIiwiZmlsdGVyIiwicyIsIm93bmVyIiwiaXNNaW5lIiwiQm9vbGVhbiIsIm93bmVySWQiLCJtYXRjaCIsInNhdmVkIiwiYm9va2FibGUiLCJhdmFpbGFiaWxpdHkiLCJzdGF0dXMiLCJjb21wYXJpbmciLCJpc1NhbGUiLCJ0cmFuc2FjdGlvbiIsImNhdCIsImNhdGVnb3J5IiwiaW1hZ2VzIiwiYWx0IiwiZGVtbyIsImxhYmVsIiwic2xpY2UiLCJtYXAiLCJpbWciLCJpIiwidXJsIiwic3ludGhldGljIiwiY2hpcCIsInNwYWNlVHlwZSIsInZlcmlmaWNhdGlvbiIsIm5hbWUiLCJhZGRyZXNzIiwiYXJlYSIsImRpc3RyaWN0IiwiZ2VvZ3JhcGh5Iiwic3BlY1Jvd3MiLCJyb3ciLCJ2YWx1ZSIsImFtZW5pdGllcyIsImxlbmd0aCIsImtleSIsImljb24iLCJJY29uIiwicnVsZXMiLCJmYW1pbHlBbGxvd2VkIiwiYmFjaGVsb3JBbGxvd2VkIiwic3R1ZGVudEZyaWVuZGx5IiwiZ2VuZGVyUHJlZmVyZW5jZSIsIm1heE9jY3VwYW50cyIsIm5lYXJieSIsIm4iLCJrbSIsImNvc3QiLCJwcmljZSIsImF2YXRhclRvbmUiLCJjaGFyQXQiLCJyb2xlIiwicmVzcG9uc2VSYXRlIiwicmVzcG9uc2VUaW1lSG91cnMiLCJyZXBsYWNlIiwiYWxlcnQiLCJzY29yZSIsImZhY3RvcnMiLCJmIiwiYXZhaWxhYmxlRnJvbSIsIm5vdGUiLCJzZXJ2aWNlQ2hhcmdlIiwidXRpbGl0aWVzIiwiZXN0aW1hdGVkTW9udGhseSIsImFkdmFuY2VNb250aHMiLCJzZWN1cml0eURlcG9zaXQiLCJsYXN0VXBkYXRlZCIsInZpZXdzIiwiaW5xdWlyeUNvdW50IiwiUnVsZUNoaXAiLCJvayIsInllcyIsIm5vIiwiX2MyIiwiU2VjdGlvbiIsInRpdGxlIiwiY2hpbGRyZW4iLCJfYzMiLCJhIiwiYXR0cmlidXRlcyIsInJvd3MiLCJhZGQiLCJ1bmRlZmluZWQiLCJwdXNoIiwiU3RyaW5nIiwiYmVkcm9vbXMiLCJiYXRocm9vbXMiLCJzaXplU3FmdCIsImZsb29yIiwiZnVybmlzaGluZyIsImJhbGNvbnkiLCJmcm9udGFnZUZ0Iiwid29ya3N0YXRpb25zIiwibWVldGluZ1Jvb20iLCJzdWl0YWJsZUZvciIsImNlaWxpbmdIZWlnaHRGdCIsImxvYWRpbmdBY2Nlc3MiLCJ2ZWhpY2xlQWNjZXNzIiwiY2FyU2xvdHMiLCJtb3RvcmN5Y2xlU2xvdHMiLCJjb3ZlcmVkIiwiYWNjZXNzSG91cnMiLCJsYW5kQXJlYURlY2ltYWwiLCJsYW5kVXNlIiwicm9hZEFjY2VzcyIsIndhdGVyU291cmNlIiwibGVhc2VZZWFycyIsIlZFUkRJQ1QiLCJtZXQiLCJjbGFzc05hbWUiLCJwYXJ0aWFsIiwibWlzc2VkIiwiRmFjdG9yUm93IiwiZmFjdG9yIiwidmVyZGljdCIsInBvaW50cyIsIndlaWdodCIsIk1hdGgiLCJhYnMiLCJyb3VuZCIsInRvRml4ZWQiLCJkZXRhaWwiLCJfYzQiLCJDb3N0Um93IiwibXV0ZWQiLCJfYzUiLCJMaWdodGJveCIsIm9wZW4iLCJvbkNsb3NlIiwiX3MyIiwib25LZXkiLCJlIiwiZG9jdW1lbnQiLCJhZGRFdmVudExpc3RlbmVyIiwicmVtb3ZlRXZlbnRMaXN0ZW5lciIsIkJvb2tpbmdNb2RhbCIsIl9zMyIsImNvbmZpZ3VyZWQiLCJtb3ZlSW4iLCJzZXRNb3ZlSW4iLCJtb3ZlSW5EYXRlIiwibW9udGhzIiwic2V0TW9udGhzIiwibWVzc2FnZSIsInNldE1lc3NhZ2UiLCJzZW5kaW5nIiwic2V0U2VuZGluZyIsImVycm9yIiwic2V0RXJyb3IiLCJhbW91bnQiLCJzdWJtaXQiLCJyZXF1ZXN0Qm9va2luZyIsInNwYWNlSWQiLCJ0cmltIiwiRXJyb3IiLCJ0YXJnZXQiLCJOdW1iZXIiLCJJbnF1aXJ5TW9kYWwiLCJvblNlbmQiLCJfczQiLCJzZXROYW1lIiwic2VudCIsInNldFNlbnQiLCJzZW5kIiwiYnVkZ2V0TWluIiwiYnVkZ2V0TWF4Iiwib3BlblRocmVhZCIsIm9wZW5Db252ZXJzYXRpb24iLCJjbG9zZSIsIndpbmRvdyIsInNldFRpbWVvdXQiLCJGaWVsZCIsIl9jOSIsIl9jIiwiX2M2IiwiX2M3IiwiX2M4Il0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlNwYWNlRGV0YWlsLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VFZmZlY3QsIHVzZU1lbW8sIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBMaW5rLCB1c2VOYXZpZ2F0ZSwgdXNlUGFyYW1zIH0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIjtcbmltcG9ydCB7IEFycm93TGVmdCwgQm9va21hcmssIFNjYWxlLCBNYXBQaW4sIENoZWNrLCBNaW51cywgWCwgQnVpbGRpbmcyLCBGbGFnLCBDaGV2cm9uUmlnaHQsIFBlbmNpbCwgQ2FsZW5kYXJDaGVjaywgQ2xvY2sgfSBmcm9tIFwibHVjaWRlLXJlYWN0XCI7XG5pbXBvcnQgeyB1c2VIYWJpdG8gfSBmcm9tIFwiQC9ob29rcy91c2VIYWJpdG9cIjtcbmltcG9ydCB7IGRiIH0gZnJvbSBcIkAvbGliL2FwaVwiO1xuaW1wb3J0IHsgdXNlQXV0aCB9IGZyb20gXCJAL2hvb2tzL3VzZUF1dGhcIjtcbmltcG9ydCB7IEJ1dHRvbiB9IGZyb20gXCJAL2NvbXBvbmVudHMvdWkvQnV0dG9uXCI7XG5pbXBvcnQgeyBNb2RhbCB9IGZyb20gXCJAL2NvbXBvbmVudHMvdWkvTW9kYWxcIjtcbmltcG9ydCB7IENvYWNobWFyayB9IGZyb20gXCJAL2NvbXBvbmVudHMvdWkvQ29hY2htYXJrXCI7XG5pbXBvcnQgeyBTcGFjZVBob3RvIH0gZnJvbSBcIkAvY29tcG9uZW50cy9zcGFjZS9TcGFjZVBob3RvXCI7XG5pbXBvcnQgeyBNYXRjaFJpbmcgfSBmcm9tIFwiQC9jb21wb25lbnRzL3NwYWNlL01hdGNoUmluZ1wiO1xuaW1wb3J0IHsgVHJ1c3RCYWRnZSwgQXZhaWxhYmlsaXR5QmFkZ2UgfSBmcm9tIFwiQC9jb21wb25lbnRzL3NwYWNlL2JhZGdlc1wiO1xuaW1wb3J0IHsga2V5U3BlYyB9IGZyb20gXCJAL2NvbXBvbmVudHMvc3BhY2UvU3BhY2VDYXJkXCI7XG5pbXBvcnQgeyBzY29yZUxpc3RpbmcgfSBmcm9tIFwiQC9saWIvbWF0Y2hpbmdcIjtcbmltcG9ydCB7IEFNRU5JVElFUywgQ0FURUdPUllfU1RZTEUgfSBmcm9tIFwiQC9kYXRhL2NhdGFsb2dcIjtcbmltcG9ydCB7IG1vbmV5LCBsb25nRGF0ZSwgbGFzdFVwZGF0ZWRMYWJlbCwgaXNTdGFsZSwgYXZhaWxhYmlsaXR5TGluZSB9IGZyb20gXCJAL2xpYi9mb3JtYXRcIjtcbmltcG9ydCB7IFNQQUNFX1RZUEVfTEFCRUwgfSBmcm9tIFwiQC90eXBlcy9zcGFjZVwiO1xuaW1wb3J0IHR5cGUgeyBNYXRjaEZhY3RvciwgU3BhY2UsIFNwYWNlTGlzdGluZyB9IGZyb20gXCJAL3R5cGVzL3NwYWNlXCI7XG5pbXBvcnQgeyBjbiB9IGZyb20gXCJAL2xpYi9jblwiO1xuaW1wb3J0IHsgdXNlSTE4biB9IGZyb20gXCJAL2kxOG5cIjtcbmltcG9ydCB7IHNwYWNlTmFtZSwgc3BhY2VEZXNjcmlwdGlvbiwgZGlzcGxheUltYWdlIH0gZnJvbSBcIkAvbGliL2xvY2FsaXplXCI7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFNwYWNlRGV0YWlsKCkge1xuICBjb25zdCB7IGlkID0gXCJcIiB9ID0gdXNlUGFyYW1zKCk7XG4gIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcbiAgY29uc3QgeyBsaXN0aW5ncywgcmVhZHksIHJlcXVpcmVtZW50cywgaGFzU3RhdGVkTmVlZHMsIGlzU2F2ZWQsIHRvZ2dsZVNhdmVkLCBpc0NvbXBhcmluZywgdG9nZ2xlQ29tcGFyZSwgc2VuZElucXVpcnkgfSA9XG4gICAgdXNlSGFiaXRvKCk7XG4gIGNvbnN0IHsgYWNjb3VudCB9ID0gdXNlQXV0aCgpO1xuICBjb25zdCB7IHQsIGxhbmd1YWdlIH0gPSB1c2VJMThuKCk7XG5cbiAgY29uc3QgW2FjdGl2ZSwgc2V0QWN0aXZlXSA9IHVzZVN0YXRlKDApO1xuICBjb25zdCBbbGlnaHRib3gsIHNldExpZ2h0Ym94XSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW2lucXVpcnlPcGVuLCBzZXRJbnF1aXJ5T3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtib29raW5nT3Blbiwgc2V0Qm9va2luZ09wZW5dID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbc2libGluZ3MsIHNldFNpYmxpbmdzXSA9IHVzZVN0YXRlPFNwYWNlW10+KFtdKTtcblxuICBjb25zdCBsaXN0aW5nID0gdXNlTWVtbygoKSA9PiBsaXN0aW5ncy5maW5kKChsKSA9PiBsLnNwYWNlLmlkID09PSBpZCkgPz8gbnVsbCwgW2xpc3RpbmdzLCBpZF0pO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgc2V0QWN0aXZlKDApO1xuICAgIGlmICghbGlzdGluZykgcmV0dXJuO1xuICAgIHZvaWQgZGIuc3BhY2VzT2ZQcm9wZXJ0eShsaXN0aW5nLnByb3BlcnR5LmlkKS50aGVuKChhbGwpID0+IHNldFNpYmxpbmdzKGFsbC5maWx0ZXIoKHMpID0+IHMuaWQgIT09IGlkKSkpO1xuICB9LCBbbGlzdGluZywgaWRdKTtcblxuICBpZiAoIXJlYWR5KSB7XG4gICAgcmV0dXJuIDxkaXYgY2xhc3NOYW1lPVwiY29udGFpbmVyLXBhZ2UgcHktMjAgdGV4dC1zbSB0ZXh0LW11dGVkXCI+TG9hZGluZyBzcGFjZeKApjwvZGl2PjtcbiAgfVxuXG4gIGlmICghbGlzdGluZykge1xuICAgIHJldHVybiAoXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbnRhaW5lci1wYWdlIHB5LTIwIHRleHQtY2VudGVyXCI+XG4gICAgICAgIDxoMSBjbGFzc05hbWU9XCJmb250LWRpc3BsYXkgdGV4dC0yeGwgZm9udC1ib2xkIHRleHQtaW5rXCI+VGhhdCBzcGFjZSBpc24ndCBoZXJlLjwvaDE+XG4gICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LW11dGVkXCI+SXQgbWF5IGhhdmUgYmVlbiByZW1vdmVkLCBvciB0aGUgbGluayBpcyBvdXQgb2YgZGF0ZS48L3A+XG4gICAgICAgIDxCdXR0b24gY2xhc3NOYW1lPVwibXQtNVwiIG9uQ2xpY2s9eygpID0+IG5hdmlnYXRlKFwiL3NlYXJjaFwiKX0+XG4gICAgICAgICAgQmFjayB0byBzZWFyY2hcbiAgICAgICAgPC9CdXR0b24+XG4gICAgICA8L2Rpdj5cbiAgICApO1xuICB9XG5cbiAgY29uc3QgeyBzcGFjZSwgcHJvcGVydHksIG93bmVyIH0gPSBsaXN0aW5nO1xuICAvLyBZb3VyIG93biBsaXN0aW5nIHNob3VsZG4ndCBpbnZpdGUgeW91IHRvIGVucXVpcmUgYWJvdXQgaXQuXG4gIGNvbnN0IGlzTWluZSA9IEJvb2xlYW4oYWNjb3VudCAmJiBwcm9wZXJ0eS5vd25lcklkID09PSBhY2NvdW50LmlkKTtcbiAgY29uc3QgbWF0Y2ggPSBoYXNTdGF0ZWROZWVkcyA/IHNjb3JlTGlzdGluZyhsaXN0aW5nLCByZXF1aXJlbWVudHMpIDogbnVsbDtcbiAgY29uc3Qgc2F2ZWQgPSBpc1NhdmVkKHNwYWNlLmlkKTtcblxuICAvLyBPY2N1cGllZCBhbmQgdW5kZXItbWFpbnRlbmFuY2Ugc3BhY2VzIGNhbm5vdCBiZSBib29rZWQ7IHRoZSBkYXRhYmFzZVxuICAvLyByZWZ1c2VzIHRvbywgYnV0IHRoZXJlIGlzIG5vIHBvaW50IG9mZmVyaW5nIGEgYnV0dG9uIHRoYXQgd2lsbCBmYWlsLlxuICBjb25zdCBib29rYWJsZSA9XG4gICAgc3BhY2UuYXZhaWxhYmlsaXR5LnN0YXR1cyAhPT0gXCJvY2N1cGllZFwiICYmIHNwYWNlLmF2YWlsYWJpbGl0eS5zdGF0dXMgIT09IFwibWFpbnRlbmFuY2VcIjtcbiAgY29uc3QgY29tcGFyaW5nID0gaXNDb21wYXJpbmcoc3BhY2UuaWQpO1xuICBjb25zdCBpc1NhbGUgPSBzcGFjZS50cmFuc2FjdGlvbiA9PT0gXCJzYWxlXCI7XG4gIGNvbnN0IGNhdCA9IENBVEVHT1JZX1NUWUxFW3NwYWNlLmNhdGVnb3J5XTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwicGItMjQgbWQ6cGItMFwiPlxuICAgICAgey8qIEdhbGxlcnkgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbnRhaW5lci1wYWdlIHB0LTQgbWQ6cHQtNlwiPlxuICAgICAgICA8TGlua1xuICAgICAgICAgIHRvPVwiL3NlYXJjaFwiXG4gICAgICAgICAgY2xhc3NOYW1lPVwibWItNCBpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1pbmstc29mdCBob3Zlcjp0ZXh0LWlua1wiXG4gICAgICAgID5cbiAgICAgICAgICA8QXJyb3dMZWZ0IHNpemU9ezE1fSBhcmlhLWhpZGRlbiAvPlxuICAgICAgICAgIEJhY2sgdG8gcmVzdWx0c1xuICAgICAgICA8L0xpbms+XG5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdhcC0yIG1kOmdyaWQtY29scy1bMS45ZnJfMWZyXSBtZDpnYXAtM1wiPlxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0TGlnaHRib3godHJ1ZSl9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJncm91cCBsaWZ0IHJlbGF0aXZlIG92ZXJmbG93LWhpZGRlbiByb3VuZGVkLWNhcmQgYmctaXZvcnktZGVlcFwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgPFNwYWNlUGhvdG9cbiAgICAgICAgICAgICAgc3JjPXtkaXNwbGF5SW1hZ2Uoc3BhY2UuaW1hZ2VzW2FjdGl2ZV0pfVxuICAgICAgICAgICAgICBhbHQ9e3NwYWNlLmltYWdlc1thY3RpdmVdLmFsdH1cbiAgICAgICAgICAgICAgY2F0ZWdvcnk9e3NwYWNlLmNhdGVnb3J5fVxuICAgICAgICAgICAgICBkZW1vPXtzcGFjZS5pbWFnZXNbYWN0aXZlXS5kZW1vfVxuICAgICAgICAgICAgICBwcmlvcml0eVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJhc3BlY3QtNC8zIHctZnVsbCBtZDphc3BlY3QtMTYvMTBcIlxuICAgICAgICAgICAgICBpbWdDbGFzc05hbWU9XCJ6b29tXCJcbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBib3R0b20tMyBsZWZ0LTMgcm91bmRlZC1mdWxsIGJnLWluay83MCBweC0yLjUgcHktMSB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC13aGl0ZSBiYWNrZHJvcC1ibHVyXCI+XG4gICAgICAgICAgICAgIHtzcGFjZS5pbWFnZXNbYWN0aXZlXS5sYWJlbH0gwrcgdmlldyBhbGxcbiAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtNCBnYXAtMiBtZDpncmlkLWNvbHMtMSBtZDpncmlkLXJvd3MtM1wiPlxuICAgICAgICAgICAge3NwYWNlLmltYWdlcy5zbGljZSgwLCAzKS5tYXAoKGltZywgaSkgPT4gKFxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAga2V5PXtpbWcudXJsICsgaX1cbiAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRBY3RpdmUoaSl9XG4gICAgICAgICAgICAgICAgYXJpYS1sYWJlbD17YFNob3cgJHtpbWcubGFiZWx9YH1cbiAgICAgICAgICAgICAgICBhcmlhLWN1cnJlbnQ9e2kgPT09IGFjdGl2ZX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgICAgICAgICAgICAgXCJvdmVyZmxvdy1oaWRkZW4gcm91bmRlZC0yeGwgYmctaXZvcnktZGVlcCByaW5nLTIgdHJhbnNpdGlvbi1hbGxcIixcbiAgICAgICAgICAgICAgICAgIGkgPT09IGFjdGl2ZSA/IFwicmluZy1pbmtcIiA6IFwicmluZy10cmFuc3BhcmVudCBob3ZlcjpyaW5nLWhhaXJsaW5lLXN0cm9uZ1wiLFxuICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8U3BhY2VQaG90b1xuICAgICAgICAgICAgICAgICAgc3JjPXtkaXNwbGF5SW1hZ2UoaW1nKX1cbiAgICAgICAgICAgICAgICAgIGFsdD1cIlwiXG4gICAgICAgICAgICAgICAgICBjYXRlZ29yeT17c3BhY2UuY2F0ZWdvcnl9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJhc3BlY3QtNC8zIHNpemUtZnVsbCBtZDphc3BlY3QtYXV0byBtZDpoLWZ1bGxcIlxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgKSl9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC14cyB0ZXh0LW11dGVkXCI+XG4gICAgICAgICAge3NwYWNlLnN5bnRoZXRpY1xuICAgICAgICAgICAgPyBcIklsbHVzdHJhdGl2ZSBkZW1vIGltYWdlcy4gVGhlc2UgYXJlIG5vdCBwaG90b2dyYXBocyBvZiBhIHJlYWwgc3BhY2UuXCJcbiAgICAgICAgICAgIDogXCJQaG90b2dyYXBocyBwcm92aWRlZCBieSB0aGUgb3duZXIuXCJ9XG4gICAgICAgIDwvcD5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogQm9keSAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29udGFpbmVyLXBhZ2UgZ3JpZCBnYXAtMTAgcHktOCBsZzpncmlkLWNvbHMtWzFmcl8yMnJlbV0gbGc6Z2FwLTE0XCI+XG4gICAgICAgIDxkaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17Y24oXCJyb3VuZGVkLWZ1bGwgcHgtMi41IHB5LTEgdGV4dC14cyBmb250LXNlbWlib2xkXCIsIGNhdC5jaGlwKX0+XG4gICAgICAgICAgICAgIHtTUEFDRV9UWVBFX0xBQkVMW3NwYWNlLnNwYWNlVHlwZV19XG4gICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICB7aXNTYWxlICYmIDxzcGFuIGNsYXNzTmFtZT1cInJvdW5kZWQtZnVsbCBiZy1pbmsgcHgtMi41IHB5LTEgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtaXZvcnlcIj5Gb3Igc2FsZTwvc3Bhbj59XG4gICAgICAgICAgICA8QXZhaWxhYmlsaXR5QmFkZ2UgYXZhaWxhYmlsaXR5PXtzcGFjZS5hdmFpbGFiaWxpdHl9IC8+XG4gICAgICAgICAgICA8VHJ1c3RCYWRnZSB2ZXJpZmljYXRpb249e3NwYWNlLnZlcmlmaWNhdGlvbn0gLz5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJtdC00IGZvbnQtZGlzcGxheSB0ZXh0LTN4bCBmb250LWV4dHJhYm9sZCB0ZXh0LWluayBzbTp0ZXh0LTR4bFwiPntzcGFjZU5hbWUoc3BhY2UsIGxhbmd1YWdlKX08L2gxPlxuXG4gICAgICAgICAgPExpbmtcbiAgICAgICAgICAgIHRvPXtgL3Byb3BlcnR5LyR7cHJvcGVydHkuaWR9YH1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cIm10LTIgaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgdGV4dC1zbSB0ZXh0LWluay1zb2Z0IGhvdmVyOnRleHQtaW5rXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICA8QnVpbGRpbmcyIHNpemU9ezE1fSBhcmlhLWhpZGRlbiAvPlxuICAgICAgICAgICAge3Byb3BlcnR5Lm5hbWV9XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LW11dGVkXCI+wrcge3Byb3BlcnR5LmFkZHJlc3N9PC9zcGFuPlxuICAgICAgICAgIDwvTGluaz5cblxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEgaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgdGV4dC1zbSB0ZXh0LW11dGVkXCI+XG4gICAgICAgICAgICA8TWFwUGluIHNpemU9ezE0fSBhcmlhLWhpZGRlbiAvPlxuICAgICAgICAgICAge3Byb3BlcnR5LmFyZWF9LCB7cHJvcGVydHkuZGlzdHJpY3R9IMK3IHtwcm9wZXJ0eS5nZW9ncmFwaHl9XG4gICAgICAgICAgPC9wPlxuXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtNiBsZWFkaW5nLXJlbGF4ZWQgdGV4dC1pbmstc29mdFwiPntzcGFjZURlc2NyaXB0aW9uKHNwYWNlLCBsYW5ndWFnZSl9PC9wPlxuXG4gICAgICAgICAgey8qIEFkYXB0aXZlIHNwZWNzIOKAlCBvbmx5IGZpZWxkcyB0aGF0IGFwcGx5IHRvIHRoaXMgY2F0ZWdvcnkgKi99XG4gICAgICAgICAgPFNlY3Rpb24gdGl0bGU9XCJUaGUgc3BhY2VcIj5cbiAgICAgICAgICAgIDxkbCBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIGdhcC1weCBvdmVyZmxvdy1oaWRkZW4gcm91bmRlZC1jYXJkIGJnLWhhaXJsaW5lIHJpbmctMSByaW5nLWhhaXJsaW5lIHNtOmdyaWQtY29scy0zXCI+XG4gICAgICAgICAgICAgIHtzcGVjUm93cyhsaXN0aW5nKS5tYXAoKHJvdykgPT4gKFxuICAgICAgICAgICAgICAgIDxkaXYga2V5PXtyb3cubGFiZWx9IGNsYXNzTmFtZT1cImJnLXN1cmZhY2UgcHgtNCBweS0zXCI+XG4gICAgICAgICAgICAgICAgICA8ZHQgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LW11dGVkXCI+e3Jvdy5sYWJlbH08L2R0PlxuICAgICAgICAgICAgICAgICAgPGRkIGNsYXNzTmFtZT1cIm10LTAuNSBmb250LWJvbGQgdG51bSB0ZXh0LWlua1wiPntyb3cudmFsdWV9PC9kZD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICA8L2RsPlxuICAgICAgICAgIDwvU2VjdGlvbj5cblxuICAgICAgICAgIHtzcGFjZS5hbWVuaXRpZXMubGVuZ3RoID4gMCAmJiAoXG4gICAgICAgICAgICA8U2VjdGlvbiB0aXRsZT1cIldoYXQncyBpbmNsdWRlZFwiPlxuICAgICAgICAgICAgICA8dWwgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICB7c3BhY2UuYW1lbml0aWVzLm1hcCgoa2V5KSA9PiB7XG4gICAgICAgICAgICAgICAgICBjb25zdCB7IGxhYmVsLCBpY29uOiBJY29uIH0gPSBBTUVOSVRJRVNba2V5XTtcbiAgICAgICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgICAgIDxsaVxuICAgICAgICAgICAgICAgICAgICAgIGtleT17a2V5fVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHJvdW5kZWQtZnVsbCBiZy1zdXJmYWNlIHB4LTMgcHktMS41IHRleHQtc20gdGV4dC1pbmstc29mdCByaW5nLTEgcmluZy1oYWlybGluZVwiXG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICA8SWNvbiBzaXplPXsxNH0gY2xhc3NOYW1lPVwidGV4dC1tdXRlZFwiIGFyaWEtaGlkZGVuIC8+XG4gICAgICAgICAgICAgICAgICAgICAge2xhYmVsfVxuICAgICAgICAgICAgICAgICAgICA8L2xpPlxuICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICB9KX1cbiAgICAgICAgICAgICAgPC91bD5cbiAgICAgICAgICAgIDwvU2VjdGlvbj5cbiAgICAgICAgICApfVxuXG4gICAgICAgICAge3NwYWNlLmNhdGVnb3J5ID09PSBcImxpdmluZ1wiICYmIHNwYWNlLnJ1bGVzICYmIChcbiAgICAgICAgICAgIDxTZWN0aW9uIHRpdGxlPVwiV2hvIHRoaXMgaXMgZm9yXCI+XG4gICAgICAgICAgICAgIDx1bCBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBnYXAtMlwiPlxuICAgICAgICAgICAgICAgIDxSdWxlQ2hpcCBvaz17c3BhY2UucnVsZXMuZmFtaWx5QWxsb3dlZH0geWVzPVwiRmFtaWxpZXMgd2VsY29tZVwiIG5vPVwiTm90IGZvciBmYW1pbGllc1wiIC8+XG4gICAgICAgICAgICAgICAgPFJ1bGVDaGlwIG9rPXtzcGFjZS5ydWxlcy5iYWNoZWxvckFsbG93ZWR9IHllcz1cIkJhY2hlbG9ycyB3ZWxjb21lXCIgbm89XCJObyBiYWNoZWxvcnNcIiAvPlxuICAgICAgICAgICAgICAgIHtzcGFjZS5ydWxlcy5zdHVkZW50RnJpZW5kbHkgJiYgPFJ1bGVDaGlwIG9rIHllcz1cIlN0dWRlbnQgZnJpZW5kbHlcIiBubz1cIlwiIC8+fVxuICAgICAgICAgICAgICAgIHtzcGFjZS5ydWxlcy5nZW5kZXJQcmVmZXJlbmNlICE9PSBcImFueVwiICYmIChcbiAgICAgICAgICAgICAgICAgIDxSdWxlQ2hpcFxuICAgICAgICAgICAgICAgICAgICBva1xuICAgICAgICAgICAgICAgICAgICB5ZXM9e3NwYWNlLnJ1bGVzLmdlbmRlclByZWZlcmVuY2UgPT09IFwibWFsZVwiID8gXCJNZW4gb25seVwiIDogXCJXb21lbiBvbmx5XCJ9XG4gICAgICAgICAgICAgICAgICAgIG5vPVwiXCJcbiAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICB7c3BhY2UucnVsZXMubWF4T2NjdXBhbnRzICYmIChcbiAgICAgICAgICAgICAgICAgIDxSdWxlQ2hpcCBvayB5ZXM9e2BVcCB0byAke3NwYWNlLnJ1bGVzLm1heE9jY3VwYW50c30gcGVvcGxlYH0gbm89XCJcIiAvPlxuICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgIDwvdWw+XG4gICAgICAgICAgICA8L1NlY3Rpb24+XG4gICAgICAgICAgKX1cblxuICAgICAgICAgIHtwcm9wZXJ0eS5uZWFyYnkubGVuZ3RoID4gMCAmJiAoXG4gICAgICAgICAgICA8U2VjdGlvbiB0aXRsZT1cIkdldHRpbmcgYXJvdW5kXCI+XG4gICAgICAgICAgICAgIDx1bCBjbGFzc05hbWU9XCJncmlkIGdhcC1weCBvdmVyZmxvdy1oaWRkZW4gcm91bmRlZC1jYXJkIGJnLWhhaXJsaW5lIHJpbmctMSByaW5nLWhhaXJsaW5lIHNtOmdyaWQtY29scy0yXCI+XG4gICAgICAgICAgICAgICAge3Byb3BlcnR5Lm5lYXJieS5tYXAoKG4pID0+IChcbiAgICAgICAgICAgICAgICAgIDxsaSBrZXk9e24ubGFiZWx9IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBiZy1zdXJmYWNlIHB4LTQgcHktMyB0ZXh0LXNtXCI+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtaW5rLXNvZnRcIj57bi5sYWJlbH08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdG51bSB0ZXh0LWlua1wiPntuLmttfSBrbTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvbGk+XG4gICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgIDwvdWw+XG4gICAgICAgICAgICA8L1NlY3Rpb24+XG4gICAgICAgICAgKX1cblxuICAgICAgICAgIHtzaWJsaW5ncy5sZW5ndGggPiAwICYmIChcbiAgICAgICAgICAgIDxTZWN0aW9uIHRpdGxlPXtgTW9yZSBhdCAke3Byb3BlcnR5Lm5hbWV9YH0+XG4gICAgICAgICAgICAgIDx1bCBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cbiAgICAgICAgICAgICAgICB7c2libGluZ3Muc2xpY2UoMCwgNSkubWFwKChzKSA9PiAoXG4gICAgICAgICAgICAgICAgICA8bGkga2V5PXtzLmlkfT5cbiAgICAgICAgICAgICAgICAgICAgPExpbmtcbiAgICAgICAgICAgICAgICAgICAgICB0bz17YC9zcGFjZS8ke3MuaWR9YH1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyByb3VuZGVkLTJ4bCBiZy1zdXJmYWNlIHAtMi41IHJpbmctMSByaW5nLWhhaXJsaW5lIHRyYW5zaXRpb24tY29sb3JzIGhvdmVyOnJpbmctaW5rXCJcbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIDxpbWcgc3JjPXtzLmltYWdlc1swXS51cmx9IGFsdD1cIlwiIGNsYXNzTmFtZT1cInNpemUtMTIgc2hyaW5rLTAgcm91bmRlZC14bCBvYmplY3QtY292ZXJcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLXctMCBmbGV4LTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRydW5jYXRlIGZvbnQtc2VtaWJvbGQgdGV4dC1pbmtcIj57cy5uYW1lfTwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRydW5jYXRlIHRleHQteHMgdGV4dC1tdXRlZFwiPntTUEFDRV9UWVBFX0xBQkVMW3Muc3BhY2VUeXBlXX08L3A+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwic2hyaW5rLTAgZm9udC1ib2xkIHRudW0gdGV4dC1pbmtcIj57bW9uZXkocy5jb3N0LnByaWNlKX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPENoZXZyb25SaWdodCBzaXplPXsxNn0gY2xhc3NOYW1lPVwic2hyaW5rLTAgdGV4dC1tdXRlZFwiIGFyaWEtaGlkZGVuIC8+XG4gICAgICAgICAgICAgICAgICAgIDwvTGluaz5cbiAgICAgICAgICAgICAgICAgIDwvbGk+XG4gICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgIDwvdWw+XG4gICAgICAgICAgICA8L1NlY3Rpb24+XG4gICAgICAgICAgKX1cblxuICAgICAgICAgIDxTZWN0aW9uIHRpdGxlPVwiT3duZXJcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBnYXAtNCByb3VuZGVkLWNhcmQgYmctc3VyZmFjZSBwLTUgcmluZy0xIHJpbmctaGFpcmxpbmVcIj5cbiAgICAgICAgICAgICAgPHNwYW5cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgICAgICAgICAgICAgXCJmbGV4IHNpemUtMTIgc2hyaW5rLTAgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHJvdW5kZWQtZnVsbCBmb250LWRpc3BsYXkgdGV4dC1sZyBmb250LWJvbGRcIixcbiAgICAgICAgICAgICAgICAgIG93bmVyLmF2YXRhclRvbmUgPT09IFwibWludFwiICYmIFwiYmctbWludCB0ZXh0LW1pbnQtaW5rXCIsXG4gICAgICAgICAgICAgICAgICBvd25lci5hdmF0YXJUb25lID09PSBcInN1blwiICYmIFwiYmctc3VuIHRleHQtc3VuLWlua1wiLFxuICAgICAgICAgICAgICAgICAgb3duZXIuYXZhdGFyVG9uZSA9PT0gXCJsaWxhY1wiICYmIFwiYmctbGlsYWMgdGV4dC1saWxhYy1pbmtcIixcbiAgICAgICAgICAgICAgICAgIG93bmVyLmF2YXRhclRvbmUgPT09IFwiY29yYWxcIiAmJiBcImJnLWNvcmFsLzYwIHRleHQtY29yYWwtaW5rXCIsXG4gICAgICAgICAgICAgICAgICBvd25lci5hdmF0YXJUb25lID09PSBcImFxdWFcIiAmJiBcImJnLWFxdWEtMjAwIHRleHQtYXF1YS03MDBcIixcbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAge293bmVyLm5hbWUuY2hhckF0KDApfVxuICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xXCI+XG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWlua1wiPntvd25lci5uYW1lfTwvcD5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGNhcGl0YWxpemUgdGV4dC1tdXRlZFwiPntvd25lci5yb2xlfTwvcD5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdG51bSB0ZXh0LWluay1zb2Z0XCI+XG4gICAgICAgICAgICAgICAgICBSZXBsaWVzIHRvIHtvd25lci5yZXNwb25zZVJhdGV9JSBvZiBpbnF1aXJpZXMgwrcgdXN1YWxseSB3aXRoaW4ge293bmVyLnJlc3BvbnNlVGltZUhvdXJzfWhcbiAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMyB0ZXh0LXhzIGxlYWRpbmctcmVsYXhlZCB0ZXh0LW11dGVkXCI+XG4gICAgICAgICAgICAgICAgICBPd25lciBzdGF0ZToge293bmVyLnZlcmlmaWNhdGlvbi5yZXBsYWNlKFwiLVwiLCBcIiBcIil9IChkZW1vKS4gSGFiaXRvIGhhcyBub3QgY2FycmllZCBvdXRcbiAgICAgICAgICAgICAgICAgIGEgcmVhbCBpZGVudGl0eSBvciBvd25lcnNoaXAgY2hlY2suXG4gICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtdC0zIGlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LW11dGVkIGhvdmVyOnRleHQtZGFuZ2VyLTYwMFwiXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGFsZXJ0KFwiUmVwb3J0aW5nIGlzIHBhcnQgb2YgdGhlIHRydXN0IHdvcmtmbG93IGFuZCBpcyBub3Qgd2lyZWQgdXAgaW4gdGhpcyBwcm90b3R5cGUuXCIpfVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8RmxhZyBzaXplPXsxMn0gYXJpYS1oaWRkZW4gLz5cbiAgICAgICAgICAgICAgUmVwb3J0IHRoaXMgbGlzdGluZ1xuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgPC9TZWN0aW9uPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogU3RpY2t5IHJhaWwgKi99XG4gICAgICAgIDxhc2lkZSBjbGFzc05hbWU9XCJsZzpzdGlja3kgbGc6dG9wLTI0IGxnOnNlbGYtc3RhcnRcIj5cbiAgICAgICAgICB7bWF0Y2ggJiYgKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi00IHJvdW5kZWQtY2FyZCBiZy1zdXJmYWNlIHAtNSByaW5nLTEgcmluZy1oYWlybGluZVwiPlxuICAgICAgICAgICAgICA8TWF0Y2hSaW5nIHNjb3JlPXttYXRjaC5zY29yZX0gLz5cbiAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cIm10LTUgdGV4dC1zbSBmb250LWJvbGQgdGV4dC1pbmtcIj5XaHkgdGhpcyBzY29yZXMgYXMgaXQgZG9lczwvaDI+XG4gICAgICAgICAgICAgIDx1bCBjbGFzc05hbWU9XCJtdC0yLjUgc3BhY2UteS0yXCI+XG4gICAgICAgICAgICAgICAge21hdGNoLmZhY3RvcnMubWFwKChmKSA9PiAoXG4gICAgICAgICAgICAgICAgICA8RmFjdG9yUm93IGtleT17Zi5rZXl9IGZhY3Rvcj17Zn0gLz5cbiAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgPC91bD5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtNCBib3JkZXItdCBib3JkZXItaGFpcmxpbmUgcHQtMyB0ZXh0LXhzIGxlYWRpbmctcmVsYXhlZCB0ZXh0LW11dGVkXCI+XG4gICAgICAgICAgICAgICAgV2VpZ2h0ZWQgYXJpdGhtZXRpYyBvdmVyIHdoYXQgeW91IHRvbGQgdXMg4oCUIGJ1ZGdldCAzMCwgbG9jYXRpb24gMjQsIHR5cGUgMjAsXG4gICAgICAgICAgICAgICAgYXZhaWxhYmlsaXR5IDEyLCBzaXplIDcsIGFtZW5pdGllcyA3LiBObyBtYWNoaW5lIGxlYXJuaW5nIGludm9sdmVkLlxuICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApfVxuXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3VuZGVkLWNhcmQgYmctc3VyZmFjZSBwLTUgcmluZy0xIHJpbmctaGFpcmxpbmVcIj5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImZvbnQtZGlzcGxheSB0ZXh0LTN4bCBmb250LWV4dHJhYm9sZCB0bnVtIHRleHQtaW5rXCI+XG4gICAgICAgICAgICAgIHttb25leShzcGFjZS5jb3N0LnByaWNlKX1cbiAgICAgICAgICAgICAgeyFpc1NhbGUgJiYgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1iYXNlIGZvbnQtbWVkaXVtIHRleHQtbXV0ZWRcIj4vbW9udGg8L3NwYW4+fVxuICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXNtIHRleHQtbXV0ZWRcIj57YXZhaWxhYmlsaXR5TGluZShzcGFjZS5hdmFpbGFiaWxpdHkuYXZhaWxhYmxlRnJvbSl9PC9wPlxuICAgICAgICAgICAge3NwYWNlLmF2YWlsYWJpbGl0eS5ub3RlICYmIChcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1hcXVhLTcwMFwiPntzcGFjZS5hdmFpbGFiaWxpdHkubm90ZX08L3A+XG4gICAgICAgICAgICApfVxuXG4gICAgICAgICAgICB7IWlzU2FsZSAmJiAoXG4gICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cIm10LTUgdGV4dC1zbSBmb250LWJvbGQgdGV4dC1pbmtcIj5Nb250aGx5IGNvc3Q8L2gyPlxuICAgICAgICAgICAgICAgIDxkbCBjbGFzc05hbWU9XCJtdC0yIHNwYWNlLXktMS41IHRleHQtc21cIj5cbiAgICAgICAgICAgICAgICAgIDxDb3N0Um93IGxhYmVsPVwiUmVudFwiIHZhbHVlPXttb25leShzcGFjZS5jb3N0LnByaWNlKX0gLz5cbiAgICAgICAgICAgICAgICAgIDxDb3N0Um93XG4gICAgICAgICAgICAgICAgICAgIGxhYmVsPVwiU2VydmljZSBjaGFyZ2VcIlxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c3BhY2UuY29zdC5zZXJ2aWNlQ2hhcmdlICE9PSBudWxsID8gbW9uZXkoc3BhY2UuY29zdC5zZXJ2aWNlQ2hhcmdlKSA6IFwiTm90IGxpc3RlZFwifVxuICAgICAgICAgICAgICAgICAgICBtdXRlZD17c3BhY2UuY29zdC5zZXJ2aWNlQ2hhcmdlID09PSBudWxsfVxuICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgIDxDb3N0Um93XG4gICAgICAgICAgICAgICAgICAgIGxhYmVsPVwiVXRpbGl0aWVzXCJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NwYWNlLmNvc3QudXRpbGl0aWVzICE9PSBudWxsID8gbW9uZXkoc3BhY2UuY29zdC51dGlsaXRpZXMpIDogXCJOb3QgbGlzdGVkXCJ9XG4gICAgICAgICAgICAgICAgICAgIG11dGVkPXtzcGFjZS5jb3N0LnV0aWxpdGllcyA9PT0gbnVsbH1cbiAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgPC9kbD5cblxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMyBib3JkZXItdCBib3JkZXItaGFpcmxpbmUgcHQtM1wiPlxuICAgICAgICAgICAgICAgICAge3NwYWNlLmNvc3QuZXN0aW1hdGVkTW9udGhseSA/IChcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWJhc2VsaW5lIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWlua1wiPkVzdGltYXRlZCB0b3RhbDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWRpc3BsYXkgdGV4dC1sZyBmb250LWJvbGQgdG51bSB0ZXh0LWFxdWEtNzAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICB7bW9uZXkoc3BhY2UuY29zdC5lc3RpbWF0ZWRNb250aGx5KX1cbiAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJyb3VuZGVkLXhsIGJnLXdhcm4tMTAwIHB4LTMgcHktMiB0ZXh0LXhzIGxlYWRpbmctcmVsYXhlZCB0ZXh0LXdhcm4tNzAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICBUaGlzIG93bmVyIGhhc24ndCBsaXN0ZWQgZXZlcnkgY29zdCwgc28gYSBtb250aGx5IHRvdGFsIGNhbid0IGJlIHNob3duLlxuICAgICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgICAgICA8Q29hY2htYXJrXG4gICAgICAgICAgICAgICAgICAgICAgICBpZD1cImNvc3RcIlxuICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGVLZXk9XCJjb2FjaC5jb3N0VGl0bGVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgYm9keUtleT1cImNvYWNoLmNvc3RCb2R5XCJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm10LTNcIlxuICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxkbCBjbGFzc05hbWU9XCJtdC00IHNwYWNlLXktMS41IGJvcmRlci10IGJvcmRlci1oYWlybGluZSBwdC0zIHRleHQtc21cIj5cbiAgICAgICAgICAgICAgICAgIHtzcGFjZS5jb3N0LmFkdmFuY2VNb250aHMgIT09IG51bGwgJiYgKFxuICAgICAgICAgICAgICAgICAgICA8Q29zdFJvd1xuICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPVwiQWR2YW5jZVwiXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Ake3NwYWNlLmNvc3QuYWR2YW5jZU1vbnRoc30gbW9udGgke3NwYWNlLmNvc3QuYWR2YW5jZU1vbnRocyA+IDEgPyBcInNcIiA6IFwiXCJ9YH1cbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICA8Q29zdFJvd1xuICAgICAgICAgICAgICAgICAgICBsYWJlbD1cIkRlcG9zaXRcIlxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c3BhY2UuY29zdC5zZWN1cml0eURlcG9zaXQgIT09IG51bGwgPyBtb25leShzcGFjZS5jb3N0LnNlY3VyaXR5RGVwb3NpdCkgOiBcIk5vdCBsaXN0ZWRcIn1cbiAgICAgICAgICAgICAgICAgICAgbXV0ZWQ9e3NwYWNlLmNvc3Quc2VjdXJpdHlEZXBvc2l0ID09PSBudWxsfVxuICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICA8L2RsPlxuICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNSBoaWRkZW4gZ2FwLTIgbWQ6ZmxleCBtZDpmbGV4LWNvbFwiPlxuICAgICAgICAgICAgICB7aXNNaW5lID8gKFxuICAgICAgICAgICAgICAgIDxMaW5rIHRvPXtgL3NwYWNlLyR7c3BhY2UuaWR9L2VkaXRgfT5cbiAgICAgICAgICAgICAgICAgIDxCdXR0b24gZnVsbFdpZHRoIHZhcmlhbnQ9XCJzZWNvbmRhcnlcIj5cbiAgICAgICAgICAgICAgICAgICAgPFBlbmNpbCBzaXplPXsxNX0gYXJpYS1oaWRkZW4gLz5cbiAgICAgICAgICAgICAgICAgICAge3QoXCJlZGl0LmFjdGlvblwiKX1cbiAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgICAgIDwvTGluaz5cbiAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgPEJ1dHRvbiBmdWxsV2lkdGggb25DbGljaz17KCkgPT4gc2V0Qm9va2luZ09wZW4odHJ1ZSl9IGRpc2FibGVkPXshYm9va2FibGV9PlxuICAgICAgICAgICAgICAgICAgICA8Q2FsZW5kYXJDaGVjayBzaXplPXsxNX0gYXJpYS1oaWRkZW4gLz5cbiAgICAgICAgICAgICAgICAgICAge3QoXCJib29raW5nLnJlcXVlc3RcIil9XG4gICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgICAgICAgIDxCdXR0b24gZnVsbFdpZHRoIHZhcmlhbnQ9XCJzZWNvbmRhcnlcIiBvbkNsaWNrPXsoKSA9PiBzZXRJbnF1aXJ5T3Blbih0cnVlKX0+XG4gICAgICAgICAgICAgICAgICAgIHt0KFwiYWN0aW9uLnNlbmRJbnF1aXJ5XCIpfVxuICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgICAgICAgICB7IWJvb2thYmxlICYmIChcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgdGV4dC14cyB0ZXh0LW11dGVkXCI+e3QoXCJib29raW5nLm5vdEF2YWlsYWJsZVwiKX08L3A+XG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJzZWNvbmRhcnlcIiBvbkNsaWNrPXsoKSA9PiB2b2lkIHRvZ2dsZVNhdmVkKHNwYWNlLmlkKX0+XG4gICAgICAgICAgICAgICAgICA8Qm9va21hcmsgc2l6ZT17MTV9IGNsYXNzTmFtZT17Y24oc2F2ZWQgJiYgXCJmaWxsLWFxdWEtNjAwIHRleHQtYXF1YS02MDBcIil9IGFyaWEtaGlkZGVuIC8+XG4gICAgICAgICAgICAgICAgICB7c2F2ZWQgPyBcIlNhdmVkXCIgOiBcIlNhdmVcIn1cbiAgICAgICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJzZWNvbmRhcnlcIiBvbkNsaWNrPXsoKSA9PiB0b2dnbGVDb21wYXJlKHNwYWNlLmlkKX0+XG4gICAgICAgICAgICAgICAgICA8U2NhbGUgc2l6ZT17MTV9IGFyaWEtaGlkZGVuIC8+XG4gICAgICAgICAgICAgICAgICB7Y29tcGFyaW5nID8gXCJBZGRlZFwiIDogXCJDb21wYXJlXCJ9XG4gICAgICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT17Y24oXCJtdC00IHRleHQteHNcIiwgaXNTdGFsZShzcGFjZS5sYXN0VXBkYXRlZCkgPyBcImZvbnQtbWVkaXVtIHRleHQtd2Fybi03MDBcIiA6IFwidGV4dC1tdXRlZFwiKX0+XG4gICAgICAgICAgICAgIHtsYXN0VXBkYXRlZExhYmVsKHNwYWNlLmxhc3RVcGRhdGVkKX0gwrcge3NwYWNlLnZpZXdzfSB2aWV3cyDCtyB7c3BhY2UuaW5xdWlyeUNvdW50fSBpbnF1aXJpZXNcbiAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9hc2lkZT5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogTW9iaWxlIHN0aWNreSBhY3Rpb25zICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC14LTAgYm90dG9tLTE0IHotMzAgYm9yZGVyLXQgYm9yZGVyLWhhaXJsaW5lIGJnLXN1cmZhY2UvOTUgcC0zIGJhY2tkcm9wLWJsdXIgbWQ6aGlkZGVuXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi13LTAgZmxleC0xXCI+XG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0cnVuY2F0ZSBmb250LWRpc3BsYXkgdGV4dC1sZyBmb250LWJvbGQgdG51bSB0ZXh0LWlua1wiPlxuICAgICAgICAgICAgICB7bW9uZXkoc3BhY2UuY29zdC5wcmljZSl9XG4gICAgICAgICAgICAgIHshaXNTYWxlICYmIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1tdXRlZFwiPi9tbzwvc3Bhbj59XG4gICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICB7bWF0Y2ggJiYgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0bnVtIHRleHQtYXF1YS03MDBcIj57bWF0Y2guc2NvcmV9JSBtYXRjaDwvcD59XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwic2Vjb25kYXJ5XCIgc2l6ZT1cInNtXCIgb25DbGljaz17KCkgPT4gdm9pZCB0b2dnbGVTYXZlZChzcGFjZS5pZCl9IGFyaWEtbGFiZWw9XCJTYXZlXCI+XG4gICAgICAgICAgICA8Qm9va21hcmsgc2l6ZT17MTZ9IGNsYXNzTmFtZT17Y24oc2F2ZWQgJiYgXCJmaWxsLWFxdWEtNjAwIHRleHQtYXF1YS02MDBcIil9IGFyaWEtaGlkZGVuIC8+XG4gICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAge2lzTWluZSA/IChcbiAgICAgICAgICAgIDxMaW5rIHRvPXtgL3NwYWNlLyR7c3BhY2UuaWR9L2VkaXRgfT5cbiAgICAgICAgICAgICAgPEJ1dHRvbiBzaXplPVwic21cIiB2YXJpYW50PVwic2Vjb25kYXJ5XCI+XG4gICAgICAgICAgICAgICAgPFBlbmNpbCBzaXplPXsxNX0gYXJpYS1oaWRkZW4gLz5cbiAgICAgICAgICAgICAgICB7dChcImVkaXQuYWN0aW9uXCIpfVxuICAgICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgIDwvTGluaz5cbiAgICAgICAgICApIDogKFxuICAgICAgICAgICAgPEJ1dHRvbiBzaXplPVwic21cIiBvbkNsaWNrPXsoKSA9PiBzZXRJbnF1aXJ5T3Blbih0cnVlKX0+XG4gICAgICAgICAgICAgIHt0KFwiYWN0aW9uLnNlbmRJbnF1aXJ5XCIpfVxuICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgKX1cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgICAgPExpZ2h0Ym94XG4gICAgICAgIG9wZW49e2xpZ2h0Ym94fVxuICAgICAgICBvbkNsb3NlPXsoKSA9PiBzZXRMaWdodGJveChmYWxzZSl9XG4gICAgICAgIGxpc3Rpbmc9e2xpc3Rpbmd9XG4gICAgICAgIGFjdGl2ZT17YWN0aXZlfVxuICAgICAgICBzZXRBY3RpdmU9e3NldEFjdGl2ZX1cbiAgICAgIC8+XG5cbiAgICAgIDxCb29raW5nTW9kYWxcbiAgICAgICAgb3Blbj17Ym9va2luZ09wZW59XG4gICAgICAgIG9uQ2xvc2U9eygpID0+IHNldEJvb2tpbmdPcGVuKGZhbHNlKX1cbiAgICAgICAgbGlzdGluZz17bGlzdGluZ31cbiAgICAgICAgcmVxdWlyZW1lbnRzPXtyZXF1aXJlbWVudHN9XG4gICAgICAvPlxuXG4gICAgICA8SW5xdWlyeU1vZGFsXG4gICAgICAgIG9wZW49e2lucXVpcnlPcGVufVxuICAgICAgICBvbkNsb3NlPXsoKSA9PiBzZXRJbnF1aXJ5T3BlbihmYWxzZSl9XG4gICAgICAgIGxpc3Rpbmc9e2xpc3Rpbmd9XG4gICAgICAgIG9uU2VuZD17c2VuZElucXVpcnl9XG4gICAgICAgIHJlcXVpcmVtZW50cz17cmVxdWlyZW1lbnRzfVxuICAgICAgLz5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cblxuLyog4pSA4pSAIFBpZWNlcyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIAgKi9cblxuLyoqIE9jY3VwYW5jeSBydWxlcyByZWFkIGFzIHBsYWluIHN0YXRlbWVudHMsIGdyZWVuIGZvciB5ZXMgYW5kIG11dGVkIGZvciBuby4gKi9cbmZ1bmN0aW9uIFJ1bGVDaGlwKHsgb2ssIHllcywgbm8gfTogeyBvazogYm9vbGVhbjsgeWVzOiBzdHJpbmc7IG5vOiBzdHJpbmcgfSkge1xuICByZXR1cm4gKFxuICAgIDxsaVxuICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgXCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSByb3VuZGVkLWZ1bGwgcHgtMyBweS0xLjUgdGV4dC1zbSBmb250LW1lZGl1bVwiLFxuICAgICAgICBvayA/IFwiYmctb2stMTAwIHRleHQtb2stNjAwXCIgOiBcImJnLWl2b3J5LWRlZXAgdGV4dC1tdXRlZFwiLFxuICAgICAgKX1cbiAgICA+XG4gICAgICB7b2sgPyA8Q2hlY2sgc2l6ZT17MTR9IGFyaWEtaGlkZGVuIC8+IDogPFggc2l6ZT17MTR9IGFyaWEtaGlkZGVuIC8+fVxuICAgICAge29rID8geWVzIDogbm99XG4gICAgPC9saT5cbiAgKTtcbn1cblxuZnVuY3Rpb24gU2VjdGlvbih7IHRpdGxlLCBjaGlsZHJlbiB9OiB7IHRpdGxlOiBzdHJpbmc7IGNoaWxkcmVuOiBSZWFjdC5SZWFjdE5vZGUgfSkge1xuICByZXR1cm4gKFxuICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cIm10LTlcIj5cbiAgICAgIDxoMiBjbGFzc05hbWU9XCJtYi0zIGZvbnQtZGlzcGxheSB0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LWlua1wiPnt0aXRsZX08L2gyPlxuICAgICAge2NoaWxkcmVufVxuICAgIDwvc2VjdGlvbj5cbiAgKTtcbn1cblxuZnVuY3Rpb24gc3BlY1Jvd3MobGlzdGluZzogU3BhY2VMaXN0aW5nKTogQXJyYXk8eyBsYWJlbDogc3RyaW5nOyB2YWx1ZTogc3RyaW5nIH0+IHtcbiAgY29uc3QgYSA9IGxpc3Rpbmcuc3BhY2UuYXR0cmlidXRlcztcbiAgY29uc3Qgcm93czogQXJyYXk8eyBsYWJlbDogc3RyaW5nOyB2YWx1ZTogc3RyaW5nIH0+ID0gW107XG4gIGNvbnN0IGFkZCA9IChsYWJlbDogc3RyaW5nLCB2YWx1ZTogc3RyaW5nIHwgbnVtYmVyIHwgdW5kZWZpbmVkIHwgYm9vbGVhbikgPT4ge1xuICAgIGlmICh2YWx1ZSA9PT0gdW5kZWZpbmVkIHx8IHZhbHVlID09PSBudWxsIHx8IHZhbHVlID09PSBmYWxzZSkgcmV0dXJuO1xuICAgIHJvd3MucHVzaCh7IGxhYmVsLCB2YWx1ZTogdHlwZW9mIHZhbHVlID09PSBcImJvb2xlYW5cIiA/IFwiWWVzXCIgOiBTdHJpbmcodmFsdWUpIH0pO1xuICB9O1xuXG4gIHN3aXRjaCAobGlzdGluZy5zcGFjZS5jYXRlZ29yeSkge1xuICAgIGNhc2UgXCJsaXZpbmdcIjpcbiAgICAgIGFkZChcIkJlZHJvb21zXCIsIGEuYmVkcm9vbXMpO1xuICAgICAgYWRkKFwiQmF0aHJvb21zXCIsIGEuYmF0aHJvb21zKTtcbiAgICAgIGFkZChcIlNpemVcIiwgYS5zaXplU3FmdCA/IGAke2Euc2l6ZVNxZnR9IHNxZnRgIDogdW5kZWZpbmVkKTtcbiAgICAgIGFkZChcIkZsb29yXCIsIGEuZmxvb3IpO1xuICAgICAgYWRkKFwiRnVybmlzaGluZ1wiLCBhLmZ1cm5pc2hpbmc/LnJlcGxhY2UoXCItXCIsIFwiIFwiKSk7XG4gICAgICBhZGQoXCJCYWxjb255XCIsIGEuYmFsY29ueSk7XG4gICAgICBicmVhaztcbiAgICBjYXNlIFwiYnVzaW5lc3NcIjpcbiAgICAgIGFkZChcIlNpemVcIiwgYS5zaXplU3FmdCA/IGAke2Euc2l6ZVNxZnR9IHNxZnRgIDogdW5kZWZpbmVkKTtcbiAgICAgIGFkZChcIkZsb29yXCIsIGEuZmxvb3IgPT09IDAgPyBcIkdyb3VuZFwiIDogYS5mbG9vcik7XG4gICAgICBhZGQoXCJGcm9udGFnZVwiLCBhLmZyb250YWdlRnQgPyBgJHthLmZyb250YWdlRnR9IGZ0YCA6IHVuZGVmaW5lZCk7XG4gICAgICBhZGQoXCJXb3Jrc3RhdGlvbnNcIiwgYS53b3Jrc3RhdGlvbnMpO1xuICAgICAgYWRkKFwiTWVldGluZyByb29tXCIsIGEubWVldGluZ1Jvb20pO1xuICAgICAgYWRkKFwiU3VpdHNcIiwgYS5zdWl0YWJsZUZvcik7XG4gICAgICBicmVhaztcbiAgICBjYXNlIFwic3RvcmFnZVwiOlxuICAgICAgYWRkKFwiU3RvcmFnZSBhcmVhXCIsIGEuc2l6ZVNxZnQgPyBgJHthLnNpemVTcWZ0fSBzcWZ0YCA6IHVuZGVmaW5lZCk7XG4gICAgICBhZGQoXCJDZWlsaW5nXCIsIGEuY2VpbGluZ0hlaWdodEZ0ID8gYCR7YS5jZWlsaW5nSGVpZ2h0RnR9IGZ0YCA6IHVuZGVmaW5lZCk7XG4gICAgICBhZGQoXCJMb2FkaW5nIGFjY2Vzc1wiLCBhLmxvYWRpbmdBY2Nlc3MpO1xuICAgICAgYWRkKFwiVmVoaWNsZSBhY2Nlc3NcIiwgYS52ZWhpY2xlQWNjZXNzKTtcbiAgICAgIGFkZChcIlN1aXRzXCIsIGEuc3VpdGFibGVGb3IpO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSBcInBhcmtpbmdcIjpcbiAgICAgIGFkZChcIkNhciBzbG90c1wiLCBhLmNhclNsb3RzKTtcbiAgICAgIGFkZChcIk1vdG9yY3ljbGUgc2xvdHNcIiwgYS5tb3RvcmN5Y2xlU2xvdHMpO1xuICAgICAgYWRkKFwiQ292ZXJcIiwgYS5jb3ZlcmVkID8gXCJDb3ZlcmVkXCIgOiBcIk9wZW5cIik7XG4gICAgICBhZGQoXCJBY2Nlc3NcIiwgYS5hY2Nlc3NIb3Vycyk7XG4gICAgICBicmVhaztcbiAgICBjYXNlIFwibGFuZFwiOlxuICAgICAgYWRkKFwiTGFuZCBhcmVhXCIsIGEubGFuZEFyZWFEZWNpbWFsID8gYCR7YS5sYW5kQXJlYURlY2ltYWx9IGRlY2ltYWxgIDogdW5kZWZpbmVkKTtcbiAgICAgIGFkZChcIlVzZVwiLCBhLmxhbmRVc2UpO1xuICAgICAgYWRkKFwiUm9hZCBhY2Nlc3NcIiwgYS5yb2FkQWNjZXNzKTtcbiAgICAgIGFkZChcIldhdGVyIHNvdXJjZVwiLCBhLndhdGVyU291cmNlKTtcbiAgICAgIGFkZChcIkxlYXNlXCIsIGEubGVhc2VZZWFycyA/IGAke2EubGVhc2VZZWFyc30geWVhcnNgIDogdW5kZWZpbmVkKTtcbiAgICAgIGJyZWFrO1xuICB9XG5cbiAgaWYgKHJvd3MubGVuZ3RoID09PSAwKSByb3dzLnB1c2goeyBsYWJlbDogXCJTdW1tYXJ5XCIsIHZhbHVlOiBrZXlTcGVjKGxpc3RpbmcpIH0pO1xuICByZXR1cm4gcm93cztcbn1cblxuY29uc3QgVkVSRElDVCA9IHtcbiAgbWV0OiB7IEljb246IENoZWNrLCBjbGFzc05hbWU6IFwidGV4dC1vay02MDBcIiB9LFxuICBwYXJ0aWFsOiB7IEljb246IE1pbnVzLCBjbGFzc05hbWU6IFwidGV4dC13YXJuLTcwMFwiIH0sXG4gIG1pc3NlZDogeyBJY29uOiBYLCBjbGFzc05hbWU6IFwidGV4dC1kYW5nZXItNjAwXCIgfSxcbn0gYXMgY29uc3Q7XG5cbmZ1bmN0aW9uIEZhY3RvclJvdyh7IGZhY3RvciB9OiB7IGZhY3RvcjogTWF0Y2hGYWN0b3IgfSkge1xuICBjb25zdCB7IEljb24sIGNsYXNzTmFtZSB9ID0gVkVSRElDVFtmYWN0b3IudmVyZGljdF07XG4gIGNvbnN0IHBvaW50cyA9IGZhY3Rvci5zY29yZSAqIGZhY3Rvci53ZWlnaHQ7XG4gIGNvbnN0IGxhYmVsID0gTWF0aC5hYnMocG9pbnRzIC0gTWF0aC5yb3VuZChwb2ludHMpKSA8IDAuMDUgPyBTdHJpbmcoTWF0aC5yb3VuZChwb2ludHMpKSA6IHBvaW50cy50b0ZpeGVkKDEpO1xuXG4gIHJldHVybiAoXG4gICAgPGxpIGNsYXNzTmFtZT1cImZsZXggZ2FwLTIuNSB0ZXh0LXNtXCI+XG4gICAgICA8SWNvbiBzaXplPXsxNX0gY2xhc3NOYW1lPXtjbihcIm10LTAuNSBzaHJpbmstMFwiLCBjbGFzc05hbWUpfSBhcmlhLWhpZGRlbiAvPlxuICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZmxleC0xIGxlYWRpbmctc251ZyB0ZXh0LWluay1zb2Z0XCI+XG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1pbmtcIj57ZmFjdG9yLmxhYmVsfTwvc3Bhbj5cbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibXgtMS41IHRleHQtaGFpcmxpbmUtc3Ryb25nXCIgYXJpYS1oaWRkZW4+wrc8L3NwYW4+XG4gICAgICAgIHtmYWN0b3IuZGV0YWlsfVxuICAgICAgPC9zcGFuPlxuICAgICAgPHNwYW4gY2xhc3NOYW1lPVwic2hyaW5rLTAgdGV4dC14cyBmb250LXNlbWlib2xkIHRudW0gdGV4dC1tdXRlZFwiPlxuICAgICAgICB7bGFiZWx9L3tmYWN0b3Iud2VpZ2h0fVxuICAgICAgPC9zcGFuPlxuICAgIDwvbGk+XG4gICk7XG59XG5cbmZ1bmN0aW9uIENvc3RSb3coeyBsYWJlbCwgdmFsdWUsIG11dGVkIH06IHsgbGFiZWw6IHN0cmluZzsgdmFsdWU6IHN0cmluZzsgbXV0ZWQ/OiBib29sZWFuIH0pIHtcbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtYmFzZWxpbmUganVzdGlmeS1iZXR3ZWVuIGdhcC0zXCI+XG4gICAgICA8ZHQgY2xhc3NOYW1lPVwidGV4dC1pbmstc29mdFwiPntsYWJlbH08L2R0PlxuICAgICAgPGRkIGNsYXNzTmFtZT17Y24oXCJmb250LXNlbWlib2xkIHRudW1cIiwgbXV0ZWQgPyBcInRleHQtbXV0ZWRcIiA6IFwidGV4dC1pbmtcIil9Pnt2YWx1ZX08L2RkPlxuICAgIDwvZGl2PlxuICApO1xufVxuXG5mdW5jdGlvbiBMaWdodGJveCh7XG4gIG9wZW4sXG4gIG9uQ2xvc2UsXG4gIGxpc3RpbmcsXG4gIGFjdGl2ZSxcbiAgc2V0QWN0aXZlLFxufToge1xuICBvcGVuOiBib29sZWFuO1xuICBvbkNsb3NlOiAoKSA9PiB2b2lkO1xuICBsaXN0aW5nOiBTcGFjZUxpc3Rpbmc7XG4gIGFjdGl2ZTogbnVtYmVyO1xuICBzZXRBY3RpdmU6IChpOiBudW1iZXIpID0+IHZvaWQ7XG59KSB7XG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKCFvcGVuKSByZXR1cm47XG4gICAgY29uc3Qgb25LZXkgPSAoZTogS2V5Ym9hcmRFdmVudCkgPT4ge1xuICAgICAgaWYgKGUua2V5ID09PSBcIkVzY2FwZVwiKSBvbkNsb3NlKCk7XG4gICAgICBpZiAoZS5rZXkgPT09IFwiQXJyb3dSaWdodFwiKSBzZXRBY3RpdmUoKGFjdGl2ZSArIDEpICUgbGlzdGluZy5zcGFjZS5pbWFnZXMubGVuZ3RoKTtcbiAgICAgIGlmIChlLmtleSA9PT0gXCJBcnJvd0xlZnRcIikgc2V0QWN0aXZlKChhY3RpdmUgLSAxICsgbGlzdGluZy5zcGFjZS5pbWFnZXMubGVuZ3RoKSAlIGxpc3Rpbmcuc3BhY2UuaW1hZ2VzLmxlbmd0aCk7XG4gICAgfTtcbiAgICBkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKFwia2V5ZG93blwiLCBvbktleSk7XG4gICAgcmV0dXJuICgpID0+IGRvY3VtZW50LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJrZXlkb3duXCIsIG9uS2V5KTtcbiAgfSwgW29wZW4sIG9uQ2xvc2UsIGFjdGl2ZSwgc2V0QWN0aXZlLCBsaXN0aW5nLnNwYWNlLmltYWdlcy5sZW5ndGhdKTtcblxuICBpZiAoIW9wZW4pIHJldHVybiBudWxsO1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIHotNTAgZmxleCBmbGV4LWNvbCBiZy1pbmsvOTUgcC00XCIgcm9sZT1cImRpYWxvZ1wiIGFyaWEtbW9kYWw9XCJ0cnVlXCIgYXJpYS1sYWJlbD1cIkltYWdlc1wiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gdGV4dC1pdm9yeVwiPlxuICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGRcIj5cbiAgICAgICAgICB7bGlzdGluZy5zcGFjZS5pbWFnZXNbYWN0aXZlXS5sYWJlbH1cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtbC0yIGZvbnQtbm9ybWFsIHRleHQtaXZvcnkvNjAgdG51bVwiPlxuICAgICAgICAgICAge2FjdGl2ZSArIDF9IC8ge2xpc3Rpbmcuc3BhY2UuaW1hZ2VzLmxlbmd0aH1cbiAgICAgICAgICA8L3NwYW4+XG4gICAgICAgIDwvcD5cbiAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17b25DbG9zZX0gYXJpYS1sYWJlbD1cIkNsb3NlXCIgY2xhc3NOYW1lPVwicm91bmRlZC1mdWxsIHAtMiBob3ZlcjpiZy13aGl0ZS8xMFwiPlxuICAgICAgICAgIDxYIHNpemU9ezIwfSAvPlxuICAgICAgICA8L2J1dHRvbj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC0xIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBweS00XCI+XG4gICAgICAgIDxpbWdcbiAgICAgICAgICBzcmM9e2xpc3Rpbmcuc3BhY2UuaW1hZ2VzW2FjdGl2ZV0udXJsfVxuICAgICAgICAgIGFsdD17bGlzdGluZy5zcGFjZS5pbWFnZXNbYWN0aXZlXS5hbHR9XG4gICAgICAgICAgY2xhc3NOYW1lPVwibWF4LWgtZnVsbCBtYXgtdy00eGwgcm91bmRlZC1jYXJkIG9iamVjdC1jb250YWluXCJcbiAgICAgICAgLz5cbiAgICAgIDwvZGl2PlxuXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAge2xpc3Rpbmcuc3BhY2UuaW1hZ2VzLm1hcCgoaW1nLCBpKSA9PiAoXG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAga2V5PXtpbWcudXJsICsgaX1cbiAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0QWN0aXZlKGkpfVxuICAgICAgICAgICAgYXJpYS1sYWJlbD17YFNob3cgJHtpbWcubGFiZWx9YH1cbiAgICAgICAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgICAgICAgIFwib3ZlcmZsb3ctaGlkZGVuIHJvdW5kZWQteGwgcmluZy0yIHRyYW5zaXRpb24tYWxsXCIsXG4gICAgICAgICAgICAgIGkgPT09IGFjdGl2ZSA/IFwicmluZy1hcXVhLTQwMFwiIDogXCJyaW5nLXRyYW5zcGFyZW50IG9wYWNpdHktNjAgaG92ZXI6b3BhY2l0eS0xMDBcIixcbiAgICAgICAgICAgICl9XG4gICAgICAgICAgPlxuICAgICAgICAgICAgPGltZyBzcmM9e2ltZy51cmx9IGFsdD1cIlwiIGNsYXNzTmFtZT1cInNpemUtMTYgb2JqZWN0LWNvdmVyXCIgLz5cbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgKSl9XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cblxuLyoqXG4gKiBSZXF1ZXN0aW5nIGEgYm9va2luZy5cbiAqXG4gKiBEZWxpYmVyYXRlbHkgbm90IGEgcGF5bWVudC4gVGhlIG93bmVyIGRlY2lkZXMsIGFuZCBvbmx5IG9uY2UgdGhleSBhY2NlcHQgZG9cbiAqIHRoZSB0d28gb2YgeW91IGdldCBlYWNoIG90aGVyJ3MgbnVtYmVyIOKAlCB3aGljaCBpcyB0aGUgdGhpbmcgdGhhdCBtYWtlc1xuICogcGVvcGxlIHdpbGxpbmcgdG8gYXNrIGluIHRoZSBmaXJzdCBwbGFjZS5cbiAqL1xuZnVuY3Rpb24gQm9va2luZ01vZGFsKHtcbiAgb3BlbixcbiAgb25DbG9zZSxcbiAgbGlzdGluZyxcbiAgcmVxdWlyZW1lbnRzLFxufToge1xuICBvcGVuOiBib29sZWFuO1xuICBvbkNsb3NlOiAoKSA9PiB2b2lkO1xuICBsaXN0aW5nOiBTcGFjZUxpc3Rpbmc7XG4gIHJlcXVpcmVtZW50czogUmV0dXJuVHlwZTx0eXBlb2YgdXNlSGFiaXRvPltcInJlcXVpcmVtZW50c1wiXTtcbn0pIHtcbiAgY29uc3QgeyB0IH0gPSB1c2VJMThuKCk7XG4gIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcbiAgY29uc3QgeyBhY2NvdW50LCBjb25maWd1cmVkIH0gPSB1c2VBdXRoKCk7XG5cbiAgY29uc3QgW21vdmVJbiwgc2V0TW92ZUluXSA9IHVzZVN0YXRlKHJlcXVpcmVtZW50cy5tb3ZlSW5EYXRlKTtcbiAgLy8gTm90IGEgdGVybSBvZiB0ZW5hbmN5IOKAlCB0aGUgcmVudCBsZWRnZXIgcnVucyBtb250aCB0byBtb250aC4gVGhpcyBpcyBvbmx5XG4gIC8vIGhvdyBtYW55IG1vbnRocyBvZiBzY2hlZHVsZSB0byByYWlzZSB1cCBmcm9udCwgd2hpY2ggdGhlIG93bmVyIGNhbiBleHRlbmQuXG4gIGNvbnN0IFttb250aHMsIHNldE1vbnRoc10gPSB1c2VTdGF0ZSgxMik7XG4gIGNvbnN0IFttZXNzYWdlLCBzZXRNZXNzYWdlXSA9IHVzZVN0YXRlKFwiXCIpO1xuICBjb25zdCBbc2VuZGluZywgc2V0U2VuZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XG5cbiAgY29uc3QgYW1vdW50ID0gbGlzdGluZy5zcGFjZS5jb3N0LnByaWNlO1xuXG4gIGNvbnN0IHN1Ym1pdCA9IGFzeW5jICgpID0+IHtcbiAgICBzZXRTZW5kaW5nKHRydWUpO1xuICAgIHNldEVycm9yKG51bGwpO1xuXG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IGRiLnJlcXVlc3RCb29raW5nKHtcbiAgICAgICAgc3BhY2VJZDogbGlzdGluZy5zcGFjZS5pZCxcbiAgICAgICAgbW92ZUluRGF0ZTogbW92ZUluLFxuICAgICAgICBtb250aHMsXG4gICAgICAgIGFtb3VudCxcbiAgICAgICAgbWVzc2FnZTogbWVzc2FnZS50cmltKCkgfHwgdW5kZWZpbmVkLFxuICAgICAgfSk7XG4gICAgICBvbkNsb3NlKCk7XG4gICAgICBuYXZpZ2F0ZShcIi9ib29raW5nc1wiKTtcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICBzZXRFcnJvcihlIGluc3RhbmNlb2YgRXJyb3IgPyBlLm1lc3NhZ2UgOiB0KFwiYXV0aC5lcnJvckdlbmVyaWNcIikpO1xuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRTZW5kaW5nKGZhbHNlKTtcbiAgICB9XG4gIH07XG5cbiAgcmV0dXJuIChcbiAgICA8TW9kYWxcbiAgICAgIG9wZW49e29wZW59XG4gICAgICBvbkNsb3NlPXtvbkNsb3NlfVxuICAgICAgdGl0bGU9e3QoXCJib29raW5nLnJlcXVlc3RUaXRsZVwiKX1cbiAgICAgIGZvb3Rlcj17XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtMlwiPlxuICAgICAgICAgIDxCdXR0b24gdmFyaWFudD1cInNlY29uZGFyeVwiIGZ1bGxXaWR0aCBvbkNsaWNrPXtvbkNsb3NlfT5cbiAgICAgICAgICAgIHt0KFwiYWN0aW9uLmNhbmNlbFwiKX1cbiAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICA8QnV0dG9uIGZ1bGxXaWR0aCBkaXNhYmxlZD17c2VuZGluZ30gb25DbGljaz17KCkgPT4gdm9pZCBzdWJtaXQoKX0+XG4gICAgICAgICAgICB7c2VuZGluZyA/IHQoXCJhY3Rpb24uc2VuZGluZ1wiKSA6IHQoXCJib29raW5nLnJlcXVlc3RcIil9XG4gICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgIDwvZGl2PlxuICAgICAgfVxuICAgID5cbiAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gbGVhZGluZy1yZWxheGVkIHRleHQtaW5rLXNvZnRcIj57dChcImJvb2tpbmcucmVxdWVzdEJvZHlcIil9PC9wPlxuXG4gICAgICB7Y29uZmlndXJlZCAmJiAhYWNjb3VudCAmJiAoXG4gICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTMgcm91bmRlZC14bCBiZy13YXJuLTEwMCBwLTMgdGV4dC1zbSBsZWFkaW5nLXJlbGF4ZWQgdGV4dC13YXJuLTcwMFwiPlxuICAgICAgICAgIHt0KFwiaW5xdWlyeS5zaWduSW5GaXJzdFwiKX1cbiAgICAgICAgPC9wPlxuICAgICAgKX1cblxuICAgICAge2Vycm9yICYmIChcbiAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMyByb3VuZGVkLXhsIGJnLWRhbmdlci0xMDAgcC0zIHRleHQtc20gdGV4dC1kYW5nZXItNjAwXCI+e2Vycm9yfTwvcD5cbiAgICAgICl9XG5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNCBncmlkIGdhcC00IHNtOmdyaWQtY29scy0yXCI+XG4gICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9ja1wiPlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1iLTEuNSBibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtaW5rLXNvZnRcIj57dChcImJvb2tpbmcubW92ZUluXCIpfTwvc3Bhbj5cbiAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcbiAgICAgICAgICAgIHZhbHVlPXttb3ZlSW59XG4gICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldE1vdmVJbihlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJoLTExIHctZnVsbCByb3VuZGVkLXhsIGJnLWl2b3J5IHB4LTMgdGV4dC1bMC45Mzc1cmVtXSByaW5nLTEgcmluZy1oYWlybGluZS1zdHJvbmcgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWFxdWEtNjAwXCJcbiAgICAgICAgICAvPlxuICAgICAgICA8L2xhYmVsPlxuXG4gICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9ja1wiPlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1iLTEuNSBibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtaW5rLXNvZnRcIj5cbiAgICAgICAgICAgIHt0KFwiYm9va2luZy5ob3dMb25nXCIpfVxuICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICA8c2VsZWN0XG4gICAgICAgICAgICB2YWx1ZT17bW9udGhzfVxuICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRNb250aHMoTnVtYmVyKGUudGFyZ2V0LnZhbHVlKSl9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJoLTExIHctZnVsbCByb3VuZGVkLXhsIGJnLWl2b3J5IHB4LTMgdGV4dC1bMC45Mzc1cmVtXSByaW5nLTEgcmluZy1oYWlybGluZS1zdHJvbmcgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWFxdWEtNjAwXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICA8b3B0aW9uIHZhbHVlPXszfT57dChcImJvb2tpbmcuc3BhbjNcIil9PC9vcHRpb24+XG4gICAgICAgICAgICA8b3B0aW9uIHZhbHVlPXs2fT57dChcImJvb2tpbmcuc3BhbjZcIil9PC9vcHRpb24+XG4gICAgICAgICAgICA8b3B0aW9uIHZhbHVlPXsxMn0+e3QoXCJib29raW5nLnNwYW4xMlwiKX08L29wdGlvbj5cbiAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9ezI0fT57dChcImJvb2tpbmcuc3BhbjI0XCIpfTwvb3B0aW9uPlxuICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICA8L2xhYmVsPlxuICAgICAgPC9kaXY+XG5cbiAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJtdC00IGJsb2NrXCI+XG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1iLTEuNSBibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtaW5rLXNvZnRcIj57dChcImlucXVpcnkueW91ck1lc3NhZ2VcIil9PC9zcGFuPlxuICAgICAgICA8dGV4dGFyZWFcbiAgICAgICAgICByb3dzPXszfVxuICAgICAgICAgIHZhbHVlPXttZXNzYWdlfVxuICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0TWVzc2FnZShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgcGxhY2Vob2xkZXI9e3QoXCJpbnF1aXJ5LmRlZmF1bHRcIil9XG4gICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHJvdW5kZWQteGwgYmctaXZvcnkgcC0zIHRleHQtWzAuOTM3NXJlbV0gcmluZy0xIHJpbmctaGFpcmxpbmUtc3Ryb25nIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1hcXVhLTYwMFwiXG4gICAgICAgIC8+XG4gICAgICA8L2xhYmVsPlxuXG4gICAgICA8ZGwgY2xhc3NOYW1lPVwibXQtNCBmbGV4IGp1c3RpZnktYmV0d2VlbiByb3VuZGVkLXhsIGJnLWl2b3J5IHAtMyB0ZXh0LXNtXCI+XG4gICAgICAgIDxkdCBjbGFzc05hbWU9XCJ0ZXh0LW11dGVkXCI+e3QoXCJib29raW5nLmFtb3VudFwiKX08L2R0PlxuICAgICAgICA8ZGQgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0bnVtIHRleHQtaW5rXCI+XG4gICAgICAgICAge21vbmV5KGFtb3VudCl9XG4gICAgICAgICAge2xpc3Rpbmcuc3BhY2UudHJhbnNhY3Rpb24gPT09IFwicmVudFwiICYmIHQoXCJ0cmFuc2FjdGlvbi5wZXJNb250aFwiKX1cbiAgICAgICAgPC9kZD5cbiAgICAgIDwvZGw+XG5cbiAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTMgdGV4dC14cyBsZWFkaW5nLXJlbGF4ZWQgdGV4dC1tdXRlZFwiPnt0KFwiYm9va2luZy5ob3dMb25nTm90ZVwiKX08L3A+XG5cbiAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgZmxleCBpdGVtcy1zdGFydCBnYXAtMiB0ZXh0LXhzIGxlYWRpbmctcmVsYXhlZCB0ZXh0LW11dGVkXCI+XG4gICAgICAgIDxDbG9jayBzaXplPXsxM30gY2xhc3NOYW1lPVwibXQtMC41IHNocmluay0wXCIgYXJpYS1oaWRkZW4gLz5cbiAgICAgICAge3QoXCJib29raW5nLnBob25lTGF0ZXJcIil9XG4gICAgICA8L3A+XG4gICAgPC9Nb2RhbD5cbiAgKTtcbn1cblxuZnVuY3Rpb24gSW5xdWlyeU1vZGFsKHtcbiAgb3BlbixcbiAgb25DbG9zZSxcbiAgbGlzdGluZyxcbiAgb25TZW5kLFxuICByZXF1aXJlbWVudHMsXG59OiB7XG4gIG9wZW46IGJvb2xlYW47XG4gIG9uQ2xvc2U6ICgpID0+IHZvaWQ7XG4gIGxpc3Rpbmc6IFNwYWNlTGlzdGluZztcbiAgb25TZW5kOiBSZXR1cm5UeXBlPHR5cGVvZiB1c2VIYWJpdG8+W1wic2VuZElucXVpcnlcIl07XG4gIHJlcXVpcmVtZW50czogUmV0dXJuVHlwZTx0eXBlb2YgdXNlSGFiaXRvPltcInJlcXVpcmVtZW50c1wiXTtcbn0pIHtcbiAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpO1xuICBjb25zdCB7IGFjY291bnQsIGNvbmZpZ3VyZWQgfSA9IHVzZUF1dGgoKTtcbiAgY29uc3QgW25hbWUsIHNldE5hbWVdID0gdXNlU3RhdGUoXCJcIik7XG4gIGNvbnN0IFttZXNzYWdlLCBzZXRNZXNzYWdlXSA9IHVzZVN0YXRlKFwiSGksIEknbSBpbnRlcmVzdGVkIGluIHRoaXMgc3BhY2UuIElzIGl0IHN0aWxsIGF2YWlsYWJsZT9cIik7XG4gIGNvbnN0IFttb3ZlSW4sIHNldE1vdmVJbl0gPSB1c2VTdGF0ZShyZXF1aXJlbWVudHMubW92ZUluRGF0ZSk7XG4gIGNvbnN0IFtzZW50LCBzZXRTZW50XSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW3NlbmRpbmcsIHNldFNlbmRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbZXJyb3IsIHNldEVycm9yXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKGFjY291bnQ/Lm5hbWUpIHNldE5hbWUoYWNjb3VudC5uYW1lKTtcbiAgfSwgW2FjY291bnRdKTtcblxuICBjb25zdCBzZW5kID0gYXN5bmMgKCkgPT4ge1xuICAgIHNldFNlbmRpbmcodHJ1ZSk7XG4gICAgc2V0RXJyb3IobnVsbCk7XG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IG9uU2VuZCh7XG4gICAgICAgIHNwYWNlSWQ6IGxpc3Rpbmcuc3BhY2UuaWQsXG4gICAgICAgIG5hbWU6IG5hbWUudHJpbSgpIHx8IGFjY291bnQ/Lm5hbWUgfHwgXCJIYWJpdG8gdXNlclwiLFxuICAgICAgICBtZXNzYWdlLFxuICAgICAgICBtb3ZlSW5EYXRlOiBtb3ZlSW4sXG4gICAgICAgIGJ1ZGdldE1pbjogcmVxdWlyZW1lbnRzLmJ1ZGdldE1pbixcbiAgICAgICAgYnVkZ2V0TWF4OiByZXF1aXJlbWVudHMuYnVkZ2V0TWF4LFxuICAgICAgfSk7XG4gICAgICBzZXRTZW50KHRydWUpO1xuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIHNldEVycm9yKGUgaW5zdGFuY2VvZiBFcnJvciA/IGUubWVzc2FnZSA6IFwiWW91ciBpbnF1aXJ5IGRpZG4ndCBzZW5kLlwiKTtcbiAgICB9IGZpbmFsbHkge1xuICAgICAgc2V0U2VuZGluZyhmYWxzZSk7XG4gICAgfVxuICB9O1xuXG4gIGNvbnN0IG9wZW5UaHJlYWQgPSBhc3luYyAoKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IGlkID0gYXdhaXQgZGIub3BlbkNvbnZlcnNhdGlvbihsaXN0aW5nLnNwYWNlLmlkKTtcbiAgICAgIG5hdmlnYXRlKGAvbWVzc2FnZXMvJHtpZH1gKTtcbiAgICB9IGNhdGNoIHtcbiAgICAgIG5hdmlnYXRlKFwiL21lc3NhZ2VzXCIpO1xuICAgIH1cbiAgfTtcblxuICBjb25zdCBjbG9zZSA9ICgpID0+IHtcbiAgICBvbkNsb3NlKCk7XG4gICAgd2luZG93LnNldFRpbWVvdXQoKCkgPT4gc2V0U2VudChmYWxzZSksIDI1MCk7XG4gIH07XG5cbiAgcmV0dXJuIChcbiAgICA8TW9kYWxcbiAgICAgIG9wZW49e29wZW59XG4gICAgICBvbkNsb3NlPXtjbG9zZX1cbiAgICAgIHRpdGxlPXtzZW50ID8gXCJJbnF1aXJ5IHNlbnRcIiA6IFwiU2VuZCBhbiBpbnF1aXJ5XCJ9XG4gICAgICBmb290ZXI9e1xuICAgICAgICBzZW50ID8gKFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtMlwiPlxuICAgICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwic2Vjb25kYXJ5XCIgZnVsbFdpZHRoIG9uQ2xpY2s9e2Nsb3NlfT5cbiAgICAgICAgICAgICAgRG9uZVxuICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgICA8QnV0dG9uIGZ1bGxXaWR0aCBvbkNsaWNrPXsoKSA9PiB2b2lkIG9wZW5UaHJlYWQoKX0+XG4gICAgICAgICAgICAgIE9wZW4gY29udmVyc2F0aW9uXG4gICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKSA6IChcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTJcIj5cbiAgICAgICAgICAgIDxCdXR0b24gdmFyaWFudD1cInNlY29uZGFyeVwiIGZ1bGxXaWR0aCBvbkNsaWNrPXtjbG9zZX0+XG4gICAgICAgICAgICAgIENhbmNlbFxuICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICAgIGZ1bGxXaWR0aFxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB2b2lkIHNlbmQoKX1cbiAgICAgICAgICAgICAgZGlzYWJsZWQ9e3NlbmRpbmcgfHwgbWVzc2FnZS50cmltKCkubGVuZ3RoID09PSAwfVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICB7c2VuZGluZyA/IFwiU2VuZGluZ+KAplwiIDogXCJTZW5kXCJ9XG4gICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKVxuICAgICAgfVxuICAgID5cbiAgICAgIHtzZW50ID8gKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktM1wiPlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gbGVhZGluZy1yZWxheGVkIHRleHQtaW5rLXNvZnRcIj5cbiAgICAgICAgICAgIHtsaXN0aW5nLm93bmVyLm5hbWV9IG5vdyBoYXMgeW91ciBtZXNzYWdlLCBidWRnZXQgYW5kIG1vdmUtaW4gZGF0ZS4gUmVwbGllcyBhcnJpdmUgaW5cbiAgICAgICAgICAgIE1lc3NhZ2VzLCBhbmQgeW91J2xsIHNlZSBhIGJhZGdlIHdoZW4gb25lIGxhbmRzLlxuICAgICAgICAgIDwvcD5cbiAgICAgICAgPC9kaXY+XG4gICAgICApIDogKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgcm91bmRlZC0yeGwgYmctaXZvcnktZGVlcCBwLTNcIj5cbiAgICAgICAgICAgIDxpbWcgc3JjPXtsaXN0aW5nLnNwYWNlLmltYWdlc1swXS51cmx9IGFsdD1cIlwiIGNsYXNzTmFtZT1cInNpemUtMTIgcm91bmRlZC14bCBvYmplY3QtY292ZXJcIiAvPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtaW4tdy0wXCI+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRydW5jYXRlIGZvbnQtc2VtaWJvbGQgdGV4dC1pbmtcIj57bGlzdGluZy5zcGFjZS5uYW1lfTwvcD5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidHJ1bmNhdGUgdGV4dC1zbSB0ZXh0LW11dGVkXCI+XG4gICAgICAgICAgICAgICAge2xpc3RpbmcucHJvcGVydHkuYXJlYX0gwrcge21vbmV5KGxpc3Rpbmcuc3BhY2UuY29zdC5wcmljZSl9XG4gICAgICAgICAgICAgICAge2xpc3Rpbmcuc3BhY2UudHJhbnNhY3Rpb24gPT09IFwicmVudFwiICYmIFwiL21vbnRoXCJ9XG4gICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgPEZpZWxkIGxhYmVsPVwiWW91ciBuYW1lXCI+XG4gICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgdmFsdWU9e25hbWV9XG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0TmFtZShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU28gdGhlIG93bmVyIGtub3dzIHdobydzIGFza2luZ1wiXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImgtMTEgdy1mdWxsIHJvdW5kZWQteGwgYmctaXZvcnkgcHgtMyB0ZXh0LVswLjkzNzVyZW1dIHJpbmctMSByaW5nLWhhaXJsaW5lLXN0cm9uZyBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctYXF1YS02MDBcIlxuICAgICAgICAgICAgLz5cbiAgICAgICAgICA8L0ZpZWxkPlxuXG4gICAgICAgICAgPEZpZWxkIGxhYmVsPVwiTWVzc2FnZVwiPlxuICAgICAgICAgICAgPHRleHRhcmVhXG4gICAgICAgICAgICAgIHJvd3M9ezN9XG4gICAgICAgICAgICAgIHZhbHVlPXttZXNzYWdlfVxuICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldE1lc3NhZ2UoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcm91bmRlZC14bCBiZy1pdm9yeSBwLTMgdGV4dC1bMC45Mzc1cmVtXSByaW5nLTEgcmluZy1oYWlybGluZS1zdHJvbmcgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWFxdWEtNjAwXCJcbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgPC9GaWVsZD5cblxuICAgICAgICAgIDxGaWVsZCBsYWJlbD1cIldoZW4geW91J2QgbW92ZSBpblwiPlxuICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcbiAgICAgICAgICAgICAgdmFsdWU9e21vdmVJbn1cbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRNb3ZlSW4oZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoLTExIHctZnVsbCByb3VuZGVkLXhsIGJnLWl2b3J5IHB4LTMgdGV4dC1bMC45Mzc1cmVtXSByaW5nLTEgcmluZy1oYWlybGluZS1zdHJvbmcgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWFxdWEtNjAwXCJcbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgPC9GaWVsZD5cblxuICAgICAgICAgIHtlcnJvciAmJiA8cCBjbGFzc05hbWU9XCJyb3VuZGVkLXhsIGJnLWRhbmdlci0xMDAgcC0zIHRleHQtc20gdGV4dC1kYW5nZXItNjAwXCI+e2Vycm9yfTwvcD59XG5cbiAgICAgICAgICB7Y29uZmlndXJlZCAmJiAhYWNjb3VudCAmJiAoXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJyb3VuZGVkLXhsIGJnLXdhcm4tMTAwIHAtMyB0ZXh0LXNtIGxlYWRpbmctcmVsYXhlZCB0ZXh0LXdhcm4tNzAwXCI+XG4gICAgICAgICAgICAgIFlvdSdsbCBuZWVkIHRve1wiIFwifVxuICAgICAgICAgICAgICA8TGluayB0bz1cIi9zaWduaW5cIiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHVuZGVybGluZVwiPlxuICAgICAgICAgICAgICAgIHNpZ24gaW5cbiAgICAgICAgICAgICAgPC9MaW5rPntcIiBcIn1cbiAgICAgICAgICAgICAgYmVmb3JlIGFuIG93bmVyIGNhbiByZXBseSB0byB5b3UuXG4gICAgICAgICAgICA8L3A+XG4gICAgICAgICAgKX1cblxuICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1pbmstc29mdFwiPlNlbnQgd2l0aCB5b3VyIGlucXVpcnk8L3A+XG4gICAgICAgICAgICA8dWwgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgZ2FwLTEuNSB0ZXh0LXhzXCI+XG4gICAgICAgICAgICAgIDxsaSBjbGFzc05hbWU9XCJyb3VuZGVkLWZ1bGwgYmctYXF1YS0xMDAgcHgtMi41IHB5LTEgZm9udC1zZW1pYm9sZCB0ZXh0LWFxdWEtNzAwXCI+XG4gICAgICAgICAgICAgICAgQnVkZ2V0IHttb25leShyZXF1aXJlbWVudHMuYnVkZ2V0TWluKX3igJN7bW9uZXkocmVxdWlyZW1lbnRzLmJ1ZGdldE1heCl9XG4gICAgICAgICAgICAgIDwvbGk+XG4gICAgICAgICAgICAgIDxsaSBjbGFzc05hbWU9XCJyb3VuZGVkLWZ1bGwgYmctYXF1YS0xMDAgcHgtMi41IHB5LTEgZm9udC1zZW1pYm9sZCB0ZXh0LWFxdWEtNzAwXCI+XG4gICAgICAgICAgICAgICAgTW92aW5nIHtsb25nRGF0ZShtb3ZlSW4pfVxuICAgICAgICAgICAgICA8L2xpPlxuICAgICAgICAgICAgPC91bD5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC14cyB0ZXh0LW11dGVkXCI+WW91ciBwaG9uZSBudW1iZXIgaXNuJ3Qgc2hhcmVkIHVudGlsIHlvdSBjaG9vc2UgdG8uPC9wPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG4gICAgPC9Nb2RhbD5cbiAgKTtcbn1cblxuZnVuY3Rpb24gRmllbGQoeyBsYWJlbCwgY2hpbGRyZW4gfTogeyBsYWJlbDogc3RyaW5nOyBjaGlsZHJlbjogUmVhY3QuUmVhY3ROb2RlIH0pIHtcbiAgcmV0dXJuIChcbiAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2tcIj5cbiAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1iLTEuNSBibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtaW5rLXNvZnRcIj57bGFiZWx9PC9zcGFuPlxuICAgICAge2NoaWxkcmVufVxuICAgIDwvbGFiZWw+XG4gICk7XG59XG4iXSwiZmlsZSI6IkQ6L0kySSBQcm9qZWN0IC0gSGFiaXRvL0FwcCBGb2xkZXIvaGFiaXRvL3NyYy9wYWdlcy9TcGFjZURldGFpbC50c3gifQ==