import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/i18n/index.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=9ceb86a3"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("D:/I2I Project - Habito/App Folder/habito/src/i18n/index.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9ceb86a3"; const createContext = __vite__cjsImport3_react["createContext"]; const useCallback = __vite__cjsImport3_react["useCallback"]; const useContext = __vite__cjsImport3_react["useContext"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useMemo = __vite__cjsImport3_react["useMemo"]; const useState = __vite__cjsImport3_react["useState"];
import { supabase } from "/src/lib/supabase.ts";
import { en } from "/src/i18n/en.ts";
import { bn } from "/src/i18n/bn.ts";
const DICTIONARIES = { en, bn };
const STORAGE_KEY = "habito.language";
const Ctx = createContext(null);
const BENGALI_DIGITS = ["০", "১", "২", "৩", "৪", "৫", "৬", "৭", "৮", "৯"];
function formatNumber(value, language) {
  const grouped = value.toLocaleString("en-IN");
  if (language === "en") return grouped;
  return grouped.replace(/\d/g, (d) => BENGALI_DIGITS[Number(d)]);
}
function detectInitial() {
  if (typeof window === "undefined") return "en";
  const stored = window.localStorage.getItem(STORAGE_KEY);
  if (stored === "en" || stored === "bn") return stored;
  return navigator.language?.toLowerCase().startsWith("bn") ? "bn" : "en";
}
export function I18nProvider({ children }) {
  _s();
  const [language, setLanguageState] = useState(detectInitial);
  useEffect(() => {
    document.documentElement.lang = language;
    document.documentElement.dataset.lang = language;
  }, [language]);
  const setLanguage = useCallback((lang) => {
    setLanguageState(lang);
    try {
      window.localStorage.setItem(STORAGE_KEY, lang);
    } catch {
    }
    const client = supabase;
    if (client) {
      void client.auth.getUser().then(({ data }) => {
        if (data.user) void client.from("profiles").update({ language: lang }).eq("id", data.user.id);
      });
    }
  }, []);
  const t = useCallback(
    (key, values) => {
      const dict = DICTIONARIES[language];
      let text = dict[key] ?? en[key] ?? String(key);
      if (values) {
        for (const [name, value2] of Object.entries(values)) {
          const rendered = typeof value2 === "number" ? formatNumber(value2, language) : value2;
          text = text.split(`{${name}}`).join(String(rendered));
        }
      }
      return text;
    },
    [language]
  );
  const value = useMemo(
    () => ({
      language,
      setLanguage,
      t,
      num: (v) => formatNumber(v, language),
      money: (v) => `৳${formatNumber(v, language)}`
    }),
    [language, setLanguage, t]
  );
  return /* @__PURE__ */ jsxDEV(Ctx.Provider, { value, children }, void 0, false, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/i18n/index.tsx",
    lineNumber: 122,
    columnNumber: 10
  }, this);
}
_s(I18nProvider, "LXZuqtkPgZj3bWix4zntw7jtwNM=");
_c = I18nProvider;
export function useI18n() {
  _s2();
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useI18n must be used inside I18nProvider");
  return ctx;
}
_s2(useI18n, "/dMy7t63NXD4eYACoT93CePwGrg=");
var _c;
$RefreshReg$(_c, "I18nProvider");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/I2I Project - Habito/App Folder/habito/src/i18n/index.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/I2I Project - Habito/App Folder/habito/src/i18n/index.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0dTOzs7Ozs7Ozs7Ozs7Ozs7OztBQXRHVCxTQUFTQSxlQUFlQyxhQUFhQyxZQUFZQyxXQUFXQyxTQUFTQyxnQkFBZ0I7QUFFckYsU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLFVBQVU7QUFDbkIsU0FBU0MsVUFBVTtBQU9uQixNQUFNQyxlQUFpRSxFQUFFRixJQUFJQyxHQUFHO0FBRWhGLE1BQU1FLGNBQWM7QUFhcEIsTUFBTUMsTUFBTVgsY0FBZ0MsSUFBSTtBQUVoRCxNQUFNWSxpQkFBaUIsQ0FBQyxLQUFLLEtBQUssS0FBSyxLQUFLLEtBQUssS0FBSyxLQUFLLEtBQUssS0FBSyxHQUFHO0FBR3hFLFNBQVNDLGFBQWFDLE9BQWVDLFVBQTRCO0FBQy9ELFFBQU1DLFVBQVVGLE1BQU1HLGVBQWUsT0FBTztBQUM1QyxNQUFJRixhQUFhLEtBQU0sUUFBT0M7QUFDOUIsU0FBT0EsUUFBUUUsUUFBUSxPQUFPLENBQUNDLE1BQU1QLGVBQWVRLE9BQU9ELENBQUMsQ0FBQyxDQUFDO0FBQ2hFO0FBRUEsU0FBU0UsZ0JBQTBCO0FBQ2pDLE1BQUksT0FBT0MsV0FBVyxZQUFhLFFBQU87QUFFMUMsUUFBTUMsU0FBU0QsT0FBT0UsYUFBYUMsUUFBUWYsV0FBVztBQUN0RCxNQUFJYSxXQUFXLFFBQVFBLFdBQVcsS0FBTSxRQUFPQTtBQUcvQyxTQUFPRyxVQUFVWCxVQUFVWSxZQUFZLEVBQUVDLFdBQVcsSUFBSSxJQUFJLE9BQU87QUFDckU7QUFFTyxnQkFBU0MsYUFBYSxFQUFFQyxTQUFrQyxHQUFHO0FBQUFDLEtBQUE7QUFDbEUsUUFBTSxDQUFDaEIsVUFBVWlCLGdCQUFnQixJQUFJM0IsU0FBbUJnQixhQUFhO0FBRXJFbEIsWUFBVSxNQUFNO0FBQ2Q4QixhQUFTQyxnQkFBZ0JDLE9BQU9wQjtBQUVoQ2tCLGFBQVNDLGdCQUFnQkUsUUFBUUQsT0FBT3BCO0FBQUFBLEVBQzFDLEdBQUcsQ0FBQ0EsUUFBUSxDQUFDO0FBRWIsUUFBTXNCLGNBQWNwQyxZQUFZLENBQUNrQyxTQUFtQjtBQUNsREgscUJBQWlCRyxJQUFJO0FBQ3JCLFFBQUk7QUFDRmIsYUFBT0UsYUFBYWMsUUFBUTVCLGFBQWF5QixJQUFJO0FBQUEsSUFDL0MsUUFBUTtBQUFBLElBQ047QUFJRixVQUFNSSxTQUFTakM7QUFDZixRQUFJaUMsUUFBUTtBQUNWLFdBQUtBLE9BQU9DLEtBQUtDLFFBQVEsRUFBRUMsS0FBSyxDQUFDLEVBQUVDLEtBQUssTUFBTTtBQUM1QyxZQUFJQSxLQUFLQyxLQUFNLE1BQUtMLE9BQU9NLEtBQUssVUFBVSxFQUFFQyxPQUFPLEVBQUUvQixVQUFVb0IsS0FBSyxDQUFDLEVBQUVZLEdBQUcsTUFBTUosS0FBS0MsS0FBS0ksRUFBRTtBQUFBLE1BQzlGLENBQUM7QUFBQSxJQUNIO0FBQUEsRUFDRixHQUFHLEVBQUU7QUFFTCxRQUFNQyxJQUFJaEQ7QUFBQUEsSUFDUixDQUFDaUQsS0FBS0MsV0FBVztBQUNmLFlBQU1DLE9BQU8zQyxhQUFhTSxRQUFRO0FBRWxDLFVBQUlzQyxPQUFlRCxLQUFLRixHQUFHLEtBQUszQyxHQUFHMkMsR0FBRyxLQUFLSSxPQUFPSixHQUFHO0FBRXJELFVBQUlDLFFBQVE7QUFDVixtQkFBVyxDQUFDSSxNQUFNekMsTUFBSyxLQUFLMEMsT0FBT0MsUUFBUU4sTUFBTSxHQUFHO0FBQ2xELGdCQUFNTyxXQUFXLE9BQU81QyxXQUFVLFdBQVdELGFBQWFDLFFBQU9DLFFBQVEsSUFBSUQ7QUFDN0V1QyxpQkFBT0EsS0FBS00sTUFBTSxJQUFJSixJQUFJLEdBQUcsRUFBRUssS0FBS04sT0FBT0ksUUFBUSxDQUFDO0FBQUEsUUFDdEQ7QUFBQSxNQUNGO0FBRUEsYUFBT0w7QUFBQUEsSUFDVDtBQUFBLElBQ0EsQ0FBQ3RDLFFBQVE7QUFBQSxFQUNYO0FBRUEsUUFBTUQsUUFBUVY7QUFBQUEsSUFDWixPQUFPO0FBQUEsTUFDTFc7QUFBQUEsTUFDQXNCO0FBQUFBLE1BQ0FZO0FBQUFBLE1BQ0FZLEtBQUtBLENBQUNDLE1BQU1qRCxhQUFhaUQsR0FBRy9DLFFBQVE7QUFBQSxNQUNwQ2dELE9BQU9BLENBQUNELE1BQU0sSUFBU2pELGFBQWFpRCxHQUFHL0MsUUFBUSxDQUFDO0FBQUEsSUFDbEQ7QUFBQSxJQUNBLENBQUNBLFVBQVVzQixhQUFhWSxDQUFDO0FBQUEsRUFDM0I7QUFFQSxTQUFPLHVCQUFDLElBQUksVUFBSixFQUFhLE9BQWVuQixZQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXNDO0FBQy9DO0FBQUNDLEdBeERlRixjQUFZO0FBQUEsS0FBWkE7QUEwRFQsZ0JBQVNtQyxVQUFxQjtBQUFBQyxNQUFBO0FBQ25DLFFBQU1DLE1BQU1oRSxXQUFXUyxHQUFHO0FBQzFCLE1BQUksQ0FBQ3VELElBQUssT0FBTSxJQUFJQyxNQUFNLDBDQUEwQztBQUNwRSxTQUFPRDtBQUNUO0FBQUNELElBSmVELFNBQU87QUFBQSxJQUFBSTtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJjcmVhdGVDb250ZXh0IiwidXNlQ2FsbGJhY2siLCJ1c2VDb250ZXh0IiwidXNlRWZmZWN0IiwidXNlTWVtbyIsInVzZVN0YXRlIiwic3VwYWJhc2UiLCJlbiIsImJuIiwiRElDVElPTkFSSUVTIiwiU1RPUkFHRV9LRVkiLCJDdHgiLCJCRU5HQUxJX0RJR0lUUyIsImZvcm1hdE51bWJlciIsInZhbHVlIiwibGFuZ3VhZ2UiLCJncm91cGVkIiwidG9Mb2NhbGVTdHJpbmciLCJyZXBsYWNlIiwiZCIsIk51bWJlciIsImRldGVjdEluaXRpYWwiLCJ3aW5kb3ciLCJzdG9yZWQiLCJsb2NhbFN0b3JhZ2UiLCJnZXRJdGVtIiwibmF2aWdhdG9yIiwidG9Mb3dlckNhc2UiLCJzdGFydHNXaXRoIiwiSTE4blByb3ZpZGVyIiwiY2hpbGRyZW4iLCJfcyIsInNldExhbmd1YWdlU3RhdGUiLCJkb2N1bWVudCIsImRvY3VtZW50RWxlbWVudCIsImxhbmciLCJkYXRhc2V0Iiwic2V0TGFuZ3VhZ2UiLCJzZXRJdGVtIiwiY2xpZW50IiwiYXV0aCIsImdldFVzZXIiLCJ0aGVuIiwiZGF0YSIsInVzZXIiLCJmcm9tIiwidXBkYXRlIiwiZXEiLCJpZCIsInQiLCJrZXkiLCJ2YWx1ZXMiLCJkaWN0IiwidGV4dCIsIlN0cmluZyIsIm5hbWUiLCJPYmplY3QiLCJlbnRyaWVzIiwicmVuZGVyZWQiLCJzcGxpdCIsImpvaW4iLCJudW0iLCJ2IiwibW9uZXkiLCJ1c2VJMThuIiwiX3MyIiwiY3R4IiwiRXJyb3IiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJpbmRleC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgY3JlYXRlQ29udGV4dCwgdXNlQ2FsbGJhY2ssIHVzZUNvbnRleHQsIHVzZUVmZmVjdCwgdXNlTWVtbywgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB0eXBlIHsgUmVhY3ROb2RlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBzdXBhYmFzZSB9IGZyb20gXCJAL2xpYi9zdXBhYmFzZVwiO1xuaW1wb3J0IHsgZW4gfSBmcm9tIFwiLi9lblwiO1xuaW1wb3J0IHsgYm4gfSBmcm9tIFwiLi9iblwiO1xuXG5leHBvcnQgdHlwZSBMYW5ndWFnZSA9IFwiZW5cIiB8IFwiYm5cIjtcblxuLyoqIEV2ZXJ5IGtleSBtdXN0IGV4aXN0IGluIGJvdGggZGljdGlvbmFyaWVzIOKAlCB0aGUgdHlwZSBlbmZvcmNlcyBpdC4gKi9cbmV4cG9ydCB0eXBlIFRyYW5zbGF0aW9uS2V5ID0ga2V5b2YgdHlwZW9mIGVuO1xuXG5jb25zdCBESUNUSU9OQVJJRVM6IFJlY29yZDxMYW5ndWFnZSwgUmVjb3JkPFRyYW5zbGF0aW9uS2V5LCBzdHJpbmc+PiA9IHsgZW4sIGJuIH07XG5cbmNvbnN0IFNUT1JBR0VfS0VZID0gXCJoYWJpdG8ubGFuZ3VhZ2VcIjtcblxuaW50ZXJmYWNlIEkxOG5TdGF0ZSB7XG4gIGxhbmd1YWdlOiBMYW5ndWFnZTtcbiAgc2V0TGFuZ3VhZ2U6IChsYW5nOiBMYW5ndWFnZSkgPT4gdm9pZDtcbiAgLyoqIFRyYW5zbGF0ZS4gVmFsdWVzIGluIHticmFjZXN9IGFyZSBzdWJzdGl0dXRlZC4gKi9cbiAgdDogKGtleTogVHJhbnNsYXRpb25LZXksIHZhbHVlcz86IFJlY29yZDxzdHJpbmcsIHN0cmluZyB8IG51bWJlcj4pID0+IHN0cmluZztcbiAgLyoqIEZvcm1hdCBhIG51bWJlciBpbiB0aGUgYWN0aXZlIHNjcmlwdDogMTIsMDAwIG9yIOCnp+CnqCzgp6bgp6bgp6YuICovXG4gIG51bTogKHZhbHVlOiBudW1iZXIpID0+IHN0cmluZztcbiAgLyoqIE1vbmV5IGluIHRoZSBhY3RpdmUgc2NyaXB0LCBlLmcuIOCnszEyLDAwMCBvciDgp7Pgp6fgp6gs4Kem4Kem4KemLiAqL1xuICBtb25leTogKHZhbHVlOiBudW1iZXIpID0+IHN0cmluZztcbn1cblxuY29uc3QgQ3R4ID0gY3JlYXRlQ29udGV4dDxJMThuU3RhdGUgfCBudWxsPihudWxsKTtcblxuY29uc3QgQkVOR0FMSV9ESUdJVFMgPSBbXCLgp6ZcIiwgXCLgp6dcIiwgXCLgp6hcIiwgXCLgp6lcIiwgXCLgp6pcIiwgXCLgp6tcIiwgXCLgp6xcIiwgXCLgp61cIiwgXCLgp65cIiwgXCLgp69cIl07XG5cbi8qKiBCZW5nYWxpIHVzZXMgdGhlIEluZGlhbiBncm91cGluZyAoMSwyMCwwMDApLCB3aGljaCBlbi1JTiBhbHJlYWR5IGFwcGxpZXMuICovXG5mdW5jdGlvbiBmb3JtYXROdW1iZXIodmFsdWU6IG51bWJlciwgbGFuZ3VhZ2U6IExhbmd1YWdlKTogc3RyaW5nIHtcbiAgY29uc3QgZ3JvdXBlZCA9IHZhbHVlLnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIik7XG4gIGlmIChsYW5ndWFnZSA9PT0gXCJlblwiKSByZXR1cm4gZ3JvdXBlZDtcbiAgcmV0dXJuIGdyb3VwZWQucmVwbGFjZSgvXFxkL2csIChkKSA9PiBCRU5HQUxJX0RJR0lUU1tOdW1iZXIoZCldKTtcbn1cblxuZnVuY3Rpb24gZGV0ZWN0SW5pdGlhbCgpOiBMYW5ndWFnZSB7XG4gIGlmICh0eXBlb2Ygd2luZG93ID09PSBcInVuZGVmaW5lZFwiKSByZXR1cm4gXCJlblwiO1xuXG4gIGNvbnN0IHN0b3JlZCA9IHdpbmRvdy5sb2NhbFN0b3JhZ2UuZ2V0SXRlbShTVE9SQUdFX0tFWSk7XG4gIGlmIChzdG9yZWQgPT09IFwiZW5cIiB8fCBzdG9yZWQgPT09IFwiYm5cIikgcmV0dXJuIHN0b3JlZDtcblxuICAvLyBBIEJhbmdsYWRlc2hpIGJyb3dzZXIgc2hvdWxkIG5vdCBoYXZlIHRvIGdvIGxvb2tpbmcgZm9yIHRoZSB0b2dnbGUuXG4gIHJldHVybiBuYXZpZ2F0b3IubGFuZ3VhZ2U/LnRvTG93ZXJDYXNlKCkuc3RhcnRzV2l0aChcImJuXCIpID8gXCJiblwiIDogXCJlblwiO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gSTE4blByb3ZpZGVyKHsgY2hpbGRyZW4gfTogeyBjaGlsZHJlbjogUmVhY3ROb2RlIH0pIHtcbiAgY29uc3QgW2xhbmd1YWdlLCBzZXRMYW5ndWFnZVN0YXRlXSA9IHVzZVN0YXRlPExhbmd1YWdlPihkZXRlY3RJbml0aWFsKTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGRvY3VtZW50LmRvY3VtZW50RWxlbWVudC5sYW5nID0gbGFuZ3VhZ2U7XG4gICAgLy8gTGV0cyBDU1MgcGljayB0aGUgcmlnaHQgdHlwZWZhY2U6IEJyaWNvbGFnZSBoYXMgbm8gQmVuZ2FsaSBnbHlwaHMuXG4gICAgZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50LmRhdGFzZXQubGFuZyA9IGxhbmd1YWdlO1xuICB9LCBbbGFuZ3VhZ2VdKTtcblxuICBjb25zdCBzZXRMYW5ndWFnZSA9IHVzZUNhbGxiYWNrKChsYW5nOiBMYW5ndWFnZSkgPT4ge1xuICAgIHNldExhbmd1YWdlU3RhdGUobGFuZyk7XG4gICAgdHJ5IHtcbiAgICAgIHdpbmRvdy5sb2NhbFN0b3JhZ2Uuc2V0SXRlbShTVE9SQUdFX0tFWSwgbGFuZyk7XG4gICAgfSBjYXRjaCB7XG4gICAgICAvLyBQcml2YXRlIG1vZGUuIFRoZSBjaG9pY2Ugc3RpbGwgYXBwbGllcyBmb3IgdGhpcyBzZXNzaW9uLlxuICAgIH1cblxuICAgIC8vIFJlbWVtYmVyIGl0IG9uIHRoZSBhY2NvdW50IHRvbywgc28gaXQgZm9sbG93cyB0aGUgcGVyc29uIHRvIGEgbmV3IGRldmljZS5cbiAgICBjb25zdCBjbGllbnQgPSBzdXBhYmFzZTtcbiAgICBpZiAoY2xpZW50KSB7XG4gICAgICB2b2lkIGNsaWVudC5hdXRoLmdldFVzZXIoKS50aGVuKCh7IGRhdGEgfSkgPT4ge1xuICAgICAgICBpZiAoZGF0YS51c2VyKSB2b2lkIGNsaWVudC5mcm9tKFwicHJvZmlsZXNcIikudXBkYXRlKHsgbGFuZ3VhZ2U6IGxhbmcgfSkuZXEoXCJpZFwiLCBkYXRhLnVzZXIuaWQpO1xuICAgICAgfSk7XG4gICAgfVxuICB9LCBbXSk7XG5cbiAgY29uc3QgdCA9IHVzZUNhbGxiYWNrPEkxOG5TdGF0ZVtcInRcIl0+KFxuICAgIChrZXksIHZhbHVlcykgPT4ge1xuICAgICAgY29uc3QgZGljdCA9IERJQ1RJT05BUklFU1tsYW5ndWFnZV07XG4gICAgICAvLyBGYWxsaW5nIGJhY2sgdG8gRW5nbGlzaCBpcyBiZXR0ZXIgdGhhbiBzaG93aW5nIGEgcmF3IGtleSB0byBhIHVzZXIuXG4gICAgICBsZXQgdGV4dDogc3RyaW5nID0gZGljdFtrZXldID8/IGVuW2tleV0gPz8gU3RyaW5nKGtleSk7XG5cbiAgICAgIGlmICh2YWx1ZXMpIHtcbiAgICAgICAgZm9yIChjb25zdCBbbmFtZSwgdmFsdWVdIG9mIE9iamVjdC5lbnRyaWVzKHZhbHVlcykpIHtcbiAgICAgICAgICBjb25zdCByZW5kZXJlZCA9IHR5cGVvZiB2YWx1ZSA9PT0gXCJudW1iZXJcIiA/IGZvcm1hdE51bWJlcih2YWx1ZSwgbGFuZ3VhZ2UpIDogdmFsdWU7XG4gICAgICAgICAgdGV4dCA9IHRleHQuc3BsaXQoYHske25hbWV9fWApLmpvaW4oU3RyaW5nKHJlbmRlcmVkKSk7XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgcmV0dXJuIHRleHQ7XG4gICAgfSxcbiAgICBbbGFuZ3VhZ2VdLFxuICApO1xuXG4gIGNvbnN0IHZhbHVlID0gdXNlTWVtbzxJMThuU3RhdGU+KFxuICAgICgpID0+ICh7XG4gICAgICBsYW5ndWFnZSxcbiAgICAgIHNldExhbmd1YWdlLFxuICAgICAgdCxcbiAgICAgIG51bTogKHYpID0+IGZvcm1hdE51bWJlcih2LCBsYW5ndWFnZSksXG4gICAgICBtb25leTogKHYpID0+IGBcXHUwOUYzJHtmb3JtYXROdW1iZXIodiwgbGFuZ3VhZ2UpfWAsXG4gICAgfSksXG4gICAgW2xhbmd1YWdlLCBzZXRMYW5ndWFnZSwgdF0sXG4gICk7XG5cbiAgcmV0dXJuIDxDdHguUHJvdmlkZXIgdmFsdWU9e3ZhbHVlfT57Y2hpbGRyZW59PC9DdHguUHJvdmlkZXI+O1xufVxuXG5leHBvcnQgZnVuY3Rpb24gdXNlSTE4bigpOiBJMThuU3RhdGUge1xuICBjb25zdCBjdHggPSB1c2VDb250ZXh0KEN0eCk7XG4gIGlmICghY3R4KSB0aHJvdyBuZXcgRXJyb3IoXCJ1c2VJMThuIG11c3QgYmUgdXNlZCBpbnNpZGUgSTE4blByb3ZpZGVyXCIpO1xuICByZXR1cm4gY3R4O1xufVxuIl0sImZpbGUiOiJEOi9JMkkgUHJvamVjdCAtIEhhYml0by9BcHAgRm9sZGVyL2hhYml0by9zcmMvaTE4bi9pbmRleC50c3gifQ==