import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Home.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=9ceb86a3"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$(), _s3 = $RefreshSig$(), _s4 = $RefreshSig$(), _s5 = $RefreshSig$(), _s6 = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9ceb86a3"; const useMemo = __vite__cjsImport3_react["useMemo"]; const useState = __vite__cjsImport3_react["useState"];
import { Link, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=9ceb86a3";
import { ArrowRight, Search, MapPin } from "/node_modules/.vite/deps/lucide-react.js?v=9ceb86a3";
import { useHabito } from "/src/hooks/useHabito.tsx";
import { Button } from "/src/components/ui/Button.tsx";
import { SpaceCard } from "/src/components/space/SpaceCard.tsx";
import { CATEGORY_STYLE } from "/src/data/catalog.ts";
import { AreaPicker } from "/src/components/ui/AreaPicker.tsx";
import { SPACE_TYPE_LABEL } from "/src/types/space.ts";
import { moneyCompact, daysSince } from "/src/lib/format.ts";
import { cn } from "/src/lib/cn.ts";
import { displayImage } from "/src/lib/localize.ts";
import { useI18n } from "/src/i18n/index.tsx";
import { SpaceCardSkeleton } from "/src/components/ui/Skeleton.tsx";
const CATEGORIES = Object.keys(CATEGORY_STYLE);
export default function Home() {
  _s();
  const { t } = useI18n();
  const { listings, ready, isSaved, toggleSaved, isComparing, toggleCompare, requirements, setRequirements } = useHabito();
  const fresh = useMemo(
    () => [...listings].filter((l) => l.space.availability.status !== "occupied").sort((a, b) => daysSince(a.space.lastUpdated) - daysSince(b.space.lastUpdated)),
    [listings]
  );
  const budget = useMemo(
    () => [...listings].filter((l) => l.space.transaction === "rent" && l.space.category === "living").sort((a, b) => a.space.cost.price - b.space.cost.price),
    [listings]
  );
  const commercial = useMemo(
    () => listings.filter((l) => l.space.category === "business" || l.space.category === "storage"),
    [listings]
  );
  const rural = useMemo(() => listings.filter((l) => l.property.geography === "rural"), [listings]);
  const rail = {
    ready,
    isSaved,
    isComparing,
    onToggleSave: (id) => void toggleSaved(id),
    onToggleCompare: (id) => toggleCompare(id)
  };
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(Hero, { requirements, setRequirements }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
      lineNumber: 76,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(CategoryStrip, { listings }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
      lineNumber: 78,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      Rail,
      {
        title: t("home.newThisWeek"),
        lead: t("home.newThisWeekBody"),
        to: "/search",
        items: fresh.slice(0, 8),
        ...rail
      },
      void 0,
      false,
      {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
        lineNumber: 80,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(BeyondTheCity, { listings: rural }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
      lineNumber: 88,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      Rail,
      {
        title: t("home.roomToWork"),
        lead: t("home.roomToWorkBody"),
        to: "/search?category=business",
        items: commercial.slice(0, 8),
        ...rail
      },
      void 0,
      false,
      {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
        lineNumber: 90,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Rail,
      {
        title: t("home.budgetTitle"),
        lead: t("home.budgetBody"),
        to: "/search?category=living",
        items: budget.slice(0, 8),
        ...rail
      },
      void 0,
      false,
      {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
        lineNumber: 98,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(HowItWorks, {}, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
      lineNumber: 106,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
    lineNumber: 75,
    columnNumber: 5
  }, this);
}
_s(Home, "mf4Cp1xS7tNOrK2ApY8mNQ7GRyo=", false, function() {
  return [useI18n, useHabito];
});
_c = Home;
function Hero({
  requirements,
  setRequirements
}) {
  _s2();
  const navigate = useNavigate();
  const { t } = useI18n();
  const [transaction, setTransaction] = useState(requirements.transaction);
  const [category, setCategory] = useState(requirements.category);
  const [area, setArea] = useState(requirements.area);
  const [budgetMax, setBudgetMax] = useState(String(requirements.budgetMax));
  const submit = () => {
    setRequirements({
      ...requirements,
      transaction,
      category,
      spaceType: "any",
      area,
      budgetMax: Number(budgetMax) || requirements.budgetMax
    });
    navigate("/search");
  };
  return /* @__PURE__ */ jsxDEV("section", { className: "relative overflow-hidden border-b border-hairline", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "atmosphere absolute inset-0", "aria-hidden": true }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
      lineNumber: 141,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "container-page relative grid gap-12 py-14 md:py-20 lg:grid-cols-[1.05fr_26rem] lg:items-center lg:gap-16", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "rise", children: [
        /* @__PURE__ */ jsxDEV("p", { className: "inline-flex items-center gap-2 rounded-full bg-surface/80 px-3 py-1.5 text-xs font-semibold text-ink-soft ring-1 ring-hairline backdrop-blur", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "size-1.5 rounded-full bg-coral", "aria-hidden": true }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
            lineNumber: 146,
            columnNumber: 13
          }, this),
          t("home.heroEyebrow")
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
          lineNumber: 145,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("h1", { className: "mt-5 font-display text-[2.75rem] font-extrabold leading-[0.98] text-ink sm:text-6xl lg:text-[4.25rem]", children: [
          t("home.heroLine1"),
          /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
            lineNumber: 152,
            columnNumber: 13
          }, this),
          t("home.heroLine2")
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
          lineNumber: 150,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "mt-6 max-w-md text-base leading-relaxed text-ink-soft sm:text-lg", children: t("home.heroBody") }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
          lineNumber: 156,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-8 flex flex-wrap gap-3", children: [
          /* @__PURE__ */ jsxDEV(Link, { to: "/find", children: /* @__PURE__ */ jsxDEV(Button, { size: "lg", children: [
            t("home.findSpace"),
            /* @__PURE__ */ jsxDEV(ArrowRight, { size: 17, "aria-hidden": true }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
              lineNumber: 164,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
            lineNumber: 162,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
            lineNumber: 161,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(Link, { to: "/list", children: /* @__PURE__ */ jsxDEV(Button, { size: "lg", variant: "secondary", children: t("home.listSpace") }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
            lineNumber: 168,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
            lineNumber: 167,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
          lineNumber: 160,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
        lineNumber: 144,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "rise rounded-card bg-surface/95 p-5 shadow-[0_30px_70px_-40px_rgb(16_24_40/0.55)] ring-1 ring-hairline backdrop-blur sm:p-6", children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "font-display text-lg font-bold text-ink", children: t("home.lookingFor") }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
          lineNumber: 177,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-4 inline-flex rounded-full bg-ivory-deep p-0.5", children: ["rent", "sale"].map(
          (t2) => /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              "aria-pressed": transaction === t2,
              onClick: () => setTransaction(t2),
              className: cn(
                "rounded-full px-4 py-1.5 text-sm font-bold transition-colors",
                transaction === t2 ? "bg-ink text-ivory" : "text-muted hover:text-ink"
              ),
              children: t2 === "rent" ? t("transaction.rent") : t("transaction.buy")
            },
            t2,
            false,
            {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
              lineNumber: 181,
              columnNumber: 13
            },
            this
          )
        ) }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
          lineNumber: 179,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("ul", { className: "mt-4 flex flex-wrap gap-1.5", children: [
          /* @__PURE__ */ jsxDEV("li", { children: /* @__PURE__ */ jsxDEV(CategoryChip, { active: category === "any", onClick: () => setCategory("any"), children: t("home.anything") }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
            lineNumber: 198,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
            lineNumber: 197,
            columnNumber: 13
          }, this),
          CATEGORIES.map((c) => {
            const Icon = CATEGORY_STYLE[c].icon;
            return /* @__PURE__ */ jsxDEV("li", { children: /* @__PURE__ */ jsxDEV(CategoryChip, { active: category === c, onClick: () => setCategory(c), children: [
              /* @__PURE__ */ jsxDEV(Icon, { size: 13, "aria-hidden": true }, void 0, false, {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
                lineNumber: 207,
                columnNumber: 21
              }, this),
              t(`category.${c}`)
            ] }, void 0, true, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
              lineNumber: 206,
              columnNumber: 19
            }, this) }, c, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
              lineNumber: 205,
              columnNumber: 17
            }, this);
          })
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
          lineNumber: 196,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-4 grid gap-3 sm:grid-cols-2", children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "mb-1.5 block text-sm font-medium text-ink-soft", children: t("home.where") }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
              lineNumber: 217,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(AreaPicker, { value: area, onChange: setArea }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
              lineNumber: 218,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
            lineNumber: 216,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("label", { className: "block", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "mb-1.5 block text-sm font-medium text-ink-soft", children: t("home.upTo") }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
              lineNumber: 222,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "relative", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-muted", children: "৳" }, void 0, false, {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
                lineNumber: 224,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "number",
                  inputMode: "numeric",
                  step: 500,
                  value: budgetMax,
                  onChange: (e) => setBudgetMax(e.target.value),
                  className: "h-11 w-full rounded-xl bg-ivory pl-7 pr-3 text-[0.9375rem] tnum text-ink ring-1 ring-hairline-strong focus:outline-none focus:ring-2 focus:ring-aqua-600"
                },
                void 0,
                false,
                {
                  fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
                  lineNumber: 225,
                  columnNumber: 17
                },
                this
              )
            ] }, void 0, true, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
              lineNumber: 223,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
            lineNumber: 221,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
          lineNumber: 215,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Button, { size: "lg", fullWidth: true, className: "mt-4", onClick: submit, children: [
          /* @__PURE__ */ jsxDEV(Search, { size: 17, "aria-hidden": true }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
            lineNumber: 238,
            columnNumber: 13
          }, this),
          t("home.exploreSpaces")
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
          lineNumber: 237,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "mt-3 text-center text-xs text-muted", children: [
          t("home.wantScored"),
          " ",
          /* @__PURE__ */ jsxDEV(Link, { to: "/find", className: "font-semibold text-aqua-700 hover:underline", children: t("home.tellUs") }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
            lineNumber: 244,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
          lineNumber: 242,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
        lineNumber: 176,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
      lineNumber: 143,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
    lineNumber: 140,
    columnNumber: 5
  }, this);
}
_s2(Hero, "hriI+QRlXBF45l5aqPW/5HOS+O4=", false, function() {
  return [useNavigate, useI18n];
});
_c2 = Hero;
function CategoryChip({
  active,
  onClick,
  children
}) {
  return /* @__PURE__ */ jsxDEV(
    "button",
    {
      type: "button",
      "aria-pressed": active,
      onClick,
      className: cn(
        "inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 text-sm font-semibold transition-all duration-150",
        active ? "bg-ink text-ivory" : "bg-ivory-deep text-ink-soft hover:bg-hairline"
      ),
      children
    },
    void 0,
    false,
    {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
      lineNumber: 264,
      columnNumber: 5
    },
    this
  );
}
_c3 = CategoryChip;
function CategoryStrip({ listings }) {
  _s3();
  const { t } = useI18n();
  return /* @__PURE__ */ jsxDEV("section", { "aria-labelledby": "cats", className: "container-page py-14 md:py-16", children: [
    /* @__PURE__ */ jsxDEV("h2", { id: "cats", className: "font-display text-2xl font-bold text-ink sm:text-3xl", children: t("home.everyKind") }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
      lineNumber: 284,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("p", { className: "mt-2 max-w-lg text-sm text-muted", children: t("home.everyKindBody") }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
      lineNumber: 287,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("ul", { className: "mt-7 grid gap-3 sm:grid-cols-2 lg:grid-cols-5", children: CATEGORIES.map((c) => {
      const style = CATEGORY_STYLE[c];
      const inCategory = listings.filter((l) => l.space.category === c);
      const rentals = inCategory.filter((l) => l.space.transaction === "rent");
      const from = rentals.length ? Math.min(...rentals.map((l) => l.space.cost.price)) : null;
      return /* @__PURE__ */ jsxDEV("li", { children: /* @__PURE__ */ jsxDEV(
        Link,
        {
          to: `/search?category=${c}`,
          className: "flex h-full flex-col gap-3 rounded-card bg-surface p-5 ring-1 ring-hairline transition-all duration-200 hover:-translate-y-0.5 hover:ring-ink",
          children: [
            /* @__PURE__ */ jsxDEV("span", { className: cn("flex size-10 items-center justify-center rounded-xl", style.chip), children: /* @__PURE__ */ jsxDEV(style.icon, { size: 19, "aria-hidden": true }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
              lineNumber: 305,
              columnNumber: 19
            }, this) }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
              lineNumber: 304,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "font-display font-bold text-ink", children: t(`category.${c}`) }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
              lineNumber: 307,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "text-xs leading-snug text-muted", children: t(`category.${c}.blurb`) }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
              lineNumber: 308,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "mt-auto pt-2 text-sm font-semibold tnum text-ink", children: [
              t("home.spacesCount", { count: inCategory.length }),
              from !== null && /* @__PURE__ */ jsxDEV("span", { className: "font-medium text-muted", children: [
                " · ",
                t("home.from", { price: moneyCompact(from) })
              ] }, void 0, true, {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
                lineNumber: 312,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
              lineNumber: 309,
              columnNumber: 17
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
          lineNumber: 300,
          columnNumber: 15
        },
        this
      ) }, c, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
        lineNumber: 299,
        columnNumber: 13
      }, this);
    }) }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
      lineNumber: 291,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
    lineNumber: 283,
    columnNumber: 5
  }, this);
}
_s3(CategoryStrip, "82N5KF9nLzZ6+2WH7KIjzIXRkLw=", false, function() {
  return [useI18n];
});
_c4 = CategoryStrip;
function Rail({
  title,
  lead,
  to,
  items,
  ready,
  isSaved,
  isComparing,
  onToggleSave,
  onToggleCompare
}) {
  _s4();
  const { t } = useI18n();
  if (ready && items.length === 0) return null;
  return /* @__PURE__ */ jsxDEV("section", { className: "py-6 md:py-8", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "container-page flex flex-wrap items-end justify-between gap-3", children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "font-display text-2xl font-bold text-ink sm:text-3xl", children: title }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
          lineNumber: 357,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "mt-1.5 text-sm text-muted", children: lead }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
          lineNumber: 358,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
        lineNumber: 356,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Link, { to, className: "inline-flex items-center gap-1.5 text-sm font-semibold text-aqua-700 hover:text-ink", children: [
        t("action.seeAll"),
        /* @__PURE__ */ jsxDEV(ArrowRight, { size: 15, "aria-hidden": true }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
          lineNumber: 362,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
        lineNumber: 360,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
      lineNumber: 355,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "mt-6 flex gap-4 overflow-x-auto px-5 pb-2 hide-scrollbar md:px-8", children: !ready ? Array.from(
      { length: 4 },
      (_, i) => /* @__PURE__ */ jsxDEV("div", { className: "w-68 shrink-0 sm:w-76", children: /* @__PURE__ */ jsxDEV(SpaceCardSkeleton, {}, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
        lineNumber: 370,
        columnNumber: 17
      }, this) }, i, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
        lineNumber: 369,
        columnNumber: 9
      }, this)
    ) : items.map(
      (l) => /* @__PURE__ */ jsxDEV("div", { className: "w-68 shrink-0 sm:w-76", children: /* @__PURE__ */ jsxDEV(
        SpaceCard,
        {
          listing: l,
          saved: isSaved(l.space.id),
          comparing: isComparing(l.space.id),
          onToggleSave,
          onToggleCompare
        },
        void 0,
        false,
        {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
          lineNumber: 375,
          columnNumber: 17
        },
        this
      ) }, l.space.id, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
        lineNumber: 374,
        columnNumber: 9
      }, this)
    ) }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
      lineNumber: 366,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
    lineNumber: 354,
    columnNumber: 5
  }, this);
}
_s4(Rail, "82N5KF9nLzZ6+2WH7KIjzIXRkLw=", false, function() {
  return [useI18n];
});
_c5 = Rail;
function BeyondTheCity({ listings }) {
  _s5();
  const { t } = useI18n();
  if (listings.length === 0) return null;
  const featured = listings.slice(0, 3);
  return /* @__PURE__ */ jsxDEV("section", { "aria-labelledby": "rural", className: "my-10 md:my-14", children: /* @__PURE__ */ jsxDEV("div", { className: "container-page", children: /* @__PURE__ */ jsxDEV("div", { className: "overflow-hidden rounded-card bg-ink text-ivory", children: /* @__PURE__ */ jsxDEV("div", { className: "grid gap-8 p-7 md:grid-cols-[1fr_1.15fr] md:items-center md:p-10", children: [
    /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("p", { className: "inline-flex items-center gap-2 rounded-full bg-white/10 px-3 py-1 text-xs font-semibold", children: [
        /* @__PURE__ */ jsxDEV(MapPin, { size: 12, "aria-hidden": true }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
          lineNumber: 403,
          columnNumber: 17
        }, this),
        t("home.outsideCity")
      ] }, void 0, true, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
        lineNumber: 402,
        columnNumber: 15
      }, this),
      /* @__PURE__ */ jsxDEV("h2", { id: "rural", className: "mt-4 font-display text-3xl font-bold leading-tight sm:text-4xl", children: t("home.ruralTitle") }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
        lineNumber: 406,
        columnNumber: 15
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "mt-4 max-w-sm leading-relaxed text-ivory/70", children: t("home.ruralBody") }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
        lineNumber: 409,
        columnNumber: 15
      }, this),
      /* @__PURE__ */ jsxDEV(Link, { to: "/search?geography=rural", className: "mt-6 inline-block", children: /* @__PURE__ */ jsxDEV(Button, { size: "lg", className: "bg-aqua-400 text-ink hover:bg-aqua-200", children: [
        t("home.ruralCta"),
        /* @__PURE__ */ jsxDEV(ArrowRight, { size: 16, "aria-hidden": true }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
          lineNumber: 415,
          columnNumber: 19
        }, this)
      ] }, void 0, true, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
        lineNumber: 413,
        columnNumber: 17
      }, this) }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
        lineNumber: 412,
        columnNumber: 15
      }, this)
    ] }, void 0, true, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
      lineNumber: 401,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("ul", { className: "grid gap-3 sm:grid-cols-3", children: featured.map(
      (l) => /* @__PURE__ */ jsxDEV("li", { children: /* @__PURE__ */ jsxDEV(
        Link,
        {
          to: `/space/${l.space.id}`,
          className: "group block overflow-hidden rounded-2xl bg-white/5 ring-1 ring-white/10 transition-colors hover:bg-white/10",
          children: [
            /* @__PURE__ */ jsxDEV("div", { className: "aspect-4/3 overflow-hidden", children: /* @__PURE__ */ jsxDEV(
              "img",
              {
                src: displayImage(l.space.images[0]),
                alt: l.space.images[0].alt,
                loading: "lazy",
                className: "size-full object-cover transition-transform duration-500 group-hover:scale-105"
              },
              void 0,
              false,
              {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
                lineNumber: 428,
                columnNumber: 23
              },
              this
            ) }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
              lineNumber: 427,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "p-3", children: [
              /* @__PURE__ */ jsxDEV("p", { className: "truncate text-sm font-semibold", children: SPACE_TYPE_LABEL[l.space.spaceType] }, void 0, false, {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
                lineNumber: 436,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "truncate text-xs text-ivory/60", children: l.property.area }, void 0, false, {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
                lineNumber: 437,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm font-bold tnum", children: [
                moneyCompact(l.space.cost.price),
                l.space.transaction === "rent" && /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-medium text-ivory/60", children: "/mo" }, void 0, false, {
                  fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
                  lineNumber: 441,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
                lineNumber: 438,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
              lineNumber: 435,
              columnNumber: 21
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
          lineNumber: 423,
          columnNumber: 19
        },
        this
      ) }, l.space.id, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
        lineNumber: 422,
        columnNumber: 15
      }, this)
    ) }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
      lineNumber: 420,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
    lineNumber: 400,
    columnNumber: 11
  }, this) }, void 0, false, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
    lineNumber: 399,
    columnNumber: 9
  }, this) }, void 0, false, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
    lineNumber: 398,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
    lineNumber: 397,
    columnNumber: 5
  }, this);
}
_s5(BeyondTheCity, "82N5KF9nLzZ6+2WH7KIjzIXRkLw=", false, function() {
  return [useI18n];
});
_c6 = BeyondTheCity;
const SEEKER_STEPS = ["steps.seeker1", "steps.seeker2", "steps.seeker3", "steps.seeker4"];
const OWNER_STEPS = ["steps.owner1", "steps.owner2", "steps.owner3", "steps.owner4"];
function HowItWorks() {
  _s6();
  const { t } = useI18n();
  return /* @__PURE__ */ jsxDEV("section", { "aria-labelledby": "how", className: "border-t border-hairline bg-ivory-deep", children: /* @__PURE__ */ jsxDEV("div", { className: "container-page py-14 md:py-20", children: [
    /* @__PURE__ */ jsxDEV("h2", { id: "how", className: "font-display text-2xl font-bold text-ink sm:text-3xl", children: t("home.twoSides") }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
      lineNumber: 466,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "mt-8 grid gap-6 lg:grid-cols-2", children: [
      { heading: t("home.ifLooking"), steps: SEEKER_STEPS, accent: "bg-aqua-400" },
      { heading: t("home.ifOwn"), steps: OWNER_STEPS, accent: "bg-coral" }
    ].map(
      (col) => /* @__PURE__ */ jsxDEV("div", { className: "rounded-card bg-surface p-6 ring-1 ring-hairline", children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "flex items-center gap-2 font-display text-lg font-bold text-ink", children: [
          /* @__PURE__ */ jsxDEV("span", { className: cn("size-2 rounded-full", col.accent), "aria-hidden": true }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
            lineNumber: 477,
            columnNumber: 17
          }, this),
          col.heading
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
          lineNumber: 476,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("ol", { className: "mt-5 space-y-4", children: col.steps.map(
          (stepKey, i) => /* @__PURE__ */ jsxDEV("li", { className: "flex gap-3.5", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "mt-0.5 flex size-6 shrink-0 items-center justify-center rounded-full bg-ivory-deep text-xs font-bold tnum text-ink", children: i + 1 }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
              lineNumber: 483,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("p", { className: "font-semibold text-ink", children: t(`${stepKey}.title`) }, void 0, false, {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
                lineNumber: 487,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "mt-0.5 text-sm leading-relaxed text-muted", children: t(`${stepKey}.body`) }, void 0, false, {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
                lineNumber: 488,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
              lineNumber: 486,
              columnNumber: 21
            }, this)
          ] }, stepKey, true, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
            lineNumber: 482,
            columnNumber: 15
          }, this)
        ) }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
          lineNumber: 480,
          columnNumber: 15
        }, this)
      ] }, col.heading, true, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
        lineNumber: 475,
        columnNumber: 11
      }, this)
    ) }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
      lineNumber: 470,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("p", { className: "mt-6 rounded-card bg-surface/70 p-5 text-sm leading-relaxed text-ink-soft ring-1 ring-hairline-strong", children: [
      /* @__PURE__ */ jsxDEV("strong", { className: "font-semibold text-ink", children: "About verification." }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
        lineNumber: 500,
        columnNumber: 11
      }, this),
      " Habito does not yet perform real identity or ownership checks. Trust states in this build demonstrate the intended workflow over synthetic data and are labelled as demo throughout. Match scores are arithmetic over your stated requirements — no machine learning is involved."
    ] }, void 0, true, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
      lineNumber: 499,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
    lineNumber: 465,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx",
    lineNumber: 464,
    columnNumber: 5
  }, this);
}
_s6(HowItWorks, "82N5KF9nLzZ6+2WH7KIjzIXRkLw=", false, function() {
  return [useI18n];
});
_c7 = HowItWorks;
var _c, _c2, _c3, _c4, _c5, _c6, _c7;
$RefreshReg$(_c, "Home");
$RefreshReg$(_c2, "Hero");
$RefreshReg$(_c3, "CategoryChip");
$RefreshReg$(_c4, "CategoryStrip");
$RefreshReg$(_c5, "Rail");
$RefreshReg$(_c6, "BeyondTheCity");
$RefreshReg$(_c7, "HowItWorks");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/I2I Project - Habito/App Folder/habito/src/pages/Home.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdURJLG1CQUNFLGNBREY7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBdkRKLFNBQVNBLFNBQVNDLGdCQUFnQjtBQUNsQyxTQUFTQyxNQUFNQyxtQkFBbUI7QUFDbEMsU0FBU0MsWUFBWUMsUUFBUUMsY0FBYztBQUMzQyxTQUFTQyxpQkFBaUI7QUFDMUIsU0FBU0MsY0FBYztBQUN2QixTQUFTQyxpQkFBaUI7QUFDMUIsU0FBU0Msc0JBQXNCO0FBQy9CLFNBQVNDLGtCQUFrQjtBQUMzQixTQUFTQyx3QkFBd0I7QUFFakMsU0FBU0MsY0FBY0MsaUJBQWlCO0FBQ3hDLFNBQVNDLFVBQVU7QUFDbkIsU0FBU0Msb0JBQW9CO0FBQzdCLFNBQVNDLGVBQWU7QUFDeEIsU0FBU0MseUJBQXlCO0FBRWxDLE1BQU1DLGFBQWFDLE9BQU9DLEtBQUtYLGNBQWM7QUFFN0Msd0JBQXdCWSxPQUFPO0FBQUFDLEtBQUE7QUFDN0IsUUFBTSxFQUFFQyxFQUFFLElBQUlQLFFBQVE7QUFDdEIsUUFBTSxFQUFFUSxVQUFVQyxPQUFPQyxTQUFTQyxhQUFhQyxhQUFhQyxlQUFlQyxjQUFjQyxnQkFBZ0IsSUFDdkd6QixVQUFVO0FBRVosUUFBTTBCLFFBQVFqQztBQUFBQSxJQUNaLE1BQ0UsQ0FBQyxHQUFHeUIsUUFBUSxFQUNUUyxPQUFPLENBQUNDLE1BQU1BLEVBQUVDLE1BQU1DLGFBQWFDLFdBQVcsVUFBVSxFQUN4REMsS0FBSyxDQUFDQyxHQUFHQyxNQUFNM0IsVUFBVTBCLEVBQUVKLE1BQU1NLFdBQVcsSUFBSTVCLFVBQVUyQixFQUFFTCxNQUFNTSxXQUFXLENBQUM7QUFBQSxJQUNuRixDQUFDakIsUUFBUTtBQUFBLEVBQ1g7QUFFQSxRQUFNa0IsU0FBUzNDO0FBQUFBLElBQ2IsTUFDRSxDQUFDLEdBQUd5QixRQUFRLEVBQ1RTLE9BQU8sQ0FBQ0MsTUFBTUEsRUFBRUMsTUFBTVEsZ0JBQWdCLFVBQVVULEVBQUVDLE1BQU1TLGFBQWEsUUFBUSxFQUM3RU4sS0FBSyxDQUFDQyxHQUFHQyxNQUFNRCxFQUFFSixNQUFNVSxLQUFLQyxRQUFRTixFQUFFTCxNQUFNVSxLQUFLQyxLQUFLO0FBQUEsSUFDM0QsQ0FBQ3RCLFFBQVE7QUFBQSxFQUNYO0FBRUEsUUFBTXVCLGFBQWFoRDtBQUFBQSxJQUNqQixNQUFNeUIsU0FBU1MsT0FBTyxDQUFDQyxNQUFNQSxFQUFFQyxNQUFNUyxhQUFhLGNBQWNWLEVBQUVDLE1BQU1TLGFBQWEsU0FBUztBQUFBLElBQzlGLENBQUNwQixRQUFRO0FBQUEsRUFDWDtBQUVBLFFBQU13QixRQUFRakQsUUFBUSxNQUFNeUIsU0FBU1MsT0FBTyxDQUFDQyxNQUFNQSxFQUFFZSxTQUFTQyxjQUFjLE9BQU8sR0FBRyxDQUFDMUIsUUFBUSxDQUFDO0FBRWhHLFFBQU0yQixPQUFPO0FBQUEsSUFDWDFCO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FFO0FBQUFBLElBQ0F3QixjQUFjQSxDQUFDQyxPQUFlLEtBQUsxQixZQUFZMEIsRUFBRTtBQUFBLElBQ2pEQyxpQkFBaUJBLENBQUNELE9BQWV4QixjQUFjd0IsRUFBRTtBQUFBLEVBQ25EO0FBRUEsU0FDRSxtQ0FDRTtBQUFBLDJCQUFDLFFBQUssY0FBNEIsbUJBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBbUU7QUFBQSxJQUVuRSx1QkFBQyxpQkFBYyxZQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBa0M7QUFBQSxJQUVsQztBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsT0FBTzlCLEVBQUUsa0JBQWtCO0FBQUEsUUFDM0IsTUFBTUEsRUFBRSxzQkFBc0I7QUFBQSxRQUM5QixJQUFHO0FBQUEsUUFDSCxPQUFPUyxNQUFNdUIsTUFBTSxHQUFHLENBQUM7QUFBQSxRQUN2QixHQUFJSjtBQUFBQTtBQUFBQSxNQUxOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUtXO0FBQUEsSUFHWCx1QkFBQyxpQkFBYyxVQUFVSCxTQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQStCO0FBQUEsSUFFL0I7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLE9BQU96QixFQUFFLGlCQUFpQjtBQUFBLFFBQzFCLE1BQU1BLEVBQUUscUJBQXFCO0FBQUEsUUFDN0IsSUFBRztBQUFBLFFBQ0gsT0FBT3dCLFdBQVdRLE1BQU0sR0FBRyxDQUFDO0FBQUEsUUFDNUIsR0FBSUo7QUFBQUE7QUFBQUEsTUFMTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFLVztBQUFBLElBR1g7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLE9BQU81QixFQUFFLGtCQUFrQjtBQUFBLFFBQzNCLE1BQU1BLEVBQUUsaUJBQWlCO0FBQUEsUUFDekIsSUFBRztBQUFBLFFBQ0gsT0FBT21CLE9BQU9hLE1BQU0sR0FBRyxDQUFDO0FBQUEsUUFDeEIsR0FBSUo7QUFBQUE7QUFBQUEsTUFMTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFLVztBQUFBLElBR1gsdUJBQUMsZ0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFXO0FBQUEsT0EvQmI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWdDQTtBQUVKO0FBRUE3QixHQXpFd0JELE1BQUk7QUFBQSxVQUNaTCxTQUVaVixTQUFTO0FBQUE7QUFBQSxLQUhXZTtBQTJFeEIsU0FBU21DLEtBQUs7QUFBQSxFQUNaMUI7QUFBQUEsRUFDQUM7QUFJRixHQUFHO0FBQUEwQixNQUFBO0FBQ0QsUUFBTUMsV0FBV3hELFlBQVk7QUFDN0IsUUFBTSxFQUFFcUIsRUFBRSxJQUFJUCxRQUFRO0FBQ3RCLFFBQU0sQ0FBQzJCLGFBQWFnQixjQUFjLElBQUkzRCxTQUEwQjhCLGFBQWFhLFdBQVc7QUFDeEYsUUFBTSxDQUFDQyxVQUFVZ0IsV0FBVyxJQUFJNUQsU0FBZ0M4QixhQUFhYyxRQUFRO0FBQ3JGLFFBQU0sQ0FBQ2lCLE1BQU1DLE9BQU8sSUFBSTlELFNBQVM4QixhQUFhK0IsSUFBSTtBQUNsRCxRQUFNLENBQUNFLFdBQVdDLFlBQVksSUFBSWhFLFNBQVNpRSxPQUFPbkMsYUFBYWlDLFNBQVMsQ0FBQztBQUV6RSxRQUFNRyxTQUFTQSxNQUFNO0FBQ25CbkMsb0JBQWdCO0FBQUEsTUFDZCxHQUFHRDtBQUFBQSxNQUNIYTtBQUFBQSxNQUNBQztBQUFBQSxNQUNBdUIsV0FBVztBQUFBLE1BQ1hOO0FBQUFBLE1BQ0FFLFdBQVdLLE9BQU9MLFNBQVMsS0FBS2pDLGFBQWFpQztBQUFBQSxJQUMvQyxDQUFDO0FBQ0RMLGFBQVMsU0FBUztBQUFBLEVBQ3BCO0FBRUEsU0FDRSx1QkFBQyxhQUFRLFdBQVUscURBQ2pCO0FBQUEsMkJBQUMsU0FBSSxXQUFVLCtCQUE4QixlQUFXLFFBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBd0Q7QUFBQSxJQUV4RCx1QkFBQyxTQUFJLFdBQVUsNEdBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLCtCQUFDLE9BQUUsV0FBVSxnSkFDWDtBQUFBLGlDQUFDLFVBQUssV0FBVSxrQ0FBaUMsZUFBVyxRQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE0RDtBQUFBLFVBQzNEbkMsRUFBRSxrQkFBa0I7QUFBQSxhQUZ2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUVBLHVCQUFDLFFBQUcsV0FBVSx5R0FDWEE7QUFBQUEsWUFBRSxnQkFBZ0I7QUFBQSxVQUNuQix1QkFBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQUc7QUFBQSxVQUNGQSxFQUFFLGdCQUFnQjtBQUFBLGFBSHJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFJQTtBQUFBLFFBRUEsdUJBQUMsT0FBRSxXQUFVLG9FQUNWQSxZQUFFLGVBQWUsS0FEcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsNkJBQ2I7QUFBQSxpQ0FBQyxRQUFLLElBQUcsU0FDUCxpQ0FBQyxVQUFPLE1BQUssTUFDVkE7QUFBQUEsY0FBRSxnQkFBZ0I7QUFBQSxZQUNuQix1QkFBQyxjQUFXLE1BQU0sSUFBSSxlQUFXLFFBQWpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWlDO0FBQUEsZUFGbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQSxLQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBS0E7QUFBQSxVQUNBLHVCQUFDLFFBQUssSUFBRyxTQUNQLGlDQUFDLFVBQU8sTUFBSyxNQUFLLFNBQVEsYUFDdkJBLFlBQUUsZ0JBQWdCLEtBRHJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUlBO0FBQUEsYUFYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBWUE7QUFBQSxXQTVCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBNkJBO0FBQUEsTUFHQSx1QkFBQyxTQUFJLFdBQVUsK0hBQ2I7QUFBQSwrQkFBQyxRQUFHLFdBQVUsMkNBQTJDQSxZQUFFLGlCQUFpQixLQUE1RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQThFO0FBQUEsUUFFOUUsdUJBQUMsU0FBSSxXQUFVLHFEQUNYLFdBQUMsUUFBUSxNQUFNLEVBQXdCOEM7QUFBQUEsVUFBSSxDQUFDQyxPQUM1QztBQUFBLFlBQUM7QUFBQTtBQUFBLGNBRUMsTUFBSztBQUFBLGNBQ0wsZ0JBQWMzQixnQkFBZ0IyQjtBQUFBQSxjQUM5QixTQUFTLE1BQU1YLGVBQWVXLEVBQUU7QUFBQSxjQUNoQyxXQUFXeEQ7QUFBQUEsZ0JBQ1Q7QUFBQSxnQkFDQTZCLGdCQUFnQjJCLEtBQUssc0JBQXNCO0FBQUEsY0FDN0M7QUFBQSxjQUVDQSxpQkFBTyxTQUFTL0MsRUFBRSxrQkFBa0IsSUFBSUEsRUFBRSxpQkFBaUI7QUFBQTtBQUFBLFlBVHZEK0M7QUFBQUEsWUFEUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBV0E7QUFBQSxRQUNELEtBZEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWVBO0FBQUEsUUFFQSx1QkFBQyxRQUFHLFdBQVUsK0JBQ1o7QUFBQSxpQ0FBQyxRQUNDLGlDQUFDLGdCQUFhLFFBQVExQixhQUFhLE9BQU8sU0FBUyxNQUFNZ0IsWUFBWSxLQUFLLEdBQ3ZFckMsWUFBRSxlQUFlLEtBRHBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUlBO0FBQUEsVUFDQ0wsV0FBV21ELElBQUksQ0FBQ0UsTUFBTTtBQUNyQixrQkFBTUMsT0FBTy9ELGVBQWU4RCxDQUFDLEVBQUVFO0FBQy9CLG1CQUNFLHVCQUFDLFFBQ0MsaUNBQUMsZ0JBQWEsUUFBUTdCLGFBQWEyQixHQUFHLFNBQVMsTUFBTVgsWUFBWVcsQ0FBQyxHQUNoRTtBQUFBLHFDQUFDLFFBQUssTUFBTSxJQUFJLGVBQVcsUUFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBMkI7QUFBQSxjQUMxQmhELEVBQUUsWUFBWWdELENBQUMsRUFBVztBQUFBLGlCQUY3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBLEtBSk9BLEdBQVQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFLQTtBQUFBLFVBRUosQ0FBQztBQUFBLGFBaEJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFpQkE7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSxrQ0FDYjtBQUFBLGlDQUFDLFdBQU0sV0FBVSxTQUNmO0FBQUEsbUNBQUMsVUFBSyxXQUFVLGtEQUFrRGhELFlBQUUsWUFBWSxLQUFoRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFrRjtBQUFBLFlBQ2xGLHVCQUFDLGNBQVcsT0FBT3NDLE1BQU0sVUFBVUMsV0FBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMkM7QUFBQSxlQUY3QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFFQSx1QkFBQyxXQUFNLFdBQVUsU0FDZjtBQUFBLG1DQUFDLFVBQUssV0FBVSxrREFBa0R2QyxZQUFFLFdBQVcsS0FBL0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBaUY7QUFBQSxZQUNqRix1QkFBQyxTQUFJLFdBQVUsWUFDYjtBQUFBLHFDQUFDLFVBQUssV0FBVSwyRUFBMEUsaUJBQTFGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTJGO0FBQUEsY0FDM0Y7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLFdBQVU7QUFBQSxrQkFDVixNQUFNO0FBQUEsa0JBQ04sT0FBT3dDO0FBQUFBLGtCQUNQLFVBQVUsQ0FBQ1csTUFBTVYsYUFBYVUsRUFBRUMsT0FBT0MsS0FBSztBQUFBLGtCQUM1QyxXQUFVO0FBQUE7QUFBQSxnQkFOWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FNc0s7QUFBQSxpQkFSeEs7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFVQTtBQUFBLGVBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFhQTtBQUFBLGFBbkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFvQkE7QUFBQSxRQUVBLHVCQUFDLFVBQU8sTUFBSyxNQUFLLFdBQVMsTUFBQyxXQUFVLFFBQU8sU0FBU1YsUUFDcEQ7QUFBQSxpQ0FBQyxVQUFPLE1BQU0sSUFBSSxlQUFXLFFBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTZCO0FBQUEsVUFDNUIzQyxFQUFFLG9CQUFvQjtBQUFBLGFBRnpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBRUEsdUJBQUMsT0FBRSxXQUFVLHVDQUNWQTtBQUFBQSxZQUFFLGlCQUFpQjtBQUFBLFVBQUc7QUFBQSxVQUN2Qix1QkFBQyxRQUFLLElBQUcsU0FBUSxXQUFVLCtDQUN4QkEsWUFBRSxhQUFhLEtBRGxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFLQTtBQUFBLFdBdkVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF3RUE7QUFBQSxTQXpHRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBMEdBO0FBQUEsT0E3R0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQThHQTtBQUVKO0FBQUNrQyxJQTNJUUQsTUFBSTtBQUFBLFVBT010RCxhQUNIYyxPQUFPO0FBQUE7QUFBQSxNQVJkd0M7QUE2SVQsU0FBU3FCLGFBQWE7QUFBQSxFQUNwQkM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFLRixHQUFHO0FBQ0QsU0FDRTtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0MsTUFBSztBQUFBLE1BQ0wsZ0JBQWNGO0FBQUFBLE1BQ2Q7QUFBQSxNQUNBLFdBQVdoRTtBQUFBQSxRQUNUO0FBQUEsUUFDQWdFLFNBQVMsc0JBQXNCO0FBQUEsTUFDakM7QUFBQSxNQUVDRTtBQUFBQTtBQUFBQSxJQVRIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQVVBO0FBRUo7QUFFQUMsTUF4QlNKO0FBMEJULFNBQVNLLGNBQWMsRUFBRTFELFNBQXVDLEdBQUc7QUFBQTJELE1BQUE7QUFDakUsUUFBTSxFQUFFNUQsRUFBRSxJQUFJUCxRQUFRO0FBQ3RCLFNBQ0UsdUJBQUMsYUFBUSxtQkFBZ0IsUUFBTyxXQUFVLGlDQUN4QztBQUFBLDJCQUFDLFFBQUcsSUFBRyxRQUFPLFdBQVUsd0RBQ3JCTyxZQUFFLGdCQUFnQixLQURyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxJQUNBLHVCQUFDLE9BQUUsV0FBVSxvQ0FDVkEsWUFBRSxvQkFBb0IsS0FEekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsSUFFQSx1QkFBQyxRQUFHLFdBQVUsaURBQ1hMLHFCQUFXbUQsSUFBSSxDQUFDRSxNQUFNO0FBQ3JCLFlBQU1hLFFBQVEzRSxlQUFlOEQsQ0FBQztBQUM5QixZQUFNYyxhQUFhN0QsU0FBU1MsT0FBTyxDQUFDQyxNQUFNQSxFQUFFQyxNQUFNUyxhQUFhMkIsQ0FBQztBQUNoRSxZQUFNZSxVQUFVRCxXQUFXcEQsT0FBTyxDQUFDQyxNQUFNQSxFQUFFQyxNQUFNUSxnQkFBZ0IsTUFBTTtBQUN2RSxZQUFNNEMsT0FBT0QsUUFBUUUsU0FBU0MsS0FBS0MsSUFBSSxHQUFHSixRQUFRakIsSUFBSSxDQUFDbkMsTUFBTUEsRUFBRUMsTUFBTVUsS0FBS0MsS0FBSyxDQUFDLElBQUk7QUFFcEYsYUFDRSx1QkFBQyxRQUNDO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxJQUFJLG9CQUFvQnlCLENBQUM7QUFBQSxVQUN6QixXQUFVO0FBQUEsVUFFVjtBQUFBLG1DQUFDLFVBQUssV0FBV3pELEdBQUcsdURBQXVEc0UsTUFBTU8sSUFBSSxHQUNuRixpQ0FBQyxNQUFNLE1BQU4sRUFBVyxNQUFNLElBQUksZUFBVyxRQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFpQyxLQURuQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxVQUFLLFdBQVUsbUNBQW1DcEUsWUFBRSxZQUFZZ0QsQ0FBQyxFQUFXLEtBQTdFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQStFO0FBQUEsWUFDL0UsdUJBQUMsVUFBSyxXQUFVLG1DQUFtQ2hELFlBQUUsWUFBWWdELENBQUMsUUFBaUIsS0FBbkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBcUY7QUFBQSxZQUNyRix1QkFBQyxVQUFLLFdBQVUsb0RBQ2JoRDtBQUFBQSxnQkFBRSxvQkFBb0IsRUFBRXFFLE9BQU9QLFdBQVdHLE9BQU8sQ0FBQztBQUFBLGNBQ2xERCxTQUFTLFFBQ1IsdUJBQUMsVUFBSyxXQUFVLDBCQUNiO0FBQUE7QUFBQSxnQkFDQWhFLEVBQUUsYUFBYSxFQUFFdUIsT0FBT2xDLGFBQWEyRSxJQUFJLEVBQUUsQ0FBQztBQUFBLG1CQUYvQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUdBO0FBQUEsaUJBTko7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFRQTtBQUFBO0FBQUE7QUFBQSxRQWpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFrQkEsS0FuQk9oQixHQUFUO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFvQkE7QUFBQSxJQUVKLENBQUMsS0E5Qkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQStCQTtBQUFBLE9BdkNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F3Q0E7QUFFSjtBQUVBWSxJQS9DU0QsZUFBYTtBQUFBLFVBQ05sRSxPQUFPO0FBQUE7QUFBQSxNQURka0U7QUFpRFQsU0FBU1csS0FBSztBQUFBLEVBQ1pDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0F4RTtBQUFBQSxFQUNBQztBQUFBQSxFQUNBRTtBQUFBQSxFQUNBd0I7QUFBQUEsRUFDQUU7QUFXRixHQUFHO0FBQUE0QyxNQUFBO0FBQ0QsUUFBTSxFQUFFM0UsRUFBRSxJQUFJUCxRQUFRO0FBQ3RCLE1BQUlTLFNBQVN3RSxNQUFNVCxXQUFXLEVBQUcsUUFBTztBQUV4QyxTQUNFLHVCQUFDLGFBQVEsV0FBVSxnQkFDakI7QUFBQSwyQkFBQyxTQUFJLFdBQVUsaUVBQ2I7QUFBQSw2QkFBQyxTQUNDO0FBQUEsK0JBQUMsUUFBRyxXQUFVLHdEQUF3RE0sbUJBQXRFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNEU7QUFBQSxRQUM1RSx1QkFBQyxPQUFFLFdBQVUsNkJBQTZCQyxrQkFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUErQztBQUFBLFdBRmpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BQ0EsdUJBQUMsUUFBSyxJQUFRLFdBQVUsdUZBQ3JCeEU7QUFBQUEsVUFBRSxlQUFlO0FBQUEsUUFDbEIsdUJBQUMsY0FBVyxNQUFNLElBQUksZUFBVyxRQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWlDO0FBQUEsV0FGbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsU0FSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBU0E7QUFBQSxJQUVBLHVCQUFDLFNBQUksV0FBVSxvRUFDWixXQUFDRSxRQUNFMEUsTUFBTVo7QUFBQUEsTUFBSyxFQUFFQyxRQUFRLEVBQUU7QUFBQSxNQUFHLENBQUNZLEdBQUdDLE1BQzVCLHVCQUFDLFNBQVksV0FBVSx5QkFDckIsaUNBQUMsdUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFrQixLQURWQSxHQUFWO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLElBQ0QsSUFDREosTUFBTTVCO0FBQUFBLE1BQUksQ0FBQ25DLE1BQ1QsdUJBQUMsU0FBcUIsV0FBVSx5QkFDOUI7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLFNBQVNBO0FBQUFBLFVBQ1QsT0FBT1IsUUFBUVEsRUFBRUMsTUFBTWtCLEVBQUU7QUFBQSxVQUN6QixXQUFXekIsWUFBWU0sRUFBRUMsTUFBTWtCLEVBQUU7QUFBQSxVQUNqQztBQUFBLFVBQ0E7QUFBQTtBQUFBLFFBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BS21DLEtBTjNCbkIsRUFBRUMsTUFBTWtCLElBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFRQTtBQUFBLElBQ0QsS0FqQlA7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWtCQTtBQUFBLE9BOUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0ErQkE7QUFFSjtBQUVBNkMsSUE1RFNMLE1BQUk7QUFBQSxVQXFCRzdFLE9BQU87QUFBQTtBQUFBLE1BckJkNkU7QUE4RFQsU0FBU1MsY0FBYyxFQUFFOUUsU0FBdUMsR0FBRztBQUFBK0UsTUFBQTtBQUNqRSxRQUFNLEVBQUVoRixFQUFFLElBQUlQLFFBQVE7QUFDdEIsTUFBSVEsU0FBU2dFLFdBQVcsRUFBRyxRQUFPO0FBQ2xDLFFBQU1nQixXQUFXaEYsU0FBUytCLE1BQU0sR0FBRyxDQUFDO0FBRXBDLFNBQ0UsdUJBQUMsYUFBUSxtQkFBZ0IsU0FBUSxXQUFVLGtCQUN6QyxpQ0FBQyxTQUFJLFdBQVUsa0JBQ2IsaUNBQUMsU0FBSSxXQUFVLGtEQUNiLGlDQUFDLFNBQUksV0FBVSxvRUFDYjtBQUFBLDJCQUFDLFNBQ0M7QUFBQSw2QkFBQyxPQUFFLFdBQVUsMkZBQ1g7QUFBQSwrQkFBQyxVQUFPLE1BQU0sSUFBSSxlQUFXLFFBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNkI7QUFBQSxRQUM1QmhDLEVBQUUsa0JBQWtCO0FBQUEsV0FGdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFDQSx1QkFBQyxRQUFHLElBQUcsU0FBUSxXQUFVLGtFQUN0QkEsWUFBRSxpQkFBaUIsS0FEdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxPQUFFLFdBQVUsK0NBQ1ZBLFlBQUUsZ0JBQWdCLEtBRHJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsUUFBSyxJQUFHLDJCQUEwQixXQUFVLHFCQUMzQyxpQ0FBQyxVQUFPLE1BQUssTUFBSyxXQUFVLDBDQUN6QkE7QUFBQUEsVUFBRSxlQUFlO0FBQUEsUUFDbEIsdUJBQUMsY0FBVyxNQUFNLElBQUksZUFBVyxRQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWlDO0FBQUEsV0FGbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBLEtBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBO0FBQUEsU0FoQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWlCQTtBQUFBLElBRUEsdUJBQUMsUUFBRyxXQUFVLDZCQUNYaUYsbUJBQVNuQztBQUFBQSxNQUFJLENBQUNuQyxNQUNiLHVCQUFDLFFBQ0M7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLElBQUksVUFBVUEsRUFBRUMsTUFBTWtCLEVBQUU7QUFBQSxVQUN4QixXQUFVO0FBQUEsVUFFVjtBQUFBLG1DQUFDLFNBQUksV0FBVSw4QkFDYjtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLEtBQUt0QyxhQUFhbUIsRUFBRUMsTUFBTXNFLE9BQU8sQ0FBQyxDQUFDO0FBQUEsZ0JBQ25DLEtBQUt2RSxFQUFFQyxNQUFNc0UsT0FBTyxDQUFDLEVBQUVDO0FBQUFBLGdCQUN2QixTQUFRO0FBQUEsZ0JBQ1IsV0FBVTtBQUFBO0FBQUEsY0FKWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFJNEYsS0FMOUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFPQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLE9BQ2I7QUFBQSxxQ0FBQyxPQUFFLFdBQVUsa0NBQWtDL0YsMkJBQWlCdUIsRUFBRUMsTUFBTWdDLFNBQVMsS0FBakY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBbUY7QUFBQSxjQUNuRix1QkFBQyxPQUFFLFdBQVUsa0NBQWtDakMsWUFBRWUsU0FBU1ksUUFBMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBK0Q7QUFBQSxjQUMvRCx1QkFBQyxPQUFFLFdBQVUsK0JBQ1ZqRDtBQUFBQSw2QkFBYXNCLEVBQUVDLE1BQU1VLEtBQUtDLEtBQUs7QUFBQSxnQkFDL0JaLEVBQUVDLE1BQU1RLGdCQUFnQixVQUN2Qix1QkFBQyxVQUFLLFdBQVUscUNBQW9DLG1CQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF1RDtBQUFBLG1CQUgzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUtBO0FBQUEsaUJBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFTQTtBQUFBO0FBQUE7QUFBQSxRQXJCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFzQkEsS0F2Qk9ULEVBQUVDLE1BQU1rQixJQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBd0JBO0FBQUEsSUFDRCxLQTNCSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBNEJBO0FBQUEsT0FoREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWlEQSxLQWxERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBbURBLEtBcERGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FxREEsS0F0REY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXVEQTtBQUVKO0FBRUFrRCxJQWpFU0QsZUFBYTtBQUFBLFVBQ050RixPQUFPO0FBQUE7QUFBQSxNQURkc0Y7QUFtRVQsTUFBTUssZUFBZSxDQUFDLGlCQUFpQixpQkFBaUIsaUJBQWlCLGVBQWU7QUFDeEYsTUFBTUMsY0FBYyxDQUFDLGdCQUFnQixnQkFBZ0IsZ0JBQWdCLGNBQWM7QUFFbkYsU0FBU0MsYUFBYTtBQUFBQyxNQUFBO0FBQ3BCLFFBQU0sRUFBRXZGLEVBQUUsSUFBSVAsUUFBUTtBQUN0QixTQUNFLHVCQUFDLGFBQVEsbUJBQWdCLE9BQU0sV0FBVSwwQ0FDdkMsaUNBQUMsU0FBSSxXQUFVLGlDQUNiO0FBQUEsMkJBQUMsUUFBRyxJQUFHLE9BQU0sV0FBVSx3REFDcEJPLFlBQUUsZUFBZSxLQURwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxJQUVBLHVCQUFDLFNBQUksV0FBVSxrQ0FDWjtBQUFBLE1BQ0MsRUFBRXdGLFNBQVN4RixFQUFFLGdCQUFnQixHQUFHeUYsT0FBT0wsY0FBY00sUUFBUSxjQUFjO0FBQUEsTUFDM0UsRUFBRUYsU0FBU3hGLEVBQUUsWUFBWSxHQUFHeUYsT0FBT0osYUFBYUssUUFBUSxXQUFXO0FBQUEsSUFBQyxFQUNwRTVDO0FBQUFBLE1BQUksQ0FBQzZDLFFBQ0wsdUJBQUMsU0FBc0IsV0FBVSxvREFDL0I7QUFBQSwrQkFBQyxRQUFHLFdBQVUsbUVBQ1o7QUFBQSxpQ0FBQyxVQUFLLFdBQVdwRyxHQUFHLHVCQUF1Qm9HLElBQUlELE1BQU0sR0FBRyxlQUFXLFFBQW5FO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1FO0FBQUEsVUFDbEVDLElBQUlIO0FBQUFBLGFBRlA7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFDQSx1QkFBQyxRQUFHLFdBQVUsa0JBQ1hHLGNBQUlGLE1BQU0zQztBQUFBQSxVQUFJLENBQUM4QyxTQUFTZCxNQUN2Qix1QkFBQyxRQUFpQixXQUFVLGdCQUMxQjtBQUFBLG1DQUFDLFVBQUssV0FBVSxzSEFDYkEsY0FBSSxLQURQO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLFNBQ0M7QUFBQSxxQ0FBQyxPQUFFLFdBQVUsMEJBQTBCOUUsWUFBRSxHQUFHNEYsT0FBTyxRQUFpQixLQUFwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFzRTtBQUFBLGNBQ3RFLHVCQUFDLE9BQUUsV0FBVSw2Q0FDVjVGLFlBQUUsR0FBRzRGLE9BQU8sT0FBZ0IsS0FEL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBS0E7QUFBQSxlQVRPQSxTQUFUO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBVUE7QUFBQSxRQUNELEtBYkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWNBO0FBQUEsV0FuQlFELElBQUlILFNBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQW9CQTtBQUFBLElBQ0QsS0ExQkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTJCQTtBQUFBLElBRUEsdUJBQUMsT0FBRSxXQUFVLHlHQUNYO0FBQUEsNkJBQUMsWUFBTyxXQUFVLDBCQUF5QixtQ0FBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE4RDtBQUFBLE1BQVM7QUFBQSxTQUR6RTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBS0E7QUFBQSxPQXZDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBd0NBLEtBekNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0EwQ0E7QUFFSjtBQUFDRCxJQS9DUUQsWUFBVTtBQUFBLFVBQ0g3RixPQUFPO0FBQUE7QUFBQSxNQURkNkY7QUFBVSxJQUFBTyxJQUFBQyxLQUFBcEMsS0FBQXFDLEtBQUFDLEtBQUFDLEtBQUFDO0FBQUEsYUFBQUwsSUFBQTtBQUFBLGFBQUFDLEtBQUE7QUFBQSxhQUFBcEMsS0FBQTtBQUFBLGFBQUFxQyxLQUFBO0FBQUEsYUFBQUMsS0FBQTtBQUFBLGFBQUFDLEtBQUE7QUFBQSxhQUFBQyxLQUFBIiwibmFtZXMiOlsidXNlTWVtbyIsInVzZVN0YXRlIiwiTGluayIsInVzZU5hdmlnYXRlIiwiQXJyb3dSaWdodCIsIlNlYXJjaCIsIk1hcFBpbiIsInVzZUhhYml0byIsIkJ1dHRvbiIsIlNwYWNlQ2FyZCIsIkNBVEVHT1JZX1NUWUxFIiwiQXJlYVBpY2tlciIsIlNQQUNFX1RZUEVfTEFCRUwiLCJtb25leUNvbXBhY3QiLCJkYXlzU2luY2UiLCJjbiIsImRpc3BsYXlJbWFnZSIsInVzZUkxOG4iLCJTcGFjZUNhcmRTa2VsZXRvbiIsIkNBVEVHT1JJRVMiLCJPYmplY3QiLCJrZXlzIiwiSG9tZSIsIl9zIiwidCIsImxpc3RpbmdzIiwicmVhZHkiLCJpc1NhdmVkIiwidG9nZ2xlU2F2ZWQiLCJpc0NvbXBhcmluZyIsInRvZ2dsZUNvbXBhcmUiLCJyZXF1aXJlbWVudHMiLCJzZXRSZXF1aXJlbWVudHMiLCJmcmVzaCIsImZpbHRlciIsImwiLCJzcGFjZSIsImF2YWlsYWJpbGl0eSIsInN0YXR1cyIsInNvcnQiLCJhIiwiYiIsImxhc3RVcGRhdGVkIiwiYnVkZ2V0IiwidHJhbnNhY3Rpb24iLCJjYXRlZ29yeSIsImNvc3QiLCJwcmljZSIsImNvbW1lcmNpYWwiLCJydXJhbCIsInByb3BlcnR5IiwiZ2VvZ3JhcGh5IiwicmFpbCIsIm9uVG9nZ2xlU2F2ZSIsImlkIiwib25Ub2dnbGVDb21wYXJlIiwic2xpY2UiLCJIZXJvIiwiX3MyIiwibmF2aWdhdGUiLCJzZXRUcmFuc2FjdGlvbiIsInNldENhdGVnb3J5IiwiYXJlYSIsInNldEFyZWEiLCJidWRnZXRNYXgiLCJzZXRCdWRnZXRNYXgiLCJTdHJpbmciLCJzdWJtaXQiLCJzcGFjZVR5cGUiLCJOdW1iZXIiLCJtYXAiLCJ0MiIsImMiLCJJY29uIiwiaWNvbiIsImUiLCJ0YXJnZXQiLCJ2YWx1ZSIsIkNhdGVnb3J5Q2hpcCIsImFjdGl2ZSIsIm9uQ2xpY2siLCJjaGlsZHJlbiIsIl9jMyIsIkNhdGVnb3J5U3RyaXAiLCJfczMiLCJzdHlsZSIsImluQ2F0ZWdvcnkiLCJyZW50YWxzIiwiZnJvbSIsImxlbmd0aCIsIk1hdGgiLCJtaW4iLCJjaGlwIiwiY291bnQiLCJSYWlsIiwidGl0bGUiLCJsZWFkIiwidG8iLCJpdGVtcyIsIl9zNCIsIkFycmF5IiwiXyIsImkiLCJCZXlvbmRUaGVDaXR5IiwiX3M1IiwiZmVhdHVyZWQiLCJpbWFnZXMiLCJhbHQiLCJTRUVLRVJfU1RFUFMiLCJPV05FUl9TVEVQUyIsIkhvd0l0V29ya3MiLCJfczYiLCJoZWFkaW5nIiwic3RlcHMiLCJhY2NlbnQiLCJjb2wiLCJzdGVwS2V5IiwiX2MiLCJfYzIiLCJfYzQiLCJfYzUiLCJfYzYiLCJfYzciXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiSG9tZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlTWVtbywgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IExpbmssIHVzZU5hdmlnYXRlIH0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIjtcbmltcG9ydCB7IEFycm93UmlnaHQsIFNlYXJjaCwgTWFwUGluIH0gZnJvbSBcImx1Y2lkZS1yZWFjdFwiO1xuaW1wb3J0IHsgdXNlSGFiaXRvIH0gZnJvbSBcIkAvaG9va3MvdXNlSGFiaXRvXCI7XG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tIFwiQC9jb21wb25lbnRzL3VpL0J1dHRvblwiO1xuaW1wb3J0IHsgU3BhY2VDYXJkIH0gZnJvbSBcIkAvY29tcG9uZW50cy9zcGFjZS9TcGFjZUNhcmRcIjtcbmltcG9ydCB7IENBVEVHT1JZX1NUWUxFIH0gZnJvbSBcIkAvZGF0YS9jYXRhbG9nXCI7XG5pbXBvcnQgeyBBcmVhUGlja2VyIH0gZnJvbSBcIkAvY29tcG9uZW50cy91aS9BcmVhUGlja2VyXCI7XG5pbXBvcnQgeyBTUEFDRV9UWVBFX0xBQkVMIH0gZnJvbSBcIkAvdHlwZXMvc3BhY2VcIjtcbmltcG9ydCB0eXBlIHsgU3BhY2VDYXRlZ29yeSwgU3BhY2VMaXN0aW5nLCBUcmFuc2FjdGlvblR5cGUgfSBmcm9tIFwiQC90eXBlcy9zcGFjZVwiO1xuaW1wb3J0IHsgbW9uZXlDb21wYWN0LCBkYXlzU2luY2UgfSBmcm9tIFwiQC9saWIvZm9ybWF0XCI7XG5pbXBvcnQgeyBjbiB9IGZyb20gXCJAL2xpYi9jblwiO1xuaW1wb3J0IHsgZGlzcGxheUltYWdlIH0gZnJvbSBcIkAvbGliL2xvY2FsaXplXCI7XG5pbXBvcnQgeyB1c2VJMThuIH0gZnJvbSBcIkAvaTE4blwiO1xuaW1wb3J0IHsgU3BhY2VDYXJkU2tlbGV0b24gfSBmcm9tIFwiQC9jb21wb25lbnRzL3VpL1NrZWxldG9uXCI7XG5cbmNvbnN0IENBVEVHT1JJRVMgPSBPYmplY3Qua2V5cyhDQVRFR09SWV9TVFlMRSkgYXMgU3BhY2VDYXRlZ29yeVtdO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBIb21lKCkge1xuICBjb25zdCB7IHQgfSA9IHVzZUkxOG4oKTtcbiAgY29uc3QgeyBsaXN0aW5ncywgcmVhZHksIGlzU2F2ZWQsIHRvZ2dsZVNhdmVkLCBpc0NvbXBhcmluZywgdG9nZ2xlQ29tcGFyZSwgcmVxdWlyZW1lbnRzLCBzZXRSZXF1aXJlbWVudHMgfSA9XG4gICAgdXNlSGFiaXRvKCk7XG5cbiAgY29uc3QgZnJlc2ggPSB1c2VNZW1vKFxuICAgICgpID0+XG4gICAgICBbLi4ubGlzdGluZ3NdXG4gICAgICAgIC5maWx0ZXIoKGwpID0+IGwuc3BhY2UuYXZhaWxhYmlsaXR5LnN0YXR1cyAhPT0gXCJvY2N1cGllZFwiKVxuICAgICAgICAuc29ydCgoYSwgYikgPT4gZGF5c1NpbmNlKGEuc3BhY2UubGFzdFVwZGF0ZWQpIC0gZGF5c1NpbmNlKGIuc3BhY2UubGFzdFVwZGF0ZWQpKSxcbiAgICBbbGlzdGluZ3NdLFxuICApO1xuXG4gIGNvbnN0IGJ1ZGdldCA9IHVzZU1lbW8oXG4gICAgKCkgPT5cbiAgICAgIFsuLi5saXN0aW5nc11cbiAgICAgICAgLmZpbHRlcigobCkgPT4gbC5zcGFjZS50cmFuc2FjdGlvbiA9PT0gXCJyZW50XCIgJiYgbC5zcGFjZS5jYXRlZ29yeSA9PT0gXCJsaXZpbmdcIilcbiAgICAgICAgLnNvcnQoKGEsIGIpID0+IGEuc3BhY2UuY29zdC5wcmljZSAtIGIuc3BhY2UuY29zdC5wcmljZSksXG4gICAgW2xpc3RpbmdzXSxcbiAgKTtcblxuICBjb25zdCBjb21tZXJjaWFsID0gdXNlTWVtbyhcbiAgICAoKSA9PiBsaXN0aW5ncy5maWx0ZXIoKGwpID0+IGwuc3BhY2UuY2F0ZWdvcnkgPT09IFwiYnVzaW5lc3NcIiB8fCBsLnNwYWNlLmNhdGVnb3J5ID09PSBcInN0b3JhZ2VcIiksXG4gICAgW2xpc3RpbmdzXSxcbiAgKTtcblxuICBjb25zdCBydXJhbCA9IHVzZU1lbW8oKCkgPT4gbGlzdGluZ3MuZmlsdGVyKChsKSA9PiBsLnByb3BlcnR5Lmdlb2dyYXBoeSA9PT0gXCJydXJhbFwiKSwgW2xpc3RpbmdzXSk7XG5cbiAgY29uc3QgcmFpbCA9IHtcbiAgICByZWFkeSxcbiAgICBpc1NhdmVkLFxuICAgIGlzQ29tcGFyaW5nLFxuICAgIG9uVG9nZ2xlU2F2ZTogKGlkOiBzdHJpbmcpID0+IHZvaWQgdG9nZ2xlU2F2ZWQoaWQpLFxuICAgIG9uVG9nZ2xlQ29tcGFyZTogKGlkOiBzdHJpbmcpID0+IHRvZ2dsZUNvbXBhcmUoaWQpLFxuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPD5cbiAgICAgIDxIZXJvIHJlcXVpcmVtZW50cz17cmVxdWlyZW1lbnRzfSBzZXRSZXF1aXJlbWVudHM9e3NldFJlcXVpcmVtZW50c30gLz5cblxuICAgICAgPENhdGVnb3J5U3RyaXAgbGlzdGluZ3M9e2xpc3RpbmdzfSAvPlxuXG4gICAgICA8UmFpbFxuICAgICAgICB0aXRsZT17dChcImhvbWUubmV3VGhpc1dlZWtcIil9XG4gICAgICAgIGxlYWQ9e3QoXCJob21lLm5ld1RoaXNXZWVrQm9keVwiKX1cbiAgICAgICAgdG89XCIvc2VhcmNoXCJcbiAgICAgICAgaXRlbXM9e2ZyZXNoLnNsaWNlKDAsIDgpfVxuICAgICAgICB7Li4ucmFpbH1cbiAgICAgIC8+XG5cbiAgICAgIDxCZXlvbmRUaGVDaXR5IGxpc3RpbmdzPXtydXJhbH0gLz5cblxuICAgICAgPFJhaWxcbiAgICAgICAgdGl0bGU9e3QoXCJob21lLnJvb21Ub1dvcmtcIil9XG4gICAgICAgIGxlYWQ9e3QoXCJob21lLnJvb21Ub1dvcmtCb2R5XCIpfVxuICAgICAgICB0bz1cIi9zZWFyY2g/Y2F0ZWdvcnk9YnVzaW5lc3NcIlxuICAgICAgICBpdGVtcz17Y29tbWVyY2lhbC5zbGljZSgwLCA4KX1cbiAgICAgICAgey4uLnJhaWx9XG4gICAgICAvPlxuXG4gICAgICA8UmFpbFxuICAgICAgICB0aXRsZT17dChcImhvbWUuYnVkZ2V0VGl0bGVcIil9XG4gICAgICAgIGxlYWQ9e3QoXCJob21lLmJ1ZGdldEJvZHlcIil9XG4gICAgICAgIHRvPVwiL3NlYXJjaD9jYXRlZ29yeT1saXZpbmdcIlxuICAgICAgICBpdGVtcz17YnVkZ2V0LnNsaWNlKDAsIDgpfVxuICAgICAgICB7Li4ucmFpbH1cbiAgICAgIC8+XG5cbiAgICAgIDxIb3dJdFdvcmtzIC8+XG4gICAgPC8+XG4gICk7XG59XG5cbi8qIOKUgOKUgCBIZXJvIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgCAqL1xuXG5mdW5jdGlvbiBIZXJvKHtcbiAgcmVxdWlyZW1lbnRzLFxuICBzZXRSZXF1aXJlbWVudHMsXG59OiB7XG4gIHJlcXVpcmVtZW50czogUmV0dXJuVHlwZTx0eXBlb2YgdXNlSGFiaXRvPltcInJlcXVpcmVtZW50c1wiXTtcbiAgc2V0UmVxdWlyZW1lbnRzOiBSZXR1cm5UeXBlPHR5cGVvZiB1c2VIYWJpdG8+W1wic2V0UmVxdWlyZW1lbnRzXCJdO1xufSkge1xuICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XG4gIGNvbnN0IHsgdCB9ID0gdXNlSTE4bigpO1xuICBjb25zdCBbdHJhbnNhY3Rpb24sIHNldFRyYW5zYWN0aW9uXSA9IHVzZVN0YXRlPFRyYW5zYWN0aW9uVHlwZT4ocmVxdWlyZW1lbnRzLnRyYW5zYWN0aW9uKTtcbiAgY29uc3QgW2NhdGVnb3J5LCBzZXRDYXRlZ29yeV0gPSB1c2VTdGF0ZTxTcGFjZUNhdGVnb3J5IHwgXCJhbnlcIj4ocmVxdWlyZW1lbnRzLmNhdGVnb3J5KTtcbiAgY29uc3QgW2FyZWEsIHNldEFyZWFdID0gdXNlU3RhdGUocmVxdWlyZW1lbnRzLmFyZWEpO1xuICBjb25zdCBbYnVkZ2V0TWF4LCBzZXRCdWRnZXRNYXhdID0gdXNlU3RhdGUoU3RyaW5nKHJlcXVpcmVtZW50cy5idWRnZXRNYXgpKTtcblxuICBjb25zdCBzdWJtaXQgPSAoKSA9PiB7XG4gICAgc2V0UmVxdWlyZW1lbnRzKHtcbiAgICAgIC4uLnJlcXVpcmVtZW50cyxcbiAgICAgIHRyYW5zYWN0aW9uLFxuICAgICAgY2F0ZWdvcnksXG4gICAgICBzcGFjZVR5cGU6IFwiYW55XCIsXG4gICAgICBhcmVhLFxuICAgICAgYnVkZ2V0TWF4OiBOdW1iZXIoYnVkZ2V0TWF4KSB8fCByZXF1aXJlbWVudHMuYnVkZ2V0TWF4LFxuICAgIH0pO1xuICAgIG5hdmlnYXRlKFwiL3NlYXJjaFwiKTtcbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cInJlbGF0aXZlIG92ZXJmbG93LWhpZGRlbiBib3JkZXItYiBib3JkZXItaGFpcmxpbmVcIj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYXRtb3NwaGVyZSBhYnNvbHV0ZSBpbnNldC0wXCIgYXJpYS1oaWRkZW4gLz5cblxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb250YWluZXItcGFnZSByZWxhdGl2ZSBncmlkIGdhcC0xMiBweS0xNCBtZDpweS0yMCBsZzpncmlkLWNvbHMtWzEuMDVmcl8yNnJlbV0gbGc6aXRlbXMtY2VudGVyIGxnOmdhcC0xNlwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJpc2VcIj5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgcm91bmRlZC1mdWxsIGJnLXN1cmZhY2UvODAgcHgtMyBweS0xLjUgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtaW5rLXNvZnQgcmluZy0xIHJpbmctaGFpcmxpbmUgYmFja2Ryb3AtYmx1clwiPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwic2l6ZS0xLjUgcm91bmRlZC1mdWxsIGJnLWNvcmFsXCIgYXJpYS1oaWRkZW4gLz5cbiAgICAgICAgICAgIHt0KFwiaG9tZS5oZXJvRXllYnJvd1wiKX1cbiAgICAgICAgICA8L3A+XG5cbiAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwibXQtNSBmb250LWRpc3BsYXkgdGV4dC1bMi43NXJlbV0gZm9udC1leHRyYWJvbGQgbGVhZGluZy1bMC45OF0gdGV4dC1pbmsgc206dGV4dC02eGwgbGc6dGV4dC1bNC4yNXJlbV1cIj5cbiAgICAgICAgICAgIHt0KFwiaG9tZS5oZXJvTGluZTFcIil9XG4gICAgICAgICAgICA8YnIgLz5cbiAgICAgICAgICAgIHt0KFwiaG9tZS5oZXJvTGluZTJcIil9XG4gICAgICAgICAgPC9oMT5cblxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTYgbWF4LXctbWQgdGV4dC1iYXNlIGxlYWRpbmctcmVsYXhlZCB0ZXh0LWluay1zb2Z0IHNtOnRleHQtbGdcIj5cbiAgICAgICAgICAgIHt0KFwiaG9tZS5oZXJvQm9keVwiKX1cbiAgICAgICAgICA8L3A+XG5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTggZmxleCBmbGV4LXdyYXAgZ2FwLTNcIj5cbiAgICAgICAgICAgIDxMaW5rIHRvPVwiL2ZpbmRcIj5cbiAgICAgICAgICAgICAgPEJ1dHRvbiBzaXplPVwibGdcIj5cbiAgICAgICAgICAgICAgICB7dChcImhvbWUuZmluZFNwYWNlXCIpfVxuICAgICAgICAgICAgICAgIDxBcnJvd1JpZ2h0IHNpemU9ezE3fSBhcmlhLWhpZGRlbiAvPlxuICAgICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgIDwvTGluaz5cbiAgICAgICAgICAgIDxMaW5rIHRvPVwiL2xpc3RcIj5cbiAgICAgICAgICAgICAgPEJ1dHRvbiBzaXplPVwibGdcIiB2YXJpYW50PVwic2Vjb25kYXJ5XCI+XG4gICAgICAgICAgICAgICAge3QoXCJob21lLmxpc3RTcGFjZVwiKX1cbiAgICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgICA8L0xpbms+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBUaGUgc2VhcmNoIGlzIHBhcnQgb2YgdGhlIHByb2R1Y3QsIG5vdCBhIGJhciBkcm9wcGVkIG9uIGEgYmFubmVyLiAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyaXNlIHJvdW5kZWQtY2FyZCBiZy1zdXJmYWNlLzk1IHAtNSBzaGFkb3ctWzBfMzBweF83MHB4Xy00MHB4X3JnYigxNl8yNF80MC8wLjU1KV0gcmluZy0xIHJpbmctaGFpcmxpbmUgYmFja2Ryb3AtYmx1ciBzbTpwLTZcIj5cbiAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwiZm9udC1kaXNwbGF5IHRleHQtbGcgZm9udC1ib2xkIHRleHQtaW5rXCI+e3QoXCJob21lLmxvb2tpbmdGb3JcIil9PC9oMj5cblxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNCBpbmxpbmUtZmxleCByb3VuZGVkLWZ1bGwgYmctaXZvcnktZGVlcCBwLTAuNVwiPlxuICAgICAgICAgICAgeyhbXCJyZW50XCIsIFwic2FsZVwiXSBhcyBUcmFuc2FjdGlvblR5cGVbXSkubWFwKCh0MikgPT4gKFxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAga2V5PXt0Mn1cbiAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICBhcmlhLXByZXNzZWQ9e3RyYW5zYWN0aW9uID09PSB0Mn1cbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRUcmFuc2FjdGlvbih0Mil9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgICAgICAgICAgIFwicm91bmRlZC1mdWxsIHB4LTQgcHktMS41IHRleHQtc20gZm9udC1ib2xkIHRyYW5zaXRpb24tY29sb3JzXCIsXG4gICAgICAgICAgICAgICAgICB0cmFuc2FjdGlvbiA9PT0gdDIgPyBcImJnLWluayB0ZXh0LWl2b3J5XCIgOiBcInRleHQtbXV0ZWQgaG92ZXI6dGV4dC1pbmtcIixcbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAge3QyID09PSBcInJlbnRcIiA/IHQoXCJ0cmFuc2FjdGlvbi5yZW50XCIpIDogdChcInRyYW5zYWN0aW9uLmJ1eVwiKX1cbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICApKX1cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDx1bCBjbGFzc05hbWU9XCJtdC00IGZsZXggZmxleC13cmFwIGdhcC0xLjVcIj5cbiAgICAgICAgICAgIDxsaT5cbiAgICAgICAgICAgICAgPENhdGVnb3J5Q2hpcCBhY3RpdmU9e2NhdGVnb3J5ID09PSBcImFueVwifSBvbkNsaWNrPXsoKSA9PiBzZXRDYXRlZ29yeShcImFueVwiKX0+XG4gICAgICAgICAgICAgICAge3QoXCJob21lLmFueXRoaW5nXCIpfVxuICAgICAgICAgICAgICA8L0NhdGVnb3J5Q2hpcD5cbiAgICAgICAgICAgIDwvbGk+XG4gICAgICAgICAgICB7Q0FURUdPUklFUy5tYXAoKGMpID0+IHtcbiAgICAgICAgICAgICAgY29uc3QgSWNvbiA9IENBVEVHT1JZX1NUWUxFW2NdLmljb247XG4gICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgPGxpIGtleT17Y30+XG4gICAgICAgICAgICAgICAgICA8Q2F0ZWdvcnlDaGlwIGFjdGl2ZT17Y2F0ZWdvcnkgPT09IGN9IG9uQ2xpY2s9eygpID0+IHNldENhdGVnb3J5KGMpfT5cbiAgICAgICAgICAgICAgICAgICAgPEljb24gc2l6ZT17MTN9IGFyaWEtaGlkZGVuIC8+XG4gICAgICAgICAgICAgICAgICAgIHt0KGBjYXRlZ29yeS4ke2N9YCBhcyBuZXZlcil9XG4gICAgICAgICAgICAgICAgICA8L0NhdGVnb3J5Q2hpcD5cbiAgICAgICAgICAgICAgICA8L2xpPlxuICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgfSl9XG4gICAgICAgICAgPC91bD5cblxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNCBncmlkIGdhcC0zIHNtOmdyaWQtY29scy0yXCI+XG4gICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2tcIj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWItMS41IGJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1pbmstc29mdFwiPnt0KFwiaG9tZS53aGVyZVwiKX08L3NwYW4+XG4gICAgICAgICAgICAgIDxBcmVhUGlja2VyIHZhbHVlPXthcmVhfSBvbkNoYW5nZT17c2V0QXJlYX0gLz5cbiAgICAgICAgICAgIDwvbGFiZWw+XG5cbiAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9ja1wiPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtYi0xLjUgYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWluay1zb2Z0XCI+e3QoXCJob21lLnVwVG9cIil9PC9zcGFuPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlXCI+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicG9pbnRlci1ldmVudHMtbm9uZSBhYnNvbHV0ZSBsZWZ0LTMgdG9wLTEvMiAtdHJhbnNsYXRlLXktMS8yIHRleHQtbXV0ZWRcIj7gp7M8L3NwYW4+XG4gICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcbiAgICAgICAgICAgICAgICAgIGlucHV0TW9kZT1cIm51bWVyaWNcIlxuICAgICAgICAgICAgICAgICAgc3RlcD17NTAwfVxuICAgICAgICAgICAgICAgICAgdmFsdWU9e2J1ZGdldE1heH1cbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0QnVkZ2V0TWF4KGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImgtMTEgdy1mdWxsIHJvdW5kZWQteGwgYmctaXZvcnkgcGwtNyBwci0zIHRleHQtWzAuOTM3NXJlbV0gdG51bSB0ZXh0LWluayByaW5nLTEgcmluZy1oYWlybGluZS1zdHJvbmcgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWFxdWEtNjAwXCJcbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICA8QnV0dG9uIHNpemU9XCJsZ1wiIGZ1bGxXaWR0aCBjbGFzc05hbWU9XCJtdC00XCIgb25DbGljaz17c3VibWl0fT5cbiAgICAgICAgICAgIDxTZWFyY2ggc2l6ZT17MTd9IGFyaWEtaGlkZGVuIC8+XG4gICAgICAgICAgICB7dChcImhvbWUuZXhwbG9yZVNwYWNlc1wiKX1cbiAgICAgICAgICA8L0J1dHRvbj5cblxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTMgdGV4dC1jZW50ZXIgdGV4dC14cyB0ZXh0LW11dGVkXCI+XG4gICAgICAgICAgICB7dChcImhvbWUud2FudFNjb3JlZFwiKX17XCIgXCJ9XG4gICAgICAgICAgICA8TGluayB0bz1cIi9maW5kXCIgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWFxdWEtNzAwIGhvdmVyOnVuZGVybGluZVwiPlxuICAgICAgICAgICAgICB7dChcImhvbWUudGVsbFVzXCIpfVxuICAgICAgICAgICAgPC9MaW5rPlxuICAgICAgICAgIDwvcD5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICA8L3NlY3Rpb24+XG4gICk7XG59XG5cbmZ1bmN0aW9uIENhdGVnb3J5Q2hpcCh7XG4gIGFjdGl2ZSxcbiAgb25DbGljayxcbiAgY2hpbGRyZW4sXG59OiB7XG4gIGFjdGl2ZTogYm9vbGVhbjtcbiAgb25DbGljazogKCkgPT4gdm9pZDtcbiAgY2hpbGRyZW46IFJlYWN0LlJlYWN0Tm9kZTtcbn0pIHtcbiAgcmV0dXJuIChcbiAgICA8YnV0dG9uXG4gICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgIGFyaWEtcHJlc3NlZD17YWN0aXZlfVxuICAgICAgb25DbGljaz17b25DbGlja31cbiAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgIFwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcm91bmRlZC1mdWxsIHB4LTMgcHktMS41IHRleHQtc20gZm9udC1zZW1pYm9sZCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0xNTBcIixcbiAgICAgICAgYWN0aXZlID8gXCJiZy1pbmsgdGV4dC1pdm9yeVwiIDogXCJiZy1pdm9yeS1kZWVwIHRleHQtaW5rLXNvZnQgaG92ZXI6YmctaGFpcmxpbmVcIixcbiAgICAgICl9XG4gICAgPlxuICAgICAge2NoaWxkcmVufVxuICAgIDwvYnV0dG9uPlxuICApO1xufVxuXG4vKiDilIDilIAgQ2F0ZWdvcnkgc3RyaXAg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAICovXG5cbmZ1bmN0aW9uIENhdGVnb3J5U3RyaXAoeyBsaXN0aW5ncyB9OiB7IGxpc3RpbmdzOiBTcGFjZUxpc3RpbmdbXSB9KSB7XG4gIGNvbnN0IHsgdCB9ID0gdXNlSTE4bigpO1xuICByZXR1cm4gKFxuICAgIDxzZWN0aW9uIGFyaWEtbGFiZWxsZWRieT1cImNhdHNcIiBjbGFzc05hbWU9XCJjb250YWluZXItcGFnZSBweS0xNCBtZDpweS0xNlwiPlxuICAgICAgPGgyIGlkPVwiY2F0c1wiIGNsYXNzTmFtZT1cImZvbnQtZGlzcGxheSB0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1pbmsgc206dGV4dC0zeGxcIj5cbiAgICAgICAge3QoXCJob21lLmV2ZXJ5S2luZFwiKX1cbiAgICAgIDwvaDI+XG4gICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIG1heC13LWxnIHRleHQtc20gdGV4dC1tdXRlZFwiPlxuICAgICAgICB7dChcImhvbWUuZXZlcnlLaW5kQm9keVwiKX1cbiAgICAgIDwvcD5cblxuICAgICAgPHVsIGNsYXNzTmFtZT1cIm10LTcgZ3JpZCBnYXAtMyBzbTpncmlkLWNvbHMtMiBsZzpncmlkLWNvbHMtNVwiPlxuICAgICAgICB7Q0FURUdPUklFUy5tYXAoKGMpID0+IHtcbiAgICAgICAgICBjb25zdCBzdHlsZSA9IENBVEVHT1JZX1NUWUxFW2NdO1xuICAgICAgICAgIGNvbnN0IGluQ2F0ZWdvcnkgPSBsaXN0aW5ncy5maWx0ZXIoKGwpID0+IGwuc3BhY2UuY2F0ZWdvcnkgPT09IGMpO1xuICAgICAgICAgIGNvbnN0IHJlbnRhbHMgPSBpbkNhdGVnb3J5LmZpbHRlcigobCkgPT4gbC5zcGFjZS50cmFuc2FjdGlvbiA9PT0gXCJyZW50XCIpO1xuICAgICAgICAgIGNvbnN0IGZyb20gPSByZW50YWxzLmxlbmd0aCA/IE1hdGgubWluKC4uLnJlbnRhbHMubWFwKChsKSA9PiBsLnNwYWNlLmNvc3QucHJpY2UpKSA6IG51bGw7XG5cbiAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgPGxpIGtleT17Y30+XG4gICAgICAgICAgICAgIDxMaW5rXG4gICAgICAgICAgICAgICAgdG89e2Avc2VhcmNoP2NhdGVnb3J5PSR7Y31gfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaC1mdWxsIGZsZXgtY29sIGdhcC0zIHJvdW5kZWQtY2FyZCBiZy1zdXJmYWNlIHAtNSByaW5nLTEgcmluZy1oYWlybGluZSB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0yMDAgaG92ZXI6LXRyYW5zbGF0ZS15LTAuNSBob3ZlcjpyaW5nLWlua1wiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2NuKFwiZmxleCBzaXplLTEwIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciByb3VuZGVkLXhsXCIsIHN0eWxlLmNoaXApfT5cbiAgICAgICAgICAgICAgICAgIDxzdHlsZS5pY29uIHNpemU9ezE5fSBhcmlhLWhpZGRlbiAvPlxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWRpc3BsYXkgZm9udC1ib2xkIHRleHQtaW5rXCI+e3QoYGNhdGVnb3J5LiR7Y31gIGFzIG5ldmVyKX08L3NwYW4+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBsZWFkaW5nLXNudWcgdGV4dC1tdXRlZFwiPnt0KGBjYXRlZ29yeS4ke2N9LmJsdXJiYCBhcyBuZXZlcil9PC9zcGFuPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm10LWF1dG8gcHQtMiB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdG51bSB0ZXh0LWlua1wiPlxuICAgICAgICAgICAgICAgICAge3QoXCJob21lLnNwYWNlc0NvdW50XCIsIHsgY291bnQ6IGluQ2F0ZWdvcnkubGVuZ3RoIH0pfVxuICAgICAgICAgICAgICAgICAge2Zyb20gIT09IG51bGwgJiYgKFxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1lZGl1bSB0ZXh0LW11dGVkXCI+XG4gICAgICAgICAgICAgICAgICAgICAge1wiIMK3IFwifVxuICAgICAgICAgICAgICAgICAgICAgIHt0KFwiaG9tZS5mcm9tXCIsIHsgcHJpY2U6IG1vbmV5Q29tcGFjdChmcm9tKSB9KX1cbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgIDwvTGluaz5cbiAgICAgICAgICAgIDwvbGk+XG4gICAgICAgICAgKTtcbiAgICAgICAgfSl9XG4gICAgICA8L3VsPlxuICAgIDwvc2VjdGlvbj5cbiAgKTtcbn1cblxuLyog4pSA4pSAIEhvcml6b250YWwgcmFpbCDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIAgKi9cblxuZnVuY3Rpb24gUmFpbCh7XG4gIHRpdGxlLFxuICBsZWFkLFxuICB0byxcbiAgaXRlbXMsXG4gIHJlYWR5LFxuICBpc1NhdmVkLFxuICBpc0NvbXBhcmluZyxcbiAgb25Ub2dnbGVTYXZlLFxuICBvblRvZ2dsZUNvbXBhcmUsXG59OiB7XG4gIHRpdGxlOiBzdHJpbmc7XG4gIGxlYWQ6IHN0cmluZztcbiAgdG86IHN0cmluZztcbiAgaXRlbXM6IFNwYWNlTGlzdGluZ1tdO1xuICByZWFkeTogYm9vbGVhbjtcbiAgaXNTYXZlZDogKGlkOiBzdHJpbmcpID0+IGJvb2xlYW47XG4gIGlzQ29tcGFyaW5nOiAoaWQ6IHN0cmluZykgPT4gYm9vbGVhbjtcbiAgb25Ub2dnbGVTYXZlOiAoaWQ6IHN0cmluZykgPT4gdm9pZDtcbiAgb25Ub2dnbGVDb21wYXJlOiAoaWQ6IHN0cmluZykgPT4gdm9pZDtcbn0pIHtcbiAgY29uc3QgeyB0IH0gPSB1c2VJMThuKCk7XG4gIGlmIChyZWFkeSAmJiBpdGVtcy5sZW5ndGggPT09IDApIHJldHVybiBudWxsO1xuXG4gIHJldHVybiAoXG4gICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwicHktNiBtZDpweS04XCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbnRhaW5lci1wYWdlIGZsZXggZmxleC13cmFwIGl0ZW1zLWVuZCBqdXN0aWZ5LWJldHdlZW4gZ2FwLTNcIj5cbiAgICAgICAgPGRpdj5cbiAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwiZm9udC1kaXNwbGF5IHRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LWluayBzbTp0ZXh0LTN4bFwiPnt0aXRsZX08L2gyPlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEuNSB0ZXh0LXNtIHRleHQtbXV0ZWRcIj57bGVhZH08L3A+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8TGluayB0bz17dG99IGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWFxdWEtNzAwIGhvdmVyOnRleHQtaW5rXCI+XG4gICAgICAgICAge3QoXCJhY3Rpb24uc2VlQWxsXCIpfVxuICAgICAgICAgIDxBcnJvd1JpZ2h0IHNpemU9ezE1fSBhcmlhLWhpZGRlbiAvPlxuICAgICAgICA8L0xpbms+XG4gICAgICA8L2Rpdj5cblxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC02IGZsZXggZ2FwLTQgb3ZlcmZsb3cteC1hdXRvIHB4LTUgcGItMiBoaWRlLXNjcm9sbGJhciBtZDpweC04XCI+XG4gICAgICAgIHshcmVhZHlcbiAgICAgICAgICA/IEFycmF5LmZyb20oeyBsZW5ndGg6IDQgfSwgKF8sIGkpID0+IChcbiAgICAgICAgICAgICAgPGRpdiBrZXk9e2l9IGNsYXNzTmFtZT1cInctNjggc2hyaW5rLTAgc206dy03NlwiPlxuICAgICAgICAgICAgICAgIDxTcGFjZUNhcmRTa2VsZXRvbiAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICkpXG4gICAgICAgICAgOiBpdGVtcy5tYXAoKGwpID0+IChcbiAgICAgICAgICAgICAgPGRpdiBrZXk9e2wuc3BhY2UuaWR9IGNsYXNzTmFtZT1cInctNjggc2hyaW5rLTAgc206dy03NlwiPlxuICAgICAgICAgICAgICAgIDxTcGFjZUNhcmRcbiAgICAgICAgICAgICAgICAgIGxpc3Rpbmc9e2x9XG4gICAgICAgICAgICAgICAgICBzYXZlZD17aXNTYXZlZChsLnNwYWNlLmlkKX1cbiAgICAgICAgICAgICAgICAgIGNvbXBhcmluZz17aXNDb21wYXJpbmcobC5zcGFjZS5pZCl9XG4gICAgICAgICAgICAgICAgICBvblRvZ2dsZVNhdmU9e29uVG9nZ2xlU2F2ZX1cbiAgICAgICAgICAgICAgICAgIG9uVG9nZ2xlQ29tcGFyZT17b25Ub2dnbGVDb21wYXJlfVxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKSl9XG4gICAgICA8L2Rpdj5cbiAgICA8L3NlY3Rpb24+XG4gICk7XG59XG5cbi8qIOKUgOKUgCBCZXlvbmQgdGhlIGNpdHkg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAICovXG5cbmZ1bmN0aW9uIEJleW9uZFRoZUNpdHkoeyBsaXN0aW5ncyB9OiB7IGxpc3RpbmdzOiBTcGFjZUxpc3RpbmdbXSB9KSB7XG4gIGNvbnN0IHsgdCB9ID0gdXNlSTE4bigpO1xuICBpZiAobGlzdGluZ3MubGVuZ3RoID09PSAwKSByZXR1cm4gbnVsbDtcbiAgY29uc3QgZmVhdHVyZWQgPSBsaXN0aW5ncy5zbGljZSgwLCAzKTtcblxuICByZXR1cm4gKFxuICAgIDxzZWN0aW9uIGFyaWEtbGFiZWxsZWRieT1cInJ1cmFsXCIgY2xhc3NOYW1lPVwibXktMTAgbWQ6bXktMTRcIj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29udGFpbmVyLXBhZ2VcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJvdmVyZmxvdy1oaWRkZW4gcm91bmRlZC1jYXJkIGJnLWluayB0ZXh0LWl2b3J5XCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdhcC04IHAtNyBtZDpncmlkLWNvbHMtWzFmcl8xLjE1ZnJdIG1kOml0ZW1zLWNlbnRlciBtZDpwLTEwXCI+XG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgcm91bmRlZC1mdWxsIGJnLXdoaXRlLzEwIHB4LTMgcHktMSB0ZXh0LXhzIGZvbnQtc2VtaWJvbGRcIj5cbiAgICAgICAgICAgICAgICA8TWFwUGluIHNpemU9ezEyfSBhcmlhLWhpZGRlbiAvPlxuICAgICAgICAgICAgICAgIHt0KFwiaG9tZS5vdXRzaWRlQ2l0eVwiKX1cbiAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICA8aDIgaWQ9XCJydXJhbFwiIGNsYXNzTmFtZT1cIm10LTQgZm9udC1kaXNwbGF5IHRleHQtM3hsIGZvbnQtYm9sZCBsZWFkaW5nLXRpZ2h0IHNtOnRleHQtNHhsXCI+XG4gICAgICAgICAgICAgICAge3QoXCJob21lLnJ1cmFsVGl0bGVcIil9XG4gICAgICAgICAgICAgIDwvaDI+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTQgbWF4LXctc20gbGVhZGluZy1yZWxheGVkIHRleHQtaXZvcnkvNzBcIj5cbiAgICAgICAgICAgICAgICB7dChcImhvbWUucnVyYWxCb2R5XCIpfVxuICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgIDxMaW5rIHRvPVwiL3NlYXJjaD9nZW9ncmFwaHk9cnVyYWxcIiBjbGFzc05hbWU9XCJtdC02IGlubGluZS1ibG9ja1wiPlxuICAgICAgICAgICAgICAgIDxCdXR0b24gc2l6ZT1cImxnXCIgY2xhc3NOYW1lPVwiYmctYXF1YS00MDAgdGV4dC1pbmsgaG92ZXI6YmctYXF1YS0yMDBcIj5cbiAgICAgICAgICAgICAgICAgIHt0KFwiaG9tZS5ydXJhbEN0YVwiKX1cbiAgICAgICAgICAgICAgICAgIDxBcnJvd1JpZ2h0IHNpemU9ezE2fSBhcmlhLWhpZGRlbiAvPlxuICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgICA8L0xpbms+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPHVsIGNsYXNzTmFtZT1cImdyaWQgZ2FwLTMgc206Z3JpZC1jb2xzLTNcIj5cbiAgICAgICAgICAgICAge2ZlYXR1cmVkLm1hcCgobCkgPT4gKFxuICAgICAgICAgICAgICAgIDxsaSBrZXk9e2wuc3BhY2UuaWR9PlxuICAgICAgICAgICAgICAgICAgPExpbmtcbiAgICAgICAgICAgICAgICAgICAgdG89e2Avc3BhY2UvJHtsLnNwYWNlLmlkfWB9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImdyb3VwIGJsb2NrIG92ZXJmbG93LWhpZGRlbiByb3VuZGVkLTJ4bCBiZy13aGl0ZS81IHJpbmctMSByaW5nLXdoaXRlLzEwIHRyYW5zaXRpb24tY29sb3JzIGhvdmVyOmJnLXdoaXRlLzEwXCJcbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhc3BlY3QtNC8zIG92ZXJmbG93LWhpZGRlblwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxpbWdcbiAgICAgICAgICAgICAgICAgICAgICAgIHNyYz17ZGlzcGxheUltYWdlKGwuc3BhY2UuaW1hZ2VzWzBdKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIGFsdD17bC5zcGFjZS5pbWFnZXNbMF0uYWx0fVxuICAgICAgICAgICAgICAgICAgICAgICAgbG9hZGluZz1cImxhenlcIlxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwic2l6ZS1mdWxsIG9iamVjdC1jb3ZlciB0cmFuc2l0aW9uLXRyYW5zZm9ybSBkdXJhdGlvbi01MDAgZ3JvdXAtaG92ZXI6c2NhbGUtMTA1XCJcbiAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTNcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0cnVuY2F0ZSB0ZXh0LXNtIGZvbnQtc2VtaWJvbGRcIj57U1BBQ0VfVFlQRV9MQUJFTFtsLnNwYWNlLnNwYWNlVHlwZV19PC9wPlxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRydW5jYXRlIHRleHQteHMgdGV4dC1pdm9yeS82MFwiPntsLnByb3BlcnR5LmFyZWF9PC9wPlxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC1zbSBmb250LWJvbGQgdG51bVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAge21vbmV5Q29tcGFjdChsLnNwYWNlLmNvc3QucHJpY2UpfVxuICAgICAgICAgICAgICAgICAgICAgICAge2wuc3BhY2UudHJhbnNhY3Rpb24gPT09IFwicmVudFwiICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWl2b3J5LzYwXCI+L21vPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9MaW5rPlxuICAgICAgICAgICAgICAgIDwvbGk+XG4gICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgPC91bD5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICA8L3NlY3Rpb24+XG4gICk7XG59XG5cbi8qIOKUgOKUgCBIb3cgaXQgd29ya3Mg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAICovXG5cbmNvbnN0IFNFRUtFUl9TVEVQUyA9IFtcInN0ZXBzLnNlZWtlcjFcIiwgXCJzdGVwcy5zZWVrZXIyXCIsIFwic3RlcHMuc2Vla2VyM1wiLCBcInN0ZXBzLnNlZWtlcjRcIl0gYXMgY29uc3Q7XG5jb25zdCBPV05FUl9TVEVQUyA9IFtcInN0ZXBzLm93bmVyMVwiLCBcInN0ZXBzLm93bmVyMlwiLCBcInN0ZXBzLm93bmVyM1wiLCBcInN0ZXBzLm93bmVyNFwiXSBhcyBjb25zdDtcblxuZnVuY3Rpb24gSG93SXRXb3JrcygpIHtcbiAgY29uc3QgeyB0IH0gPSB1c2VJMThuKCk7XG4gIHJldHVybiAoXG4gICAgPHNlY3Rpb24gYXJpYS1sYWJlbGxlZGJ5PVwiaG93XCIgY2xhc3NOYW1lPVwiYm9yZGVyLXQgYm9yZGVyLWhhaXJsaW5lIGJnLWl2b3J5LWRlZXBcIj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29udGFpbmVyLXBhZ2UgcHktMTQgbWQ6cHktMjBcIj5cbiAgICAgICAgPGgyIGlkPVwiaG93XCIgY2xhc3NOYW1lPVwiZm9udC1kaXNwbGF5IHRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LWluayBzbTp0ZXh0LTN4bFwiPlxuICAgICAgICAgIHt0KFwiaG9tZS50d29TaWRlc1wiKX1cbiAgICAgICAgPC9oMj5cblxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTggZ3JpZCBnYXAtNiBsZzpncmlkLWNvbHMtMlwiPlxuICAgICAgICAgIHtbXG4gICAgICAgICAgICB7IGhlYWRpbmc6IHQoXCJob21lLmlmTG9va2luZ1wiKSwgc3RlcHM6IFNFRUtFUl9TVEVQUywgYWNjZW50OiBcImJnLWFxdWEtNDAwXCIgfSxcbiAgICAgICAgICAgIHsgaGVhZGluZzogdChcImhvbWUuaWZPd25cIiksIHN0ZXBzOiBPV05FUl9TVEVQUywgYWNjZW50OiBcImJnLWNvcmFsXCIgfSxcbiAgICAgICAgICBdLm1hcCgoY29sKSA9PiAoXG4gICAgICAgICAgICA8ZGl2IGtleT17Y29sLmhlYWRpbmd9IGNsYXNzTmFtZT1cInJvdW5kZWQtY2FyZCBiZy1zdXJmYWNlIHAtNiByaW5nLTEgcmluZy1oYWlybGluZVwiPlxuICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgZm9udC1kaXNwbGF5IHRleHQtbGcgZm9udC1ib2xkIHRleHQtaW5rXCI+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtjbihcInNpemUtMiByb3VuZGVkLWZ1bGxcIiwgY29sLmFjY2VudCl9IGFyaWEtaGlkZGVuIC8+XG4gICAgICAgICAgICAgICAge2NvbC5oZWFkaW5nfVxuICAgICAgICAgICAgICA8L2gzPlxuICAgICAgICAgICAgICA8b2wgY2xhc3NOYW1lPVwibXQtNSBzcGFjZS15LTRcIj5cbiAgICAgICAgICAgICAgICB7Y29sLnN0ZXBzLm1hcCgoc3RlcEtleSwgaSkgPT4gKFxuICAgICAgICAgICAgICAgICAgPGxpIGtleT17c3RlcEtleX0gY2xhc3NOYW1lPVwiZmxleCBnYXAtMy41XCI+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm10LTAuNSBmbGV4IHNpemUtNiBzaHJpbmstMCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC1mdWxsIGJnLWl2b3J5LWRlZXAgdGV4dC14cyBmb250LWJvbGQgdG51bSB0ZXh0LWlua1wiPlxuICAgICAgICAgICAgICAgICAgICAgIHtpICsgMX1cbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1pbmtcIj57dChgJHtzdGVwS2V5fS50aXRsZWAgYXMgbmV2ZXIpfTwvcD5cbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0wLjUgdGV4dC1zbSBsZWFkaW5nLXJlbGF4ZWQgdGV4dC1tdXRlZFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAge3QoYCR7c3RlcEtleX0uYm9keWAgYXMgbmV2ZXIpfVxuICAgICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2xpPlxuICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICA8L29sPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKSl9XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTYgcm91bmRlZC1jYXJkIGJnLXN1cmZhY2UvNzAgcC01IHRleHQtc20gbGVhZGluZy1yZWxheGVkIHRleHQtaW5rLXNvZnQgcmluZy0xIHJpbmctaGFpcmxpbmUtc3Ryb25nXCI+XG4gICAgICAgICAgPHN0cm9uZyBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtaW5rXCI+QWJvdXQgdmVyaWZpY2F0aW9uLjwvc3Ryb25nPiBIYWJpdG8gZG9lcyBub3RcbiAgICAgICAgICB5ZXQgcGVyZm9ybSByZWFsIGlkZW50aXR5IG9yIG93bmVyc2hpcCBjaGVja3MuIFRydXN0IHN0YXRlcyBpbiB0aGlzIGJ1aWxkIGRlbW9uc3RyYXRlIHRoZVxuICAgICAgICAgIGludGVuZGVkIHdvcmtmbG93IG92ZXIgc3ludGhldGljIGRhdGEgYW5kIGFyZSBsYWJlbGxlZCBhcyBkZW1vIHRocm91Z2hvdXQuIE1hdGNoIHNjb3Jlc1xuICAgICAgICAgIGFyZSBhcml0aG1ldGljIG92ZXIgeW91ciBzdGF0ZWQgcmVxdWlyZW1lbnRzIOKAlCBubyBtYWNoaW5lIGxlYXJuaW5nIGlzIGludm9sdmVkLlxuICAgICAgICA8L3A+XG4gICAgICA8L2Rpdj5cbiAgICA8L3NlY3Rpb24+XG4gICk7XG59XG4iXSwiZmlsZSI6IkQ6L0kySSBQcm9qZWN0IC0gSGFiaXRvL0FwcCBGb2xkZXIvaGFiaXRvL3NyYy9wYWdlcy9Ib21lLnRzeCJ9