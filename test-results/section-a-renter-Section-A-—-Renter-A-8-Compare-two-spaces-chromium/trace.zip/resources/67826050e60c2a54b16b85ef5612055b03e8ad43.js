import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/@fs/D:\\I2I Project - Habito\\App Folder\\habito\\src\\pages\\ListSpace.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=9ceb86a3"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9ceb86a3"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import { Link, useNavigate, useParams } from "/node_modules/.vite/deps/react-router-dom.js?v=9ceb86a3";
import { ArrowLeft, ArrowRight, Check, Plus, Archive, Trash2, Undo2 } from "/node_modules/.vite/deps/lucide-react.js?v=9ceb86a3";
import { useHabito } from "/src/hooks/useHabito.tsx";
import { db } from "/src/lib/api/index.ts";
import { PageHeader } from "/src/components/layout/PageHeader.tsx";
import { Modal } from "/src/components/ui/Modal.tsx";
import { useToast } from "/src/components/ui/Toast.tsx";
import { Button } from "/src/components/ui/Button.tsx";
import { CATEGORY_STYLE, TYPES_BY_CATEGORY, AMENITIES, AMENITIES_BY_CATEGORY } from "/src/data/catalog.ts";
import { AREAS } from "/src/data/areas.ts";
import { AreaPicker } from "/src/components/ui/AreaPicker.tsx";
import { PinPicker } from "/src/components/space/PinPicker.tsx";
import { SPACE_TYPE_LABEL, CATEGORY_OF_TYPE } from "/src/types/space.ts";
import { PhotoUploader } from "/src/components/space/PhotoUploader.tsx";
import { money } from "/src/lib/format.ts";
import { cn } from "/src/lib/cn.ts";
import { useI18n } from "/src/i18n/index.tsx";
const CATEGORIES = Object.keys(CATEGORY_STYLE);
const STEPS = ["What", "Where", "Details", "Included", "Photos", "Price", "Review"];
export default function ListSpace() {
  _s();
  const navigate = useNavigate();
  const { id: editingId } = useParams();
  const { t } = useI18n();
  const { notify } = useToast();
  const { refresh, ownerId } = useHabito();
  const editing = Boolean(editingId);
  const [existing, setExisting] = useState(null);
  const [loaded, setLoaded] = useState(!editingId);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [working, setWorking] = useState(false);
  const [step, setStep] = useState(0);
  const [properties, setProperties] = useState([]);
  const [saving, setSaving] = useState(false);
  const [spaceType, setSpaceType] = useState("apartment");
  const [transaction, setTransaction] = useState("rent");
  const [propertyId, setPropertyId] = useState("");
  const [newPropertyName, setNewPropertyName] = useState("");
  const [area, setArea] = useState("Mirpur");
  const [neighborhood, setNeighborhood] = useState("");
  const [name, setName] = useState("");
  const [attrs, setAttrs] = useState({});
  const [amenities, setAmenities] = useState([]);
  const [rules, setRules] = useState({
    familyAllowed: true,
    bachelorAllowed: true,
    studentFriendly: true,
    genderPreference: "any",
    maxOccupants: null
  });
  const [photos, setPhotos] = useState([]);
  const [pin, setPin] = useState(null);
  const [fee, setFee] = useState(null);
  const [allowance, setAllowance] = useState(null);
  const [paying, setPaying] = useState(false);
  const [photosTouched, setPhotosTouched] = useState(false);
  const [draftId] = useState(() => crypto.randomUUID());
  const [price, setPrice] = useState(12e3);
  const [serviceCharge, setServiceCharge] = useState("");
  const [utilities, setUtilities] = useState("");
  const [status, setStatus] = useState("available");
  const [availableFrom, setAvailableFrom] = useState((/* @__PURE__ */ new Date()).toISOString().slice(0, 10));
  const category = CATEGORY_OF_TYPE[spaceType];
  const selectedArea = AREAS.find((a) => a.name === area);
  useEffect(() => {
    void db.listingFee(category).then(setFee);
  }, [category]);
  useEffect(() => {
    if (propertyId === "new") {
      setAllowance({ used: 0, hasPlan: false });
      return;
    }
    void db.listingAllowance(propertyId).then(setAllowance);
  }, [propertyId]);
  useEffect(() => {
    if (!editingId) return;
    void db.space(editingId).then((space) => {
      if (space) {
        setExisting(space);
        setSpaceType(space.spaceType);
        setTransaction(space.transaction);
        setPropertyId(space.propertyId);
        setName(space.name);
        setAttrs(space.attributes);
        setAmenities(space.amenities);
        if (space.rules) setRules(space.rules);
        setPhotos(space.synthetic ? [] : space.images);
        setPrice(space.cost.price);
        setServiceCharge(space.cost.serviceCharge ?? "");
        setUtilities(space.cost.utilities ?? "");
        setStatus(space.availability.status);
        setAvailableFrom(space.availability.availableFrom);
      }
      setLoaded(true);
    });
  }, [editingId]);
  useEffect(() => {
    void db.properties(ownerId).then((p) => {
      setProperties(p);
      if (p.length && !propertyId) setPropertyId(p[0].id);
    });
  }, [ownerId]);
  useEffect(() => {
    if (editing) return;
    setAttrs({});
    setAmenities([]);
  }, [category, editing]);
  const setAttr = (k, v) => setAttrs((a) => ({ ...a, [k]: v }));
  const setListingStatus = async (next) => {
    if (!existing) return;
    setWorking(true);
    await db.updateSpace(existing.id, { status: next });
    await refresh();
    setWorking(false);
    notify(next === "archived" ? t("edit.archived") : t("edit.restored"));
    navigate("/portfolio");
  };
  const destroy = async () => {
    if (!existing) return;
    setWorking(true);
    await db.deleteSpace(existing.id);
    await refresh();
    setWorking(false);
    notify(t("edit.deleted"));
    navigate("/portfolio");
  };
  const saveEdit = async () => {
    if (!existing) return;
    setSaving(true);
    const disclosed = serviceCharge !== "" && utilities !== "";
    await db.updateSpace(existing.id, {
      name: name.trim() || SPACE_TYPE_LABEL[spaceType],
      transaction,
      cost: {
        price,
        serviceCharge: serviceCharge === "" ? null : Number(serviceCharge),
        utilities: utilities === "" ? null : Number(utilities),
        securityDeposit: existing.cost.securityDeposit,
        advanceMonths: existing.cost.advanceMonths,
        estimatedMonthly: disclosed ? price + Number(serviceCharge) + Number(utilities) : null
      },
      attributes: attrs,
      amenities,
      rules,
      availability: { ...existing.availability, status, availableFrom },
      // An owner who removed every photo meant to remove them. Fall back to the
      // illustration rather than quietly restoring what they deleted.
      images: photosTouched ? photos.length ? photos : placeholderImages(category, name || SPACE_TYPE_LABEL[spaceType]) : existing.images
    });
    await refresh();
    setSaving(false);
    notify(t("edit.saved"));
    navigate(`/space/${existing.id}`);
  };
  const publish = async () => {
    setSaving(true);
    const areaMeta = AREAS.find((a) => a.name === area);
    let targetId = propertyId;
    if (propertyId === "__new") {
      const created2 = await db.createProperty({
        name: newPropertyName.trim() || `${area} property`,
        ownerId,
        area,
        neighborhood: neighborhood.trim() || area,
        address: `${neighborhood.trim() || area}, ${area}`,
        district: areaMeta.district,
        geography: areaMeta.geography,
        latitude: pin ? pin[0] : areaMeta.latitude,
        locationSource: pin ? "pinned" : "area",
        longitude: pin ? pin[1] : areaMeta.longitude,
        nearby: [],
        coverImage: `/photos/${category === "land" ? "land-1" : "living-1"}.svg`
      });
      targetId = created2.id;
    }
    const disclosed = serviceCharge !== "" && utilities !== "";
    const label = ["Exterior", "Interior", "Detail"];
    const created = await db.createSpace({
      propertyId: targetId,
      name: name.trim() || SPACE_TYPE_LABEL[spaceType],
      category,
      spaceType,
      transaction,
      cost: {
        price,
        serviceCharge: serviceCharge === "" ? null : Number(serviceCharge),
        utilities: utilities === "" ? null : Number(utilities),
        securityDeposit: null,
        advanceMonths: transaction === "rent" ? 2 : null,
        estimatedMonthly: disclosed ? price + Number(serviceCharge) + Number(utilities) : null
      },
      attributes: attrs,
      amenities,
      rules,
      availability: { status, availableFrom },
      // Real photographs where the owner gave them; illustration otherwise, so
      // a listing never looks photographed when it isn't.
      images: photos.length ? photos : [0, 1].map((i) => ({
        url: `/photos/${category}-${i % 2 + 1}.svg`,
        label: label[i],
        alt: `Illustrative placeholder image for ${name || SPACE_TYPE_LABEL[spaceType]}`,
        demo: true
      })),
      description: `${SPACE_TYPE_LABEL[spaceType]} in ${neighborhood.trim() || area}. Added through the Habito listing flow.`,
      verification: { demo: true, owner: "identity-submitted", space: "documents-submitted" },
      status: "published",
      lastUpdated: (/* @__PURE__ */ new Date()).toISOString().slice(0, 10)
    });
    await refresh();
    setSaving(false);
    navigate(`/space/${created.id}`);
  };
  const canAdvance = () => {
    if (step === 1) return propertyId !== "" && (propertyId !== "__new" || newPropertyName.trim().length > 1);
    if (step === 5) return price > 0;
    return true;
  };
  if (!loaded) {
    return /* @__PURE__ */ jsxDEV("div", { className: "container-page py-20 text-sm text-muted", children: t("misc.loading") }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
      lineNumber: 302,
      columnNumber: 12
    }, this);
  }
  if (editing && !existing) {
    return /* @__PURE__ */ jsxDEV("div", { className: "container-page py-20 text-center", children: [
      /* @__PURE__ */ jsxDEV("h1", { className: "font-display text-2xl font-bold text-ink", children: t("space.notFound") }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
        lineNumber: 308,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Link, { to: "/portfolio", className: "mt-5 inline-block", children: /* @__PURE__ */ jsxDEV(Button, { children: t("nav.portfolio") }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
        lineNumber: 310,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
        lineNumber: 309,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
      lineNumber: 307,
      columnNumber: 7
    }, this);
  }
  const archived = existing?.status === "archived";
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(
      PageHeader,
      {
        title: editing ? t("edit.title") : t("list.title"),
        lead: editing ? t("edit.lead") : t("list.lead"),
        actions: editing ? /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-2", children: [
          /* @__PURE__ */ jsxDEV(
            Button,
            {
              variant: "secondary",
              size: "sm",
              disabled: working,
              onClick: () => void setListingStatus(archived ? "published" : "archived"),
              children: [
                archived ? /* @__PURE__ */ jsxDEV(Undo2, { size: 15, "aria-hidden": true }, void 0, false, {
                  fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
                  lineNumber: 332,
                  columnNumber: 29
                }, this) : /* @__PURE__ */ jsxDEV(Archive, { size: 15, "aria-hidden": true }, void 0, false, {
                  fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
                  lineNumber: 332,
                  columnNumber: 63
                }, this),
                archived ? t("edit.restore") : t("edit.archive")
              ]
            },
            void 0,
            true,
            {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
              lineNumber: 326,
              columnNumber: 15
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(Button, { variant: "secondary", size: "sm", onClick: () => setConfirmDelete(true), children: [
            /* @__PURE__ */ jsxDEV(Trash2, { size: 15, "aria-hidden": true }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
              lineNumber: 336,
              columnNumber: 17
            }, this),
            t("edit.delete")
          ] }, void 0, true, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
            lineNumber: 335,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
          lineNumber: 325,
          columnNumber: 9
        }, this) : void 0
      },
      void 0,
      false,
      {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
        lineNumber: 320,
        columnNumber: 7
      },
      this
    ),
    archived && /* @__PURE__ */ jsxDEV("div", { className: "container-page pt-6", children: /* @__PURE__ */ jsxDEV("p", { className: "rounded-card bg-warn-100 p-4 text-sm leading-relaxed text-warn-700", children: t("edit.archivedNotice") }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
      lineNumber: 346,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
      lineNumber: 345,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "container-page max-w-3xl py-8 md:py-10", children: [
      /* @__PURE__ */ jsxDEV("ol", { className: "mb-8 flex items-center gap-1.5", "aria-label": "Progress", children: STEPS.map(
        (label, i) => /* @__PURE__ */ jsxDEV("li", { className: "flex flex-1 items-center gap-1.5", children: /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: [
          /* @__PURE__ */ jsxDEV(
            "div",
            {
              className: cn(
                "h-1 rounded-full transition-colors",
                i < step ? "bg-ink" : i === step ? "bg-aqua-400" : "bg-hairline"
              )
            },
            void 0,
            false,
            {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
              lineNumber: 358,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "span",
            {
              className: cn(
                "mt-1.5 hidden text-xs font-semibold sm:block",
                i === step ? "text-ink" : "text-muted"
              ),
              children: label
            },
            void 0,
            false,
            {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
              lineNumber: 364,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
          lineNumber: 357,
          columnNumber: 15
        }, this) }, label, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
          lineNumber: 356,
          columnNumber: 11
        }, this)
      ) }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
        lineNumber: 354,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "rounded-card bg-surface p-5 ring-1 ring-hairline sm:p-7", children: [
        step === 0 && /* @__PURE__ */ jsxDEV(Step, { title: t("list.whatOffering"), children: [
          /* @__PURE__ */ jsxDEV("ul", { className: "flex flex-wrap gap-2", children: CATEGORIES.flatMap((c) => TYPES_BY_CATEGORY[c]).map(
            (t2) => /* @__PURE__ */ jsxDEV("li", { children: /* @__PURE__ */ jsxDEV(Chip, { active: spaceType === t2, onClick: () => setSpaceType(t2), children: SPACE_TYPE_LABEL[t2] }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
              lineNumber: 383,
              columnNumber: 21
            }, this) }, t2, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
              lineNumber: 382,
              columnNumber: 15
            }, this)
          ) }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
            lineNumber: 380,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "mb-2 mt-6 text-sm font-medium text-ink-soft", children: "Renting it out, or selling?" }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
            lineNumber: 390,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "inline-flex rounded-full bg-ivory-deep p-0.5", children: ["rent", "sale"].map(
            (t2) => /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                "aria-pressed": transaction === t2,
                onClick: () => setTransaction(t2),
                className: cn(
                  "rounded-full px-5 py-2 text-sm font-bold transition-colors",
                  transaction === t2 ? "bg-ink text-ivory" : "text-muted hover:text-ink"
                ),
                children: t2 === "rent" ? "Renting" : "Selling"
              },
              t2,
              false,
              {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
                lineNumber: 393,
                columnNumber: 15
              },
              this
            )
          ) }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
            lineNumber: 391,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
          lineNumber: 379,
          columnNumber: 11
        }, this),
        step === 1 && /* @__PURE__ */ jsxDEV(Step, { title: t("list.whereIsIt"), children: [
          /* @__PURE__ */ jsxDEV("p", { className: "mb-2 text-sm font-medium text-ink-soft", children: "Which property is this space in?" }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
            lineNumber: 412,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
            properties.map(
              (p) => /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: cn(
                    "flex cursor-pointer items-center gap-3 rounded-2xl p-3 ring-1 transition-colors",
                    propertyId === p.id ? "bg-aqua-50 ring-aqua-600" : "bg-ivory ring-hairline hover:ring-hairline-strong"
                  ),
                  children: [
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        type: "radio",
                        name: "property",
                        checked: propertyId === p.id,
                        onChange: () => setPropertyId(p.id),
                        className: "accent-aqua-600"
                      },
                      void 0,
                      false,
                      {
                        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
                        lineNumber: 422,
                        columnNumber: 21
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV("img", { src: p.coverImage, alt: "", className: "size-10 rounded-lg object-cover" }, void 0, false, {
                      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
                      lineNumber: 429,
                      columnNumber: 21
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "min-w-0", children: [
                      /* @__PURE__ */ jsxDEV("p", { className: "truncate font-semibold text-ink", children: p.name }, void 0, false, {
                        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
                        lineNumber: 431,
                        columnNumber: 23
                      }, this),
                      /* @__PURE__ */ jsxDEV("p", { className: "truncate text-xs text-muted", children: [
                        p.neighborhood,
                        ", ",
                        p.area
                      ] }, void 0, true, {
                        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
                        lineNumber: 432,
                        columnNumber: 23
                      }, this)
                    ] }, void 0, true, {
                      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
                      lineNumber: 430,
                      columnNumber: 21
                    }, this)
                  ]
                },
                p.id,
                true,
                {
                  fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
                  lineNumber: 415,
                  columnNumber: 15
                },
                this
              )
            ),
            /* @__PURE__ */ jsxDEV(
              "label",
              {
                className: cn(
                  "flex cursor-pointer items-center gap-3 rounded-2xl p-3 ring-1 transition-colors",
                  propertyId === "__new" ? "bg-aqua-50 ring-aqua-600" : "bg-ivory ring-hairline hover:ring-hairline-strong"
                ),
                children: [
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      type: "radio",
                      name: "property",
                      checked: propertyId === "__new",
                      onChange: () => setPropertyId("__new"),
                      className: "accent-aqua-600"
                    },
                    void 0,
                    false,
                    {
                      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
                      lineNumber: 445,
                      columnNumber: 19
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV("span", { className: "flex size-10 items-center justify-center rounded-lg bg-ivory-deep text-muted", children: /* @__PURE__ */ jsxDEV(Plus, { size: 17, "aria-hidden": true }, void 0, false, {
                    fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
                    lineNumber: 453,
                    columnNumber: 21
                  }, this) }, void 0, false, {
                    fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
                    lineNumber: 452,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-ink", children: "A new property" }, void 0, false, {
                    fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
                    lineNumber: 455,
                    columnNumber: 19
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
                lineNumber: 439,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
            lineNumber: 413,
            columnNumber: 15
          }, this),
          propertyId === "__new" && /* @__PURE__ */ jsxDEV("div", { className: "mt-5 grid gap-4 sm:grid-cols-2", children: [
            /* @__PURE__ */ jsxDEV(Field, { label: "Property name", children: /* @__PURE__ */ jsxDEV(
              "input",
              {
                value: newPropertyName,
                onChange: (e) => setNewPropertyName(e.target.value),
                placeholder: "e.g. Rahman Villa",
                className: inputClass
              },
              void 0,
              false,
              {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
                lineNumber: 462,
                columnNumber: 21
              },
              this
            ) }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
              lineNumber: 461,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(Field, { label: t("filter.area"), children: /* @__PURE__ */ jsxDEV(AreaPicker, { value: area, onChange: setArea }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
              lineNumber: 470,
              columnNumber: 21
            }, this) }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
              lineNumber: 469,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(Field, { label: t("list.neighbourhood"), children: /* @__PURE__ */ jsxDEV(
              "input",
              {
                value: neighborhood,
                onChange: (e) => setNeighborhood(e.target.value),
                placeholder: "e.g. Mirpur 10",
                className: inputClass
              },
              void 0,
              false,
              {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
                lineNumber: 473,
                columnNumber: 21
              },
              this
            ) }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
              lineNumber: 472,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
            lineNumber: 460,
            columnNumber: 13
          }, this),
          propertyId === "new" && selectedArea && /* @__PURE__ */ jsxDEV("div", { className: "mt-7 border-t border-hairline pt-6", children: [
            /* @__PURE__ */ jsxDEV("h3", { className: "mb-1 font-display font-bold text-ink", children: t("map.pinTitle") }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
              lineNumber: 486,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "mb-4 text-sm leading-relaxed text-muted", children: t("map.pinBody") }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
              lineNumber: 487,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              PinPicker,
              {
                centre: [selectedArea.latitude, selectedArea.longitude],
                value: pin,
                onChange: setPin
              },
              void 0,
              false,
              {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
                lineNumber: 488,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
            lineNumber: 485,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
          lineNumber: 411,
          columnNumber: 11
        }, this),
        step === 2 && /* @__PURE__ */ jsxDEV(Step, { title: `About this ${SPACE_TYPE_LABEL[spaceType].toLowerCase()}`, children: [
          /* @__PURE__ */ jsxDEV(Field, { label: "Name it", children: /* @__PURE__ */ jsxDEV(
            "input",
            {
              value: name,
              onChange: (e) => setName(e.target.value),
              placeholder: placeholderName(spaceType),
              className: inputClass
            },
            void 0,
            false,
            {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
              lineNumber: 501,
              columnNumber: 17
            },
            this
          ) }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
            lineNumber: 500,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "mt-4 grid gap-4 sm:grid-cols-2", children: fieldsFor(category).map(
            (f) => /* @__PURE__ */ jsxDEV(Field, { label: f.label, children: f.kind === "bool" ? /* @__PURE__ */ jsxDEV("label", { className: "flex h-11 items-center gap-2.5 rounded-xl bg-ivory px-3 text-sm ring-1 ring-hairline-strong", children: [
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "checkbox",
                  checked: Boolean(attrs[f.key]),
                  onChange: (e) => setAttr(f.key, e.target.checked),
                  className: "size-4 accent-aqua-600"
                },
                void 0,
                false,
                {
                  fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
                  lineNumber: 514,
                  columnNumber: 25
                },
                this
              ),
              "Yes"
            ] }, void 0, true, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
              lineNumber: 513,
              columnNumber: 17
            }, this) : f.kind === "text" ? /* @__PURE__ */ jsxDEV(
              "input",
              {
                value: attrs[f.key] ?? "",
                onChange: (e) => setAttr(f.key, e.target.value),
                placeholder: f.placeholder,
                className: inputClass
              },
              void 0,
              false,
              {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
                lineNumber: 523,
                columnNumber: 17
              },
              this
            ) : /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "number",
                inputMode: "numeric",
                min: 0,
                value: attrs[f.key] ?? "",
                onChange: (e) => setAttr(f.key, e.target.value === "" ? void 0 : Number(e.target.value)),
                placeholder: f.placeholder,
                className: cn(inputClass, "tnum")
              },
              void 0,
              false,
              {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
                lineNumber: 530,
                columnNumber: 17
              },
              this
            ) }, f.key, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
              lineNumber: 511,
              columnNumber: 15
            }, this)
          ) }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
            lineNumber: 509,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
          lineNumber: 499,
          columnNumber: 11
        }, this),
        step === 3 && /* @__PURE__ */ jsxDEV(Step, { title: t("list.whatIncluded"), children: [
          /* @__PURE__ */ jsxDEV("ul", { className: "flex flex-wrap gap-2", children: AMENITIES_BY_CATEGORY[category].map((key) => {
            const { label, icon: Icon } = AMENITIES[key];
            const on = amenities.includes(key);
            return /* @__PURE__ */ jsxDEV("li", { children: /* @__PURE__ */ jsxDEV(
              Chip,
              {
                active: on,
                onClick: () => setAmenities(on ? amenities.filter((a) => a !== key) : [...amenities, key]),
                children: [
                  /* @__PURE__ */ jsxDEV(Icon, { size: 14, "aria-hidden": true }, void 0, false, {
                    fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
                    lineNumber: 560,
                    columnNumber: 25
                  }, this),
                  label
                ]
              },
              void 0,
              true,
              {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
                lineNumber: 554,
                columnNumber: 23
              },
              this
            ) }, key, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
              lineNumber: 553,
              columnNumber: 19
            }, this);
          }) }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
            lineNumber: 548,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "mt-4 text-xs text-muted", children: [
            "Only the options that make sense for a ",
            SPACE_TYPE_LABEL[spaceType].toLowerCase(),
            " are shown."
          ] }, void 0, true, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
            lineNumber: 567,
            columnNumber: 15
          }, this),
          category === "living" && /* @__PURE__ */ jsxDEV("div", { className: "mt-7 border-t border-hairline pt-6", children: [
            /* @__PURE__ */ jsxDEV("h3", { className: "mb-1 font-display font-bold text-ink", children: t("rules.title") }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
              lineNumber: 573,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "mb-4 text-xs text-muted", children: "This is the first thing most renters filter on, so it's worth getting right." }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
              lineNumber: 574,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("ul", { className: "flex flex-wrap gap-2", children: [
              /* @__PURE__ */ jsxDEV("li", { children: /* @__PURE__ */ jsxDEV(
                Chip,
                {
                  active: rules.familyAllowed,
                  onClick: () => setRules({ ...rules, familyAllowed: !rules.familyAllowed }),
                  children: t("filter.familyAllowed")
                },
                void 0,
                false,
                {
                  fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
                  lineNumber: 580,
                  columnNumber: 23
                },
                this
              ) }, void 0, false, {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
                lineNumber: 579,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("li", { children: /* @__PURE__ */ jsxDEV(
                Chip,
                {
                  active: rules.bachelorAllowed,
                  onClick: () => setRules({ ...rules, bachelorAllowed: !rules.bachelorAllowed }),
                  children: t("filter.bachelorAllowed")
                },
                void 0,
                false,
                {
                  fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
                  lineNumber: 588,
                  columnNumber: 23
                },
                this
              ) }, void 0, false, {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
                lineNumber: 587,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("li", { children: /* @__PURE__ */ jsxDEV(
                Chip,
                {
                  active: rules.studentFriendly,
                  onClick: () => setRules({ ...rules, studentFriendly: !rules.studentFriendly }),
                  children: t("filter.studentFriendly")
                },
                void 0,
                false,
                {
                  fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
                  lineNumber: 596,
                  columnNumber: 23
                },
                this
              ) }, void 0, false, {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
                lineNumber: 595,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
              lineNumber: 578,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mt-4 grid gap-4 sm:grid-cols-2", children: [
              /* @__PURE__ */ jsxDEV(Field, { label: "Gender preference", children: /* @__PURE__ */ jsxDEV(
                "select",
                {
                  value: rules.genderPreference,
                  onChange: (e) => setRules({ ...rules, genderPreference: e.target.value }),
                  className: inputClass,
                  children: [
                    /* @__PURE__ */ jsxDEV("option", { value: "any", children: "No preference" }, void 0, false, {
                      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
                      lineNumber: 614,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("option", { value: "male", children: "Men only" }, void 0, false, {
                      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
                      lineNumber: 615,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("option", { value: "female", children: "Women only" }, void 0, false, {
                      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
                      lineNumber: 616,
                      columnNumber: 25
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
                  lineNumber: 607,
                  columnNumber: 23
                },
                this
              ) }, void 0, false, {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
                lineNumber: 606,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(Field, { label: "Maximum occupants", children: /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "number",
                  min: 1,
                  value: rules.maxOccupants ?? "",
                  placeholder: "No limit",
                  onChange: (e) => setRules({
                    ...rules,
                    maxOccupants: e.target.value === "" ? null : Number(e.target.value)
                  }),
                  className: cn(inputClass, "tnum")
                },
                void 0,
                false,
                {
                  fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
                  lineNumber: 620,
                  columnNumber: 23
                },
                this
              ) }, void 0, false, {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
                lineNumber: 619,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
              lineNumber: 605,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
            lineNumber: 572,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
          lineNumber: 547,
          columnNumber: 11
        }, this),
        step === 4 && /* @__PURE__ */ jsxDEV(Step, { title: t("list.photos"), children: [
          /* @__PURE__ */ jsxDEV("p", { className: "mb-5 text-sm text-muted", children: t("list.photosLead") }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
            lineNumber: 642,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            PhotoUploader,
            {
              spaceId: draftId,
              images: photos,
              onChange: (next) => {
                setPhotosTouched(true);
                setPhotos(next);
              }
            },
            void 0,
            false,
            {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
              lineNumber: 643,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
          lineNumber: 641,
          columnNumber: 11
        }, this),
        step === 5 && /* @__PURE__ */ jsxDEV(Step, { title: t("list.priceAvailability"), children: [
          /* @__PURE__ */ jsxDEV("div", { className: "grid gap-4 sm:grid-cols-2", children: [
            /* @__PURE__ */ jsxDEV(Field, { label: transaction === "rent" ? "Monthly rent" : "Asking price", children: /* @__PURE__ */ jsxDEV(MoneyInput, { value: price, onChange: setPrice }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
              lineNumber: 658,
              columnNumber: 19
            }, this) }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
              lineNumber: 657,
              columnNumber: 17
            }, this),
            transaction === "rent" && /* @__PURE__ */ jsxDEV(Fragment, { children: [
              /* @__PURE__ */ jsxDEV(Field, { label: "Service charge", children: /* @__PURE__ */ jsxDEV(MoneyInput, { value: serviceCharge, onChange: setServiceCharge, allowEmpty: true }, void 0, false, {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
                lineNumber: 663,
                columnNumber: 23
              }, this) }, void 0, false, {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
                lineNumber: 662,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(Field, { label: "Utilities", children: /* @__PURE__ */ jsxDEV(MoneyInput, { value: utilities, onChange: setUtilities, allowEmpty: true }, void 0, false, {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
                lineNumber: 666,
                columnNumber: 23
              }, this) }, void 0, false, {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
                lineNumber: 665,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
              lineNumber: 661,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(Field, { label: "Status", children: /* @__PURE__ */ jsxDEV(
              "select",
              {
                value: status,
                onChange: (e) => setStatus(e.target.value),
                className: inputClass,
                children: [
                  /* @__PURE__ */ jsxDEV("option", { value: "available", children: "Available" }, void 0, false, {
                    fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
                    lineNumber: 676,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { value: "partially-available", children: "Partly available" }, void 0, false, {
                    fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
                    lineNumber: 677,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { value: "available-soon", children: "Available soon" }, void 0, false, {
                    fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
                    lineNumber: 678,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { value: "occupied", children: "Occupied" }, void 0, false, {
                    fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
                    lineNumber: 679,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { value: "maintenance", children: "Maintenance" }, void 0, false, {
                    fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
                    lineNumber: 680,
                    columnNumber: 21
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
                lineNumber: 671,
                columnNumber: 19
              },
              this
            ) }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
              lineNumber: 670,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(Field, { label: "Available from", children: /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "date",
                value: availableFrom,
                onChange: (e) => setAvailableFrom(e.target.value),
                className: inputClass
              },
              void 0,
              false,
              {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
                lineNumber: 684,
                columnNumber: 19
              },
              this
            ) }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
              lineNumber: 683,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
            lineNumber: 656,
            columnNumber: 15
          }, this),
          transaction === "rent" && /* @__PURE__ */ jsxDEV("p", { className: "mt-4 rounded-xl bg-aqua-50 p-3 text-xs leading-relaxed text-aqua-700", children: 'Listing every cost gets your space a total-cost figure on the card and lets it pass the "full cost disclosed" filter. Leaving them blank does the opposite.' }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
            lineNumber: 694,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
          lineNumber: 655,
          columnNumber: 11
        }, this),
        step === 6 && /* @__PURE__ */ jsxDEV(Step, { title: t("list.review"), children: [
          !editing && fee !== null && allowance !== null && /* @__PURE__ */ jsxDEV("div", { className: "mb-5 rounded-card bg-aqua-50 p-4 ring-1 ring-aqua-200", children: [
            allowance.used < 3 || allowance.hasPlan ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
              /* @__PURE__ */ jsxDEV("p", { className: "font-display font-bold text-aqua-700", children: t("fee.title") }, void 0, false, {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
                lineNumber: 710,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm leading-relaxed text-ink-soft", children: t("fee.body") }, void 0, false, {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
                lineNumber: 711,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "mt-3 flex flex-wrap items-baseline justify-between gap-2", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-muted", children: t("fee.amount") }, void 0, false, {
                  fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
                  lineNumber: 713,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "font-display text-xl font-extrabold tnum text-ink", children: money(fee) }, void 0, false, {
                  fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
                  lineNumber: 714,
                  columnNumber: 25
                }, this)
              ] }, void 0, true, {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
                lineNumber: 712,
                columnNumber: 23
              }, this),
              !allowance.hasPlan && /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-xs text-muted", children: t("fee.free", { used: allowance.used + 1 }) }, void 0, false, {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
                lineNumber: 719,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
              lineNumber: 709,
              columnNumber: 15
            }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
              /* @__PURE__ */ jsxDEV("p", { className: "font-display font-bold text-warn-700", children: t("fee.allowanceUsed") }, void 0, false, {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
                lineNumber: 726,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm leading-relaxed text-ink-soft", children: t("fee.allowanceBody") }, void 0, false, {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
                lineNumber: 729,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "mt-2 font-semibold tnum text-ink", children: t("fee.planPrice") }, void 0, false, {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
                lineNumber: 732,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV(
                Button,
                {
                  size: "sm",
                  variant: "secondary",
                  className: "mt-3",
                  disabled: paying,
                  onClick: async () => {
                    setPaying(true);
                    try {
                      await db.buyPropertyPlan(propertyId, 5e3);
                      setAllowance(await db.listingAllowance(propertyId));
                      notify(t("fee.paid"));
                    } finally {
                      setPaying(false);
                    }
                  },
                  children: t("fee.buyPlan")
                },
                void 0,
                false,
                {
                  fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
                  lineNumber: 733,
                  columnNumber: 23
                },
                this
              )
            ] }, void 0, true, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
              lineNumber: 725,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "mt-3 text-xs leading-relaxed text-warn-700", children: t("fee.sandbox") }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
              lineNumber: 754,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
            lineNumber: 707,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("dl", { className: "divide-y divide-hairline rounded-2xl bg-ivory ring-1 ring-hairline", children: [
            /* @__PURE__ */ jsxDEV(Review, { label: "Space", value: `${name || SPACE_TYPE_LABEL[spaceType]} · ${SPACE_TYPE_LABEL[spaceType]}` }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
              lineNumber: 759,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(
              Review,
              {
                label: "Property",
                value: propertyId === "__new" ? `${newPropertyName || "New property"} (new) · ${area}` : properties.find((p) => p.id === propertyId)?.name ?? "—"
              },
              void 0,
              false,
              {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
                lineNumber: 760,
                columnNumber: 17
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Review,
              {
                label: transaction === "rent" ? "Rent" : "Price",
                value: money(price) + (transaction === "rent" && serviceCharge !== "" && utilities !== "" ? ` · about ${money(price + Number(serviceCharge) + Number(utilities))} all in` : "")
              },
              void 0,
              false,
              {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
                lineNumber: 768,
                columnNumber: 17
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(Review, { label: "Availability", value: status.replace("-", " ") }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
              lineNumber: 777,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(Review, { label: "Included", value: amenities.length ? amenities.map((a) => t(`amenity.${a}`)).join(", ") : "Nothing listed" }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
              lineNumber: 778,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
            lineNumber: 758,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "mt-4 text-xs leading-relaxed text-muted", children: "Placeholder images are attached automatically in this prototype. The space is saved on this device and appears immediately in search and in your portfolio." }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
            lineNumber: 781,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
          lineNumber: 703,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-8 flex items-center gap-3 border-t border-hairline pt-5", children: [
          step > 0 && /* @__PURE__ */ jsxDEV(Button, { variant: "secondary", onClick: () => setStep((s) => s - 1), children: [
            /* @__PURE__ */ jsxDEV(ArrowLeft, { size: 16, "aria-hidden": true }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
              lineNumber: 792,
              columnNumber: 17
            }, this),
            "Back"
          ] }, void 0, true, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
            lineNumber: 791,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "ml-auto text-xs tnum text-muted", children: [
            "Step ",
            step + 1,
            " of ",
            STEPS.length
          ] }, void 0, true, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
            lineNumber: 796,
            columnNumber: 13
          }, this),
          step < STEPS.length - 1 ? /* @__PURE__ */ jsxDEV(Button, { disabled: !canAdvance(), onClick: () => setStep((s) => s + 1), children: [
            "Continue",
            /* @__PURE__ */ jsxDEV(ArrowRight, { size: 16, "aria-hidden": true }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
              lineNumber: 802,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
            lineNumber: 800,
            columnNumber: 13
          }, this) : /* @__PURE__ */ jsxDEV(Button, { disabled: saving, onClick: () => void (editing ? saveEdit() : publish()), children: [
            /* @__PURE__ */ jsxDEV(Check, { size: 16, "aria-hidden": true }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
              lineNumber: 806,
              columnNumber: 17
            }, this),
            saving ? t("action.publishing") : editing ? t("action.saveChanges") : !editing && fee !== null && allowance !== null && allowance.used < 3 ? t("fee.pay") : t("action.publish")
          ] }, void 0, true, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
            lineNumber: 805,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
          lineNumber: 789,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
        lineNumber: 377,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
      lineNumber: 352,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        open: confirmDelete,
        onClose: () => setConfirmDelete(false),
        title: t("edit.deleteTitle"),
        footer: /* @__PURE__ */ jsxDEV("div", { className: "flex gap-2", children: [
          /* @__PURE__ */ jsxDEV(Button, { variant: "secondary", fullWidth: true, onClick: () => setConfirmDelete(false), children: t("action.cancel") }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
            lineNumber: 826,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(Button, { variant: "destructive", fullWidth: true, disabled: working, onClick: () => void destroy(), children: t("edit.delete") }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
            lineNumber: 829,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
          lineNumber: 825,
          columnNumber: 9
        }, this),
        children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-sm leading-relaxed text-ink-soft", children: t("edit.deleteBody") }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
            lineNumber: 835,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "mt-3 rounded-xl bg-warn-100 p-3 text-sm leading-relaxed text-warn-700", children: t("edit.deleteWarning") }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
            lineNumber: 836,
            columnNumber: 9
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
        lineNumber: 820,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
    lineNumber: 319,
    columnNumber: 5
  }, this);
}
_s(ListSpace, "P/k5OSh5HqnScYHeoCSAixuqI7s=", false, function() {
  return [useNavigate, useParams, useI18n, useToast, useHabito];
});
_c = ListSpace;
function placeholderImages(category, label) {
  return [0, 1].map((i) => ({
    url: `/photos/${category}-${i % 2 + 1}.svg`,
    label: i === 0 ? "Main" : "Second view",
    alt: `Illustrative placeholder image for ${label}`,
    demo: true
  }));
}
function fieldsFor(category) {
  switch (category) {
    case "living":
      return [
        { key: "bedrooms", label: "Bedrooms", kind: "number", placeholder: "2" },
        { key: "bathrooms", label: "Bathrooms", kind: "number", placeholder: "2" },
        { key: "sizeSqft", label: "Size (sqft)", kind: "number", placeholder: "950" },
        { key: "floor", label: "Floor", kind: "number", placeholder: "3" },
        { key: "balcony", label: "Balcony", kind: "bool" },
        { key: "kitchen", label: "Kitchen", kind: "bool" }
      ];
    case "business":
      return [
        { key: "sizeSqft", label: "Size (sqft)", kind: "number", placeholder: "400" },
        { key: "floor", label: "Floor", kind: "number", placeholder: "0 for ground" },
        { key: "frontageFt", label: "Frontage (ft)", kind: "number", placeholder: "14" },
        { key: "workstations", label: "Workstations", kind: "number", placeholder: "12" },
        { key: "meetingRoom", label: "Meeting room", kind: "bool" },
        { key: "suitableFor", label: "Suits which business", kind: "text", placeholder: "Pharmacy" }
      ];
    case "storage":
      return [
        { key: "sizeSqft", label: "Storage area (sqft)", kind: "number", placeholder: "1200" },
        { key: "ceilingHeightFt", label: "Ceiling height (ft)", kind: "number", placeholder: "14" },
        { key: "loadingAccess", label: "Loading access", kind: "bool" },
        { key: "vehicleAccess", label: "Truck access", kind: "bool" },
        { key: "suitableFor", label: "Suitable goods", kind: "text", placeholder: "Dry goods" }
      ];
    case "parking":
      return [
        { key: "carSlots", label: "Car slots", kind: "number", placeholder: "2" },
        { key: "motorcycleSlots", label: "Motorcycle slots", kind: "number", placeholder: "4" },
        { key: "covered", label: "Covered", kind: "bool" },
        { key: "accessHours", label: "Access hours", kind: "text", placeholder: "24 hours" }
      ];
    case "land":
      return [
        { key: "landAreaDecimal", label: "Land area (decimal)", kind: "number", placeholder: "35" },
        { key: "landUse", label: "Land use", kind: "text", placeholder: "Paddy" },
        { key: "roadAccess", label: "Road access", kind: "bool" },
        { key: "waterSource", label: "Water source", kind: "bool" },
        { key: "leaseYears", label: "Lease length (years)", kind: "number", placeholder: "3" }
      ];
  }
}
function placeholderName(type) {
  switch (type) {
    case "apartment":
      return "Flat 3A";
    case "shop":
      return "Shop 01";
    case "godown":
      return "Godown 01";
    case "garage":
      return "Garage";
    case "office":
      return "Second floor office";
    case "farmland":
      return "North plot";
    default:
      return SPACE_TYPE_LABEL[type];
  }
}
const inputClass = "h-11 w-full rounded-xl bg-ivory px-3 text-[0.9375rem] text-ink ring-1 ring-hairline-strong focus:outline-none focus:ring-2 focus:ring-aqua-600";
function Step({ title, children }) {
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("h2", { className: "mb-5 font-display text-xl font-bold text-ink", children: title }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
      lineNumber: 929,
      columnNumber: 7
    }, this),
    children
  ] }, void 0, true, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
    lineNumber: 928,
    columnNumber: 5
  }, this);
}
_c2 = Step;
function Field({ label, children }) {
  return /* @__PURE__ */ jsxDEV("label", { className: "block", children: [
    /* @__PURE__ */ jsxDEV("span", { className: "mb-1.5 block text-sm font-medium text-ink-soft", children: label }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
      lineNumber: 938,
      columnNumber: 7
    }, this),
    children
  ] }, void 0, true, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
    lineNumber: 937,
    columnNumber: 5
  }, this);
}
_c3 = Field;
function Chip({ active, onClick, children }) {
  return /* @__PURE__ */ jsxDEV(
    "button",
    {
      type: "button",
      "aria-pressed": active,
      onClick,
      className: cn(
        "inline-flex items-center gap-1.5 rounded-full px-3.5 py-2 text-sm font-semibold transition-colors",
        active ? "bg-ink text-ivory" : "bg-ivory-deep text-ink-soft hover:bg-hairline"
      ),
      children
    },
    void 0,
    false,
    {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
      lineNumber: 946,
      columnNumber: 5
    },
    this
  );
}
_c4 = Chip;
function MoneyInput({
  value,
  onChange,
  allowEmpty
}) {
  return /* @__PURE__ */ jsxDEV("div", { className: "relative", children: [
    /* @__PURE__ */ jsxDEV("span", { className: "pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-muted", children: "৳" }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
      lineNumber: 971,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      "input",
      {
        type: "number",
        inputMode: "numeric",
        step: 500,
        min: 0,
        value,
        placeholder: allowEmpty ? "Not listed" : void 0,
        onChange: (e) => onChange(e.target.value === "" ? "" : Number(e.target.value)),
        className: cn(inputClass, "pl-7 tnum")
      },
      void 0,
      false,
      {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
        lineNumber: 972,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
    lineNumber: 970,
    columnNumber: 5
  }, this);
}
_c5 = MoneyInput;
function Review({ label, value }) {
  return /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-baseline justify-between gap-2 px-4 py-3", children: [
    /* @__PURE__ */ jsxDEV("dt", { className: "text-sm text-muted", children: label }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
      lineNumber: 989,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("dd", { className: "text-sm font-semibold text-ink", children: value }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
      lineNumber: 990,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx",
    lineNumber: 988,
    columnNumber: 5
  }, this);
}
_c6 = Review;
var _c, _c2, _c3, _c4, _c5, _c6;
$RefreshReg$(_c, "ListSpace");
$RefreshReg$(_c2, "Step");
$RefreshReg$(_c3, "Field");
$RefreshReg$(_c4, "Chip");
$RefreshReg$(_c5, "MoneyInput");
$RefreshReg$(_c6, "Review");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/I2I Project - Habito/App Folder/habito/src/pages/ListSpace.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMFJXLFNBdVdPLFVBdldQOzs7Ozs7Ozs7Ozs7Ozs7OztBQTFSWCxTQUFTQSxXQUFXQyxnQkFBZ0I7QUFDcEMsU0FBU0MsTUFBTUMsYUFBYUMsaUJBQWlCO0FBQzdDLFNBQVNDLFdBQVdDLFlBQVlDLE9BQU9DLE1BQU1DLFNBQVNDLFFBQVFDLGFBQWE7QUFDM0UsU0FBU0MsaUJBQWlCO0FBQzFCLFNBQVNDLFVBQVU7QUFDbkIsU0FBU0Msa0JBQWtCO0FBQzNCLFNBQVNDLGFBQWE7QUFDdEIsU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLGNBQWM7QUFDdkIsU0FBU0MsZ0JBQWdCQyxtQkFBbUJDLFdBQVdDLDZCQUE2QjtBQUNwRixTQUFTQyxhQUFhO0FBQ3RCLFNBQVNDLGtCQUFrQjtBQUMzQixTQUFTQyxpQkFBaUI7QUFDMUIsU0FBU0Msa0JBQWtCQyx3QkFBd0I7QUFLbkQsU0FBU0MscUJBQXFCO0FBQzlCLFNBQVNDLGFBQWE7QUFDdEIsU0FBU0MsVUFBVTtBQUNuQixTQUFTQyxlQUFlO0FBRXhCLE1BQU1DLGFBQWFDLE9BQU9DLEtBQUtmLGNBQWM7QUFDN0MsTUFBTWdCLFFBQVEsQ0FBQyxRQUFRLFNBQVMsV0FBVyxZQUFZLFVBQVUsU0FBUyxRQUFRO0FBVWxGLHdCQUF3QkMsWUFBWTtBQUFBQyxLQUFBO0FBQ2xDLFFBQU1DLFdBQVdsQyxZQUFZO0FBQzdCLFFBQU0sRUFBRW1DLElBQUlDLFVBQVUsSUFBSW5DLFVBQVU7QUFDcEMsUUFBTSxFQUFFb0MsRUFBRSxJQUFJVixRQUFRO0FBQ3RCLFFBQU0sRUFBRVcsT0FBTyxJQUFJekIsU0FBUztBQUM1QixRQUFNLEVBQUUwQixTQUFTQyxRQUFRLElBQUkvQixVQUFVO0FBRXZDLFFBQU1nQyxVQUFVQyxRQUFRTixTQUFTO0FBQ2pDLFFBQU0sQ0FBQ08sVUFBVUMsV0FBVyxJQUFJOUMsU0FBdUIsSUFBSTtBQUMzRCxRQUFNLENBQUMrQyxRQUFRQyxTQUFTLElBQUloRCxTQUFTLENBQUNzQyxTQUFTO0FBQy9DLFFBQU0sQ0FBQ1csZUFBZUMsZ0JBQWdCLElBQUlsRCxTQUFTLEtBQUs7QUFDeEQsUUFBTSxDQUFDbUQsU0FBU0MsVUFBVSxJQUFJcEQsU0FBUyxLQUFLO0FBRTVDLFFBQU0sQ0FBQ3FELE1BQU1DLE9BQU8sSUFBSXRELFNBQVMsQ0FBQztBQUNsQyxRQUFNLENBQUN1RCxZQUFZQyxhQUFhLElBQUl4RCxTQUFxQixFQUFFO0FBQzNELFFBQU0sQ0FBQ3lELFFBQVFDLFNBQVMsSUFBSTFELFNBQVMsS0FBSztBQUUxQyxRQUFNLENBQUMyRCxXQUFXQyxZQUFZLElBQUk1RCxTQUFvQixXQUFXO0FBQ2pFLFFBQU0sQ0FBQzZELGFBQWFDLGNBQWMsSUFBSTlELFNBQTBCLE1BQU07QUFDdEUsUUFBTSxDQUFDK0QsWUFBWUMsYUFBYSxJQUFJaEUsU0FBaUIsRUFBRTtBQUN2RCxRQUFNLENBQUNpRSxpQkFBaUJDLGtCQUFrQixJQUFJbEUsU0FBUyxFQUFFO0FBQ3pELFFBQU0sQ0FBQ21FLE1BQU1DLE9BQU8sSUFBSXBFLFNBQVMsUUFBUTtBQUN6QyxRQUFNLENBQUNxRSxjQUFjQyxlQUFlLElBQUl0RSxTQUFTLEVBQUU7QUFDbkQsUUFBTSxDQUFDdUUsTUFBTUMsT0FBTyxJQUFJeEUsU0FBUyxFQUFFO0FBQ25DLFFBQU0sQ0FBQ3lFLE9BQU9DLFFBQVEsSUFBSTFFLFNBQTBCLENBQUMsQ0FBQztBQUN0RCxRQUFNLENBQUMyRSxXQUFXQyxZQUFZLElBQUk1RSxTQUF1QixFQUFFO0FBQzNELFFBQU0sQ0FBQzZFLE9BQU9DLFFBQVEsSUFBSTlFLFNBQXlCO0FBQUEsSUFDakQrRSxlQUFlO0FBQUEsSUFDZkMsaUJBQWlCO0FBQUEsSUFDakJDLGlCQUFpQjtBQUFBLElBQ2pCQyxrQkFBa0I7QUFBQSxJQUNsQkMsY0FBYztBQUFBLEVBQ2hCLENBQUM7QUFDRCxRQUFNLENBQUNDLFFBQVFDLFNBQVMsSUFBSXJGLFNBQXVCLEVBQUU7QUFFckQsUUFBTSxDQUFDc0YsS0FBS0MsTUFBTSxJQUFJdkYsU0FBa0MsSUFBSTtBQUM1RCxRQUFNLENBQUN3RixLQUFLQyxNQUFNLElBQUl6RixTQUF3QixJQUFJO0FBQ2xELFFBQU0sQ0FBQzBGLFdBQVdDLFlBQVksSUFBSTNGLFNBQW9ELElBQUk7QUFDMUYsUUFBTSxDQUFDNEYsUUFBUUMsU0FBUyxJQUFJN0YsU0FBUyxLQUFLO0FBSTFDLFFBQU0sQ0FBQzhGLGVBQWVDLGdCQUFnQixJQUFJL0YsU0FBUyxLQUFLO0FBRXhELFFBQU0sQ0FBQ2dHLE9BQU8sSUFBSWhHLFNBQVMsTUFBTWlHLE9BQU9DLFdBQVcsQ0FBQztBQUNwRCxRQUFNLENBQUNDLE9BQU9DLFFBQVEsSUFBSXBHLFNBQVMsSUFBSztBQUN4QyxRQUFNLENBQUNxRyxlQUFlQyxnQkFBZ0IsSUFBSXRHLFNBQXNCLEVBQUU7QUFDbEUsUUFBTSxDQUFDdUcsV0FBV0MsWUFBWSxJQUFJeEcsU0FBc0IsRUFBRTtBQUMxRCxRQUFNLENBQUN5RyxRQUFRQyxTQUFTLElBQUkxRyxTQUE2QixXQUFXO0FBQ3BFLFFBQU0sQ0FBQzJHLGVBQWVDLGdCQUFnQixJQUFJNUcsVUFBUyxvQkFBSTZHLEtBQUssR0FBRUMsWUFBWSxFQUFFQyxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBRXhGLFFBQU1DLFdBQVd2RixpQkFBaUJrQyxTQUFTO0FBRTNDLFFBQU1zRCxlQUFlNUYsTUFBTTZGLEtBQUssQ0FBQ0MsTUFBTUEsRUFBRTVDLFNBQVNKLElBQUk7QUFHdERwRSxZQUFVLE1BQU07QUFDZCxTQUFLYSxHQUFHd0csV0FBV0osUUFBUSxFQUFFSyxLQUFLNUIsTUFBTTtBQUFBLEVBQzFDLEdBQUcsQ0FBQ3VCLFFBQVEsQ0FBQztBQUViakgsWUFBVSxNQUFNO0FBQ2QsUUFBSWdFLGVBQWUsT0FBTztBQUN4QjRCLG1CQUFhLEVBQUUyQixNQUFNLEdBQUdDLFNBQVMsTUFBTSxDQUFDO0FBQ3hDO0FBQUEsSUFDRjtBQUNBLFNBQUszRyxHQUFHNEcsaUJBQWlCekQsVUFBVSxFQUFFc0QsS0FBSzFCLFlBQVk7QUFBQSxFQUN4RCxHQUFHLENBQUM1QixVQUFVLENBQUM7QUFJZmhFLFlBQVUsTUFBTTtBQUNkLFFBQUksQ0FBQ3VDLFVBQVc7QUFFaEIsU0FBSzFCLEdBQUc2RyxNQUFNbkYsU0FBUyxFQUFFK0UsS0FBSyxDQUFDSSxVQUFVO0FBQ3ZDLFVBQUlBLE9BQU87QUFDVDNFLG9CQUFZMkUsS0FBSztBQUNqQjdELHFCQUFhNkQsTUFBTTlELFNBQVM7QUFDNUJHLHVCQUFlMkQsTUFBTTVELFdBQVc7QUFDaENHLHNCQUFjeUQsTUFBTTFELFVBQVU7QUFDOUJTLGdCQUFRaUQsTUFBTWxELElBQUk7QUFDbEJHLGlCQUFTK0MsTUFBTUMsVUFBVTtBQUN6QjlDLHFCQUFhNkMsTUFBTTlDLFNBQVM7QUFDNUIsWUFBSThDLE1BQU01QyxNQUFPQyxVQUFTMkMsTUFBTTVDLEtBQUs7QUFHckNRLGtCQUFVb0MsTUFBTUUsWUFBWSxLQUFLRixNQUFNRyxNQUFNO0FBQzdDeEIsaUJBQVNxQixNQUFNSSxLQUFLMUIsS0FBSztBQUN6QkcseUJBQWlCbUIsTUFBTUksS0FBS3hCLGlCQUFpQixFQUFFO0FBQy9DRyxxQkFBYWlCLE1BQU1JLEtBQUt0QixhQUFhLEVBQUU7QUFDdkNHLGtCQUFVZSxNQUFNSyxhQUFhckIsTUFBTTtBQUNuQ0cseUJBQWlCYSxNQUFNSyxhQUFhbkIsYUFBYTtBQUFBLE1BQ25EO0FBQ0EzRCxnQkFBVSxJQUFJO0FBQUEsSUFDaEIsQ0FBQztBQUFBLEVBQ0gsR0FBRyxDQUFDVixTQUFTLENBQUM7QUFFZHZDLFlBQVUsTUFBTTtBQUNkLFNBQUthLEdBQUcyQyxXQUFXYixPQUFPLEVBQUUyRSxLQUFLLENBQUNVLE1BQU07QUFDdEN2RSxvQkFBY3VFLENBQUM7QUFDZixVQUFJQSxFQUFFQyxVQUFVLENBQUNqRSxXQUFZQyxlQUFjK0QsRUFBRSxDQUFDLEVBQUUxRixFQUFFO0FBQUEsSUFDcEQsQ0FBQztBQUFBLEVBRUgsR0FBRyxDQUFDSyxPQUFPLENBQUM7QUFFWjNDLFlBQVUsTUFBTTtBQUVkLFFBQUk0QyxRQUFTO0FBQ2IrQixhQUFTLENBQUMsQ0FBQztBQUNYRSxpQkFBYSxFQUFFO0FBQUEsRUFDakIsR0FBRyxDQUFDb0MsVUFBVXJFLE9BQU8sQ0FBQztBQUV0QixRQUFNc0YsVUFBVSxDQUFrQ0MsR0FBTUMsTUFDdER6RCxTQUFTLENBQUN5QyxPQUFPLEVBQUUsR0FBR0EsR0FBRyxDQUFDZSxDQUFDLEdBQUdDLEVBQUUsRUFBRTtBQUVwQyxRQUFNQyxtQkFBbUIsT0FBT0MsU0FBd0I7QUFDdEQsUUFBSSxDQUFDeEYsU0FBVTtBQUNmTyxlQUFXLElBQUk7QUFDZixVQUFNeEMsR0FBRzBILFlBQVl6RixTQUFTUixJQUFJLEVBQUVvRSxRQUFRNEIsS0FBSyxDQUFDO0FBQ2xELFVBQU01RixRQUFRO0FBQ2RXLGVBQVcsS0FBSztBQUNoQlosV0FBTzZGLFNBQVMsYUFBYTlGLEVBQUUsZUFBZSxJQUFJQSxFQUFFLGVBQWUsQ0FBQztBQUNwRUgsYUFBUyxZQUFZO0FBQUEsRUFDdkI7QUFFQSxRQUFNbUcsVUFBVSxZQUFZO0FBQzFCLFFBQUksQ0FBQzFGLFNBQVU7QUFDZk8sZUFBVyxJQUFJO0FBQ2YsVUFBTXhDLEdBQUc0SCxZQUFZM0YsU0FBU1IsRUFBRTtBQUNoQyxVQUFNSSxRQUFRO0FBQ2RXLGVBQVcsS0FBSztBQUNoQlosV0FBT0QsRUFBRSxjQUFjLENBQUM7QUFDeEJILGFBQVMsWUFBWTtBQUFBLEVBQ3ZCO0FBRUEsUUFBTXFHLFdBQVcsWUFBWTtBQUMzQixRQUFJLENBQUM1RixTQUFVO0FBQ2ZhLGNBQVUsSUFBSTtBQUVkLFVBQU1nRixZQUFZckMsa0JBQWtCLE1BQU1FLGNBQWM7QUFDeEQsVUFBTTNGLEdBQUcwSCxZQUFZekYsU0FBU1IsSUFBSTtBQUFBLE1BQ2hDa0MsTUFBTUEsS0FBS29FLEtBQUssS0FBS25ILGlCQUFpQm1DLFNBQVM7QUFBQSxNQUMvQ0U7QUFBQUEsTUFDQWdFLE1BQU07QUFBQSxRQUNKMUI7QUFBQUEsUUFDQUUsZUFBZUEsa0JBQWtCLEtBQUssT0FBT3VDLE9BQU92QyxhQUFhO0FBQUEsUUFDakVFLFdBQVdBLGNBQWMsS0FBSyxPQUFPcUMsT0FBT3JDLFNBQVM7QUFBQSxRQUNyRHNDLGlCQUFpQmhHLFNBQVNnRixLQUFLZ0I7QUFBQUEsUUFDL0JDLGVBQWVqRyxTQUFTZ0YsS0FBS2lCO0FBQUFBLFFBQzdCQyxrQkFBa0JMLFlBQVl2QyxRQUFReUMsT0FBT3ZDLGFBQWEsSUFBSXVDLE9BQU9yQyxTQUFTLElBQUk7QUFBQSxNQUNwRjtBQUFBLE1BQ0FtQixZQUFZakQ7QUFBQUEsTUFDWkU7QUFBQUEsTUFDQUU7QUFBQUEsTUFDQWlELGNBQWMsRUFBRSxHQUFHakYsU0FBU2lGLGNBQWNyQixRQUFRRSxjQUFjO0FBQUE7QUFBQTtBQUFBLE1BR2hFaUIsUUFBUTlCLGdCQUNKVixPQUFPNEMsU0FDTDVDLFNBQ0E0RCxrQkFBa0JoQyxVQUFVekMsUUFBUS9DLGlCQUFpQm1DLFNBQVMsQ0FBQyxJQUNqRWQsU0FBUytFO0FBQUFBLElBQ2YsQ0FBQztBQUVELFVBQU1uRixRQUFRO0FBQ2RpQixjQUFVLEtBQUs7QUFDZmxCLFdBQU9ELEVBQUUsWUFBWSxDQUFDO0FBQ3RCSCxhQUFTLFVBQVVTLFNBQVNSLEVBQUUsRUFBRTtBQUFBLEVBQ2xDO0FBUUEsUUFBTTRHLFVBQVUsWUFBWTtBQUMxQnZGLGNBQVUsSUFBSTtBQUNkLFVBQU13RixXQUFXN0gsTUFBTTZGLEtBQUssQ0FBQ0MsTUFBTUEsRUFBRTVDLFNBQVNKLElBQUk7QUFFbEQsUUFBSWdGLFdBQVdwRjtBQUNmLFFBQUlBLGVBQWUsU0FBUztBQUMxQixZQUFNcUYsV0FBVSxNQUFNeEksR0FBR3lJLGVBQWU7QUFBQSxRQUN0QzlFLE1BQU1OLGdCQUFnQjBFLEtBQUssS0FBSyxHQUFHeEUsSUFBSTtBQUFBLFFBQ3ZDekI7QUFBQUEsUUFDQXlCO0FBQUFBLFFBQ0FFLGNBQWNBLGFBQWFzRSxLQUFLLEtBQUt4RTtBQUFBQSxRQUNyQ21GLFNBQVMsR0FBR2pGLGFBQWFzRSxLQUFLLEtBQUt4RSxJQUFJLEtBQUtBLElBQUk7QUFBQSxRQUNoRG9GLFVBQVVMLFNBQVNLO0FBQUFBLFFBQ25CQyxXQUFXTixTQUFTTTtBQUFBQSxRQUNwQkMsVUFBVW5FLE1BQU1BLElBQUksQ0FBQyxJQUFJNEQsU0FBU087QUFBQUEsUUFDbENDLGdCQUFnQnBFLE1BQU8sV0FBc0I7QUFBQSxRQUM3Q3FFLFdBQVdyRSxNQUFNQSxJQUFJLENBQUMsSUFBSTRELFNBQVNTO0FBQUFBLFFBQ25DQyxRQUFRO0FBQUEsUUFDUkMsWUFBWSxXQUFXN0MsYUFBYSxTQUFTLFdBQVcsVUFBVTtBQUFBLE1BQ3BFLENBQUM7QUFDRG1DLGlCQUFXQyxTQUFRL0c7QUFBQUEsSUFDckI7QUFFQSxVQUFNcUcsWUFBWXJDLGtCQUFrQixNQUFNRSxjQUFjO0FBQ3hELFVBQU11RCxRQUFRLENBQUMsWUFBWSxZQUFZLFFBQVE7QUFFL0MsVUFBTVYsVUFBVSxNQUFNeEksR0FBR21KLFlBQVk7QUFBQSxNQUNuQ2hHLFlBQVlvRjtBQUFBQSxNQUNaNUUsTUFBTUEsS0FBS29FLEtBQUssS0FBS25ILGlCQUFpQm1DLFNBQVM7QUFBQSxNQUMvQ3FEO0FBQUFBLE1BQ0FyRDtBQUFBQSxNQUNBRTtBQUFBQSxNQUNBZ0UsTUFBTTtBQUFBLFFBQ0oxQjtBQUFBQSxRQUNBRSxlQUFlQSxrQkFBa0IsS0FBSyxPQUFPdUMsT0FBT3ZDLGFBQWE7QUFBQSxRQUNqRUUsV0FBV0EsY0FBYyxLQUFLLE9BQU9xQyxPQUFPckMsU0FBUztBQUFBLFFBQ3JEc0MsaUJBQWlCO0FBQUEsUUFDakJDLGVBQWVqRixnQkFBZ0IsU0FBUyxJQUFJO0FBQUEsUUFDNUNrRixrQkFBa0JMLFlBQVl2QyxRQUFReUMsT0FBT3ZDLGFBQWEsSUFBSXVDLE9BQU9yQyxTQUFTLElBQUk7QUFBQSxNQUNwRjtBQUFBLE1BQ0FtQixZQUFZakQ7QUFBQUEsTUFDWkU7QUFBQUEsTUFDQUU7QUFBQUEsTUFDQWlELGNBQWMsRUFBRXJCLFFBQVFFLGNBQWM7QUFBQTtBQUFBO0FBQUEsTUFHdENpQixRQUFReEMsT0FBTzRDLFNBQ1g1QyxTQUNBLENBQUMsR0FBRyxDQUFDLEVBQUU0RSxJQUFJLENBQUNDLE9BQU87QUFBQSxRQUNqQkMsS0FBSyxXQUFXbEQsUUFBUSxJQUFLaUQsSUFBSSxJQUFLLENBQUM7QUFBQSxRQUN2Q0gsT0FBT0EsTUFBTUcsQ0FBQztBQUFBLFFBQ2RFLEtBQUssc0NBQXNDNUYsUUFBUS9DLGlCQUFpQm1DLFNBQVMsQ0FBQztBQUFBLFFBQzlFeUcsTUFBTTtBQUFBLE1BQ1IsRUFBRTtBQUFBLE1BQ05DLGFBQ0UsR0FBRzdJLGlCQUFpQm1DLFNBQVMsQ0FBQyxPQUFPVSxhQUFhc0UsS0FBSyxLQUFLeEUsSUFBSTtBQUFBLE1BQ2xFbUcsY0FBYyxFQUFFRixNQUFNLE1BQU1HLE9BQU8sc0JBQXNCOUMsT0FBTyxzQkFBc0I7QUFBQSxNQUN0RmhCLFFBQVE7QUFBQSxNQUNSK0QsY0FBYSxvQkFBSTNELEtBQUssR0FBRUMsWUFBWSxFQUFFQyxNQUFNLEdBQUcsRUFBRTtBQUFBLElBQ25ELENBQUM7QUFFRCxVQUFNdEUsUUFBUTtBQUNkaUIsY0FBVSxLQUFLO0FBQ2Z0QixhQUFTLFVBQVVnSCxRQUFRL0csRUFBRSxFQUFFO0FBQUEsRUFDakM7QUFFQSxRQUFNb0ksYUFBYUEsTUFBTTtBQUN2QixRQUFJcEgsU0FBUyxFQUFHLFFBQU9VLGVBQWUsT0FBT0EsZUFBZSxXQUFXRSxnQkFBZ0IwRSxLQUFLLEVBQUVYLFNBQVM7QUFDdkcsUUFBSTNFLFNBQVMsRUFBRyxRQUFPOEMsUUFBUTtBQUMvQixXQUFPO0FBQUEsRUFDVDtBQUVBLE1BQUksQ0FBQ3BELFFBQVE7QUFDWCxXQUFPLHVCQUFDLFNBQUksV0FBVSwyQ0FBMkNSLFlBQUUsY0FBYyxLQUExRTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTRFO0FBQUEsRUFDckY7QUFFQSxNQUFJSSxXQUFXLENBQUNFLFVBQVU7QUFDeEIsV0FDRSx1QkFBQyxTQUFJLFdBQVUsb0NBQ2I7QUFBQSw2QkFBQyxRQUFHLFdBQVUsNENBQTRDTixZQUFFLGdCQUFnQixLQUE1RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQThFO0FBQUEsTUFDOUUsdUJBQUMsUUFBSyxJQUFHLGNBQWEsV0FBVSxxQkFDOUIsaUNBQUMsVUFBUUEsWUFBRSxlQUFlLEtBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNEIsS0FEOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBS0E7QUFBQSxFQUVKO0FBRUEsUUFBTW1JLFdBQVc3SCxVQUFVNEQsV0FBVztBQUV0QyxTQUNFLG1DQUNFO0FBQUE7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLE9BQU85RCxVQUFVSixFQUFFLFlBQVksSUFBSUEsRUFBRSxZQUFZO0FBQUEsUUFDakQsTUFBTUksVUFBVUosRUFBRSxXQUFXLElBQUlBLEVBQUUsV0FBVztBQUFBLFFBQzlDLFNBQ0VJLFVBQ0UsdUJBQUMsU0FBSSxXQUFVLHdCQUNiO0FBQUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFNBQVE7QUFBQSxjQUNSLE1BQUs7QUFBQSxjQUNMLFVBQVVRO0FBQUFBLGNBQ1YsU0FBUyxNQUFNLEtBQUtpRixpQkFBaUJzQyxXQUFXLGNBQWMsVUFBVTtBQUFBLGNBRXZFQTtBQUFBQSwyQkFBVyx1QkFBQyxTQUFNLE1BQU0sSUFBSSxlQUFXLFFBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTRCLElBQU0sdUJBQUMsV0FBUSxNQUFNLElBQUksZUFBVyxRQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUE4QjtBQUFBLGdCQUMzRUEsV0FBV25JLEVBQUUsY0FBYyxJQUFJQSxFQUFFLGNBQWM7QUFBQTtBQUFBO0FBQUEsWUFQbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBUUE7QUFBQSxVQUNBLHVCQUFDLFVBQU8sU0FBUSxhQUFZLE1BQUssTUFBSyxTQUFTLE1BQU1XLGlCQUFpQixJQUFJLEdBQ3hFO0FBQUEsbUNBQUMsVUFBTyxNQUFNLElBQUksZUFBVyxRQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE2QjtBQUFBLFlBQzVCWCxFQUFFLGFBQWE7QUFBQSxlQUZsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsYUFiRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBY0EsSUFDRW9JO0FBQUFBO0FBQUFBLE1BcEJSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQXFCRztBQUFBLElBR0ZELFlBQ0MsdUJBQUMsU0FBSSxXQUFVLHVCQUNiLGlDQUFDLE9BQUUsV0FBVSxzRUFDVm5JLFlBQUUscUJBQXFCLEtBRDFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FJQTtBQUFBLElBR0YsdUJBQUMsU0FBSSxXQUFVLDBDQUViO0FBQUEsNkJBQUMsUUFBRyxXQUFVLGtDQUFpQyxjQUFXLFlBQ3ZETixnQkFBTStIO0FBQUFBLFFBQUksQ0FBQ0YsT0FBT0csTUFDakIsdUJBQUMsUUFBZSxXQUFVLG9DQUN4QixpQ0FBQyxTQUFJLFdBQVUsVUFDYjtBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxXQUFXckk7QUFBQUEsZ0JBQ1Q7QUFBQSxnQkFDQXFJLElBQUk1RyxPQUFPLFdBQVc0RyxNQUFNNUcsT0FBTyxnQkFBZ0I7QUFBQSxjQUNyRDtBQUFBO0FBQUEsWUFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFJSTtBQUFBLFVBRUo7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFdBQVd6QjtBQUFBQSxnQkFDVDtBQUFBLGdCQUNBcUksTUFBTTVHLE9BQU8sYUFBYTtBQUFBLGNBQzVCO0FBQUEsY0FFQ3lHO0FBQUFBO0FBQUFBLFlBTkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBT0E7QUFBQSxhQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFlQSxLQWhCT0EsT0FBVDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBaUJBO0FBQUEsTUFDRCxLQXBCSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBcUJBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsMkRBQ1p6RztBQUFBQSxpQkFBUyxLQUNSLHVCQUFDLFFBQUssT0FBT2QsRUFBRSxtQkFBbUIsR0FDaEM7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsd0JBQ1hULHFCQUFXOEksUUFBUSxDQUFDQyxNQUFNM0osa0JBQWtCMkosQ0FBQyxDQUFDLEVBQUViO0FBQUFBLFlBQUksQ0FBQ3pILE9BQ3BELHVCQUFDLFFBQ0MsaUNBQUMsUUFBSyxRQUFRb0IsY0FBY3BCLElBQUcsU0FBUyxNQUFNcUIsYUFBYXJCLEVBQUMsR0FDekRmLDJCQUFpQmUsRUFBQyxLQURyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBLEtBSE9BLElBQVQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFJQTtBQUFBLFVBQ0QsS0FQSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVFBO0FBQUEsVUFFQSx1QkFBQyxPQUFFLFdBQVUsK0NBQThDLDJDQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFzRjtBQUFBLFVBQ3RGLHVCQUFDLFNBQUksV0FBVSxnREFDWCxXQUFDLFFBQVEsTUFBTSxFQUF3QnlIO0FBQUFBLFlBQUksQ0FBQ3pILE9BQzVDO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBRUMsTUFBSztBQUFBLGdCQUNMLGdCQUFjc0IsZ0JBQWdCdEI7QUFBQUEsZ0JBQzlCLFNBQVMsTUFBTXVCLGVBQWV2QixFQUFDO0FBQUEsZ0JBQy9CLFdBQVdYO0FBQUFBLGtCQUNUO0FBQUEsa0JBQ0FpQyxnQkFBZ0J0QixLQUFJLHNCQUFzQjtBQUFBLGdCQUM1QztBQUFBLGdCQUVDQSxpQkFBTSxTQUFTLFlBQVk7QUFBQTtBQUFBLGNBVHZCQTtBQUFBQSxjQURQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFXQTtBQUFBLFVBQ0QsS0FkSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWVBO0FBQUEsYUEzQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTRCQTtBQUFBLFFBR0RjLFNBQVMsS0FDUix1QkFBQyxRQUFLLE9BQU9kLEVBQUUsZ0JBQWdCLEdBQzdCO0FBQUEsaUNBQUMsT0FBRSxXQUFVLDBDQUF5QyxnREFBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBc0Y7QUFBQSxVQUN0Rix1QkFBQyxTQUFJLFdBQVUsYUFDWmdCO0FBQUFBLHVCQUFXeUc7QUFBQUEsY0FBSSxDQUFDakMsTUFDZjtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFFQyxXQUFXbkc7QUFBQUEsb0JBQ1Q7QUFBQSxvQkFDQW1DLGVBQWVnRSxFQUFFMUYsS0FBSyw2QkFBNkI7QUFBQSxrQkFDckQ7QUFBQSxrQkFFQTtBQUFBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLE1BQUs7QUFBQSx3QkFDTCxNQUFLO0FBQUEsd0JBQ0wsU0FBUzBCLGVBQWVnRSxFQUFFMUY7QUFBQUEsd0JBQzFCLFVBQVUsTUFBTTJCLGNBQWMrRCxFQUFFMUYsRUFBRTtBQUFBLHdCQUNsQyxXQUFVO0FBQUE7QUFBQSxzQkFMWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBSzZCO0FBQUEsb0JBRTdCLHVCQUFDLFNBQUksS0FBSzBGLEVBQUU4QixZQUFZLEtBQUksSUFBRyxXQUFVLHFDQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUEwRTtBQUFBLG9CQUMxRSx1QkFBQyxTQUFJLFdBQVUsV0FDYjtBQUFBLDZDQUFDLE9BQUUsV0FBVSxtQ0FBbUM5QixZQUFFeEQsUUFBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBdUQ7QUFBQSxzQkFDdkQsdUJBQUMsT0FBRSxXQUFVLCtCQUNWd0Q7QUFBQUEsMEJBQUUxRDtBQUFBQSx3QkFBYTtBQUFBLHdCQUFHMEQsRUFBRTVEO0FBQUFBLDJCQUR2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEseUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFLQTtBQUFBO0FBQUE7QUFBQSxnQkFuQks0RCxFQUFFMUY7QUFBQUEsZ0JBRFQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQXFCQTtBQUFBLFlBQ0Q7QUFBQSxZQUVEO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsV0FBV1Q7QUFBQUEsa0JBQ1Q7QUFBQSxrQkFDQW1DLGVBQWUsVUFBVSw2QkFBNkI7QUFBQSxnQkFDeEQ7QUFBQSxnQkFFQTtBQUFBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLE1BQUs7QUFBQSxzQkFDTCxNQUFLO0FBQUEsc0JBQ0wsU0FBU0EsZUFBZTtBQUFBLHNCQUN4QixVQUFVLE1BQU1DLGNBQWMsT0FBTztBQUFBLHNCQUNyQyxXQUFVO0FBQUE7QUFBQSxvQkFMWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBSzZCO0FBQUEsa0JBRTdCLHVCQUFDLFVBQUssV0FBVSxnRkFDZCxpQ0FBQyxRQUFLLE1BQU0sSUFBSSxlQUFXLFFBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTJCLEtBRDdCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFDQSx1QkFBQyxVQUFLLFdBQVUsMEJBQXlCLDhCQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF1RDtBQUFBO0FBQUE7QUFBQSxjQWhCekQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBaUJBO0FBQUEsZUEzQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkE0Q0E7QUFBQSxVQUVDRCxlQUFlLFdBQ2QsdUJBQUMsU0FBSSxXQUFVLGtDQUNiO0FBQUEsbUNBQUMsU0FBTSxPQUFNLGlCQUNYO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsT0FBT0U7QUFBQUEsZ0JBQ1AsVUFBVSxDQUFDNkcsTUFBTTVHLG1CQUFtQjRHLEVBQUVDLE9BQU9DLEtBQUs7QUFBQSxnQkFDbEQsYUFBWTtBQUFBLGdCQUNaLFdBQVdDO0FBQUFBO0FBQUFBLGNBSmI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBSXdCLEtBTDFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBT0E7QUFBQSxZQUNBLHVCQUFDLFNBQU0sT0FBTzFJLEVBQUUsYUFBYSxHQUMzQixpQ0FBQyxjQUFXLE9BQU80QixNQUFNLFVBQVVDLFdBQW5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTJDLEtBRDdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLFNBQU0sT0FBTzdCLEVBQUUsb0JBQW9CLEdBQ2xDO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsT0FBTzhCO0FBQUFBLGdCQUNQLFVBQVUsQ0FBQ3lHLE1BQU14RyxnQkFBZ0J3RyxFQUFFQyxPQUFPQyxLQUFLO0FBQUEsZ0JBQy9DLGFBQVk7QUFBQSxnQkFDWixXQUFXQztBQUFBQTtBQUFBQSxjQUpiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUl3QixLQUwxQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU9BO0FBQUEsZUFuQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFvQkE7QUFBQSxVQUlEbEgsZUFBZSxTQUFTa0QsZ0JBQ3ZCLHVCQUFDLFNBQUksV0FBVSxzQ0FDYjtBQUFBLG1DQUFDLFFBQUcsV0FBVSx3Q0FBd0MxRSxZQUFFLGNBQWMsS0FBdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBd0U7QUFBQSxZQUN4RSx1QkFBQyxPQUFFLFdBQVUsMkNBQTJDQSxZQUFFLGFBQWEsS0FBdkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBeUU7QUFBQSxZQUN6RTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFFBQVEsQ0FBQzBFLGFBQWF3QyxVQUFVeEMsYUFBYTBDLFNBQVM7QUFBQSxnQkFDdEQsT0FBT3JFO0FBQUFBLGdCQUNQLFVBQVVDO0FBQUFBO0FBQUFBLGNBSFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBR21CO0FBQUEsZUFOckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFRQTtBQUFBLGFBbEZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFvRkE7QUFBQSxRQUdEbEMsU0FBUyxLQUNSLHVCQUFDLFFBQUssT0FBTyxjQUFjN0IsaUJBQWlCbUMsU0FBUyxFQUFFdUgsWUFBWSxDQUFDLElBQ2xFO0FBQUEsaUNBQUMsU0FBTSxPQUFNLFdBQ1g7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE9BQU8zRztBQUFBQSxjQUNQLFVBQVUsQ0FBQ3VHLE1BQU10RyxRQUFRc0csRUFBRUMsT0FBT0MsS0FBSztBQUFBLGNBQ3ZDLGFBQWFHLGdCQUFnQnhILFNBQVM7QUFBQSxjQUN0QyxXQUFXc0g7QUFBQUE7QUFBQUEsWUFKYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFJd0IsS0FMMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFPQTtBQUFBLFVBRUEsdUJBQUMsU0FBSSxXQUFVLGtDQUNaRyxvQkFBVXBFLFFBQVEsRUFBRWdEO0FBQUFBLFlBQUksQ0FBQ3FCLE1BQ3hCLHVCQUFDLFNBQWtCLE9BQU9BLEVBQUV2QixPQUN6QnVCLFlBQUVDLFNBQVMsU0FDVix1QkFBQyxXQUFNLFdBQVUsK0ZBQ2Y7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsU0FBUzFJLFFBQVE2QixNQUFNNEcsRUFBRUUsR0FBRyxDQUFDO0FBQUEsa0JBQzdCLFVBQVUsQ0FBQ1QsTUFBTTdDLFFBQVFvRCxFQUFFRSxLQUFLVCxFQUFFQyxPQUFPUyxPQUFnQjtBQUFBLGtCQUN6RCxXQUFVO0FBQUE7QUFBQSxnQkFKWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FJb0M7QUFBQTtBQUFBLGlCQUx0QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVFBLElBQ0VILEVBQUVDLFNBQVMsU0FDYjtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE9BQVE3RyxNQUFNNEcsRUFBRUUsR0FBRyxLQUFnQjtBQUFBLGdCQUNuQyxVQUFVLENBQUNULE1BQU03QyxRQUFRb0QsRUFBRUUsS0FBS1QsRUFBRUMsT0FBT0MsS0FBYztBQUFBLGdCQUN2RCxhQUFhSyxFQUFFSTtBQUFBQSxnQkFDZixXQUFXUjtBQUFBQTtBQUFBQSxjQUpiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUl3QixJQUd4QjtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxXQUFVO0FBQUEsZ0JBQ1YsS0FBSztBQUFBLGdCQUNMLE9BQVF4RyxNQUFNNEcsRUFBRUUsR0FBRyxLQUFnQjtBQUFBLGdCQUNuQyxVQUFVLENBQUNULE1BQU03QyxRQUFRb0QsRUFBRUUsS0FBTVQsRUFBRUMsT0FBT0MsVUFBVSxLQUFLTCxTQUFZL0IsT0FBT2tDLEVBQUVDLE9BQU9DLEtBQUssQ0FBVztBQUFBLGdCQUNyRyxhQUFhSyxFQUFFSTtBQUFBQSxnQkFDZixXQUFXN0osR0FBR3FKLFlBQVksTUFBTTtBQUFBO0FBQUEsY0FQbEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBT29DLEtBMUI1QkksRUFBRUUsS0FBZDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTZCQTtBQUFBLFVBQ0QsS0FoQ0g7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFpQ0E7QUFBQSxhQTNDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBNENBO0FBQUEsUUFHRGxJLFNBQVMsS0FDUix1QkFBQyxRQUFLLE9BQU9kLEVBQUUsbUJBQW1CLEdBQ2hDO0FBQUEsaUNBQUMsUUFBRyxXQUFVLHdCQUNYbkIsZ0NBQXNCNEYsUUFBUSxFQUFFZ0QsSUFBSSxDQUFDdUIsUUFBUTtBQUM1QyxrQkFBTSxFQUFFekIsT0FBTzRCLE1BQU1DLEtBQUssSUFBSXhLLFVBQVVvSyxHQUFHO0FBQzNDLGtCQUFNSyxLQUFLakgsVUFBVWtILFNBQVNOLEdBQUc7QUFDakMsbUJBQ0UsdUJBQUMsUUFDQztBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFFBQVFLO0FBQUFBLGdCQUNSLFNBQVMsTUFDUGhILGFBQWFnSCxLQUFLakgsVUFBVW1ILE9BQU8sQ0FBQzNFLE1BQU1BLE1BQU1vRSxHQUFHLElBQUksQ0FBQyxHQUFHNUcsV0FBVzRHLEdBQUcsQ0FBQztBQUFBLGdCQUc1RTtBQUFBLHlDQUFDLFFBQUssTUFBTSxJQUFJLGVBQVcsUUFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBMkI7QUFBQSxrQkFDMUJ6QjtBQUFBQTtBQUFBQTtBQUFBQSxjQVBIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVFBLEtBVE95QixLQUFUO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBVUE7QUFBQSxVQUVKLENBQUMsS0FqQkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFrQkE7QUFBQSxVQUNBLHVCQUFDLE9BQUUsV0FBVSwyQkFBeUI7QUFBQTtBQUFBLFlBQ0kvSixpQkFBaUJtQyxTQUFTLEVBQUV1SCxZQUFZO0FBQUEsWUFBRTtBQUFBLGVBRHBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUVDbEUsYUFBYSxZQUNaLHVCQUFDLFNBQUksV0FBVSxzQ0FDYjtBQUFBLG1DQUFDLFFBQUcsV0FBVSx3Q0FBd0N6RSxZQUFFLGFBQWEsS0FBckU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBdUU7QUFBQSxZQUN2RSx1QkFBQyxPQUFFLFdBQVUsMkJBQXlCLDRGQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFFQSx1QkFBQyxRQUFHLFdBQVUsd0JBQ1o7QUFBQSxxQ0FBQyxRQUNDO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFFBQVFzQyxNQUFNRTtBQUFBQSxrQkFDZCxTQUFTLE1BQU1ELFNBQVMsRUFBRSxHQUFHRCxPQUFPRSxlQUFlLENBQUNGLE1BQU1FLGNBQWMsQ0FBQztBQUFBLGtCQUV4RXhDLFlBQUUsc0JBQXNCO0FBQUE7QUFBQSxnQkFKM0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBS0EsS0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQU9BO0FBQUEsY0FDQSx1QkFBQyxRQUNDO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFFBQVFzQyxNQUFNRztBQUFBQSxrQkFDZCxTQUFTLE1BQU1GLFNBQVMsRUFBRSxHQUFHRCxPQUFPRyxpQkFBaUIsQ0FBQ0gsTUFBTUcsZ0JBQWdCLENBQUM7QUFBQSxrQkFFNUV6QyxZQUFFLHdCQUF3QjtBQUFBO0FBQUEsZ0JBSjdCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUtBLEtBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFPQTtBQUFBLGNBQ0EsdUJBQUMsUUFDQztBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxRQUFRc0MsTUFBTUk7QUFBQUEsa0JBQ2QsU0FBUyxNQUFNSCxTQUFTLEVBQUUsR0FBR0QsT0FBT0ksaUJBQWlCLENBQUNKLE1BQU1JLGdCQUFnQixDQUFDO0FBQUEsa0JBRTVFMUMsWUFBRSx3QkFBd0I7QUFBQTtBQUFBLGdCQUo3QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLQSxLQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBT0E7QUFBQSxpQkF4QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF5QkE7QUFBQSxZQUVBLHVCQUFDLFNBQUksV0FBVSxrQ0FDYjtBQUFBLHFDQUFDLFNBQU0sT0FBTSxxQkFDWDtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxPQUFPc0MsTUFBTUs7QUFBQUEsa0JBQ2IsVUFBVSxDQUFDNEYsTUFDVGhHLFNBQVMsRUFBRSxHQUFHRCxPQUFPSyxrQkFBa0I0RixFQUFFQyxPQUFPQyxNQUEwQixDQUFDO0FBQUEsa0JBRTdFLFdBQVdDO0FBQUFBLGtCQUVYO0FBQUEsMkNBQUMsWUFBTyxPQUFNLE9BQU0sNkJBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWlDO0FBQUEsb0JBQ2pDLHVCQUFDLFlBQU8sT0FBTSxRQUFPLHdCQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUE2QjtBQUFBLG9CQUM3Qix1QkFBQyxZQUFPLE9BQU0sVUFBUywwQkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBaUM7QUFBQTtBQUFBO0FBQUEsZ0JBVG5DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVVBLEtBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFZQTtBQUFBLGNBQ0EsdUJBQUMsU0FBTSxPQUFNLHFCQUNYO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxLQUFLO0FBQUEsa0JBQ0wsT0FBT3BHLE1BQU1NLGdCQUFnQjtBQUFBLGtCQUM3QixhQUFZO0FBQUEsa0JBQ1osVUFBVSxDQUFDMkYsTUFDVGhHLFNBQVM7QUFBQSxvQkFDUCxHQUFHRDtBQUFBQSxvQkFDSE0sY0FBYzJGLEVBQUVDLE9BQU9DLFVBQVUsS0FBSyxPQUFPcEMsT0FBT2tDLEVBQUVDLE9BQU9DLEtBQUs7QUFBQSxrQkFDcEUsQ0FBQztBQUFBLGtCQUVILFdBQVdwSixHQUFHcUosWUFBWSxNQUFNO0FBQUE7QUFBQSxnQkFYbEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBV29DLEtBWnRDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBY0E7QUFBQSxpQkE1QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkE2QkE7QUFBQSxlQTlERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQStEQTtBQUFBLGFBeEZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUEwRkE7QUFBQSxRQUdENUgsU0FBUyxLQUNSLHVCQUFDLFFBQUssT0FBT2QsRUFBRSxhQUFhLEdBQzFCO0FBQUEsaUNBQUMsT0FBRSxXQUFVLDJCQUEyQkEsWUFBRSxpQkFBaUIsS0FBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNkQ7QUFBQSxVQUM3RDtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsU0FBU3lEO0FBQUFBLGNBQ1QsUUFBUVo7QUFBQUEsY0FDUixVQUFVLENBQUNpRCxTQUFTO0FBQ2xCdEMsaUNBQWlCLElBQUk7QUFDckJWLDBCQUFVZ0QsSUFBSTtBQUFBLGNBQ2hCO0FBQUE7QUFBQSxZQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU1JO0FBQUEsYUFSTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBVUE7QUFBQSxRQUdEaEYsU0FBUyxLQUNSLHVCQUFDLFFBQUssT0FBT2QsRUFBRSx3QkFBd0IsR0FDckM7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsNkJBQ2I7QUFBQSxtQ0FBQyxTQUFNLE9BQU9zQixnQkFBZ0IsU0FBUyxpQkFBaUIsZ0JBQ3RELGlDQUFDLGNBQVcsT0FBT3NDLE9BQU8sVUFBVUMsWUFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNkMsS0FEL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0N2QyxnQkFBZ0IsVUFDZixtQ0FDRTtBQUFBLHFDQUFDLFNBQU0sT0FBTSxrQkFDWCxpQ0FBQyxjQUFXLE9BQU93QyxlQUFlLFVBQVVDLGtCQUFrQixZQUFVLFFBQXhFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXdFLEtBRDFFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLFNBQU0sT0FBTSxhQUNYLGlDQUFDLGNBQVcsT0FBT0MsV0FBVyxVQUFVQyxjQUFjLFlBQVUsUUFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBZ0UsS0FEbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBT0E7QUFBQSxZQUVGLHVCQUFDLFNBQU0sT0FBTSxVQUNYO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsT0FBT0M7QUFBQUEsZ0JBQ1AsVUFBVSxDQUFDcUUsTUFBTXBFLFVBQVVvRSxFQUFFQyxPQUFPQyxLQUEyQjtBQUFBLGdCQUMvRCxXQUFXQztBQUFBQSxnQkFFWDtBQUFBLHlDQUFDLFlBQU8sT0FBTSxhQUFZLHlCQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFtQztBQUFBLGtCQUNuQyx1QkFBQyxZQUFPLE9BQU0sdUJBQXNCLGdDQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFvRDtBQUFBLGtCQUNwRCx1QkFBQyxZQUFPLE9BQU0sa0JBQWlCLDhCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE2QztBQUFBLGtCQUM3Qyx1QkFBQyxZQUFPLE9BQU0sWUFBVyx3QkFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBaUM7QUFBQSxrQkFDakMsdUJBQUMsWUFBTyxPQUFNLGVBQWMsMkJBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXVDO0FBQUE7QUFBQTtBQUFBLGNBVHpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVVBLEtBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFZQTtBQUFBLFlBQ0EsdUJBQUMsU0FBTSxPQUFNLGtCQUNYO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLE9BQU90RTtBQUFBQSxnQkFDUCxVQUFVLENBQUNtRSxNQUFNbEUsaUJBQWlCa0UsRUFBRUMsT0FBT0MsS0FBSztBQUFBLGdCQUNoRCxXQUFXQztBQUFBQTtBQUFBQSxjQUpiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUl3QixLQUwxQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU9BO0FBQUEsZUFsQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFtQ0E7QUFBQSxVQUVDcEgsZ0JBQWdCLFVBQ2YsdUJBQUMsT0FBRSxXQUFVLHdFQUFzRSwyS0FBbkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLGFBMUNKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUE0Q0E7QUFBQSxRQUdEUixTQUFTLEtBQ1IsdUJBQUMsUUFBSyxPQUFPZCxFQUFFLGFBQWEsR0FHekI7QUFBQSxXQUFDSSxXQUFXNkMsUUFBUSxRQUFRRSxjQUFjLFFBQ3pDLHVCQUFDLFNBQUksV0FBVSx5REFDWkE7QUFBQUEsc0JBQVU0QixPQUFPLEtBQUs1QixVQUFVNkIsVUFDL0IsbUNBQ0U7QUFBQSxxQ0FBQyxPQUFFLFdBQVUsd0NBQXdDaEYsWUFBRSxXQUFXLEtBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW9FO0FBQUEsY0FDcEUsdUJBQUMsT0FBRSxXQUFVLDhDQUE4Q0EsWUFBRSxVQUFVLEtBQXZFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXlFO0FBQUEsY0FDekUsdUJBQUMsU0FBSSxXQUFVLDREQUNiO0FBQUEsdUNBQUMsVUFBSyxXQUFVLHNCQUFzQkEsWUFBRSxZQUFZLEtBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXNEO0FBQUEsZ0JBQ3RELHVCQUFDLFVBQUssV0FBVSxxREFDYlosZ0JBQU02RCxHQUFHLEtBRFo7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBS0E7QUFBQSxjQUNDLENBQUNFLFVBQVU2QixXQUNWLHVCQUFDLE9BQUUsV0FBVSwyQkFDVmhGLFlBQUUsWUFBWSxFQUFFK0UsTUFBTTVCLFVBQVU0QixPQUFPLEVBQUUsQ0FBQyxLQUQ3QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBWko7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFjQSxJQUVBLG1DQUNFO0FBQUEscUNBQUMsT0FBRSxXQUFVLHdDQUNWL0UsWUFBRSxtQkFBbUIsS0FEeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0EsdUJBQUMsT0FBRSxXQUFVLDhDQUNWQSxZQUFFLG1CQUFtQixLQUR4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxPQUFFLFdBQVUsb0NBQW9DQSxZQUFFLGVBQWUsS0FBbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBb0U7QUFBQSxjQUNwRTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsU0FBUTtBQUFBLGtCQUNSLFdBQVU7QUFBQSxrQkFDVixVQUFVcUQ7QUFBQUEsa0JBQ1YsU0FBUyxZQUFZO0FBQ25CQyw4QkFBVSxJQUFJO0FBQ2Qsd0JBQUk7QUFDRiw0QkFBTWpGLEdBQUdtTCxnQkFBZ0JoSSxZQUFZLEdBQUk7QUFDekM0QixtQ0FBYSxNQUFNL0UsR0FBRzRHLGlCQUFpQnpELFVBQVUsQ0FBQztBQUNsRHZCLDZCQUFPRCxFQUFFLFVBQVUsQ0FBQztBQUFBLG9CQUN0QixVQUFDO0FBQ0NzRCxnQ0FBVSxLQUFLO0FBQUEsb0JBQ2pCO0FBQUEsa0JBQ0Y7QUFBQSxrQkFFQ3RELFlBQUUsYUFBYTtBQUFBO0FBQUEsZ0JBaEJsQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FpQkE7QUFBQSxpQkF6QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkEwQkE7QUFBQSxZQUdGLHVCQUFDLE9BQUUsV0FBVSw4Q0FBOENBLFlBQUUsYUFBYSxLQUExRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE0RTtBQUFBLGVBL0M5RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWdEQTtBQUFBLFVBR0YsdUJBQUMsUUFBRyxXQUFVLHNFQUNaO0FBQUEsbUNBQUMsVUFBTyxPQUFNLFNBQVEsT0FBTyxHQUFHZ0MsUUFBUS9DLGlCQUFpQm1DLFNBQVMsQ0FBQyxNQUFNbkMsaUJBQWlCbUMsU0FBUyxDQUFDLE1BQXBHO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXVHO0FBQUEsWUFDdkc7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxPQUFNO0FBQUEsZ0JBQ04sT0FDRUksZUFBZSxVQUNYLEdBQUdFLG1CQUFtQixjQUFjLFlBQVlFLElBQUksS0FDcERaLFdBQVcyRCxLQUFLLENBQUNhLE1BQU1BLEVBQUUxRixPQUFPMEIsVUFBVSxHQUFHUSxRQUFRO0FBQUE7QUFBQSxjQUw3RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFNRztBQUFBLFlBRUg7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxPQUFPVixnQkFBZ0IsU0FBUyxTQUFTO0FBQUEsZ0JBQ3pDLE9BQ0VsQyxNQUFNd0UsS0FBSyxLQUNWdEMsZ0JBQWdCLFVBQVV3QyxrQkFBa0IsTUFBTUUsY0FBYyxLQUM3RCxZQUFZNUUsTUFBTXdFLFFBQVF5QyxPQUFPdkMsYUFBYSxJQUFJdUMsT0FBT3JDLFNBQVMsQ0FBQyxDQUFDLFlBQ3BFO0FBQUE7QUFBQSxjQU5SO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU9HO0FBQUEsWUFFSCx1QkFBQyxVQUFPLE9BQU0sZ0JBQWUsT0FBT0UsT0FBT3VGLFFBQVEsS0FBSyxHQUFHLEtBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTZEO0FBQUEsWUFDN0QsdUJBQUMsVUFBTyxPQUFNLFlBQVcsT0FBT3JILFVBQVVxRCxTQUFTckQsVUFBVXFGLElBQUksQ0FBQzdDLE1BQU01RSxFQUFFLFdBQVc0RSxDQUFDLEVBQVcsQ0FBQyxFQUFFOEUsS0FBSyxJQUFJLElBQUksb0JBQWpIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWtJO0FBQUEsZUFwQnBJO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBcUJBO0FBQUEsVUFFQSx1QkFBQyxPQUFFLFdBQVUsMkNBQXlDLDJLQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsYUFqRkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWtGQTtBQUFBLFFBSUYsdUJBQUMsU0FBSSxXQUFVLDhEQUNaNUk7QUFBQUEsaUJBQU8sS0FDTix1QkFBQyxVQUFPLFNBQVEsYUFBWSxTQUFTLE1BQU1DLFFBQVEsQ0FBQzRJLE1BQU1BLElBQUksQ0FBQyxHQUM3RDtBQUFBLG1DQUFDLGFBQVUsTUFBTSxJQUFJLGVBQVcsUUFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBZ0M7QUFBQTtBQUFBLGVBRGxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUVGLHVCQUFDLFVBQUssV0FBVSxtQ0FBaUM7QUFBQTtBQUFBLFlBQ3pDN0ksT0FBTztBQUFBLFlBQUU7QUFBQSxZQUFLcEIsTUFBTStGO0FBQUFBLGVBRDVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNDM0UsT0FBT3BCLE1BQU0rRixTQUFTLElBQ3JCLHVCQUFDLFVBQU8sVUFBVSxDQUFDeUMsV0FBVyxHQUFHLFNBQVMsTUFBTW5ILFFBQVEsQ0FBQzRJLE1BQU1BLElBQUksQ0FBQyxHQUFFO0FBQUE7QUFBQSxZQUVwRSx1QkFBQyxjQUFXLE1BQU0sSUFBSSxlQUFXLFFBQWpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWlDO0FBQUEsZUFGbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQSxJQUVBLHVCQUFDLFVBQU8sVUFBVXpJLFFBQVEsU0FBUyxNQUFNLE1BQU1kLFVBQVU4RixTQUFTLElBQUlRLFFBQVEsSUFDNUU7QUFBQSxtQ0FBQyxTQUFNLE1BQU0sSUFBSSxlQUFXLFFBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTRCO0FBQUEsWUFDM0J4RixTQUNHbEIsRUFBRSxtQkFBbUIsSUFDckJJLFVBQ0VKLEVBQUUsb0JBQW9CLElBQ3RCLENBQUNJLFdBQVc2QyxRQUFRLFFBQVFFLGNBQWMsUUFBUUEsVUFBVTRCLE9BQU8sSUFDakUvRSxFQUFFLFNBQVMsSUFDWEEsRUFBRSxnQkFBZ0I7QUFBQSxlQVI1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVNBO0FBQUEsYUF6Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTJCQTtBQUFBLFdBdmJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF3YkE7QUFBQSxTQWpkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBa2RBO0FBQUEsSUFFQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsTUFBTVU7QUFBQUEsUUFDTixTQUFTLE1BQU1DLGlCQUFpQixLQUFLO0FBQUEsUUFDckMsT0FBT1gsRUFBRSxrQkFBa0I7QUFBQSxRQUMzQixRQUNFLHVCQUFDLFNBQUksV0FBVSxjQUNiO0FBQUEsaUNBQUMsVUFBTyxTQUFRLGFBQVksV0FBUyxNQUFDLFNBQVMsTUFBTVcsaUJBQWlCLEtBQUssR0FDeEVYLFlBQUUsZUFBZSxLQURwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxVQUFPLFNBQVEsZUFBYyxXQUFTLE1BQUMsVUFBVVksU0FBUyxTQUFTLE1BQU0sS0FBS29GLFFBQVEsR0FDcEZoRyxZQUFFLGFBQWEsS0FEbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU9BO0FBQUEsUUFHRjtBQUFBLGlDQUFDLE9BQUUsV0FBVSx5Q0FBeUNBLFlBQUUsaUJBQWlCLEtBQXpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJFO0FBQUEsVUFDM0UsdUJBQUMsT0FBRSxXQUFVLHlFQUNWQSxZQUFFLG9CQUFvQixLQUR6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUE7QUFBQTtBQUFBLE1BbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQW1CQTtBQUFBLE9BeGdCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBeWdCQTtBQUVKO0FBRUFKLEdBdHhCd0JELFdBQVM7QUFBQSxVQUNkaEMsYUFDU0MsV0FDWjBCLFNBQ0tkLFVBQ1VKLFNBQVM7QUFBQTtBQUFBLEtBTGhCdUI7QUF1eEJ4QixTQUFTOEcsa0JBQWtCaEMsVUFBeUI4QyxPQUE2QjtBQUMvRSxTQUFPLENBQUMsR0FBRyxDQUFDLEVBQUVFLElBQUksQ0FBQ0MsT0FBTztBQUFBLElBQ3hCQyxLQUFLLFdBQVdsRCxRQUFRLElBQUtpRCxJQUFJLElBQUssQ0FBQztBQUFBLElBQ3ZDSCxPQUFPRyxNQUFNLElBQUksU0FBUztBQUFBLElBQzFCRSxLQUFLLHNDQUFzQ0wsS0FBSztBQUFBLElBQ2hETSxNQUFNO0FBQUEsRUFDUixFQUFFO0FBQ0o7QUFXQSxTQUFTZ0IsVUFBVXBFLFVBQXNDO0FBQ3ZELFVBQVFBLFVBQVE7QUFBQSxJQUNkLEtBQUs7QUFDSCxhQUFPO0FBQUEsUUFDTCxFQUFFdUUsS0FBSyxZQUFZekIsT0FBTyxZQUFZd0IsTUFBTSxVQUFVRyxhQUFhLElBQUk7QUFBQSxRQUN2RSxFQUFFRixLQUFLLGFBQWF6QixPQUFPLGFBQWF3QixNQUFNLFVBQVVHLGFBQWEsSUFBSTtBQUFBLFFBQ3pFLEVBQUVGLEtBQUssWUFBWXpCLE9BQU8sZUFBZXdCLE1BQU0sVUFBVUcsYUFBYSxNQUFNO0FBQUEsUUFDNUUsRUFBRUYsS0FBSyxTQUFTekIsT0FBTyxTQUFTd0IsTUFBTSxVQUFVRyxhQUFhLElBQUk7QUFBQSxRQUNqRSxFQUFFRixLQUFLLFdBQVd6QixPQUFPLFdBQVd3QixNQUFNLE9BQU87QUFBQSxRQUNqRCxFQUFFQyxLQUFLLFdBQVd6QixPQUFPLFdBQVd3QixNQUFNLE9BQU87QUFBQSxNQUFDO0FBQUEsSUFFdEQsS0FBSztBQUNILGFBQU87QUFBQSxRQUNMLEVBQUVDLEtBQUssWUFBWXpCLE9BQU8sZUFBZXdCLE1BQU0sVUFBVUcsYUFBYSxNQUFNO0FBQUEsUUFDNUUsRUFBRUYsS0FBSyxTQUFTekIsT0FBTyxTQUFTd0IsTUFBTSxVQUFVRyxhQUFhLGVBQWU7QUFBQSxRQUM1RSxFQUFFRixLQUFLLGNBQWN6QixPQUFPLGlCQUFpQndCLE1BQU0sVUFBVUcsYUFBYSxLQUFLO0FBQUEsUUFDL0UsRUFBRUYsS0FBSyxnQkFBZ0J6QixPQUFPLGdCQUFnQndCLE1BQU0sVUFBVUcsYUFBYSxLQUFLO0FBQUEsUUFDaEYsRUFBRUYsS0FBSyxlQUFlekIsT0FBTyxnQkFBZ0J3QixNQUFNLE9BQU87QUFBQSxRQUMxRCxFQUFFQyxLQUFLLGVBQWV6QixPQUFPLHdCQUF3QndCLE1BQU0sUUFBUUcsYUFBYSxXQUFXO0FBQUEsTUFBQztBQUFBLElBRWhHLEtBQUs7QUFDSCxhQUFPO0FBQUEsUUFDTCxFQUFFRixLQUFLLFlBQVl6QixPQUFPLHVCQUF1QndCLE1BQU0sVUFBVUcsYUFBYSxPQUFPO0FBQUEsUUFDckYsRUFBRUYsS0FBSyxtQkFBbUJ6QixPQUFPLHVCQUF1QndCLE1BQU0sVUFBVUcsYUFBYSxLQUFLO0FBQUEsUUFDMUYsRUFBRUYsS0FBSyxpQkFBaUJ6QixPQUFPLGtCQUFrQndCLE1BQU0sT0FBTztBQUFBLFFBQzlELEVBQUVDLEtBQUssaUJBQWlCekIsT0FBTyxnQkFBZ0J3QixNQUFNLE9BQU87QUFBQSxRQUM1RCxFQUFFQyxLQUFLLGVBQWV6QixPQUFPLGtCQUFrQndCLE1BQU0sUUFBUUcsYUFBYSxZQUFZO0FBQUEsTUFBQztBQUFBLElBRTNGLEtBQUs7QUFDSCxhQUFPO0FBQUEsUUFDTCxFQUFFRixLQUFLLFlBQVl6QixPQUFPLGFBQWF3QixNQUFNLFVBQVVHLGFBQWEsSUFBSTtBQUFBLFFBQ3hFLEVBQUVGLEtBQUssbUJBQW1CekIsT0FBTyxvQkFBb0J3QixNQUFNLFVBQVVHLGFBQWEsSUFBSTtBQUFBLFFBQ3RGLEVBQUVGLEtBQUssV0FBV3pCLE9BQU8sV0FBV3dCLE1BQU0sT0FBTztBQUFBLFFBQ2pELEVBQUVDLEtBQUssZUFBZXpCLE9BQU8sZ0JBQWdCd0IsTUFBTSxRQUFRRyxhQUFhLFdBQVc7QUFBQSxNQUFDO0FBQUEsSUFFeEYsS0FBSztBQUNILGFBQU87QUFBQSxRQUNMLEVBQUVGLEtBQUssbUJBQW1CekIsT0FBTyx1QkFBdUJ3QixNQUFNLFVBQVVHLGFBQWEsS0FBSztBQUFBLFFBQzFGLEVBQUVGLEtBQUssV0FBV3pCLE9BQU8sWUFBWXdCLE1BQU0sUUFBUUcsYUFBYSxRQUFRO0FBQUEsUUFDeEUsRUFBRUYsS0FBSyxjQUFjekIsT0FBTyxlQUFld0IsTUFBTSxPQUFPO0FBQUEsUUFDeEQsRUFBRUMsS0FBSyxlQUFlekIsT0FBTyxnQkFBZ0J3QixNQUFNLE9BQU87QUFBQSxRQUMxRCxFQUFFQyxLQUFLLGNBQWN6QixPQUFPLHdCQUF3QndCLE1BQU0sVUFBVUcsYUFBYSxJQUFJO0FBQUEsTUFBQztBQUFBLEVBRTVGO0FBQ0Y7QUFFQSxTQUFTTixnQkFBZ0JnQixNQUF5QjtBQUNoRCxVQUFRQSxNQUFJO0FBQUEsSUFDVixLQUFLO0FBQWEsYUFBTztBQUFBLElBQ3pCLEtBQUs7QUFBUSxhQUFPO0FBQUEsSUFDcEIsS0FBSztBQUFVLGFBQU87QUFBQSxJQUN0QixLQUFLO0FBQVUsYUFBTztBQUFBLElBQ3RCLEtBQUs7QUFBVSxhQUFPO0FBQUEsSUFDdEIsS0FBSztBQUFZLGFBQU87QUFBQSxJQUN4QjtBQUFTLGFBQU8zSyxpQkFBaUIySyxJQUFJO0FBQUEsRUFDdkM7QUFDRjtBQUlBLE1BQU1sQixhQUNKO0FBRUYsU0FBU21CLEtBQUssRUFBRUMsT0FBT0MsU0FBdUQsR0FBRztBQUMvRSxTQUNFLHVCQUFDLFNBQ0M7QUFBQSwyQkFBQyxRQUFHLFdBQVUsZ0RBQWdERCxtQkFBOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFvRTtBQUFBLElBQ25FQztBQUFBQSxPQUZIO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FHQTtBQUVKO0FBQUNDLE1BUFFIO0FBU1QsU0FBU0ksTUFBTSxFQUFFMUMsT0FBT3dDLFNBQXVELEdBQUc7QUFDaEYsU0FDRSx1QkFBQyxXQUFNLFdBQVUsU0FDZjtBQUFBLDJCQUFDLFVBQUssV0FBVSxrREFBa0R4QyxtQkFBbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF3RTtBQUFBLElBQ3ZFd0M7QUFBQUEsT0FGSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBR0E7QUFFSjtBQUFDRyxNQVBRRDtBQVNULFNBQVNFLEtBQUssRUFBRUMsUUFBUUMsU0FBU04sU0FBOEUsR0FBRztBQUNoSCxTQUNFO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDQyxNQUFLO0FBQUEsTUFDTCxnQkFBY0s7QUFBQUEsTUFDZDtBQUFBLE1BQ0EsV0FBVy9LO0FBQUFBLFFBQ1Q7QUFBQSxRQUNBK0ssU0FBUyxzQkFBc0I7QUFBQSxNQUNqQztBQUFBLE1BRUNMO0FBQUFBO0FBQUFBLElBVEg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBVUE7QUFFSjtBQUFDTyxNQWRRSDtBQWdCVCxTQUFTSSxXQUFXO0FBQUEsRUFDbEI5QjtBQUFBQSxFQUNBK0I7QUFBQUEsRUFDQUM7QUFLRixHQUFHO0FBQ0QsU0FDRSx1QkFBQyxTQUFJLFdBQVUsWUFDYjtBQUFBLDJCQUFDLFVBQUssV0FBVSwyRUFBMEUsaUJBQTFGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBMkY7QUFBQSxJQUMzRjtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsTUFBSztBQUFBLFFBQ0wsV0FBVTtBQUFBLFFBQ1YsTUFBTTtBQUFBLFFBQ04sS0FBSztBQUFBLFFBQ0w7QUFBQSxRQUNBLGFBQWFBLGFBQWEsZUFBZXJDO0FBQUFBLFFBQ3pDLFVBQVUsQ0FBQ0csTUFBTWlDLFNBQVVqQyxFQUFFQyxPQUFPQyxVQUFVLEtBQUssS0FBS3BDLE9BQU9rQyxFQUFFQyxPQUFPQyxLQUFLLENBQVc7QUFBQSxRQUN4RixXQUFXcEosR0FBR3FKLFlBQVksV0FBVztBQUFBO0FBQUEsTUFSdkM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBUXlDO0FBQUEsT0FWM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVlBO0FBRUo7QUFBQ2dDLE1BeEJRSDtBQTBCVCxTQUFTSSxPQUFPLEVBQUVwRCxPQUFPa0IsTUFBd0MsR0FBRztBQUNsRSxTQUNFLHVCQUFDLFNBQUksV0FBVSxpRUFDYjtBQUFBLDJCQUFDLFFBQUcsV0FBVSxzQkFBc0JsQixtQkFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEwQztBQUFBLElBQzFDLHVCQUFDLFFBQUcsV0FBVSxrQ0FBa0NrQixtQkFBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFzRDtBQUFBLE9BRnhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FHQTtBQUVKO0FBQUNtQyxNQVBRRDtBQUFNLElBQUFFLElBQUFiLEtBQUFFLEtBQUFJLEtBQUFJLEtBQUFFO0FBQUEsYUFBQUMsSUFBQTtBQUFBLGFBQUFiLEtBQUE7QUFBQSxhQUFBRSxLQUFBO0FBQUEsYUFBQUksS0FBQTtBQUFBLGFBQUFJLEtBQUE7QUFBQSxhQUFBRSxLQUFBIiwibmFtZXMiOlsidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJMaW5rIiwidXNlTmF2aWdhdGUiLCJ1c2VQYXJhbXMiLCJBcnJvd0xlZnQiLCJBcnJvd1JpZ2h0IiwiQ2hlY2siLCJQbHVzIiwiQXJjaGl2ZSIsIlRyYXNoMiIsIlVuZG8yIiwidXNlSGFiaXRvIiwiZGIiLCJQYWdlSGVhZGVyIiwiTW9kYWwiLCJ1c2VUb2FzdCIsIkJ1dHRvbiIsIkNBVEVHT1JZX1NUWUxFIiwiVFlQRVNfQllfQ0FURUdPUlkiLCJBTUVOSVRJRVMiLCJBTUVOSVRJRVNfQllfQ0FURUdPUlkiLCJBUkVBUyIsIkFyZWFQaWNrZXIiLCJQaW5QaWNrZXIiLCJTUEFDRV9UWVBFX0xBQkVMIiwiQ0FURUdPUllfT0ZfVFlQRSIsIlBob3RvVXBsb2FkZXIiLCJtb25leSIsImNuIiwidXNlSTE4biIsIkNBVEVHT1JJRVMiLCJPYmplY3QiLCJrZXlzIiwiU1RFUFMiLCJMaXN0U3BhY2UiLCJfcyIsIm5hdmlnYXRlIiwiaWQiLCJlZGl0aW5nSWQiLCJ0Iiwibm90aWZ5IiwicmVmcmVzaCIsIm93bmVySWQiLCJlZGl0aW5nIiwiQm9vbGVhbiIsImV4aXN0aW5nIiwic2V0RXhpc3RpbmciLCJsb2FkZWQiLCJzZXRMb2FkZWQiLCJjb25maXJtRGVsZXRlIiwic2V0Q29uZmlybURlbGV0ZSIsIndvcmtpbmciLCJzZXRXb3JraW5nIiwic3RlcCIsInNldFN0ZXAiLCJwcm9wZXJ0aWVzIiwic2V0UHJvcGVydGllcyIsInNhdmluZyIsInNldFNhdmluZyIsInNwYWNlVHlwZSIsInNldFNwYWNlVHlwZSIsInRyYW5zYWN0aW9uIiwic2V0VHJhbnNhY3Rpb24iLCJwcm9wZXJ0eUlkIiwic2V0UHJvcGVydHlJZCIsIm5ld1Byb3BlcnR5TmFtZSIsInNldE5ld1Byb3BlcnR5TmFtZSIsImFyZWEiLCJzZXRBcmVhIiwibmVpZ2hib3Job29kIiwic2V0TmVpZ2hib3Job29kIiwibmFtZSIsInNldE5hbWUiLCJhdHRycyIsInNldEF0dHJzIiwiYW1lbml0aWVzIiwic2V0QW1lbml0aWVzIiwicnVsZXMiLCJzZXRSdWxlcyIsImZhbWlseUFsbG93ZWQiLCJiYWNoZWxvckFsbG93ZWQiLCJzdHVkZW50RnJpZW5kbHkiLCJnZW5kZXJQcmVmZXJlbmNlIiwibWF4T2NjdXBhbnRzIiwicGhvdG9zIiwic2V0UGhvdG9zIiwicGluIiwic2V0UGluIiwiZmVlIiwic2V0RmVlIiwiYWxsb3dhbmNlIiwic2V0QWxsb3dhbmNlIiwicGF5aW5nIiwic2V0UGF5aW5nIiwicGhvdG9zVG91Y2hlZCIsInNldFBob3Rvc1RvdWNoZWQiLCJkcmFmdElkIiwiY3J5cHRvIiwicmFuZG9tVVVJRCIsInByaWNlIiwic2V0UHJpY2UiLCJzZXJ2aWNlQ2hhcmdlIiwic2V0U2VydmljZUNoYXJnZSIsInV0aWxpdGllcyIsInNldFV0aWxpdGllcyIsInN0YXR1cyIsInNldFN0YXR1cyIsImF2YWlsYWJsZUZyb20iLCJzZXRBdmFpbGFibGVGcm9tIiwiRGF0ZSIsInRvSVNPU3RyaW5nIiwic2xpY2UiLCJjYXRlZ29yeSIsInNlbGVjdGVkQXJlYSIsImZpbmQiLCJhIiwibGlzdGluZ0ZlZSIsInRoZW4iLCJ1c2VkIiwiaGFzUGxhbiIsImxpc3RpbmdBbGxvd2FuY2UiLCJzcGFjZSIsImF0dHJpYnV0ZXMiLCJzeW50aGV0aWMiLCJpbWFnZXMiLCJjb3N0IiwiYXZhaWxhYmlsaXR5IiwicCIsImxlbmd0aCIsInNldEF0dHIiLCJrIiwidiIsInNldExpc3RpbmdTdGF0dXMiLCJuZXh0IiwidXBkYXRlU3BhY2UiLCJkZXN0cm95IiwiZGVsZXRlU3BhY2UiLCJzYXZlRWRpdCIsImRpc2Nsb3NlZCIsInRyaW0iLCJOdW1iZXIiLCJzZWN1cml0eURlcG9zaXQiLCJhZHZhbmNlTW9udGhzIiwiZXN0aW1hdGVkTW9udGhseSIsInBsYWNlaG9sZGVySW1hZ2VzIiwicHVibGlzaCIsImFyZWFNZXRhIiwidGFyZ2V0SWQiLCJjcmVhdGVkIiwiY3JlYXRlUHJvcGVydHkiLCJhZGRyZXNzIiwiZGlzdHJpY3QiLCJnZW9ncmFwaHkiLCJsYXRpdHVkZSIsImxvY2F0aW9uU291cmNlIiwibG9uZ2l0dWRlIiwibmVhcmJ5IiwiY292ZXJJbWFnZSIsImxhYmVsIiwiY3JlYXRlU3BhY2UiLCJtYXAiLCJpIiwidXJsIiwiYWx0IiwiZGVtbyIsImRlc2NyaXB0aW9uIiwidmVyaWZpY2F0aW9uIiwib3duZXIiLCJsYXN0VXBkYXRlZCIsImNhbkFkdmFuY2UiLCJhcmNoaXZlZCIsInVuZGVmaW5lZCIsImZsYXRNYXAiLCJjIiwiZSIsInRhcmdldCIsInZhbHVlIiwiaW5wdXRDbGFzcyIsInRvTG93ZXJDYXNlIiwicGxhY2Vob2xkZXJOYW1lIiwiZmllbGRzRm9yIiwiZiIsImtpbmQiLCJrZXkiLCJjaGVja2VkIiwicGxhY2Vob2xkZXIiLCJpY29uIiwiSWNvbiIsIm9uIiwiaW5jbHVkZXMiLCJmaWx0ZXIiLCJidXlQcm9wZXJ0eVBsYW4iLCJyZXBsYWNlIiwiam9pbiIsInMiLCJ0eXBlIiwiU3RlcCIsInRpdGxlIiwiY2hpbGRyZW4iLCJfYzIiLCJGaWVsZCIsIl9jMyIsIkNoaXAiLCJhY3RpdmUiLCJvbkNsaWNrIiwiX2M0IiwiTW9uZXlJbnB1dCIsIm9uQ2hhbmdlIiwiYWxsb3dFbXB0eSIsIl9jNSIsIlJldmlldyIsIl9jNiIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkxpc3RTcGFjZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgTGluaywgdXNlTmF2aWdhdGUsIHVzZVBhcmFtcyB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XG5pbXBvcnQgeyBBcnJvd0xlZnQsIEFycm93UmlnaHQsIENoZWNrLCBQbHVzLCBBcmNoaXZlLCBUcmFzaDIsIFVuZG8yIH0gZnJvbSBcImx1Y2lkZS1yZWFjdFwiO1xuaW1wb3J0IHsgdXNlSGFiaXRvIH0gZnJvbSBcIkAvaG9va3MvdXNlSGFiaXRvXCI7XG5pbXBvcnQgeyBkYiB9IGZyb20gXCJAL2xpYi9hcGlcIjtcbmltcG9ydCB7IFBhZ2VIZWFkZXIgfSBmcm9tIFwiQC9jb21wb25lbnRzL2xheW91dC9QYWdlSGVhZGVyXCI7XG5pbXBvcnQgeyBNb2RhbCB9IGZyb20gXCJAL2NvbXBvbmVudHMvdWkvTW9kYWxcIjtcbmltcG9ydCB7IHVzZVRvYXN0IH0gZnJvbSBcIkAvY29tcG9uZW50cy91aS9Ub2FzdFwiO1xuaW1wb3J0IHsgQnV0dG9uIH0gZnJvbSBcIkAvY29tcG9uZW50cy91aS9CdXR0b25cIjtcbmltcG9ydCB7IENBVEVHT1JZX1NUWUxFLCBUWVBFU19CWV9DQVRFR09SWSwgQU1FTklUSUVTLCBBTUVOSVRJRVNfQllfQ0FURUdPUlkgfSBmcm9tIFwiQC9kYXRhL2NhdGFsb2dcIjtcbmltcG9ydCB7IEFSRUFTIH0gZnJvbSBcIkAvZGF0YS9hcmVhc1wiO1xuaW1wb3J0IHsgQXJlYVBpY2tlciB9IGZyb20gXCJAL2NvbXBvbmVudHMvdWkvQXJlYVBpY2tlclwiO1xuaW1wb3J0IHsgUGluUGlja2VyIH0gZnJvbSBcIkAvY29tcG9uZW50cy9zcGFjZS9QaW5QaWNrZXJcIjtcbmltcG9ydCB7IFNQQUNFX1RZUEVfTEFCRUwsIENBVEVHT1JZX09GX1RZUEUgfSBmcm9tIFwiQC90eXBlcy9zcGFjZVwiO1xuaW1wb3J0IHR5cGUge1xuICBBbWVuaXR5S2V5LCBBdmFpbGFiaWxpdHlTdGF0dXMsIEdlbmRlclByZWZlcmVuY2UsIExpc3RpbmdTdGF0dXMsIE9jY3VwYW5jeVJ1bGVzLCBQcm9wZXJ0eSxcbiAgU3BhY2UsIFNwYWNlQXR0cmlidXRlcywgU3BhY2VDYXRlZ29yeSwgU3BhY2VJbWFnZSwgU3BhY2VUeXBlLCBUcmFuc2FjdGlvblR5cGUsXG59IGZyb20gXCJAL3R5cGVzL3NwYWNlXCI7XG5pbXBvcnQgeyBQaG90b1VwbG9hZGVyIH0gZnJvbSBcIkAvY29tcG9uZW50cy9zcGFjZS9QaG90b1VwbG9hZGVyXCI7XG5pbXBvcnQgeyBtb25leSB9IGZyb20gXCJAL2xpYi9mb3JtYXRcIjtcbmltcG9ydCB7IGNuIH0gZnJvbSBcIkAvbGliL2NuXCI7XG5pbXBvcnQgeyB1c2VJMThuIH0gZnJvbSBcIkAvaTE4blwiO1xuXG5jb25zdCBDQVRFR09SSUVTID0gT2JqZWN0LmtleXMoQ0FURUdPUllfU1RZTEUpIGFzIFNwYWNlQ2F0ZWdvcnlbXTtcbmNvbnN0IFNURVBTID0gW1wiV2hhdFwiLCBcIldoZXJlXCIsIFwiRGV0YWlsc1wiLCBcIkluY2x1ZGVkXCIsIFwiUGhvdG9zXCIsIFwiUHJpY2VcIiwgXCJSZXZpZXdcIl07XG5cbi8qKlxuICogR3VpZGVkIGxpc3RpbmcgZmxvdy4gVGhlIERldGFpbHMgc3RlcCBhc2tzIGRpZmZlcmVudCBxdWVzdGlvbnMgcGVyIGNhdGVnb3J5IOKAlFxuICogYSBnYXJhZ2UgaXMgbmV2ZXIgYXNrZWQgaG93IG1hbnkgYmVkcm9vbXMgaXQgaGFzLlxuICovXG4vKipcbiAqIE9uZSBmb3JtLCB0d28gam9icy4gRWRpdGluZyBpcyB0aGUgc2FtZSBzaXggc3RlcHMgd2l0aCB0aGUgYW5zd2VycyBhbHJlYWR5XG4gKiBmaWxsZWQgaW4sIHNvIGFuIG93bmVyIGNvcnJlY3RpbmcgYSBwcmljZSBkb2Vzbid0IG1lZXQgYSBkaWZmZXJlbnQgc2NyZWVuLlxuICovXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBMaXN0U3BhY2UoKSB7XG4gIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcbiAgY29uc3QgeyBpZDogZWRpdGluZ0lkIH0gPSB1c2VQYXJhbXMoKTtcbiAgY29uc3QgeyB0IH0gPSB1c2VJMThuKCk7XG4gIGNvbnN0IHsgbm90aWZ5IH0gPSB1c2VUb2FzdCgpO1xuICBjb25zdCB7IHJlZnJlc2gsIG93bmVySWQgfSA9IHVzZUhhYml0bygpO1xuXG4gIGNvbnN0IGVkaXRpbmcgPSBCb29sZWFuKGVkaXRpbmdJZCk7XG4gIGNvbnN0IFtleGlzdGluZywgc2V0RXhpc3RpbmddID0gdXNlU3RhdGU8U3BhY2UgfCBudWxsPihudWxsKTtcbiAgY29uc3QgW2xvYWRlZCwgc2V0TG9hZGVkXSA9IHVzZVN0YXRlKCFlZGl0aW5nSWQpO1xuICBjb25zdCBbY29uZmlybURlbGV0ZSwgc2V0Q29uZmlybURlbGV0ZV0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFt3b3JraW5nLCBzZXRXb3JraW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcblxuICBjb25zdCBbc3RlcCwgc2V0U3RlcF0gPSB1c2VTdGF0ZSgwKTtcbiAgY29uc3QgW3Byb3BlcnRpZXMsIHNldFByb3BlcnRpZXNdID0gdXNlU3RhdGU8UHJvcGVydHlbXT4oW10pO1xuICBjb25zdCBbc2F2aW5nLCBzZXRTYXZpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xuXG4gIGNvbnN0IFtzcGFjZVR5cGUsIHNldFNwYWNlVHlwZV0gPSB1c2VTdGF0ZTxTcGFjZVR5cGU+KFwiYXBhcnRtZW50XCIpO1xuICBjb25zdCBbdHJhbnNhY3Rpb24sIHNldFRyYW5zYWN0aW9uXSA9IHVzZVN0YXRlPFRyYW5zYWN0aW9uVHlwZT4oXCJyZW50XCIpO1xuICBjb25zdCBbcHJvcGVydHlJZCwgc2V0UHJvcGVydHlJZF0gPSB1c2VTdGF0ZTxzdHJpbmc+KFwiXCIpO1xuICBjb25zdCBbbmV3UHJvcGVydHlOYW1lLCBzZXROZXdQcm9wZXJ0eU5hbWVdID0gdXNlU3RhdGUoXCJcIik7XG4gIGNvbnN0IFthcmVhLCBzZXRBcmVhXSA9IHVzZVN0YXRlKFwiTWlycHVyXCIpO1xuICBjb25zdCBbbmVpZ2hib3Job29kLCBzZXROZWlnaGJvcmhvb2RdID0gdXNlU3RhdGUoXCJcIik7XG4gIGNvbnN0IFtuYW1lLCBzZXROYW1lXSA9IHVzZVN0YXRlKFwiXCIpO1xuICBjb25zdCBbYXR0cnMsIHNldEF0dHJzXSA9IHVzZVN0YXRlPFNwYWNlQXR0cmlidXRlcz4oe30pO1xuICBjb25zdCBbYW1lbml0aWVzLCBzZXRBbWVuaXRpZXNdID0gdXNlU3RhdGU8QW1lbml0eUtleVtdPihbXSk7XG4gIGNvbnN0IFtydWxlcywgc2V0UnVsZXNdID0gdXNlU3RhdGU8T2NjdXBhbmN5UnVsZXM+KHtcbiAgICBmYW1pbHlBbGxvd2VkOiB0cnVlLFxuICAgIGJhY2hlbG9yQWxsb3dlZDogdHJ1ZSxcbiAgICBzdHVkZW50RnJpZW5kbHk6IHRydWUsXG4gICAgZ2VuZGVyUHJlZmVyZW5jZTogXCJhbnlcIixcbiAgICBtYXhPY2N1cGFudHM6IG51bGwsXG4gIH0pO1xuICBjb25zdCBbcGhvdG9zLCBzZXRQaG90b3NdID0gdXNlU3RhdGU8U3BhY2VJbWFnZVtdPihbXSk7XG4gIC8vIE51bGwgdW50aWwgdGhlIG93bmVyIGRyYWdzIHRoZSBtYXJrZXI7IHRoZSBhcmVhIGNlbnRyZSBpcyB1c2VkIG1lYW53aGlsZS5cbiAgY29uc3QgW3Bpbiwgc2V0UGluXSA9IHVzZVN0YXRlPFtudW1iZXIsIG51bWJlcl0gfCBudWxsPihudWxsKTtcbiAgY29uc3QgW2ZlZSwgc2V0RmVlXSA9IHVzZVN0YXRlPG51bWJlciB8IG51bGw+KG51bGwpO1xuICBjb25zdCBbYWxsb3dhbmNlLCBzZXRBbGxvd2FuY2VdID0gdXNlU3RhdGU8eyB1c2VkOiBudW1iZXI7IGhhc1BsYW46IGJvb2xlYW4gfSB8IG51bGw+KG51bGwpO1xuICBjb25zdCBbcGF5aW5nLCBzZXRQYXlpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xuICAvLyBXaGV0aGVyIHRoZSBvd25lciB0b3VjaGVkIHRoZSBwaG90b3MgYXQgYWxsLiBXaXRob3V0IHRoaXMsIHJlbW92aW5nIGV2ZXJ5XG4gIC8vIHBob3RvIGlzIGluZGlzdGluZ3Vpc2hhYmxlIGZyb20gbm90IG9wZW5pbmcgdGhlIHN0ZXAsIGFuZCB0aGUgb2xkIGltYWdlc1xuICAvLyBjb21lIHN0cmFpZ2h0IGJhY2sgb24gc2F2ZS5cbiAgY29uc3QgW3Bob3Rvc1RvdWNoZWQsIHNldFBob3Rvc1RvdWNoZWRdID0gdXNlU3RhdGUoZmFsc2UpO1xuICAvLyBQaG90b3MgYXJlIGZpbGVkIHVuZGVyIHRoaXMgaWQgYmVmb3JlIHRoZSBzcGFjZSByb3cgZXhpc3RzLlxuICBjb25zdCBbZHJhZnRJZF0gPSB1c2VTdGF0ZSgoKSA9PiBjcnlwdG8ucmFuZG9tVVVJRCgpKTtcbiAgY29uc3QgW3ByaWNlLCBzZXRQcmljZV0gPSB1c2VTdGF0ZSgxMjAwMCk7XG4gIGNvbnN0IFtzZXJ2aWNlQ2hhcmdlLCBzZXRTZXJ2aWNlQ2hhcmdlXSA9IHVzZVN0YXRlPG51bWJlciB8IFwiXCI+KFwiXCIpO1xuICBjb25zdCBbdXRpbGl0aWVzLCBzZXRVdGlsaXRpZXNdID0gdXNlU3RhdGU8bnVtYmVyIHwgXCJcIj4oXCJcIik7XG4gIGNvbnN0IFtzdGF0dXMsIHNldFN0YXR1c10gPSB1c2VTdGF0ZTxBdmFpbGFiaWxpdHlTdGF0dXM+KFwiYXZhaWxhYmxlXCIpO1xuICBjb25zdCBbYXZhaWxhYmxlRnJvbSwgc2V0QXZhaWxhYmxlRnJvbV0gPSB1c2VTdGF0ZShuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkuc2xpY2UoMCwgMTApKTtcblxuICBjb25zdCBjYXRlZ29yeSA9IENBVEVHT1JZX09GX1RZUEVbc3BhY2VUeXBlXTtcbiAgLyoqIFRoZSBjaG9zZW4gYXJlYSdzIGNlbnRyZSwgdXNlZCBhcyB0aGUgcGluJ3Mgc3RhcnRpbmcgcG9pbnQuICovXG4gIGNvbnN0IHNlbGVjdGVkQXJlYSA9IEFSRUFTLmZpbmQoKGEpID0+IGEubmFtZSA9PT0gYXJlYSk7XG5cbiAgLy8gV2hhdCBpdCBjb3N0cyB0byBwdWJsaXNoIHRoaXMsIGFuZCBob3cgbXVjaCBvZiB0aGUgZnJlZSBhbGxvd2FuY2UgaXMgbGVmdC5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICB2b2lkIGRiLmxpc3RpbmdGZWUoY2F0ZWdvcnkpLnRoZW4oc2V0RmVlKTtcbiAgfSwgW2NhdGVnb3J5XSk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAocHJvcGVydHlJZCA9PT0gXCJuZXdcIikge1xuICAgICAgc2V0QWxsb3dhbmNlKHsgdXNlZDogMCwgaGFzUGxhbjogZmFsc2UgfSk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIHZvaWQgZGIubGlzdGluZ0FsbG93YW5jZShwcm9wZXJ0eUlkKS50aGVuKHNldEFsbG93YW5jZSk7XG4gIH0sIFtwcm9wZXJ0eUlkXSk7XG5cbiAgLy8gRmV0Y2hlZCBieSBpZCByYXRoZXIgdGhhbiB0YWtlbiBmcm9tIHRoZSBicm93c2luZyBsaXN0LCBiZWNhdXNlIGFuXG4gIC8vIGFyY2hpdmVkIHNwYWNlIGlzIGRlbGliZXJhdGVseSBhYnNlbnQgZnJvbSB0aGF0IGxpc3QuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKCFlZGl0aW5nSWQpIHJldHVybjtcblxuICAgIHZvaWQgZGIuc3BhY2UoZWRpdGluZ0lkKS50aGVuKChzcGFjZSkgPT4ge1xuICAgICAgaWYgKHNwYWNlKSB7XG4gICAgICAgIHNldEV4aXN0aW5nKHNwYWNlKTtcbiAgICAgICAgc2V0U3BhY2VUeXBlKHNwYWNlLnNwYWNlVHlwZSk7XG4gICAgICAgIHNldFRyYW5zYWN0aW9uKHNwYWNlLnRyYW5zYWN0aW9uKTtcbiAgICAgICAgc2V0UHJvcGVydHlJZChzcGFjZS5wcm9wZXJ0eUlkKTtcbiAgICAgICAgc2V0TmFtZShzcGFjZS5uYW1lKTtcbiAgICAgICAgc2V0QXR0cnMoc3BhY2UuYXR0cmlidXRlcyk7XG4gICAgICAgIHNldEFtZW5pdGllcyhzcGFjZS5hbWVuaXRpZXMpO1xuICAgICAgICBpZiAoc3BhY2UucnVsZXMpIHNldFJ1bGVzKHNwYWNlLnJ1bGVzKTtcbiAgICAgICAgLy8gU2VlZCBpbGx1c3RyYXRpb25zIGFyZW4ndCB0aGUgb3duZXIncyBwaG90b3MsIHNvIGRvbid0IHByZXNlbnQgdGhlbVxuICAgICAgICAvLyBhcyBzb21ldGhpbmcgdGhleSB1cGxvYWRlZC5cbiAgICAgICAgc2V0UGhvdG9zKHNwYWNlLnN5bnRoZXRpYyA/IFtdIDogc3BhY2UuaW1hZ2VzKTtcbiAgICAgICAgc2V0UHJpY2Uoc3BhY2UuY29zdC5wcmljZSk7XG4gICAgICAgIHNldFNlcnZpY2VDaGFyZ2Uoc3BhY2UuY29zdC5zZXJ2aWNlQ2hhcmdlID8/IFwiXCIpO1xuICAgICAgICBzZXRVdGlsaXRpZXMoc3BhY2UuY29zdC51dGlsaXRpZXMgPz8gXCJcIik7XG4gICAgICAgIHNldFN0YXR1cyhzcGFjZS5hdmFpbGFiaWxpdHkuc3RhdHVzKTtcbiAgICAgICAgc2V0QXZhaWxhYmxlRnJvbShzcGFjZS5hdmFpbGFiaWxpdHkuYXZhaWxhYmxlRnJvbSk7XG4gICAgICB9XG4gICAgICBzZXRMb2FkZWQodHJ1ZSk7XG4gICAgfSk7XG4gIH0sIFtlZGl0aW5nSWRdKTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIHZvaWQgZGIucHJvcGVydGllcyhvd25lcklkKS50aGVuKChwKSA9PiB7XG4gICAgICBzZXRQcm9wZXJ0aWVzKHApO1xuICAgICAgaWYgKHAubGVuZ3RoICYmICFwcm9wZXJ0eUlkKSBzZXRQcm9wZXJ0eUlkKHBbMF0uaWQpO1xuICAgIH0pO1xuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSByZWFjdC1ob29rcy9leGhhdXN0aXZlLWRlcHNcbiAgfSwgW293bmVySWRdKTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIC8vIE9ubHkgd2hlbiBzdGFydGluZyBmcmVzaCDigJQgb24gYW4gZWRpdCB0aGlzIHdvdWxkIGVyYXNlIHdoYXQncyB0aGVyZS5cbiAgICBpZiAoZWRpdGluZykgcmV0dXJuO1xuICAgIHNldEF0dHJzKHt9KTtcbiAgICBzZXRBbWVuaXRpZXMoW10pO1xuICB9LCBbY2F0ZWdvcnksIGVkaXRpbmddKTtcblxuICBjb25zdCBzZXRBdHRyID0gPEsgZXh0ZW5kcyBrZXlvZiBTcGFjZUF0dHJpYnV0ZXM+KGs6IEssIHY6IFNwYWNlQXR0cmlidXRlc1tLXSkgPT5cbiAgICBzZXRBdHRycygoYSkgPT4gKHsgLi4uYSwgW2tdOiB2IH0pKTtcblxuICBjb25zdCBzZXRMaXN0aW5nU3RhdHVzID0gYXN5bmMgKG5leHQ6IExpc3RpbmdTdGF0dXMpID0+IHtcbiAgICBpZiAoIWV4aXN0aW5nKSByZXR1cm47XG4gICAgc2V0V29ya2luZyh0cnVlKTtcbiAgICBhd2FpdCBkYi51cGRhdGVTcGFjZShleGlzdGluZy5pZCwgeyBzdGF0dXM6IG5leHQgfSk7XG4gICAgYXdhaXQgcmVmcmVzaCgpO1xuICAgIHNldFdvcmtpbmcoZmFsc2UpO1xuICAgIG5vdGlmeShuZXh0ID09PSBcImFyY2hpdmVkXCIgPyB0KFwiZWRpdC5hcmNoaXZlZFwiKSA6IHQoXCJlZGl0LnJlc3RvcmVkXCIpKTtcbiAgICBuYXZpZ2F0ZShcIi9wb3J0Zm9saW9cIik7XG4gIH07XG5cbiAgY29uc3QgZGVzdHJveSA9IGFzeW5jICgpID0+IHtcbiAgICBpZiAoIWV4aXN0aW5nKSByZXR1cm47XG4gICAgc2V0V29ya2luZyh0cnVlKTtcbiAgICBhd2FpdCBkYi5kZWxldGVTcGFjZShleGlzdGluZy5pZCk7XG4gICAgYXdhaXQgcmVmcmVzaCgpO1xuICAgIHNldFdvcmtpbmcoZmFsc2UpO1xuICAgIG5vdGlmeSh0KFwiZWRpdC5kZWxldGVkXCIpKTtcbiAgICBuYXZpZ2F0ZShcIi9wb3J0Zm9saW9cIik7XG4gIH07XG5cbiAgY29uc3Qgc2F2ZUVkaXQgPSBhc3luYyAoKSA9PiB7XG4gICAgaWYgKCFleGlzdGluZykgcmV0dXJuO1xuICAgIHNldFNhdmluZyh0cnVlKTtcblxuICAgIGNvbnN0IGRpc2Nsb3NlZCA9IHNlcnZpY2VDaGFyZ2UgIT09IFwiXCIgJiYgdXRpbGl0aWVzICE9PSBcIlwiO1xuICAgIGF3YWl0IGRiLnVwZGF0ZVNwYWNlKGV4aXN0aW5nLmlkLCB7XG4gICAgICBuYW1lOiBuYW1lLnRyaW0oKSB8fCBTUEFDRV9UWVBFX0xBQkVMW3NwYWNlVHlwZV0sXG4gICAgICB0cmFuc2FjdGlvbixcbiAgICAgIGNvc3Q6IHtcbiAgICAgICAgcHJpY2UsXG4gICAgICAgIHNlcnZpY2VDaGFyZ2U6IHNlcnZpY2VDaGFyZ2UgPT09IFwiXCIgPyBudWxsIDogTnVtYmVyKHNlcnZpY2VDaGFyZ2UpLFxuICAgICAgICB1dGlsaXRpZXM6IHV0aWxpdGllcyA9PT0gXCJcIiA/IG51bGwgOiBOdW1iZXIodXRpbGl0aWVzKSxcbiAgICAgICAgc2VjdXJpdHlEZXBvc2l0OiBleGlzdGluZy5jb3N0LnNlY3VyaXR5RGVwb3NpdCxcbiAgICAgICAgYWR2YW5jZU1vbnRoczogZXhpc3RpbmcuY29zdC5hZHZhbmNlTW9udGhzLFxuICAgICAgICBlc3RpbWF0ZWRNb250aGx5OiBkaXNjbG9zZWQgPyBwcmljZSArIE51bWJlcihzZXJ2aWNlQ2hhcmdlKSArIE51bWJlcih1dGlsaXRpZXMpIDogbnVsbCxcbiAgICAgIH0sXG4gICAgICBhdHRyaWJ1dGVzOiBhdHRycyxcbiAgICAgIGFtZW5pdGllcyxcbiAgICAgIHJ1bGVzLFxuICAgICAgYXZhaWxhYmlsaXR5OiB7IC4uLmV4aXN0aW5nLmF2YWlsYWJpbGl0eSwgc3RhdHVzLCBhdmFpbGFibGVGcm9tIH0sXG4gICAgICAvLyBBbiBvd25lciB3aG8gcmVtb3ZlZCBldmVyeSBwaG90byBtZWFudCB0byByZW1vdmUgdGhlbS4gRmFsbCBiYWNrIHRvIHRoZVxuICAgICAgLy8gaWxsdXN0cmF0aW9uIHJhdGhlciB0aGFuIHF1aWV0bHkgcmVzdG9yaW5nIHdoYXQgdGhleSBkZWxldGVkLlxuICAgICAgaW1hZ2VzOiBwaG90b3NUb3VjaGVkXG4gICAgICAgID8gcGhvdG9zLmxlbmd0aFxuICAgICAgICAgID8gcGhvdG9zXG4gICAgICAgICAgOiBwbGFjZWhvbGRlckltYWdlcyhjYXRlZ29yeSwgbmFtZSB8fCBTUEFDRV9UWVBFX0xBQkVMW3NwYWNlVHlwZV0pXG4gICAgICAgIDogZXhpc3RpbmcuaW1hZ2VzLFxuICAgIH0pO1xuXG4gICAgYXdhaXQgcmVmcmVzaCgpO1xuICAgIHNldFNhdmluZyhmYWxzZSk7XG4gICAgbm90aWZ5KHQoXCJlZGl0LnNhdmVkXCIpKTtcbiAgICBuYXZpZ2F0ZShgL3NwYWNlLyR7ZXhpc3RpbmcuaWR9YCk7XG4gIH07XG5cbiAgLyoqXG4gICAqIFB1Ymxpc2hpbmcgaXMgd2hlcmUgdGhlIGZlZSBpcyB0YWtlbi5cbiAgICpcbiAgICogVGhlIHNwYWNlIGlzIGNyZWF0ZWQgZmlyc3QgYW5kIHBhaWQgZm9yIHNlY29uZCwgc28gYSBmYWlsZWQgcGF5bWVudCBsZWF2ZXNcbiAgICogYSBkcmFmdCB0aGUgb3duZXIgY2FuIHJldHVybiB0byByYXRoZXIgdGhhbiBsb3NpbmcgZXZlcnl0aGluZyB0aGV5IHR5cGVkLlxuICAgKi9cbiAgY29uc3QgcHVibGlzaCA9IGFzeW5jICgpID0+IHtcbiAgICBzZXRTYXZpbmcodHJ1ZSk7XG4gICAgY29uc3QgYXJlYU1ldGEgPSBBUkVBUy5maW5kKChhKSA9PiBhLm5hbWUgPT09IGFyZWEpITtcblxuICAgIGxldCB0YXJnZXRJZCA9IHByb3BlcnR5SWQ7XG4gICAgaWYgKHByb3BlcnR5SWQgPT09IFwiX19uZXdcIikge1xuICAgICAgY29uc3QgY3JlYXRlZCA9IGF3YWl0IGRiLmNyZWF0ZVByb3BlcnR5KHtcbiAgICAgICAgbmFtZTogbmV3UHJvcGVydHlOYW1lLnRyaW0oKSB8fCBgJHthcmVhfSBwcm9wZXJ0eWAsXG4gICAgICAgIG93bmVySWQsXG4gICAgICAgIGFyZWEsXG4gICAgICAgIG5laWdoYm9yaG9vZDogbmVpZ2hib3Job29kLnRyaW0oKSB8fCBhcmVhLFxuICAgICAgICBhZGRyZXNzOiBgJHtuZWlnaGJvcmhvb2QudHJpbSgpIHx8IGFyZWF9LCAke2FyZWF9YCxcbiAgICAgICAgZGlzdHJpY3Q6IGFyZWFNZXRhLmRpc3RyaWN0LFxuICAgICAgICBnZW9ncmFwaHk6IGFyZWFNZXRhLmdlb2dyYXBoeSxcbiAgICAgICAgbGF0aXR1ZGU6IHBpbiA/IHBpblswXSA6IGFyZWFNZXRhLmxhdGl0dWRlLFxuICAgICAgICBsb2NhdGlvblNvdXJjZTogcGluID8gKFwicGlubmVkXCIgYXMgY29uc3QpIDogKFwiYXJlYVwiIGFzIGNvbnN0KSxcbiAgICAgICAgbG9uZ2l0dWRlOiBwaW4gPyBwaW5bMV0gOiBhcmVhTWV0YS5sb25naXR1ZGUsXG4gICAgICAgIG5lYXJieTogW10sXG4gICAgICAgIGNvdmVySW1hZ2U6IGAvcGhvdG9zLyR7Y2F0ZWdvcnkgPT09IFwibGFuZFwiID8gXCJsYW5kLTFcIiA6IFwibGl2aW5nLTFcIn0uc3ZnYCxcbiAgICAgIH0pO1xuICAgICAgdGFyZ2V0SWQgPSBjcmVhdGVkLmlkO1xuICAgIH1cblxuICAgIGNvbnN0IGRpc2Nsb3NlZCA9IHNlcnZpY2VDaGFyZ2UgIT09IFwiXCIgJiYgdXRpbGl0aWVzICE9PSBcIlwiO1xuICAgIGNvbnN0IGxhYmVsID0gW1wiRXh0ZXJpb3JcIiwgXCJJbnRlcmlvclwiLCBcIkRldGFpbFwiXTtcblxuICAgIGNvbnN0IGNyZWF0ZWQgPSBhd2FpdCBkYi5jcmVhdGVTcGFjZSh7XG4gICAgICBwcm9wZXJ0eUlkOiB0YXJnZXRJZCxcbiAgICAgIG5hbWU6IG5hbWUudHJpbSgpIHx8IFNQQUNFX1RZUEVfTEFCRUxbc3BhY2VUeXBlXSxcbiAgICAgIGNhdGVnb3J5LFxuICAgICAgc3BhY2VUeXBlLFxuICAgICAgdHJhbnNhY3Rpb24sXG4gICAgICBjb3N0OiB7XG4gICAgICAgIHByaWNlLFxuICAgICAgICBzZXJ2aWNlQ2hhcmdlOiBzZXJ2aWNlQ2hhcmdlID09PSBcIlwiID8gbnVsbCA6IE51bWJlcihzZXJ2aWNlQ2hhcmdlKSxcbiAgICAgICAgdXRpbGl0aWVzOiB1dGlsaXRpZXMgPT09IFwiXCIgPyBudWxsIDogTnVtYmVyKHV0aWxpdGllcyksXG4gICAgICAgIHNlY3VyaXR5RGVwb3NpdDogbnVsbCxcbiAgICAgICAgYWR2YW5jZU1vbnRoczogdHJhbnNhY3Rpb24gPT09IFwicmVudFwiID8gMiA6IG51bGwsXG4gICAgICAgIGVzdGltYXRlZE1vbnRobHk6IGRpc2Nsb3NlZCA/IHByaWNlICsgTnVtYmVyKHNlcnZpY2VDaGFyZ2UpICsgTnVtYmVyKHV0aWxpdGllcykgOiBudWxsLFxuICAgICAgfSxcbiAgICAgIGF0dHJpYnV0ZXM6IGF0dHJzLFxuICAgICAgYW1lbml0aWVzLFxuICAgICAgcnVsZXMsXG4gICAgICBhdmFpbGFiaWxpdHk6IHsgc3RhdHVzLCBhdmFpbGFibGVGcm9tIH0sXG4gICAgICAvLyBSZWFsIHBob3RvZ3JhcGhzIHdoZXJlIHRoZSBvd25lciBnYXZlIHRoZW07IGlsbHVzdHJhdGlvbiBvdGhlcndpc2UsIHNvXG4gICAgICAvLyBhIGxpc3RpbmcgbmV2ZXIgbG9va3MgcGhvdG9ncmFwaGVkIHdoZW4gaXQgaXNuJ3QuXG4gICAgICBpbWFnZXM6IHBob3Rvcy5sZW5ndGhcbiAgICAgICAgPyBwaG90b3NcbiAgICAgICAgOiBbMCwgMV0ubWFwKChpKSA9PiAoe1xuICAgICAgICAgICAgdXJsOiBgL3Bob3Rvcy8ke2NhdGVnb3J5fS0keyhpICUgMikgKyAxfS5zdmdgLFxuICAgICAgICAgICAgbGFiZWw6IGxhYmVsW2ldLFxuICAgICAgICAgICAgYWx0OiBgSWxsdXN0cmF0aXZlIHBsYWNlaG9sZGVyIGltYWdlIGZvciAke25hbWUgfHwgU1BBQ0VfVFlQRV9MQUJFTFtzcGFjZVR5cGVdfWAsXG4gICAgICAgICAgICBkZW1vOiB0cnVlIGFzIGNvbnN0LFxuICAgICAgICAgIH0pKSxcbiAgICAgIGRlc2NyaXB0aW9uOlxuICAgICAgICBgJHtTUEFDRV9UWVBFX0xBQkVMW3NwYWNlVHlwZV19IGluICR7bmVpZ2hib3Job29kLnRyaW0oKSB8fCBhcmVhfS4gQWRkZWQgdGhyb3VnaCB0aGUgSGFiaXRvIGxpc3RpbmcgZmxvdy5gLFxuICAgICAgdmVyaWZpY2F0aW9uOiB7IGRlbW86IHRydWUsIG93bmVyOiBcImlkZW50aXR5LXN1Ym1pdHRlZFwiLCBzcGFjZTogXCJkb2N1bWVudHMtc3VibWl0dGVkXCIgfSxcbiAgICAgIHN0YXR1czogXCJwdWJsaXNoZWRcIixcbiAgICAgIGxhc3RVcGRhdGVkOiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkuc2xpY2UoMCwgMTApLFxuICAgIH0pO1xuXG4gICAgYXdhaXQgcmVmcmVzaCgpO1xuICAgIHNldFNhdmluZyhmYWxzZSk7XG4gICAgbmF2aWdhdGUoYC9zcGFjZS8ke2NyZWF0ZWQuaWR9YCk7XG4gIH07XG5cbiAgY29uc3QgY2FuQWR2YW5jZSA9ICgpID0+IHtcbiAgICBpZiAoc3RlcCA9PT0gMSkgcmV0dXJuIHByb3BlcnR5SWQgIT09IFwiXCIgJiYgKHByb3BlcnR5SWQgIT09IFwiX19uZXdcIiB8fCBuZXdQcm9wZXJ0eU5hbWUudHJpbSgpLmxlbmd0aCA+IDEpO1xuICAgIGlmIChzdGVwID09PSA1KSByZXR1cm4gcHJpY2UgPiAwO1xuICAgIHJldHVybiB0cnVlO1xuICB9O1xuXG4gIGlmICghbG9hZGVkKSB7XG4gICAgcmV0dXJuIDxkaXYgY2xhc3NOYW1lPVwiY29udGFpbmVyLXBhZ2UgcHktMjAgdGV4dC1zbSB0ZXh0LW11dGVkXCI+e3QoXCJtaXNjLmxvYWRpbmdcIil9PC9kaXY+O1xuICB9XG5cbiAgaWYgKGVkaXRpbmcgJiYgIWV4aXN0aW5nKSB7XG4gICAgcmV0dXJuIChcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29udGFpbmVyLXBhZ2UgcHktMjAgdGV4dC1jZW50ZXJcIj5cbiAgICAgICAgPGgxIGNsYXNzTmFtZT1cImZvbnQtZGlzcGxheSB0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1pbmtcIj57dChcInNwYWNlLm5vdEZvdW5kXCIpfTwvaDE+XG4gICAgICAgIDxMaW5rIHRvPVwiL3BvcnRmb2xpb1wiIGNsYXNzTmFtZT1cIm10LTUgaW5saW5lLWJsb2NrXCI+XG4gICAgICAgICAgPEJ1dHRvbj57dChcIm5hdi5wb3J0Zm9saW9cIil9PC9CdXR0b24+XG4gICAgICAgIDwvTGluaz5cbiAgICAgIDwvZGl2PlxuICAgICk7XG4gIH1cblxuICBjb25zdCBhcmNoaXZlZCA9IGV4aXN0aW5nPy5zdGF0dXMgPT09IFwiYXJjaGl2ZWRcIjtcblxuICByZXR1cm4gKFxuICAgIDw+XG4gICAgICA8UGFnZUhlYWRlclxuICAgICAgICB0aXRsZT17ZWRpdGluZyA/IHQoXCJlZGl0LnRpdGxlXCIpIDogdChcImxpc3QudGl0bGVcIil9XG4gICAgICAgIGxlYWQ9e2VkaXRpbmcgPyB0KFwiZWRpdC5sZWFkXCIpIDogdChcImxpc3QubGVhZFwiKX1cbiAgICAgICAgYWN0aW9ucz17XG4gICAgICAgICAgZWRpdGluZyA/IChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJzZWNvbmRhcnlcIlxuICAgICAgICAgICAgICAgIHNpemU9XCJzbVwiXG4gICAgICAgICAgICAgICAgZGlzYWJsZWQ9e3dvcmtpbmd9XG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gdm9pZCBzZXRMaXN0aW5nU3RhdHVzKGFyY2hpdmVkID8gXCJwdWJsaXNoZWRcIiA6IFwiYXJjaGl2ZWRcIil9XG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICB7YXJjaGl2ZWQgPyA8VW5kbzIgc2l6ZT17MTV9IGFyaWEtaGlkZGVuIC8+IDogPEFyY2hpdmUgc2l6ZT17MTV9IGFyaWEtaGlkZGVuIC8+fVxuICAgICAgICAgICAgICAgIHthcmNoaXZlZCA/IHQoXCJlZGl0LnJlc3RvcmVcIikgOiB0KFwiZWRpdC5hcmNoaXZlXCIpfVxuICAgICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwic2Vjb25kYXJ5XCIgc2l6ZT1cInNtXCIgb25DbGljaz17KCkgPT4gc2V0Q29uZmlybURlbGV0ZSh0cnVlKX0+XG4gICAgICAgICAgICAgICAgPFRyYXNoMiBzaXplPXsxNX0gYXJpYS1oaWRkZW4gLz5cbiAgICAgICAgICAgICAgICB7dChcImVkaXQuZGVsZXRlXCIpfVxuICAgICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICkgOiB1bmRlZmluZWRcbiAgICAgICAgfVxuICAgICAgLz5cblxuICAgICAge2FyY2hpdmVkICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb250YWluZXItcGFnZSBwdC02XCI+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwicm91bmRlZC1jYXJkIGJnLXdhcm4tMTAwIHAtNCB0ZXh0LXNtIGxlYWRpbmctcmVsYXhlZCB0ZXh0LXdhcm4tNzAwXCI+XG4gICAgICAgICAgICB7dChcImVkaXQuYXJjaGl2ZWROb3RpY2VcIil9XG4gICAgICAgICAgPC9wPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29udGFpbmVyLXBhZ2UgbWF4LXctM3hsIHB5LTggbWQ6cHktMTBcIj5cbiAgICAgICAgey8qIFByb2dyZXNzICovfVxuICAgICAgICA8b2wgY2xhc3NOYW1lPVwibWItOCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41XCIgYXJpYS1sYWJlbD1cIlByb2dyZXNzXCI+XG4gICAgICAgICAge1NURVBTLm1hcCgobGFiZWwsIGkpID0+IChcbiAgICAgICAgICAgIDxsaSBrZXk9e2xhYmVsfSBjbGFzc05hbWU9XCJmbGV4IGZsZXgtMSBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMVwiPlxuICAgICAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgICAgICAgICAgICAgIFwiaC0xIHJvdW5kZWQtZnVsbCB0cmFuc2l0aW9uLWNvbG9yc1wiLFxuICAgICAgICAgICAgICAgICAgICBpIDwgc3RlcCA/IFwiYmctaW5rXCIgOiBpID09PSBzdGVwID8gXCJiZy1hcXVhLTQwMFwiIDogXCJiZy1oYWlybGluZVwiLFxuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgIDxzcGFuXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgICAgICAgICAgICAgICBcIm10LTEuNSBoaWRkZW4gdGV4dC14cyBmb250LXNlbWlib2xkIHNtOmJsb2NrXCIsXG4gICAgICAgICAgICAgICAgICAgIGkgPT09IHN0ZXAgPyBcInRleHQtaW5rXCIgOiBcInRleHQtbXV0ZWRcIixcbiAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAge2xhYmVsfVxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2xpPlxuICAgICAgICAgICkpfVxuICAgICAgICA8L29sPlxuXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm91bmRlZC1jYXJkIGJnLXN1cmZhY2UgcC01IHJpbmctMSByaW5nLWhhaXJsaW5lIHNtOnAtN1wiPlxuICAgICAgICAgIHtzdGVwID09PSAwICYmIChcbiAgICAgICAgICAgIDxTdGVwIHRpdGxlPXt0KFwibGlzdC53aGF0T2ZmZXJpbmdcIil9PlxuICAgICAgICAgICAgICA8dWwgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICB7Q0FURUdPUklFUy5mbGF0TWFwKChjKSA9PiBUWVBFU19CWV9DQVRFR09SWVtjXSkubWFwKCh0KSA9PiAoXG4gICAgICAgICAgICAgICAgICA8bGkga2V5PXt0fT5cbiAgICAgICAgICAgICAgICAgICAgPENoaXAgYWN0aXZlPXtzcGFjZVR5cGUgPT09IHR9IG9uQ2xpY2s9eygpID0+IHNldFNwYWNlVHlwZSh0KX0+XG4gICAgICAgICAgICAgICAgICAgICAge1NQQUNFX1RZUEVfTEFCRUxbdF19XG4gICAgICAgICAgICAgICAgICAgIDwvQ2hpcD5cbiAgICAgICAgICAgICAgICAgIDwvbGk+XG4gICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgIDwvdWw+XG5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibWItMiBtdC02IHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1pbmstc29mdFwiPlJlbnRpbmcgaXQgb3V0LCBvciBzZWxsaW5nPzwvcD5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCByb3VuZGVkLWZ1bGwgYmctaXZvcnktZGVlcCBwLTAuNVwiPlxuICAgICAgICAgICAgICAgIHsoW1wicmVudFwiLCBcInNhbGVcIl0gYXMgVHJhbnNhY3Rpb25UeXBlW10pLm1hcCgodCkgPT4gKFxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICBrZXk9e3R9XG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICBhcmlhLXByZXNzZWQ9e3RyYW5zYWN0aW9uID09PSB0fVxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRUcmFuc2FjdGlvbih0KX1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgICAgICAgICAgICAgICBcInJvdW5kZWQtZnVsbCBweC01IHB5LTIgdGV4dC1zbSBmb250LWJvbGQgdHJhbnNpdGlvbi1jb2xvcnNcIixcbiAgICAgICAgICAgICAgICAgICAgICB0cmFuc2FjdGlvbiA9PT0gdCA/IFwiYmctaW5rIHRleHQtaXZvcnlcIiA6IFwidGV4dC1tdXRlZCBob3Zlcjp0ZXh0LWlua1wiLFxuICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICB7dCA9PT0gXCJyZW50XCIgPyBcIlJlbnRpbmdcIiA6IFwiU2VsbGluZ1wifVxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9TdGVwPlxuICAgICAgICAgICl9XG5cbiAgICAgICAgICB7c3RlcCA9PT0gMSAmJiAoXG4gICAgICAgICAgICA8U3RlcCB0aXRsZT17dChcImxpc3Qud2hlcmVJc0l0XCIpfT5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtaW5rLXNvZnRcIj5XaGljaCBwcm9wZXJ0eSBpcyB0aGlzIHNwYWNlIGluPzwvcD5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cbiAgICAgICAgICAgICAgICB7cHJvcGVydGllcy5tYXAoKHApID0+IChcbiAgICAgICAgICAgICAgICAgIDxsYWJlbFxuICAgICAgICAgICAgICAgICAgICBrZXk9e3AuaWR9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgICAgICAgICAgICAgICAgXCJmbGV4IGN1cnNvci1wb2ludGVyIGl0ZW1zLWNlbnRlciBnYXAtMyByb3VuZGVkLTJ4bCBwLTMgcmluZy0xIHRyYW5zaXRpb24tY29sb3JzXCIsXG4gICAgICAgICAgICAgICAgICAgICAgcHJvcGVydHlJZCA9PT0gcC5pZCA/IFwiYmctYXF1YS01MCByaW5nLWFxdWEtNjAwXCIgOiBcImJnLWl2b3J5IHJpbmctaGFpcmxpbmUgaG92ZXI6cmluZy1oYWlybGluZS1zdHJvbmdcIixcbiAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInJhZGlvXCJcbiAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwicHJvcGVydHlcIlxuICAgICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e3Byb3BlcnR5SWQgPT09IHAuaWR9XG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eygpID0+IHNldFByb3BlcnR5SWQocC5pZCl9XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYWNjZW50LWFxdWEtNjAwXCJcbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgPGltZyBzcmM9e3AuY292ZXJJbWFnZX0gYWx0PVwiXCIgY2xhc3NOYW1lPVwic2l6ZS0xMCByb3VuZGVkLWxnIG9iamVjdC1jb3ZlclwiIC8+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLXctMFwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRydW5jYXRlIGZvbnQtc2VtaWJvbGQgdGV4dC1pbmtcIj57cC5uYW1lfTwvcD5cbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0cnVuY2F0ZSB0ZXh0LXhzIHRleHQtbXV0ZWRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtwLm5laWdoYm9yaG9vZH0sIHtwLmFyZWF9XG4gICAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgKSl9XG5cbiAgICAgICAgICAgICAgICA8bGFiZWxcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgICAgICAgICAgICAgIFwiZmxleCBjdXJzb3ItcG9pbnRlciBpdGVtcy1jZW50ZXIgZ2FwLTMgcm91bmRlZC0yeGwgcC0zIHJpbmctMSB0cmFuc2l0aW9uLWNvbG9yc1wiLFxuICAgICAgICAgICAgICAgICAgICBwcm9wZXJ0eUlkID09PSBcIl9fbmV3XCIgPyBcImJnLWFxdWEtNTAgcmluZy1hcXVhLTYwMFwiIDogXCJiZy1pdm9yeSByaW5nLWhhaXJsaW5lIGhvdmVyOnJpbmctaGFpcmxpbmUtc3Ryb25nXCIsXG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwicmFkaW9cIlxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwicHJvcGVydHlcIlxuICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXtwcm9wZXJ0eUlkID09PSBcIl9fbmV3XCJ9XG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoKSA9PiBzZXRQcm9wZXJ0eUlkKFwiX19uZXdcIil9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImFjY2VudC1hcXVhLTYwMFwiXG4gICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZmxleCBzaXplLTEwIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciByb3VuZGVkLWxnIGJnLWl2b3J5LWRlZXAgdGV4dC1tdXRlZFwiPlxuICAgICAgICAgICAgICAgICAgICA8UGx1cyBzaXplPXsxN30gYXJpYS1oaWRkZW4gLz5cbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1pbmtcIj5BIG5ldyBwcm9wZXJ0eTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICB7cHJvcGVydHlJZCA9PT0gXCJfX25ld1wiICYmIChcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTUgZ3JpZCBnYXAtNCBzbTpncmlkLWNvbHMtMlwiPlxuICAgICAgICAgICAgICAgICAgPEZpZWxkIGxhYmVsPVwiUHJvcGVydHkgbmFtZVwiPlxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17bmV3UHJvcGVydHlOYW1lfVxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0TmV3UHJvcGVydHlOYW1lKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cImUuZy4gUmFobWFuIFZpbGxhXCJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2lucHV0Q2xhc3N9XG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICA8L0ZpZWxkPlxuICAgICAgICAgICAgICAgICAgPEZpZWxkIGxhYmVsPXt0KFwiZmlsdGVyLmFyZWFcIil9PlxuICAgICAgICAgICAgICAgICAgICA8QXJlYVBpY2tlciB2YWx1ZT17YXJlYX0gb25DaGFuZ2U9e3NldEFyZWF9IC8+XG4gICAgICAgICAgICAgICAgICA8L0ZpZWxkPlxuICAgICAgICAgICAgICAgICAgPEZpZWxkIGxhYmVsPXt0KFwibGlzdC5uZWlnaGJvdXJob29kXCIpfT5cbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e25laWdoYm9yaG9vZH1cbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldE5laWdoYm9yaG9vZChlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJlLmcuIE1pcnB1ciAxMFwiXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtpbnB1dENsYXNzfVxuICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgPC9GaWVsZD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICB7LyogT25seSBmb3IgYSBuZXcgcHJvcGVydHkg4oCUIGFuIGV4aXN0aW5nIG9uZSBhbHJlYWR5IGhhcyBhIHBpbi4gKi99XG4gICAgICAgICAgICAgIHtwcm9wZXJ0eUlkID09PSBcIm5ld1wiICYmIHNlbGVjdGVkQXJlYSAmJiAoXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC03IGJvcmRlci10IGJvcmRlci1oYWlybGluZSBwdC02XCI+XG4gICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwibWItMSBmb250LWRpc3BsYXkgZm9udC1ib2xkIHRleHQtaW5rXCI+e3QoXCJtYXAucGluVGl0bGVcIil9PC9oMz5cbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm1iLTQgdGV4dC1zbSBsZWFkaW5nLXJlbGF4ZWQgdGV4dC1tdXRlZFwiPnt0KFwibWFwLnBpbkJvZHlcIil9PC9wPlxuICAgICAgICAgICAgICAgICAgPFBpblBpY2tlclxuICAgICAgICAgICAgICAgICAgICBjZW50cmU9e1tzZWxlY3RlZEFyZWEubGF0aXR1ZGUsIHNlbGVjdGVkQXJlYS5sb25naXR1ZGVdfVxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17cGlufVxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17c2V0UGlufVxuICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDwvU3RlcD5cbiAgICAgICAgICApfVxuXG4gICAgICAgICAge3N0ZXAgPT09IDIgJiYgKFxuICAgICAgICAgICAgPFN0ZXAgdGl0bGU9e2BBYm91dCB0aGlzICR7U1BBQ0VfVFlQRV9MQUJFTFtzcGFjZVR5cGVdLnRvTG93ZXJDYXNlKCl9YH0+XG4gICAgICAgICAgICAgIDxGaWVsZCBsYWJlbD1cIk5hbWUgaXRcIj5cbiAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtuYW1lfVxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXROYW1lKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPXtwbGFjZWhvbGRlck5hbWUoc3BhY2VUeXBlKX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17aW5wdXRDbGFzc31cbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8L0ZpZWxkPlxuXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNCBncmlkIGdhcC00IHNtOmdyaWQtY29scy0yXCI+XG4gICAgICAgICAgICAgICAge2ZpZWxkc0ZvcihjYXRlZ29yeSkubWFwKChmKSA9PiAoXG4gICAgICAgICAgICAgICAgICA8RmllbGQga2V5PXtmLmtleX0gbGFiZWw9e2YubGFiZWx9PlxuICAgICAgICAgICAgICAgICAgICB7Zi5raW5kID09PSBcImJvb2xcIiA/IChcbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZmxleCBoLTExIGl0ZW1zLWNlbnRlciBnYXAtMi41IHJvdW5kZWQteGwgYmctaXZvcnkgcHgtMyB0ZXh0LXNtIHJpbmctMSByaW5nLWhhaXJsaW5lLXN0cm9uZ1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e0Jvb2xlYW4oYXR0cnNbZi5rZXldKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRBdHRyKGYua2V5LCBlLnRhcmdldC5jaGVja2VkIGFzIG5ldmVyKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwic2l6ZS00IGFjY2VudC1hcXVhLTYwMFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgWWVzXG4gICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgKSA6IGYua2luZCA9PT0gXCJ0ZXh0XCIgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17KGF0dHJzW2Yua2V5XSBhcyBzdHJpbmcpID8/IFwiXCJ9XG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEF0dHIoZi5rZXksIGUudGFyZ2V0LnZhbHVlIGFzIG5ldmVyKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPXtmLnBsYWNlaG9sZGVyfVxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtpbnB1dENsYXNzfVxuICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlucHV0TW9kZT1cIm51bWVyaWNcIlxuICAgICAgICAgICAgICAgICAgICAgICAgbWluPXswfVxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9eyhhdHRyc1tmLmtleV0gYXMgbnVtYmVyKSA/PyBcIlwifVxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRBdHRyKGYua2V5LCAoZS50YXJnZXQudmFsdWUgPT09IFwiXCIgPyB1bmRlZmluZWQgOiBOdW1iZXIoZS50YXJnZXQudmFsdWUpKSBhcyBuZXZlcil9XG4gICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj17Zi5wbGFjZWhvbGRlcn1cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17Y24oaW5wdXRDbGFzcywgXCJ0bnVtXCIpfVxuICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICA8L0ZpZWxkPlxuICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvU3RlcD5cbiAgICAgICAgICApfVxuXG4gICAgICAgICAge3N0ZXAgPT09IDMgJiYgKFxuICAgICAgICAgICAgPFN0ZXAgdGl0bGU9e3QoXCJsaXN0LndoYXRJbmNsdWRlZFwiKX0+XG4gICAgICAgICAgICAgIDx1bCBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBnYXAtMlwiPlxuICAgICAgICAgICAgICAgIHtBTUVOSVRJRVNfQllfQ0FURUdPUllbY2F0ZWdvcnldLm1hcCgoa2V5KSA9PiB7XG4gICAgICAgICAgICAgICAgICBjb25zdCB7IGxhYmVsLCBpY29uOiBJY29uIH0gPSBBTUVOSVRJRVNba2V5XTtcbiAgICAgICAgICAgICAgICAgIGNvbnN0IG9uID0gYW1lbml0aWVzLmluY2x1ZGVzKGtleSk7XG4gICAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgICA8bGkga2V5PXtrZXl9PlxuICAgICAgICAgICAgICAgICAgICAgIDxDaGlwXG4gICAgICAgICAgICAgICAgICAgICAgICBhY3RpdmU9e29ufVxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0QW1lbml0aWVzKG9uID8gYW1lbml0aWVzLmZpbHRlcigoYSkgPT4gYSAhPT0ga2V5KSA6IFsuLi5hbWVuaXRpZXMsIGtleV0pXG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgPEljb24gc2l6ZT17MTR9IGFyaWEtaGlkZGVuIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICB7bGFiZWx9XG4gICAgICAgICAgICAgICAgICAgICAgPC9DaGlwPlxuICAgICAgICAgICAgICAgICAgICA8L2xpPlxuICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICB9KX1cbiAgICAgICAgICAgICAgPC91bD5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtNCB0ZXh0LXhzIHRleHQtbXV0ZWRcIj5cbiAgICAgICAgICAgICAgICBPbmx5IHRoZSBvcHRpb25zIHRoYXQgbWFrZSBzZW5zZSBmb3IgYSB7U1BBQ0VfVFlQRV9MQUJFTFtzcGFjZVR5cGVdLnRvTG93ZXJDYXNlKCl9IGFyZSBzaG93bi5cbiAgICAgICAgICAgICAgPC9wPlxuXG4gICAgICAgICAgICAgIHtjYXRlZ29yeSA9PT0gXCJsaXZpbmdcIiAmJiAoXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC03IGJvcmRlci10IGJvcmRlci1oYWlybGluZSBwdC02XCI+XG4gICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwibWItMSBmb250LWRpc3BsYXkgZm9udC1ib2xkIHRleHQtaW5rXCI+e3QoXCJydWxlcy50aXRsZVwiKX08L2gzPlxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibWItNCB0ZXh0LXhzIHRleHQtbXV0ZWRcIj5cbiAgICAgICAgICAgICAgICAgICAgVGhpcyBpcyB0aGUgZmlyc3QgdGhpbmcgbW9zdCByZW50ZXJzIGZpbHRlciBvbiwgc28gaXQncyB3b3J0aCBnZXR0aW5nIHJpZ2h0LlxuICAgICAgICAgICAgICAgICAgPC9wPlxuXG4gICAgICAgICAgICAgICAgICA8dWwgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgPGxpPlxuICAgICAgICAgICAgICAgICAgICAgIDxDaGlwXG4gICAgICAgICAgICAgICAgICAgICAgICBhY3RpdmU9e3J1bGVzLmZhbWlseUFsbG93ZWR9XG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRSdWxlcyh7IC4uLnJ1bGVzLCBmYW1pbHlBbGxvd2VkOiAhcnVsZXMuZmFtaWx5QWxsb3dlZCB9KX1cbiAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICB7dChcImZpbHRlci5mYW1pbHlBbGxvd2VkXCIpfVxuICAgICAgICAgICAgICAgICAgICAgIDwvQ2hpcD5cbiAgICAgICAgICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICAgICAgICAgICAgPGxpPlxuICAgICAgICAgICAgICAgICAgICAgIDxDaGlwXG4gICAgICAgICAgICAgICAgICAgICAgICBhY3RpdmU9e3J1bGVzLmJhY2hlbG9yQWxsb3dlZH1cbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFJ1bGVzKHsgLi4ucnVsZXMsIGJhY2hlbG9yQWxsb3dlZDogIXJ1bGVzLmJhY2hlbG9yQWxsb3dlZCB9KX1cbiAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICB7dChcImZpbHRlci5iYWNoZWxvckFsbG93ZWRcIil9XG4gICAgICAgICAgICAgICAgICAgICAgPC9DaGlwPlxuICAgICAgICAgICAgICAgICAgICA8L2xpPlxuICAgICAgICAgICAgICAgICAgICA8bGk+XG4gICAgICAgICAgICAgICAgICAgICAgPENoaXBcbiAgICAgICAgICAgICAgICAgICAgICAgIGFjdGl2ZT17cnVsZXMuc3R1ZGVudEZyaWVuZGx5fVxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0UnVsZXMoeyAuLi5ydWxlcywgc3R1ZGVudEZyaWVuZGx5OiAhcnVsZXMuc3R1ZGVudEZyaWVuZGx5IH0pfVxuICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgIHt0KFwiZmlsdGVyLnN0dWRlbnRGcmllbmRseVwiKX1cbiAgICAgICAgICAgICAgICAgICAgICA8L0NoaXA+XG4gICAgICAgICAgICAgICAgICAgIDwvbGk+XG4gICAgICAgICAgICAgICAgICA8L3VsPlxuXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTQgZ3JpZCBnYXAtNCBzbTpncmlkLWNvbHMtMlwiPlxuICAgICAgICAgICAgICAgICAgICA8RmllbGQgbGFiZWw9XCJHZW5kZXIgcHJlZmVyZW5jZVwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxzZWxlY3RcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtydWxlcy5nZW5kZXJQcmVmZXJlbmNlfVxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRSdWxlcyh7IC4uLnJ1bGVzLCBnZW5kZXJQcmVmZXJlbmNlOiBlLnRhcmdldC52YWx1ZSBhcyBHZW5kZXJQcmVmZXJlbmNlIH0pXG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2lucHV0Q2xhc3N9XG4gICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImFueVwiPk5vIHByZWZlcmVuY2U8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJtYWxlXCI+TWVuIG9ubHk8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJmZW1hbGVcIj5Xb21lbiBvbmx5PC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgICAgICAgICAgICAgIDwvRmllbGQ+XG4gICAgICAgICAgICAgICAgICAgIDxGaWVsZCBsYWJlbD1cIk1heGltdW0gb2NjdXBhbnRzXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIG1pbj17MX1cbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtydWxlcy5tYXhPY2N1cGFudHMgPz8gXCJcIn1cbiAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiTm8gbGltaXRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRSdWxlcyh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLi4ucnVsZXMsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbWF4T2NjdXBhbnRzOiBlLnRhcmdldC52YWx1ZSA9PT0gXCJcIiA/IG51bGwgOiBOdW1iZXIoZS50YXJnZXQudmFsdWUpLFxuICAgICAgICAgICAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtjbihpbnB1dENsYXNzLCBcInRudW1cIil9XG4gICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgPC9GaWVsZD5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgPC9TdGVwPlxuICAgICAgICAgICl9XG5cbiAgICAgICAgICB7c3RlcCA9PT0gNCAmJiAoXG4gICAgICAgICAgICA8U3RlcCB0aXRsZT17dChcImxpc3QucGhvdG9zXCIpfT5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibWItNSB0ZXh0LXNtIHRleHQtbXV0ZWRcIj57dChcImxpc3QucGhvdG9zTGVhZFwiKX08L3A+XG4gICAgICAgICAgICAgIDxQaG90b1VwbG9hZGVyXG4gICAgICAgICAgICAgICAgc3BhY2VJZD17ZHJhZnRJZH1cbiAgICAgICAgICAgICAgICBpbWFnZXM9e3Bob3Rvc31cbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KG5leHQpID0+IHtcbiAgICAgICAgICAgICAgICAgIHNldFBob3Rvc1RvdWNoZWQodHJ1ZSk7XG4gICAgICAgICAgICAgICAgICBzZXRQaG90b3MobmV4dCk7XG4gICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDwvU3RlcD5cbiAgICAgICAgICApfVxuXG4gICAgICAgICAge3N0ZXAgPT09IDUgJiYgKFxuICAgICAgICAgICAgPFN0ZXAgdGl0bGU9e3QoXCJsaXN0LnByaWNlQXZhaWxhYmlsaXR5XCIpfT5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdhcC00IHNtOmdyaWQtY29scy0yXCI+XG4gICAgICAgICAgICAgICAgPEZpZWxkIGxhYmVsPXt0cmFuc2FjdGlvbiA9PT0gXCJyZW50XCIgPyBcIk1vbnRobHkgcmVudFwiIDogXCJBc2tpbmcgcHJpY2VcIn0+XG4gICAgICAgICAgICAgICAgICA8TW9uZXlJbnB1dCB2YWx1ZT17cHJpY2V9IG9uQ2hhbmdlPXtzZXRQcmljZX0gLz5cbiAgICAgICAgICAgICAgICA8L0ZpZWxkPlxuICAgICAgICAgICAgICAgIHt0cmFuc2FjdGlvbiA9PT0gXCJyZW50XCIgJiYgKFxuICAgICAgICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgICAgICAgPEZpZWxkIGxhYmVsPVwiU2VydmljZSBjaGFyZ2VcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8TW9uZXlJbnB1dCB2YWx1ZT17c2VydmljZUNoYXJnZX0gb25DaGFuZ2U9e3NldFNlcnZpY2VDaGFyZ2V9IGFsbG93RW1wdHkgLz5cbiAgICAgICAgICAgICAgICAgICAgPC9GaWVsZD5cbiAgICAgICAgICAgICAgICAgICAgPEZpZWxkIGxhYmVsPVwiVXRpbGl0aWVzXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPE1vbmV5SW5wdXQgdmFsdWU9e3V0aWxpdGllc30gb25DaGFuZ2U9e3NldFV0aWxpdGllc30gYWxsb3dFbXB0eSAvPlxuICAgICAgICAgICAgICAgICAgICA8L0ZpZWxkPlxuICAgICAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA8RmllbGQgbGFiZWw9XCJTdGF0dXNcIj5cbiAgICAgICAgICAgICAgICAgIDxzZWxlY3RcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3N0YXR1c31cbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRTdGF0dXMoZS50YXJnZXQudmFsdWUgYXMgQXZhaWxhYmlsaXR5U3RhdHVzKX1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtpbnB1dENsYXNzfVxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiYXZhaWxhYmxlXCI+QXZhaWxhYmxlPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJwYXJ0aWFsbHktYXZhaWxhYmxlXCI+UGFydGx5IGF2YWlsYWJsZTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiYXZhaWxhYmxlLXNvb25cIj5BdmFpbGFibGUgc29vbjwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwib2NjdXBpZWRcIj5PY2N1cGllZDwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwibWFpbnRlbmFuY2VcIj5NYWludGVuYW5jZTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgICAgICAgICAgPC9GaWVsZD5cbiAgICAgICAgICAgICAgICA8RmllbGQgbGFiZWw9XCJBdmFpbGFibGUgZnJvbVwiPlxuICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2F2YWlsYWJsZUZyb219XG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0QXZhaWxhYmxlRnJvbShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17aW5wdXRDbGFzc31cbiAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgPC9GaWVsZD5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAge3RyYW5zYWN0aW9uID09PSBcInJlbnRcIiAmJiAoXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtNCByb3VuZGVkLXhsIGJnLWFxdWEtNTAgcC0zIHRleHQteHMgbGVhZGluZy1yZWxheGVkIHRleHQtYXF1YS03MDBcIj5cbiAgICAgICAgICAgICAgICAgIExpc3RpbmcgZXZlcnkgY29zdCBnZXRzIHlvdXIgc3BhY2UgYSB0b3RhbC1jb3N0IGZpZ3VyZSBvbiB0aGUgY2FyZCBhbmQgbGV0cyBpdCBwYXNzXG4gICAgICAgICAgICAgICAgICB0aGUgXCJmdWxsIGNvc3QgZGlzY2xvc2VkXCIgZmlsdGVyLiBMZWF2aW5nIHRoZW0gYmxhbmsgZG9lcyB0aGUgb3Bwb3NpdGUuXG4gICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgPC9TdGVwPlxuICAgICAgICAgICl9XG5cbiAgICAgICAgICB7c3RlcCA9PT0gNiAmJiAoXG4gICAgICAgICAgICA8U3RlcCB0aXRsZT17dChcImxpc3QucmV2aWV3XCIpfT5cbiAgICAgICAgICAgICAgey8qIFRoZSBmZWUsIGFuZCB3aGF0IGl0IGJ1eXMuIFNob3duIGJlZm9yZSB0aGUgc3VtbWFyeSBzbyBpdCBpc1xuICAgICAgICAgICAgICAgICAgbmV2ZXIgYSBzdXJwcmlzZSBhdCB0aGUgbW9tZW50IG9mIHByZXNzaW5nIHB1Ymxpc2guICovfVxuICAgICAgICAgICAgICB7IWVkaXRpbmcgJiYgZmVlICE9PSBudWxsICYmIGFsbG93YW5jZSAhPT0gbnVsbCAmJiAoXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi01IHJvdW5kZWQtY2FyZCBiZy1hcXVhLTUwIHAtNCByaW5nLTEgcmluZy1hcXVhLTIwMFwiPlxuICAgICAgICAgICAgICAgICAge2FsbG93YW5jZS51c2VkIDwgMyB8fCBhbGxvd2FuY2UuaGFzUGxhbiA/IChcbiAgICAgICAgICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJmb250LWRpc3BsYXkgZm9udC1ib2xkIHRleHQtYXF1YS03MDBcIj57dChcImZlZS50aXRsZVwiKX08L3A+XG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXNtIGxlYWRpbmctcmVsYXhlZCB0ZXh0LWluay1zb2Z0XCI+e3QoXCJmZWUuYm9keVwiKX08L3A+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0zIGZsZXggZmxleC13cmFwIGl0ZW1zLWJhc2VsaW5lIGp1c3RpZnktYmV0d2VlbiBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LW11dGVkXCI+e3QoXCJmZWUuYW1vdW50XCIpfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtZGlzcGxheSB0ZXh0LXhsIGZvbnQtZXh0cmFib2xkIHRudW0gdGV4dC1pbmtcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAge21vbmV5KGZlZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgeyFhbGxvd2FuY2UuaGFzUGxhbiAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0xIHRleHQteHMgdGV4dC1tdXRlZFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICB7dChcImZlZS5mcmVlXCIsIHsgdXNlZDogYWxsb3dhbmNlLnVzZWQgKyAxIH0pfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJmb250LWRpc3BsYXkgZm9udC1ib2xkIHRleHQtd2Fybi03MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIHt0KFwiZmVlLmFsbG93YW5jZVVzZWRcIil9XG4gICAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC1zbSBsZWFkaW5nLXJlbGF4ZWQgdGV4dC1pbmstc29mdFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAge3QoXCJmZWUuYWxsb3dhbmNlQm9keVwiKX1cbiAgICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiBmb250LXNlbWlib2xkIHRudW0gdGV4dC1pbmtcIj57dChcImZlZS5wbGFuUHJpY2VcIil9PC9wPlxuICAgICAgICAgICAgICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgIHNpemU9XCJzbVwiXG4gICAgICAgICAgICAgICAgICAgICAgICB2YXJpYW50PVwic2Vjb25kYXJ5XCJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm10LTNcIlxuICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e3BheWluZ31cbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2FzeW5jICgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0UGF5aW5nKHRydWUpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGF3YWl0IGRiLmJ1eVByb3BlcnR5UGxhbihwcm9wZXJ0eUlkLCA1MDAwKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRBbGxvd2FuY2UoYXdhaXQgZGIubGlzdGluZ0FsbG93YW5jZShwcm9wZXJ0eUlkKSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbm90aWZ5KHQoXCJmZWUucGFpZFwiKSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIH0gZmluYWxseSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0UGF5aW5nKGZhbHNlKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICB7dChcImZlZS5idXlQbGFuXCIpfVxuICAgICAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTMgdGV4dC14cyBsZWFkaW5nLXJlbGF4ZWQgdGV4dC13YXJuLTcwMFwiPnt0KFwiZmVlLnNhbmRib3hcIil9PC9wPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgIDxkbCBjbGFzc05hbWU9XCJkaXZpZGUteSBkaXZpZGUtaGFpcmxpbmUgcm91bmRlZC0yeGwgYmctaXZvcnkgcmluZy0xIHJpbmctaGFpcmxpbmVcIj5cbiAgICAgICAgICAgICAgICA8UmV2aWV3IGxhYmVsPVwiU3BhY2VcIiB2YWx1ZT17YCR7bmFtZSB8fCBTUEFDRV9UWVBFX0xBQkVMW3NwYWNlVHlwZV19IMK3ICR7U1BBQ0VfVFlQRV9MQUJFTFtzcGFjZVR5cGVdfWB9IC8+XG4gICAgICAgICAgICAgICAgPFJldmlld1xuICAgICAgICAgICAgICAgICAgbGFiZWw9XCJQcm9wZXJ0eVwiXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17XG4gICAgICAgICAgICAgICAgICAgIHByb3BlcnR5SWQgPT09IFwiX19uZXdcIlxuICAgICAgICAgICAgICAgICAgICAgID8gYCR7bmV3UHJvcGVydHlOYW1lIHx8IFwiTmV3IHByb3BlcnR5XCJ9IChuZXcpIMK3ICR7YXJlYX1gXG4gICAgICAgICAgICAgICAgICAgICAgOiBwcm9wZXJ0aWVzLmZpbmQoKHApID0+IHAuaWQgPT09IHByb3BlcnR5SWQpPy5uYW1lID8/IFwi4oCUXCJcbiAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgIDxSZXZpZXdcbiAgICAgICAgICAgICAgICAgIGxhYmVsPXt0cmFuc2FjdGlvbiA9PT0gXCJyZW50XCIgPyBcIlJlbnRcIiA6IFwiUHJpY2VcIn1cbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtcbiAgICAgICAgICAgICAgICAgICAgbW9uZXkocHJpY2UpICtcbiAgICAgICAgICAgICAgICAgICAgKHRyYW5zYWN0aW9uID09PSBcInJlbnRcIiAmJiBzZXJ2aWNlQ2hhcmdlICE9PSBcIlwiICYmIHV0aWxpdGllcyAhPT0gXCJcIlxuICAgICAgICAgICAgICAgICAgICAgID8gYCDCtyBhYm91dCAke21vbmV5KHByaWNlICsgTnVtYmVyKHNlcnZpY2VDaGFyZ2UpICsgTnVtYmVyKHV0aWxpdGllcykpfSBhbGwgaW5gXG4gICAgICAgICAgICAgICAgICAgICAgOiBcIlwiKVxuICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgPFJldmlldyBsYWJlbD1cIkF2YWlsYWJpbGl0eVwiIHZhbHVlPXtzdGF0dXMucmVwbGFjZShcIi1cIiwgXCIgXCIpfSAvPlxuICAgICAgICAgICAgICAgIDxSZXZpZXcgbGFiZWw9XCJJbmNsdWRlZFwiIHZhbHVlPXthbWVuaXRpZXMubGVuZ3RoID8gYW1lbml0aWVzLm1hcCgoYSkgPT4gdChgYW1lbml0eS4ke2F9YCBhcyBuZXZlcikpLmpvaW4oXCIsIFwiKSA6IFwiTm90aGluZyBsaXN0ZWRcIn0gLz5cbiAgICAgICAgICAgICAgPC9kbD5cblxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC00IHRleHQteHMgbGVhZGluZy1yZWxheGVkIHRleHQtbXV0ZWRcIj5cbiAgICAgICAgICAgICAgICBQbGFjZWhvbGRlciBpbWFnZXMgYXJlIGF0dGFjaGVkIGF1dG9tYXRpY2FsbHkgaW4gdGhpcyBwcm90b3R5cGUuIFRoZSBzcGFjZSBpcyBzYXZlZFxuICAgICAgICAgICAgICAgIG9uIHRoaXMgZGV2aWNlIGFuZCBhcHBlYXJzIGltbWVkaWF0ZWx5IGluIHNlYXJjaCBhbmQgaW4geW91ciBwb3J0Zm9saW8uXG4gICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgIDwvU3RlcD5cbiAgICAgICAgICApfVxuXG4gICAgICAgICAgey8qIENvbnRyb2xzICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtOCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBib3JkZXItdCBib3JkZXItaGFpcmxpbmUgcHQtNVwiPlxuICAgICAgICAgICAge3N0ZXAgPiAwICYmIChcbiAgICAgICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwic2Vjb25kYXJ5XCIgb25DbGljaz17KCkgPT4gc2V0U3RlcCgocykgPT4gcyAtIDEpfT5cbiAgICAgICAgICAgICAgICA8QXJyb3dMZWZ0IHNpemU9ezE2fSBhcmlhLWhpZGRlbiAvPlxuICAgICAgICAgICAgICAgIEJhY2tcbiAgICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgICApfVxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWwtYXV0byB0ZXh0LXhzIHRudW0gdGV4dC1tdXRlZFwiPlxuICAgICAgICAgICAgICBTdGVwIHtzdGVwICsgMX0gb2Yge1NURVBTLmxlbmd0aH1cbiAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgIHtzdGVwIDwgU1RFUFMubGVuZ3RoIC0gMSA/IChcbiAgICAgICAgICAgICAgPEJ1dHRvbiBkaXNhYmxlZD17IWNhbkFkdmFuY2UoKX0gb25DbGljaz17KCkgPT4gc2V0U3RlcCgocykgPT4gcyArIDEpfT5cbiAgICAgICAgICAgICAgICBDb250aW51ZVxuICAgICAgICAgICAgICAgIDxBcnJvd1JpZ2h0IHNpemU9ezE2fSBhcmlhLWhpZGRlbiAvPlxuICAgICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgIDxCdXR0b24gZGlzYWJsZWQ9e3NhdmluZ30gb25DbGljaz17KCkgPT4gdm9pZCAoZWRpdGluZyA/IHNhdmVFZGl0KCkgOiBwdWJsaXNoKCkpfT5cbiAgICAgICAgICAgICAgICA8Q2hlY2sgc2l6ZT17MTZ9IGFyaWEtaGlkZGVuIC8+XG4gICAgICAgICAgICAgICAge3NhdmluZ1xuICAgICAgICAgICAgICAgICAgPyB0KFwiYWN0aW9uLnB1Ymxpc2hpbmdcIilcbiAgICAgICAgICAgICAgICAgIDogZWRpdGluZ1xuICAgICAgICAgICAgICAgICAgICA/IHQoXCJhY3Rpb24uc2F2ZUNoYW5nZXNcIilcbiAgICAgICAgICAgICAgICAgICAgOiAhZWRpdGluZyAmJiBmZWUgIT09IG51bGwgJiYgYWxsb3dhbmNlICE9PSBudWxsICYmIGFsbG93YW5jZS51c2VkIDwgM1xuICAgICAgICAgICAgICAgICAgICAgID8gdChcImZlZS5wYXlcIilcbiAgICAgICAgICAgICAgICAgICAgICA6IHQoXCJhY3Rpb24ucHVibGlzaFwiKX1cbiAgICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgICApfVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICA8TW9kYWxcbiAgICAgICAgb3Blbj17Y29uZmlybURlbGV0ZX1cbiAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0Q29uZmlybURlbGV0ZShmYWxzZSl9XG4gICAgICAgIHRpdGxlPXt0KFwiZWRpdC5kZWxldGVUaXRsZVwiKX1cbiAgICAgICAgZm9vdGVyPXtcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTJcIj5cbiAgICAgICAgICAgIDxCdXR0b24gdmFyaWFudD1cInNlY29uZGFyeVwiIGZ1bGxXaWR0aCBvbkNsaWNrPXsoKSA9PiBzZXRDb25maXJtRGVsZXRlKGZhbHNlKX0+XG4gICAgICAgICAgICAgIHt0KFwiYWN0aW9uLmNhbmNlbFwiKX1cbiAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwiZGVzdHJ1Y3RpdmVcIiBmdWxsV2lkdGggZGlzYWJsZWQ9e3dvcmtpbmd9IG9uQ2xpY2s9eygpID0+IHZvaWQgZGVzdHJveSgpfT5cbiAgICAgICAgICAgICAge3QoXCJlZGl0LmRlbGV0ZVwiKX1cbiAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICB9XG4gICAgICA+XG4gICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gbGVhZGluZy1yZWxheGVkIHRleHQtaW5rLXNvZnRcIj57dChcImVkaXQuZGVsZXRlQm9keVwiKX08L3A+XG4gICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTMgcm91bmRlZC14bCBiZy13YXJuLTEwMCBwLTMgdGV4dC1zbSBsZWFkaW5nLXJlbGF4ZWQgdGV4dC13YXJuLTcwMFwiPlxuICAgICAgICAgIHt0KFwiZWRpdC5kZWxldGVXYXJuaW5nXCIpfVxuICAgICAgICA8L3A+XG4gICAgICA8L01vZGFsPlxuICAgIDwvPlxuICApO1xufVxuXG4vKiogVGhlIGlsbHVzdHJhdGlvbiB1c2VkIHdoZW4gYSBsaXN0aW5nIGhhcyBubyBwaG90b2dyYXBocyBvZiBpdHMgb3duLiAqL1xuZnVuY3Rpb24gcGxhY2Vob2xkZXJJbWFnZXMoY2F0ZWdvcnk6IFNwYWNlQ2F0ZWdvcnksIGxhYmVsOiBzdHJpbmcpOiBTcGFjZUltYWdlW10ge1xuICByZXR1cm4gWzAsIDFdLm1hcCgoaSkgPT4gKHtcbiAgICB1cmw6IGAvcGhvdG9zLyR7Y2F0ZWdvcnl9LSR7KGkgJSAyKSArIDF9LnN2Z2AsXG4gICAgbGFiZWw6IGkgPT09IDAgPyBcIk1haW5cIiA6IFwiU2Vjb25kIHZpZXdcIixcbiAgICBhbHQ6IGBJbGx1c3RyYXRpdmUgcGxhY2Vob2xkZXIgaW1hZ2UgZm9yICR7bGFiZWx9YCxcbiAgICBkZW1vOiB0cnVlIGFzIGNvbnN0LFxuICB9KSk7XG59XG5cbi8qIOKUgOKUgCBBZGFwdGl2ZSBmaWVsZCBzZXRzIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgCAqL1xuXG5pbnRlcmZhY2UgRmllbGRTcGVjIHtcbiAga2V5OiBrZXlvZiBTcGFjZUF0dHJpYnV0ZXM7XG4gIGxhYmVsOiBzdHJpbmc7XG4gIGtpbmQ6IFwibnVtYmVyXCIgfCBcImJvb2xcIiB8IFwidGV4dFwiO1xuICBwbGFjZWhvbGRlcj86IHN0cmluZztcbn1cblxuZnVuY3Rpb24gZmllbGRzRm9yKGNhdGVnb3J5OiBTcGFjZUNhdGVnb3J5KTogRmllbGRTcGVjW10ge1xuICBzd2l0Y2ggKGNhdGVnb3J5KSB7XG4gICAgY2FzZSBcImxpdmluZ1wiOlxuICAgICAgcmV0dXJuIFtcbiAgICAgICAgeyBrZXk6IFwiYmVkcm9vbXNcIiwgbGFiZWw6IFwiQmVkcm9vbXNcIiwga2luZDogXCJudW1iZXJcIiwgcGxhY2Vob2xkZXI6IFwiMlwiIH0sXG4gICAgICAgIHsga2V5OiBcImJhdGhyb29tc1wiLCBsYWJlbDogXCJCYXRocm9vbXNcIiwga2luZDogXCJudW1iZXJcIiwgcGxhY2Vob2xkZXI6IFwiMlwiIH0sXG4gICAgICAgIHsga2V5OiBcInNpemVTcWZ0XCIsIGxhYmVsOiBcIlNpemUgKHNxZnQpXCIsIGtpbmQ6IFwibnVtYmVyXCIsIHBsYWNlaG9sZGVyOiBcIjk1MFwiIH0sXG4gICAgICAgIHsga2V5OiBcImZsb29yXCIsIGxhYmVsOiBcIkZsb29yXCIsIGtpbmQ6IFwibnVtYmVyXCIsIHBsYWNlaG9sZGVyOiBcIjNcIiB9LFxuICAgICAgICB7IGtleTogXCJiYWxjb255XCIsIGxhYmVsOiBcIkJhbGNvbnlcIiwga2luZDogXCJib29sXCIgfSxcbiAgICAgICAgeyBrZXk6IFwia2l0Y2hlblwiLCBsYWJlbDogXCJLaXRjaGVuXCIsIGtpbmQ6IFwiYm9vbFwiIH0sXG4gICAgICBdO1xuICAgIGNhc2UgXCJidXNpbmVzc1wiOlxuICAgICAgcmV0dXJuIFtcbiAgICAgICAgeyBrZXk6IFwic2l6ZVNxZnRcIiwgbGFiZWw6IFwiU2l6ZSAoc3FmdClcIiwga2luZDogXCJudW1iZXJcIiwgcGxhY2Vob2xkZXI6IFwiNDAwXCIgfSxcbiAgICAgICAgeyBrZXk6IFwiZmxvb3JcIiwgbGFiZWw6IFwiRmxvb3JcIiwga2luZDogXCJudW1iZXJcIiwgcGxhY2Vob2xkZXI6IFwiMCBmb3IgZ3JvdW5kXCIgfSxcbiAgICAgICAgeyBrZXk6IFwiZnJvbnRhZ2VGdFwiLCBsYWJlbDogXCJGcm9udGFnZSAoZnQpXCIsIGtpbmQ6IFwibnVtYmVyXCIsIHBsYWNlaG9sZGVyOiBcIjE0XCIgfSxcbiAgICAgICAgeyBrZXk6IFwid29ya3N0YXRpb25zXCIsIGxhYmVsOiBcIldvcmtzdGF0aW9uc1wiLCBraW5kOiBcIm51bWJlclwiLCBwbGFjZWhvbGRlcjogXCIxMlwiIH0sXG4gICAgICAgIHsga2V5OiBcIm1lZXRpbmdSb29tXCIsIGxhYmVsOiBcIk1lZXRpbmcgcm9vbVwiLCBraW5kOiBcImJvb2xcIiB9LFxuICAgICAgICB7IGtleTogXCJzdWl0YWJsZUZvclwiLCBsYWJlbDogXCJTdWl0cyB3aGljaCBidXNpbmVzc1wiLCBraW5kOiBcInRleHRcIiwgcGxhY2Vob2xkZXI6IFwiUGhhcm1hY3lcIiB9LFxuICAgICAgXTtcbiAgICBjYXNlIFwic3RvcmFnZVwiOlxuICAgICAgcmV0dXJuIFtcbiAgICAgICAgeyBrZXk6IFwic2l6ZVNxZnRcIiwgbGFiZWw6IFwiU3RvcmFnZSBhcmVhIChzcWZ0KVwiLCBraW5kOiBcIm51bWJlclwiLCBwbGFjZWhvbGRlcjogXCIxMjAwXCIgfSxcbiAgICAgICAgeyBrZXk6IFwiY2VpbGluZ0hlaWdodEZ0XCIsIGxhYmVsOiBcIkNlaWxpbmcgaGVpZ2h0IChmdClcIiwga2luZDogXCJudW1iZXJcIiwgcGxhY2Vob2xkZXI6IFwiMTRcIiB9LFxuICAgICAgICB7IGtleTogXCJsb2FkaW5nQWNjZXNzXCIsIGxhYmVsOiBcIkxvYWRpbmcgYWNjZXNzXCIsIGtpbmQ6IFwiYm9vbFwiIH0sXG4gICAgICAgIHsga2V5OiBcInZlaGljbGVBY2Nlc3NcIiwgbGFiZWw6IFwiVHJ1Y2sgYWNjZXNzXCIsIGtpbmQ6IFwiYm9vbFwiIH0sXG4gICAgICAgIHsga2V5OiBcInN1aXRhYmxlRm9yXCIsIGxhYmVsOiBcIlN1aXRhYmxlIGdvb2RzXCIsIGtpbmQ6IFwidGV4dFwiLCBwbGFjZWhvbGRlcjogXCJEcnkgZ29vZHNcIiB9LFxuICAgICAgXTtcbiAgICBjYXNlIFwicGFya2luZ1wiOlxuICAgICAgcmV0dXJuIFtcbiAgICAgICAgeyBrZXk6IFwiY2FyU2xvdHNcIiwgbGFiZWw6IFwiQ2FyIHNsb3RzXCIsIGtpbmQ6IFwibnVtYmVyXCIsIHBsYWNlaG9sZGVyOiBcIjJcIiB9LFxuICAgICAgICB7IGtleTogXCJtb3RvcmN5Y2xlU2xvdHNcIiwgbGFiZWw6IFwiTW90b3JjeWNsZSBzbG90c1wiLCBraW5kOiBcIm51bWJlclwiLCBwbGFjZWhvbGRlcjogXCI0XCIgfSxcbiAgICAgICAgeyBrZXk6IFwiY292ZXJlZFwiLCBsYWJlbDogXCJDb3ZlcmVkXCIsIGtpbmQ6IFwiYm9vbFwiIH0sXG4gICAgICAgIHsga2V5OiBcImFjY2Vzc0hvdXJzXCIsIGxhYmVsOiBcIkFjY2VzcyBob3Vyc1wiLCBraW5kOiBcInRleHRcIiwgcGxhY2Vob2xkZXI6IFwiMjQgaG91cnNcIiB9LFxuICAgICAgXTtcbiAgICBjYXNlIFwibGFuZFwiOlxuICAgICAgcmV0dXJuIFtcbiAgICAgICAgeyBrZXk6IFwibGFuZEFyZWFEZWNpbWFsXCIsIGxhYmVsOiBcIkxhbmQgYXJlYSAoZGVjaW1hbClcIiwga2luZDogXCJudW1iZXJcIiwgcGxhY2Vob2xkZXI6IFwiMzVcIiB9LFxuICAgICAgICB7IGtleTogXCJsYW5kVXNlXCIsIGxhYmVsOiBcIkxhbmQgdXNlXCIsIGtpbmQ6IFwidGV4dFwiLCBwbGFjZWhvbGRlcjogXCJQYWRkeVwiIH0sXG4gICAgICAgIHsga2V5OiBcInJvYWRBY2Nlc3NcIiwgbGFiZWw6IFwiUm9hZCBhY2Nlc3NcIiwga2luZDogXCJib29sXCIgfSxcbiAgICAgICAgeyBrZXk6IFwid2F0ZXJTb3VyY2VcIiwgbGFiZWw6IFwiV2F0ZXIgc291cmNlXCIsIGtpbmQ6IFwiYm9vbFwiIH0sXG4gICAgICAgIHsga2V5OiBcImxlYXNlWWVhcnNcIiwgbGFiZWw6IFwiTGVhc2UgbGVuZ3RoICh5ZWFycylcIiwga2luZDogXCJudW1iZXJcIiwgcGxhY2Vob2xkZXI6IFwiM1wiIH0sXG4gICAgICBdO1xuICB9XG59XG5cbmZ1bmN0aW9uIHBsYWNlaG9sZGVyTmFtZSh0eXBlOiBTcGFjZVR5cGUpOiBzdHJpbmcge1xuICBzd2l0Y2ggKHR5cGUpIHtcbiAgICBjYXNlIFwiYXBhcnRtZW50XCI6IHJldHVybiBcIkZsYXQgM0FcIjtcbiAgICBjYXNlIFwic2hvcFwiOiByZXR1cm4gXCJTaG9wIDAxXCI7XG4gICAgY2FzZSBcImdvZG93blwiOiByZXR1cm4gXCJHb2Rvd24gMDFcIjtcbiAgICBjYXNlIFwiZ2FyYWdlXCI6IHJldHVybiBcIkdhcmFnZVwiO1xuICAgIGNhc2UgXCJvZmZpY2VcIjogcmV0dXJuIFwiU2Vjb25kIGZsb29yIG9mZmljZVwiO1xuICAgIGNhc2UgXCJmYXJtbGFuZFwiOiByZXR1cm4gXCJOb3J0aCBwbG90XCI7XG4gICAgZGVmYXVsdDogcmV0dXJuIFNQQUNFX1RZUEVfTEFCRUxbdHlwZV07XG4gIH1cbn1cblxuLyog4pSA4pSAIFNtYWxsIHBpZWNlcyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIAgKi9cblxuY29uc3QgaW5wdXRDbGFzcyA9XG4gIFwiaC0xMSB3LWZ1bGwgcm91bmRlZC14bCBiZy1pdm9yeSBweC0zIHRleHQtWzAuOTM3NXJlbV0gdGV4dC1pbmsgcmluZy0xIHJpbmctaGFpcmxpbmUtc3Ryb25nIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1hcXVhLTYwMFwiO1xuXG5mdW5jdGlvbiBTdGVwKHsgdGl0bGUsIGNoaWxkcmVuIH06IHsgdGl0bGU6IHN0cmluZzsgY2hpbGRyZW46IFJlYWN0LlJlYWN0Tm9kZSB9KSB7XG4gIHJldHVybiAoXG4gICAgPGRpdj5cbiAgICAgIDxoMiBjbGFzc05hbWU9XCJtYi01IGZvbnQtZGlzcGxheSB0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LWlua1wiPnt0aXRsZX08L2gyPlxuICAgICAge2NoaWxkcmVufVxuICAgIDwvZGl2PlxuICApO1xufVxuXG5mdW5jdGlvbiBGaWVsZCh7IGxhYmVsLCBjaGlsZHJlbiB9OiB7IGxhYmVsOiBzdHJpbmc7IGNoaWxkcmVuOiBSZWFjdC5SZWFjdE5vZGUgfSkge1xuICByZXR1cm4gKFxuICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9ja1wiPlxuICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWItMS41IGJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1pbmstc29mdFwiPntsYWJlbH08L3NwYW4+XG4gICAgICB7Y2hpbGRyZW59XG4gICAgPC9sYWJlbD5cbiAgKTtcbn1cblxuZnVuY3Rpb24gQ2hpcCh7IGFjdGl2ZSwgb25DbGljaywgY2hpbGRyZW4gfTogeyBhY3RpdmU6IGJvb2xlYW47IG9uQ2xpY2s6ICgpID0+IHZvaWQ7IGNoaWxkcmVuOiBSZWFjdC5SZWFjdE5vZGUgfSkge1xuICByZXR1cm4gKFxuICAgIDxidXR0b25cbiAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgYXJpYS1wcmVzc2VkPXthY3RpdmV9XG4gICAgICBvbkNsaWNrPXtvbkNsaWNrfVxuICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgXCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSByb3VuZGVkLWZ1bGwgcHgtMy41IHB5LTIgdGV4dC1zbSBmb250LXNlbWlib2xkIHRyYW5zaXRpb24tY29sb3JzXCIsXG4gICAgICAgIGFjdGl2ZSA/IFwiYmctaW5rIHRleHQtaXZvcnlcIiA6IFwiYmctaXZvcnktZGVlcCB0ZXh0LWluay1zb2Z0IGhvdmVyOmJnLWhhaXJsaW5lXCIsXG4gICAgICApfVxuICAgID5cbiAgICAgIHtjaGlsZHJlbn1cbiAgICA8L2J1dHRvbj5cbiAgKTtcbn1cblxuZnVuY3Rpb24gTW9uZXlJbnB1dCh7XG4gIHZhbHVlLFxuICBvbkNoYW5nZSxcbiAgYWxsb3dFbXB0eSxcbn06IHtcbiAgdmFsdWU6IG51bWJlciB8IFwiXCI7XG4gIG9uQ2hhbmdlOiAodjogbmV2ZXIpID0+IHZvaWQ7XG4gIGFsbG93RW1wdHk/OiBib29sZWFuO1xufSkge1xuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmVcIj5cbiAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInBvaW50ZXItZXZlbnRzLW5vbmUgYWJzb2x1dGUgbGVmdC0zIHRvcC0xLzIgLXRyYW5zbGF0ZS15LTEvMiB0ZXh0LW11dGVkXCI+4KezPC9zcGFuPlxuICAgICAgPGlucHV0XG4gICAgICAgIHR5cGU9XCJudW1iZXJcIlxuICAgICAgICBpbnB1dE1vZGU9XCJudW1lcmljXCJcbiAgICAgICAgc3RlcD17NTAwfVxuICAgICAgICBtaW49ezB9XG4gICAgICAgIHZhbHVlPXt2YWx1ZX1cbiAgICAgICAgcGxhY2Vob2xkZXI9e2FsbG93RW1wdHkgPyBcIk5vdCBsaXN0ZWRcIiA6IHVuZGVmaW5lZH1cbiAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBvbkNoYW5nZSgoZS50YXJnZXQudmFsdWUgPT09IFwiXCIgPyBcIlwiIDogTnVtYmVyKGUudGFyZ2V0LnZhbHVlKSkgYXMgbmV2ZXIpfVxuICAgICAgICBjbGFzc05hbWU9e2NuKGlucHV0Q2xhc3MsIFwicGwtNyB0bnVtXCIpfVxuICAgICAgLz5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cblxuZnVuY3Rpb24gUmV2aWV3KHsgbGFiZWwsIHZhbHVlIH06IHsgbGFiZWw6IHN0cmluZzsgdmFsdWU6IHN0cmluZyB9KSB7XG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1iYXNlbGluZSBqdXN0aWZ5LWJldHdlZW4gZ2FwLTIgcHgtNCBweS0zXCI+XG4gICAgICA8ZHQgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LW11dGVkXCI+e2xhYmVsfTwvZHQ+XG4gICAgICA8ZGQgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtaW5rXCI+e3ZhbHVlfTwvZGQ+XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXSwiZmlsZSI6IkQ6L0kySSBQcm9qZWN0IC0gSGFiaXRvL0FwcCBGb2xkZXIvaGFiaXRvL3NyYy9wYWdlcy9MaXN0U3BhY2UudHN4In0=