import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Compare.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=9ceb86a3"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("D:/I2I Project - Habito/App Folder/habito/src/pages/Compare.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=9ceb86a3";
import { Scale, Check, X, Trash2 } from "/node_modules/.vite/deps/lucide-react.js?v=9ceb86a3";
import { useHabito } from "/src/hooks/useHabito.tsx";
import { PageHeader } from "/src/components/layout/PageHeader.tsx";
import { Button } from "/src/components/ui/Button.tsx";
import { scoreListing, distanceFromArea } from "/src/lib/matching.ts";
import { money, longDate, lastUpdatedShort } from "/src/lib/format.ts";
import { AMENITIES } from "/src/data/catalog.ts";
import { trustLevel } from "/src/components/space/badges.tsx";
import { SPACE_TYPE_LABEL, AVAILABILITY_LABEL } from "/src/types/space.ts";
import { cn } from "/src/lib/cn.ts";
import { displayImage } from "/src/lib/localize.ts";
import { useI18n } from "/src/i18n/index.tsx";
export default function Compare() {
  _s();
  const { t } = useI18n();
  const { compareIds, listings, clearCompare, toggleCompare, requirements, hasStatedNeeds } = useHabito();
  const selected = listings.filter((l) => compareIds.includes(l.space.id));
  if (selected.length === 0) {
    return /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV(PageHeader, { title: t("compare.title"), lead: t("compare.lead") }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Compare.tsx",
        lineNumber: 44,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "container-page py-10", children: /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col items-center rounded-card bg-surface px-6 py-16 text-center ring-1 ring-hairline", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "mb-4 flex size-12 items-center justify-center rounded-full bg-aqua-100 text-aqua-700", children: /* @__PURE__ */ jsxDEV(Scale, { size: 22, "aria-hidden": true }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Compare.tsx",
          lineNumber: 48,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Compare.tsx",
          lineNumber: 47,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("h2", { className: "font-display text-xl font-bold text-ink", children: "Nothing to compare yet." }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Compare.tsx",
          lineNumber: 50,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "mt-2 max-w-sm text-sm text-muted", children: "Tap the scales icon on any space and it lands in the tray at the bottom of the screen." }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Compare.tsx",
          lineNumber: 51,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(Link, { to: "/search", className: "mt-5", children: /* @__PURE__ */ jsxDEV(Button, { children: "Browse spaces" }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Compare.tsx",
          lineNumber: 55,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Compare.tsx",
          lineNumber: 54,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Compare.tsx",
        lineNumber: 46,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Compare.tsx",
        lineNumber: 45,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Compare.tsx",
      lineNumber: 43,
      columnNumber: 7
    }, this);
  }
  const scores = new Map(selected.map((l) => [l.space.id, scoreListing(l, requirements).score]));
  const bestScore = Math.max(...selected.map((l) => scores.get(l.space.id) ?? 0));
  const cheapest = Math.min(...selected.map((l) => l.space.cost.price));
  const disclosedTotals = selected.map((l) => l.space.cost.estimatedMonthly).filter((t2) => t2 !== null);
  const bestTotal = disclosedTotals.length ? Math.min(...disclosedTotals) : null;
  const sizes = selected.map((l) => l.space.attributes.sizeSqft ?? 0);
  const biggest = Math.max(...sizes);
  const distances = selected.map((l) => distanceFromArea(l, requirements.area) ?? Infinity);
  const nearest = Math.min(...distances);
  const showBedrooms = selected.some((l) => l.space.attributes.bedrooms !== void 0);
  const showSize = selected.some((l) => l.space.attributes.sizeSqft !== void 0);
  const showSlots = selected.some((l) => l.space.attributes.carSlots !== void 0);
  const showLand = selected.some((l) => l.space.attributes.landAreaDecimal !== void 0);
  const amenityRows = Object.keys(AMENITIES).filter(
    (key) => selected.some((l) => l.space.amenities.includes(key))
  );
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(
      PageHeader,
      {
        title: t("compare.title"),
        lead: `${selected.length} space${selected.length > 1 ? "s" : ""} side by side. The strongest figure in each row is highlighted.`,
        actions: /* @__PURE__ */ jsxDEV(Button, { variant: "secondary", onClick: clearCompare, children: [
          /* @__PURE__ */ jsxDEV(Trash2, { size: 16, "aria-hidden": true }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Compare.tsx",
            lineNumber: 95,
            columnNumber: 13
          }, this),
          "Clear"
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Compare.tsx",
          lineNumber: 94,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Compare.tsx",
        lineNumber: 90,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { className: "container-page py-8 md:py-10", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "overflow-x-auto rounded-card bg-surface ring-1 ring-hairline", children: /* @__PURE__ */ jsxDEV("table", { className: "w-full min-w-160 text-sm", children: [
        /* @__PURE__ */ jsxDEV("caption", { className: "sr-only", children: "Side-by-side comparison of the spaces you selected" }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Compare.tsx",
          lineNumber: 104,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("thead", { children: /* @__PURE__ */ jsxDEV("tr", { className: "border-b border-hairline", children: [
          /* @__PURE__ */ jsxDEV("th", { scope: "col", className: "w-36 px-4 py-4 text-left text-xs font-semibold uppercase tracking-wide text-muted", children: "Feature" }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Compare.tsx",
            lineNumber: 107,
            columnNumber: 17
          }, this),
          selected.map(
            (l) => /* @__PURE__ */ jsxDEV("th", { scope: "col", className: "min-w-48 px-3 py-4 text-left align-top", children: [
              /* @__PURE__ */ jsxDEV(Link, { to: `/space/${l.space.id}`, className: "block", children: [
                /* @__PURE__ */ jsxDEV("img", { src: displayImage(l.space.images[0]), alt: "", className: "mb-2 h-24 w-full rounded-xl object-cover" }, void 0, false, {
                  fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Compare.tsx",
                  lineNumber: 113,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "font-display font-bold text-ink hover:text-aqua-700", children: l.space.name }, void 0, false, {
                  fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Compare.tsx",
                  lineNumber: 114,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Compare.tsx",
                lineNumber: 112,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "mt-0.5 text-xs font-normal text-muted", children: [
                SPACE_TYPE_LABEL[l.space.spaceType],
                " · ",
                l.property.area
              ] }, void 0, true, {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Compare.tsx",
                lineNumber: 116,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "button",
                  onClick: () => toggleCompare(l.space.id),
                  className: "mt-2 inline-flex items-center gap-1 text-xs font-semibold text-muted hover:text-danger-600",
                  children: [
                    /* @__PURE__ */ jsxDEV(X, { size: 12, "aria-hidden": true }, void 0, false, {
                      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Compare.tsx",
                      lineNumber: 124,
                      columnNumber: 23
                    }, this),
                    "Remove"
                  ]
                },
                void 0,
                true,
                {
                  fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Compare.tsx",
                  lineNumber: 119,
                  columnNumber: 21
                },
                this
              )
            ] }, l.space.id, true, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Compare.tsx",
              lineNumber: 111,
              columnNumber: 17
            }, this)
          )
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Compare.tsx",
          lineNumber: 106,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Compare.tsx",
          lineNumber: 105,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("tbody", { children: [
          hasStatedNeeds && /* @__PURE__ */ jsxDEV(Row, { label: "Match", children: selected.map(
            (l) => /* @__PURE__ */ jsxDEV(Cell, { best: scores.get(l.space.id) === bestScore, children: /* @__PURE__ */ jsxDEV("span", { className: "font-display text-base font-bold", children: [
              scores.get(l.space.id),
              "%"
            ] }, void 0, true, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Compare.tsx",
              lineNumber: 136,
              columnNumber: 23
            }, this) }, l.space.id, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Compare.tsx",
              lineNumber: 135,
              columnNumber: 17
            }, this)
          ) }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Compare.tsx",
            lineNumber: 133,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(Row, { label: "Price", children: selected.map(
            (l) => /* @__PURE__ */ jsxDEV(Cell, { best: l.space.cost.price === cheapest, children: [
              money(l.space.cost.price),
              l.space.transaction === "rent" && /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-medium text-muted", children: "/mo" }, void 0, false, {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Compare.tsx",
                lineNumber: 146,
                columnNumber: 56
              }, this)
            ] }, l.space.id, true, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Compare.tsx",
              lineNumber: 144,
              columnNumber: 17
            }, this)
          ) }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Compare.tsx",
            lineNumber: 142,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(Row, { label: "Total monthly", children: selected.map(
            (l) => /* @__PURE__ */ jsxDEV(Cell, { best: bestTotal !== null && l.space.cost.estimatedMonthly === bestTotal, children: l.space.cost.estimatedMonthly ? money(l.space.cost.estimatedMonthly) : /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-medium text-warn-700", children: "Not disclosed" }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Compare.tsx",
              lineNumber: 157,
              columnNumber: 19
            }, this) }, l.space.id, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Compare.tsx",
              lineNumber: 153,
              columnNumber: 17
            }, this)
          ) }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Compare.tsx",
            lineNumber: 151,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(Row, { label: "Transaction", children: selected.map(
            (l) => /* @__PURE__ */ jsxDEV(Cell, { children: /* @__PURE__ */ jsxDEV("span", { className: "capitalize", children: l.space.transaction === "rent" ? "Rent" : "Sale" }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Compare.tsx",
              lineNumber: 166,
              columnNumber: 21
            }, this) }, l.space.id, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Compare.tsx",
              lineNumber: 165,
              columnNumber: 17
            }, this)
          ) }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Compare.tsx",
            lineNumber: 163,
            columnNumber: 15
          }, this),
          showBedrooms && /* @__PURE__ */ jsxDEV(Row, { label: "Bedrooms", children: selected.map(
            (l) => /* @__PURE__ */ jsxDEV(Cell, { children: l.space.attributes.bedrooms ?? "—" }, l.space.id, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Compare.tsx",
              lineNumber: 174,
              columnNumber: 17
            }, this)
          ) }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Compare.tsx",
            lineNumber: 172,
            columnNumber: 15
          }, this),
          showSize && /* @__PURE__ */ jsxDEV(Row, { label: "Size", children: selected.map(
            (l) => /* @__PURE__ */ jsxDEV(Cell, { best: (l.space.attributes.sizeSqft ?? 0) === biggest && biggest > 0, children: l.space.attributes.sizeSqft ? `${l.space.attributes.sizeSqft} sqft` : "—" }, l.space.id, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Compare.tsx",
              lineNumber: 182,
              columnNumber: 17
            }, this)
          ) }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Compare.tsx",
            lineNumber: 180,
            columnNumber: 15
          }, this),
          showSlots && /* @__PURE__ */ jsxDEV(Row, { label: "Slots", children: selected.map((l) => {
            const a = l.space.attributes;
            return /* @__PURE__ */ jsxDEV(Cell, { children: a.carSlots !== void 0 ? `${a.carSlots} car · ${a.motorcycleSlots ?? 0} bike` : "—" }, l.space.id, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Compare.tsx",
              lineNumber: 194,
              columnNumber: 21
            }, this);
          }) }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Compare.tsx",
            lineNumber: 190,
            columnNumber: 15
          }, this),
          showLand && /* @__PURE__ */ jsxDEV(Row, { label: "Land area", children: selected.map(
            (l) => /* @__PURE__ */ jsxDEV(Cell, { children: l.space.attributes.landAreaDecimal ? `${l.space.attributes.landAreaDecimal} decimal` : "—" }, l.space.id, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Compare.tsx",
              lineNumber: 205,
              columnNumber: 17
            }, this)
          ) }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Compare.tsx",
            lineNumber: 203,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(Row, { label: `From ${requirements.area}`, children: selected.map(
            (l, i) => /* @__PURE__ */ jsxDEV(Cell, { best: distances[i] === nearest && nearest !== Infinity, children: distances[i] === Infinity ? "—" : `${distances[i].toFixed(1)} km` }, l.space.id, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Compare.tsx",
              lineNumber: 214,
              columnNumber: 17
            }, this)
          ) }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Compare.tsx",
            lineNumber: 212,
            columnNumber: 15
          }, this),
          amenityRows.map(
            (key) => /* @__PURE__ */ jsxDEV(Row, { label: t(`amenity.${key}`), children: selected.map(
              (l) => /* @__PURE__ */ jsxDEV(Cell, { children: l.space.amenities.includes(key) ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
                /* @__PURE__ */ jsxDEV(Check, { size: 16, className: "text-ok-600", "aria-hidden": true }, void 0, false, {
                  fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Compare.tsx",
                  lineNumber: 226,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "sr-only", children: "Yes" }, void 0, false, {
                  fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Compare.tsx",
                  lineNumber: 227,
                  columnNumber: 27
                }, this)
              ] }, void 0, true, {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Compare.tsx",
                lineNumber: 225,
                columnNumber: 19
              }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
                /* @__PURE__ */ jsxDEV(X, { size: 16, className: "text-hairline-strong", "aria-hidden": true }, void 0, false, {
                  fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Compare.tsx",
                  lineNumber: 231,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "sr-only", children: "No" }, void 0, false, {
                  fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Compare.tsx",
                  lineNumber: 232,
                  columnNumber: 27
                }, this)
              ] }, void 0, true, {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Compare.tsx",
                lineNumber: 230,
                columnNumber: 19
              }, this) }, l.space.id, false, {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Compare.tsx",
                lineNumber: 223,
                columnNumber: 17
              }, this)
            ) }, key, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Compare.tsx",
              lineNumber: 221,
              columnNumber: 15
            }, this)
          ),
          /* @__PURE__ */ jsxDEV(Row, { label: "Availability", children: selected.map(
            (l) => /* @__PURE__ */ jsxDEV(Cell, { children: /* @__PURE__ */ jsxDEV("span", { className: "text-xs", children: AVAILABILITY_LABEL[l.space.availability.status] }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Compare.tsx",
              lineNumber: 243,
              columnNumber: 21
            }, this) }, l.space.id, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Compare.tsx",
              lineNumber: 242,
              columnNumber: 17
            }, this)
          ) }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Compare.tsx",
            lineNumber: 240,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(Row, { label: "Free from", children: selected.map(
            (l) => /* @__PURE__ */ jsxDEV(Cell, { children: /* @__PURE__ */ jsxDEV("span", { className: "text-xs", children: longDate(l.space.availability.availableFrom) }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Compare.tsx",
              lineNumber: 251,
              columnNumber: 21
            }, this) }, l.space.id, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Compare.tsx",
              lineNumber: 250,
              columnNumber: 17
            }, this)
          ) }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Compare.tsx",
            lineNumber: 248,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(Row, { label: "Trust", children: selected.map((l) => {
            const level = trustLevel(l.space.verification);
            return /* @__PURE__ */ jsxDEV(Cell, { children: /* @__PURE__ */ jsxDEV(
              "span",
              {
                className: cn(
                  "text-xs font-semibold",
                  level === "verified" ? "text-ok-600" : level === "in-review" ? "text-warn-700" : "text-muted"
                ),
                children: level === "verified" ? "Verified (demo)" : level === "in-review" ? "In review" : "Not verified"
              },
              void 0,
              false,
              {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Compare.tsx",
                lineNumber: 261,
                columnNumber: 23
              },
              this
            ) }, l.space.id, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Compare.tsx",
              lineNumber: 260,
              columnNumber: 21
            }, this);
          }) }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Compare.tsx",
            lineNumber: 256,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(Row, { label: "Updated", children: selected.map(
            (l) => /* @__PURE__ */ jsxDEV(Cell, { children: /* @__PURE__ */ jsxDEV("span", { className: "text-xs text-muted", children: lastUpdatedShort(l.space.lastUpdated) }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Compare.tsx",
              lineNumber: 277,
              columnNumber: 21
            }, this) }, l.space.id, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Compare.tsx",
              lineNumber: 276,
              columnNumber: 17
            }, this)
          ) }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Compare.tsx",
            lineNumber: 274,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(Row, { label: "", children: selected.map(
            (l) => /* @__PURE__ */ jsxDEV(Cell, { children: /* @__PURE__ */ jsxDEV(Link, { to: `/space/${l.space.id}`, children: /* @__PURE__ */ jsxDEV(Button, { size: "sm", variant: "secondary", children: "Open" }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Compare.tsx",
              lineNumber: 286,
              columnNumber: 23
            }, this) }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Compare.tsx",
              lineNumber: 285,
              columnNumber: 21
            }, this) }, l.space.id, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Compare.tsx",
              lineNumber: 284,
              columnNumber: 17
            }, this)
          ) }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Compare.tsx",
            lineNumber: 282,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Compare.tsx",
          lineNumber: 131,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Compare.tsx",
        lineNumber: 103,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Compare.tsx",
        lineNumber: 102,
        columnNumber: 9
      }, this),
      selected.length === 1 && /* @__PURE__ */ jsxDEV("p", { className: "mt-5 rounded-card bg-surface/70 p-4 text-sm text-ink-soft ring-1 ring-hairline-strong", children: "Add one or two more and the differences become much easier to read." }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Compare.tsx",
        lineNumber: 298,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Compare.tsx",
      lineNumber: 101,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Compare.tsx",
    lineNumber: 89,
    columnNumber: 5
  }, this);
}
_s(Compare, "aRtM902lQEHDu3+zeA1q66HeL5o=", false, function() {
  return [useI18n, useHabito];
});
_c = Compare;
function Row({ label, children }) {
  return /* @__PURE__ */ jsxDEV("tr", { className: "border-b border-hairline last:border-0", children: [
    /* @__PURE__ */ jsxDEV("th", { scope: "row", className: "px-4 py-3 text-left align-middle text-xs font-semibold text-muted", children: label }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Compare.tsx",
      lineNumber: 310,
      columnNumber: 7
    }, this),
    children
  ] }, void 0, true, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Compare.tsx",
    lineNumber: 309,
    columnNumber: 5
  }, this);
}
_c2 = Row;
function Cell({ children, best }) {
  return /* @__PURE__ */ jsxDEV("td", { className: cn("px-3 py-3 align-middle font-semibold tnum", best ? "bg-aqua-50 text-aqua-700" : "text-ink"), children: /* @__PURE__ */ jsxDEV("span", { className: "inline-flex items-center gap-1.5", children }, void 0, false, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Compare.tsx",
    lineNumber: 321,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Compare.tsx",
    lineNumber: 320,
    columnNumber: 5
  }, this);
}
_c3 = Cell;
var _c, _c2, _c3;
$RefreshReg$(_c, "Compare");
$RefreshReg$(_c2, "Row");
$RefreshReg$(_c3, "Cell");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/I2I Project - Habito/App Folder/habito/src/pages/Compare.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/I2I Project - Habito/App Folder/habito/src/pages/Compare.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdUJNLG1CQUNFLGNBREY7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBdkJOLFNBQVNBLFlBQVk7QUFDckIsU0FBU0MsT0FBT0MsT0FBT0MsR0FBR0MsY0FBYztBQUN4QyxTQUFTQyxpQkFBaUI7QUFDMUIsU0FBU0Msa0JBQWtCO0FBQzNCLFNBQVNDLGNBQWM7QUFDdkIsU0FBU0MsY0FBY0Msd0JBQXdCO0FBQy9DLFNBQVNDLE9BQU9DLFVBQVVDLHdCQUF3QjtBQUNsRCxTQUFTQyxpQkFBaUI7QUFDMUIsU0FBU0Msa0JBQWtCO0FBQzNCLFNBQVNDLGtCQUFrQkMsMEJBQTBCO0FBRXJELFNBQVNDLFVBQVU7QUFDbkIsU0FBU0Msb0JBQW9CO0FBQzdCLFNBQVNDLGVBQWU7QUFHeEIsd0JBQXdCQyxVQUFVO0FBQUFDLEtBQUE7QUFDaEMsUUFBTSxFQUFFQyxFQUFFLElBQUlILFFBQVE7QUFDdEIsUUFBTSxFQUFFSSxZQUFZQyxVQUFVQyxjQUFjQyxlQUFlQyxjQUFjQyxlQUFlLElBQUl2QixVQUFVO0FBQ3RHLFFBQU13QixXQUFXTCxTQUFTTSxPQUFPLENBQUNDLE1BQU1SLFdBQVdTLFNBQVNELEVBQUVFLE1BQU1DLEVBQUUsQ0FBQztBQUV2RSxNQUFJTCxTQUFTTSxXQUFXLEdBQUc7QUFDekIsV0FDRSxtQ0FDRTtBQUFBLDZCQUFDLGNBQVcsT0FBT2IsRUFBRSxlQUFlLEdBQUcsTUFBTUEsRUFBRSxjQUFjLEtBQTdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBK0Q7QUFBQSxNQUMvRCx1QkFBQyxTQUFJLFdBQVUsd0JBQ2IsaUNBQUMsU0FBSSxXQUFVLGtHQUNiO0FBQUEsK0JBQUMsVUFBSyxXQUFVLHdGQUNkLGlDQUFDLFNBQU0sTUFBTSxJQUFJLGVBQVcsUUFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE0QixLQUQ5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLFFBQUcsV0FBVSwyQ0FBMEMsdUNBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBK0U7QUFBQSxRQUMvRSx1QkFBQyxPQUFFLFdBQVUsb0NBQWtDLHNHQUEvQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLFFBQUssSUFBRyxXQUFVLFdBQVUsUUFDM0IsaUNBQUMsVUFBTyw2QkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXFCLEtBRHZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVdBLEtBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWFBO0FBQUEsU0FmRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBZ0JBO0FBQUEsRUFFSjtBQUVBLFFBQU1jLFNBQVMsSUFBSUMsSUFBSVIsU0FBU1MsSUFBSSxDQUFDUCxNQUFNLENBQUNBLEVBQUVFLE1BQU1DLElBQUkxQixhQUFhdUIsR0FBR0osWUFBWSxFQUFFWSxLQUFLLENBQUMsQ0FBQztBQUM3RixRQUFNQyxZQUFZQyxLQUFLQyxJQUFJLEdBQUdiLFNBQVNTLElBQUksQ0FBQ1AsTUFBTUssT0FBT08sSUFBSVosRUFBRUUsTUFBTUMsRUFBRSxLQUFLLENBQUMsQ0FBQztBQUM5RSxRQUFNVSxXQUFXSCxLQUFLSSxJQUFJLEdBQUdoQixTQUFTUyxJQUFJLENBQUNQLE1BQU1BLEVBQUVFLE1BQU1hLEtBQUtDLEtBQUssQ0FBQztBQUVwRSxRQUFNQyxrQkFBa0JuQixTQUNyQlMsSUFBSSxDQUFDUCxNQUFNQSxFQUFFRSxNQUFNYSxLQUFLRyxnQkFBZ0IsRUFDeENuQixPQUFPLENBQUNSLE9BQW1CQSxPQUFNLElBQUk7QUFDeEMsUUFBTTRCLFlBQVlGLGdCQUFnQmIsU0FBU00sS0FBS0ksSUFBSSxHQUFHRyxlQUFlLElBQUk7QUFFMUUsUUFBTUcsUUFBUXRCLFNBQVNTLElBQUksQ0FBQ1AsTUFBTUEsRUFBRUUsTUFBTW1CLFdBQVdDLFlBQVksQ0FBQztBQUNsRSxRQUFNQyxVQUFVYixLQUFLQyxJQUFJLEdBQUdTLEtBQUs7QUFFakMsUUFBTUksWUFBWTFCLFNBQVNTLElBQUksQ0FBQ1AsTUFBTXRCLGlCQUFpQnNCLEdBQUdKLGFBQWE2QixJQUFJLEtBQUtDLFFBQVE7QUFDeEYsUUFBTUMsVUFBVWpCLEtBQUtJLElBQUksR0FBR1UsU0FBUztBQUVyQyxRQUFNSSxlQUFlOUIsU0FBUytCLEtBQUssQ0FBQzdCLE1BQU1BLEVBQUVFLE1BQU1tQixXQUFXUyxhQUFhQyxNQUFTO0FBQ25GLFFBQU1DLFdBQVdsQyxTQUFTK0IsS0FBSyxDQUFDN0IsTUFBTUEsRUFBRUUsTUFBTW1CLFdBQVdDLGFBQWFTLE1BQVM7QUFDL0UsUUFBTUUsWUFBWW5DLFNBQVMrQixLQUFLLENBQUM3QixNQUFNQSxFQUFFRSxNQUFNbUIsV0FBV2EsYUFBYUgsTUFBUztBQUNoRixRQUFNSSxXQUFXckMsU0FBUytCLEtBQUssQ0FBQzdCLE1BQU1BLEVBQUVFLE1BQU1tQixXQUFXZSxvQkFBb0JMLE1BQVM7QUFHdEYsUUFBTU0sY0FBZUMsT0FBT0MsS0FBS3pELFNBQVMsRUFBbUJpQjtBQUFBQSxJQUFPLENBQUN5QyxRQUNuRTFDLFNBQVMrQixLQUFLLENBQUM3QixNQUFNQSxFQUFFRSxNQUFNdUMsVUFBVXhDLFNBQVN1QyxHQUFHLENBQUM7QUFBQSxFQUN0RDtBQUVBLFNBQ0UsbUNBQ0U7QUFBQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsT0FBT2pELEVBQUUsZUFBZTtBQUFBLFFBQ3hCLE1BQU0sR0FBR08sU0FBU00sTUFBTSxTQUFTTixTQUFTTSxTQUFTLElBQUksTUFBTSxFQUFFO0FBQUEsUUFDL0QsU0FDRSx1QkFBQyxVQUFPLFNBQVEsYUFBWSxTQUFTVixjQUNuQztBQUFBLGlDQUFDLFVBQU8sTUFBTSxJQUFJLGVBQVcsUUFBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNkI7QUFBQTtBQUFBLGFBRC9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBO0FBQUEsTUFQSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFRRztBQUFBLElBR0gsdUJBQUMsU0FBSSxXQUFVLGdDQUNiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLGdFQUNiLGlDQUFDLFdBQU0sV0FBVSw0QkFDZjtBQUFBLCtCQUFDLGFBQVEsV0FBVSxXQUFVLGtFQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQStFO0FBQUEsUUFDL0UsdUJBQUMsV0FDQyxpQ0FBQyxRQUFHLFdBQVUsNEJBQ1o7QUFBQSxpQ0FBQyxRQUFHLE9BQU0sT0FBTSxXQUFVLHFGQUFtRix1QkFBN0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0NJLFNBQVNTO0FBQUFBLFlBQUksQ0FBQ1AsTUFDYix1QkFBQyxRQUFvQixPQUFNLE9BQU0sV0FBVSwwQ0FDekM7QUFBQSxxQ0FBQyxRQUFLLElBQUksVUFBVUEsRUFBRUUsTUFBTUMsRUFBRSxJQUFJLFdBQVUsU0FDMUM7QUFBQSx1Q0FBQyxTQUFJLEtBQUtoQixhQUFhYSxFQUFFRSxNQUFNd0MsT0FBTyxDQUFDLENBQUMsR0FBRyxLQUFJLElBQUcsV0FBVSw4Q0FBNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBc0c7QUFBQSxnQkFDdEcsdUJBQUMsVUFBSyxXQUFVLHVEQUF1RDFDLFlBQUVFLE1BQU15QyxRQUEvRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFvRjtBQUFBLG1CQUZ0RjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUdBO0FBQUEsY0FDQSx1QkFBQyxPQUFFLFdBQVUseUNBQ1YzRDtBQUFBQSxpQ0FBaUJnQixFQUFFRSxNQUFNMEMsU0FBUztBQUFBLGdCQUFFO0FBQUEsZ0JBQUk1QyxFQUFFNkMsU0FBU3BCO0FBQUFBLG1CQUR0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsU0FBUyxNQUFNOUIsY0FBY0ssRUFBRUUsTUFBTUMsRUFBRTtBQUFBLGtCQUN2QyxXQUFVO0FBQUEsa0JBRVY7QUFBQSwyQ0FBQyxLQUFFLE1BQU0sSUFBSSxlQUFXLFFBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQXdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBTDFCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQU9BO0FBQUEsaUJBZk9ILEVBQUVFLE1BQU1DLElBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBZ0JBO0FBQUEsVUFDRDtBQUFBLGFBdEJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF1QkEsS0F4QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXlCQTtBQUFBLFFBQ0EsdUJBQUMsV0FDRU47QUFBQUEsNEJBQ0MsdUJBQUMsT0FBSSxPQUFNLFNBQ1JDLG1CQUFTUztBQUFBQSxZQUFJLENBQUNQLE1BQ2IsdUJBQUMsUUFBc0IsTUFBTUssT0FBT08sSUFBSVosRUFBRUUsTUFBTUMsRUFBRSxNQUFNTSxXQUN0RCxpQ0FBQyxVQUFLLFdBQVUsb0NBQW9DSjtBQUFBQSxxQkFBT08sSUFBSVosRUFBRUUsTUFBTUMsRUFBRTtBQUFBLGNBQUU7QUFBQSxpQkFBM0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNEUsS0FEbkVILEVBQUVFLE1BQU1DLElBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxVQUNELEtBTEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFNQTtBQUFBLFVBR0YsdUJBQUMsT0FBSSxPQUFNLFNBQ1JMLG1CQUFTUztBQUFBQSxZQUFJLENBQUNQLE1BQ2IsdUJBQUMsUUFBc0IsTUFBTUEsRUFBRUUsTUFBTWEsS0FBS0MsVUFBVUgsVUFDakRsQztBQUFBQSxvQkFBTXFCLEVBQUVFLE1BQU1hLEtBQUtDLEtBQUs7QUFBQSxjQUN4QmhCLEVBQUVFLE1BQU00QyxnQkFBZ0IsVUFBVSx1QkFBQyxVQUFLLFdBQVUsa0NBQWlDLG1CQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFvRDtBQUFBLGlCQUY5RTlDLEVBQUVFLE1BQU1DLElBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxVQUNELEtBTkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFPQTtBQUFBLFVBRUEsdUJBQUMsT0FBSSxPQUFNLGlCQUNSTCxtQkFBU1M7QUFBQUEsWUFBSSxDQUFDUCxNQUNiLHVCQUFDLFFBQXNCLE1BQU1tQixjQUFjLFFBQVFuQixFQUFFRSxNQUFNYSxLQUFLRyxxQkFBcUJDLFdBQ2xGbkIsWUFBRUUsTUFBTWEsS0FBS0csbUJBQ1p2QyxNQUFNcUIsRUFBRUUsTUFBTWEsS0FBS0csZ0JBQWdCLElBRW5DLHVCQUFDLFVBQUssV0FBVSxxQ0FBb0MsNkJBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWlFLEtBSjFEbEIsRUFBRUUsTUFBTUMsSUFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFNQTtBQUFBLFVBQ0QsS0FUSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVVBO0FBQUEsVUFFQSx1QkFBQyxPQUFJLE9BQU0sZUFDUkwsbUJBQVNTO0FBQUFBLFlBQUksQ0FBQ1AsTUFDYix1QkFBQyxRQUNDLGlDQUFDLFVBQUssV0FBVSxjQUFjQSxZQUFFRSxNQUFNNEMsZ0JBQWdCLFNBQVMsU0FBUyxVQUF4RTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUErRSxLQUR0RTlDLEVBQUVFLE1BQU1DLElBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxVQUNELEtBTEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFNQTtBQUFBLFVBRUN5QixnQkFDQyx1QkFBQyxPQUFJLE9BQU0sWUFDUjlCLG1CQUFTUztBQUFBQSxZQUFJLENBQUNQLE1BQ2IsdUJBQUMsUUFBdUJBLFlBQUVFLE1BQU1tQixXQUFXUyxZQUFZLE9BQTVDOUIsRUFBRUUsTUFBTUMsSUFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMkQ7QUFBQSxVQUM1RCxLQUhIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBSUE7QUFBQSxVQUdENkIsWUFDQyx1QkFBQyxPQUFJLE9BQU0sUUFDUmxDLG1CQUFTUztBQUFBQSxZQUFJLENBQUNQLE1BQ2IsdUJBQUMsUUFBc0IsT0FBT0EsRUFBRUUsTUFBTW1CLFdBQVdDLFlBQVksT0FBT0MsV0FBV0EsVUFBVSxHQUN0RnZCLFlBQUVFLE1BQU1tQixXQUFXQyxXQUFXLEdBQUd0QixFQUFFRSxNQUFNbUIsV0FBV0MsUUFBUSxVQUFVLE9BRDlEdEIsRUFBRUUsTUFBTUMsSUFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFVBQ0QsS0FMSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU1BO0FBQUEsVUFHRDhCLGFBQ0MsdUJBQUMsT0FBSSxPQUFNLFNBQ1JuQyxtQkFBU1MsSUFBSSxDQUFDUCxNQUFNO0FBQ25CLGtCQUFNK0MsSUFBSS9DLEVBQUVFLE1BQU1tQjtBQUNsQixtQkFDRSx1QkFBQyxRQUNFMEIsWUFBRWIsYUFBYUgsU0FBWSxHQUFHZ0IsRUFBRWIsUUFBUSxVQUFVYSxFQUFFQyxtQkFBbUIsQ0FBQyxVQUFVLE9BRDFFaEQsRUFBRUUsTUFBTUMsSUFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFVBRUosQ0FBQyxLQVJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBU0E7QUFBQSxVQUdEZ0MsWUFDQyx1QkFBQyxPQUFJLE9BQU0sYUFDUnJDLG1CQUFTUztBQUFBQSxZQUFJLENBQUNQLE1BQ2IsdUJBQUMsUUFDRUEsWUFBRUUsTUFBTW1CLFdBQVdlLGtCQUFrQixHQUFHcEMsRUFBRUUsTUFBTW1CLFdBQVdlLGVBQWUsYUFBYSxPQUQvRXBDLEVBQUVFLE1BQU1DLElBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxVQUNELEtBTEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFNQTtBQUFBLFVBR0YsdUJBQUMsT0FBSSxPQUFPLFFBQVFQLGFBQWE2QixJQUFJLElBQ2xDM0IsbUJBQVNTO0FBQUFBLFlBQUksQ0FBQ1AsR0FBR2lELE1BQ2hCLHVCQUFDLFFBQXNCLE1BQU16QixVQUFVeUIsQ0FBQyxNQUFNdEIsV0FBV0EsWUFBWUQsVUFDbEVGLG9CQUFVeUIsQ0FBQyxNQUFNdkIsV0FBVyxNQUFNLEdBQUdGLFVBQVV5QixDQUFDLEVBQUVDLFFBQVEsQ0FBQyxDQUFDLFNBRHBEbEQsRUFBRUUsTUFBTUMsSUFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFVBQ0QsS0FMSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU1BO0FBQUEsVUFFQ2tDLFlBQVk5QjtBQUFBQSxZQUFJLENBQUNpQyxRQUNoQix1QkFBQyxPQUFjLE9BQU9qRCxFQUFFLFdBQVdpRCxHQUFHLEVBQVcsR0FDOUMxQyxtQkFBU1M7QUFBQUEsY0FBSSxDQUFDUCxNQUNiLHVCQUFDLFFBQ0VBLFlBQUVFLE1BQU11QyxVQUFVeEMsU0FBU3VDLEdBQUcsSUFDN0IsbUNBQ0U7QUFBQSx1Q0FBQyxTQUFNLE1BQU0sSUFBSSxXQUFVLGVBQWMsZUFBVyxRQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFvRDtBQUFBLGdCQUNwRCx1QkFBQyxVQUFLLFdBQVUsV0FBVSxtQkFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBNkI7QUFBQSxtQkFGL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFHQSxJQUVBLG1DQUNFO0FBQUEsdUNBQUMsS0FBRSxNQUFNLElBQUksV0FBVSx3QkFBdUIsZUFBVyxRQUF6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF5RDtBQUFBLGdCQUN6RCx1QkFBQyxVQUFLLFdBQVUsV0FBVSxrQkFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBNEI7QUFBQSxtQkFGOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFHQSxLQVZPeEMsRUFBRUUsTUFBTUMsSUFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFZQTtBQUFBLFlBQ0QsS0FmT3FDLEtBQVY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFnQkE7QUFBQSxVQUNEO0FBQUEsVUFFRCx1QkFBQyxPQUFJLE9BQU0sZ0JBQ1IxQyxtQkFBU1M7QUFBQUEsWUFBSSxDQUFDUCxNQUNiLHVCQUFDLFFBQ0MsaUNBQUMsVUFBSyxXQUFVLFdBQVdmLDZCQUFtQmUsRUFBRUUsTUFBTWlELGFBQWFDLE1BQU0sS0FBekU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMkUsS0FEbEVwRCxFQUFFRSxNQUFNQyxJQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsVUFDRCxLQUxIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBTUE7QUFBQSxVQUVBLHVCQUFDLE9BQUksT0FBTSxhQUNSTCxtQkFBU1M7QUFBQUEsWUFBSSxDQUFDUCxNQUNiLHVCQUFDLFFBQ0MsaUNBQUMsVUFBSyxXQUFVLFdBQVdwQixtQkFBU29CLEVBQUVFLE1BQU1pRCxhQUFhRSxhQUFhLEtBQXRFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXdFLEtBRC9EckQsRUFBRUUsTUFBTUMsSUFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFVBQ0QsS0FMSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU1BO0FBQUEsVUFFQSx1QkFBQyxPQUFJLE9BQU0sU0FDUkwsbUJBQVNTLElBQUksQ0FBQ1AsTUFBTTtBQUNuQixrQkFBTXNELFFBQVF2RSxXQUFXaUIsRUFBRUUsTUFBTXFELFlBQVk7QUFDN0MsbUJBQ0UsdUJBQUMsUUFDQztBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFdBQVdyRTtBQUFBQSxrQkFDVDtBQUFBLGtCQUNBb0UsVUFBVSxhQUFhLGdCQUFnQkEsVUFBVSxjQUFjLGtCQUFrQjtBQUFBLGdCQUNuRjtBQUFBLGdCQUVDQSxvQkFBVSxhQUFhLG9CQUFvQkEsVUFBVSxjQUFjLGNBQWM7QUFBQTtBQUFBLGNBTnBGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU9BLEtBUlN0RCxFQUFFRSxNQUFNQyxJQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVNBO0FBQUEsVUFFSixDQUFDLEtBZkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFnQkE7QUFBQSxVQUVBLHVCQUFDLE9BQUksT0FBTSxXQUNSTCxtQkFBU1M7QUFBQUEsWUFBSSxDQUFDUCxNQUNiLHVCQUFDLFFBQ0MsaUNBQUMsVUFBSyxXQUFVLHNCQUFzQm5CLDJCQUFpQm1CLEVBQUVFLE1BQU1zRCxXQUFXLEtBQTFFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTRFLEtBRG5FeEQsRUFBRUUsTUFBTUMsSUFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFVBQ0QsS0FMSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU1BO0FBQUEsVUFFQSx1QkFBQyxPQUFJLE9BQU0sSUFDUkwsbUJBQVNTO0FBQUFBLFlBQUksQ0FBQ1AsTUFDYix1QkFBQyxRQUNDLGlDQUFDLFFBQUssSUFBSSxVQUFVQSxFQUFFRSxNQUFNQyxFQUFFLElBQzVCLGlDQUFDLFVBQU8sTUFBSyxNQUFLLFNBQVEsYUFBVyxvQkFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBSUEsS0FMU0gsRUFBRUUsTUFBTUMsSUFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFNQTtBQUFBLFVBQ0QsS0FUSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVVBO0FBQUEsYUFqS0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWtLQTtBQUFBLFdBOUxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUErTEEsS0FoTUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWlNQTtBQUFBLE1BRUNMLFNBQVNNLFdBQVcsS0FDbkIsdUJBQUMsT0FBRSxXQUFVLHlGQUF1RixtRkFBcEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0F2TUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXlNQTtBQUFBLE9Bck5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FzTkE7QUFFSjtBQUFDZCxHQTdRdUJELFNBQU87QUFBQSxVQUNmRCxTQUM4RWQsU0FBUztBQUFBO0FBQUEsS0FGL0VlO0FBK1F4QixTQUFTb0UsSUFBSSxFQUFFQyxPQUFPQyxTQUF1RCxHQUFHO0FBQzlFLFNBQ0UsdUJBQUMsUUFBRyxXQUFVLDBDQUNaO0FBQUEsMkJBQUMsUUFBRyxPQUFNLE9BQU0sV0FBVSxxRUFDdkJELG1CQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLElBQ0NDO0FBQUFBLE9BSkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUtBO0FBRUo7QUFBQ0MsTUFUUUg7QUFXVCxTQUFTSSxLQUFLLEVBQUVGLFVBQVVHLEtBQW9ELEdBQUc7QUFDL0UsU0FDRSx1QkFBQyxRQUFHLFdBQVc1RSxHQUFHLDZDQUE2QzRFLE9BQU8sNkJBQTZCLFVBQVUsR0FDM0csaUNBQUMsVUFBSyxXQUFVLG9DQUFvQ0gsWUFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUE2RCxLQUQvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBRUE7QUFFSjtBQUFDSSxNQU5RRjtBQUFJLElBQUFHLElBQUFKLEtBQUFHO0FBQUEsYUFBQUMsSUFBQTtBQUFBLGFBQUFKLEtBQUE7QUFBQSxhQUFBRyxLQUFBIiwibmFtZXMiOlsiTGluayIsIlNjYWxlIiwiQ2hlY2siLCJYIiwiVHJhc2gyIiwidXNlSGFiaXRvIiwiUGFnZUhlYWRlciIsIkJ1dHRvbiIsInNjb3JlTGlzdGluZyIsImRpc3RhbmNlRnJvbUFyZWEiLCJtb25leSIsImxvbmdEYXRlIiwibGFzdFVwZGF0ZWRTaG9ydCIsIkFNRU5JVElFUyIsInRydXN0TGV2ZWwiLCJTUEFDRV9UWVBFX0xBQkVMIiwiQVZBSUxBQklMSVRZX0xBQkVMIiwiY24iLCJkaXNwbGF5SW1hZ2UiLCJ1c2VJMThuIiwiQ29tcGFyZSIsIl9zIiwidCIsImNvbXBhcmVJZHMiLCJsaXN0aW5ncyIsImNsZWFyQ29tcGFyZSIsInRvZ2dsZUNvbXBhcmUiLCJyZXF1aXJlbWVudHMiLCJoYXNTdGF0ZWROZWVkcyIsInNlbGVjdGVkIiwiZmlsdGVyIiwibCIsImluY2x1ZGVzIiwic3BhY2UiLCJpZCIsImxlbmd0aCIsInNjb3JlcyIsIk1hcCIsIm1hcCIsInNjb3JlIiwiYmVzdFNjb3JlIiwiTWF0aCIsIm1heCIsImdldCIsImNoZWFwZXN0IiwibWluIiwiY29zdCIsInByaWNlIiwiZGlzY2xvc2VkVG90YWxzIiwiZXN0aW1hdGVkTW9udGhseSIsImJlc3RUb3RhbCIsInNpemVzIiwiYXR0cmlidXRlcyIsInNpemVTcWZ0IiwiYmlnZ2VzdCIsImRpc3RhbmNlcyIsImFyZWEiLCJJbmZpbml0eSIsIm5lYXJlc3QiLCJzaG93QmVkcm9vbXMiLCJzb21lIiwiYmVkcm9vbXMiLCJ1bmRlZmluZWQiLCJzaG93U2l6ZSIsInNob3dTbG90cyIsImNhclNsb3RzIiwic2hvd0xhbmQiLCJsYW5kQXJlYURlY2ltYWwiLCJhbWVuaXR5Um93cyIsIk9iamVjdCIsImtleXMiLCJrZXkiLCJhbWVuaXRpZXMiLCJpbWFnZXMiLCJuYW1lIiwic3BhY2VUeXBlIiwicHJvcGVydHkiLCJ0cmFuc2FjdGlvbiIsImEiLCJtb3RvcmN5Y2xlU2xvdHMiLCJpIiwidG9GaXhlZCIsImF2YWlsYWJpbGl0eSIsInN0YXR1cyIsImF2YWlsYWJsZUZyb20iLCJsZXZlbCIsInZlcmlmaWNhdGlvbiIsImxhc3RVcGRhdGVkIiwiUm93IiwibGFiZWwiLCJjaGlsZHJlbiIsIl9jMiIsIkNlbGwiLCJiZXN0IiwiX2MzIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQ29tcGFyZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTGluayB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XG5pbXBvcnQgeyBTY2FsZSwgQ2hlY2ssIFgsIFRyYXNoMiB9IGZyb20gXCJsdWNpZGUtcmVhY3RcIjtcbmltcG9ydCB7IHVzZUhhYml0byB9IGZyb20gXCJAL2hvb2tzL3VzZUhhYml0b1wiO1xuaW1wb3J0IHsgUGFnZUhlYWRlciB9IGZyb20gXCJAL2NvbXBvbmVudHMvbGF5b3V0L1BhZ2VIZWFkZXJcIjtcbmltcG9ydCB7IEJ1dHRvbiB9IGZyb20gXCJAL2NvbXBvbmVudHMvdWkvQnV0dG9uXCI7XG5pbXBvcnQgeyBzY29yZUxpc3RpbmcsIGRpc3RhbmNlRnJvbUFyZWEgfSBmcm9tIFwiQC9saWIvbWF0Y2hpbmdcIjtcbmltcG9ydCB7IG1vbmV5LCBsb25nRGF0ZSwgbGFzdFVwZGF0ZWRTaG9ydCB9IGZyb20gXCJAL2xpYi9mb3JtYXRcIjtcbmltcG9ydCB7IEFNRU5JVElFUyB9IGZyb20gXCJAL2RhdGEvY2F0YWxvZ1wiO1xuaW1wb3J0IHsgdHJ1c3RMZXZlbCB9IGZyb20gXCJAL2NvbXBvbmVudHMvc3BhY2UvYmFkZ2VzXCI7XG5pbXBvcnQgeyBTUEFDRV9UWVBFX0xBQkVMLCBBVkFJTEFCSUxJVFlfTEFCRUwgfSBmcm9tIFwiQC90eXBlcy9zcGFjZVwiO1xuaW1wb3J0IHR5cGUgeyBBbWVuaXR5S2V5IH0gZnJvbSBcIkAvdHlwZXMvc3BhY2VcIjtcbmltcG9ydCB7IGNuIH0gZnJvbSBcIkAvbGliL2NuXCI7XG5pbXBvcnQgeyBkaXNwbGF5SW1hZ2UgfSBmcm9tIFwiQC9saWIvbG9jYWxpemVcIjtcbmltcG9ydCB7IHVzZUkxOG4gfSBmcm9tIFwiQC9pMThuXCI7XG5cbi8qKiBSb3dzIGFkYXB0IHRvIHdoYXQncyBiZWluZyBjb21wYXJlZCDigJQgbm8gZW1wdHkgXCJiZWRyb29tc1wiIHJvdyBmb3IgYSBnYXJhZ2UuICovXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBDb21wYXJlKCkge1xuICBjb25zdCB7IHQgfSA9IHVzZUkxOG4oKTtcbiAgY29uc3QgeyBjb21wYXJlSWRzLCBsaXN0aW5ncywgY2xlYXJDb21wYXJlLCB0b2dnbGVDb21wYXJlLCByZXF1aXJlbWVudHMsIGhhc1N0YXRlZE5lZWRzIH0gPSB1c2VIYWJpdG8oKTtcbiAgY29uc3Qgc2VsZWN0ZWQgPSBsaXN0aW5ncy5maWx0ZXIoKGwpID0+IGNvbXBhcmVJZHMuaW5jbHVkZXMobC5zcGFjZS5pZCkpO1xuXG4gIGlmIChzZWxlY3RlZC5sZW5ndGggPT09IDApIHtcbiAgICByZXR1cm4gKFxuICAgICAgPD5cbiAgICAgICAgPFBhZ2VIZWFkZXIgdGl0bGU9e3QoXCJjb21wYXJlLnRpdGxlXCIpfSBsZWFkPXt0KFwiY29tcGFyZS5sZWFkXCIpfSAvPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbnRhaW5lci1wYWdlIHB5LTEwXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlciByb3VuZGVkLWNhcmQgYmctc3VyZmFjZSBweC02IHB5LTE2IHRleHQtY2VudGVyIHJpbmctMSByaW5nLWhhaXJsaW5lXCI+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtYi00IGZsZXggc2l6ZS0xMiBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC1mdWxsIGJnLWFxdWEtMTAwIHRleHQtYXF1YS03MDBcIj5cbiAgICAgICAgICAgICAgPFNjYWxlIHNpemU9ezIyfSBhcmlhLWhpZGRlbiAvPlxuICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cImZvbnQtZGlzcGxheSB0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LWlua1wiPk5vdGhpbmcgdG8gY29tcGFyZSB5ZXQuPC9oMj5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgbWF4LXctc20gdGV4dC1zbSB0ZXh0LW11dGVkXCI+XG4gICAgICAgICAgICAgIFRhcCB0aGUgc2NhbGVzIGljb24gb24gYW55IHNwYWNlIGFuZCBpdCBsYW5kcyBpbiB0aGUgdHJheSBhdCB0aGUgYm90dG9tIG9mIHRoZSBzY3JlZW4uXG4gICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICA8TGluayB0bz1cIi9zZWFyY2hcIiBjbGFzc05hbWU9XCJtdC01XCI+XG4gICAgICAgICAgICAgIDxCdXR0b24+QnJvd3NlIHNwYWNlczwvQnV0dG9uPlxuICAgICAgICAgICAgPC9MaW5rPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvPlxuICAgICk7XG4gIH1cblxuICBjb25zdCBzY29yZXMgPSBuZXcgTWFwKHNlbGVjdGVkLm1hcCgobCkgPT4gW2wuc3BhY2UuaWQsIHNjb3JlTGlzdGluZyhsLCByZXF1aXJlbWVudHMpLnNjb3JlXSkpO1xuICBjb25zdCBiZXN0U2NvcmUgPSBNYXRoLm1heCguLi5zZWxlY3RlZC5tYXAoKGwpID0+IHNjb3Jlcy5nZXQobC5zcGFjZS5pZCkgPz8gMCkpO1xuICBjb25zdCBjaGVhcGVzdCA9IE1hdGgubWluKC4uLnNlbGVjdGVkLm1hcCgobCkgPT4gbC5zcGFjZS5jb3N0LnByaWNlKSk7XG5cbiAgY29uc3QgZGlzY2xvc2VkVG90YWxzID0gc2VsZWN0ZWRcbiAgICAubWFwKChsKSA9PiBsLnNwYWNlLmNvc3QuZXN0aW1hdGVkTW9udGhseSlcbiAgICAuZmlsdGVyKCh0KTogdCBpcyBudW1iZXIgPT4gdCAhPT0gbnVsbCk7XG4gIGNvbnN0IGJlc3RUb3RhbCA9IGRpc2Nsb3NlZFRvdGFscy5sZW5ndGggPyBNYXRoLm1pbiguLi5kaXNjbG9zZWRUb3RhbHMpIDogbnVsbDtcblxuICBjb25zdCBzaXplcyA9IHNlbGVjdGVkLm1hcCgobCkgPT4gbC5zcGFjZS5hdHRyaWJ1dGVzLnNpemVTcWZ0ID8/IDApO1xuICBjb25zdCBiaWdnZXN0ID0gTWF0aC5tYXgoLi4uc2l6ZXMpO1xuXG4gIGNvbnN0IGRpc3RhbmNlcyA9IHNlbGVjdGVkLm1hcCgobCkgPT4gZGlzdGFuY2VGcm9tQXJlYShsLCByZXF1aXJlbWVudHMuYXJlYSkgPz8gSW5maW5pdHkpO1xuICBjb25zdCBuZWFyZXN0ID0gTWF0aC5taW4oLi4uZGlzdGFuY2VzKTtcblxuICBjb25zdCBzaG93QmVkcm9vbXMgPSBzZWxlY3RlZC5zb21lKChsKSA9PiBsLnNwYWNlLmF0dHJpYnV0ZXMuYmVkcm9vbXMgIT09IHVuZGVmaW5lZCk7XG4gIGNvbnN0IHNob3dTaXplID0gc2VsZWN0ZWQuc29tZSgobCkgPT4gbC5zcGFjZS5hdHRyaWJ1dGVzLnNpemVTcWZ0ICE9PSB1bmRlZmluZWQpO1xuICBjb25zdCBzaG93U2xvdHMgPSBzZWxlY3RlZC5zb21lKChsKSA9PiBsLnNwYWNlLmF0dHJpYnV0ZXMuY2FyU2xvdHMgIT09IHVuZGVmaW5lZCk7XG4gIGNvbnN0IHNob3dMYW5kID0gc2VsZWN0ZWQuc29tZSgobCkgPT4gbC5zcGFjZS5hdHRyaWJ1dGVzLmxhbmRBcmVhRGVjaW1hbCAhPT0gdW5kZWZpbmVkKTtcblxuICAvLyBPbmx5IGNvbXBhcmUgYW1lbml0aWVzIGF0IGxlYXN0IG9uZSBzcGFjZSBhY3R1YWxseSBoYXMuXG4gIGNvbnN0IGFtZW5pdHlSb3dzID0gKE9iamVjdC5rZXlzKEFNRU5JVElFUykgYXMgQW1lbml0eUtleVtdKS5maWx0ZXIoKGtleSkgPT5cbiAgICBzZWxlY3RlZC5zb21lKChsKSA9PiBsLnNwYWNlLmFtZW5pdGllcy5pbmNsdWRlcyhrZXkpKSxcbiAgKTtcblxuICByZXR1cm4gKFxuICAgIDw+XG4gICAgICA8UGFnZUhlYWRlclxuICAgICAgICB0aXRsZT17dChcImNvbXBhcmUudGl0bGVcIil9XG4gICAgICAgIGxlYWQ9e2Ake3NlbGVjdGVkLmxlbmd0aH0gc3BhY2Uke3NlbGVjdGVkLmxlbmd0aCA+IDEgPyBcInNcIiA6IFwiXCJ9IHNpZGUgYnkgc2lkZS4gVGhlIHN0cm9uZ2VzdCBmaWd1cmUgaW4gZWFjaCByb3cgaXMgaGlnaGxpZ2h0ZWQuYH1cbiAgICAgICAgYWN0aW9ucz17XG4gICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwic2Vjb25kYXJ5XCIgb25DbGljaz17Y2xlYXJDb21wYXJlfT5cbiAgICAgICAgICAgIDxUcmFzaDIgc2l6ZT17MTZ9IGFyaWEtaGlkZGVuIC8+XG4gICAgICAgICAgICBDbGVhclxuICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICB9XG4gICAgICAvPlxuXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbnRhaW5lci1wYWdlIHB5LTggbWQ6cHktMTBcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJvdmVyZmxvdy14LWF1dG8gcm91bmRlZC1jYXJkIGJnLXN1cmZhY2UgcmluZy0xIHJpbmctaGFpcmxpbmVcIj5cbiAgICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwidy1mdWxsIG1pbi13LTE2MCB0ZXh0LXNtXCI+XG4gICAgICAgICAgICA8Y2FwdGlvbiBjbGFzc05hbWU9XCJzci1vbmx5XCI+U2lkZS1ieS1zaWRlIGNvbXBhcmlzb24gb2YgdGhlIHNwYWNlcyB5b3Ugc2VsZWN0ZWQ8L2NhcHRpb24+XG4gICAgICAgICAgICA8dGhlYWQ+XG4gICAgICAgICAgICAgIDx0ciBjbGFzc05hbWU9XCJib3JkZXItYiBib3JkZXItaGFpcmxpbmVcIj5cbiAgICAgICAgICAgICAgICA8dGggc2NvcGU9XCJjb2xcIiBjbGFzc05hbWU9XCJ3LTM2IHB4LTQgcHktNCB0ZXh0LWxlZnQgdGV4dC14cyBmb250LXNlbWlib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlIHRleHQtbXV0ZWRcIj5cbiAgICAgICAgICAgICAgICAgIEZlYXR1cmVcbiAgICAgICAgICAgICAgICA8L3RoPlxuICAgICAgICAgICAgICAgIHtzZWxlY3RlZC5tYXAoKGwpID0+IChcbiAgICAgICAgICAgICAgICAgIDx0aCBrZXk9e2wuc3BhY2UuaWR9IHNjb3BlPVwiY29sXCIgY2xhc3NOYW1lPVwibWluLXctNDggcHgtMyBweS00IHRleHQtbGVmdCBhbGlnbi10b3BcIj5cbiAgICAgICAgICAgICAgICAgICAgPExpbmsgdG89e2Avc3BhY2UvJHtsLnNwYWNlLmlkfWB9IGNsYXNzTmFtZT1cImJsb2NrXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPGltZyBzcmM9e2Rpc3BsYXlJbWFnZShsLnNwYWNlLmltYWdlc1swXSl9IGFsdD1cIlwiIGNsYXNzTmFtZT1cIm1iLTIgaC0yNCB3LWZ1bGwgcm91bmRlZC14bCBvYmplY3QtY292ZXJcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtZGlzcGxheSBmb250LWJvbGQgdGV4dC1pbmsgaG92ZXI6dGV4dC1hcXVhLTcwMFwiPntsLnNwYWNlLm5hbWV9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L0xpbms+XG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTAuNSB0ZXh0LXhzIGZvbnQtbm9ybWFsIHRleHQtbXV0ZWRcIj5cbiAgICAgICAgICAgICAgICAgICAgICB7U1BBQ0VfVFlQRV9MQUJFTFtsLnNwYWNlLnNwYWNlVHlwZV19IMK3IHtsLnByb3BlcnR5LmFyZWF9XG4gICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHRvZ2dsZUNvbXBhcmUobC5zcGFjZS5pZCl9XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibXQtMiBpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtbXV0ZWQgaG92ZXI6dGV4dC1kYW5nZXItNjAwXCJcbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIDxYIHNpemU9ezEyfSBhcmlhLWhpZGRlbiAvPlxuICAgICAgICAgICAgICAgICAgICAgIFJlbW92ZVxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgIDwvdGg+XG4gICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICA8L3RoZWFkPlxuICAgICAgICAgICAgPHRib2R5PlxuICAgICAgICAgICAgICB7aGFzU3RhdGVkTmVlZHMgJiYgKFxuICAgICAgICAgICAgICAgIDxSb3cgbGFiZWw9XCJNYXRjaFwiPlxuICAgICAgICAgICAgICAgICAge3NlbGVjdGVkLm1hcCgobCkgPT4gKFxuICAgICAgICAgICAgICAgICAgICA8Q2VsbCBrZXk9e2wuc3BhY2UuaWR9IGJlc3Q9e3Njb3Jlcy5nZXQobC5zcGFjZS5pZCkgPT09IGJlc3RTY29yZX0+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1kaXNwbGF5IHRleHQtYmFzZSBmb250LWJvbGRcIj57c2NvcmVzLmdldChsLnNwYWNlLmlkKX0lPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L0NlbGw+XG4gICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICA8L1Jvdz5cbiAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICA8Um93IGxhYmVsPVwiUHJpY2VcIj5cbiAgICAgICAgICAgICAgICB7c2VsZWN0ZWQubWFwKChsKSA9PiAoXG4gICAgICAgICAgICAgICAgICA8Q2VsbCBrZXk9e2wuc3BhY2UuaWR9IGJlc3Q9e2wuc3BhY2UuY29zdC5wcmljZSA9PT0gY2hlYXBlc3R9PlxuICAgICAgICAgICAgICAgICAgICB7bW9uZXkobC5zcGFjZS5jb3N0LnByaWNlKX1cbiAgICAgICAgICAgICAgICAgICAge2wuc3BhY2UudHJhbnNhY3Rpb24gPT09IFwicmVudFwiICYmIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1tdXRlZFwiPi9tbzwvc3Bhbj59XG4gICAgICAgICAgICAgICAgICA8L0NlbGw+XG4gICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgIDwvUm93PlxuXG4gICAgICAgICAgICAgIDxSb3cgbGFiZWw9XCJUb3RhbCBtb250aGx5XCI+XG4gICAgICAgICAgICAgICAge3NlbGVjdGVkLm1hcCgobCkgPT4gKFxuICAgICAgICAgICAgICAgICAgPENlbGwga2V5PXtsLnNwYWNlLmlkfSBiZXN0PXtiZXN0VG90YWwgIT09IG51bGwgJiYgbC5zcGFjZS5jb3N0LmVzdGltYXRlZE1vbnRobHkgPT09IGJlc3RUb3RhbH0+XG4gICAgICAgICAgICAgICAgICAgIHtsLnNwYWNlLmNvc3QuZXN0aW1hdGVkTW9udGhseSA/IChcbiAgICAgICAgICAgICAgICAgICAgICBtb25leShsLnNwYWNlLmNvc3QuZXN0aW1hdGVkTW9udGhseSlcbiAgICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtd2Fybi03MDBcIj5Ob3QgZGlzY2xvc2VkPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgPC9DZWxsPlxuICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICA8L1Jvdz5cblxuICAgICAgICAgICAgICA8Um93IGxhYmVsPVwiVHJhbnNhY3Rpb25cIj5cbiAgICAgICAgICAgICAgICB7c2VsZWN0ZWQubWFwKChsKSA9PiAoXG4gICAgICAgICAgICAgICAgICA8Q2VsbCBrZXk9e2wuc3BhY2UuaWR9PlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJjYXBpdGFsaXplXCI+e2wuc3BhY2UudHJhbnNhY3Rpb24gPT09IFwicmVudFwiID8gXCJSZW50XCIgOiBcIlNhbGVcIn08L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8L0NlbGw+XG4gICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgIDwvUm93PlxuXG4gICAgICAgICAgICAgIHtzaG93QmVkcm9vbXMgJiYgKFxuICAgICAgICAgICAgICAgIDxSb3cgbGFiZWw9XCJCZWRyb29tc1wiPlxuICAgICAgICAgICAgICAgICAge3NlbGVjdGVkLm1hcCgobCkgPT4gKFxuICAgICAgICAgICAgICAgICAgICA8Q2VsbCBrZXk9e2wuc3BhY2UuaWR9PntsLnNwYWNlLmF0dHJpYnV0ZXMuYmVkcm9vbXMgPz8gXCLigJRcIn08L0NlbGw+XG4gICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICA8L1Jvdz5cbiAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICB7c2hvd1NpemUgJiYgKFxuICAgICAgICAgICAgICAgIDxSb3cgbGFiZWw9XCJTaXplXCI+XG4gICAgICAgICAgICAgICAgICB7c2VsZWN0ZWQubWFwKChsKSA9PiAoXG4gICAgICAgICAgICAgICAgICAgIDxDZWxsIGtleT17bC5zcGFjZS5pZH0gYmVzdD17KGwuc3BhY2UuYXR0cmlidXRlcy5zaXplU3FmdCA/PyAwKSA9PT0gYmlnZ2VzdCAmJiBiaWdnZXN0ID4gMH0+XG4gICAgICAgICAgICAgICAgICAgICAge2wuc3BhY2UuYXR0cmlidXRlcy5zaXplU3FmdCA/IGAke2wuc3BhY2UuYXR0cmlidXRlcy5zaXplU3FmdH0gc3FmdGAgOiBcIuKAlFwifVxuICAgICAgICAgICAgICAgICAgICA8L0NlbGw+XG4gICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICA8L1Jvdz5cbiAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICB7c2hvd1Nsb3RzICYmIChcbiAgICAgICAgICAgICAgICA8Um93IGxhYmVsPVwiU2xvdHNcIj5cbiAgICAgICAgICAgICAgICAgIHtzZWxlY3RlZC5tYXAoKGwpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgYSA9IGwuc3BhY2UuYXR0cmlidXRlcztcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgICA8Q2VsbCBrZXk9e2wuc3BhY2UuaWR9PlxuICAgICAgICAgICAgICAgICAgICAgICAge2EuY2FyU2xvdHMgIT09IHVuZGVmaW5lZCA/IGAke2EuY2FyU2xvdHN9IGNhciDCtyAke2EubW90b3JjeWNsZVNsb3RzID8/IDB9IGJpa2VgIDogXCLigJRcIn1cbiAgICAgICAgICAgICAgICAgICAgICA8L0NlbGw+XG4gICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgICB9KX1cbiAgICAgICAgICAgICAgICA8L1Jvdz5cbiAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICB7c2hvd0xhbmQgJiYgKFxuICAgICAgICAgICAgICAgIDxSb3cgbGFiZWw9XCJMYW5kIGFyZWFcIj5cbiAgICAgICAgICAgICAgICAgIHtzZWxlY3RlZC5tYXAoKGwpID0+IChcbiAgICAgICAgICAgICAgICAgICAgPENlbGwga2V5PXtsLnNwYWNlLmlkfT5cbiAgICAgICAgICAgICAgICAgICAgICB7bC5zcGFjZS5hdHRyaWJ1dGVzLmxhbmRBcmVhRGVjaW1hbCA/IGAke2wuc3BhY2UuYXR0cmlidXRlcy5sYW5kQXJlYURlY2ltYWx9IGRlY2ltYWxgIDogXCLigJRcIn1cbiAgICAgICAgICAgICAgICAgICAgPC9DZWxsPlxuICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgPC9Sb3c+XG4gICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgPFJvdyBsYWJlbD17YEZyb20gJHtyZXF1aXJlbWVudHMuYXJlYX1gfT5cbiAgICAgICAgICAgICAgICB7c2VsZWN0ZWQubWFwKChsLCBpKSA9PiAoXG4gICAgICAgICAgICAgICAgICA8Q2VsbCBrZXk9e2wuc3BhY2UuaWR9IGJlc3Q9e2Rpc3RhbmNlc1tpXSA9PT0gbmVhcmVzdCAmJiBuZWFyZXN0ICE9PSBJbmZpbml0eX0+XG4gICAgICAgICAgICAgICAgICAgIHtkaXN0YW5jZXNbaV0gPT09IEluZmluaXR5ID8gXCLigJRcIiA6IGAke2Rpc3RhbmNlc1tpXS50b0ZpeGVkKDEpfSBrbWB9XG4gICAgICAgICAgICAgICAgICA8L0NlbGw+XG4gICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgIDwvUm93PlxuXG4gICAgICAgICAgICAgIHthbWVuaXR5Um93cy5tYXAoKGtleSkgPT4gKFxuICAgICAgICAgICAgICAgIDxSb3cga2V5PXtrZXl9IGxhYmVsPXt0KGBhbWVuaXR5LiR7a2V5fWAgYXMgbmV2ZXIpfT5cbiAgICAgICAgICAgICAgICAgIHtzZWxlY3RlZC5tYXAoKGwpID0+IChcbiAgICAgICAgICAgICAgICAgICAgPENlbGwga2V5PXtsLnNwYWNlLmlkfT5cbiAgICAgICAgICAgICAgICAgICAgICB7bC5zcGFjZS5hbWVuaXRpZXMuaW5jbHVkZXMoa2V5KSA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxDaGVjayBzaXplPXsxNn0gY2xhc3NOYW1lPVwidGV4dC1vay02MDBcIiBhcmlhLWhpZGRlbiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJzci1vbmx5XCI+WWVzPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxYIHNpemU9ezE2fSBjbGFzc05hbWU9XCJ0ZXh0LWhhaXJsaW5lLXN0cm9uZ1wiIGFyaWEtaGlkZGVuIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInNyLW9ubHlcIj5Obzwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgIDwvQ2VsbD5cbiAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgIDwvUm93PlxuICAgICAgICAgICAgICApKX1cblxuICAgICAgICAgICAgICA8Um93IGxhYmVsPVwiQXZhaWxhYmlsaXR5XCI+XG4gICAgICAgICAgICAgICAge3NlbGVjdGVkLm1hcCgobCkgPT4gKFxuICAgICAgICAgICAgICAgICAgPENlbGwga2V5PXtsLnNwYWNlLmlkfT5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14c1wiPntBVkFJTEFCSUxJVFlfTEFCRUxbbC5zcGFjZS5hdmFpbGFiaWxpdHkuc3RhdHVzXX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8L0NlbGw+XG4gICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgIDwvUm93PlxuXG4gICAgICAgICAgICAgIDxSb3cgbGFiZWw9XCJGcmVlIGZyb21cIj5cbiAgICAgICAgICAgICAgICB7c2VsZWN0ZWQubWFwKChsKSA9PiAoXG4gICAgICAgICAgICAgICAgICA8Q2VsbCBrZXk9e2wuc3BhY2UuaWR9PlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzXCI+e2xvbmdEYXRlKGwuc3BhY2UuYXZhaWxhYmlsaXR5LmF2YWlsYWJsZUZyb20pfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvQ2VsbD5cbiAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgPC9Sb3c+XG5cbiAgICAgICAgICAgICAgPFJvdyBsYWJlbD1cIlRydXN0XCI+XG4gICAgICAgICAgICAgICAge3NlbGVjdGVkLm1hcCgobCkgPT4ge1xuICAgICAgICAgICAgICAgICAgY29uc3QgbGV2ZWwgPSB0cnVzdExldmVsKGwuc3BhY2UudmVyaWZpY2F0aW9uKTtcbiAgICAgICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgICAgIDxDZWxsIGtleT17bC5zcGFjZS5pZH0+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW5cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgICAgICAgICAgICAgICAgICAgIFwidGV4dC14cyBmb250LXNlbWlib2xkXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGxldmVsID09PSBcInZlcmlmaWVkXCIgPyBcInRleHQtb2stNjAwXCIgOiBsZXZlbCA9PT0gXCJpbi1yZXZpZXdcIiA/IFwidGV4dC13YXJuLTcwMFwiIDogXCJ0ZXh0LW11dGVkXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtsZXZlbCA9PT0gXCJ2ZXJpZmllZFwiID8gXCJWZXJpZmllZCAoZGVtbylcIiA6IGxldmVsID09PSBcImluLXJldmlld1wiID8gXCJJbiByZXZpZXdcIiA6IFwiTm90IHZlcmlmaWVkXCJ9XG4gICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L0NlbGw+XG4gICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgIH0pfVxuICAgICAgICAgICAgICA8L1Jvdz5cblxuICAgICAgICAgICAgICA8Um93IGxhYmVsPVwiVXBkYXRlZFwiPlxuICAgICAgICAgICAgICAgIHtzZWxlY3RlZC5tYXAoKGwpID0+IChcbiAgICAgICAgICAgICAgICAgIDxDZWxsIGtleT17bC5zcGFjZS5pZH0+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1tdXRlZFwiPntsYXN0VXBkYXRlZFNob3J0KGwuc3BhY2UubGFzdFVwZGF0ZWQpfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvQ2VsbD5cbiAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgPC9Sb3c+XG5cbiAgICAgICAgICAgICAgPFJvdyBsYWJlbD1cIlwiPlxuICAgICAgICAgICAgICAgIHtzZWxlY3RlZC5tYXAoKGwpID0+IChcbiAgICAgICAgICAgICAgICAgIDxDZWxsIGtleT17bC5zcGFjZS5pZH0+XG4gICAgICAgICAgICAgICAgICAgIDxMaW5rIHRvPXtgL3NwYWNlLyR7bC5zcGFjZS5pZH1gfT5cbiAgICAgICAgICAgICAgICAgICAgICA8QnV0dG9uIHNpemU9XCJzbVwiIHZhcmlhbnQ9XCJzZWNvbmRhcnlcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIE9wZW5cbiAgICAgICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgPC9MaW5rPlxuICAgICAgICAgICAgICAgICAgPC9DZWxsPlxuICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICA8L1Jvdz5cbiAgICAgICAgICAgIDwvdGJvZHk+XG4gICAgICAgICAgPC90YWJsZT5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAge3NlbGVjdGVkLmxlbmd0aCA9PT0gMSAmJiAoXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtNSByb3VuZGVkLWNhcmQgYmctc3VyZmFjZS83MCBwLTQgdGV4dC1zbSB0ZXh0LWluay1zb2Z0IHJpbmctMSByaW5nLWhhaXJsaW5lLXN0cm9uZ1wiPlxuICAgICAgICAgICAgQWRkIG9uZSBvciB0d28gbW9yZSBhbmQgdGhlIGRpZmZlcmVuY2VzIGJlY29tZSBtdWNoIGVhc2llciB0byByZWFkLlxuICAgICAgICAgIDwvcD5cbiAgICAgICAgKX1cbiAgICAgIDwvZGl2PlxuICAgIDwvPlxuICApO1xufVxuXG5mdW5jdGlvbiBSb3coeyBsYWJlbCwgY2hpbGRyZW4gfTogeyBsYWJlbDogc3RyaW5nOyBjaGlsZHJlbjogUmVhY3QuUmVhY3ROb2RlIH0pIHtcbiAgcmV0dXJuIChcbiAgICA8dHIgY2xhc3NOYW1lPVwiYm9yZGVyLWIgYm9yZGVyLWhhaXJsaW5lIGxhc3Q6Ym9yZGVyLTBcIj5cbiAgICAgIDx0aCBzY29wZT1cInJvd1wiIGNsYXNzTmFtZT1cInB4LTQgcHktMyB0ZXh0LWxlZnQgYWxpZ24tbWlkZGxlIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LW11dGVkXCI+XG4gICAgICAgIHtsYWJlbH1cbiAgICAgIDwvdGg+XG4gICAgICB7Y2hpbGRyZW59XG4gICAgPC90cj5cbiAgKTtcbn1cblxuZnVuY3Rpb24gQ2VsbCh7IGNoaWxkcmVuLCBiZXN0IH06IHsgY2hpbGRyZW46IFJlYWN0LlJlYWN0Tm9kZTsgYmVzdD86IGJvb2xlYW4gfSkge1xuICByZXR1cm4gKFxuICAgIDx0ZCBjbGFzc05hbWU9e2NuKFwicHgtMyBweS0zIGFsaWduLW1pZGRsZSBmb250LXNlbWlib2xkIHRudW1cIiwgYmVzdCA/IFwiYmctYXF1YS01MCB0ZXh0LWFxdWEtNzAwXCIgOiBcInRleHQtaW5rXCIpfT5cbiAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41XCI+e2NoaWxkcmVufTwvc3Bhbj5cbiAgICA8L3RkPlxuICApO1xufVxuIl0sImZpbGUiOiJEOi9JMkkgUHJvamVjdCAtIEhhYml0by9BcHAgRm9sZGVyL2hhYml0by9zcmMvcGFnZXMvQ29tcGFyZS50c3gifQ==