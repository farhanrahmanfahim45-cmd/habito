import { SPACE_TYPE_LABEL, CATEGORY_OF_TYPE } from "/src/types/space.ts";
import { AMENITIES } from "/src/data/catalog.ts";
import { AREAS, haversineKm } from "/src/data/areas.ts";
import { money, longDate } from "/src/lib/format.ts";
export const WEIGHT_PROFILES = {
  // Home: budget dominates, and the extras people list as essential matter.
  living: { budget: 30, location: 24, spaceType: 18, availability: 12, capacity: 6, amenities: 10 },
  // Shop or office: footfall is the business, so location outweighs price.
  business: { budget: 24, location: 30, spaceType: 16, availability: 10, capacity: 12, amenities: 8 },
  // Godown: capacity is the point of renting one. Access and power matter more
  // than being central.
  storage: { budget: 26, location: 18, spaceType: 14, availability: 10, capacity: 20, amenities: 12 },
  // Parking: entirely about being near where you leave the car, and whether a
  // slot is actually free. Floor area is meaningless.
  parking: { budget: 22, location: 34, spaceType: 12, availability: 20, capacity: 0, amenities: 12 },
  // Land: plot size and road access decide it; nobody rents farmland for the
  // month it becomes free.
  land: { budget: 28, location: 18, spaceType: 16, availability: 8, capacity: 22, amenities: 8 }
};
export function weightsFor(category) {
  return WEIGHT_PROFILES[category];
}
const clamp01 = (n) => Math.max(0, Math.min(1, n));
export function distanceFromArea(listing, areaName) {
  const area = AREAS.find((a) => a.name === areaName);
  if (!area) return null;
  return haversineKm(area.latitude, area.longitude, listing.property.latitude, listing.property.longitude);
}
function budgetFactor(l, r, w) {
  const base = { key: "budget", label: "Budget", weight: w.budget };
  const { cost } = l.space;
  const usingTotal = cost.estimatedMonthly !== null && l.space.transaction === "rent";
  const amount = usingTotal ? cost.estimatedMonthly : cost.price;
  if (amount >= r.budgetMin && amount <= r.budgetMax) {
    return {
      ...base,
      score: 1,
      verdict: "met",
      detail: usingTotal ? `${money(amount)} a month all in, inside your range` : `${money(amount)} sits inside your range`
    };
  }
  if (amount < r.budgetMin) {
    const gap = (r.budgetMin - amount) / Math.max(r.budgetMin, 1);
    return { ...base, score: clamp01(1 - gap * 0.3), verdict: "met", detail: `${money(amount)} — below the range you set` };
  }
  const overshoot = (amount - r.budgetMax) / Math.max(r.budgetMax, 1);
  return {
    ...base,
    score: clamp01(1 - overshoot * 2.2),
    verdict: overshoot <= 0.12 ? "partial" : "missed",
    detail: `${money(amount - r.budgetMax)} over your maximum${usingTotal ? " once charges are counted" : ""}`
  };
}
function locationFactor(l, r, w) {
  const base = { key: "location", label: "Location", weight: w.location };
  if (l.property.area === r.area) {
    return { ...base, score: 1, verdict: "met", detail: `In ${l.property.neighborhood}, the area you chose` };
  }
  const km = distanceFromArea(l, r.area);
  if (km === null) {
    return { ...base, score: 0.5, verdict: "partial", detail: `In ${l.property.area}` };
  }
  return {
    ...base,
    score: clamp01(1 - km / 14),
    verdict: km <= 4 ? "partial" : "missed",
    detail: `${km.toFixed(1)} km from ${r.area}, in ${l.property.area}`
  };
}
const NEIGHBOURING = {
  room: ["shared-room", "sublet"],
  "shared-room": ["room", "sublet"],
  sublet: ["room", "shared-room", "apartment"],
  apartment: ["sublet", "house"],
  house: ["apartment", "tin-shed", "homestead"],
  "tin-shed": ["house", "homestead"],
  shop: ["office"],
  office: ["shop"],
  godown: ["shop"],
  garage: ["parking-slot"],
  "parking-slot": ["garage"],
  farmland: ["pond", "homestead"]
};
function typeFactor(l, r, w) {
  const base = { key: "spaceType", label: "Space type", weight: w.spaceType };
  const type = l.space.spaceType;
  if (r.spaceType !== "any") {
    if (type === r.spaceType) {
      return { ...base, score: 1, verdict: "met", detail: "Exactly the kind of space you asked for" };
    }
    if (NEIGHBOURING[r.spaceType]?.includes(type)) {
      return {
        ...base,
        score: 0.55,
        verdict: "partial",
        detail: `A ${SPACE_TYPE_LABEL[type].toLowerCase()} rather than a ${SPACE_TYPE_LABEL[r.spaceType].toLowerCase()}`
      };
    }
    return { ...base, score: 0, verdict: "missed", detail: `A ${SPACE_TYPE_LABEL[type].toLowerCase()}, not what you asked for` };
  }
  if (r.category !== "any") {
    const inCategory = CATEGORY_OF_TYPE[type] === r.category;
    return {
      ...base,
      score: inCategory ? 0.95 : 0,
      verdict: inCategory ? "met" : "missed",
      detail: inCategory ? `A ${SPACE_TYPE_LABEL[type].toLowerCase()} in the category you chose` : `Outside the category you chose`
    };
  }
  return { ...base, score: 0.9, verdict: "met", detail: "You're open to any kind of space" };
}
function availabilityFactor(l, r, w) {
  const base = { key: "availability", label: "Availability", weight: w.availability };
  const { status, availableFrom, note } = l.space.availability;
  if (status === "occupied") return { ...base, score: 0, verdict: "missed", detail: "Currently occupied" };
  if (status === "maintenance") return { ...base, score: 0.15, verdict: "missed", detail: "Under maintenance" };
  const daysLate = Math.round((new Date(availableFrom).getTime() - new Date(r.moveInDate).getTime()) / 864e5);
  if (daysLate <= 0) {
    if (l.space.category === "parking") {
      const wanted = (r.capacity.carSlots ?? 0) + (r.capacity.motorcycleSlots ?? 0);
      const free = l.space.availability.availableUnits ?? 1;
      if (wanted > 0 && free < wanted) {
        return {
          ...base,
          score: clamp01(free / wanted),
          verdict: free > 0 ? "partial" : "missed",
          detail: note ? note : `${free} free, you need ${wanted}`
        };
      }
      return { ...base, score: 1, verdict: "met", detail: note ?? "Free now" };
    }
    return {
      ...base,
      score: status === "partially-available" ? 0.8 : 1,
      verdict: status === "partially-available" ? "partial" : "met",
      detail: status === "partially-available" && note ? `Partly free — ${note}` : `Free from ${longDate(availableFrom)}, before you need it`
    };
  }
  return {
    ...base,
    score: clamp01(1 - daysLate / 45),
    verdict: daysLate <= 14 ? "partial" : "missed",
    detail: `Free from ${longDate(availableFrom)}, ${daysLate} day${daysLate > 1 ? "s" : ""} after you wanted it`
  };
}
function capacityFactor(l, r, w) {
  const base = { key: "size", label: capacityLabel(l.space.category), weight: w.capacity };
  const a = l.space.attributes;
  const need = r.capacity;
  if (w.capacity === 0) {
    return { ...base, score: 1, verdict: "met", detail: "Not scored for this kind of space" };
  }
  const shortfall = (have, want, unit, tolerance = 0.85) => {
    if (have === void 0) {
      return { ...base, score: 0.6, verdict: "partial", detail: `Not stated by the owner` };
    }
    if (have >= want) {
      return { ...base, score: 1, verdict: "met", detail: `${have} ${unit}, at or above what you need` };
    }
    return {
      ...base,
      score: clamp01(have / want),
      verdict: have >= want * tolerance ? "partial" : "missed",
      detail: `${have} ${unit}, short of the ${want} you wanted`
    };
  };
  switch (l.space.category) {
    case "living": {
      if (need.minBedrooms) return shortfall(a.bedrooms, need.minBedrooms, "bedrooms");
      if (need.minSizeSqft) return shortfall(a.sizeSqft, need.minSizeSqft, "sqft");
      break;
    }
    case "business": {
      if (need.minWorkstations) return shortfall(a.workstations, need.minWorkstations, "workstations");
      if (need.minSizeSqft) return shortfall(a.sizeSqft, need.minSizeSqft, "sqft");
      break;
    }
    case "storage": {
      if (need.minSizeSqft) {
        const area = shortfall(a.sizeSqft, need.minSizeSqft, "sqft");
        if (need.minCeilingFt && a.ceilingHeightFt !== void 0 && a.ceilingHeightFt < need.minCeilingFt) {
          return {
            ...area,
            score: area.score * 0.7,
            verdict: "partial",
            detail: `${a.sizeSqft ?? "?"} sqft but only ${a.ceilingHeightFt} ft of headroom`
          };
        }
        return area;
      }
      break;
    }
    case "land": {
      if (need.minLandDecimal) return shortfall(a.landAreaDecimal, need.minLandDecimal, "decimal");
      break;
    }
    case "parking":
      break;
  }
  return { ...base, score: 0.9, verdict: "met", detail: "You didn't set a minimum" };
}
function capacityLabel(category) {
  switch (category) {
    case "living":
      return "Size";
    case "business":
      return "Space";
    case "storage":
      return "Capacity";
    case "parking":
      return "Slots";
    case "land":
      return "Plot size";
  }
}
function amenitiesFactor(l, r, w) {
  const base = { key: "amenities", label: "Amenities", weight: w.amenities };
  if (r.amenities.length === 0) {
    return { ...base, score: 0.9, verdict: "met", detail: "You didn't name anything essential" };
  }
  const missing = r.amenities.filter((a) => !l.space.amenities.includes(a));
  if (missing.length === 0) {
    return { ...base, score: 1, verdict: "met", detail: "Has everything you asked for" };
  }
  const score = (r.amenities.length - missing.length) / r.amenities.length;
  return {
    ...base,
    score,
    verdict: score >= 0.5 ? "partial" : "missed",
    detail: `No ${missing.map((m) => AMENITIES[m].label.toLowerCase()).join(", ")}`
  };
}
export function scoreListing(l, r) {
  const w = weightsFor(l.space.category);
  const factors = [
    budgetFactor(l, r, w),
    locationFactor(l, r, w),
    typeFactor(l, r, w),
    availabilityFactor(l, r, w),
    capacityFactor(l, r, w),
    amenitiesFactor(l, r, w)
  ].filter((f) => f.weight > 0);
  const weighted = factors.reduce((s, f) => s + f.score * f.weight, 0);
  const total = factors.reduce((s, f) => s + f.weight, 0);
  const pct = weighted / total * 100;
  const score = pct >= 99.995 ? 100 : Math.min(99, Math.round(pct));
  return { spaceId: l.space.id, score, factors };
}
export function scoreAll(listings, r) {
  const map = /* @__PURE__ */ new Map();
  for (const l of listings) map.set(l.space.id, scoreListing(l, r));
  return map;
}
export function matchLabel(score) {
  if (score >= 90) return "Excellent match";
  if (score >= 78) return "Strong match";
  if (score >= 62) return "Worth a look";
  return "Loose match";
}
export function nearbyAlternatives(listings, r, excludeIds, limit = 6) {
  return listings.filter((l) => !excludeIds.includes(l.space.id) && l.space.availability.status !== "occupied").map((l) => {
    const match = scoreListing(l, r);
    const km = distanceFromArea(l, r.area);
    const amount = l.space.cost.estimatedMonthly ?? l.space.cost.price;
    let reason;
    if (l.property.area !== r.area && km !== null && km <= 6) {
      reason = `${km.toFixed(1)} km from ${r.area}, in ${l.property.area}`;
    } else if (amount < r.budgetMin) {
      reason = `Cheaper than your range at ${money(amount)}`;
    } else if (r.spaceType !== "any" && l.space.spaceType !== r.spaceType) {
      reason = `A ${SPACE_TYPE_LABEL[l.space.spaceType].toLowerCase()} instead`;
    } else if (amount > r.budgetMax) {
      reason = `${money(amount - r.budgetMax)} above your maximum`;
    } else {
      reason = "Close on everything else";
    }
    return { listing: l, score: match.score, distanceKm: km, reason };
  }).filter((s) => s.score >= 45).sort((a, b) => b.score - a.score).slice(0, limit);
}
export const DEFAULT_REQUIREMENTS = {
  transaction: "rent",
  category: "any",
  spaceType: "any",
  area: "Badda",
  budgetMin: 6e3,
  budgetMax: 14e3,
  capacity: {},
  moveInDate: new Date(Date.now() + 21 * 864e5).toISOString().slice(0, 10),
  amenities: [],
  occupancy: "any"
};
export function acceptsOccupancy(l, occupancy) {
  if (occupancy === "any") return true;
  if (l.space.category !== "living") return true;
  const rules = l.space.rules;
  if (!rules) return true;
  switch (occupancy) {
    case "family":
      return rules.familyAllowed;
    case "bachelor":
      return rules.bachelorAllowed;
    case "student":
      return rules.studentFriendly || rules.bachelorAllowed;
    default:
      return true;
  }
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1hdGNoaW5nLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB0eXBlIHtcbiAgTWF0Y2hGYWN0b3IsXG4gIE1hdGNoUmVzdWx0LFxuICBTZWFyY2hSZXF1aXJlbWVudHMsXG4gIFNwYWNlTGlzdGluZyxcbn0gZnJvbSBcIkAvdHlwZXMvc3BhY2VcIjtcbmltcG9ydCB7IFNQQUNFX1RZUEVfTEFCRUwsIENBVEVHT1JZX09GX1RZUEUgfSBmcm9tIFwiQC90eXBlcy9zcGFjZVwiO1xuaW1wb3J0IHR5cGUgeyBTcGFjZUNhdGVnb3J5IH0gZnJvbSBcIkAvdHlwZXMvc3BhY2VcIjtcbmltcG9ydCB7IEFNRU5JVElFUyB9IGZyb20gXCJAL2RhdGEvY2F0YWxvZ1wiO1xuaW1wb3J0IHsgQVJFQVMsIGhhdmVyc2luZUttIH0gZnJvbSBcIkAvZGF0YS9hcmVhc1wiO1xuaW1wb3J0IHsgbW9uZXksIGxvbmdEYXRlIH0gZnJvbSBcIi4vZm9ybWF0XCI7XG5cbi8qKlxuICogSGFiaXRvIE1hdGNoIOKAlCB0cmFuc3BhcmVudCBhbmQgcnVsZS1iYXNlZC5cbiAqXG4gKiBBcml0aG1ldGljIG92ZXIgc3RhdGVkIHJlcXVpcmVtZW50cywgbm90IGEgbGVhcm5lZCBtb2RlbCwgYW5kIG5ldmVyXG4gKiBkZXNjcmliZWQgYXMgQUkuIEVhY2ggZmFjdG9yIHJldHVybnMgdGhlIHNlbnRlbmNlIGEgcGVyc29uIG5lZWRzIHRvXG4gKiB1bmRlcnN0YW5kIHRoZSBudW1iZXIsIHNvIHRoZSBVSSBuZXZlciBzaG93cyBhIHNjb3JlIHdpdGhvdXQgaXRzIHJlYXNvbnMuXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgV2VpZ2h0cyB7XG4gIGJ1ZGdldDogbnVtYmVyO1xuICBsb2NhdGlvbjogbnVtYmVyO1xuICBzcGFjZVR5cGU6IG51bWJlcjtcbiAgYXZhaWxhYmlsaXR5OiBudW1iZXI7XG4gIGNhcGFjaXR5OiBudW1iZXI7XG4gIGFtZW5pdGllczogbnVtYmVyO1xufVxuXG4vKipcbiAqIFdoYXQgbWF0dGVycyBkZXBlbmRzIG9uIHdoYXQgeW91IGFyZSBsb29raW5nIGZvci5cbiAqXG4gKiBBIHNpbmdsZSB3ZWlnaHQgc2V0IGFjcm9zcyBldmVyeSBjYXRlZ29yeSB3YXMgYWx3YXlzIGEgY29tcHJvbWlzZTogaXQgc2NvcmVkXG4gKiBhIGdhcmFnZSBvbiBmbG9vciBhcmVhIGl0IGRvZXMgbm90IGhhdmUsIGFuZCBnYXZlIGEgc2hvcCdzIGxvY2F0aW9uIHRoZSBzYW1lXG4gKiBpbXBvcnRhbmNlIGFzIGEgZ29kb3duJ3MsIHdoZW4gZm9yIGEgc2hvcCBsb2NhdGlvbiBpcyBjbG9zZSB0byB0aGUgd2hvbGVcbiAqIGRlY2lzaW9uLiBUaGVzZSBwcm9maWxlcyBlYWNoIHRvdGFsIDEwMC5cbiAqL1xuZXhwb3J0IGNvbnN0IFdFSUdIVF9QUk9GSUxFUzogUmVjb3JkPFNwYWNlQ2F0ZWdvcnksIFdlaWdodHM+ID0ge1xuICAvLyBIb21lOiBidWRnZXQgZG9taW5hdGVzLCBhbmQgdGhlIGV4dHJhcyBwZW9wbGUgbGlzdCBhcyBlc3NlbnRpYWwgbWF0dGVyLlxuICBsaXZpbmc6IHsgYnVkZ2V0OiAzMCwgbG9jYXRpb246IDI0LCBzcGFjZVR5cGU6IDE4LCBhdmFpbGFiaWxpdHk6IDEyLCBjYXBhY2l0eTogNiwgYW1lbml0aWVzOiAxMCB9LFxuXG4gIC8vIFNob3Agb3Igb2ZmaWNlOiBmb290ZmFsbCBpcyB0aGUgYnVzaW5lc3MsIHNvIGxvY2F0aW9uIG91dHdlaWdocyBwcmljZS5cbiAgYnVzaW5lc3M6IHsgYnVkZ2V0OiAyNCwgbG9jYXRpb246IDMwLCBzcGFjZVR5cGU6IDE2LCBhdmFpbGFiaWxpdHk6IDEwLCBjYXBhY2l0eTogMTIsIGFtZW5pdGllczogOCB9LFxuXG4gIC8vIEdvZG93bjogY2FwYWNpdHkgaXMgdGhlIHBvaW50IG9mIHJlbnRpbmcgb25lLiBBY2Nlc3MgYW5kIHBvd2VyIG1hdHRlciBtb3JlXG4gIC8vIHRoYW4gYmVpbmcgY2VudHJhbC5cbiAgc3RvcmFnZTogeyBidWRnZXQ6IDI2LCBsb2NhdGlvbjogMTgsIHNwYWNlVHlwZTogMTQsIGF2YWlsYWJpbGl0eTogMTAsIGNhcGFjaXR5OiAyMCwgYW1lbml0aWVzOiAxMiB9LFxuXG4gIC8vIFBhcmtpbmc6IGVudGlyZWx5IGFib3V0IGJlaW5nIG5lYXIgd2hlcmUgeW91IGxlYXZlIHRoZSBjYXIsIGFuZCB3aGV0aGVyIGFcbiAgLy8gc2xvdCBpcyBhY3R1YWxseSBmcmVlLiBGbG9vciBhcmVhIGlzIG1lYW5pbmdsZXNzLlxuICBwYXJraW5nOiB7IGJ1ZGdldDogMjIsIGxvY2F0aW9uOiAzNCwgc3BhY2VUeXBlOiAxMiwgYXZhaWxhYmlsaXR5OiAyMCwgY2FwYWNpdHk6IDAsIGFtZW5pdGllczogMTIgfSxcblxuICAvLyBMYW5kOiBwbG90IHNpemUgYW5kIHJvYWQgYWNjZXNzIGRlY2lkZSBpdDsgbm9ib2R5IHJlbnRzIGZhcm1sYW5kIGZvciB0aGVcbiAgLy8gbW9udGggaXQgYmVjb21lcyBmcmVlLlxuICBsYW5kOiB7IGJ1ZGdldDogMjgsIGxvY2F0aW9uOiAxOCwgc3BhY2VUeXBlOiAxNiwgYXZhaWxhYmlsaXR5OiA4LCBjYXBhY2l0eTogMjIsIGFtZW5pdGllczogOCB9LFxufTtcblxuLyoqIFdlaWdodHMgZm9yIHdoYXRldmVyIHRoZSBsaXN0aW5nIGFjdHVhbGx5IGlzLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHdlaWdodHNGb3IoY2F0ZWdvcnk6IFNwYWNlQ2F0ZWdvcnkpOiBXZWlnaHRzIHtcbiAgcmV0dXJuIFdFSUdIVF9QUk9GSUxFU1tjYXRlZ29yeV07XG59XG5cbmNvbnN0IGNsYW1wMDEgPSAobjogbnVtYmVyKSA9PiBNYXRoLm1heCgwLCBNYXRoLm1pbigxLCBuKSk7XG5cbmV4cG9ydCBmdW5jdGlvbiBkaXN0YW5jZUZyb21BcmVhKGxpc3Rpbmc6IFNwYWNlTGlzdGluZywgYXJlYU5hbWU6IHN0cmluZyk6IG51bWJlciB8IG51bGwge1xuICBjb25zdCBhcmVhID0gQVJFQVMuZmluZCgoYSkgPT4gYS5uYW1lID09PSBhcmVhTmFtZSk7XG4gIGlmICghYXJlYSkgcmV0dXJuIG51bGw7XG4gIHJldHVybiBoYXZlcnNpbmVLbShhcmVhLmxhdGl0dWRlLCBhcmVhLmxvbmdpdHVkZSwgbGlzdGluZy5wcm9wZXJ0eS5sYXRpdHVkZSwgbGlzdGluZy5wcm9wZXJ0eS5sb25naXR1ZGUpO1xufVxuXG5mdW5jdGlvbiBidWRnZXRGYWN0b3IobDogU3BhY2VMaXN0aW5nLCByOiBTZWFyY2hSZXF1aXJlbWVudHMsIHc6IFdlaWdodHMpOiBNYXRjaEZhY3RvciB7XG4gIGNvbnN0IGJhc2UgPSB7IGtleTogXCJidWRnZXRcIiBhcyBjb25zdCwgbGFiZWw6IFwiQnVkZ2V0XCIsIHdlaWdodDogdy5idWRnZXQgfTtcbiAgY29uc3QgeyBjb3N0IH0gPSBsLnNwYWNlO1xuXG4gIC8vIEp1ZGdlIG9uIHdoYXQgc29tZW9uZSBhY3R1YWxseSBwYXlzIGVhY2ggbW9udGggd2hlcmUgdGhhdCdzIGtub3duIOKAlFxuICAvLyByZW50IGFsb25lIGlzIHRoZSBmaWd1cmUgdGhhdCBtaXNsZWFkcyBwZW9wbGUuXG4gIGNvbnN0IHVzaW5nVG90YWwgPSBjb3N0LmVzdGltYXRlZE1vbnRobHkgIT09IG51bGwgJiYgbC5zcGFjZS50cmFuc2FjdGlvbiA9PT0gXCJyZW50XCI7XG4gIGNvbnN0IGFtb3VudCA9IHVzaW5nVG90YWwgPyBjb3N0LmVzdGltYXRlZE1vbnRobHkhIDogY29zdC5wcmljZTtcblxuICBpZiAoYW1vdW50ID49IHIuYnVkZ2V0TWluICYmIGFtb3VudCA8PSByLmJ1ZGdldE1heCkge1xuICAgIHJldHVybiB7XG4gICAgICAuLi5iYXNlLFxuICAgICAgc2NvcmU6IDEsXG4gICAgICB2ZXJkaWN0OiBcIm1ldFwiLFxuICAgICAgZGV0YWlsOiB1c2luZ1RvdGFsXG4gICAgICAgID8gYCR7bW9uZXkoYW1vdW50KX0gYSBtb250aCBhbGwgaW4sIGluc2lkZSB5b3VyIHJhbmdlYFxuICAgICAgICA6IGAke21vbmV5KGFtb3VudCl9IHNpdHMgaW5zaWRlIHlvdXIgcmFuZ2VgLFxuICAgIH07XG4gIH1cblxuICBpZiAoYW1vdW50IDwgci5idWRnZXRNaW4pIHtcbiAgICBjb25zdCBnYXAgPSAoci5idWRnZXRNaW4gLSBhbW91bnQpIC8gTWF0aC5tYXgoci5idWRnZXRNaW4sIDEpO1xuICAgIHJldHVybiB7IC4uLmJhc2UsIHNjb3JlOiBjbGFtcDAxKDEgLSBnYXAgKiAwLjMpLCB2ZXJkaWN0OiBcIm1ldFwiLCBkZXRhaWw6IGAke21vbmV5KGFtb3VudCl9IOKAlCBiZWxvdyB0aGUgcmFuZ2UgeW91IHNldGAgfTtcbiAgfVxuXG4gIGNvbnN0IG92ZXJzaG9vdCA9IChhbW91bnQgLSByLmJ1ZGdldE1heCkgLyBNYXRoLm1heChyLmJ1ZGdldE1heCwgMSk7XG4gIHJldHVybiB7XG4gICAgLi4uYmFzZSxcbiAgICBzY29yZTogY2xhbXAwMSgxIC0gb3ZlcnNob290ICogMi4yKSxcbiAgICB2ZXJkaWN0OiBvdmVyc2hvb3QgPD0gMC4xMiA/IFwicGFydGlhbFwiIDogXCJtaXNzZWRcIixcbiAgICBkZXRhaWw6IGAke21vbmV5KGFtb3VudCAtIHIuYnVkZ2V0TWF4KX0gb3ZlciB5b3VyIG1heGltdW0ke3VzaW5nVG90YWwgPyBcIiBvbmNlIGNoYXJnZXMgYXJlIGNvdW50ZWRcIiA6IFwiXCJ9YCxcbiAgfTtcbn1cblxuZnVuY3Rpb24gbG9jYXRpb25GYWN0b3IobDogU3BhY2VMaXN0aW5nLCByOiBTZWFyY2hSZXF1aXJlbWVudHMsIHc6IFdlaWdodHMpOiBNYXRjaEZhY3RvciB7XG4gIGNvbnN0IGJhc2UgPSB7IGtleTogXCJsb2NhdGlvblwiIGFzIGNvbnN0LCBsYWJlbDogXCJMb2NhdGlvblwiLCB3ZWlnaHQ6IHcubG9jYXRpb24gfTtcblxuICBpZiAobC5wcm9wZXJ0eS5hcmVhID09PSByLmFyZWEpIHtcbiAgICByZXR1cm4geyAuLi5iYXNlLCBzY29yZTogMSwgdmVyZGljdDogXCJtZXRcIiwgZGV0YWlsOiBgSW4gJHtsLnByb3BlcnR5Lm5laWdoYm9yaG9vZH0sIHRoZSBhcmVhIHlvdSBjaG9zZWAgfTtcbiAgfVxuXG4gIGNvbnN0IGttID0gZGlzdGFuY2VGcm9tQXJlYShsLCByLmFyZWEpO1xuICBpZiAoa20gPT09IG51bGwpIHtcbiAgICByZXR1cm4geyAuLi5iYXNlLCBzY29yZTogMC41LCB2ZXJkaWN0OiBcInBhcnRpYWxcIiwgZGV0YWlsOiBgSW4gJHtsLnByb3BlcnR5LmFyZWF9YCB9O1xuICB9XG5cbiAgcmV0dXJuIHtcbiAgICAuLi5iYXNlLFxuICAgIHNjb3JlOiBjbGFtcDAxKDEgLSBrbSAvIDE0KSxcbiAgICB2ZXJkaWN0OiBrbSA8PSA0ID8gXCJwYXJ0aWFsXCIgOiBcIm1pc3NlZFwiLFxuICAgIGRldGFpbDogYCR7a20udG9GaXhlZCgxKX0ga20gZnJvbSAke3IuYXJlYX0sIGluICR7bC5wcm9wZXJ0eS5hcmVhfWAsXG4gIH07XG59XG5cbmNvbnN0IE5FSUdIQk9VUklORzogUGFydGlhbDxSZWNvcmQ8c3RyaW5nLCBzdHJpbmdbXT4+ID0ge1xuICByb29tOiBbXCJzaGFyZWQtcm9vbVwiLCBcInN1YmxldFwiXSxcbiAgXCJzaGFyZWQtcm9vbVwiOiBbXCJyb29tXCIsIFwic3VibGV0XCJdLFxuICBzdWJsZXQ6IFtcInJvb21cIiwgXCJzaGFyZWQtcm9vbVwiLCBcImFwYXJ0bWVudFwiXSxcbiAgYXBhcnRtZW50OiBbXCJzdWJsZXRcIiwgXCJob3VzZVwiXSxcbiAgaG91c2U6IFtcImFwYXJ0bWVudFwiLCBcInRpbi1zaGVkXCIsIFwiaG9tZXN0ZWFkXCJdLFxuICBcInRpbi1zaGVkXCI6IFtcImhvdXNlXCIsIFwiaG9tZXN0ZWFkXCJdLFxuICBzaG9wOiBbXCJvZmZpY2VcIl0sXG4gIG9mZmljZTogW1wic2hvcFwiXSxcbiAgZ29kb3duOiBbXCJzaG9wXCJdLFxuICBnYXJhZ2U6IFtcInBhcmtpbmctc2xvdFwiXSxcbiAgXCJwYXJraW5nLXNsb3RcIjogW1wiZ2FyYWdlXCJdLFxuICBmYXJtbGFuZDogW1wicG9uZFwiLCBcImhvbWVzdGVhZFwiXSxcbn07XG5cbmZ1bmN0aW9uIHR5cGVGYWN0b3IobDogU3BhY2VMaXN0aW5nLCByOiBTZWFyY2hSZXF1aXJlbWVudHMsIHc6IFdlaWdodHMpOiBNYXRjaEZhY3RvciB7XG4gIGNvbnN0IGJhc2UgPSB7IGtleTogXCJzcGFjZVR5cGVcIiBhcyBjb25zdCwgbGFiZWw6IFwiU3BhY2UgdHlwZVwiLCB3ZWlnaHQ6IHcuc3BhY2VUeXBlIH07XG4gIGNvbnN0IHR5cGUgPSBsLnNwYWNlLnNwYWNlVHlwZTtcblxuICBpZiAoci5zcGFjZVR5cGUgIT09IFwiYW55XCIpIHtcbiAgICBpZiAodHlwZSA9PT0gci5zcGFjZVR5cGUpIHtcbiAgICAgIHJldHVybiB7IC4uLmJhc2UsIHNjb3JlOiAxLCB2ZXJkaWN0OiBcIm1ldFwiLCBkZXRhaWw6IFwiRXhhY3RseSB0aGUga2luZCBvZiBzcGFjZSB5b3UgYXNrZWQgZm9yXCIgfTtcbiAgICB9XG4gICAgaWYgKE5FSUdIQk9VUklOR1tyLnNwYWNlVHlwZV0/LmluY2x1ZGVzKHR5cGUpKSB7XG4gICAgICByZXR1cm4ge1xuICAgICAgICAuLi5iYXNlLFxuICAgICAgICBzY29yZTogMC41NSxcbiAgICAgICAgdmVyZGljdDogXCJwYXJ0aWFsXCIsXG4gICAgICAgIGRldGFpbDogYEEgJHtTUEFDRV9UWVBFX0xBQkVMW3R5cGVdLnRvTG93ZXJDYXNlKCl9IHJhdGhlciB0aGFuIGEgJHtTUEFDRV9UWVBFX0xBQkVMW3Iuc3BhY2VUeXBlXS50b0xvd2VyQ2FzZSgpfWAsXG4gICAgICB9O1xuICAgIH1cbiAgICByZXR1cm4geyAuLi5iYXNlLCBzY29yZTogMCwgdmVyZGljdDogXCJtaXNzZWRcIiwgZGV0YWlsOiBgQSAke1NQQUNFX1RZUEVfTEFCRUxbdHlwZV0udG9Mb3dlckNhc2UoKX0sIG5vdCB3aGF0IHlvdSBhc2tlZCBmb3JgIH07XG4gIH1cblxuICBpZiAoci5jYXRlZ29yeSAhPT0gXCJhbnlcIikge1xuICAgIGNvbnN0IGluQ2F0ZWdvcnkgPSBDQVRFR09SWV9PRl9UWVBFW3R5cGVdID09PSByLmNhdGVnb3J5O1xuICAgIHJldHVybiB7XG4gICAgICAuLi5iYXNlLFxuICAgICAgc2NvcmU6IGluQ2F0ZWdvcnkgPyAwLjk1IDogMCxcbiAgICAgIHZlcmRpY3Q6IGluQ2F0ZWdvcnkgPyBcIm1ldFwiIDogXCJtaXNzZWRcIixcbiAgICAgIGRldGFpbDogaW5DYXRlZ29yeSA/IGBBICR7U1BBQ0VfVFlQRV9MQUJFTFt0eXBlXS50b0xvd2VyQ2FzZSgpfSBpbiB0aGUgY2F0ZWdvcnkgeW91IGNob3NlYCA6IGBPdXRzaWRlIHRoZSBjYXRlZ29yeSB5b3UgY2hvc2VgLFxuICAgIH07XG4gIH1cblxuICByZXR1cm4geyAuLi5iYXNlLCBzY29yZTogMC45LCB2ZXJkaWN0OiBcIm1ldFwiLCBkZXRhaWw6IFwiWW91J3JlIG9wZW4gdG8gYW55IGtpbmQgb2Ygc3BhY2VcIiB9O1xufVxuXG5mdW5jdGlvbiBhdmFpbGFiaWxpdHlGYWN0b3IobDogU3BhY2VMaXN0aW5nLCByOiBTZWFyY2hSZXF1aXJlbWVudHMsIHc6IFdlaWdodHMpOiBNYXRjaEZhY3RvciB7XG4gIGNvbnN0IGJhc2UgPSB7IGtleTogXCJhdmFpbGFiaWxpdHlcIiBhcyBjb25zdCwgbGFiZWw6IFwiQXZhaWxhYmlsaXR5XCIsIHdlaWdodDogdy5hdmFpbGFiaWxpdHkgfTtcbiAgY29uc3QgeyBzdGF0dXMsIGF2YWlsYWJsZUZyb20sIG5vdGUgfSA9IGwuc3BhY2UuYXZhaWxhYmlsaXR5O1xuXG4gIGlmIChzdGF0dXMgPT09IFwib2NjdXBpZWRcIikgcmV0dXJuIHsgLi4uYmFzZSwgc2NvcmU6IDAsIHZlcmRpY3Q6IFwibWlzc2VkXCIsIGRldGFpbDogXCJDdXJyZW50bHkgb2NjdXBpZWRcIiB9O1xuICBpZiAoc3RhdHVzID09PSBcIm1haW50ZW5hbmNlXCIpIHJldHVybiB7IC4uLmJhc2UsIHNjb3JlOiAwLjE1LCB2ZXJkaWN0OiBcIm1pc3NlZFwiLCBkZXRhaWw6IFwiVW5kZXIgbWFpbnRlbmFuY2VcIiB9O1xuXG4gIGNvbnN0IGRheXNMYXRlID0gTWF0aC5yb3VuZCgobmV3IERhdGUoYXZhaWxhYmxlRnJvbSkuZ2V0VGltZSgpIC0gbmV3IERhdGUoci5tb3ZlSW5EYXRlKS5nZXRUaW1lKCkpIC8gODY0MDAwMDApO1xuXG4gIGlmIChkYXlzTGF0ZSA8PSAwKSB7XG4gICAgLy8gRm9yIHBhcmtpbmcsIFwiaG93IG1hbnkgYXJlIGZyZWVcIiBpcyB0aGUgd2hvbGUgcXVlc3Rpb24sIHNvIHRoZSBub3RlXG4gICAgLy8gYWJvdXQgZnJlZSBzbG90cyBpcyB0aGUgYW5zd2VyIHJhdGhlciB0aGFuIGEgZm9vdG5vdGUuXG4gICAgaWYgKGwuc3BhY2UuY2F0ZWdvcnkgPT09IFwicGFya2luZ1wiKSB7XG4gICAgICBjb25zdCB3YW50ZWQgPSAoci5jYXBhY2l0eS5jYXJTbG90cyA/PyAwKSArIChyLmNhcGFjaXR5Lm1vdG9yY3ljbGVTbG90cyA/PyAwKTtcbiAgICAgIGNvbnN0IGZyZWUgPSBsLnNwYWNlLmF2YWlsYWJpbGl0eS5hdmFpbGFibGVVbml0cyA/PyAxO1xuXG4gICAgICBpZiAod2FudGVkID4gMCAmJiBmcmVlIDwgd2FudGVkKSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgLi4uYmFzZSxcbiAgICAgICAgICBzY29yZTogY2xhbXAwMShmcmVlIC8gd2FudGVkKSxcbiAgICAgICAgICB2ZXJkaWN0OiBmcmVlID4gMCA/IFwicGFydGlhbFwiIDogXCJtaXNzZWRcIixcbiAgICAgICAgICBkZXRhaWw6IG5vdGUgPyBub3RlIDogYCR7ZnJlZX0gZnJlZSwgeW91IG5lZWQgJHt3YW50ZWR9YCxcbiAgICAgICAgfTtcbiAgICAgIH1cbiAgICAgIHJldHVybiB7IC4uLmJhc2UsIHNjb3JlOiAxLCB2ZXJkaWN0OiBcIm1ldFwiLCBkZXRhaWw6IG5vdGUgPz8gXCJGcmVlIG5vd1wiIH07XG4gICAgfVxuXG4gICAgcmV0dXJuIHtcbiAgICAgIC4uLmJhc2UsXG4gICAgICBzY29yZTogc3RhdHVzID09PSBcInBhcnRpYWxseS1hdmFpbGFibGVcIiA/IDAuOCA6IDEsXG4gICAgICB2ZXJkaWN0OiBzdGF0dXMgPT09IFwicGFydGlhbGx5LWF2YWlsYWJsZVwiID8gXCJwYXJ0aWFsXCIgOiBcIm1ldFwiLFxuICAgICAgZGV0YWlsOiBzdGF0dXMgPT09IFwicGFydGlhbGx5LWF2YWlsYWJsZVwiICYmIG5vdGUgPyBgUGFydGx5IGZyZWUg4oCUICR7bm90ZX1gIDogYEZyZWUgZnJvbSAke2xvbmdEYXRlKGF2YWlsYWJsZUZyb20pfSwgYmVmb3JlIHlvdSBuZWVkIGl0YCxcbiAgICB9O1xuICB9XG5cbiAgcmV0dXJuIHtcbiAgICAuLi5iYXNlLFxuICAgIHNjb3JlOiBjbGFtcDAxKDEgLSBkYXlzTGF0ZSAvIDQ1KSxcbiAgICB2ZXJkaWN0OiBkYXlzTGF0ZSA8PSAxNCA/IFwicGFydGlhbFwiIDogXCJtaXNzZWRcIixcbiAgICBkZXRhaWw6IGBGcmVlIGZyb20gJHtsb25nRGF0ZShhdmFpbGFibGVGcm9tKX0sICR7ZGF5c0xhdGV9IGRheSR7ZGF5c0xhdGUgPiAxID8gXCJzXCIgOiBcIlwifSBhZnRlciB5b3Ugd2FudGVkIGl0YCxcbiAgfTtcbn1cblxuLyoqXG4gKiBXaGV0aGVyIHRoZSBzcGFjZSBpcyBiaWcgZW5vdWdoIOKAlCBtZWFzdXJlZCBpbiB3aGF0ZXZlciB1bml0IHRoZSBjYXRlZ29yeVxuICogYWN0dWFsbHkgdXNlcy4gU3F1YXJlIGZlZXQgZm9yIGEgZmxhdCwgc2xvdHMgZm9yIGEgZ2FyYWdlLCBkZWNpbWFscyBmb3IgbGFuZC5cbiAqL1xuZnVuY3Rpb24gY2FwYWNpdHlGYWN0b3IobDogU3BhY2VMaXN0aW5nLCByOiBTZWFyY2hSZXF1aXJlbWVudHMsIHc6IFdlaWdodHMpOiBNYXRjaEZhY3RvciB7XG4gIGNvbnN0IGJhc2UgPSB7IGtleTogXCJzaXplXCIgYXMgY29uc3QsIGxhYmVsOiBjYXBhY2l0eUxhYmVsKGwuc3BhY2UuY2F0ZWdvcnkpLCB3ZWlnaHQ6IHcuY2FwYWNpdHkgfTtcbiAgY29uc3QgYSA9IGwuc3BhY2UuYXR0cmlidXRlcztcbiAgY29uc3QgbmVlZCA9IHIuY2FwYWNpdHk7XG5cbiAgLy8gUGFya2luZyBpcyBzY29yZWQgb24gYXZhaWxhYmlsaXR5IGluc3RlYWQsIHNvIGNhcGFjaXR5IGNhcnJpZXMgbm8gd2VpZ2h0LlxuICBpZiAody5jYXBhY2l0eSA9PT0gMCkge1xuICAgIHJldHVybiB7IC4uLmJhc2UsIHNjb3JlOiAxLCB2ZXJkaWN0OiBcIm1ldFwiLCBkZXRhaWw6IFwiTm90IHNjb3JlZCBmb3IgdGhpcyBraW5kIG9mIHNwYWNlXCIgfTtcbiAgfVxuXG4gIGNvbnN0IHNob3J0ZmFsbCA9IChoYXZlOiBudW1iZXIgfCB1bmRlZmluZWQsIHdhbnQ6IG51bWJlciwgdW5pdDogc3RyaW5nLCB0b2xlcmFuY2UgPSAwLjg1KSA9PiB7XG4gICAgaWYgKGhhdmUgPT09IHVuZGVmaW5lZCkge1xuICAgICAgcmV0dXJuIHsgLi4uYmFzZSwgc2NvcmU6IDAuNiwgdmVyZGljdDogXCJwYXJ0aWFsXCIgYXMgY29uc3QsIGRldGFpbDogYE5vdCBzdGF0ZWQgYnkgdGhlIG93bmVyYCB9O1xuICAgIH1cbiAgICBpZiAoaGF2ZSA+PSB3YW50KSB7XG4gICAgICByZXR1cm4geyAuLi5iYXNlLCBzY29yZTogMSwgdmVyZGljdDogXCJtZXRcIiBhcyBjb25zdCwgZGV0YWlsOiBgJHtoYXZlfSAke3VuaXR9LCBhdCBvciBhYm92ZSB3aGF0IHlvdSBuZWVkYCB9O1xuICAgIH1cbiAgICByZXR1cm4ge1xuICAgICAgLi4uYmFzZSxcbiAgICAgIHNjb3JlOiBjbGFtcDAxKGhhdmUgLyB3YW50KSxcbiAgICAgIHZlcmRpY3Q6IGhhdmUgPj0gd2FudCAqIHRvbGVyYW5jZSA/IChcInBhcnRpYWxcIiBhcyBjb25zdCkgOiAoXCJtaXNzZWRcIiBhcyBjb25zdCksXG4gICAgICBkZXRhaWw6IGAke2hhdmV9ICR7dW5pdH0sIHNob3J0IG9mIHRoZSAke3dhbnR9IHlvdSB3YW50ZWRgLFxuICAgIH07XG4gIH07XG5cbiAgc3dpdGNoIChsLnNwYWNlLmNhdGVnb3J5KSB7XG4gICAgY2FzZSBcImxpdmluZ1wiOiB7XG4gICAgICBpZiAobmVlZC5taW5CZWRyb29tcykgcmV0dXJuIHNob3J0ZmFsbChhLmJlZHJvb21zLCBuZWVkLm1pbkJlZHJvb21zLCBcImJlZHJvb21zXCIpO1xuICAgICAgaWYgKG5lZWQubWluU2l6ZVNxZnQpIHJldHVybiBzaG9ydGZhbGwoYS5zaXplU3FmdCwgbmVlZC5taW5TaXplU3FmdCwgXCJzcWZ0XCIpO1xuICAgICAgYnJlYWs7XG4gICAgfVxuICAgIGNhc2UgXCJidXNpbmVzc1wiOiB7XG4gICAgICBpZiAobmVlZC5taW5Xb3Jrc3RhdGlvbnMpIHJldHVybiBzaG9ydGZhbGwoYS53b3Jrc3RhdGlvbnMsIG5lZWQubWluV29ya3N0YXRpb25zLCBcIndvcmtzdGF0aW9uc1wiKTtcbiAgICAgIGlmIChuZWVkLm1pblNpemVTcWZ0KSByZXR1cm4gc2hvcnRmYWxsKGEuc2l6ZVNxZnQsIG5lZWQubWluU2l6ZVNxZnQsIFwic3FmdFwiKTtcbiAgICAgIGJyZWFrO1xuICAgIH1cbiAgICBjYXNlIFwic3RvcmFnZVwiOiB7XG4gICAgICBpZiAobmVlZC5taW5TaXplU3FmdCkge1xuICAgICAgICBjb25zdCBhcmVhID0gc2hvcnRmYWxsKGEuc2l6ZVNxZnQsIG5lZWQubWluU2l6ZVNxZnQsIFwic3FmdFwiKTtcbiAgICAgICAgLy8gSGVhZHJvb20gZGVjaWRlcyBob3cgbXVjaCB5b3UgY2FuIGFjdHVhbGx5IHN0YWNrIGludG8gdGhhdCBmbG9vci5cbiAgICAgICAgaWYgKG5lZWQubWluQ2VpbGluZ0Z0ICYmIGEuY2VpbGluZ0hlaWdodEZ0ICE9PSB1bmRlZmluZWQgJiYgYS5jZWlsaW5nSGVpZ2h0RnQgPCBuZWVkLm1pbkNlaWxpbmdGdCkge1xuICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAuLi5hcmVhLFxuICAgICAgICAgICAgc2NvcmU6IGFyZWEuc2NvcmUgKiAwLjcsXG4gICAgICAgICAgICB2ZXJkaWN0OiBcInBhcnRpYWxcIixcbiAgICAgICAgICAgIGRldGFpbDogYCR7YS5zaXplU3FmdCA/PyBcIj9cIn0gc3FmdCBidXQgb25seSAke2EuY2VpbGluZ0hlaWdodEZ0fSBmdCBvZiBoZWFkcm9vbWAsXG4gICAgICAgICAgfTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gYXJlYTtcbiAgICAgIH1cbiAgICAgIGJyZWFrO1xuICAgIH1cbiAgICBjYXNlIFwibGFuZFwiOiB7XG4gICAgICBpZiAobmVlZC5taW5MYW5kRGVjaW1hbCkgcmV0dXJuIHNob3J0ZmFsbChhLmxhbmRBcmVhRGVjaW1hbCwgbmVlZC5taW5MYW5kRGVjaW1hbCwgXCJkZWNpbWFsXCIpO1xuICAgICAgYnJlYWs7XG4gICAgfVxuICAgIGNhc2UgXCJwYXJraW5nXCI6XG4gICAgICBicmVhaztcbiAgfVxuXG4gIHJldHVybiB7IC4uLmJhc2UsIHNjb3JlOiAwLjksIHZlcmRpY3Q6IFwibWV0XCIsIGRldGFpbDogXCJZb3UgZGlkbid0IHNldCBhIG1pbmltdW1cIiB9O1xufVxuXG5mdW5jdGlvbiBjYXBhY2l0eUxhYmVsKGNhdGVnb3J5OiBTcGFjZUNhdGVnb3J5KTogc3RyaW5nIHtcbiAgc3dpdGNoIChjYXRlZ29yeSkge1xuICAgIGNhc2UgXCJsaXZpbmdcIjogcmV0dXJuIFwiU2l6ZVwiO1xuICAgIGNhc2UgXCJidXNpbmVzc1wiOiByZXR1cm4gXCJTcGFjZVwiO1xuICAgIGNhc2UgXCJzdG9yYWdlXCI6IHJldHVybiBcIkNhcGFjaXR5XCI7XG4gICAgY2FzZSBcInBhcmtpbmdcIjogcmV0dXJuIFwiU2xvdHNcIjtcbiAgICBjYXNlIFwibGFuZFwiOiByZXR1cm4gXCJQbG90IHNpemVcIjtcbiAgfVxufVxuXG5cbmZ1bmN0aW9uIGFtZW5pdGllc0ZhY3RvcihsOiBTcGFjZUxpc3RpbmcsIHI6IFNlYXJjaFJlcXVpcmVtZW50cywgdzogV2VpZ2h0cyk6IE1hdGNoRmFjdG9yIHtcbiAgY29uc3QgYmFzZSA9IHsga2V5OiBcImFtZW5pdGllc1wiIGFzIGNvbnN0LCBsYWJlbDogXCJBbWVuaXRpZXNcIiwgd2VpZ2h0OiB3LmFtZW5pdGllcyB9O1xuXG4gIGlmIChyLmFtZW5pdGllcy5sZW5ndGggPT09IDApIHtcbiAgICByZXR1cm4geyAuLi5iYXNlLCBzY29yZTogMC45LCB2ZXJkaWN0OiBcIm1ldFwiLCBkZXRhaWw6IFwiWW91IGRpZG4ndCBuYW1lIGFueXRoaW5nIGVzc2VudGlhbFwiIH07XG4gIH1cblxuICBjb25zdCBtaXNzaW5nID0gci5hbWVuaXRpZXMuZmlsdGVyKChhKSA9PiAhbC5zcGFjZS5hbWVuaXRpZXMuaW5jbHVkZXMoYSkpO1xuICBpZiAobWlzc2luZy5sZW5ndGggPT09IDApIHtcbiAgICByZXR1cm4geyAuLi5iYXNlLCBzY29yZTogMSwgdmVyZGljdDogXCJtZXRcIiwgZGV0YWlsOiBcIkhhcyBldmVyeXRoaW5nIHlvdSBhc2tlZCBmb3JcIiB9O1xuICB9XG5cbiAgY29uc3Qgc2NvcmUgPSAoci5hbWVuaXRpZXMubGVuZ3RoIC0gbWlzc2luZy5sZW5ndGgpIC8gci5hbWVuaXRpZXMubGVuZ3RoO1xuICByZXR1cm4ge1xuICAgIC4uLmJhc2UsXG4gICAgc2NvcmUsXG4gICAgdmVyZGljdDogc2NvcmUgPj0gMC41ID8gXCJwYXJ0aWFsXCIgOiBcIm1pc3NlZFwiLFxuICAgIGRldGFpbDogYE5vICR7bWlzc2luZy5tYXAoKG0pID0+IEFNRU5JVElFU1ttXS5sYWJlbC50b0xvd2VyQ2FzZSgpKS5qb2luKFwiLCBcIil9YCxcbiAgfTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHNjb3JlTGlzdGluZyhsOiBTcGFjZUxpc3RpbmcsIHI6IFNlYXJjaFJlcXVpcmVtZW50cyk6IE1hdGNoUmVzdWx0IHtcbiAgLy8gV2VpZ2h0cyBjb21lIGZyb20gd2hhdCB0aGUgbGlzdGluZyBpcywgbm90IGZyb20gd2hhdCB0aGUgc2VhcmNoZXIgYXNrZWRcbiAgLy8gZm9yLCBzbyBhIGdhcmFnZSBpcyBuZXZlciBqdWRnZWQgb24gZmxvb3IgYXJlYSBpdCBkb2VzIG5vdCBoYXZlLlxuICBjb25zdCB3ID0gd2VpZ2h0c0ZvcihsLnNwYWNlLmNhdGVnb3J5KTtcblxuICBjb25zdCBmYWN0b3JzID0gW1xuICAgIGJ1ZGdldEZhY3RvcihsLCByLCB3KSxcbiAgICBsb2NhdGlvbkZhY3RvcihsLCByLCB3KSxcbiAgICB0eXBlRmFjdG9yKGwsIHIsIHcpLFxuICAgIGF2YWlsYWJpbGl0eUZhY3RvcihsLCByLCB3KSxcbiAgICBjYXBhY2l0eUZhY3RvcihsLCByLCB3KSxcbiAgICBhbWVuaXRpZXNGYWN0b3IobCwgciwgdyksXG4gIF0uZmlsdGVyKChmKSA9PiBmLndlaWdodCA+IDApO1xuXG4gIGNvbnN0IHdlaWdodGVkID0gZmFjdG9ycy5yZWR1Y2UoKHMsIGYpID0+IHMgKyBmLnNjb3JlICogZi53ZWlnaHQsIDApO1xuICBjb25zdCB0b3RhbCA9IGZhY3RvcnMucmVkdWNlKChzLCBmKSA9PiBzICsgZi53ZWlnaHQsIDApO1xuICBjb25zdCBwY3QgPSAod2VpZ2h0ZWQgLyB0b3RhbCkgKiAxMDA7XG5cbiAgLy8gT25seSBhIGdlbnVpbmVseSBwZXJmZWN0IGZpdCByZWFkcyAxMDAuIFJvdW5kaW5nIDk5LjYgdXAgd2hpbGUgYSBmYWN0b3IgaXNcbiAgLy8gc3RpbGwgZmxhZ2dlZCBwYXJ0aWFsIHdvdWxkIGNvbnRyYWRpY3QgdGhlIHJlYXNvbnMgc2hvd24gYmVzaWRlIGl0LlxuICBjb25zdCBzY29yZSA9IHBjdCA+PSA5OS45OTUgPyAxMDAgOiBNYXRoLm1pbig5OSwgTWF0aC5yb3VuZChwY3QpKTtcblxuICByZXR1cm4geyBzcGFjZUlkOiBsLnNwYWNlLmlkLCBzY29yZSwgZmFjdG9ycyB9O1xufVxuXG5leHBvcnQgZnVuY3Rpb24gc2NvcmVBbGwobGlzdGluZ3M6IFNwYWNlTGlzdGluZ1tdLCByOiBTZWFyY2hSZXF1aXJlbWVudHMpOiBNYXA8c3RyaW5nLCBNYXRjaFJlc3VsdD4ge1xuICBjb25zdCBtYXAgPSBuZXcgTWFwPHN0cmluZywgTWF0Y2hSZXN1bHQ+KCk7XG4gIGZvciAoY29uc3QgbCBvZiBsaXN0aW5ncykgbWFwLnNldChsLnNwYWNlLmlkLCBzY29yZUxpc3RpbmcobCwgcikpO1xuICByZXR1cm4gbWFwO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gbWF0Y2hMYWJlbChzY29yZTogbnVtYmVyKTogc3RyaW5nIHtcbiAgaWYgKHNjb3JlID49IDkwKSByZXR1cm4gXCJFeGNlbGxlbnQgbWF0Y2hcIjtcbiAgaWYgKHNjb3JlID49IDc4KSByZXR1cm4gXCJTdHJvbmcgbWF0Y2hcIjtcbiAgaWYgKHNjb3JlID49IDYyKSByZXR1cm4gXCJXb3J0aCBhIGxvb2tcIjtcbiAgcmV0dXJuIFwiTG9vc2UgbWF0Y2hcIjtcbn1cblxuLyoqXG4gKiBXaGVuIHRoZSBleGFjdCBzZWFyY2ggY29tZXMgdXAgc2hvcnQsIHN1Z2dlc3Qgd2hhdCdzIGFjdHVhbGx5IG5lYXIgaXQgYW5kXG4gKiBzYXkgd2h5IOKAlCByYXRoZXIgdGhhbiBhIGJhcmUgXCJubyByZXN1bHRzXCIuXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgTmVhcmJ5U3VnZ2VzdGlvbiB7XG4gIGxpc3Rpbmc6IFNwYWNlTGlzdGluZztcbiAgc2NvcmU6IG51bWJlcjtcbiAgZGlzdGFuY2VLbTogbnVtYmVyIHwgbnVsbDtcbiAgcmVhc29uOiBzdHJpbmc7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBuZWFyYnlBbHRlcm5hdGl2ZXMoXG4gIGxpc3RpbmdzOiBTcGFjZUxpc3RpbmdbXSxcbiAgcjogU2VhcmNoUmVxdWlyZW1lbnRzLFxuICBleGNsdWRlSWRzOiBzdHJpbmdbXSxcbiAgbGltaXQgPSA2LFxuKTogTmVhcmJ5U3VnZ2VzdGlvbltdIHtcbiAgcmV0dXJuIGxpc3RpbmdzXG4gICAgLmZpbHRlcigobCkgPT4gIWV4Y2x1ZGVJZHMuaW5jbHVkZXMobC5zcGFjZS5pZCkgJiYgbC5zcGFjZS5hdmFpbGFiaWxpdHkuc3RhdHVzICE9PSBcIm9jY3VwaWVkXCIpXG4gICAgLm1hcCgobCkgPT4ge1xuICAgICAgY29uc3QgbWF0Y2ggPSBzY29yZUxpc3RpbmcobCwgcik7XG4gICAgICBjb25zdCBrbSA9IGRpc3RhbmNlRnJvbUFyZWEobCwgci5hcmVhKTtcbiAgICAgIGNvbnN0IGFtb3VudCA9IGwuc3BhY2UuY29zdC5lc3RpbWF0ZWRNb250aGx5ID8/IGwuc3BhY2UuY29zdC5wcmljZTtcblxuICAgICAgbGV0IHJlYXNvbjogc3RyaW5nO1xuICAgICAgaWYgKGwucHJvcGVydHkuYXJlYSAhPT0gci5hcmVhICYmIGttICE9PSBudWxsICYmIGttIDw9IDYpIHtcbiAgICAgICAgcmVhc29uID0gYCR7a20udG9GaXhlZCgxKX0ga20gZnJvbSAke3IuYXJlYX0sIGluICR7bC5wcm9wZXJ0eS5hcmVhfWA7XG4gICAgICB9IGVsc2UgaWYgKGFtb3VudCA8IHIuYnVkZ2V0TWluKSB7XG4gICAgICAgIHJlYXNvbiA9IGBDaGVhcGVyIHRoYW4geW91ciByYW5nZSBhdCAke21vbmV5KGFtb3VudCl9YDtcbiAgICAgIH0gZWxzZSBpZiAoci5zcGFjZVR5cGUgIT09IFwiYW55XCIgJiYgbC5zcGFjZS5zcGFjZVR5cGUgIT09IHIuc3BhY2VUeXBlKSB7XG4gICAgICAgIHJlYXNvbiA9IGBBICR7U1BBQ0VfVFlQRV9MQUJFTFtsLnNwYWNlLnNwYWNlVHlwZV0udG9Mb3dlckNhc2UoKX0gaW5zdGVhZGA7XG4gICAgICB9IGVsc2UgaWYgKGFtb3VudCA+IHIuYnVkZ2V0TWF4KSB7XG4gICAgICAgIHJlYXNvbiA9IGAke21vbmV5KGFtb3VudCAtIHIuYnVkZ2V0TWF4KX0gYWJvdmUgeW91ciBtYXhpbXVtYDtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHJlYXNvbiA9IFwiQ2xvc2Ugb24gZXZlcnl0aGluZyBlbHNlXCI7XG4gICAgICB9XG5cbiAgICAgIHJldHVybiB7IGxpc3Rpbmc6IGwsIHNjb3JlOiBtYXRjaC5zY29yZSwgZGlzdGFuY2VLbToga20sIHJlYXNvbiB9O1xuICAgIH0pXG4gICAgLmZpbHRlcigocykgPT4gcy5zY29yZSA+PSA0NSlcbiAgICAuc29ydCgoYSwgYikgPT4gYi5zY29yZSAtIGEuc2NvcmUpXG4gICAgLnNsaWNlKDAsIGxpbWl0KTtcbn1cblxuZXhwb3J0IGNvbnN0IERFRkFVTFRfUkVRVUlSRU1FTlRTOiBTZWFyY2hSZXF1aXJlbWVudHMgPSB7XG4gIHRyYW5zYWN0aW9uOiBcInJlbnRcIixcbiAgY2F0ZWdvcnk6IFwiYW55XCIsXG4gIHNwYWNlVHlwZTogXCJhbnlcIixcbiAgYXJlYTogXCJCYWRkYVwiLFxuICBidWRnZXRNaW46IDYwMDAsXG4gIGJ1ZGdldE1heDogMTQwMDAsXG4gIGNhcGFjaXR5OiB7fSxcbiAgbW92ZUluRGF0ZTogbmV3IERhdGUoRGF0ZS5ub3coKSArIDIxICogODY0MDAwMDApLnRvSVNPU3RyaW5nKCkuc2xpY2UoMCwgMTApLFxuICBhbWVuaXRpZXM6IFtdLFxuICBvY2N1cGFuY3k6IFwiYW55XCIsXG59O1xuXG4vKipcbiAqIFdoZXRoZXIgYSBsaXN0aW5nIHdpbGwgYWNjZXB0IHRoaXMgaG91c2Vob2xkIGF0IGFsbC5cbiAqXG4gKiBEZWxpYmVyYXRlbHkgbm90IHBhcnQgb2YgdGhlIHNjb3JlOiBiZWluZyB0b2xkIGEgcGxhY2UgaXMgYSA3OCUgbWF0Y2ggd2hlblxuICogdGhlIG93bmVyIHdvbid0IHRha2UgYmFjaGVsb3JzIHdhc3RlcyBhIHZpZXdpbmcgYW5kIGEgcGhvbmUgY2FsbC4gTGlzdGluZ3NcbiAqIHRoYXQgZXhjbHVkZSB5b3UgYXJlIGZpbHRlcmVkIG91dCBpbnN0ZWFkLlxuICovXG5leHBvcnQgZnVuY3Rpb24gYWNjZXB0c09jY3VwYW5jeShsOiBTcGFjZUxpc3RpbmcsIG9jY3VwYW5jeTogU2VhcmNoUmVxdWlyZW1lbnRzW1wib2NjdXBhbmN5XCJdKTogYm9vbGVhbiB7XG4gIGlmIChvY2N1cGFuY3kgPT09IFwiYW55XCIpIHJldHVybiB0cnVlO1xuICBpZiAobC5zcGFjZS5jYXRlZ29yeSAhPT0gXCJsaXZpbmdcIikgcmV0dXJuIHRydWU7XG5cbiAgY29uc3QgcnVsZXMgPSBsLnNwYWNlLnJ1bGVzO1xuICBpZiAoIXJ1bGVzKSByZXR1cm4gdHJ1ZTtcblxuICBzd2l0Y2ggKG9jY3VwYW5jeSkge1xuICAgIGNhc2UgXCJmYW1pbHlcIjpcbiAgICAgIHJldHVybiBydWxlcy5mYW1pbHlBbGxvd2VkO1xuICAgIGNhc2UgXCJiYWNoZWxvclwiOlxuICAgICAgcmV0dXJuIHJ1bGVzLmJhY2hlbG9yQWxsb3dlZDtcbiAgICBjYXNlIFwic3R1ZGVudFwiOlxuICAgICAgcmV0dXJuIHJ1bGVzLnN0dWRlbnRGcmllbmRseSB8fCBydWxlcy5iYWNoZWxvckFsbG93ZWQ7XG4gICAgZGVmYXVsdDpcbiAgICAgIHJldHVybiB0cnVlO1xuICB9XG59XG4iXSwibWFwcGluZ3MiOiJBQU1BLFNBQVMsa0JBQWtCLHdCQUF3QjtBQUVuRCxTQUFTLGlCQUFpQjtBQUMxQixTQUFTLE9BQU8sbUJBQW1CO0FBQ25DLFNBQVMsT0FBTyxnQkFBZ0I7QUEwQnpCLGFBQU0sa0JBQWtEO0FBQUE7QUFBQSxFQUU3RCxRQUFRLEVBQUUsUUFBUSxJQUFJLFVBQVUsSUFBSSxXQUFXLElBQUksY0FBYyxJQUFJLFVBQVUsR0FBRyxXQUFXLEdBQUc7QUFBQTtBQUFBLEVBR2hHLFVBQVUsRUFBRSxRQUFRLElBQUksVUFBVSxJQUFJLFdBQVcsSUFBSSxjQUFjLElBQUksVUFBVSxJQUFJLFdBQVcsRUFBRTtBQUFBO0FBQUE7QUFBQSxFQUlsRyxTQUFTLEVBQUUsUUFBUSxJQUFJLFVBQVUsSUFBSSxXQUFXLElBQUksY0FBYyxJQUFJLFVBQVUsSUFBSSxXQUFXLEdBQUc7QUFBQTtBQUFBO0FBQUEsRUFJbEcsU0FBUyxFQUFFLFFBQVEsSUFBSSxVQUFVLElBQUksV0FBVyxJQUFJLGNBQWMsSUFBSSxVQUFVLEdBQUcsV0FBVyxHQUFHO0FBQUE7QUFBQTtBQUFBLEVBSWpHLE1BQU0sRUFBRSxRQUFRLElBQUksVUFBVSxJQUFJLFdBQVcsSUFBSSxjQUFjLEdBQUcsVUFBVSxJQUFJLFdBQVcsRUFBRTtBQUMvRjtBQUdPLGdCQUFTLFdBQVcsVUFBa0M7QUFDM0QsU0FBTyxnQkFBZ0IsUUFBUTtBQUNqQztBQUVBLE1BQU0sVUFBVSxDQUFDLE1BQWMsS0FBSyxJQUFJLEdBQUcsS0FBSyxJQUFJLEdBQUcsQ0FBQyxDQUFDO0FBRWxELGdCQUFTLGlCQUFpQixTQUF1QixVQUFpQztBQUN2RixRQUFNLE9BQU8sTUFBTSxLQUFLLENBQUMsTUFBTSxFQUFFLFNBQVMsUUFBUTtBQUNsRCxNQUFJLENBQUMsS0FBTSxRQUFPO0FBQ2xCLFNBQU8sWUFBWSxLQUFLLFVBQVUsS0FBSyxXQUFXLFFBQVEsU0FBUyxVQUFVLFFBQVEsU0FBUyxTQUFTO0FBQ3pHO0FBRUEsU0FBUyxhQUFhLEdBQWlCLEdBQXVCLEdBQXlCO0FBQ3JGLFFBQU0sT0FBTyxFQUFFLEtBQUssVUFBbUIsT0FBTyxVQUFVLFFBQVEsRUFBRSxPQUFPO0FBQ3pFLFFBQU0sRUFBRSxLQUFLLElBQUksRUFBRTtBQUluQixRQUFNLGFBQWEsS0FBSyxxQkFBcUIsUUFBUSxFQUFFLE1BQU0sZ0JBQWdCO0FBQzdFLFFBQU0sU0FBUyxhQUFhLEtBQUssbUJBQW9CLEtBQUs7QUFFMUQsTUFBSSxVQUFVLEVBQUUsYUFBYSxVQUFVLEVBQUUsV0FBVztBQUNsRCxXQUFPO0FBQUEsTUFDTCxHQUFHO0FBQUEsTUFDSCxPQUFPO0FBQUEsTUFDUCxTQUFTO0FBQUEsTUFDVCxRQUFRLGFBQ0osR0FBRyxNQUFNLE1BQU0sQ0FBQyx1Q0FDaEIsR0FBRyxNQUFNLE1BQU0sQ0FBQztBQUFBLElBQ3RCO0FBQUEsRUFDRjtBQUVBLE1BQUksU0FBUyxFQUFFLFdBQVc7QUFDeEIsVUFBTSxPQUFPLEVBQUUsWUFBWSxVQUFVLEtBQUssSUFBSSxFQUFFLFdBQVcsQ0FBQztBQUM1RCxXQUFPLEVBQUUsR0FBRyxNQUFNLE9BQU8sUUFBUSxJQUFJLE1BQU0sR0FBRyxHQUFHLFNBQVMsT0FBTyxRQUFRLEdBQUcsTUFBTSxNQUFNLENBQUMsNkJBQTZCO0FBQUEsRUFDeEg7QUFFQSxRQUFNLGFBQWEsU0FBUyxFQUFFLGFBQWEsS0FBSyxJQUFJLEVBQUUsV0FBVyxDQUFDO0FBQ2xFLFNBQU87QUFBQSxJQUNMLEdBQUc7QUFBQSxJQUNILE9BQU8sUUFBUSxJQUFJLFlBQVksR0FBRztBQUFBLElBQ2xDLFNBQVMsYUFBYSxPQUFPLFlBQVk7QUFBQSxJQUN6QyxRQUFRLEdBQUcsTUFBTSxTQUFTLEVBQUUsU0FBUyxDQUFDLHFCQUFxQixhQUFhLDhCQUE4QixFQUFFO0FBQUEsRUFDMUc7QUFDRjtBQUVBLFNBQVMsZUFBZSxHQUFpQixHQUF1QixHQUF5QjtBQUN2RixRQUFNLE9BQU8sRUFBRSxLQUFLLFlBQXFCLE9BQU8sWUFBWSxRQUFRLEVBQUUsU0FBUztBQUUvRSxNQUFJLEVBQUUsU0FBUyxTQUFTLEVBQUUsTUFBTTtBQUM5QixXQUFPLEVBQUUsR0FBRyxNQUFNLE9BQU8sR0FBRyxTQUFTLE9BQU8sUUFBUSxNQUFNLEVBQUUsU0FBUyxZQUFZLHVCQUF1QjtBQUFBLEVBQzFHO0FBRUEsUUFBTSxLQUFLLGlCQUFpQixHQUFHLEVBQUUsSUFBSTtBQUNyQyxNQUFJLE9BQU8sTUFBTTtBQUNmLFdBQU8sRUFBRSxHQUFHLE1BQU0sT0FBTyxLQUFLLFNBQVMsV0FBVyxRQUFRLE1BQU0sRUFBRSxTQUFTLElBQUksR0FBRztBQUFBLEVBQ3BGO0FBRUEsU0FBTztBQUFBLElBQ0wsR0FBRztBQUFBLElBQ0gsT0FBTyxRQUFRLElBQUksS0FBSyxFQUFFO0FBQUEsSUFDMUIsU0FBUyxNQUFNLElBQUksWUFBWTtBQUFBLElBQy9CLFFBQVEsR0FBRyxHQUFHLFFBQVEsQ0FBQyxDQUFDLFlBQVksRUFBRSxJQUFJLFFBQVEsRUFBRSxTQUFTLElBQUk7QUFBQSxFQUNuRTtBQUNGO0FBRUEsTUFBTSxlQUFrRDtBQUFBLEVBQ3RELE1BQU0sQ0FBQyxlQUFlLFFBQVE7QUFBQSxFQUM5QixlQUFlLENBQUMsUUFBUSxRQUFRO0FBQUEsRUFDaEMsUUFBUSxDQUFDLFFBQVEsZUFBZSxXQUFXO0FBQUEsRUFDM0MsV0FBVyxDQUFDLFVBQVUsT0FBTztBQUFBLEVBQzdCLE9BQU8sQ0FBQyxhQUFhLFlBQVksV0FBVztBQUFBLEVBQzVDLFlBQVksQ0FBQyxTQUFTLFdBQVc7QUFBQSxFQUNqQyxNQUFNLENBQUMsUUFBUTtBQUFBLEVBQ2YsUUFBUSxDQUFDLE1BQU07QUFBQSxFQUNmLFFBQVEsQ0FBQyxNQUFNO0FBQUEsRUFDZixRQUFRLENBQUMsY0FBYztBQUFBLEVBQ3ZCLGdCQUFnQixDQUFDLFFBQVE7QUFBQSxFQUN6QixVQUFVLENBQUMsUUFBUSxXQUFXO0FBQ2hDO0FBRUEsU0FBUyxXQUFXLEdBQWlCLEdBQXVCLEdBQXlCO0FBQ25GLFFBQU0sT0FBTyxFQUFFLEtBQUssYUFBc0IsT0FBTyxjQUFjLFFBQVEsRUFBRSxVQUFVO0FBQ25GLFFBQU0sT0FBTyxFQUFFLE1BQU07QUFFckIsTUFBSSxFQUFFLGNBQWMsT0FBTztBQUN6QixRQUFJLFNBQVMsRUFBRSxXQUFXO0FBQ3hCLGFBQU8sRUFBRSxHQUFHLE1BQU0sT0FBTyxHQUFHLFNBQVMsT0FBTyxRQUFRLDBDQUEwQztBQUFBLElBQ2hHO0FBQ0EsUUFBSSxhQUFhLEVBQUUsU0FBUyxHQUFHLFNBQVMsSUFBSSxHQUFHO0FBQzdDLGFBQU87QUFBQSxRQUNMLEdBQUc7QUFBQSxRQUNILE9BQU87QUFBQSxRQUNQLFNBQVM7QUFBQSxRQUNULFFBQVEsS0FBSyxpQkFBaUIsSUFBSSxFQUFFLFlBQVksQ0FBQyxrQkFBa0IsaUJBQWlCLEVBQUUsU0FBUyxFQUFFLFlBQVksQ0FBQztBQUFBLE1BQ2hIO0FBQUEsSUFDRjtBQUNBLFdBQU8sRUFBRSxHQUFHLE1BQU0sT0FBTyxHQUFHLFNBQVMsVUFBVSxRQUFRLEtBQUssaUJBQWlCLElBQUksRUFBRSxZQUFZLENBQUMsMkJBQTJCO0FBQUEsRUFDN0g7QUFFQSxNQUFJLEVBQUUsYUFBYSxPQUFPO0FBQ3hCLFVBQU0sYUFBYSxpQkFBaUIsSUFBSSxNQUFNLEVBQUU7QUFDaEQsV0FBTztBQUFBLE1BQ0wsR0FBRztBQUFBLE1BQ0gsT0FBTyxhQUFhLE9BQU87QUFBQSxNQUMzQixTQUFTLGFBQWEsUUFBUTtBQUFBLE1BQzlCLFFBQVEsYUFBYSxLQUFLLGlCQUFpQixJQUFJLEVBQUUsWUFBWSxDQUFDLCtCQUErQjtBQUFBLElBQy9GO0FBQUEsRUFDRjtBQUVBLFNBQU8sRUFBRSxHQUFHLE1BQU0sT0FBTyxLQUFLLFNBQVMsT0FBTyxRQUFRLG1DQUFtQztBQUMzRjtBQUVBLFNBQVMsbUJBQW1CLEdBQWlCLEdBQXVCLEdBQXlCO0FBQzNGLFFBQU0sT0FBTyxFQUFFLEtBQUssZ0JBQXlCLE9BQU8sZ0JBQWdCLFFBQVEsRUFBRSxhQUFhO0FBQzNGLFFBQU0sRUFBRSxRQUFRLGVBQWUsS0FBSyxJQUFJLEVBQUUsTUFBTTtBQUVoRCxNQUFJLFdBQVcsV0FBWSxRQUFPLEVBQUUsR0FBRyxNQUFNLE9BQU8sR0FBRyxTQUFTLFVBQVUsUUFBUSxxQkFBcUI7QUFDdkcsTUFBSSxXQUFXLGNBQWUsUUFBTyxFQUFFLEdBQUcsTUFBTSxPQUFPLE1BQU0sU0FBUyxVQUFVLFFBQVEsb0JBQW9CO0FBRTVHLFFBQU0sV0FBVyxLQUFLLE9BQU8sSUFBSSxLQUFLLGFBQWEsRUFBRSxRQUFRLElBQUksSUFBSSxLQUFLLEVBQUUsVUFBVSxFQUFFLFFBQVEsS0FBSyxLQUFRO0FBRTdHLE1BQUksWUFBWSxHQUFHO0FBR2pCLFFBQUksRUFBRSxNQUFNLGFBQWEsV0FBVztBQUNsQyxZQUFNLFVBQVUsRUFBRSxTQUFTLFlBQVksTUFBTSxFQUFFLFNBQVMsbUJBQW1CO0FBQzNFLFlBQU0sT0FBTyxFQUFFLE1BQU0sYUFBYSxrQkFBa0I7QUFFcEQsVUFBSSxTQUFTLEtBQUssT0FBTyxRQUFRO0FBQy9CLGVBQU87QUFBQSxVQUNMLEdBQUc7QUFBQSxVQUNILE9BQU8sUUFBUSxPQUFPLE1BQU07QUFBQSxVQUM1QixTQUFTLE9BQU8sSUFBSSxZQUFZO0FBQUEsVUFDaEMsUUFBUSxPQUFPLE9BQU8sR0FBRyxJQUFJLG1CQUFtQixNQUFNO0FBQUEsUUFDeEQ7QUFBQSxNQUNGO0FBQ0EsYUFBTyxFQUFFLEdBQUcsTUFBTSxPQUFPLEdBQUcsU0FBUyxPQUFPLFFBQVEsUUFBUSxXQUFXO0FBQUEsSUFDekU7QUFFQSxXQUFPO0FBQUEsTUFDTCxHQUFHO0FBQUEsTUFDSCxPQUFPLFdBQVcsd0JBQXdCLE1BQU07QUFBQSxNQUNoRCxTQUFTLFdBQVcsd0JBQXdCLFlBQVk7QUFBQSxNQUN4RCxRQUFRLFdBQVcseUJBQXlCLE9BQU8saUJBQWlCLElBQUksS0FBSyxhQUFhLFNBQVMsYUFBYSxDQUFDO0FBQUEsSUFDbkg7QUFBQSxFQUNGO0FBRUEsU0FBTztBQUFBLElBQ0wsR0FBRztBQUFBLElBQ0gsT0FBTyxRQUFRLElBQUksV0FBVyxFQUFFO0FBQUEsSUFDaEMsU0FBUyxZQUFZLEtBQUssWUFBWTtBQUFBLElBQ3RDLFFBQVEsYUFBYSxTQUFTLGFBQWEsQ0FBQyxLQUFLLFFBQVEsT0FBTyxXQUFXLElBQUksTUFBTSxFQUFFO0FBQUEsRUFDekY7QUFDRjtBQU1BLFNBQVMsZUFBZSxHQUFpQixHQUF1QixHQUF5QjtBQUN2RixRQUFNLE9BQU8sRUFBRSxLQUFLLFFBQWlCLE9BQU8sY0FBYyxFQUFFLE1BQU0sUUFBUSxHQUFHLFFBQVEsRUFBRSxTQUFTO0FBQ2hHLFFBQU0sSUFBSSxFQUFFLE1BQU07QUFDbEIsUUFBTSxPQUFPLEVBQUU7QUFHZixNQUFJLEVBQUUsYUFBYSxHQUFHO0FBQ3BCLFdBQU8sRUFBRSxHQUFHLE1BQU0sT0FBTyxHQUFHLFNBQVMsT0FBTyxRQUFRLG9DQUFvQztBQUFBLEVBQzFGO0FBRUEsUUFBTSxZQUFZLENBQUMsTUFBMEIsTUFBYyxNQUFjLFlBQVksU0FBUztBQUM1RixRQUFJLFNBQVMsUUFBVztBQUN0QixhQUFPLEVBQUUsR0FBRyxNQUFNLE9BQU8sS0FBSyxTQUFTLFdBQW9CLFFBQVEsMEJBQTBCO0FBQUEsSUFDL0Y7QUFDQSxRQUFJLFFBQVEsTUFBTTtBQUNoQixhQUFPLEVBQUUsR0FBRyxNQUFNLE9BQU8sR0FBRyxTQUFTLE9BQWdCLFFBQVEsR0FBRyxJQUFJLElBQUksSUFBSSw4QkFBOEI7QUFBQSxJQUM1RztBQUNBLFdBQU87QUFBQSxNQUNMLEdBQUc7QUFBQSxNQUNILE9BQU8sUUFBUSxPQUFPLElBQUk7QUFBQSxNQUMxQixTQUFTLFFBQVEsT0FBTyxZQUFhLFlBQXVCO0FBQUEsTUFDNUQsUUFBUSxHQUFHLElBQUksSUFBSSxJQUFJLGtCQUFrQixJQUFJO0FBQUEsSUFDL0M7QUFBQSxFQUNGO0FBRUEsVUFBUSxFQUFFLE1BQU0sVUFBVTtBQUFBLElBQ3hCLEtBQUssVUFBVTtBQUNiLFVBQUksS0FBSyxZQUFhLFFBQU8sVUFBVSxFQUFFLFVBQVUsS0FBSyxhQUFhLFVBQVU7QUFDL0UsVUFBSSxLQUFLLFlBQWEsUUFBTyxVQUFVLEVBQUUsVUFBVSxLQUFLLGFBQWEsTUFBTTtBQUMzRTtBQUFBLElBQ0Y7QUFBQSxJQUNBLEtBQUssWUFBWTtBQUNmLFVBQUksS0FBSyxnQkFBaUIsUUFBTyxVQUFVLEVBQUUsY0FBYyxLQUFLLGlCQUFpQixjQUFjO0FBQy9GLFVBQUksS0FBSyxZQUFhLFFBQU8sVUFBVSxFQUFFLFVBQVUsS0FBSyxhQUFhLE1BQU07QUFDM0U7QUFBQSxJQUNGO0FBQUEsSUFDQSxLQUFLLFdBQVc7QUFDZCxVQUFJLEtBQUssYUFBYTtBQUNwQixjQUFNLE9BQU8sVUFBVSxFQUFFLFVBQVUsS0FBSyxhQUFhLE1BQU07QUFFM0QsWUFBSSxLQUFLLGdCQUFnQixFQUFFLG9CQUFvQixVQUFhLEVBQUUsa0JBQWtCLEtBQUssY0FBYztBQUNqRyxpQkFBTztBQUFBLFlBQ0wsR0FBRztBQUFBLFlBQ0gsT0FBTyxLQUFLLFFBQVE7QUFBQSxZQUNwQixTQUFTO0FBQUEsWUFDVCxRQUFRLEdBQUcsRUFBRSxZQUFZLEdBQUcsa0JBQWtCLEVBQUUsZUFBZTtBQUFBLFVBQ2pFO0FBQUEsUUFDRjtBQUNBLGVBQU87QUFBQSxNQUNUO0FBQ0E7QUFBQSxJQUNGO0FBQUEsSUFDQSxLQUFLLFFBQVE7QUFDWCxVQUFJLEtBQUssZUFBZ0IsUUFBTyxVQUFVLEVBQUUsaUJBQWlCLEtBQUssZ0JBQWdCLFNBQVM7QUFDM0Y7QUFBQSxJQUNGO0FBQUEsSUFDQSxLQUFLO0FBQ0g7QUFBQSxFQUNKO0FBRUEsU0FBTyxFQUFFLEdBQUcsTUFBTSxPQUFPLEtBQUssU0FBUyxPQUFPLFFBQVEsMkJBQTJCO0FBQ25GO0FBRUEsU0FBUyxjQUFjLFVBQWlDO0FBQ3RELFVBQVEsVUFBVTtBQUFBLElBQ2hCLEtBQUs7QUFBVSxhQUFPO0FBQUEsSUFDdEIsS0FBSztBQUFZLGFBQU87QUFBQSxJQUN4QixLQUFLO0FBQVcsYUFBTztBQUFBLElBQ3ZCLEtBQUs7QUFBVyxhQUFPO0FBQUEsSUFDdkIsS0FBSztBQUFRLGFBQU87QUFBQSxFQUN0QjtBQUNGO0FBR0EsU0FBUyxnQkFBZ0IsR0FBaUIsR0FBdUIsR0FBeUI7QUFDeEYsUUFBTSxPQUFPLEVBQUUsS0FBSyxhQUFzQixPQUFPLGFBQWEsUUFBUSxFQUFFLFVBQVU7QUFFbEYsTUFBSSxFQUFFLFVBQVUsV0FBVyxHQUFHO0FBQzVCLFdBQU8sRUFBRSxHQUFHLE1BQU0sT0FBTyxLQUFLLFNBQVMsT0FBTyxRQUFRLHFDQUFxQztBQUFBLEVBQzdGO0FBRUEsUUFBTSxVQUFVLEVBQUUsVUFBVSxPQUFPLENBQUMsTUFBTSxDQUFDLEVBQUUsTUFBTSxVQUFVLFNBQVMsQ0FBQyxDQUFDO0FBQ3hFLE1BQUksUUFBUSxXQUFXLEdBQUc7QUFDeEIsV0FBTyxFQUFFLEdBQUcsTUFBTSxPQUFPLEdBQUcsU0FBUyxPQUFPLFFBQVEsK0JBQStCO0FBQUEsRUFDckY7QUFFQSxRQUFNLFNBQVMsRUFBRSxVQUFVLFNBQVMsUUFBUSxVQUFVLEVBQUUsVUFBVTtBQUNsRSxTQUFPO0FBQUEsSUFDTCxHQUFHO0FBQUEsSUFDSDtBQUFBLElBQ0EsU0FBUyxTQUFTLE1BQU0sWUFBWTtBQUFBLElBQ3BDLFFBQVEsTUFBTSxRQUFRLElBQUksQ0FBQyxNQUFNLFVBQVUsQ0FBQyxFQUFFLE1BQU0sWUFBWSxDQUFDLEVBQUUsS0FBSyxJQUFJLENBQUM7QUFBQSxFQUMvRTtBQUNGO0FBRU8sZ0JBQVMsYUFBYSxHQUFpQixHQUFvQztBQUdoRixRQUFNLElBQUksV0FBVyxFQUFFLE1BQU0sUUFBUTtBQUVyQyxRQUFNLFVBQVU7QUFBQSxJQUNkLGFBQWEsR0FBRyxHQUFHLENBQUM7QUFBQSxJQUNwQixlQUFlLEdBQUcsR0FBRyxDQUFDO0FBQUEsSUFDdEIsV0FBVyxHQUFHLEdBQUcsQ0FBQztBQUFBLElBQ2xCLG1CQUFtQixHQUFHLEdBQUcsQ0FBQztBQUFBLElBQzFCLGVBQWUsR0FBRyxHQUFHLENBQUM7QUFBQSxJQUN0QixnQkFBZ0IsR0FBRyxHQUFHLENBQUM7QUFBQSxFQUN6QixFQUFFLE9BQU8sQ0FBQyxNQUFNLEVBQUUsU0FBUyxDQUFDO0FBRTVCLFFBQU0sV0FBVyxRQUFRLE9BQU8sQ0FBQyxHQUFHLE1BQU0sSUFBSSxFQUFFLFFBQVEsRUFBRSxRQUFRLENBQUM7QUFDbkUsUUFBTSxRQUFRLFFBQVEsT0FBTyxDQUFDLEdBQUcsTUFBTSxJQUFJLEVBQUUsUUFBUSxDQUFDO0FBQ3RELFFBQU0sTUFBTyxXQUFXLFFBQVM7QUFJakMsUUFBTSxRQUFRLE9BQU8sU0FBUyxNQUFNLEtBQUssSUFBSSxJQUFJLEtBQUssTUFBTSxHQUFHLENBQUM7QUFFaEUsU0FBTyxFQUFFLFNBQVMsRUFBRSxNQUFNLElBQUksT0FBTyxRQUFRO0FBQy9DO0FBRU8sZ0JBQVMsU0FBUyxVQUEwQixHQUFpRDtBQUNsRyxRQUFNLE1BQU0sb0JBQUksSUFBeUI7QUFDekMsYUFBVyxLQUFLLFNBQVUsS0FBSSxJQUFJLEVBQUUsTUFBTSxJQUFJLGFBQWEsR0FBRyxDQUFDLENBQUM7QUFDaEUsU0FBTztBQUNUO0FBRU8sZ0JBQVMsV0FBVyxPQUF1QjtBQUNoRCxNQUFJLFNBQVMsR0FBSSxRQUFPO0FBQ3hCLE1BQUksU0FBUyxHQUFJLFFBQU87QUFDeEIsTUFBSSxTQUFTLEdBQUksUUFBTztBQUN4QixTQUFPO0FBQ1Q7QUFhTyxnQkFBUyxtQkFDZCxVQUNBLEdBQ0EsWUFDQSxRQUFRLEdBQ1k7QUFDcEIsU0FBTyxTQUNKLE9BQU8sQ0FBQyxNQUFNLENBQUMsV0FBVyxTQUFTLEVBQUUsTUFBTSxFQUFFLEtBQUssRUFBRSxNQUFNLGFBQWEsV0FBVyxVQUFVLEVBQzVGLElBQUksQ0FBQyxNQUFNO0FBQ1YsVUFBTSxRQUFRLGFBQWEsR0FBRyxDQUFDO0FBQy9CLFVBQU0sS0FBSyxpQkFBaUIsR0FBRyxFQUFFLElBQUk7QUFDckMsVUFBTSxTQUFTLEVBQUUsTUFBTSxLQUFLLG9CQUFvQixFQUFFLE1BQU0sS0FBSztBQUU3RCxRQUFJO0FBQ0osUUFBSSxFQUFFLFNBQVMsU0FBUyxFQUFFLFFBQVEsT0FBTyxRQUFRLE1BQU0sR0FBRztBQUN4RCxlQUFTLEdBQUcsR0FBRyxRQUFRLENBQUMsQ0FBQyxZQUFZLEVBQUUsSUFBSSxRQUFRLEVBQUUsU0FBUyxJQUFJO0FBQUEsSUFDcEUsV0FBVyxTQUFTLEVBQUUsV0FBVztBQUMvQixlQUFTLDhCQUE4QixNQUFNLE1BQU0sQ0FBQztBQUFBLElBQ3RELFdBQVcsRUFBRSxjQUFjLFNBQVMsRUFBRSxNQUFNLGNBQWMsRUFBRSxXQUFXO0FBQ3JFLGVBQVMsS0FBSyxpQkFBaUIsRUFBRSxNQUFNLFNBQVMsRUFBRSxZQUFZLENBQUM7QUFBQSxJQUNqRSxXQUFXLFNBQVMsRUFBRSxXQUFXO0FBQy9CLGVBQVMsR0FBRyxNQUFNLFNBQVMsRUFBRSxTQUFTLENBQUM7QUFBQSxJQUN6QyxPQUFPO0FBQ0wsZUFBUztBQUFBLElBQ1g7QUFFQSxXQUFPLEVBQUUsU0FBUyxHQUFHLE9BQU8sTUFBTSxPQUFPLFlBQVksSUFBSSxPQUFPO0FBQUEsRUFDbEUsQ0FBQyxFQUNBLE9BQU8sQ0FBQyxNQUFNLEVBQUUsU0FBUyxFQUFFLEVBQzNCLEtBQUssQ0FBQyxHQUFHLE1BQU0sRUFBRSxRQUFRLEVBQUUsS0FBSyxFQUNoQyxNQUFNLEdBQUcsS0FBSztBQUNuQjtBQUVPLGFBQU0sdUJBQTJDO0FBQUEsRUFDdEQsYUFBYTtBQUFBLEVBQ2IsVUFBVTtBQUFBLEVBQ1YsV0FBVztBQUFBLEVBQ1gsTUFBTTtBQUFBLEVBQ04sV0FBVztBQUFBLEVBQ1gsV0FBVztBQUFBLEVBQ1gsVUFBVSxDQUFDO0FBQUEsRUFDWCxZQUFZLElBQUksS0FBSyxLQUFLLElBQUksSUFBSSxLQUFLLEtBQVEsRUFBRSxZQUFZLEVBQUUsTUFBTSxHQUFHLEVBQUU7QUFBQSxFQUMxRSxXQUFXLENBQUM7QUFBQSxFQUNaLFdBQVc7QUFDYjtBQVNPLGdCQUFTLGlCQUFpQixHQUFpQixXQUFxRDtBQUNyRyxNQUFJLGNBQWMsTUFBTyxRQUFPO0FBQ2hDLE1BQUksRUFBRSxNQUFNLGFBQWEsU0FBVSxRQUFPO0FBRTFDLFFBQU0sUUFBUSxFQUFFLE1BQU07QUFDdEIsTUFBSSxDQUFDLE1BQU8sUUFBTztBQUVuQixVQUFRLFdBQVc7QUFBQSxJQUNqQixLQUFLO0FBQ0gsYUFBTyxNQUFNO0FBQUEsSUFDZixLQUFLO0FBQ0gsYUFBTyxNQUFNO0FBQUEsSUFDZixLQUFLO0FBQ0gsYUFBTyxNQUFNLG1CQUFtQixNQUFNO0FBQUEsSUFDeEM7QUFDRSxhQUFPO0FBQUEsRUFDWDtBQUNGOyIsIm5hbWVzIjpbXX0=