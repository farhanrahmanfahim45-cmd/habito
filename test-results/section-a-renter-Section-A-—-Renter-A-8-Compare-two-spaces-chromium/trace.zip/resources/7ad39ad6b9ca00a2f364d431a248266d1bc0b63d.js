import { client, toOwner, toProperty, toSpace, propertyInsert, spaceInsert, spacePatch } from "/src/lib/supabase.ts";
let channelSeq = 0;
const SPACE_COLUMNS = "*";
const PROPERTY_COLUMNS = "*";
function fail(context, error) {
  throw new Error(`${context}: ${error?.message ?? "unknown error"}`);
}
async function currentUserId() {
  const { data } = await client().auth.getUser();
  return data.user?.id ?? null;
}
async function requireUser(action) {
  const id = await currentUserId();
  if (!id) throw new Error(`You need to be signed in to ${action}.`);
  return id;
}
async function loadListings(filter) {
  let query = client().from("spaces").select(
    // Named explicitly: property_managers adds a second properties→profiles
    // path, and PostgREST will not guess between them.
    `${SPACE_COLUMNS}, properties!inner(${PROPERTY_COLUMNS}, profiles!properties_owner_id_fkey!inner(*))`
  ).eq("status", "published");
  if (filter?.spaceId) query = query.eq("id", filter.spaceId);
  const { data, error } = await query;
  if (error) fail("Could not load listings", error);
  return (data ?? []).map((row) => {
    const { properties, ...spaceRow } = row;
    const { profiles, ...propertyRow } = properties;
    return {
      space: toSpace(spaceRow),
      property: toProperty(propertyRow),
      owner: toOwner(profiles)
    };
  });
}
export const supabaseRepository = {
  kind: "supabase",
  /* ── Reads ────────────────────────────────────────────────────────────── */
  async listings() {
    return loadListings();
  },
  async listing(spaceId) {
    const [found] = await loadListings({ spaceId });
    return found ?? null;
  },
  async properties(ownerId) {
    let query = client().from("properties").select(PROPERTY_COLUMNS).order("created_at", { ascending: false });
    if (ownerId) query = query.eq("owner_id", ownerId);
    const { data, error } = await query;
    if (error) fail("Could not load properties", error);
    return data.map(toProperty);
  },
  async spacesOfProperty(propertyId) {
    const { data, error } = await client().from("spaces").select(SPACE_COLUMNS).eq("property_id", propertyId).order("created_at", { ascending: true });
    if (error) fail("Could not load spaces", error);
    return data.map(toSpace);
  },
  async space(spaceId) {
    const { data, error } = await client().from("spaces").select(SPACE_COLUMNS).eq("id", spaceId).maybeSingle();
    if (error) fail("Could not load that space", error);
    return data ? toSpace(data) : null;
  },
  async owner(ownerId) {
    const { data, error } = await client().from("profiles").select("*").eq("id", ownerId).maybeSingle();
    if (error) fail("Could not load owner", error);
    return data ? toOwner(data) : null;
  },
  /* ── Owner writes ─────────────────────────────────────────────────────── */
  async createProperty(input) {
    const userId = await requireUser("add a property");
    const { data, error } = await client().from("properties").insert({ ...propertyInsert(input), owner_id: userId }).select().single();
    if (error) fail("Could not create the property", error);
    return toProperty(data);
  },
  async createSpace(input) {
    await requireUser("add a space");
    const { data, error } = await client().from("spaces").insert(spaceInsert(input)).select().single();
    if (error) fail("Could not create the space", error);
    return toSpace(data);
  },
  async updateSpace(spaceId, patch) {
    await requireUser("edit a space");
    const { data, error } = await client().from("spaces").update(spacePatch(patch)).eq("id", spaceId).select().maybeSingle();
    if (error) fail("Could not update the space", error);
    return data ? toSpace(data) : null;
  },
  async deleteSpace(spaceId) {
    await requireUser("remove a space");
    const { error } = await client().from("spaces").delete().eq("id", spaceId);
    if (error) fail("Could not remove the space", error);
  },
  /* ── Favourites ───────────────────────────────────────────────────────── */
  async saved() {
    const userId = await currentUserId();
    if (!userId) return [];
    const { data, error } = await client().from("favorites").select("space_id").eq("user_id", userId);
    if (error) fail("Could not load saved spaces", error);
    return (data ?? []).map((r) => r.space_id);
  },
  async toggleSaved(spaceId) {
    const userId = await requireUser("save a space");
    const { data: existing } = await client().from("favorites").select("space_id").eq("user_id", userId).eq("space_id", spaceId).maybeSingle();
    if (existing) {
      const { error: error2 } = await client().from("favorites").delete().eq("user_id", userId).eq("space_id", spaceId);
      if (error2) fail("Could not remove from saved", error2);
      return false;
    }
    const { error } = await client().from("favorites").insert({ user_id: userId, space_id: spaceId });
    if (error) fail("Could not save this space", error);
    return true;
  },
  /* ── Inquiries ────────────────────────────────────────────────────────── */
  // Backed by conversations + messages, so the same rows become the chat
  // thread when messaging lands in the next stage.
  async inquiries() {
    const userId = await currentUserId();
    if (!userId) return [];
    const { data, error } = await client().from("conversations").select("id, space_id, renter_id, created_at, messages(id, body, created_at, sender_id), profiles!conversations_renter_id_fkey(name)").order("last_message_at", { ascending: false });
    if (error) fail("Could not load inquiries", error);
    return (data ?? []).flatMap((row) => {
      const conv = row;
      const first = [...conv.messages].sort((a, b) => a.created_at.localeCompare(b.created_at))[0];
      if (!first || !conv.space_id) return [];
      const profile = Array.isArray(conv.profiles) ? conv.profiles[0] : conv.profiles;
      return [{
        id: conv.id,
        spaceId: conv.space_id,
        name: profile?.name ?? "Habito user",
        message: first.body,
        moveInDate: conv.created_at.slice(0, 10),
        budgetMin: 0,
        budgetMax: 0,
        sentAt: first.created_at,
        status: "new"
      }];
    });
  },
  async createInquiry(input) {
    const userId = await requireUser("send an inquiry");
    const { data: space, error: spaceError } = await client().from("spaces").select("id, properties!inner(owner_id)").eq("id", input.spaceId).single();
    if (spaceError) fail("Could not find that space", spaceError);
    const ownerId = space.properties.owner_id;
    const { data: conversation, error: convError } = await client().from("conversations").upsert(
      { space_id: input.spaceId, renter_id: userId, owner_id: ownerId, last_message_at: (/* @__PURE__ */ new Date()).toISOString() },
      { onConflict: "space_id,renter_id,owner_id" }
    ).select().single();
    if (convError) fail("Could not start the conversation", convError);
    const { data: message, error: msgError } = await client().from("messages").insert({ conversation_id: conversation.id, sender_id: userId, body: input.message }).select().single();
    if (msgError) fail("Could not send the message", msgError);
    await client().from("notifications").insert({
      user_id: ownerId,
      kind: "message",
      title: "New inquiry",
      body: input.message.slice(0, 140),
      entity_type: "space",
      entity_id: input.spaceId
    });
    return {
      ...input,
      id: message.id,
      sentAt: message.created_at,
      status: "new"
    };
  },
  async setInquiryStatus(inquiryId, _status) {
    const userId = await currentUserId();
    if (!userId) return;
    await client().from("messages").update({ read_at: (/* @__PURE__ */ new Date()).toISOString() }).eq("conversation_id", inquiryId).neq("sender_id", userId).is("read_at", null);
  },
  /* ── Space requests ───────────────────────────────────────────────────── */
  async requests() {
    const { data, error } = await client().from("space_requests").select("*").eq("open", true).order("created_at", { ascending: false });
    if (error) fail("Could not load requests", error);
    return (data ?? []).map((row) => {
      const r = row;
      return {
        id: r.id,
        category: r.category,
        spaceType: r.space_type,
        transaction: r.transaction,
        area: r.area,
        budgetMin: Number(r.budget_min),
        budgetMax: Number(r.budget_max),
        neededBy: r.needed_by,
        note: r.note ?? "",
        createdAt: r.created_at
      };
    });
  },
  async createRequest(input) {
    const userId = await requireUser("post a request");
    const { data, error } = await client().from("space_requests").insert({
      user_id: userId,
      category: input.category,
      space_type: input.spaceType,
      transaction: input.transaction,
      area: input.area,
      budget_min: input.budgetMin,
      budget_max: input.budgetMax,
      needed_by: input.neededBy,
      note: input.note
    }).select().single();
    if (error) fail("Could not post the request", error);
    return { ...input, id: data.id, createdAt: data.created_at };
  },
  /* ── Bookings ─────────────────────────────────────────────────────── */
  async bookings() {
    const userId = await currentUserId();
    if (!userId) return [];
    const { data, error } = await client().from("bookings").select(`
        *,
        spaces ( id, name, images, properties ( area ) ),
        renter:profiles!bookings_renter_id_fkey ( id, name ),
        owner:profiles!bookings_owner_id_fkey ( id, name )
      `).order("created_at", { ascending: false });
    if (error) fail("Could not load your bookings", error);
    return (data ?? []).map((row) => {
      const b = row;
      return {
        id: b.id,
        spaceId: b.space_id,
        spaceName: b.spaces?.name ?? "A space",
        spaceImage: b.spaces?.images?.[0]?.url ?? null,
        area: b.spaces?.properties?.area ?? null,
        renterId: b.renter_id,
        renterName: b.renter?.name ?? "Habito user",
        ownerId: b.owner_id,
        ownerName: b.owner?.name ?? "Owner",
        status: b.status,
        moveInDate: b.move_in_date,
        months: b.months,
        amount: b.amount,
        message: b.message,
        phoneShared: b.phone_shared,
        renterPhone: b.renter_phone,
        ownerPhone: b.owner_phone,
        declineReason: b.decline_reason,
        createdAt: b.created_at,
        decidedAt: b.decided_at,
        youAreOwner: b.owner_id === userId
      };
    });
  },
  async requestBooking(input) {
    const userId = await requireUser("request a booking");
    const { data, error } = await client().from("bookings").insert({
      space_id: input.spaceId,
      renter_id: userId,
      owner_id: userId,
      move_in_date: input.moveInDate,
      months: input.months,
      amount: input.amount,
      message: input.message ?? null
    }).select().single();
    if (error) fail("Could not request this booking", error);
    const row = data;
    return {
      id: row.id,
      spaceId: input.spaceId,
      spaceName: "",
      spaceImage: null,
      area: null,
      renterId: userId,
      renterName: "",
      ownerId: "",
      ownerName: "",
      status: row.status,
      moveInDate: input.moveInDate,
      months: input.months,
      amount: input.amount,
      message: input.message ?? null,
      phoneShared: false,
      renterPhone: null,
      ownerPhone: null,
      declineReason: null,
      createdAt: row.created_at,
      decidedAt: null,
      youAreOwner: false
    };
  },
  async setBookingStatus(bookingId, status, reason) {
    await requireUser("change a booking");
    const patch = { status };
    if (reason !== void 0) patch.decline_reason = reason;
    const { error } = await client().from("bookings").update(patch).eq("id", bookingId);
    if (error) fail("Could not update this booking", error);
  },
  /* ── Moderation ───────────────────────────────────────────────────── */
  async reviewQueue() {
    const { data, error } = await client().from("review_queue").select("*").order("priority", { ascending: true }).order("created_at", { ascending: true });
    if (error) fail("Could not load the review queue", error);
    return (data ?? []).map((row) => {
      const r = row;
      return {
        spaceId: r.space_id,
        spaceName: r.space_name,
        area: r.area,
        ownerId: r.owner_id,
        ownerName: r.owner_name,
        ownerTrust: r.owner_trust,
        completeness: r.completeness,
        flaggedDuplicate: r.flagged_duplicate,
        hiddenAt: r.hidden_at,
        hiddenReason: r.hidden_reason,
        reportCount: Number(r.report_count),
        openReports: Number(r.open_reports),
        priority: r.priority
      };
    });
  },
  async setListingVisible(spaceId, visible, note) {
    const { error } = await client().rpc("admin_set_listing_visible", {
      target: spaceId,
      visible,
      why: note ?? null
    });
    if (error) fail("Could not change that listing", error);
  },
  async setTrust(profileId, tier, note) {
    const { error } = await client().rpc("admin_set_trust", {
      target: profileId,
      tier,
      why: note
    });
    if (error) fail("Could not set that trust level", error);
  },
  async resolveReports(spaceId, dismiss, note) {
    const { error } = await client().rpc("admin_resolve_reports", {
      target: spaceId,
      dismiss,
      why: note ?? null
    });
    if (error) fail("Could not resolve those reports", error);
  },
  async clearDuplicate(spaceId, note) {
    const { error } = await client().rpc("admin_clear_duplicate", {
      target: spaceId,
      why: note ?? null
    });
    if (error) fail("Could not clear that flag", error);
  },
  /* ── Listing fees ─────────────────────────────────────────────────── */
  async listingFee(category) {
    const { data } = await client().from("listing_prices").select("amount").eq("category", category).maybeSingle();
    return data?.amount ?? 200;
  },
  async listingAllowance(propertyId) {
    const [{ data: used }, { data: plan }] = await Promise.all([
      client().rpc("listings_this_month", { target: propertyId }),
      client().rpc("property_has_plan", { target: propertyId })
    ]);
    return { used: Number(used ?? 0), hasPlan: Boolean(plan) };
  },
  async payListingFee(spaceId, amount) {
    const userId = await requireUser("pay a listing fee");
    const { data, error } = await client().from("payments").insert({
      user_id: userId,
      amount,
      kind: "listing",
      space_id: spaceId,
      gateway: "sandbox",
      status: "pending",
      simulated: true
    }).select("id").single();
    if (error) fail("Could not start that payment", error);
    const { error: settleError } = await client().from("payments").update({ status: "successful", reference: `SANDBOX-${Date.now()}` }).eq("id", data.id);
    if (settleError) fail("That payment did not go through", settleError);
  },
  async buyPropertyPlan(propertyId, amount) {
    const userId = await requireUser("buy a plan");
    const ends = /* @__PURE__ */ new Date();
    ends.setFullYear(ends.getFullYear() + 1);
    const { data, error } = await client().from("property_plans").insert({
      property_id: propertyId,
      owner_id: userId,
      ends_on: ends.toISOString().slice(0, 10),
      amount
    }).select("id").single();
    if (error) fail("Could not start that plan", error);
    const { data: payment } = await client().from("payments").insert({
      user_id: userId,
      amount,
      kind: "plan",
      plan_id: data.id,
      gateway: "sandbox",
      status: "pending",
      simulated: true
    }).select("id").single();
    if (payment) {
      await client().from("payments").update({ status: "successful", reference: `SANDBOX-${Date.now()}` }).eq("id", payment.id);
    }
  },
  /* ── Rent ─────────────────────────────────────────────────────────── */
  async invoices() {
    const userId = await currentUserId();
    if (!userId) return [];
    await client().rpc("mark_overdue_invoices");
    const { data, error } = await client().from("rent_invoices").select(`
        *,
        spaces ( name, properties ( area ) ),
        renter:profiles!rent_invoices_renter_id_fkey ( name ),
        owner:profiles!rent_invoices_owner_id_fkey ( name ),
        payments ( simulated )
      `).order("due_date", { ascending: true });
    if (error) fail("Could not load your rent", error);
    return (data ?? []).map((row) => {
      const r = row;
      const youAreOwner = r.owner_id === userId;
      return {
        id: r.id,
        bookingId: r.booking_id,
        spaceId: r.space_id,
        spaceName: r.spaces?.name ?? "A space",
        area: r.spaces?.properties?.area ?? null,
        counterpartName: (youAreOwner ? r.renter?.name : r.owner?.name) ?? "Habito user",
        youAreOwner,
        periodStart: r.period_start,
        periodEnd: r.period_end,
        dueDate: r.due_date,
        amount: r.amount,
        status: r.status,
        paidAt: r.paid_at,
        receiptNo: r.receipt_no,
        simulated: r.payments?.simulated ?? false
      };
    });
  },
  async payInvoice(invoiceId) {
    const userId = await requireUser("pay rent");
    const { data: invoice, error: readError } = await client().from("rent_invoices").select("id, booking_id, amount, status").eq("id", invoiceId).single();
    if (readError) fail("Could not find that invoice", readError);
    const inv = invoice;
    if (inv.status === "paid") return;
    const { data: payment, error: insertError } = await client().from("payments").insert({
      booking_id: inv.booking_id,
      user_id: userId,
      amount: inv.amount,
      invoice_id: invoiceId,
      kind: "rent",
      gateway: "sandbox",
      status: "pending",
      simulated: true
    }).select("id").single();
    if (insertError) fail("Could not start that payment", insertError);
    const { error: settleError } = await client().from("payments").update({ status: "successful", reference: `SANDBOX-${Date.now()}` }).eq("id", payment.id);
    if (settleError) fail("That payment did not go through", settleError);
  },
  async waiveInvoice(invoiceId) {
    await requireUser("waive rent");
    const { error } = await client().from("rent_invoices").update({ status: "waived" }).eq("id", invoiceId);
    if (error) fail("Could not waive that month", error);
  },
  async extendSchedule(bookingId, months = 12) {
    await requireUser("extend a rent schedule");
    const { error } = await client().rpc("extend_rent_schedule", {
      target_booking: bookingId,
      add_months: months
    });
    if (error) fail("Could not extend that schedule", error);
  },
  /* ── Messaging ────────────────────────────────────────────────────── */
  async conversations() {
    const userId = await currentUserId();
    if (!userId) return [];
    const { data, error } = await client().from("conversations").select(`
        id, space_id, renter_id, owner_id, last_message_at,
        spaces ( id, name, images, properties ( area ) ),
        renter:profiles!conversations_renter_id_fkey ( id, name, avatar_tone ),
        owner:profiles!conversations_owner_id_fkey ( id, name, avatar_tone ),
        messages ( id, body, sender_id, read_at, created_at )
      `).order("last_message_at", { ascending: false });
    if (error) fail("Could not load your messages", error);
    return (data ?? []).map((row) => {
      const c = row;
      const youAreOwner = c.owner_id === userId;
      const other = youAreOwner ? c.renter : c.owner;
      const ordered = [...c.messages].sort((a, b) => a.created_at.localeCompare(b.created_at));
      const last = ordered[ordered.length - 1];
      return {
        id: c.id,
        spaceId: c.space_id,
        spaceName: c.spaces?.name ?? "A space",
        spaceImage: c.spaces?.images?.[0]?.url ?? null,
        propertyArea: c.spaces?.properties?.area ?? null,
        counterpartId: other?.id ?? "",
        counterpartName: other?.name ?? "Habito user",
        counterpartTone: other?.avatar_tone ?? "aqua",
        youAreOwner,
        lastMessage: last?.body ?? "",
        lastMessageAt: last?.created_at ?? c.last_message_at,
        unread: ordered.filter((m) => m.sender_id !== userId && !m.read_at).length
      };
    });
  },
  async messages(conversationId) {
    const userId = await currentUserId();
    const { data, error } = await client().from("messages").select("*").eq("conversation_id", conversationId).order("created_at", { ascending: true });
    if (error) fail("Could not load the conversation", error);
    return (data ?? []).map((row) => {
      const m = row;
      return {
        id: m.id,
        conversationId,
        senderId: m.sender_id,
        body: m.body,
        sentAt: m.created_at,
        readAt: m.read_at,
        mine: m.sender_id === userId
      };
    });
  },
  async sendMessage(conversationId, body) {
    const userId = await requireUser("send a message");
    const { data, error } = await client().from("messages").insert({ conversation_id: conversationId, sender_id: userId, body }).select().single();
    if (error) fail("Could not send your message", error);
    await client().from("conversations").update({ last_message_at: (/* @__PURE__ */ new Date()).toISOString() }).eq("id", conversationId);
    const m = data;
    return { id: m.id, conversationId, senderId: userId, body, sentAt: m.created_at, readAt: null, mine: true };
  },
  async markRead(conversationId) {
    const userId = await currentUserId();
    if (!userId) return;
    await client().from("messages").update({ read_at: (/* @__PURE__ */ new Date()).toISOString() }).eq("conversation_id", conversationId).neq("sender_id", userId).is("read_at", null);
  },
  async openConversation(spaceId) {
    const userId = await requireUser("start a conversation");
    const { data: space, error: spaceError } = await client().from("spaces").select("id, properties!inner(owner_id)").eq("id", spaceId).single();
    if (spaceError) fail("Could not find that space", spaceError);
    const ownerId = space.properties.owner_id;
    if (ownerId === userId) throw new Error("That's your own listing.");
    const { data, error } = await client().from("conversations").upsert(
      { space_id: spaceId, renter_id: userId, owner_id: ownerId, last_message_at: (/* @__PURE__ */ new Date()).toISOString() },
      { onConflict: "space_id,renter_id,owner_id" }
    ).select("id").single();
    if (error) fail("Could not open the conversation", error);
    return data.id;
  },
  subscribeToMessages(onChange) {
    const name = `habito-messages-${++channelSeq}`;
    const poll = window.setInterval(onChange, 2e4);
    let channel = null;
    try {
      channel = client().channel(name).on("postgres_changes", { event: "*", schema: "public", table: "messages" }, () => onChange()).on("postgres_changes", { event: "*", schema: "public", table: "conversations" }, () => onChange()).subscribe();
    } catch (error) {
      console.warn("Habito: live updates unavailable, polling instead.", error);
    }
    return () => {
      window.clearInterval(poll);
      if (channel) void client().removeChannel(channel);
    };
  },
  /* ── Maintenance ──────────────────────────────────────────────────────── */
  async reset() {
    throw new Error("Resetting isn't available when Habito is connected to the database.");
  }
};

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInN1cGFiYXNlLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB0eXBlIHsgUmVhbHRpbWVDaGFubmVsIH0gZnJvbSBcIkBzdXBhYmFzZS9zdXBhYmFzZS1qc1wiO1xuaW1wb3J0IHsgY2xpZW50LCB0b093bmVyLCB0b1Byb3BlcnR5LCB0b1NwYWNlLCBwcm9wZXJ0eUluc2VydCwgc3BhY2VJbnNlcnQsIHNwYWNlUGF0Y2ggfSBmcm9tIFwiQC9saWIvc3VwYWJhc2VcIjtcbmltcG9ydCB0eXBlIHsgUHJvZmlsZVJvdywgUHJvcGVydHlSb3csIFNwYWNlUm93IH0gZnJvbSBcIkAvbGliL3N1cGFiYXNlXCI7XG5pbXBvcnQgdHlwZSB7IFJlcG9zaXRvcnkgfSBmcm9tIFwiLi90eXBlc1wiO1xuaW1wb3J0IHR5cGUge1xuICBCb29raW5nLFxuICBCb29raW5nU3RhdHVzLFxuICBDb252ZXJzYXRpb24sXG4gIElucXVpcnksXG4gIElucXVpcnlTdGF0dXMsXG4gIE1lc3NhZ2UsXG4gIFJlbnRJbnZvaWNlLFxuICBSZXZpZXdJdGVtLFxuICBUcnVzdFRpZXIsXG4gIE93bmVyLFxuICBQcm9wZXJ0eSxcbiAgU3BhY2UsXG4gIFNwYWNlTGlzdGluZyxcbiAgU3BhY2VSZXF1ZXN0LFxufSBmcm9tIFwiQC90eXBlcy9zcGFjZVwiO1xuXG4vKipcbiAqIFBvc3RncmVzLWJhY2tlZCByZXBvc2l0b3J5LlxuICpcbiAqIFJlYWRzIGFyZSBwdWJsaWM7IGV2ZXJ5IHdyaXRlIGlzIGF1dGhvcmlzZWQgYnkgcm93LWxldmVsIHNlY3VyaXR5IGluIHRoZVxuICogZGF0YWJhc2UgcmF0aGVyIHRoYW4gYnkgY2hlY2tzIGluIHRoaXMgZmlsZS4gSWYgYSBzaWduZWQtb3V0IHZpc2l0b3IgY2FsbHMgYVxuICogd3JpdGUsIFBvc3RncmVzIHJlamVjdHMgaXQg4oCUIHRoZSBmcm9udGVuZCBjYW5ub3QgZ3JhbnQgaXRzZWxmIHBlcm1pc3Npb24uXG4gKi9cblxuLyoqIE1ha2VzIGVhY2ggcmVhbHRpbWUgY2hhbm5lbCBuYW1lIHVuaXF1ZSBhY3Jvc3MgdGhlIGFwcCdzIHN1YnNjcmliZXJzLiAqL1xubGV0IGNoYW5uZWxTZXEgPSAwO1xuXG5jb25zdCBTUEFDRV9DT0xVTU5TID0gXCIqXCI7XG5jb25zdCBQUk9QRVJUWV9DT0xVTU5TID0gXCIqXCI7XG5cbmZ1bmN0aW9uIGZhaWwoY29udGV4dDogc3RyaW5nLCBlcnJvcjogeyBtZXNzYWdlOiBzdHJpbmcgfSB8IG51bGwpOiBuZXZlciB7XG4gIHRocm93IG5ldyBFcnJvcihgJHtjb250ZXh0fTogJHtlcnJvcj8ubWVzc2FnZSA/PyBcInVua25vd24gZXJyb3JcIn1gKTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gY3VycmVudFVzZXJJZCgpOiBQcm9taXNlPHN0cmluZyB8IG51bGw+IHtcbiAgY29uc3QgeyBkYXRhIH0gPSBhd2FpdCBjbGllbnQoKS5hdXRoLmdldFVzZXIoKTtcbiAgcmV0dXJuIGRhdGEudXNlcj8uaWQgPz8gbnVsbDtcbn1cblxuLyoqIFJlcXVpcmVzIGEgc2lnbmVkLWluIHVzZXIgZm9yIGFjdGlvbnMgdGhhdCBhcmUgbWVhbmluZ2xlc3Mgd2l0aG91dCBvbmUuICovXG5hc3luYyBmdW5jdGlvbiByZXF1aXJlVXNlcihhY3Rpb246IHN0cmluZyk6IFByb21pc2U8c3RyaW5nPiB7XG4gIGNvbnN0IGlkID0gYXdhaXQgY3VycmVudFVzZXJJZCgpO1xuICBpZiAoIWlkKSB0aHJvdyBuZXcgRXJyb3IoYFlvdSBuZWVkIHRvIGJlIHNpZ25lZCBpbiB0byAke2FjdGlvbn0uYCk7XG4gIHJldHVybiBpZDtcbn1cblxuLyoqIEpvaW5zIHNwYWNlcyB0byB0aGVpciBwcm9wZXJ0eSBhbmQgb3duZXIgaW4gb25lIHJvdW5kIHRyaXAuICovXG5hc3luYyBmdW5jdGlvbiBsb2FkTGlzdGluZ3MoZmlsdGVyPzogeyBzcGFjZUlkPzogc3RyaW5nIH0pOiBQcm9taXNlPFNwYWNlTGlzdGluZ1tdPiB7XG4gIGxldCBxdWVyeSA9IGNsaWVudCgpXG4gICAgLmZyb20oXCJzcGFjZXNcIilcbiAgICAuc2VsZWN0KFxuICAgICAgLy8gTmFtZWQgZXhwbGljaXRseTogcHJvcGVydHlfbWFuYWdlcnMgYWRkcyBhIHNlY29uZCBwcm9wZXJ0aWVz4oaScHJvZmlsZXNcbiAgICAgIC8vIHBhdGgsIGFuZCBQb3N0Z1JFU1Qgd2lsbCBub3QgZ3Vlc3MgYmV0d2VlbiB0aGVtLlxuICAgICAgYCR7U1BBQ0VfQ09MVU1OU30sIHByb3BlcnRpZXMhaW5uZXIoJHtQUk9QRVJUWV9DT0xVTU5TfSwgcHJvZmlsZXMhcHJvcGVydGllc19vd25lcl9pZF9ma2V5IWlubmVyKCopKWAsXG4gICAgKVxuICAgIC5lcShcInN0YXR1c1wiLCBcInB1Ymxpc2hlZFwiKTtcblxuICBpZiAoZmlsdGVyPy5zcGFjZUlkKSBxdWVyeSA9IHF1ZXJ5LmVxKFwiaWRcIiwgZmlsdGVyLnNwYWNlSWQpO1xuXG4gIGNvbnN0IHsgZGF0YSwgZXJyb3IgfSA9IGF3YWl0IHF1ZXJ5O1xuICBpZiAoZXJyb3IpIGZhaWwoXCJDb3VsZCBub3QgbG9hZCBsaXN0aW5nc1wiLCBlcnJvcik7XG5cbiAgcmV0dXJuIChkYXRhID8/IFtdKS5tYXAoKHJvdykgPT4ge1xuICAgIGNvbnN0IHsgcHJvcGVydGllcywgLi4uc3BhY2VSb3cgfSA9IHJvdyBhcyBTcGFjZVJvdyAmIHtcbiAgICAgIHByb3BlcnRpZXM6IFByb3BlcnR5Um93ICYgeyBwcm9maWxlczogUHJvZmlsZVJvdyB9O1xuICAgIH07XG4gICAgY29uc3QgeyBwcm9maWxlcywgLi4ucHJvcGVydHlSb3cgfSA9IHByb3BlcnRpZXM7XG4gICAgcmV0dXJuIHtcbiAgICAgIHNwYWNlOiB0b1NwYWNlKHNwYWNlUm93IGFzIFNwYWNlUm93KSxcbiAgICAgIHByb3BlcnR5OiB0b1Byb3BlcnR5KHByb3BlcnR5Um93IGFzIFByb3BlcnR5Um93KSxcbiAgICAgIG93bmVyOiB0b093bmVyKHByb2ZpbGVzKSxcbiAgICB9O1xuICB9KTtcbn1cblxuZXhwb3J0IGNvbnN0IHN1cGFiYXNlUmVwb3NpdG9yeTogUmVwb3NpdG9yeSA9IHtcbiAga2luZDogXCJzdXBhYmFzZVwiLFxuXG4gIC8qIOKUgOKUgCBSZWFkcyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIAgKi9cblxuICBhc3luYyBsaXN0aW5ncygpOiBQcm9taXNlPFNwYWNlTGlzdGluZ1tdPiB7XG4gICAgcmV0dXJuIGxvYWRMaXN0aW5ncygpO1xuICB9LFxuXG4gIGFzeW5jIGxpc3Rpbmcoc3BhY2VJZDogc3RyaW5nKTogUHJvbWlzZTxTcGFjZUxpc3RpbmcgfCBudWxsPiB7XG4gICAgY29uc3QgW2ZvdW5kXSA9IGF3YWl0IGxvYWRMaXN0aW5ncyh7IHNwYWNlSWQgfSk7XG4gICAgcmV0dXJuIGZvdW5kID8/IG51bGw7XG4gIH0sXG5cbiAgYXN5bmMgcHJvcGVydGllcyhvd25lcklkPzogc3RyaW5nKTogUHJvbWlzZTxQcm9wZXJ0eVtdPiB7XG4gICAgbGV0IHF1ZXJ5ID0gY2xpZW50KCkuZnJvbShcInByb3BlcnRpZXNcIikuc2VsZWN0KFBST1BFUlRZX0NPTFVNTlMpLm9yZGVyKFwiY3JlYXRlZF9hdFwiLCB7IGFzY2VuZGluZzogZmFsc2UgfSk7XG4gICAgaWYgKG93bmVySWQpIHF1ZXJ5ID0gcXVlcnkuZXEoXCJvd25lcl9pZFwiLCBvd25lcklkKTtcblxuICAgIGNvbnN0IHsgZGF0YSwgZXJyb3IgfSA9IGF3YWl0IHF1ZXJ5O1xuICAgIGlmIChlcnJvcikgZmFpbChcIkNvdWxkIG5vdCBsb2FkIHByb3BlcnRpZXNcIiwgZXJyb3IpO1xuICAgIHJldHVybiAoZGF0YSBhcyBQcm9wZXJ0eVJvd1tdKS5tYXAodG9Qcm9wZXJ0eSk7XG4gIH0sXG5cbiAgYXN5bmMgc3BhY2VzT2ZQcm9wZXJ0eShwcm9wZXJ0eUlkOiBzdHJpbmcpOiBQcm9taXNlPFNwYWNlW10+IHtcbiAgICAvLyBObyBzdGF0dXMgZmlsdGVyOiB0aGUgcG9ydGZvbGlvIHNob3dzIGFyY2hpdmVkIHNwYWNlcyB0b28sIHdoaWNoIGlzIHRoZVxuICAgIC8vIG9ubHkgcGxhY2UgdGhleSBzaG91bGQgc3RpbGwgYmUgdmlzaWJsZS5cbiAgICBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCBjbGllbnQoKVxuICAgICAgLmZyb20oXCJzcGFjZXNcIilcbiAgICAgIC5zZWxlY3QoU1BBQ0VfQ09MVU1OUylcbiAgICAgIC5lcShcInByb3BlcnR5X2lkXCIsIHByb3BlcnR5SWQpXG4gICAgICAub3JkZXIoXCJjcmVhdGVkX2F0XCIsIHsgYXNjZW5kaW5nOiB0cnVlIH0pO1xuXG4gICAgaWYgKGVycm9yKSBmYWlsKFwiQ291bGQgbm90IGxvYWQgc3BhY2VzXCIsIGVycm9yKTtcbiAgICByZXR1cm4gKGRhdGEgYXMgU3BhY2VSb3dbXSkubWFwKHRvU3BhY2UpO1xuICB9LFxuXG4gIGFzeW5jIHNwYWNlKHNwYWNlSWQ6IHN0cmluZyk6IFByb21pc2U8U3BhY2UgfCBudWxsPiB7XG4gICAgY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgY2xpZW50KClcbiAgICAgIC5mcm9tKFwic3BhY2VzXCIpXG4gICAgICAuc2VsZWN0KFNQQUNFX0NPTFVNTlMpXG4gICAgICAuZXEoXCJpZFwiLCBzcGFjZUlkKVxuICAgICAgLm1heWJlU2luZ2xlKCk7XG5cbiAgICBpZiAoZXJyb3IpIGZhaWwoXCJDb3VsZCBub3QgbG9hZCB0aGF0IHNwYWNlXCIsIGVycm9yKTtcbiAgICByZXR1cm4gZGF0YSA/IHRvU3BhY2UoZGF0YSBhcyBTcGFjZVJvdykgOiBudWxsO1xuICB9LFxuXG4gIGFzeW5jIG93bmVyKG93bmVySWQ6IHN0cmluZyk6IFByb21pc2U8T3duZXIgfCBudWxsPiB7XG4gICAgY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgY2xpZW50KCkuZnJvbShcInByb2ZpbGVzXCIpLnNlbGVjdChcIipcIikuZXEoXCJpZFwiLCBvd25lcklkKS5tYXliZVNpbmdsZSgpO1xuICAgIGlmIChlcnJvcikgZmFpbChcIkNvdWxkIG5vdCBsb2FkIG93bmVyXCIsIGVycm9yKTtcbiAgICByZXR1cm4gZGF0YSA/IHRvT3duZXIoZGF0YSBhcyBQcm9maWxlUm93KSA6IG51bGw7XG4gIH0sXG5cbiAgLyog4pSA4pSAIE93bmVyIHdyaXRlcyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIAgKi9cblxuICBhc3luYyBjcmVhdGVQcm9wZXJ0eShpbnB1dCk6IFByb21pc2U8UHJvcGVydHk+IHtcbiAgICBjb25zdCB1c2VySWQgPSBhd2FpdCByZXF1aXJlVXNlcihcImFkZCBhIHByb3BlcnR5XCIpO1xuICAgIGNvbnN0IHsgZGF0YSwgZXJyb3IgfSA9IGF3YWl0IGNsaWVudCgpXG4gICAgICAuZnJvbShcInByb3BlcnRpZXNcIilcbiAgICAgIC5pbnNlcnQoeyAuLi5wcm9wZXJ0eUluc2VydChpbnB1dCksIG93bmVyX2lkOiB1c2VySWQgfSlcbiAgICAgIC5zZWxlY3QoKVxuICAgICAgLnNpbmdsZSgpO1xuXG4gICAgaWYgKGVycm9yKSBmYWlsKFwiQ291bGQgbm90IGNyZWF0ZSB0aGUgcHJvcGVydHlcIiwgZXJyb3IpO1xuICAgIHJldHVybiB0b1Byb3BlcnR5KGRhdGEgYXMgUHJvcGVydHlSb3cpO1xuICB9LFxuXG4gIGFzeW5jIGNyZWF0ZVNwYWNlKGlucHV0KTogUHJvbWlzZTxTcGFjZT4ge1xuICAgIGF3YWl0IHJlcXVpcmVVc2VyKFwiYWRkIGEgc3BhY2VcIik7XG4gICAgY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgY2xpZW50KCkuZnJvbShcInNwYWNlc1wiKS5pbnNlcnQoc3BhY2VJbnNlcnQoaW5wdXQpKS5zZWxlY3QoKS5zaW5nbGUoKTtcbiAgICBpZiAoZXJyb3IpIGZhaWwoXCJDb3VsZCBub3QgY3JlYXRlIHRoZSBzcGFjZVwiLCBlcnJvcik7XG4gICAgcmV0dXJuIHRvU3BhY2UoZGF0YSBhcyBTcGFjZVJvdyk7XG4gIH0sXG5cbiAgYXN5bmMgdXBkYXRlU3BhY2Uoc3BhY2VJZDogc3RyaW5nLCBwYXRjaDogUGFydGlhbDxTcGFjZT4pOiBQcm9taXNlPFNwYWNlIHwgbnVsbD4ge1xuICAgIGF3YWl0IHJlcXVpcmVVc2VyKFwiZWRpdCBhIHNwYWNlXCIpO1xuICAgIGNvbnN0IHsgZGF0YSwgZXJyb3IgfSA9IGF3YWl0IGNsaWVudCgpXG4gICAgICAuZnJvbShcInNwYWNlc1wiKVxuICAgICAgLnVwZGF0ZShzcGFjZVBhdGNoKHBhdGNoKSlcbiAgICAgIC5lcShcImlkXCIsIHNwYWNlSWQpXG4gICAgICAuc2VsZWN0KClcbiAgICAgIC5tYXliZVNpbmdsZSgpO1xuXG4gICAgaWYgKGVycm9yKSBmYWlsKFwiQ291bGQgbm90IHVwZGF0ZSB0aGUgc3BhY2VcIiwgZXJyb3IpO1xuICAgIHJldHVybiBkYXRhID8gdG9TcGFjZShkYXRhIGFzIFNwYWNlUm93KSA6IG51bGw7XG4gIH0sXG5cbiAgYXN5bmMgZGVsZXRlU3BhY2Uoc3BhY2VJZDogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgYXdhaXQgcmVxdWlyZVVzZXIoXCJyZW1vdmUgYSBzcGFjZVwiKTtcbiAgICBjb25zdCB7IGVycm9yIH0gPSBhd2FpdCBjbGllbnQoKS5mcm9tKFwic3BhY2VzXCIpLmRlbGV0ZSgpLmVxKFwiaWRcIiwgc3BhY2VJZCk7XG4gICAgaWYgKGVycm9yKSBmYWlsKFwiQ291bGQgbm90IHJlbW92ZSB0aGUgc3BhY2VcIiwgZXJyb3IpO1xuICB9LFxuXG4gIC8qIOKUgOKUgCBGYXZvdXJpdGVzIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgCAqL1xuXG4gIGFzeW5jIHNhdmVkKCk6IFByb21pc2U8c3RyaW5nW10+IHtcbiAgICBjb25zdCB1c2VySWQgPSBhd2FpdCBjdXJyZW50VXNlcklkKCk7XG4gICAgaWYgKCF1c2VySWQpIHJldHVybiBbXTtcblxuICAgIGNvbnN0IHsgZGF0YSwgZXJyb3IgfSA9IGF3YWl0IGNsaWVudCgpLmZyb20oXCJmYXZvcml0ZXNcIikuc2VsZWN0KFwic3BhY2VfaWRcIikuZXEoXCJ1c2VyX2lkXCIsIHVzZXJJZCk7XG4gICAgaWYgKGVycm9yKSBmYWlsKFwiQ291bGQgbm90IGxvYWQgc2F2ZWQgc3BhY2VzXCIsIGVycm9yKTtcbiAgICByZXR1cm4gKGRhdGEgPz8gW10pLm1hcCgocikgPT4gKHIgYXMgeyBzcGFjZV9pZDogc3RyaW5nIH0pLnNwYWNlX2lkKTtcbiAgfSxcblxuICBhc3luYyB0b2dnbGVTYXZlZChzcGFjZUlkOiBzdHJpbmcpOiBQcm9taXNlPGJvb2xlYW4+IHtcbiAgICBjb25zdCB1c2VySWQgPSBhd2FpdCByZXF1aXJlVXNlcihcInNhdmUgYSBzcGFjZVwiKTtcblxuICAgIGNvbnN0IHsgZGF0YTogZXhpc3RpbmcgfSA9IGF3YWl0IGNsaWVudCgpXG4gICAgICAuZnJvbShcImZhdm9yaXRlc1wiKVxuICAgICAgLnNlbGVjdChcInNwYWNlX2lkXCIpXG4gICAgICAuZXEoXCJ1c2VyX2lkXCIsIHVzZXJJZClcbiAgICAgIC5lcShcInNwYWNlX2lkXCIsIHNwYWNlSWQpXG4gICAgICAubWF5YmVTaW5nbGUoKTtcblxuICAgIGlmIChleGlzdGluZykge1xuICAgICAgY29uc3QgeyBlcnJvciB9ID0gYXdhaXQgY2xpZW50KClcbiAgICAgICAgLmZyb20oXCJmYXZvcml0ZXNcIilcbiAgICAgICAgLmRlbGV0ZSgpXG4gICAgICAgIC5lcShcInVzZXJfaWRcIiwgdXNlcklkKVxuICAgICAgICAuZXEoXCJzcGFjZV9pZFwiLCBzcGFjZUlkKTtcbiAgICAgIGlmIChlcnJvcikgZmFpbChcIkNvdWxkIG5vdCByZW1vdmUgZnJvbSBzYXZlZFwiLCBlcnJvcik7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuXG4gICAgY29uc3QgeyBlcnJvciB9ID0gYXdhaXQgY2xpZW50KCkuZnJvbShcImZhdm9yaXRlc1wiKS5pbnNlcnQoeyB1c2VyX2lkOiB1c2VySWQsIHNwYWNlX2lkOiBzcGFjZUlkIH0pO1xuICAgIGlmIChlcnJvcikgZmFpbChcIkNvdWxkIG5vdCBzYXZlIHRoaXMgc3BhY2VcIiwgZXJyb3IpO1xuICAgIHJldHVybiB0cnVlO1xuICB9LFxuXG4gIC8qIOKUgOKUgCBJbnF1aXJpZXMg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAICovXG4gIC8vIEJhY2tlZCBieSBjb252ZXJzYXRpb25zICsgbWVzc2FnZXMsIHNvIHRoZSBzYW1lIHJvd3MgYmVjb21lIHRoZSBjaGF0XG4gIC8vIHRocmVhZCB3aGVuIG1lc3NhZ2luZyBsYW5kcyBpbiB0aGUgbmV4dCBzdGFnZS5cblxuICBhc3luYyBpbnF1aXJpZXMoKTogUHJvbWlzZTxJbnF1aXJ5W10+IHtcbiAgICBjb25zdCB1c2VySWQgPSBhd2FpdCBjdXJyZW50VXNlcklkKCk7XG4gICAgaWYgKCF1c2VySWQpIHJldHVybiBbXTtcblxuICAgIGNvbnN0IHsgZGF0YSwgZXJyb3IgfSA9IGF3YWl0IGNsaWVudCgpXG4gICAgICAuZnJvbShcImNvbnZlcnNhdGlvbnNcIilcbiAgICAgIC5zZWxlY3QoXCJpZCwgc3BhY2VfaWQsIHJlbnRlcl9pZCwgY3JlYXRlZF9hdCwgbWVzc2FnZXMoaWQsIGJvZHksIGNyZWF0ZWRfYXQsIHNlbmRlcl9pZCksIHByb2ZpbGVzIWNvbnZlcnNhdGlvbnNfcmVudGVyX2lkX2ZrZXkobmFtZSlcIilcbiAgICAgIC5vcmRlcihcImxhc3RfbWVzc2FnZV9hdFwiLCB7IGFzY2VuZGluZzogZmFsc2UgfSk7XG5cbiAgICBpZiAoZXJyb3IpIGZhaWwoXCJDb3VsZCBub3QgbG9hZCBpbnF1aXJpZXNcIiwgZXJyb3IpO1xuXG4gICAgcmV0dXJuIChkYXRhID8/IFtdKS5mbGF0TWFwKChyb3cpID0+IHtcbiAgICAgIGNvbnN0IGNvbnYgPSByb3cgYXMgdW5rbm93biBhcyB7XG4gICAgICAgIGlkOiBzdHJpbmc7XG4gICAgICAgIHNwYWNlX2lkOiBzdHJpbmcgfCBudWxsO1xuICAgICAgICByZW50ZXJfaWQ6IHN0cmluZztcbiAgICAgICAgY3JlYXRlZF9hdDogc3RyaW5nO1xuICAgICAgICBtZXNzYWdlczogQXJyYXk8eyBpZDogc3RyaW5nOyBib2R5OiBzdHJpbmc7IGNyZWF0ZWRfYXQ6IHN0cmluZzsgc2VuZGVyX2lkOiBzdHJpbmcgfT47XG4gICAgICAgIHByb2ZpbGVzOiB7IG5hbWU6IHN0cmluZyB9IHwgQXJyYXk8eyBuYW1lOiBzdHJpbmcgfT4gfCBudWxsO1xuICAgICAgfTtcbiAgICAgIGNvbnN0IGZpcnN0ID0gWy4uLmNvbnYubWVzc2FnZXNdLnNvcnQoKGEsIGIpID0+IGEuY3JlYXRlZF9hdC5sb2NhbGVDb21wYXJlKGIuY3JlYXRlZF9hdCkpWzBdO1xuICAgICAgaWYgKCFmaXJzdCB8fCAhY29udi5zcGFjZV9pZCkgcmV0dXJuIFtdO1xuXG4gICAgICAvLyBQb3N0Z1JFU1QgcmV0dXJucyBhbiBlbWJlZGRlZCByb3cgYXMgYW4gb2JqZWN0IG9yIGEgb25lLWVsZW1lbnQgYXJyYXlcbiAgICAgIC8vIGRlcGVuZGluZyBvbiB0aGUgcmVsYXRpb25zaGlwIGl0IGluZmVyczsgaGFuZGxlIGJvdGguXG4gICAgICBjb25zdCBwcm9maWxlID0gQXJyYXkuaXNBcnJheShjb252LnByb2ZpbGVzKSA/IGNvbnYucHJvZmlsZXNbMF0gOiBjb252LnByb2ZpbGVzO1xuXG4gICAgICByZXR1cm4gW3tcbiAgICAgICAgaWQ6IGNvbnYuaWQsXG4gICAgICAgIHNwYWNlSWQ6IGNvbnYuc3BhY2VfaWQsXG4gICAgICAgIG5hbWU6IHByb2ZpbGU/Lm5hbWUgPz8gXCJIYWJpdG8gdXNlclwiLFxuICAgICAgICBtZXNzYWdlOiBmaXJzdC5ib2R5LFxuICAgICAgICBtb3ZlSW5EYXRlOiBjb252LmNyZWF0ZWRfYXQuc2xpY2UoMCwgMTApLFxuICAgICAgICBidWRnZXRNaW46IDAsXG4gICAgICAgIGJ1ZGdldE1heDogMCxcbiAgICAgICAgc2VudEF0OiBmaXJzdC5jcmVhdGVkX2F0LFxuICAgICAgICBzdGF0dXM6IFwibmV3XCIgYXMgSW5xdWlyeVN0YXR1cyxcbiAgICAgIH1dO1xuICAgIH0pO1xuICB9LFxuXG4gIGFzeW5jIGNyZWF0ZUlucXVpcnkoaW5wdXQpOiBQcm9taXNlPElucXVpcnk+IHtcbiAgICBjb25zdCB1c2VySWQgPSBhd2FpdCByZXF1aXJlVXNlcihcInNlbmQgYW4gaW5xdWlyeVwiKTtcblxuICAgIGNvbnN0IHsgZGF0YTogc3BhY2UsIGVycm9yOiBzcGFjZUVycm9yIH0gPSBhd2FpdCBjbGllbnQoKVxuICAgICAgLmZyb20oXCJzcGFjZXNcIilcbiAgICAgIC5zZWxlY3QoXCJpZCwgcHJvcGVydGllcyFpbm5lcihvd25lcl9pZClcIilcbiAgICAgIC5lcShcImlkXCIsIGlucHV0LnNwYWNlSWQpXG4gICAgICAuc2luZ2xlKCk7XG5cbiAgICBpZiAoc3BhY2VFcnJvcikgZmFpbChcIkNvdWxkIG5vdCBmaW5kIHRoYXQgc3BhY2VcIiwgc3BhY2VFcnJvcik7XG4gICAgY29uc3Qgb3duZXJJZCA9IChzcGFjZSBhcyB1bmtub3duIGFzIHsgcHJvcGVydGllczogeyBvd25lcl9pZDogc3RyaW5nIH0gfSkucHJvcGVydGllcy5vd25lcl9pZDtcblxuICAgIC8vIE9uZSB0aHJlYWQgcGVyIHBlcnNvbiBwZXIgc3BhY2Ug4oCUIGEgc2Vjb25kIGlucXVpcnkgY29udGludWVzIGl0LlxuICAgIGNvbnN0IHsgZGF0YTogY29udmVyc2F0aW9uLCBlcnJvcjogY29udkVycm9yIH0gPSBhd2FpdCBjbGllbnQoKVxuICAgICAgLmZyb20oXCJjb252ZXJzYXRpb25zXCIpXG4gICAgICAudXBzZXJ0KFxuICAgICAgICB7IHNwYWNlX2lkOiBpbnB1dC5zcGFjZUlkLCByZW50ZXJfaWQ6IHVzZXJJZCwgb3duZXJfaWQ6IG93bmVySWQsIGxhc3RfbWVzc2FnZV9hdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpIH0sXG4gICAgICAgIHsgb25Db25mbGljdDogXCJzcGFjZV9pZCxyZW50ZXJfaWQsb3duZXJfaWRcIiB9LFxuICAgICAgKVxuICAgICAgLnNlbGVjdCgpXG4gICAgICAuc2luZ2xlKCk7XG5cbiAgICBpZiAoY29udkVycm9yKSBmYWlsKFwiQ291bGQgbm90IHN0YXJ0IHRoZSBjb252ZXJzYXRpb25cIiwgY29udkVycm9yKTtcblxuICAgIGNvbnN0IHsgZGF0YTogbWVzc2FnZSwgZXJyb3I6IG1zZ0Vycm9yIH0gPSBhd2FpdCBjbGllbnQoKVxuICAgICAgLmZyb20oXCJtZXNzYWdlc1wiKVxuICAgICAgLmluc2VydCh7IGNvbnZlcnNhdGlvbl9pZDogKGNvbnZlcnNhdGlvbiBhcyB7IGlkOiBzdHJpbmcgfSkuaWQsIHNlbmRlcl9pZDogdXNlcklkLCBib2R5OiBpbnB1dC5tZXNzYWdlIH0pXG4gICAgICAuc2VsZWN0KClcbiAgICAgIC5zaW5nbGUoKTtcblxuICAgIGlmIChtc2dFcnJvcikgZmFpbChcIkNvdWxkIG5vdCBzZW5kIHRoZSBtZXNzYWdlXCIsIG1zZ0Vycm9yKTtcblxuICAgIGF3YWl0IGNsaWVudCgpLmZyb20oXCJub3RpZmljYXRpb25zXCIpLmluc2VydCh7XG4gICAgICB1c2VyX2lkOiBvd25lcklkLFxuICAgICAga2luZDogXCJtZXNzYWdlXCIsXG4gICAgICB0aXRsZTogXCJOZXcgaW5xdWlyeVwiLFxuICAgICAgYm9keTogaW5wdXQubWVzc2FnZS5zbGljZSgwLCAxNDApLFxuICAgICAgZW50aXR5X3R5cGU6IFwic3BhY2VcIixcbiAgICAgIGVudGl0eV9pZDogaW5wdXQuc3BhY2VJZCxcbiAgICB9KTtcblxuICAgIHJldHVybiB7XG4gICAgICAuLi5pbnB1dCxcbiAgICAgIGlkOiAobWVzc2FnZSBhcyB7IGlkOiBzdHJpbmcgfSkuaWQsXG4gICAgICBzZW50QXQ6IChtZXNzYWdlIGFzIHsgY3JlYXRlZF9hdDogc3RyaW5nIH0pLmNyZWF0ZWRfYXQsXG4gICAgICBzdGF0dXM6IFwibmV3XCIsXG4gICAgfTtcbiAgfSxcblxuICBhc3luYyBzZXRJbnF1aXJ5U3RhdHVzKGlucXVpcnlJZDogc3RyaW5nLCBfc3RhdHVzOiBJbnF1aXJ5U3RhdHVzKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgLy8gSW5xdWlyeSBzdGF0ZSBtb3ZlcyBvbnRvIHRoZSBib29raW5nIHJlY29yZCBpbiB0aGUgbmV4dCBzdGFnZTsgZm9yIG5vd1xuICAgIC8vIG9wZW5pbmcgYSB0aHJlYWQgc2ltcGx5IG1hcmtzIGl0cyBtZXNzYWdlcyByZWFkLlxuICAgIGNvbnN0IHVzZXJJZCA9IGF3YWl0IGN1cnJlbnRVc2VySWQoKTtcbiAgICBpZiAoIXVzZXJJZCkgcmV0dXJuO1xuXG4gICAgYXdhaXQgY2xpZW50KClcbiAgICAgIC5mcm9tKFwibWVzc2FnZXNcIilcbiAgICAgIC51cGRhdGUoeyByZWFkX2F0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkgfSlcbiAgICAgIC5lcShcImNvbnZlcnNhdGlvbl9pZFwiLCBpbnF1aXJ5SWQpXG4gICAgICAubmVxKFwic2VuZGVyX2lkXCIsIHVzZXJJZClcbiAgICAgIC5pcyhcInJlYWRfYXRcIiwgbnVsbCk7XG4gIH0sXG5cbiAgLyog4pSA4pSAIFNwYWNlIHJlcXVlc3RzIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgCAqL1xuXG4gIGFzeW5jIHJlcXVlc3RzKCk6IFByb21pc2U8U3BhY2VSZXF1ZXN0W10+IHtcbiAgICBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCBjbGllbnQoKVxuICAgICAgLmZyb20oXCJzcGFjZV9yZXF1ZXN0c1wiKVxuICAgICAgLnNlbGVjdChcIipcIilcbiAgICAgIC5lcShcIm9wZW5cIiwgdHJ1ZSlcbiAgICAgIC5vcmRlcihcImNyZWF0ZWRfYXRcIiwgeyBhc2NlbmRpbmc6IGZhbHNlIH0pO1xuXG4gICAgaWYgKGVycm9yKSBmYWlsKFwiQ291bGQgbm90IGxvYWQgcmVxdWVzdHNcIiwgZXJyb3IpO1xuXG4gICAgcmV0dXJuIChkYXRhID8/IFtdKS5tYXAoKHJvdykgPT4ge1xuICAgICAgY29uc3QgciA9IHJvdyBhcyBSZWNvcmQ8c3RyaW5nLCBzdHJpbmcgJiBudW1iZXI+O1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgaWQ6IHIuaWQsXG4gICAgICAgIGNhdGVnb3J5OiByLmNhdGVnb3J5IGFzIFNwYWNlUmVxdWVzdFtcImNhdGVnb3J5XCJdLFxuICAgICAgICBzcGFjZVR5cGU6IHIuc3BhY2VfdHlwZSBhcyBTcGFjZVJlcXVlc3RbXCJzcGFjZVR5cGVcIl0sXG4gICAgICAgIHRyYW5zYWN0aW9uOiByLnRyYW5zYWN0aW9uIGFzIFNwYWNlUmVxdWVzdFtcInRyYW5zYWN0aW9uXCJdLFxuICAgICAgICBhcmVhOiByLmFyZWEsXG4gICAgICAgIGJ1ZGdldE1pbjogTnVtYmVyKHIuYnVkZ2V0X21pbiksXG4gICAgICAgIGJ1ZGdldE1heDogTnVtYmVyKHIuYnVkZ2V0X21heCksXG4gICAgICAgIG5lZWRlZEJ5OiByLm5lZWRlZF9ieSxcbiAgICAgICAgbm90ZTogci5ub3RlID8/IFwiXCIsXG4gICAgICAgIGNyZWF0ZWRBdDogci5jcmVhdGVkX2F0LFxuICAgICAgfTtcbiAgICB9KTtcbiAgfSxcblxuICBhc3luYyBjcmVhdGVSZXF1ZXN0KGlucHV0KTogUHJvbWlzZTxTcGFjZVJlcXVlc3Q+IHtcbiAgICBjb25zdCB1c2VySWQgPSBhd2FpdCByZXF1aXJlVXNlcihcInBvc3QgYSByZXF1ZXN0XCIpO1xuXG4gICAgY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgY2xpZW50KClcbiAgICAgIC5mcm9tKFwic3BhY2VfcmVxdWVzdHNcIilcbiAgICAgIC5pbnNlcnQoe1xuICAgICAgICB1c2VyX2lkOiB1c2VySWQsXG4gICAgICAgIGNhdGVnb3J5OiBpbnB1dC5jYXRlZ29yeSxcbiAgICAgICAgc3BhY2VfdHlwZTogaW5wdXQuc3BhY2VUeXBlLFxuICAgICAgICB0cmFuc2FjdGlvbjogaW5wdXQudHJhbnNhY3Rpb24sXG4gICAgICAgIGFyZWE6IGlucHV0LmFyZWEsXG4gICAgICAgIGJ1ZGdldF9taW46IGlucHV0LmJ1ZGdldE1pbixcbiAgICAgICAgYnVkZ2V0X21heDogaW5wdXQuYnVkZ2V0TWF4LFxuICAgICAgICBuZWVkZWRfYnk6IGlucHV0Lm5lZWRlZEJ5LFxuICAgICAgICBub3RlOiBpbnB1dC5ub3RlLFxuICAgICAgfSlcbiAgICAgIC5zZWxlY3QoKVxuICAgICAgLnNpbmdsZSgpO1xuXG4gICAgaWYgKGVycm9yKSBmYWlsKFwiQ291bGQgbm90IHBvc3QgdGhlIHJlcXVlc3RcIiwgZXJyb3IpO1xuICAgIHJldHVybiB7IC4uLmlucHV0LCBpZDogKGRhdGEgYXMgeyBpZDogc3RyaW5nIH0pLmlkLCBjcmVhdGVkQXQ6IChkYXRhIGFzIHsgY3JlYXRlZF9hdDogc3RyaW5nIH0pLmNyZWF0ZWRfYXQgfTtcbiAgfSxcblxuICAvKiDilIDilIAgQm9va2luZ3Mg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAICovXG5cbiAgYXN5bmMgYm9va2luZ3MoKTogUHJvbWlzZTxCb29raW5nW10+IHtcbiAgICBjb25zdCB1c2VySWQgPSBhd2FpdCBjdXJyZW50VXNlcklkKCk7XG4gICAgaWYgKCF1c2VySWQpIHJldHVybiBbXTtcblxuICAgIC8vIFJvdy1sZXZlbCBzZWN1cml0eSBhbHJlYWR5IGxpbWl0cyB0aGlzIHRvIGJvb2tpbmdzIHlvdSBhcmUgcGFydCBvZi5cbiAgICBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCBjbGllbnQoKVxuICAgICAgLmZyb20oXCJib29raW5nc1wiKVxuICAgICAgLnNlbGVjdChgXG4gICAgICAgICosXG4gICAgICAgIHNwYWNlcyAoIGlkLCBuYW1lLCBpbWFnZXMsIHByb3BlcnRpZXMgKCBhcmVhICkgKSxcbiAgICAgICAgcmVudGVyOnByb2ZpbGVzIWJvb2tpbmdzX3JlbnRlcl9pZF9ma2V5ICggaWQsIG5hbWUgKSxcbiAgICAgICAgb3duZXI6cHJvZmlsZXMhYm9va2luZ3Nfb3duZXJfaWRfZmtleSAoIGlkLCBuYW1lIClcbiAgICAgIGApXG4gICAgICAub3JkZXIoXCJjcmVhdGVkX2F0XCIsIHsgYXNjZW5kaW5nOiBmYWxzZSB9KTtcblxuICAgIGlmIChlcnJvcikgZmFpbChcIkNvdWxkIG5vdCBsb2FkIHlvdXIgYm9va2luZ3NcIiwgZXJyb3IpO1xuXG4gICAgcmV0dXJuIChkYXRhID8/IFtdKS5tYXAoKHJvdykgPT4ge1xuICAgICAgY29uc3QgYiA9IHJvdyBhcyB1bmtub3duIGFzIHtcbiAgICAgICAgaWQ6IHN0cmluZzsgc3BhY2VfaWQ6IHN0cmluZzsgcmVudGVyX2lkOiBzdHJpbmc7IG93bmVyX2lkOiBzdHJpbmc7XG4gICAgICAgIHN0YXR1czogQm9va2luZ1N0YXR1czsgbW92ZV9pbl9kYXRlOiBzdHJpbmc7IG1vbnRoczogbnVtYmVyOyBhbW91bnQ6IG51bWJlcjtcbiAgICAgICAgbWVzc2FnZTogc3RyaW5nIHwgbnVsbDsgcGhvbmVfc2hhcmVkOiBib29sZWFuO1xuICAgICAgICByZW50ZXJfcGhvbmU6IHN0cmluZyB8IG51bGw7IG93bmVyX3Bob25lOiBzdHJpbmcgfCBudWxsO1xuICAgICAgICBkZWNsaW5lX3JlYXNvbjogc3RyaW5nIHwgbnVsbDsgY3JlYXRlZF9hdDogc3RyaW5nOyBkZWNpZGVkX2F0OiBzdHJpbmcgfCBudWxsO1xuICAgICAgICBzcGFjZXM6IHsgbmFtZTogc3RyaW5nOyBpbWFnZXM6IEFycmF5PHsgdXJsOiBzdHJpbmcgfT47IHByb3BlcnRpZXM6IHsgYXJlYTogc3RyaW5nIH0gfCBudWxsIH0gfCBudWxsO1xuICAgICAgICByZW50ZXI6IHsgaWQ6IHN0cmluZzsgbmFtZTogc3RyaW5nIH0gfCBudWxsO1xuICAgICAgICBvd25lcjogeyBpZDogc3RyaW5nOyBuYW1lOiBzdHJpbmcgfSB8IG51bGw7XG4gICAgICB9O1xuXG4gICAgICByZXR1cm4ge1xuICAgICAgICBpZDogYi5pZCxcbiAgICAgICAgc3BhY2VJZDogYi5zcGFjZV9pZCxcbiAgICAgICAgc3BhY2VOYW1lOiBiLnNwYWNlcz8ubmFtZSA/PyBcIkEgc3BhY2VcIixcbiAgICAgICAgc3BhY2VJbWFnZTogYi5zcGFjZXM/LmltYWdlcz8uWzBdPy51cmwgPz8gbnVsbCxcbiAgICAgICAgYXJlYTogYi5zcGFjZXM/LnByb3BlcnRpZXM/LmFyZWEgPz8gbnVsbCxcbiAgICAgICAgcmVudGVySWQ6IGIucmVudGVyX2lkLFxuICAgICAgICByZW50ZXJOYW1lOiBiLnJlbnRlcj8ubmFtZSA/PyBcIkhhYml0byB1c2VyXCIsXG4gICAgICAgIG93bmVySWQ6IGIub3duZXJfaWQsXG4gICAgICAgIG93bmVyTmFtZTogYi5vd25lcj8ubmFtZSA/PyBcIk93bmVyXCIsXG4gICAgICAgIHN0YXR1czogYi5zdGF0dXMsXG4gICAgICAgIG1vdmVJbkRhdGU6IGIubW92ZV9pbl9kYXRlLFxuICAgICAgICBtb250aHM6IGIubW9udGhzLFxuICAgICAgICBhbW91bnQ6IGIuYW1vdW50LFxuICAgICAgICBtZXNzYWdlOiBiLm1lc3NhZ2UsXG4gICAgICAgIHBob25lU2hhcmVkOiBiLnBob25lX3NoYXJlZCxcbiAgICAgICAgcmVudGVyUGhvbmU6IGIucmVudGVyX3Bob25lLFxuICAgICAgICBvd25lclBob25lOiBiLm93bmVyX3Bob25lLFxuICAgICAgICBkZWNsaW5lUmVhc29uOiBiLmRlY2xpbmVfcmVhc29uLFxuICAgICAgICBjcmVhdGVkQXQ6IGIuY3JlYXRlZF9hdCxcbiAgICAgICAgZGVjaWRlZEF0OiBiLmRlY2lkZWRfYXQsXG4gICAgICAgIHlvdUFyZU93bmVyOiBiLm93bmVyX2lkID09PSB1c2VySWQsXG4gICAgICB9O1xuICAgIH0pO1xuICB9LFxuXG4gIGFzeW5jIHJlcXVlc3RCb29raW5nKGlucHV0KTogUHJvbWlzZTxCb29raW5nPiB7XG4gICAgY29uc3QgdXNlcklkID0gYXdhaXQgcmVxdWlyZVVzZXIoXCJyZXF1ZXN0IGEgYm9va2luZ1wiKTtcblxuICAgIC8vIG93bmVyX2lkIGlzIG92ZXJ3cml0dGVuIGJ5IGEgdHJpZ2dlciBmcm9tIHRoZSBwcm9wZXJ0eSwgc28gd2hhdCB0aGVcbiAgICAvLyBjbGllbnQgc2VuZHMgaGVyZSBjYW5ub3QgYmUgdXNlZCB0byBtaXNhdHRyaWJ1dGUgYSBib29raW5nLlxuICAgIGNvbnN0IHsgZGF0YSwgZXJyb3IgfSA9IGF3YWl0IGNsaWVudCgpXG4gICAgICAuZnJvbShcImJvb2tpbmdzXCIpXG4gICAgICAuaW5zZXJ0KHtcbiAgICAgICAgc3BhY2VfaWQ6IGlucHV0LnNwYWNlSWQsXG4gICAgICAgIHJlbnRlcl9pZDogdXNlcklkLFxuICAgICAgICBvd25lcl9pZDogdXNlcklkLFxuICAgICAgICBtb3ZlX2luX2RhdGU6IGlucHV0Lm1vdmVJbkRhdGUsXG4gICAgICAgIG1vbnRoczogaW5wdXQubW9udGhzLFxuICAgICAgICBhbW91bnQ6IGlucHV0LmFtb3VudCxcbiAgICAgICAgbWVzc2FnZTogaW5wdXQubWVzc2FnZSA/PyBudWxsLFxuICAgICAgfSlcbiAgICAgIC5zZWxlY3QoKVxuICAgICAgLnNpbmdsZSgpO1xuXG4gICAgaWYgKGVycm9yKSBmYWlsKFwiQ291bGQgbm90IHJlcXVlc3QgdGhpcyBib29raW5nXCIsIGVycm9yKTtcblxuICAgIGNvbnN0IHJvdyA9IGRhdGEgYXMgeyBpZDogc3RyaW5nOyBjcmVhdGVkX2F0OiBzdHJpbmc7IHN0YXR1czogQm9va2luZ1N0YXR1cyB9O1xuICAgIHJldHVybiB7XG4gICAgICBpZDogcm93LmlkLFxuICAgICAgc3BhY2VJZDogaW5wdXQuc3BhY2VJZCxcbiAgICAgIHNwYWNlTmFtZTogXCJcIixcbiAgICAgIHNwYWNlSW1hZ2U6IG51bGwsXG4gICAgICBhcmVhOiBudWxsLFxuICAgICAgcmVudGVySWQ6IHVzZXJJZCxcbiAgICAgIHJlbnRlck5hbWU6IFwiXCIsXG4gICAgICBvd25lcklkOiBcIlwiLFxuICAgICAgb3duZXJOYW1lOiBcIlwiLFxuICAgICAgc3RhdHVzOiByb3cuc3RhdHVzLFxuICAgICAgbW92ZUluRGF0ZTogaW5wdXQubW92ZUluRGF0ZSxcbiAgICAgIG1vbnRoczogaW5wdXQubW9udGhzLFxuICAgICAgYW1vdW50OiBpbnB1dC5hbW91bnQsXG4gICAgICBtZXNzYWdlOiBpbnB1dC5tZXNzYWdlID8/IG51bGwsXG4gICAgICBwaG9uZVNoYXJlZDogZmFsc2UsXG4gICAgICByZW50ZXJQaG9uZTogbnVsbCxcbiAgICAgIG93bmVyUGhvbmU6IG51bGwsXG4gICAgICBkZWNsaW5lUmVhc29uOiBudWxsLFxuICAgICAgY3JlYXRlZEF0OiByb3cuY3JlYXRlZF9hdCxcbiAgICAgIGRlY2lkZWRBdDogbnVsbCxcbiAgICAgIHlvdUFyZU93bmVyOiBmYWxzZSxcbiAgICB9O1xuICB9LFxuXG4gIGFzeW5jIHNldEJvb2tpbmdTdGF0dXMoYm9va2luZ0lkOiBzdHJpbmcsIHN0YXR1czogQm9va2luZ1N0YXR1cywgcmVhc29uPzogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgYXdhaXQgcmVxdWlyZVVzZXIoXCJjaGFuZ2UgYSBib29raW5nXCIpO1xuXG4gICAgY29uc3QgcGF0Y2g6IFJlY29yZDxzdHJpbmcsIHVua25vd24+ID0geyBzdGF0dXMgfTtcbiAgICBpZiAocmVhc29uICE9PSB1bmRlZmluZWQpIHBhdGNoLmRlY2xpbmVfcmVhc29uID0gcmVhc29uO1xuXG4gICAgLy8gTGVnYWwgbW92ZXMsIHBlcm1pc3Npb25zIGFuZCB0aGUgcGhvbmUgcmV2ZWFsIGFyZSBhbGwgZGVjaWRlZCBieSB0aGVcbiAgICAvLyBkYXRhYmFzZSB0cmlnZ2VyOyBhIHJlamVjdGlvbiBoZXJlIGlzIGEgcmVhbCByZWplY3Rpb24uXG4gICAgY29uc3QgeyBlcnJvciB9ID0gYXdhaXQgY2xpZW50KCkuZnJvbShcImJvb2tpbmdzXCIpLnVwZGF0ZShwYXRjaCkuZXEoXCJpZFwiLCBib29raW5nSWQpO1xuICAgIGlmIChlcnJvcikgZmFpbChcIkNvdWxkIG5vdCB1cGRhdGUgdGhpcyBib29raW5nXCIsIGVycm9yKTtcbiAgfSxcblxuICAvKiDilIDilIAgTW9kZXJhdGlvbiDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIAgKi9cblxuICBhc3luYyByZXZpZXdRdWV1ZSgpOiBQcm9taXNlPFJldmlld0l0ZW1bXT4ge1xuICAgIGNvbnN0IHsgZGF0YSwgZXJyb3IgfSA9IGF3YWl0IGNsaWVudCgpXG4gICAgICAuZnJvbShcInJldmlld19xdWV1ZVwiKVxuICAgICAgLnNlbGVjdChcIipcIilcbiAgICAgIC5vcmRlcihcInByaW9yaXR5XCIsIHsgYXNjZW5kaW5nOiB0cnVlIH0pXG4gICAgICAub3JkZXIoXCJjcmVhdGVkX2F0XCIsIHsgYXNjZW5kaW5nOiB0cnVlIH0pO1xuXG4gICAgaWYgKGVycm9yKSBmYWlsKFwiQ291bGQgbm90IGxvYWQgdGhlIHJldmlldyBxdWV1ZVwiLCBlcnJvcik7XG5cbiAgICByZXR1cm4gKGRhdGEgPz8gW10pLm1hcCgocm93KSA9PiB7XG4gICAgICBjb25zdCByID0gcm93IGFzIHtcbiAgICAgICAgc3BhY2VfaWQ6IHN0cmluZzsgc3BhY2VfbmFtZTogc3RyaW5nOyBhcmVhOiBzdHJpbmcgfCBudWxsO1xuICAgICAgICBvd25lcl9pZDogc3RyaW5nOyBvd25lcl9uYW1lOiBzdHJpbmc7IG93bmVyX3RydXN0OiBUcnVzdFRpZXI7XG4gICAgICAgIGNvbXBsZXRlbmVzczogbnVtYmVyOyBmbGFnZ2VkX2R1cGxpY2F0ZTogYm9vbGVhbjtcbiAgICAgICAgaGlkZGVuX2F0OiBzdHJpbmcgfCBudWxsOyBoaWRkZW5fcmVhc29uOiBzdHJpbmcgfCBudWxsO1xuICAgICAgICByZXBvcnRfY291bnQ6IG51bWJlcjsgb3Blbl9yZXBvcnRzOiBudW1iZXI7IHByaW9yaXR5OiBudW1iZXI7XG4gICAgICB9O1xuXG4gICAgICByZXR1cm4ge1xuICAgICAgICBzcGFjZUlkOiByLnNwYWNlX2lkLFxuICAgICAgICBzcGFjZU5hbWU6IHIuc3BhY2VfbmFtZSxcbiAgICAgICAgYXJlYTogci5hcmVhLFxuICAgICAgICBvd25lcklkOiByLm93bmVyX2lkLFxuICAgICAgICBvd25lck5hbWU6IHIub3duZXJfbmFtZSxcbiAgICAgICAgb3duZXJUcnVzdDogci5vd25lcl90cnVzdCxcbiAgICAgICAgY29tcGxldGVuZXNzOiByLmNvbXBsZXRlbmVzcyxcbiAgICAgICAgZmxhZ2dlZER1cGxpY2F0ZTogci5mbGFnZ2VkX2R1cGxpY2F0ZSxcbiAgICAgICAgaGlkZGVuQXQ6IHIuaGlkZGVuX2F0LFxuICAgICAgICBoaWRkZW5SZWFzb246IHIuaGlkZGVuX3JlYXNvbixcbiAgICAgICAgcmVwb3J0Q291bnQ6IE51bWJlcihyLnJlcG9ydF9jb3VudCksXG4gICAgICAgIG9wZW5SZXBvcnRzOiBOdW1iZXIoci5vcGVuX3JlcG9ydHMpLFxuICAgICAgICBwcmlvcml0eTogci5wcmlvcml0eSxcbiAgICAgIH07XG4gICAgfSk7XG4gIH0sXG5cbiAgYXN5bmMgc2V0TGlzdGluZ1Zpc2libGUoc3BhY2VJZDogc3RyaW5nLCB2aXNpYmxlOiBib29sZWFuLCBub3RlPzogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgLy8gRXZlcnkgb25lIG9mIHRoZXNlIHdyaXRlcyBpdHMgb3duIGF1ZGl0IHJvdyBpbnNpZGUgdGhlIGZ1bmN0aW9uLCBzbyB0aGVcbiAgICAvLyByZWNvcmQgY2Fubm90IGJlIHNraXBwZWQgYnkgYSBjbGllbnQgdGhhdCBmb3JnZXRzIHRvIHdyaXRlIGl0LlxuICAgIGNvbnN0IHsgZXJyb3IgfSA9IGF3YWl0IGNsaWVudCgpLnJwYyhcImFkbWluX3NldF9saXN0aW5nX3Zpc2libGVcIiwge1xuICAgICAgdGFyZ2V0OiBzcGFjZUlkLFxuICAgICAgdmlzaWJsZSxcbiAgICAgIHdoeTogbm90ZSA/PyBudWxsLFxuICAgIH0pO1xuICAgIGlmIChlcnJvcikgZmFpbChcIkNvdWxkIG5vdCBjaGFuZ2UgdGhhdCBsaXN0aW5nXCIsIGVycm9yKTtcbiAgfSxcblxuICBhc3luYyBzZXRUcnVzdChwcm9maWxlSWQ6IHN0cmluZywgdGllcjogVHJ1c3RUaWVyLCBub3RlOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcbiAgICBjb25zdCB7IGVycm9yIH0gPSBhd2FpdCBjbGllbnQoKS5ycGMoXCJhZG1pbl9zZXRfdHJ1c3RcIiwge1xuICAgICAgdGFyZ2V0OiBwcm9maWxlSWQsXG4gICAgICB0aWVyLFxuICAgICAgd2h5OiBub3RlLFxuICAgIH0pO1xuICAgIGlmIChlcnJvcikgZmFpbChcIkNvdWxkIG5vdCBzZXQgdGhhdCB0cnVzdCBsZXZlbFwiLCBlcnJvcik7XG4gIH0sXG5cbiAgYXN5bmMgcmVzb2x2ZVJlcG9ydHMoc3BhY2VJZDogc3RyaW5nLCBkaXNtaXNzOiBib29sZWFuLCBub3RlPzogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgY29uc3QgeyBlcnJvciB9ID0gYXdhaXQgY2xpZW50KCkucnBjKFwiYWRtaW5fcmVzb2x2ZV9yZXBvcnRzXCIsIHtcbiAgICAgIHRhcmdldDogc3BhY2VJZCxcbiAgICAgIGRpc21pc3MsXG4gICAgICB3aHk6IG5vdGUgPz8gbnVsbCxcbiAgICB9KTtcbiAgICBpZiAoZXJyb3IpIGZhaWwoXCJDb3VsZCBub3QgcmVzb2x2ZSB0aG9zZSByZXBvcnRzXCIsIGVycm9yKTtcbiAgfSxcblxuICBhc3luYyBjbGVhckR1cGxpY2F0ZShzcGFjZUlkOiBzdHJpbmcsIG5vdGU/OiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcbiAgICBjb25zdCB7IGVycm9yIH0gPSBhd2FpdCBjbGllbnQoKS5ycGMoXCJhZG1pbl9jbGVhcl9kdXBsaWNhdGVcIiwge1xuICAgICAgdGFyZ2V0OiBzcGFjZUlkLFxuICAgICAgd2h5OiBub3RlID8/IG51bGwsXG4gICAgfSk7XG4gICAgaWYgKGVycm9yKSBmYWlsKFwiQ291bGQgbm90IGNsZWFyIHRoYXQgZmxhZ1wiLCBlcnJvcik7XG4gIH0sXG5cbiAgLyog4pSA4pSAIExpc3RpbmcgZmVlcyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIAgKi9cblxuICBhc3luYyBsaXN0aW5nRmVlKGNhdGVnb3J5OiBzdHJpbmcpOiBQcm9taXNlPG51bWJlcj4ge1xuICAgIGNvbnN0IHsgZGF0YSB9ID0gYXdhaXQgY2xpZW50KClcbiAgICAgIC5mcm9tKFwibGlzdGluZ19wcmljZXNcIilcbiAgICAgIC5zZWxlY3QoXCJhbW91bnRcIilcbiAgICAgIC5lcShcImNhdGVnb3J5XCIsIGNhdGVnb3J5KVxuICAgICAgLm1heWJlU2luZ2xlKCk7XG5cbiAgICByZXR1cm4gKGRhdGEgYXMgeyBhbW91bnQ6IG51bWJlciB9IHwgbnVsbCk/LmFtb3VudCA/PyAyMDA7XG4gIH0sXG5cbiAgYXN5bmMgbGlzdGluZ0FsbG93YW5jZShwcm9wZXJ0eUlkOiBzdHJpbmcpOiBQcm9taXNlPHsgdXNlZDogbnVtYmVyOyBoYXNQbGFuOiBib29sZWFuIH0+IHtcbiAgICBjb25zdCBbeyBkYXRhOiB1c2VkIH0sIHsgZGF0YTogcGxhbiB9XSA9IGF3YWl0IFByb21pc2UuYWxsKFtcbiAgICAgIGNsaWVudCgpLnJwYyhcImxpc3RpbmdzX3RoaXNfbW9udGhcIiwgeyB0YXJnZXQ6IHByb3BlcnR5SWQgfSksXG4gICAgICBjbGllbnQoKS5ycGMoXCJwcm9wZXJ0eV9oYXNfcGxhblwiLCB7IHRhcmdldDogcHJvcGVydHlJZCB9KSxcbiAgICBdKTtcblxuICAgIHJldHVybiB7IHVzZWQ6IE51bWJlcih1c2VkID8/IDApLCBoYXNQbGFuOiBCb29sZWFuKHBsYW4pIH07XG4gIH0sXG5cbiAgYXN5bmMgcGF5TGlzdGluZ0ZlZShzcGFjZUlkOiBzdHJpbmcsIGFtb3VudDogbnVtYmVyKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgY29uc3QgdXNlcklkID0gYXdhaXQgcmVxdWlyZVVzZXIoXCJwYXkgYSBsaXN0aW5nIGZlZVwiKTtcblxuICAgIGNvbnN0IHsgZGF0YSwgZXJyb3IgfSA9IGF3YWl0IGNsaWVudCgpXG4gICAgICAuZnJvbShcInBheW1lbnRzXCIpXG4gICAgICAuaW5zZXJ0KHtcbiAgICAgICAgdXNlcl9pZDogdXNlcklkLFxuICAgICAgICBhbW91bnQsXG4gICAgICAgIGtpbmQ6IFwibGlzdGluZ1wiLFxuICAgICAgICBzcGFjZV9pZDogc3BhY2VJZCxcbiAgICAgICAgZ2F0ZXdheTogXCJzYW5kYm94XCIsXG4gICAgICAgIHN0YXR1czogXCJwZW5kaW5nXCIsXG4gICAgICAgIHNpbXVsYXRlZDogdHJ1ZSxcbiAgICAgIH0pXG4gICAgICAuc2VsZWN0KFwiaWRcIilcbiAgICAgIC5zaW5nbGUoKTtcblxuICAgIGlmIChlcnJvcikgZmFpbChcIkNvdWxkIG5vdCBzdGFydCB0aGF0IHBheW1lbnRcIiwgZXJyb3IpO1xuXG4gICAgLy8gU3RhbmRzIGluIGZvciB0aGUgZ2F0ZXdheSBjYWxsYmFjaywgZXhhY3RseSBhcyB0aGUgcmVudCBzYW5kYm94IGRpZC5cbiAgICBjb25zdCB7IGVycm9yOiBzZXR0bGVFcnJvciB9ID0gYXdhaXQgY2xpZW50KClcbiAgICAgIC5mcm9tKFwicGF5bWVudHNcIilcbiAgICAgIC51cGRhdGUoeyBzdGF0dXM6IFwic3VjY2Vzc2Z1bFwiLCByZWZlcmVuY2U6IGBTQU5EQk9YLSR7RGF0ZS5ub3coKX1gIH0pXG4gICAgICAuZXEoXCJpZFwiLCAoZGF0YSBhcyB7IGlkOiBzdHJpbmcgfSkuaWQpO1xuXG4gICAgaWYgKHNldHRsZUVycm9yKSBmYWlsKFwiVGhhdCBwYXltZW50IGRpZCBub3QgZ28gdGhyb3VnaFwiLCBzZXR0bGVFcnJvcik7XG4gIH0sXG5cbiAgYXN5bmMgYnV5UHJvcGVydHlQbGFuKHByb3BlcnR5SWQ6IHN0cmluZywgYW1vdW50OiBudW1iZXIpOiBQcm9taXNlPHZvaWQ+IHtcbiAgICBjb25zdCB1c2VySWQgPSBhd2FpdCByZXF1aXJlVXNlcihcImJ1eSBhIHBsYW5cIik7XG5cbiAgICBjb25zdCBlbmRzID0gbmV3IERhdGUoKTtcbiAgICBlbmRzLnNldEZ1bGxZZWFyKGVuZHMuZ2V0RnVsbFllYXIoKSArIDEpO1xuXG4gICAgY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgY2xpZW50KClcbiAgICAgIC5mcm9tKFwicHJvcGVydHlfcGxhbnNcIilcbiAgICAgIC5pbnNlcnQoe1xuICAgICAgICBwcm9wZXJ0eV9pZDogcHJvcGVydHlJZCxcbiAgICAgICAgb3duZXJfaWQ6IHVzZXJJZCxcbiAgICAgICAgZW5kc19vbjogZW5kcy50b0lTT1N0cmluZygpLnNsaWNlKDAsIDEwKSxcbiAgICAgICAgYW1vdW50LFxuICAgICAgfSlcbiAgICAgIC5zZWxlY3QoXCJpZFwiKVxuICAgICAgLnNpbmdsZSgpO1xuXG4gICAgaWYgKGVycm9yKSBmYWlsKFwiQ291bGQgbm90IHN0YXJ0IHRoYXQgcGxhblwiLCBlcnJvcik7XG5cbiAgICBjb25zdCB7IGRhdGE6IHBheW1lbnQgfSA9IGF3YWl0IGNsaWVudCgpXG4gICAgICAuZnJvbShcInBheW1lbnRzXCIpXG4gICAgICAuaW5zZXJ0KHtcbiAgICAgICAgdXNlcl9pZDogdXNlcklkLFxuICAgICAgICBhbW91bnQsXG4gICAgICAgIGtpbmQ6IFwicGxhblwiLFxuICAgICAgICBwbGFuX2lkOiAoZGF0YSBhcyB7IGlkOiBzdHJpbmcgfSkuaWQsXG4gICAgICAgIGdhdGV3YXk6IFwic2FuZGJveFwiLFxuICAgICAgICBzdGF0dXM6IFwicGVuZGluZ1wiLFxuICAgICAgICBzaW11bGF0ZWQ6IHRydWUsXG4gICAgICB9KVxuICAgICAgLnNlbGVjdChcImlkXCIpXG4gICAgICAuc2luZ2xlKCk7XG5cbiAgICBpZiAocGF5bWVudCkge1xuICAgICAgYXdhaXQgY2xpZW50KClcbiAgICAgICAgLmZyb20oXCJwYXltZW50c1wiKVxuICAgICAgICAudXBkYXRlKHsgc3RhdHVzOiBcInN1Y2Nlc3NmdWxcIiwgcmVmZXJlbmNlOiBgU0FOREJPWC0ke0RhdGUubm93KCl9YCB9KVxuICAgICAgICAuZXEoXCJpZFwiLCAocGF5bWVudCBhcyB7IGlkOiBzdHJpbmcgfSkuaWQpO1xuICAgIH1cbiAgfSxcblxuICAvKiDilIDilIAgUmVudCDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIAgKi9cblxuICBhc3luYyBpbnZvaWNlcygpOiBQcm9taXNlPFJlbnRJbnZvaWNlW10+IHtcbiAgICBjb25zdCB1c2VySWQgPSBhd2FpdCBjdXJyZW50VXNlcklkKCk7XG4gICAgaWYgKCF1c2VySWQpIHJldHVybiBbXTtcblxuICAgIC8vIFN3ZWVwIG92ZXJkdWUgZmlyc3Qgc28gd2hhdCB5b3Ugc2VlIGlzIGN1cnJlbnQgcmF0aGVyIHRoYW4geWVzdGVyZGF5J3MuXG4gICAgYXdhaXQgY2xpZW50KCkucnBjKFwibWFya19vdmVyZHVlX2ludm9pY2VzXCIpO1xuXG4gICAgY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgY2xpZW50KClcbiAgICAgIC5mcm9tKFwicmVudF9pbnZvaWNlc1wiKVxuICAgICAgLnNlbGVjdChgXG4gICAgICAgICosXG4gICAgICAgIHNwYWNlcyAoIG5hbWUsIHByb3BlcnRpZXMgKCBhcmVhICkgKSxcbiAgICAgICAgcmVudGVyOnByb2ZpbGVzIXJlbnRfaW52b2ljZXNfcmVudGVyX2lkX2ZrZXkgKCBuYW1lICksXG4gICAgICAgIG93bmVyOnByb2ZpbGVzIXJlbnRfaW52b2ljZXNfb3duZXJfaWRfZmtleSAoIG5hbWUgKSxcbiAgICAgICAgcGF5bWVudHMgKCBzaW11bGF0ZWQgKVxuICAgICAgYClcbiAgICAgIC5vcmRlcihcImR1ZV9kYXRlXCIsIHsgYXNjZW5kaW5nOiB0cnVlIH0pO1xuXG4gICAgaWYgKGVycm9yKSBmYWlsKFwiQ291bGQgbm90IGxvYWQgeW91ciByZW50XCIsIGVycm9yKTtcblxuICAgIHJldHVybiAoZGF0YSA/PyBbXSkubWFwKChyb3cpID0+IHtcbiAgICAgIGNvbnN0IHIgPSByb3cgYXMgdW5rbm93biBhcyB7XG4gICAgICAgIGlkOiBzdHJpbmc7IGJvb2tpbmdfaWQ6IHN0cmluZzsgc3BhY2VfaWQ6IHN0cmluZzsgcmVudGVyX2lkOiBzdHJpbmc7IG93bmVyX2lkOiBzdHJpbmc7XG4gICAgICAgIHBlcmlvZF9zdGFydDogc3RyaW5nOyBwZXJpb2RfZW5kOiBzdHJpbmc7IGR1ZV9kYXRlOiBzdHJpbmc7IGFtb3VudDogbnVtYmVyO1xuICAgICAgICBzdGF0dXM6IFJlbnRJbnZvaWNlW1wic3RhdHVzXCJdOyBwYWlkX2F0OiBzdHJpbmcgfCBudWxsOyByZWNlaXB0X25vOiBzdHJpbmcgfCBudWxsO1xuICAgICAgICBzcGFjZXM6IHsgbmFtZTogc3RyaW5nOyBwcm9wZXJ0aWVzOiB7IGFyZWE6IHN0cmluZyB9IHwgbnVsbCB9IHwgbnVsbDtcbiAgICAgICAgcmVudGVyOiB7IG5hbWU6IHN0cmluZyB9IHwgbnVsbDtcbiAgICAgICAgb3duZXI6IHsgbmFtZTogc3RyaW5nIH0gfCBudWxsO1xuICAgICAgICBwYXltZW50czogeyBzaW11bGF0ZWQ6IGJvb2xlYW4gfSB8IG51bGw7XG4gICAgICB9O1xuXG4gICAgICBjb25zdCB5b3VBcmVPd25lciA9IHIub3duZXJfaWQgPT09IHVzZXJJZDtcbiAgICAgIHJldHVybiB7XG4gICAgICAgIGlkOiByLmlkLFxuICAgICAgICBib29raW5nSWQ6IHIuYm9va2luZ19pZCxcbiAgICAgICAgc3BhY2VJZDogci5zcGFjZV9pZCxcbiAgICAgICAgc3BhY2VOYW1lOiByLnNwYWNlcz8ubmFtZSA/PyBcIkEgc3BhY2VcIixcbiAgICAgICAgYXJlYTogci5zcGFjZXM/LnByb3BlcnRpZXM/LmFyZWEgPz8gbnVsbCxcbiAgICAgICAgY291bnRlcnBhcnROYW1lOiAoeW91QXJlT3duZXIgPyByLnJlbnRlcj8ubmFtZSA6IHIub3duZXI/Lm5hbWUpID8/IFwiSGFiaXRvIHVzZXJcIixcbiAgICAgICAgeW91QXJlT3duZXIsXG4gICAgICAgIHBlcmlvZFN0YXJ0OiByLnBlcmlvZF9zdGFydCxcbiAgICAgICAgcGVyaW9kRW5kOiByLnBlcmlvZF9lbmQsXG4gICAgICAgIGR1ZURhdGU6IHIuZHVlX2RhdGUsXG4gICAgICAgIGFtb3VudDogci5hbW91bnQsXG4gICAgICAgIHN0YXR1czogci5zdGF0dXMsXG4gICAgICAgIHBhaWRBdDogci5wYWlkX2F0LFxuICAgICAgICByZWNlaXB0Tm86IHIucmVjZWlwdF9ubyxcbiAgICAgICAgc2ltdWxhdGVkOiByLnBheW1lbnRzPy5zaW11bGF0ZWQgPz8gZmFsc2UsXG4gICAgICB9O1xuICAgIH0pO1xuICB9LFxuXG4gIGFzeW5jIHBheUludm9pY2UoaW52b2ljZUlkOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcbiAgICBjb25zdCB1c2VySWQgPSBhd2FpdCByZXF1aXJlVXNlcihcInBheSByZW50XCIpO1xuXG4gICAgY29uc3QgeyBkYXRhOiBpbnZvaWNlLCBlcnJvcjogcmVhZEVycm9yIH0gPSBhd2FpdCBjbGllbnQoKVxuICAgICAgLmZyb20oXCJyZW50X2ludm9pY2VzXCIpXG4gICAgICAuc2VsZWN0KFwiaWQsIGJvb2tpbmdfaWQsIGFtb3VudCwgc3RhdHVzXCIpXG4gICAgICAuZXEoXCJpZFwiLCBpbnZvaWNlSWQpXG4gICAgICAuc2luZ2xlKCk7XG5cbiAgICBpZiAocmVhZEVycm9yKSBmYWlsKFwiQ291bGQgbm90IGZpbmQgdGhhdCBpbnZvaWNlXCIsIHJlYWRFcnJvcik7XG4gICAgY29uc3QgaW52ID0gaW52b2ljZSBhcyB7IGJvb2tpbmdfaWQ6IHN0cmluZzsgYW1vdW50OiBudW1iZXI7IHN0YXR1czogc3RyaW5nIH07XG4gICAgaWYgKGludi5zdGF0dXMgPT09IFwicGFpZFwiKSByZXR1cm47XG5cbiAgICAvLyBSYWlzZWQgYXMgcGVuZGluZyDigJQgdGhlIGRhdGFiYXNlIHJlZnVzZXMgYW55IG90aGVyIHN0YXJ0aW5nIHN0YXR1cy5cbiAgICBjb25zdCB7IGRhdGE6IHBheW1lbnQsIGVycm9yOiBpbnNlcnRFcnJvciB9ID0gYXdhaXQgY2xpZW50KClcbiAgICAgIC5mcm9tKFwicGF5bWVudHNcIilcbiAgICAgIC5pbnNlcnQoe1xuICAgICAgICBib29raW5nX2lkOiBpbnYuYm9va2luZ19pZCxcbiAgICAgICAgdXNlcl9pZDogdXNlcklkLFxuICAgICAgICBhbW91bnQ6IGludi5hbW91bnQsXG4gICAgICAgIGludm9pY2VfaWQ6IGludm9pY2VJZCxcbiAgICAgICAga2luZDogXCJyZW50XCIsXG4gICAgICAgIGdhdGV3YXk6IFwic2FuZGJveFwiLFxuICAgICAgICBzdGF0dXM6IFwicGVuZGluZ1wiLFxuICAgICAgICBzaW11bGF0ZWQ6IHRydWUsXG4gICAgICB9KVxuICAgICAgLnNlbGVjdChcImlkXCIpXG4gICAgICAuc2luZ2xlKCk7XG5cbiAgICBpZiAoaW5zZXJ0RXJyb3IpIGZhaWwoXCJDb3VsZCBub3Qgc3RhcnQgdGhhdCBwYXltZW50XCIsIGluc2VydEVycm9yKTtcblxuICAgIC8vIFN0YW5kcyBpbiBmb3IgdGhlIGdhdGV3YXkgY2FsbGJhY2suIEEgcmVhbCBpbnRlZ3JhdGlvbiByZXBsYWNlcyBleGFjdGx5XG4gICAgLy8gdGhpcyBzdGVwIGFuZCBub3RoaW5nIGVsc2UuXG4gICAgY29uc3QgeyBlcnJvcjogc2V0dGxlRXJyb3IgfSA9IGF3YWl0IGNsaWVudCgpXG4gICAgICAuZnJvbShcInBheW1lbnRzXCIpXG4gICAgICAudXBkYXRlKHsgc3RhdHVzOiBcInN1Y2Nlc3NmdWxcIiwgcmVmZXJlbmNlOiBgU0FOREJPWC0ke0RhdGUubm93KCl9YCB9KVxuICAgICAgLmVxKFwiaWRcIiwgKHBheW1lbnQgYXMgeyBpZDogc3RyaW5nIH0pLmlkKTtcblxuICAgIGlmIChzZXR0bGVFcnJvcikgZmFpbChcIlRoYXQgcGF5bWVudCBkaWQgbm90IGdvIHRocm91Z2hcIiwgc2V0dGxlRXJyb3IpO1xuICB9LFxuXG4gIGFzeW5jIHdhaXZlSW52b2ljZShpbnZvaWNlSWQ6IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuICAgIGF3YWl0IHJlcXVpcmVVc2VyKFwid2FpdmUgcmVudFwiKTtcbiAgICBjb25zdCB7IGVycm9yIH0gPSBhd2FpdCBjbGllbnQoKVxuICAgICAgLmZyb20oXCJyZW50X2ludm9pY2VzXCIpXG4gICAgICAudXBkYXRlKHsgc3RhdHVzOiBcIndhaXZlZFwiIH0pXG4gICAgICAuZXEoXCJpZFwiLCBpbnZvaWNlSWQpO1xuICAgIGlmIChlcnJvcikgZmFpbChcIkNvdWxkIG5vdCB3YWl2ZSB0aGF0IG1vbnRoXCIsIGVycm9yKTtcbiAgfSxcblxuICBhc3luYyBleHRlbmRTY2hlZHVsZShib29raW5nSWQ6IHN0cmluZywgbW9udGhzID0gMTIpOiBQcm9taXNlPHZvaWQ+IHtcbiAgICBhd2FpdCByZXF1aXJlVXNlcihcImV4dGVuZCBhIHJlbnQgc2NoZWR1bGVcIik7XG4gICAgY29uc3QgeyBlcnJvciB9ID0gYXdhaXQgY2xpZW50KCkucnBjKFwiZXh0ZW5kX3JlbnRfc2NoZWR1bGVcIiwge1xuICAgICAgdGFyZ2V0X2Jvb2tpbmc6IGJvb2tpbmdJZCxcbiAgICAgIGFkZF9tb250aHM6IG1vbnRocyxcbiAgICB9KTtcbiAgICBpZiAoZXJyb3IpIGZhaWwoXCJDb3VsZCBub3QgZXh0ZW5kIHRoYXQgc2NoZWR1bGVcIiwgZXJyb3IpO1xuICB9LFxuXG4gIC8qIOKUgOKUgCBNZXNzYWdpbmcg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAICovXG5cbiAgYXN5bmMgY29udmVyc2F0aW9ucygpOiBQcm9taXNlPENvbnZlcnNhdGlvbltdPiB7XG4gICAgY29uc3QgdXNlcklkID0gYXdhaXQgY3VycmVudFVzZXJJZCgpO1xuICAgIGlmICghdXNlcklkKSByZXR1cm4gW107XG5cbiAgICAvLyBSb3ctbGV2ZWwgc2VjdXJpdHkgYWxyZWFkeSBsaW1pdHMgdGhpcyB0byB0aHJlYWRzIHlvdSBiZWxvbmcgdG8sIHNvXG4gICAgLy8gdGhlcmUgaXMgbm8gbmVlZCB0byBmaWx0ZXIgYnkgdXNlciBoZXJlLlxuICAgIGNvbnN0IHsgZGF0YSwgZXJyb3IgfSA9IGF3YWl0IGNsaWVudCgpXG4gICAgICAuZnJvbShcImNvbnZlcnNhdGlvbnNcIilcbiAgICAgIC5zZWxlY3QoYFxuICAgICAgICBpZCwgc3BhY2VfaWQsIHJlbnRlcl9pZCwgb3duZXJfaWQsIGxhc3RfbWVzc2FnZV9hdCxcbiAgICAgICAgc3BhY2VzICggaWQsIG5hbWUsIGltYWdlcywgcHJvcGVydGllcyAoIGFyZWEgKSApLFxuICAgICAgICByZW50ZXI6cHJvZmlsZXMhY29udmVyc2F0aW9uc19yZW50ZXJfaWRfZmtleSAoIGlkLCBuYW1lLCBhdmF0YXJfdG9uZSApLFxuICAgICAgICBvd25lcjpwcm9maWxlcyFjb252ZXJzYXRpb25zX293bmVyX2lkX2ZrZXkgKCBpZCwgbmFtZSwgYXZhdGFyX3RvbmUgKSxcbiAgICAgICAgbWVzc2FnZXMgKCBpZCwgYm9keSwgc2VuZGVyX2lkLCByZWFkX2F0LCBjcmVhdGVkX2F0IClcbiAgICAgIGApXG4gICAgICAub3JkZXIoXCJsYXN0X21lc3NhZ2VfYXRcIiwgeyBhc2NlbmRpbmc6IGZhbHNlIH0pO1xuXG4gICAgaWYgKGVycm9yKSBmYWlsKFwiQ291bGQgbm90IGxvYWQgeW91ciBtZXNzYWdlc1wiLCBlcnJvcik7XG5cbiAgICByZXR1cm4gKGRhdGEgPz8gW10pLm1hcCgocm93KSA9PiB7XG4gICAgICBjb25zdCBjID0gcm93IGFzIHVua25vd24gYXMge1xuICAgICAgICBpZDogc3RyaW5nO1xuICAgICAgICBzcGFjZV9pZDogc3RyaW5nIHwgbnVsbDtcbiAgICAgICAgcmVudGVyX2lkOiBzdHJpbmc7XG4gICAgICAgIG93bmVyX2lkOiBzdHJpbmc7XG4gICAgICAgIGxhc3RfbWVzc2FnZV9hdDogc3RyaW5nO1xuICAgICAgICBzcGFjZXM6IHsgbmFtZTogc3RyaW5nOyBpbWFnZXM6IEFycmF5PHsgdXJsOiBzdHJpbmcgfT47IHByb3BlcnRpZXM6IHsgYXJlYTogc3RyaW5nIH0gfCBudWxsIH0gfCBudWxsO1xuICAgICAgICByZW50ZXI6IHsgaWQ6IHN0cmluZzsgbmFtZTogc3RyaW5nOyBhdmF0YXJfdG9uZTogc3RyaW5nIH0gfCBudWxsO1xuICAgICAgICBvd25lcjogeyBpZDogc3RyaW5nOyBuYW1lOiBzdHJpbmc7IGF2YXRhcl90b25lOiBzdHJpbmcgfSB8IG51bGw7XG4gICAgICAgIG1lc3NhZ2VzOiBBcnJheTx7IGlkOiBzdHJpbmc7IGJvZHk6IHN0cmluZzsgc2VuZGVyX2lkOiBzdHJpbmc7IHJlYWRfYXQ6IHN0cmluZyB8IG51bGw7IGNyZWF0ZWRfYXQ6IHN0cmluZyB9PjtcbiAgICAgIH07XG5cbiAgICAgIGNvbnN0IHlvdUFyZU93bmVyID0gYy5vd25lcl9pZCA9PT0gdXNlcklkO1xuICAgICAgY29uc3Qgb3RoZXIgPSB5b3VBcmVPd25lciA/IGMucmVudGVyIDogYy5vd25lcjtcbiAgICAgIGNvbnN0IG9yZGVyZWQgPSBbLi4uYy5tZXNzYWdlc10uc29ydCgoYSwgYikgPT4gYS5jcmVhdGVkX2F0LmxvY2FsZUNvbXBhcmUoYi5jcmVhdGVkX2F0KSk7XG4gICAgICBjb25zdCBsYXN0ID0gb3JkZXJlZFtvcmRlcmVkLmxlbmd0aCAtIDFdO1xuXG4gICAgICByZXR1cm4ge1xuICAgICAgICBpZDogYy5pZCxcbiAgICAgICAgc3BhY2VJZDogYy5zcGFjZV9pZCxcbiAgICAgICAgc3BhY2VOYW1lOiBjLnNwYWNlcz8ubmFtZSA/PyBcIkEgc3BhY2VcIixcbiAgICAgICAgc3BhY2VJbWFnZTogYy5zcGFjZXM/LmltYWdlcz8uWzBdPy51cmwgPz8gbnVsbCxcbiAgICAgICAgcHJvcGVydHlBcmVhOiBjLnNwYWNlcz8ucHJvcGVydGllcz8uYXJlYSA/PyBudWxsLFxuICAgICAgICBjb3VudGVycGFydElkOiBvdGhlcj8uaWQgPz8gXCJcIixcbiAgICAgICAgY291bnRlcnBhcnROYW1lOiBvdGhlcj8ubmFtZSA/PyBcIkhhYml0byB1c2VyXCIsXG4gICAgICAgIGNvdW50ZXJwYXJ0VG9uZTogb3RoZXI/LmF2YXRhcl90b25lID8/IFwiYXF1YVwiLFxuICAgICAgICB5b3VBcmVPd25lcixcbiAgICAgICAgbGFzdE1lc3NhZ2U6IGxhc3Q/LmJvZHkgPz8gXCJcIixcbiAgICAgICAgbGFzdE1lc3NhZ2VBdDogbGFzdD8uY3JlYXRlZF9hdCA/PyBjLmxhc3RfbWVzc2FnZV9hdCxcbiAgICAgICAgdW5yZWFkOiBvcmRlcmVkLmZpbHRlcigobSkgPT4gbS5zZW5kZXJfaWQgIT09IHVzZXJJZCAmJiAhbS5yZWFkX2F0KS5sZW5ndGgsXG4gICAgICB9O1xuICAgIH0pO1xuICB9LFxuXG4gIGFzeW5jIG1lc3NhZ2VzKGNvbnZlcnNhdGlvbklkOiBzdHJpbmcpOiBQcm9taXNlPE1lc3NhZ2VbXT4ge1xuICAgIGNvbnN0IHVzZXJJZCA9IGF3YWl0IGN1cnJlbnRVc2VySWQoKTtcblxuICAgIGNvbnN0IHsgZGF0YSwgZXJyb3IgfSA9IGF3YWl0IGNsaWVudCgpXG4gICAgICAuZnJvbShcIm1lc3NhZ2VzXCIpXG4gICAgICAuc2VsZWN0KFwiKlwiKVxuICAgICAgLmVxKFwiY29udmVyc2F0aW9uX2lkXCIsIGNvbnZlcnNhdGlvbklkKVxuICAgICAgLm9yZGVyKFwiY3JlYXRlZF9hdFwiLCB7IGFzY2VuZGluZzogdHJ1ZSB9KTtcblxuICAgIGlmIChlcnJvcikgZmFpbChcIkNvdWxkIG5vdCBsb2FkIHRoZSBjb252ZXJzYXRpb25cIiwgZXJyb3IpO1xuXG4gICAgcmV0dXJuIChkYXRhID8/IFtdKS5tYXAoKHJvdykgPT4ge1xuICAgICAgY29uc3QgbSA9IHJvdyBhcyB7IGlkOiBzdHJpbmc7IHNlbmRlcl9pZDogc3RyaW5nOyBib2R5OiBzdHJpbmc7IGNyZWF0ZWRfYXQ6IHN0cmluZzsgcmVhZF9hdDogc3RyaW5nIHwgbnVsbCB9O1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgaWQ6IG0uaWQsXG4gICAgICAgIGNvbnZlcnNhdGlvbklkLFxuICAgICAgICBzZW5kZXJJZDogbS5zZW5kZXJfaWQsXG4gICAgICAgIGJvZHk6IG0uYm9keSxcbiAgICAgICAgc2VudEF0OiBtLmNyZWF0ZWRfYXQsXG4gICAgICAgIHJlYWRBdDogbS5yZWFkX2F0LFxuICAgICAgICBtaW5lOiBtLnNlbmRlcl9pZCA9PT0gdXNlcklkLFxuICAgICAgfTtcbiAgICB9KTtcbiAgfSxcblxuICBhc3luYyBzZW5kTWVzc2FnZShjb252ZXJzYXRpb25JZDogc3RyaW5nLCBib2R5OiBzdHJpbmcpOiBQcm9taXNlPE1lc3NhZ2U+IHtcbiAgICBjb25zdCB1c2VySWQgPSBhd2FpdCByZXF1aXJlVXNlcihcInNlbmQgYSBtZXNzYWdlXCIpO1xuXG4gICAgY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgY2xpZW50KClcbiAgICAgIC5mcm9tKFwibWVzc2FnZXNcIilcbiAgICAgIC5pbnNlcnQoeyBjb252ZXJzYXRpb25faWQ6IGNvbnZlcnNhdGlvbklkLCBzZW5kZXJfaWQ6IHVzZXJJZCwgYm9keSB9KVxuICAgICAgLnNlbGVjdCgpXG4gICAgICAuc2luZ2xlKCk7XG5cbiAgICBpZiAoZXJyb3IpIGZhaWwoXCJDb3VsZCBub3Qgc2VuZCB5b3VyIG1lc3NhZ2VcIiwgZXJyb3IpO1xuXG4gICAgLy8gS2VlcHMgdGhlIGNvbnZlcnNhdGlvbiBsaXN0IG9yZGVyZWQgYnkgcmVjZW5jeS5cbiAgICBhd2FpdCBjbGllbnQoKVxuICAgICAgLmZyb20oXCJjb252ZXJzYXRpb25zXCIpXG4gICAgICAudXBkYXRlKHsgbGFzdF9tZXNzYWdlX2F0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkgfSlcbiAgICAgIC5lcShcImlkXCIsIGNvbnZlcnNhdGlvbklkKTtcblxuICAgIGNvbnN0IG0gPSBkYXRhIGFzIHsgaWQ6IHN0cmluZzsgY3JlYXRlZF9hdDogc3RyaW5nIH07XG4gICAgcmV0dXJuIHsgaWQ6IG0uaWQsIGNvbnZlcnNhdGlvbklkLCBzZW5kZXJJZDogdXNlcklkLCBib2R5LCBzZW50QXQ6IG0uY3JlYXRlZF9hdCwgcmVhZEF0OiBudWxsLCBtaW5lOiB0cnVlIH07XG4gIH0sXG5cbiAgYXN5bmMgbWFya1JlYWQoY29udmVyc2F0aW9uSWQ6IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuICAgIGNvbnN0IHVzZXJJZCA9IGF3YWl0IGN1cnJlbnRVc2VySWQoKTtcbiAgICBpZiAoIXVzZXJJZCkgcmV0dXJuO1xuXG4gICAgYXdhaXQgY2xpZW50KClcbiAgICAgIC5mcm9tKFwibWVzc2FnZXNcIilcbiAgICAgIC51cGRhdGUoeyByZWFkX2F0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkgfSlcbiAgICAgIC5lcShcImNvbnZlcnNhdGlvbl9pZFwiLCBjb252ZXJzYXRpb25JZClcbiAgICAgIC5uZXEoXCJzZW5kZXJfaWRcIiwgdXNlcklkKVxuICAgICAgLmlzKFwicmVhZF9hdFwiLCBudWxsKTtcbiAgfSxcblxuICBhc3luYyBvcGVuQ29udmVyc2F0aW9uKHNwYWNlSWQ6IHN0cmluZyk6IFByb21pc2U8c3RyaW5nPiB7XG4gICAgY29uc3QgdXNlcklkID0gYXdhaXQgcmVxdWlyZVVzZXIoXCJzdGFydCBhIGNvbnZlcnNhdGlvblwiKTtcblxuICAgIGNvbnN0IHsgZGF0YTogc3BhY2UsIGVycm9yOiBzcGFjZUVycm9yIH0gPSBhd2FpdCBjbGllbnQoKVxuICAgICAgLmZyb20oXCJzcGFjZXNcIilcbiAgICAgIC5zZWxlY3QoXCJpZCwgcHJvcGVydGllcyFpbm5lcihvd25lcl9pZClcIilcbiAgICAgIC5lcShcImlkXCIsIHNwYWNlSWQpXG4gICAgICAuc2luZ2xlKCk7XG5cbiAgICBpZiAoc3BhY2VFcnJvcikgZmFpbChcIkNvdWxkIG5vdCBmaW5kIHRoYXQgc3BhY2VcIiwgc3BhY2VFcnJvcik7XG4gICAgY29uc3Qgb3duZXJJZCA9IChzcGFjZSBhcyB1bmtub3duIGFzIHsgcHJvcGVydGllczogeyBvd25lcl9pZDogc3RyaW5nIH0gfSkucHJvcGVydGllcy5vd25lcl9pZDtcblxuICAgIGlmIChvd25lcklkID09PSB1c2VySWQpIHRocm93IG5ldyBFcnJvcihcIlRoYXQncyB5b3VyIG93biBsaXN0aW5nLlwiKTtcblxuICAgIGNvbnN0IHsgZGF0YSwgZXJyb3IgfSA9IGF3YWl0IGNsaWVudCgpXG4gICAgICAuZnJvbShcImNvbnZlcnNhdGlvbnNcIilcbiAgICAgIC51cHNlcnQoXG4gICAgICAgIHsgc3BhY2VfaWQ6IHNwYWNlSWQsIHJlbnRlcl9pZDogdXNlcklkLCBvd25lcl9pZDogb3duZXJJZCwgbGFzdF9tZXNzYWdlX2F0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkgfSxcbiAgICAgICAgeyBvbkNvbmZsaWN0OiBcInNwYWNlX2lkLHJlbnRlcl9pZCxvd25lcl9pZFwiIH0sXG4gICAgICApXG4gICAgICAuc2VsZWN0KFwiaWRcIilcbiAgICAgIC5zaW5nbGUoKTtcblxuICAgIGlmIChlcnJvcikgZmFpbChcIkNvdWxkIG5vdCBvcGVuIHRoZSBjb252ZXJzYXRpb25cIiwgZXJyb3IpO1xuICAgIHJldHVybiAoZGF0YSBhcyB7IGlkOiBzdHJpbmcgfSkuaWQ7XG4gIH0sXG5cbiAgc3Vic2NyaWJlVG9NZXNzYWdlcyhvbkNoYW5nZTogKCkgPT4gdm9pZCk6ICgpID0+IHZvaWQge1xuICAgIC8vIFNldmVyYWwgcGFydHMgb2YgdGhlIGFwcCBzdWJzY3JpYmUgYXQgb25jZSDigJQgdGhlIHVucmVhZCBiYWRnZSwgdGhlXG4gICAgLy8gY29udmVyc2F0aW9uIGxpc3QsIHRoZSBvcGVuIHRocmVhZC4gQXNraW5nIGZvciB0aGUgc2FtZSBjaGFubmVsIG5hbWVcbiAgICAvLyB0d2ljZSByZXR1cm5zIHRoZSBhbHJlYWR5LXN1YnNjcmliZWQgaW5zdGFuY2UsIHdoaWNoIHRoZW4gcmVmdXNlcyBuZXdcbiAgICAvLyBjYWxsYmFja3MsIHNvIGV2ZXJ5IHN1YnNjcmliZXIgZ2V0cyBpdHMgb3duIGNoYW5uZWwuXG4gICAgY29uc3QgbmFtZSA9IGBoYWJpdG8tbWVzc2FnZXMtJHsrK2NoYW5uZWxTZXF9YDtcblxuICAgIC8vIEEgcG9sbCBrZWVwcyBtZXNzYWdlcyBhcnJpdmluZyBldmVuIGlmIHJlYWx0aW1lIGlzbid0IGVuYWJsZWQgb24gdGhlXG4gICAgLy8gdGFibGVzIG9yIHRoZSBzb2NrZXQgZHJvcHMuIFNldCB1cCBmaXJzdCBzbyBpdCBzdXJ2aXZlcyBhIGxpdmUgZmFpbHVyZS5cbiAgICBjb25zdCBwb2xsID0gd2luZG93LnNldEludGVydmFsKG9uQ2hhbmdlLCAyMDAwMCk7XG5cbiAgICBsZXQgY2hhbm5lbDogUmVhbHRpbWVDaGFubmVsIHwgbnVsbCA9IG51bGw7XG4gICAgdHJ5IHtcbiAgICAgIGNoYW5uZWwgPSBjbGllbnQoKVxuICAgICAgICAuY2hhbm5lbChuYW1lKVxuICAgICAgICAub24oXCJwb3N0Z3Jlc19jaGFuZ2VzXCIsIHsgZXZlbnQ6IFwiKlwiLCBzY2hlbWE6IFwicHVibGljXCIsIHRhYmxlOiBcIm1lc3NhZ2VzXCIgfSwgKCkgPT4gb25DaGFuZ2UoKSlcbiAgICAgICAgLm9uKFwicG9zdGdyZXNfY2hhbmdlc1wiLCB7IGV2ZW50OiBcIipcIiwgc2NoZW1hOiBcInB1YmxpY1wiLCB0YWJsZTogXCJjb252ZXJzYXRpb25zXCIgfSwgKCkgPT4gb25DaGFuZ2UoKSlcbiAgICAgICAgLnN1YnNjcmliZSgpO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAvLyBMaXZlIHVwZGF0ZXMgYXJlIGEgY29udmVuaWVuY2UsIG5ldmVyIGEgcmVxdWlyZW1lbnQuIEZhbGxpbmcgYmFjayB0b1xuICAgICAgLy8gdGhlIHBvbGwgaXMgZmFyIGJldHRlciB0aGFuIHRha2luZyB0aGUgcGFnZSBkb3duLlxuICAgICAgY29uc29sZS53YXJuKFwiSGFiaXRvOiBsaXZlIHVwZGF0ZXMgdW5hdmFpbGFibGUsIHBvbGxpbmcgaW5zdGVhZC5cIiwgZXJyb3IpO1xuICAgIH1cblxuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICB3aW5kb3cuY2xlYXJJbnRlcnZhbChwb2xsKTtcbiAgICAgIGlmIChjaGFubmVsKSB2b2lkIGNsaWVudCgpLnJlbW92ZUNoYW5uZWwoY2hhbm5lbCk7XG4gICAgfTtcbiAgfSxcblxuXG4gIC8qIOKUgOKUgCBNYWludGVuYW5jZSDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIAgKi9cblxuICBhc3luYyByZXNldCgpOiBQcm9taXNlPHZvaWQ+IHtcbiAgICAvLyBOb3RoaW5nIHRvIHJlc2V0IGFnYWluc3QgYSBzaGFyZWQgZGF0YWJhc2UuIFNlZWQgZGF0YSBpcyByZXN0b3JlZCBieVxuICAgIC8vIHJlcGxheWluZyBzdXBhYmFzZS9zZWVkLnNxbCwgd2hpY2ggaXMgYSBkZWxpYmVyYXRlIGFkbWluIGFjdGlvbi5cbiAgICB0aHJvdyBuZXcgRXJyb3IoXCJSZXNldHRpbmcgaXNuJ3QgYXZhaWxhYmxlIHdoZW4gSGFiaXRvIGlzIGNvbm5lY3RlZCB0byB0aGUgZGF0YWJhc2UuXCIpO1xuICB9LFxufTtcbiJdLCJtYXBwaW5ncyI6IkFBQ0EsU0FBUyxRQUFRLFNBQVMsWUFBWSxTQUFTLGdCQUFnQixhQUFhLGtCQUFrQjtBQTZCOUYsSUFBSSxhQUFhO0FBRWpCLE1BQU0sZ0JBQWdCO0FBQ3RCLE1BQU0sbUJBQW1CO0FBRXpCLFNBQVMsS0FBSyxTQUFpQixPQUEwQztBQUN2RSxRQUFNLElBQUksTUFBTSxHQUFHLE9BQU8sS0FBSyxPQUFPLFdBQVcsZUFBZSxFQUFFO0FBQ3BFO0FBRUEsZUFBZSxnQkFBd0M7QUFDckQsUUFBTSxFQUFFLEtBQUssSUFBSSxNQUFNLE9BQU8sRUFBRSxLQUFLLFFBQVE7QUFDN0MsU0FBTyxLQUFLLE1BQU0sTUFBTTtBQUMxQjtBQUdBLGVBQWUsWUFBWSxRQUFpQztBQUMxRCxRQUFNLEtBQUssTUFBTSxjQUFjO0FBQy9CLE1BQUksQ0FBQyxHQUFJLE9BQU0sSUFBSSxNQUFNLCtCQUErQixNQUFNLEdBQUc7QUFDakUsU0FBTztBQUNUO0FBR0EsZUFBZSxhQUFhLFFBQXdEO0FBQ2xGLE1BQUksUUFBUSxPQUFPLEVBQ2hCLEtBQUssUUFBUSxFQUNiO0FBQUE7QUFBQTtBQUFBLElBR0MsR0FBRyxhQUFhLHNCQUFzQixnQkFBZ0I7QUFBQSxFQUN4RCxFQUNDLEdBQUcsVUFBVSxXQUFXO0FBRTNCLE1BQUksUUFBUSxRQUFTLFNBQVEsTUFBTSxHQUFHLE1BQU0sT0FBTyxPQUFPO0FBRTFELFFBQU0sRUFBRSxNQUFNLE1BQU0sSUFBSSxNQUFNO0FBQzlCLE1BQUksTUFBTyxNQUFLLDJCQUEyQixLQUFLO0FBRWhELFVBQVEsUUFBUSxDQUFDLEdBQUcsSUFBSSxDQUFDLFFBQVE7QUFDL0IsVUFBTSxFQUFFLFlBQVksR0FBRyxTQUFTLElBQUk7QUFHcEMsVUFBTSxFQUFFLFVBQVUsR0FBRyxZQUFZLElBQUk7QUFDckMsV0FBTztBQUFBLE1BQ0wsT0FBTyxRQUFRLFFBQW9CO0FBQUEsTUFDbkMsVUFBVSxXQUFXLFdBQTBCO0FBQUEsTUFDL0MsT0FBTyxRQUFRLFFBQVE7QUFBQSxJQUN6QjtBQUFBLEVBQ0YsQ0FBQztBQUNIO0FBRU8sYUFBTSxxQkFBaUM7QUFBQSxFQUM1QyxNQUFNO0FBQUE7QUFBQSxFQUlOLE1BQU0sV0FBb0M7QUFDeEMsV0FBTyxhQUFhO0FBQUEsRUFDdEI7QUFBQSxFQUVBLE1BQU0sUUFBUSxTQUErQztBQUMzRCxVQUFNLENBQUMsS0FBSyxJQUFJLE1BQU0sYUFBYSxFQUFFLFFBQVEsQ0FBQztBQUM5QyxXQUFPLFNBQVM7QUFBQSxFQUNsQjtBQUFBLEVBRUEsTUFBTSxXQUFXLFNBQXVDO0FBQ3RELFFBQUksUUFBUSxPQUFPLEVBQUUsS0FBSyxZQUFZLEVBQUUsT0FBTyxnQkFBZ0IsRUFBRSxNQUFNLGNBQWMsRUFBRSxXQUFXLE1BQU0sQ0FBQztBQUN6RyxRQUFJLFFBQVMsU0FBUSxNQUFNLEdBQUcsWUFBWSxPQUFPO0FBRWpELFVBQU0sRUFBRSxNQUFNLE1BQU0sSUFBSSxNQUFNO0FBQzlCLFFBQUksTUFBTyxNQUFLLDZCQUE2QixLQUFLO0FBQ2xELFdBQVEsS0FBdUIsSUFBSSxVQUFVO0FBQUEsRUFDL0M7QUFBQSxFQUVBLE1BQU0saUJBQWlCLFlBQXNDO0FBRzNELFVBQU0sRUFBRSxNQUFNLE1BQU0sSUFBSSxNQUFNLE9BQU8sRUFDbEMsS0FBSyxRQUFRLEVBQ2IsT0FBTyxhQUFhLEVBQ3BCLEdBQUcsZUFBZSxVQUFVLEVBQzVCLE1BQU0sY0FBYyxFQUFFLFdBQVcsS0FBSyxDQUFDO0FBRTFDLFFBQUksTUFBTyxNQUFLLHlCQUF5QixLQUFLO0FBQzlDLFdBQVEsS0FBb0IsSUFBSSxPQUFPO0FBQUEsRUFDekM7QUFBQSxFQUVBLE1BQU0sTUFBTSxTQUF3QztBQUNsRCxVQUFNLEVBQUUsTUFBTSxNQUFNLElBQUksTUFBTSxPQUFPLEVBQ2xDLEtBQUssUUFBUSxFQUNiLE9BQU8sYUFBYSxFQUNwQixHQUFHLE1BQU0sT0FBTyxFQUNoQixZQUFZO0FBRWYsUUFBSSxNQUFPLE1BQUssNkJBQTZCLEtBQUs7QUFDbEQsV0FBTyxPQUFPLFFBQVEsSUFBZ0IsSUFBSTtBQUFBLEVBQzVDO0FBQUEsRUFFQSxNQUFNLE1BQU0sU0FBd0M7QUFDbEQsVUFBTSxFQUFFLE1BQU0sTUFBTSxJQUFJLE1BQU0sT0FBTyxFQUFFLEtBQUssVUFBVSxFQUFFLE9BQU8sR0FBRyxFQUFFLEdBQUcsTUFBTSxPQUFPLEVBQUUsWUFBWTtBQUNsRyxRQUFJLE1BQU8sTUFBSyx3QkFBd0IsS0FBSztBQUM3QyxXQUFPLE9BQU8sUUFBUSxJQUFrQixJQUFJO0FBQUEsRUFDOUM7QUFBQTtBQUFBLEVBSUEsTUFBTSxlQUFlLE9BQTBCO0FBQzdDLFVBQU0sU0FBUyxNQUFNLFlBQVksZ0JBQWdCO0FBQ2pELFVBQU0sRUFBRSxNQUFNLE1BQU0sSUFBSSxNQUFNLE9BQU8sRUFDbEMsS0FBSyxZQUFZLEVBQ2pCLE9BQU8sRUFBRSxHQUFHLGVBQWUsS0FBSyxHQUFHLFVBQVUsT0FBTyxDQUFDLEVBQ3JELE9BQU8sRUFDUCxPQUFPO0FBRVYsUUFBSSxNQUFPLE1BQUssaUNBQWlDLEtBQUs7QUFDdEQsV0FBTyxXQUFXLElBQW1CO0FBQUEsRUFDdkM7QUFBQSxFQUVBLE1BQU0sWUFBWSxPQUF1QjtBQUN2QyxVQUFNLFlBQVksYUFBYTtBQUMvQixVQUFNLEVBQUUsTUFBTSxNQUFNLElBQUksTUFBTSxPQUFPLEVBQUUsS0FBSyxRQUFRLEVBQUUsT0FBTyxZQUFZLEtBQUssQ0FBQyxFQUFFLE9BQU8sRUFBRSxPQUFPO0FBQ2pHLFFBQUksTUFBTyxNQUFLLDhCQUE4QixLQUFLO0FBQ25ELFdBQU8sUUFBUSxJQUFnQjtBQUFBLEVBQ2pDO0FBQUEsRUFFQSxNQUFNLFlBQVksU0FBaUIsT0FBOEM7QUFDL0UsVUFBTSxZQUFZLGNBQWM7QUFDaEMsVUFBTSxFQUFFLE1BQU0sTUFBTSxJQUFJLE1BQU0sT0FBTyxFQUNsQyxLQUFLLFFBQVEsRUFDYixPQUFPLFdBQVcsS0FBSyxDQUFDLEVBQ3hCLEdBQUcsTUFBTSxPQUFPLEVBQ2hCLE9BQU8sRUFDUCxZQUFZO0FBRWYsUUFBSSxNQUFPLE1BQUssOEJBQThCLEtBQUs7QUFDbkQsV0FBTyxPQUFPLFFBQVEsSUFBZ0IsSUFBSTtBQUFBLEVBQzVDO0FBQUEsRUFFQSxNQUFNLFlBQVksU0FBZ0M7QUFDaEQsVUFBTSxZQUFZLGdCQUFnQjtBQUNsQyxVQUFNLEVBQUUsTUFBTSxJQUFJLE1BQU0sT0FBTyxFQUFFLEtBQUssUUFBUSxFQUFFLE9BQU8sRUFBRSxHQUFHLE1BQU0sT0FBTztBQUN6RSxRQUFJLE1BQU8sTUFBSyw4QkFBOEIsS0FBSztBQUFBLEVBQ3JEO0FBQUE7QUFBQSxFQUlBLE1BQU0sUUFBMkI7QUFDL0IsVUFBTSxTQUFTLE1BQU0sY0FBYztBQUNuQyxRQUFJLENBQUMsT0FBUSxRQUFPLENBQUM7QUFFckIsVUFBTSxFQUFFLE1BQU0sTUFBTSxJQUFJLE1BQU0sT0FBTyxFQUFFLEtBQUssV0FBVyxFQUFFLE9BQU8sVUFBVSxFQUFFLEdBQUcsV0FBVyxNQUFNO0FBQ2hHLFFBQUksTUFBTyxNQUFLLCtCQUErQixLQUFLO0FBQ3BELFlBQVEsUUFBUSxDQUFDLEdBQUcsSUFBSSxDQUFDLE1BQU8sRUFBMkIsUUFBUTtBQUFBLEVBQ3JFO0FBQUEsRUFFQSxNQUFNLFlBQVksU0FBbUM7QUFDbkQsVUFBTSxTQUFTLE1BQU0sWUFBWSxjQUFjO0FBRS9DLFVBQU0sRUFBRSxNQUFNLFNBQVMsSUFBSSxNQUFNLE9BQU8sRUFDckMsS0FBSyxXQUFXLEVBQ2hCLE9BQU8sVUFBVSxFQUNqQixHQUFHLFdBQVcsTUFBTSxFQUNwQixHQUFHLFlBQVksT0FBTyxFQUN0QixZQUFZO0FBRWYsUUFBSSxVQUFVO0FBQ1osWUFBTSxFQUFFLE9BQUFBLE9BQU0sSUFBSSxNQUFNLE9BQU8sRUFDNUIsS0FBSyxXQUFXLEVBQ2hCLE9BQU8sRUFDUCxHQUFHLFdBQVcsTUFBTSxFQUNwQixHQUFHLFlBQVksT0FBTztBQUN6QixVQUFJQSxPQUFPLE1BQUssK0JBQStCQSxNQUFLO0FBQ3BELGFBQU87QUFBQSxJQUNUO0FBRUEsVUFBTSxFQUFFLE1BQU0sSUFBSSxNQUFNLE9BQU8sRUFBRSxLQUFLLFdBQVcsRUFBRSxPQUFPLEVBQUUsU0FBUyxRQUFRLFVBQVUsUUFBUSxDQUFDO0FBQ2hHLFFBQUksTUFBTyxNQUFLLDZCQUE2QixLQUFLO0FBQ2xELFdBQU87QUFBQSxFQUNUO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFNQSxNQUFNLFlBQWdDO0FBQ3BDLFVBQU0sU0FBUyxNQUFNLGNBQWM7QUFDbkMsUUFBSSxDQUFDLE9BQVEsUUFBTyxDQUFDO0FBRXJCLFVBQU0sRUFBRSxNQUFNLE1BQU0sSUFBSSxNQUFNLE9BQU8sRUFDbEMsS0FBSyxlQUFlLEVBQ3BCLE9BQU8sNkhBQTZILEVBQ3BJLE1BQU0sbUJBQW1CLEVBQUUsV0FBVyxNQUFNLENBQUM7QUFFaEQsUUFBSSxNQUFPLE1BQUssNEJBQTRCLEtBQUs7QUFFakQsWUFBUSxRQUFRLENBQUMsR0FBRyxRQUFRLENBQUMsUUFBUTtBQUNuQyxZQUFNLE9BQU87QUFRYixZQUFNLFFBQVEsQ0FBQyxHQUFHLEtBQUssUUFBUSxFQUFFLEtBQUssQ0FBQyxHQUFHLE1BQU0sRUFBRSxXQUFXLGNBQWMsRUFBRSxVQUFVLENBQUMsRUFBRSxDQUFDO0FBQzNGLFVBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxTQUFVLFFBQU8sQ0FBQztBQUl0QyxZQUFNLFVBQVUsTUFBTSxRQUFRLEtBQUssUUFBUSxJQUFJLEtBQUssU0FBUyxDQUFDLElBQUksS0FBSztBQUV2RSxhQUFPLENBQUM7QUFBQSxRQUNOLElBQUksS0FBSztBQUFBLFFBQ1QsU0FBUyxLQUFLO0FBQUEsUUFDZCxNQUFNLFNBQVMsUUFBUTtBQUFBLFFBQ3ZCLFNBQVMsTUFBTTtBQUFBLFFBQ2YsWUFBWSxLQUFLLFdBQVcsTUFBTSxHQUFHLEVBQUU7QUFBQSxRQUN2QyxXQUFXO0FBQUEsUUFDWCxXQUFXO0FBQUEsUUFDWCxRQUFRLE1BQU07QUFBQSxRQUNkLFFBQVE7QUFBQSxNQUNWLENBQUM7QUFBQSxJQUNILENBQUM7QUFBQSxFQUNIO0FBQUEsRUFFQSxNQUFNLGNBQWMsT0FBeUI7QUFDM0MsVUFBTSxTQUFTLE1BQU0sWUFBWSxpQkFBaUI7QUFFbEQsVUFBTSxFQUFFLE1BQU0sT0FBTyxPQUFPLFdBQVcsSUFBSSxNQUFNLE9BQU8sRUFDckQsS0FBSyxRQUFRLEVBQ2IsT0FBTyxnQ0FBZ0MsRUFDdkMsR0FBRyxNQUFNLE1BQU0sT0FBTyxFQUN0QixPQUFPO0FBRVYsUUFBSSxXQUFZLE1BQUssNkJBQTZCLFVBQVU7QUFDNUQsVUFBTSxVQUFXLE1BQTBELFdBQVc7QUFHdEYsVUFBTSxFQUFFLE1BQU0sY0FBYyxPQUFPLFVBQVUsSUFBSSxNQUFNLE9BQU8sRUFDM0QsS0FBSyxlQUFlLEVBQ3BCO0FBQUEsTUFDQyxFQUFFLFVBQVUsTUFBTSxTQUFTLFdBQVcsUUFBUSxVQUFVLFNBQVMsa0JBQWlCLG9CQUFJLEtBQUssR0FBRSxZQUFZLEVBQUU7QUFBQSxNQUMzRyxFQUFFLFlBQVksOEJBQThCO0FBQUEsSUFDOUMsRUFDQyxPQUFPLEVBQ1AsT0FBTztBQUVWLFFBQUksVUFBVyxNQUFLLG9DQUFvQyxTQUFTO0FBRWpFLFVBQU0sRUFBRSxNQUFNLFNBQVMsT0FBTyxTQUFTLElBQUksTUFBTSxPQUFPLEVBQ3JELEtBQUssVUFBVSxFQUNmLE9BQU8sRUFBRSxpQkFBa0IsYUFBZ0MsSUFBSSxXQUFXLFFBQVEsTUFBTSxNQUFNLFFBQVEsQ0FBQyxFQUN2RyxPQUFPLEVBQ1AsT0FBTztBQUVWLFFBQUksU0FBVSxNQUFLLDhCQUE4QixRQUFRO0FBRXpELFVBQU0sT0FBTyxFQUFFLEtBQUssZUFBZSxFQUFFLE9BQU87QUFBQSxNQUMxQyxTQUFTO0FBQUEsTUFDVCxNQUFNO0FBQUEsTUFDTixPQUFPO0FBQUEsTUFDUCxNQUFNLE1BQU0sUUFBUSxNQUFNLEdBQUcsR0FBRztBQUFBLE1BQ2hDLGFBQWE7QUFBQSxNQUNiLFdBQVcsTUFBTTtBQUFBLElBQ25CLENBQUM7QUFFRCxXQUFPO0FBQUEsTUFDTCxHQUFHO0FBQUEsTUFDSCxJQUFLLFFBQTJCO0FBQUEsTUFDaEMsUUFBUyxRQUFtQztBQUFBLE1BQzVDLFFBQVE7QUFBQSxJQUNWO0FBQUEsRUFDRjtBQUFBLEVBRUEsTUFBTSxpQkFBaUIsV0FBbUIsU0FBdUM7QUFHL0UsVUFBTSxTQUFTLE1BQU0sY0FBYztBQUNuQyxRQUFJLENBQUMsT0FBUTtBQUViLFVBQU0sT0FBTyxFQUNWLEtBQUssVUFBVSxFQUNmLE9BQU8sRUFBRSxVQUFTLG9CQUFJLEtBQUssR0FBRSxZQUFZLEVBQUUsQ0FBQyxFQUM1QyxHQUFHLG1CQUFtQixTQUFTLEVBQy9CLElBQUksYUFBYSxNQUFNLEVBQ3ZCLEdBQUcsV0FBVyxJQUFJO0FBQUEsRUFDdkI7QUFBQTtBQUFBLEVBSUEsTUFBTSxXQUFvQztBQUN4QyxVQUFNLEVBQUUsTUFBTSxNQUFNLElBQUksTUFBTSxPQUFPLEVBQ2xDLEtBQUssZ0JBQWdCLEVBQ3JCLE9BQU8sR0FBRyxFQUNWLEdBQUcsUUFBUSxJQUFJLEVBQ2YsTUFBTSxjQUFjLEVBQUUsV0FBVyxNQUFNLENBQUM7QUFFM0MsUUFBSSxNQUFPLE1BQUssMkJBQTJCLEtBQUs7QUFFaEQsWUFBUSxRQUFRLENBQUMsR0FBRyxJQUFJLENBQUMsUUFBUTtBQUMvQixZQUFNLElBQUk7QUFDVixhQUFPO0FBQUEsUUFDTCxJQUFJLEVBQUU7QUFBQSxRQUNOLFVBQVUsRUFBRTtBQUFBLFFBQ1osV0FBVyxFQUFFO0FBQUEsUUFDYixhQUFhLEVBQUU7QUFBQSxRQUNmLE1BQU0sRUFBRTtBQUFBLFFBQ1IsV0FBVyxPQUFPLEVBQUUsVUFBVTtBQUFBLFFBQzlCLFdBQVcsT0FBTyxFQUFFLFVBQVU7QUFBQSxRQUM5QixVQUFVLEVBQUU7QUFBQSxRQUNaLE1BQU0sRUFBRSxRQUFRO0FBQUEsUUFDaEIsV0FBVyxFQUFFO0FBQUEsTUFDZjtBQUFBLElBQ0YsQ0FBQztBQUFBLEVBQ0g7QUFBQSxFQUVBLE1BQU0sY0FBYyxPQUE4QjtBQUNoRCxVQUFNLFNBQVMsTUFBTSxZQUFZLGdCQUFnQjtBQUVqRCxVQUFNLEVBQUUsTUFBTSxNQUFNLElBQUksTUFBTSxPQUFPLEVBQ2xDLEtBQUssZ0JBQWdCLEVBQ3JCLE9BQU87QUFBQSxNQUNOLFNBQVM7QUFBQSxNQUNULFVBQVUsTUFBTTtBQUFBLE1BQ2hCLFlBQVksTUFBTTtBQUFBLE1BQ2xCLGFBQWEsTUFBTTtBQUFBLE1BQ25CLE1BQU0sTUFBTTtBQUFBLE1BQ1osWUFBWSxNQUFNO0FBQUEsTUFDbEIsWUFBWSxNQUFNO0FBQUEsTUFDbEIsV0FBVyxNQUFNO0FBQUEsTUFDakIsTUFBTSxNQUFNO0FBQUEsSUFDZCxDQUFDLEVBQ0EsT0FBTyxFQUNQLE9BQU87QUFFVixRQUFJLE1BQU8sTUFBSyw4QkFBOEIsS0FBSztBQUNuRCxXQUFPLEVBQUUsR0FBRyxPQUFPLElBQUssS0FBd0IsSUFBSSxXQUFZLEtBQWdDLFdBQVc7QUFBQSxFQUM3RztBQUFBO0FBQUEsRUFJQSxNQUFNLFdBQStCO0FBQ25DLFVBQU0sU0FBUyxNQUFNLGNBQWM7QUFDbkMsUUFBSSxDQUFDLE9BQVEsUUFBTyxDQUFDO0FBR3JCLFVBQU0sRUFBRSxNQUFNLE1BQU0sSUFBSSxNQUFNLE9BQU8sRUFDbEMsS0FBSyxVQUFVLEVBQ2YsT0FBTztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsT0FLUCxFQUNBLE1BQU0sY0FBYyxFQUFFLFdBQVcsTUFBTSxDQUFDO0FBRTNDLFFBQUksTUFBTyxNQUFLLGdDQUFnQyxLQUFLO0FBRXJELFlBQVEsUUFBUSxDQUFDLEdBQUcsSUFBSSxDQUFDLFFBQVE7QUFDL0IsWUFBTSxJQUFJO0FBV1YsYUFBTztBQUFBLFFBQ0wsSUFBSSxFQUFFO0FBQUEsUUFDTixTQUFTLEVBQUU7QUFBQSxRQUNYLFdBQVcsRUFBRSxRQUFRLFFBQVE7QUFBQSxRQUM3QixZQUFZLEVBQUUsUUFBUSxTQUFTLENBQUMsR0FBRyxPQUFPO0FBQUEsUUFDMUMsTUFBTSxFQUFFLFFBQVEsWUFBWSxRQUFRO0FBQUEsUUFDcEMsVUFBVSxFQUFFO0FBQUEsUUFDWixZQUFZLEVBQUUsUUFBUSxRQUFRO0FBQUEsUUFDOUIsU0FBUyxFQUFFO0FBQUEsUUFDWCxXQUFXLEVBQUUsT0FBTyxRQUFRO0FBQUEsUUFDNUIsUUFBUSxFQUFFO0FBQUEsUUFDVixZQUFZLEVBQUU7QUFBQSxRQUNkLFFBQVEsRUFBRTtBQUFBLFFBQ1YsUUFBUSxFQUFFO0FBQUEsUUFDVixTQUFTLEVBQUU7QUFBQSxRQUNYLGFBQWEsRUFBRTtBQUFBLFFBQ2YsYUFBYSxFQUFFO0FBQUEsUUFDZixZQUFZLEVBQUU7QUFBQSxRQUNkLGVBQWUsRUFBRTtBQUFBLFFBQ2pCLFdBQVcsRUFBRTtBQUFBLFFBQ2IsV0FBVyxFQUFFO0FBQUEsUUFDYixhQUFhLEVBQUUsYUFBYTtBQUFBLE1BQzlCO0FBQUEsSUFDRixDQUFDO0FBQUEsRUFDSDtBQUFBLEVBRUEsTUFBTSxlQUFlLE9BQXlCO0FBQzVDLFVBQU0sU0FBUyxNQUFNLFlBQVksbUJBQW1CO0FBSXBELFVBQU0sRUFBRSxNQUFNLE1BQU0sSUFBSSxNQUFNLE9BQU8sRUFDbEMsS0FBSyxVQUFVLEVBQ2YsT0FBTztBQUFBLE1BQ04sVUFBVSxNQUFNO0FBQUEsTUFDaEIsV0FBVztBQUFBLE1BQ1gsVUFBVTtBQUFBLE1BQ1YsY0FBYyxNQUFNO0FBQUEsTUFDcEIsUUFBUSxNQUFNO0FBQUEsTUFDZCxRQUFRLE1BQU07QUFBQSxNQUNkLFNBQVMsTUFBTSxXQUFXO0FBQUEsSUFDNUIsQ0FBQyxFQUNBLE9BQU8sRUFDUCxPQUFPO0FBRVYsUUFBSSxNQUFPLE1BQUssa0NBQWtDLEtBQUs7QUFFdkQsVUFBTSxNQUFNO0FBQ1osV0FBTztBQUFBLE1BQ0wsSUFBSSxJQUFJO0FBQUEsTUFDUixTQUFTLE1BQU07QUFBQSxNQUNmLFdBQVc7QUFBQSxNQUNYLFlBQVk7QUFBQSxNQUNaLE1BQU07QUFBQSxNQUNOLFVBQVU7QUFBQSxNQUNWLFlBQVk7QUFBQSxNQUNaLFNBQVM7QUFBQSxNQUNULFdBQVc7QUFBQSxNQUNYLFFBQVEsSUFBSTtBQUFBLE1BQ1osWUFBWSxNQUFNO0FBQUEsTUFDbEIsUUFBUSxNQUFNO0FBQUEsTUFDZCxRQUFRLE1BQU07QUFBQSxNQUNkLFNBQVMsTUFBTSxXQUFXO0FBQUEsTUFDMUIsYUFBYTtBQUFBLE1BQ2IsYUFBYTtBQUFBLE1BQ2IsWUFBWTtBQUFBLE1BQ1osZUFBZTtBQUFBLE1BQ2YsV0FBVyxJQUFJO0FBQUEsTUFDZixXQUFXO0FBQUEsTUFDWCxhQUFhO0FBQUEsSUFDZjtBQUFBLEVBQ0Y7QUFBQSxFQUVBLE1BQU0saUJBQWlCLFdBQW1CLFFBQXVCLFFBQWdDO0FBQy9GLFVBQU0sWUFBWSxrQkFBa0I7QUFFcEMsVUFBTSxRQUFpQyxFQUFFLE9BQU87QUFDaEQsUUFBSSxXQUFXLE9BQVcsT0FBTSxpQkFBaUI7QUFJakQsVUFBTSxFQUFFLE1BQU0sSUFBSSxNQUFNLE9BQU8sRUFBRSxLQUFLLFVBQVUsRUFBRSxPQUFPLEtBQUssRUFBRSxHQUFHLE1BQU0sU0FBUztBQUNsRixRQUFJLE1BQU8sTUFBSyxpQ0FBaUMsS0FBSztBQUFBLEVBQ3hEO0FBQUE7QUFBQSxFQUlBLE1BQU0sY0FBcUM7QUFDekMsVUFBTSxFQUFFLE1BQU0sTUFBTSxJQUFJLE1BQU0sT0FBTyxFQUNsQyxLQUFLLGNBQWMsRUFDbkIsT0FBTyxHQUFHLEVBQ1YsTUFBTSxZQUFZLEVBQUUsV0FBVyxLQUFLLENBQUMsRUFDckMsTUFBTSxjQUFjLEVBQUUsV0FBVyxLQUFLLENBQUM7QUFFMUMsUUFBSSxNQUFPLE1BQUssbUNBQW1DLEtBQUs7QUFFeEQsWUFBUSxRQUFRLENBQUMsR0FBRyxJQUFJLENBQUMsUUFBUTtBQUMvQixZQUFNLElBQUk7QUFRVixhQUFPO0FBQUEsUUFDTCxTQUFTLEVBQUU7QUFBQSxRQUNYLFdBQVcsRUFBRTtBQUFBLFFBQ2IsTUFBTSxFQUFFO0FBQUEsUUFDUixTQUFTLEVBQUU7QUFBQSxRQUNYLFdBQVcsRUFBRTtBQUFBLFFBQ2IsWUFBWSxFQUFFO0FBQUEsUUFDZCxjQUFjLEVBQUU7QUFBQSxRQUNoQixrQkFBa0IsRUFBRTtBQUFBLFFBQ3BCLFVBQVUsRUFBRTtBQUFBLFFBQ1osY0FBYyxFQUFFO0FBQUEsUUFDaEIsYUFBYSxPQUFPLEVBQUUsWUFBWTtBQUFBLFFBQ2xDLGFBQWEsT0FBTyxFQUFFLFlBQVk7QUFBQSxRQUNsQyxVQUFVLEVBQUU7QUFBQSxNQUNkO0FBQUEsSUFDRixDQUFDO0FBQUEsRUFDSDtBQUFBLEVBRUEsTUFBTSxrQkFBa0IsU0FBaUIsU0FBa0IsTUFBOEI7QUFHdkYsVUFBTSxFQUFFLE1BQU0sSUFBSSxNQUFNLE9BQU8sRUFBRSxJQUFJLDZCQUE2QjtBQUFBLE1BQ2hFLFFBQVE7QUFBQSxNQUNSO0FBQUEsTUFDQSxLQUFLLFFBQVE7QUFBQSxJQUNmLENBQUM7QUFDRCxRQUFJLE1BQU8sTUFBSyxpQ0FBaUMsS0FBSztBQUFBLEVBQ3hEO0FBQUEsRUFFQSxNQUFNLFNBQVMsV0FBbUIsTUFBaUIsTUFBNkI7QUFDOUUsVUFBTSxFQUFFLE1BQU0sSUFBSSxNQUFNLE9BQU8sRUFBRSxJQUFJLG1CQUFtQjtBQUFBLE1BQ3RELFFBQVE7QUFBQSxNQUNSO0FBQUEsTUFDQSxLQUFLO0FBQUEsSUFDUCxDQUFDO0FBQ0QsUUFBSSxNQUFPLE1BQUssa0NBQWtDLEtBQUs7QUFBQSxFQUN6RDtBQUFBLEVBRUEsTUFBTSxlQUFlLFNBQWlCLFNBQWtCLE1BQThCO0FBQ3BGLFVBQU0sRUFBRSxNQUFNLElBQUksTUFBTSxPQUFPLEVBQUUsSUFBSSx5QkFBeUI7QUFBQSxNQUM1RCxRQUFRO0FBQUEsTUFDUjtBQUFBLE1BQ0EsS0FBSyxRQUFRO0FBQUEsSUFDZixDQUFDO0FBQ0QsUUFBSSxNQUFPLE1BQUssbUNBQW1DLEtBQUs7QUFBQSxFQUMxRDtBQUFBLEVBRUEsTUFBTSxlQUFlLFNBQWlCLE1BQThCO0FBQ2xFLFVBQU0sRUFBRSxNQUFNLElBQUksTUFBTSxPQUFPLEVBQUUsSUFBSSx5QkFBeUI7QUFBQSxNQUM1RCxRQUFRO0FBQUEsTUFDUixLQUFLLFFBQVE7QUFBQSxJQUNmLENBQUM7QUFDRCxRQUFJLE1BQU8sTUFBSyw2QkFBNkIsS0FBSztBQUFBLEVBQ3BEO0FBQUE7QUFBQSxFQUlBLE1BQU0sV0FBVyxVQUFtQztBQUNsRCxVQUFNLEVBQUUsS0FBSyxJQUFJLE1BQU0sT0FBTyxFQUMzQixLQUFLLGdCQUFnQixFQUNyQixPQUFPLFFBQVEsRUFDZixHQUFHLFlBQVksUUFBUSxFQUN2QixZQUFZO0FBRWYsV0FBUSxNQUFvQyxVQUFVO0FBQUEsRUFDeEQ7QUFBQSxFQUVBLE1BQU0saUJBQWlCLFlBQWlFO0FBQ3RGLFVBQU0sQ0FBQyxFQUFFLE1BQU0sS0FBSyxHQUFHLEVBQUUsTUFBTSxLQUFLLENBQUMsSUFBSSxNQUFNLFFBQVEsSUFBSTtBQUFBLE1BQ3pELE9BQU8sRUFBRSxJQUFJLHVCQUF1QixFQUFFLFFBQVEsV0FBVyxDQUFDO0FBQUEsTUFDMUQsT0FBTyxFQUFFLElBQUkscUJBQXFCLEVBQUUsUUFBUSxXQUFXLENBQUM7QUFBQSxJQUMxRCxDQUFDO0FBRUQsV0FBTyxFQUFFLE1BQU0sT0FBTyxRQUFRLENBQUMsR0FBRyxTQUFTLFFBQVEsSUFBSSxFQUFFO0FBQUEsRUFDM0Q7QUFBQSxFQUVBLE1BQU0sY0FBYyxTQUFpQixRQUErQjtBQUNsRSxVQUFNLFNBQVMsTUFBTSxZQUFZLG1CQUFtQjtBQUVwRCxVQUFNLEVBQUUsTUFBTSxNQUFNLElBQUksTUFBTSxPQUFPLEVBQ2xDLEtBQUssVUFBVSxFQUNmLE9BQU87QUFBQSxNQUNOLFNBQVM7QUFBQSxNQUNUO0FBQUEsTUFDQSxNQUFNO0FBQUEsTUFDTixVQUFVO0FBQUEsTUFDVixTQUFTO0FBQUEsTUFDVCxRQUFRO0FBQUEsTUFDUixXQUFXO0FBQUEsSUFDYixDQUFDLEVBQ0EsT0FBTyxJQUFJLEVBQ1gsT0FBTztBQUVWLFFBQUksTUFBTyxNQUFLLGdDQUFnQyxLQUFLO0FBR3JELFVBQU0sRUFBRSxPQUFPLFlBQVksSUFBSSxNQUFNLE9BQU8sRUFDekMsS0FBSyxVQUFVLEVBQ2YsT0FBTyxFQUFFLFFBQVEsY0FBYyxXQUFXLFdBQVcsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQ25FLEdBQUcsTUFBTyxLQUF3QixFQUFFO0FBRXZDLFFBQUksWUFBYSxNQUFLLG1DQUFtQyxXQUFXO0FBQUEsRUFDdEU7QUFBQSxFQUVBLE1BQU0sZ0JBQWdCLFlBQW9CLFFBQStCO0FBQ3ZFLFVBQU0sU0FBUyxNQUFNLFlBQVksWUFBWTtBQUU3QyxVQUFNLE9BQU8sb0JBQUksS0FBSztBQUN0QixTQUFLLFlBQVksS0FBSyxZQUFZLElBQUksQ0FBQztBQUV2QyxVQUFNLEVBQUUsTUFBTSxNQUFNLElBQUksTUFBTSxPQUFPLEVBQ2xDLEtBQUssZ0JBQWdCLEVBQ3JCLE9BQU87QUFBQSxNQUNOLGFBQWE7QUFBQSxNQUNiLFVBQVU7QUFBQSxNQUNWLFNBQVMsS0FBSyxZQUFZLEVBQUUsTUFBTSxHQUFHLEVBQUU7QUFBQSxNQUN2QztBQUFBLElBQ0YsQ0FBQyxFQUNBLE9BQU8sSUFBSSxFQUNYLE9BQU87QUFFVixRQUFJLE1BQU8sTUFBSyw2QkFBNkIsS0FBSztBQUVsRCxVQUFNLEVBQUUsTUFBTSxRQUFRLElBQUksTUFBTSxPQUFPLEVBQ3BDLEtBQUssVUFBVSxFQUNmLE9BQU87QUFBQSxNQUNOLFNBQVM7QUFBQSxNQUNUO0FBQUEsTUFDQSxNQUFNO0FBQUEsTUFDTixTQUFVLEtBQXdCO0FBQUEsTUFDbEMsU0FBUztBQUFBLE1BQ1QsUUFBUTtBQUFBLE1BQ1IsV0FBVztBQUFBLElBQ2IsQ0FBQyxFQUNBLE9BQU8sSUFBSSxFQUNYLE9BQU87QUFFVixRQUFJLFNBQVM7QUFDWCxZQUFNLE9BQU8sRUFDVixLQUFLLFVBQVUsRUFDZixPQUFPLEVBQUUsUUFBUSxjQUFjLFdBQVcsV0FBVyxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFDbkUsR0FBRyxNQUFPLFFBQTJCLEVBQUU7QUFBQSxJQUM1QztBQUFBLEVBQ0Y7QUFBQTtBQUFBLEVBSUEsTUFBTSxXQUFtQztBQUN2QyxVQUFNLFNBQVMsTUFBTSxjQUFjO0FBQ25DLFFBQUksQ0FBQyxPQUFRLFFBQU8sQ0FBQztBQUdyQixVQUFNLE9BQU8sRUFBRSxJQUFJLHVCQUF1QjtBQUUxQyxVQUFNLEVBQUUsTUFBTSxNQUFNLElBQUksTUFBTSxPQUFPLEVBQ2xDLEtBQUssZUFBZSxFQUNwQixPQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE9BTVAsRUFDQSxNQUFNLFlBQVksRUFBRSxXQUFXLEtBQUssQ0FBQztBQUV4QyxRQUFJLE1BQU8sTUFBSyw0QkFBNEIsS0FBSztBQUVqRCxZQUFRLFFBQVEsQ0FBQyxHQUFHLElBQUksQ0FBQyxRQUFRO0FBQy9CLFlBQU0sSUFBSTtBQVVWLFlBQU0sY0FBYyxFQUFFLGFBQWE7QUFDbkMsYUFBTztBQUFBLFFBQ0wsSUFBSSxFQUFFO0FBQUEsUUFDTixXQUFXLEVBQUU7QUFBQSxRQUNiLFNBQVMsRUFBRTtBQUFBLFFBQ1gsV0FBVyxFQUFFLFFBQVEsUUFBUTtBQUFBLFFBQzdCLE1BQU0sRUFBRSxRQUFRLFlBQVksUUFBUTtBQUFBLFFBQ3BDLGtCQUFrQixjQUFjLEVBQUUsUUFBUSxPQUFPLEVBQUUsT0FBTyxTQUFTO0FBQUEsUUFDbkU7QUFBQSxRQUNBLGFBQWEsRUFBRTtBQUFBLFFBQ2YsV0FBVyxFQUFFO0FBQUEsUUFDYixTQUFTLEVBQUU7QUFBQSxRQUNYLFFBQVEsRUFBRTtBQUFBLFFBQ1YsUUFBUSxFQUFFO0FBQUEsUUFDVixRQUFRLEVBQUU7QUFBQSxRQUNWLFdBQVcsRUFBRTtBQUFBLFFBQ2IsV0FBVyxFQUFFLFVBQVUsYUFBYTtBQUFBLE1BQ3RDO0FBQUEsSUFDRixDQUFDO0FBQUEsRUFDSDtBQUFBLEVBRUEsTUFBTSxXQUFXLFdBQWtDO0FBQ2pELFVBQU0sU0FBUyxNQUFNLFlBQVksVUFBVTtBQUUzQyxVQUFNLEVBQUUsTUFBTSxTQUFTLE9BQU8sVUFBVSxJQUFJLE1BQU0sT0FBTyxFQUN0RCxLQUFLLGVBQWUsRUFDcEIsT0FBTyxnQ0FBZ0MsRUFDdkMsR0FBRyxNQUFNLFNBQVMsRUFDbEIsT0FBTztBQUVWLFFBQUksVUFBVyxNQUFLLCtCQUErQixTQUFTO0FBQzVELFVBQU0sTUFBTTtBQUNaLFFBQUksSUFBSSxXQUFXLE9BQVE7QUFHM0IsVUFBTSxFQUFFLE1BQU0sU0FBUyxPQUFPLFlBQVksSUFBSSxNQUFNLE9BQU8sRUFDeEQsS0FBSyxVQUFVLEVBQ2YsT0FBTztBQUFBLE1BQ04sWUFBWSxJQUFJO0FBQUEsTUFDaEIsU0FBUztBQUFBLE1BQ1QsUUFBUSxJQUFJO0FBQUEsTUFDWixZQUFZO0FBQUEsTUFDWixNQUFNO0FBQUEsTUFDTixTQUFTO0FBQUEsTUFDVCxRQUFRO0FBQUEsTUFDUixXQUFXO0FBQUEsSUFDYixDQUFDLEVBQ0EsT0FBTyxJQUFJLEVBQ1gsT0FBTztBQUVWLFFBQUksWUFBYSxNQUFLLGdDQUFnQyxXQUFXO0FBSWpFLFVBQU0sRUFBRSxPQUFPLFlBQVksSUFBSSxNQUFNLE9BQU8sRUFDekMsS0FBSyxVQUFVLEVBQ2YsT0FBTyxFQUFFLFFBQVEsY0FBYyxXQUFXLFdBQVcsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQ25FLEdBQUcsTUFBTyxRQUEyQixFQUFFO0FBRTFDLFFBQUksWUFBYSxNQUFLLG1DQUFtQyxXQUFXO0FBQUEsRUFDdEU7QUFBQSxFQUVBLE1BQU0sYUFBYSxXQUFrQztBQUNuRCxVQUFNLFlBQVksWUFBWTtBQUM5QixVQUFNLEVBQUUsTUFBTSxJQUFJLE1BQU0sT0FBTyxFQUM1QixLQUFLLGVBQWUsRUFDcEIsT0FBTyxFQUFFLFFBQVEsU0FBUyxDQUFDLEVBQzNCLEdBQUcsTUFBTSxTQUFTO0FBQ3JCLFFBQUksTUFBTyxNQUFLLDhCQUE4QixLQUFLO0FBQUEsRUFDckQ7QUFBQSxFQUVBLE1BQU0sZUFBZSxXQUFtQixTQUFTLElBQW1CO0FBQ2xFLFVBQU0sWUFBWSx3QkFBd0I7QUFDMUMsVUFBTSxFQUFFLE1BQU0sSUFBSSxNQUFNLE9BQU8sRUFBRSxJQUFJLHdCQUF3QjtBQUFBLE1BQzNELGdCQUFnQjtBQUFBLE1BQ2hCLFlBQVk7QUFBQSxJQUNkLENBQUM7QUFDRCxRQUFJLE1BQU8sTUFBSyxrQ0FBa0MsS0FBSztBQUFBLEVBQ3pEO0FBQUE7QUFBQSxFQUlBLE1BQU0sZ0JBQXlDO0FBQzdDLFVBQU0sU0FBUyxNQUFNLGNBQWM7QUFDbkMsUUFBSSxDQUFDLE9BQVEsUUFBTyxDQUFDO0FBSXJCLFVBQU0sRUFBRSxNQUFNLE1BQU0sSUFBSSxNQUFNLE9BQU8sRUFDbEMsS0FBSyxlQUFlLEVBQ3BCLE9BQU87QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsT0FNUCxFQUNBLE1BQU0sbUJBQW1CLEVBQUUsV0FBVyxNQUFNLENBQUM7QUFFaEQsUUFBSSxNQUFPLE1BQUssZ0NBQWdDLEtBQUs7QUFFckQsWUFBUSxRQUFRLENBQUMsR0FBRyxJQUFJLENBQUMsUUFBUTtBQUMvQixZQUFNLElBQUk7QUFZVixZQUFNLGNBQWMsRUFBRSxhQUFhO0FBQ25DLFlBQU0sUUFBUSxjQUFjLEVBQUUsU0FBUyxFQUFFO0FBQ3pDLFlBQU0sVUFBVSxDQUFDLEdBQUcsRUFBRSxRQUFRLEVBQUUsS0FBSyxDQUFDLEdBQUcsTUFBTSxFQUFFLFdBQVcsY0FBYyxFQUFFLFVBQVUsQ0FBQztBQUN2RixZQUFNLE9BQU8sUUFBUSxRQUFRLFNBQVMsQ0FBQztBQUV2QyxhQUFPO0FBQUEsUUFDTCxJQUFJLEVBQUU7QUFBQSxRQUNOLFNBQVMsRUFBRTtBQUFBLFFBQ1gsV0FBVyxFQUFFLFFBQVEsUUFBUTtBQUFBLFFBQzdCLFlBQVksRUFBRSxRQUFRLFNBQVMsQ0FBQyxHQUFHLE9BQU87QUFBQSxRQUMxQyxjQUFjLEVBQUUsUUFBUSxZQUFZLFFBQVE7QUFBQSxRQUM1QyxlQUFlLE9BQU8sTUFBTTtBQUFBLFFBQzVCLGlCQUFpQixPQUFPLFFBQVE7QUFBQSxRQUNoQyxpQkFBaUIsT0FBTyxlQUFlO0FBQUEsUUFDdkM7QUFBQSxRQUNBLGFBQWEsTUFBTSxRQUFRO0FBQUEsUUFDM0IsZUFBZSxNQUFNLGNBQWMsRUFBRTtBQUFBLFFBQ3JDLFFBQVEsUUFBUSxPQUFPLENBQUMsTUFBTSxFQUFFLGNBQWMsVUFBVSxDQUFDLEVBQUUsT0FBTyxFQUFFO0FBQUEsTUFDdEU7QUFBQSxJQUNGLENBQUM7QUFBQSxFQUNIO0FBQUEsRUFFQSxNQUFNLFNBQVMsZ0JBQTRDO0FBQ3pELFVBQU0sU0FBUyxNQUFNLGNBQWM7QUFFbkMsVUFBTSxFQUFFLE1BQU0sTUFBTSxJQUFJLE1BQU0sT0FBTyxFQUNsQyxLQUFLLFVBQVUsRUFDZixPQUFPLEdBQUcsRUFDVixHQUFHLG1CQUFtQixjQUFjLEVBQ3BDLE1BQU0sY0FBYyxFQUFFLFdBQVcsS0FBSyxDQUFDO0FBRTFDLFFBQUksTUFBTyxNQUFLLG1DQUFtQyxLQUFLO0FBRXhELFlBQVEsUUFBUSxDQUFDLEdBQUcsSUFBSSxDQUFDLFFBQVE7QUFDL0IsWUFBTSxJQUFJO0FBQ1YsYUFBTztBQUFBLFFBQ0wsSUFBSSxFQUFFO0FBQUEsUUFDTjtBQUFBLFFBQ0EsVUFBVSxFQUFFO0FBQUEsUUFDWixNQUFNLEVBQUU7QUFBQSxRQUNSLFFBQVEsRUFBRTtBQUFBLFFBQ1YsUUFBUSxFQUFFO0FBQUEsUUFDVixNQUFNLEVBQUUsY0FBYztBQUFBLE1BQ3hCO0FBQUEsSUFDRixDQUFDO0FBQUEsRUFDSDtBQUFBLEVBRUEsTUFBTSxZQUFZLGdCQUF3QixNQUFnQztBQUN4RSxVQUFNLFNBQVMsTUFBTSxZQUFZLGdCQUFnQjtBQUVqRCxVQUFNLEVBQUUsTUFBTSxNQUFNLElBQUksTUFBTSxPQUFPLEVBQ2xDLEtBQUssVUFBVSxFQUNmLE9BQU8sRUFBRSxpQkFBaUIsZ0JBQWdCLFdBQVcsUUFBUSxLQUFLLENBQUMsRUFDbkUsT0FBTyxFQUNQLE9BQU87QUFFVixRQUFJLE1BQU8sTUFBSywrQkFBK0IsS0FBSztBQUdwRCxVQUFNLE9BQU8sRUFDVixLQUFLLGVBQWUsRUFDcEIsT0FBTyxFQUFFLGtCQUFpQixvQkFBSSxLQUFLLEdBQUUsWUFBWSxFQUFFLENBQUMsRUFDcEQsR0FBRyxNQUFNLGNBQWM7QUFFMUIsVUFBTSxJQUFJO0FBQ1YsV0FBTyxFQUFFLElBQUksRUFBRSxJQUFJLGdCQUFnQixVQUFVLFFBQVEsTUFBTSxRQUFRLEVBQUUsWUFBWSxRQUFRLE1BQU0sTUFBTSxLQUFLO0FBQUEsRUFDNUc7QUFBQSxFQUVBLE1BQU0sU0FBUyxnQkFBdUM7QUFDcEQsVUFBTSxTQUFTLE1BQU0sY0FBYztBQUNuQyxRQUFJLENBQUMsT0FBUTtBQUViLFVBQU0sT0FBTyxFQUNWLEtBQUssVUFBVSxFQUNmLE9BQU8sRUFBRSxVQUFTLG9CQUFJLEtBQUssR0FBRSxZQUFZLEVBQUUsQ0FBQyxFQUM1QyxHQUFHLG1CQUFtQixjQUFjLEVBQ3BDLElBQUksYUFBYSxNQUFNLEVBQ3ZCLEdBQUcsV0FBVyxJQUFJO0FBQUEsRUFDdkI7QUFBQSxFQUVBLE1BQU0saUJBQWlCLFNBQWtDO0FBQ3ZELFVBQU0sU0FBUyxNQUFNLFlBQVksc0JBQXNCO0FBRXZELFVBQU0sRUFBRSxNQUFNLE9BQU8sT0FBTyxXQUFXLElBQUksTUFBTSxPQUFPLEVBQ3JELEtBQUssUUFBUSxFQUNiLE9BQU8sZ0NBQWdDLEVBQ3ZDLEdBQUcsTUFBTSxPQUFPLEVBQ2hCLE9BQU87QUFFVixRQUFJLFdBQVksTUFBSyw2QkFBNkIsVUFBVTtBQUM1RCxVQUFNLFVBQVcsTUFBMEQsV0FBVztBQUV0RixRQUFJLFlBQVksT0FBUSxPQUFNLElBQUksTUFBTSwwQkFBMEI7QUFFbEUsVUFBTSxFQUFFLE1BQU0sTUFBTSxJQUFJLE1BQU0sT0FBTyxFQUNsQyxLQUFLLGVBQWUsRUFDcEI7QUFBQSxNQUNDLEVBQUUsVUFBVSxTQUFTLFdBQVcsUUFBUSxVQUFVLFNBQVMsa0JBQWlCLG9CQUFJLEtBQUssR0FBRSxZQUFZLEVBQUU7QUFBQSxNQUNyRyxFQUFFLFlBQVksOEJBQThCO0FBQUEsSUFDOUMsRUFDQyxPQUFPLElBQUksRUFDWCxPQUFPO0FBRVYsUUFBSSxNQUFPLE1BQUssbUNBQW1DLEtBQUs7QUFDeEQsV0FBUSxLQUF3QjtBQUFBLEVBQ2xDO0FBQUEsRUFFQSxvQkFBb0IsVUFBa0M7QUFLcEQsVUFBTSxPQUFPLG1CQUFtQixFQUFFLFVBQVU7QUFJNUMsVUFBTSxPQUFPLE9BQU8sWUFBWSxVQUFVLEdBQUs7QUFFL0MsUUFBSSxVQUFrQztBQUN0QyxRQUFJO0FBQ0YsZ0JBQVUsT0FBTyxFQUNkLFFBQVEsSUFBSSxFQUNaLEdBQUcsb0JBQW9CLEVBQUUsT0FBTyxLQUFLLFFBQVEsVUFBVSxPQUFPLFdBQVcsR0FBRyxNQUFNLFNBQVMsQ0FBQyxFQUM1RixHQUFHLG9CQUFvQixFQUFFLE9BQU8sS0FBSyxRQUFRLFVBQVUsT0FBTyxnQkFBZ0IsR0FBRyxNQUFNLFNBQVMsQ0FBQyxFQUNqRyxVQUFVO0FBQUEsSUFDZixTQUFTLE9BQU87QUFHZCxjQUFRLEtBQUssc0RBQXNELEtBQUs7QUFBQSxJQUMxRTtBQUVBLFdBQU8sTUFBTTtBQUNYLGFBQU8sY0FBYyxJQUFJO0FBQ3pCLFVBQUksUUFBUyxNQUFLLE9BQU8sRUFBRSxjQUFjLE9BQU87QUFBQSxJQUNsRDtBQUFBLEVBQ0Y7QUFBQTtBQUFBLEVBS0EsTUFBTSxRQUF1QjtBQUczQixVQUFNLElBQUksTUFBTSxxRUFBcUU7QUFBQSxFQUN2RjtBQUNGOyIsIm5hbWVzIjpbImVycm9yIl19