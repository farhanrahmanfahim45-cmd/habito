import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/@fs/D:\\I2I Project - Habito\\App Folder\\habito\\src\\components\\ui\\Button.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=9ceb86a3"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("D:/I2I Project - Habito/App Folder/habito/src/components/ui/Button.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9ceb86a3"; const forwardRef = __vite__cjsImport3_react["forwardRef"];
import { cn } from "/src/lib/cn.ts";
const VARIANTS = {
  primary: "bg-ink text-ivory hover:bg-ink-soft disabled:bg-ink/30",
  secondary: "bg-surface text-ink ring-1 ring-hairline-strong hover:ring-ink disabled:text-muted",
  ghost: "bg-transparent text-ink-soft hover:bg-ivory-deep hover:text-ink",
  quiet: "bg-ivory-deep text-ink hover:bg-hairline",
  destructive: "bg-danger-600 text-white hover:brightness-110"
};
const SIZES = {
  sm: "h-9 px-3 text-sm gap-1.5",
  md: "h-11 px-4 text-[0.9375rem] gap-2",
  lg: "h-13 px-6 text-base gap-2"
};
export const Button = forwardRef(_c = function Button2({ variant = "primary", size = "md", fullWidth, className, type = "button", ...props }, ref) {
  return /* @__PURE__ */ jsxDEV(
    "button",
    {
      ref,
      type,
      className: cn(
        "press inline-flex items-center justify-center rounded-full font-semibold",
        "transition-all duration-150 active:scale-[0.98] disabled:cursor-not-allowed disabled:active:scale-100",
        VARIANTS[variant],
        SIZES[size],
        fullWidth && "w-full",
        className
      ),
      ...props
    },
    void 0,
    false,
    {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/ui/Button.tsx",
      lineNumber: 52,
      columnNumber: 5
    },
    this
  );
});
_c2 = Button;
var _c, _c2;
$RefreshReg$(_c, "Button$forwardRef");
$RefreshReg$(_c2, "Button");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/I2I Project - Habito/App Folder/habito/src/components/ui/Button.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/I2I Project - Habito/App Folder/habito/src/components/ui/Button.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0NJOzs7Ozs7Ozs7Ozs7Ozs7O0FBaENKLFNBQVNBLGtCQUFrQjtBQUUzQixTQUFTQyxVQUFVO0FBV25CLE1BQU1DLFdBQW9DO0FBQUEsRUFDeENDLFNBQVM7QUFBQSxFQUNUQyxXQUFXO0FBQUEsRUFDWEMsT0FBTztBQUFBLEVBQ1BDLE9BQU87QUFBQSxFQUNQQyxhQUFhO0FBQ2Y7QUFFQSxNQUFNQyxRQUE4QjtBQUFBLEVBQ2xDQyxJQUFJO0FBQUEsRUFDSkMsSUFBSTtBQUFBLEVBQ0pDLElBQUk7QUFDTjtBQUVPLGFBQU1DLFNBQVNaLFdBQTBDYSxLQUFDLFNBQVNELFFBQ3hFLEVBQUVFLFVBQVUsV0FBV0MsT0FBTyxNQUFNQyxXQUFXQyxXQUFXQyxPQUFPLFVBQVUsR0FBR0MsTUFBTSxHQUNwRkMsS0FDQTtBQUNBLFNBQ0U7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNDO0FBQUEsTUFDQTtBQUFBLE1BQ0EsV0FBV25CO0FBQUFBLFFBQ1Q7QUFBQSxRQUNBO0FBQUEsUUFDQUMsU0FBU1ksT0FBTztBQUFBLFFBQ2hCTixNQUFNTyxJQUFJO0FBQUEsUUFDVkMsYUFBYTtBQUFBLFFBQ2JDO0FBQUFBLE1BQ0Y7QUFBQSxNQUNBLEdBQUlFO0FBQUFBO0FBQUFBLElBWE47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBV1k7QUFHaEIsQ0FBQztBQUFFRSxNQW5CVVQ7QUFBTSxJQUFBQyxJQUFBUTtBQUFBLGFBQUFSLElBQUE7QUFBQSxhQUFBUSxLQUFBIiwibmFtZXMiOlsiZm9yd2FyZFJlZiIsImNuIiwiVkFSSUFOVFMiLCJwcmltYXJ5Iiwic2Vjb25kYXJ5IiwiZ2hvc3QiLCJxdWlldCIsImRlc3RydWN0aXZlIiwiU0laRVMiLCJzbSIsIm1kIiwibGciLCJCdXR0b24iLCJfYyIsInZhcmlhbnQiLCJzaXplIiwiZnVsbFdpZHRoIiwiY2xhc3NOYW1lIiwidHlwZSIsInByb3BzIiwicmVmIiwiX2MyIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkJ1dHRvbi50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgZm9yd2FyZFJlZiB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHR5cGUgeyBCdXR0b25IVE1MQXR0cmlidXRlcyB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgY24gfSBmcm9tIFwiQC9saWIvY25cIjtcblxudHlwZSBWYXJpYW50ID0gXCJwcmltYXJ5XCIgfCBcInNlY29uZGFyeVwiIHwgXCJnaG9zdFwiIHwgXCJxdWlldFwiIHwgXCJkZXN0cnVjdGl2ZVwiO1xudHlwZSBTaXplID0gXCJzbVwiIHwgXCJtZFwiIHwgXCJsZ1wiO1xuXG5pbnRlcmZhY2UgQnV0dG9uUHJvcHMgZXh0ZW5kcyBCdXR0b25IVE1MQXR0cmlidXRlczxIVE1MQnV0dG9uRWxlbWVudD4ge1xuICB2YXJpYW50PzogVmFyaWFudDtcbiAgc2l6ZT86IFNpemU7XG4gIGZ1bGxXaWR0aD86IGJvb2xlYW47XG59XG5cbmNvbnN0IFZBUklBTlRTOiBSZWNvcmQ8VmFyaWFudCwgc3RyaW5nPiA9IHtcbiAgcHJpbWFyeTogXCJiZy1pbmsgdGV4dC1pdm9yeSBob3ZlcjpiZy1pbmstc29mdCBkaXNhYmxlZDpiZy1pbmsvMzBcIixcbiAgc2Vjb25kYXJ5OiBcImJnLXN1cmZhY2UgdGV4dC1pbmsgcmluZy0xIHJpbmctaGFpcmxpbmUtc3Ryb25nIGhvdmVyOnJpbmctaW5rIGRpc2FibGVkOnRleHQtbXV0ZWRcIixcbiAgZ2hvc3Q6IFwiYmctdHJhbnNwYXJlbnQgdGV4dC1pbmstc29mdCBob3ZlcjpiZy1pdm9yeS1kZWVwIGhvdmVyOnRleHQtaW5rXCIsXG4gIHF1aWV0OiBcImJnLWl2b3J5LWRlZXAgdGV4dC1pbmsgaG92ZXI6YmctaGFpcmxpbmVcIixcbiAgZGVzdHJ1Y3RpdmU6IFwiYmctZGFuZ2VyLTYwMCB0ZXh0LXdoaXRlIGhvdmVyOmJyaWdodG5lc3MtMTEwXCIsXG59O1xuXG5jb25zdCBTSVpFUzogUmVjb3JkPFNpemUsIHN0cmluZz4gPSB7XG4gIHNtOiBcImgtOSBweC0zIHRleHQtc20gZ2FwLTEuNVwiLFxuICBtZDogXCJoLTExIHB4LTQgdGV4dC1bMC45Mzc1cmVtXSBnYXAtMlwiLFxuICBsZzogXCJoLTEzIHB4LTYgdGV4dC1iYXNlIGdhcC0yXCIsXG59O1xuXG5leHBvcnQgY29uc3QgQnV0dG9uID0gZm9yd2FyZFJlZjxIVE1MQnV0dG9uRWxlbWVudCwgQnV0dG9uUHJvcHM+KGZ1bmN0aW9uIEJ1dHRvbihcbiAgeyB2YXJpYW50ID0gXCJwcmltYXJ5XCIsIHNpemUgPSBcIm1kXCIsIGZ1bGxXaWR0aCwgY2xhc3NOYW1lLCB0eXBlID0gXCJidXR0b25cIiwgLi4ucHJvcHMgfSxcbiAgcmVmLFxuKSB7XG4gIHJldHVybiAoXG4gICAgPGJ1dHRvblxuICAgICAgcmVmPXtyZWZ9XG4gICAgICB0eXBlPXt0eXBlfVxuICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgXCJwcmVzcyBpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC1mdWxsIGZvbnQtc2VtaWJvbGRcIixcbiAgICAgICAgXCJ0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0xNTAgYWN0aXZlOnNjYWxlLVswLjk4XSBkaXNhYmxlZDpjdXJzb3Itbm90LWFsbG93ZWQgZGlzYWJsZWQ6YWN0aXZlOnNjYWxlLTEwMFwiLFxuICAgICAgICBWQVJJQU5UU1t2YXJpYW50XSxcbiAgICAgICAgU0laRVNbc2l6ZV0sXG4gICAgICAgIGZ1bGxXaWR0aCAmJiBcInctZnVsbFwiLFxuICAgICAgICBjbGFzc05hbWUsXG4gICAgICApfVxuICAgICAgey4uLnByb3BzfVxuICAgIC8+XG4gICk7XG59KTtcbiJdLCJmaWxlIjoiRDovSTJJIFByb2plY3QgLSBIYWJpdG8vQXBwIEZvbGRlci9oYWJpdG8vc3JjL2NvbXBvbmVudHMvdWkvQnV0dG9uLnRzeCJ9