import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/space/PhotoUploader.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=9ceb86a3"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("D:/I2I Project - Habito/App Folder/habito/src/components/space/PhotoUploader.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9ceb86a3"; const useRef = __vite__cjsImport3_react["useRef"]; const useState = __vite__cjsImport3_react["useState"];
import { ImagePlus, X, Star, Loader2 } from "/node_modules/.vite/deps/lucide-react.js?v=9ceb86a3";
import { client, isRemote } from "/src/lib/supabase.ts";
import { useI18n } from "/src/i18n/index.tsx";
import { useAuth } from "/src/hooks/useAuth.tsx";
import { Button } from "/src/components/ui/Button.tsx";
import { cn } from "/src/lib/cn.ts";
const MAX_PHOTOS = 6;
const MAX_EDGE = 1600;
const TARGET_QUALITY = 0.82;
const HARD_LIMIT_BYTES = 5 * 1024 * 1024;
async function compress(file) {
  const bitmap = await createImageBitmap(file);
  const scale = Math.min(1, MAX_EDGE / Math.max(bitmap.width, bitmap.height));
  const width = Math.round(bitmap.width * scale);
  const height = Math.round(bitmap.height * scale);
  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("Could not process that image.");
  ctx.drawImage(bitmap, 0, 0, width, height);
  bitmap.close();
  const blob = await new Promise(
    (resolve) => canvas.toBlob(resolve, "image/jpeg", TARGET_QUALITY)
  );
  if (!blob) throw new Error("Could not process that image.");
  return blob;
}
export function PhotoUploader({
  spaceId,
  images,
  onChange
}) {
  _s();
  const { t } = useI18n();
  const { account } = useAuth();
  const inputRef = useRef(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(null);
  const canUpload = isRemote && Boolean(account);
  const remaining = MAX_PHOTOS - images.length;
  const handleFiles = async (files) => {
    if (!files || files.length === 0 || !account) return;
    setBusy(true);
    setError(null);
    const chosen = Array.from(files).slice(0, remaining);
    const added = [];
    for (const file of chosen) {
      try {
        const blob = await compress(file);
        if (blob.size > HARD_LIMIT_BYTES) {
          setError(t("list.photoTooLarge"));
          continue;
        }
        const path = `${account.id}/${spaceId}/${crypto.randomUUID()}.jpg`;
        const { error: uploadError } = await client().storage.from("space-photos").upload(path, blob, { contentType: "image/jpeg", upsert: false });
        if (uploadError) {
          setError(t("list.photoFailed"));
          continue;
        }
        const { data } = client().storage.from("space-photos").getPublicUrl(path);
        added.push({
          url: data.publicUrl,
          label: `Photo ${images.length + added.length + 1}`,
          alt: "Photograph provided by the owner of this space",
          // Owner photographs are real; only seed artwork carries the demo flag.
          demo: false
        });
      } catch {
        setError(t("list.photoFailed"));
      }
    }
    if (added.length) onChange([...images, ...added]);
    setBusy(false);
    if (inputRef.current) inputRef.current.value = "";
  };
  const remove = (index) => onChange(images.filter((_, i) => i !== index));
  const makeCover = (index) => {
    const next = [...images];
    const [chosen] = next.splice(index, 1);
    onChange([chosen, ...next]);
  };
  return /* @__PURE__ */ jsxDEV("div", { children: [
    images.length > 0 && /* @__PURE__ */ jsxDEV("ul", { className: "mb-4 grid grid-cols-3 gap-2 sm:grid-cols-4", children: images.map(
      (image, index) => /* @__PURE__ */ jsxDEV("li", { className: "group relative overflow-hidden rounded-xl bg-ivory-deep", children: [
        /* @__PURE__ */ jsxDEV("img", { src: image.url, alt: image.alt, className: "aspect-4/3 w-full object-cover" }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/PhotoUploader.tsx",
          lineNumber: 146,
          columnNumber: 15
        }, this),
        index === 0 && /* @__PURE__ */ jsxDEV("span", { className: "absolute left-1.5 top-1.5 rounded-full bg-ink/85 px-2 py-0.5 text-[0.65rem] font-bold text-ivory", children: t("list.coverPhoto") }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/PhotoUploader.tsx",
          lineNumber: 149,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "absolute inset-x-1.5 bottom-1.5 flex justify-end gap-1", children: [
          index !== 0 && /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: () => makeCover(index),
              "aria-label": t("list.setCover"),
              title: t("list.setCover"),
              className: "rounded-full bg-surface/90 p-1.5 text-ink-soft backdrop-blur hover:text-aqua-700",
              children: /* @__PURE__ */ jsxDEV(Star, { size: 13, "aria-hidden": true }, void 0, false, {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/PhotoUploader.tsx",
                lineNumber: 163,
                columnNumber: 21
              }, this)
            },
            void 0,
            false,
            {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/PhotoUploader.tsx",
              lineNumber: 156,
              columnNumber: 13
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: () => remove(index),
              "aria-label": t("action.remove"),
              className: "rounded-full bg-surface/90 p-1.5 text-ink-soft backdrop-blur hover:text-danger-600",
              children: /* @__PURE__ */ jsxDEV(X, { size: 13, "aria-hidden": true }, void 0, false, {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/PhotoUploader.tsx",
                lineNumber: 172,
                columnNumber: 19
              }, this)
            },
            void 0,
            false,
            {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/PhotoUploader.tsx",
              lineNumber: 166,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/PhotoUploader.tsx",
          lineNumber: 154,
          columnNumber: 15
        }, this)
      ] }, image.url, true, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/PhotoUploader.tsx",
        lineNumber: 145,
        columnNumber: 9
      }, this)
    ) }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/PhotoUploader.tsx",
      lineNumber: 143,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      "input",
      {
        ref: inputRef,
        type: "file",
        accept: "image/jpeg,image/png,image/webp",
        multiple: true,
        hidden: true,
        onChange: (e) => void handleFiles(e.target.files)
      },
      void 0,
      false,
      {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/PhotoUploader.tsx",
        lineNumber: 180,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center gap-3", children: [
      /* @__PURE__ */ jsxDEV(
        Button,
        {
          variant: "secondary",
          disabled: !canUpload || busy || remaining <= 0,
          onClick: () => inputRef.current?.click(),
          children: [
            busy ? /* @__PURE__ */ jsxDEV(Loader2, { size: 16, className: "animate-spin", "aria-hidden": true }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/PhotoUploader.tsx",
              lineNumber: 196,
              columnNumber: 11
            }, this) : /* @__PURE__ */ jsxDEV(ImagePlus, { size: 16, "aria-hidden": true }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/PhotoUploader.tsx",
              lineNumber: 198,
              columnNumber: 11
            }, this),
            busy ? t("list.uploading") : t("list.addPhotos")
          ]
        },
        void 0,
        true,
        {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/PhotoUploader.tsx",
          lineNumber: 190,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("p", { className: cn("text-xs", images.length === 0 ? "text-muted" : "text-ink-soft"), children: images.length === 0 ? t("list.noPhotos") : t("list.photoHint") }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/PhotoUploader.tsx",
        lineNumber: 203,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/PhotoUploader.tsx",
      lineNumber: 189,
      columnNumber: 7
    }, this),
    !canUpload && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-xs leading-relaxed text-warn-700", children: isRemote ? t("inquiry.signInFirst") : t("auth.noDatabase") }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/PhotoUploader.tsx",
      lineNumber: 209,
      columnNumber: 7
    }, this),
    error && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-danger-600", children: error }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/PhotoUploader.tsx",
      lineNumber: 214,
      columnNumber: 17
    }, this)
  ] }, void 0, true, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/space/PhotoUploader.tsx",
    lineNumber: 141,
    columnNumber: 5
  }, this);
}
_s(PhotoUploader, "NgNoT3CWuIZoSJlAYLFixJEuYnU=", false, function() {
  return [useI18n, useAuth];
});
_c = PhotoUploader;
var _c;
$RefreshReg$(_c, "PhotoUploader");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/I2I Project - Habito/App Folder/habito/src/components/space/PhotoUploader.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/I2I Project - Habito/App Folder/habito/src/components/space/PhotoUploader.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBOEhjOzs7Ozs7Ozs7Ozs7Ozs7OztBQTlIZCxTQUFTQSxRQUFRQyxnQkFBZ0I7QUFDakMsU0FBU0MsV0FBV0MsR0FBR0MsTUFBTUMsZUFBZTtBQUM1QyxTQUFTQyxRQUFRQyxnQkFBZ0I7QUFDakMsU0FBU0MsZUFBZTtBQUN4QixTQUFTQyxlQUFlO0FBQ3hCLFNBQVNDLGNBQWM7QUFDdkIsU0FBU0MsVUFBVTtBQUduQixNQUFNQyxhQUFhO0FBQ25CLE1BQU1DLFdBQVc7QUFDakIsTUFBTUMsaUJBQWlCO0FBQ3ZCLE1BQU1DLG1CQUFtQixJQUFJLE9BQU87QUFTcEMsZUFBZUMsU0FBU0MsTUFBMkI7QUFDakQsUUFBTUMsU0FBUyxNQUFNQyxrQkFBa0JGLElBQUk7QUFFM0MsUUFBTUcsUUFBUUMsS0FBS0MsSUFBSSxHQUFHVCxXQUFXUSxLQUFLRSxJQUFJTCxPQUFPTSxPQUFPTixPQUFPTyxNQUFNLENBQUM7QUFDMUUsUUFBTUQsUUFBUUgsS0FBS0ssTUFBTVIsT0FBT00sUUFBUUosS0FBSztBQUM3QyxRQUFNSyxTQUFTSixLQUFLSyxNQUFNUixPQUFPTyxTQUFTTCxLQUFLO0FBRS9DLFFBQU1PLFNBQVNDLFNBQVNDLGNBQWMsUUFBUTtBQUM5Q0YsU0FBT0gsUUFBUUE7QUFDZkcsU0FBT0YsU0FBU0E7QUFFaEIsUUFBTUssTUFBTUgsT0FBT0ksV0FBVyxJQUFJO0FBQ2xDLE1BQUksQ0FBQ0QsSUFBSyxPQUFNLElBQUlFLE1BQU0sK0JBQStCO0FBQ3pERixNQUFJRyxVQUFVZixRQUFRLEdBQUcsR0FBR00sT0FBT0MsTUFBTTtBQUN6Q1AsU0FBT2dCLE1BQU07QUFFYixRQUFNQyxPQUFPLE1BQU0sSUFBSUM7QUFBQUEsSUFBcUIsQ0FBQ0MsWUFDM0NWLE9BQU9XLE9BQU9ELFNBQVMsY0FBY3ZCLGNBQWM7QUFBQSxFQUNyRDtBQUVBLE1BQUksQ0FBQ3FCLEtBQU0sT0FBTSxJQUFJSCxNQUFNLCtCQUErQjtBQUMxRCxTQUFPRztBQUNUO0FBRU8sZ0JBQVNJLGNBQWM7QUFBQSxFQUM1QkM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFNRixHQUFHO0FBQUFDLEtBQUE7QUFDRCxRQUFNLEVBQUVDLEVBQUUsSUFBSXBDLFFBQVE7QUFDdEIsUUFBTSxFQUFFcUMsUUFBUSxJQUFJcEMsUUFBUTtBQUM1QixRQUFNcUMsV0FBVzlDLE9BQXlCLElBQUk7QUFFOUMsUUFBTSxDQUFDK0MsTUFBTUMsT0FBTyxJQUFJL0MsU0FBUyxLQUFLO0FBQ3RDLFFBQU0sQ0FBQ2dELE9BQU9DLFFBQVEsSUFBSWpELFNBQXdCLElBQUk7QUFFdEQsUUFBTWtELFlBQVk1QyxZQUFZNkMsUUFBUVAsT0FBTztBQUM3QyxRQUFNUSxZQUFZekMsYUFBYTZCLE9BQU9hO0FBRXRDLFFBQU1DLGNBQWMsT0FBT0MsVUFBMkI7QUFDcEQsUUFBSSxDQUFDQSxTQUFTQSxNQUFNRixXQUFXLEtBQUssQ0FBQ1QsUUFBUztBQUU5Q0csWUFBUSxJQUFJO0FBQ1pFLGFBQVMsSUFBSTtBQUViLFVBQU1PLFNBQVNDLE1BQU1DLEtBQUtILEtBQUssRUFBRUksTUFBTSxHQUFHUCxTQUFTO0FBQ25ELFVBQU1RLFFBQXNCO0FBRTVCLGVBQVc1QyxRQUFRd0MsUUFBUTtBQUN6QixVQUFJO0FBQ0YsY0FBTXRCLE9BQU8sTUFBTW5CLFNBQVNDLElBQUk7QUFFaEMsWUFBSWtCLEtBQUsyQixPQUFPL0Msa0JBQWtCO0FBQ2hDbUMsbUJBQVNOLEVBQUUsb0JBQW9CLENBQUM7QUFDaEM7QUFBQSxRQUNGO0FBRUEsY0FBTW1CLE9BQU8sR0FBR2xCLFFBQVFtQixFQUFFLElBQUl4QixPQUFPLElBQUl5QixPQUFPQyxXQUFXLENBQUM7QUFDNUQsY0FBTSxFQUFFakIsT0FBT2tCLFlBQVksSUFBSSxNQUFNN0QsT0FBTyxFQUN6QzhELFFBQVFULEtBQUssY0FBYyxFQUMzQlUsT0FBT04sTUFBTTVCLE1BQU0sRUFBRW1DLGFBQWEsY0FBY0MsUUFBUSxNQUFNLENBQUM7QUFFbEUsWUFBSUosYUFBYTtBQUNmakIsbUJBQVNOLEVBQUUsa0JBQWtCLENBQUM7QUFDOUI7QUFBQSxRQUNGO0FBRUEsY0FBTSxFQUFFNEIsS0FBSyxJQUFJbEUsT0FBTyxFQUFFOEQsUUFBUVQsS0FBSyxjQUFjLEVBQUVjLGFBQWFWLElBQUk7QUFFeEVGLGNBQU1hLEtBQUs7QUFBQSxVQUNUQyxLQUFLSCxLQUFLSTtBQUFBQSxVQUNWQyxPQUFPLFNBQVNwQyxPQUFPYSxTQUFTTyxNQUFNUCxTQUFTLENBQUM7QUFBQSxVQUNoRHdCLEtBQUs7QUFBQTtBQUFBLFVBRUxDLE1BQU07QUFBQSxRQUNSLENBQUM7QUFBQSxNQUNILFFBQVE7QUFDTjdCLGlCQUFTTixFQUFFLGtCQUFrQixDQUFDO0FBQUEsTUFDaEM7QUFBQSxJQUNGO0FBRUEsUUFBSWlCLE1BQU1QLE9BQVFaLFVBQVMsQ0FBQyxHQUFHRCxRQUFRLEdBQUdvQixLQUFLLENBQUM7QUFDaERiLFlBQVEsS0FBSztBQUNiLFFBQUlGLFNBQVNrQyxRQUFTbEMsVUFBU2tDLFFBQVFDLFFBQVE7QUFBQSxFQUNqRDtBQUVBLFFBQU1DLFNBQVNBLENBQUNDLFVBQWtCekMsU0FBU0QsT0FBTzJDLE9BQU8sQ0FBQ0MsR0FBR0MsTUFBTUEsTUFBTUgsS0FBSyxDQUFDO0FBRS9FLFFBQU1JLFlBQVlBLENBQUNKLFVBQWtCO0FBQ25DLFVBQU1LLE9BQU8sQ0FBQyxHQUFHL0MsTUFBTTtBQUN2QixVQUFNLENBQUNnQixNQUFNLElBQUkrQixLQUFLQyxPQUFPTixPQUFPLENBQUM7QUFDckN6QyxhQUFTLENBQUNlLFFBQVEsR0FBRytCLElBQUksQ0FBQztBQUFBLEVBQzVCO0FBRUEsU0FDRSx1QkFBQyxTQUNFL0M7QUFBQUEsV0FBT2EsU0FBUyxLQUNmLHVCQUFDLFFBQUcsV0FBVSw4Q0FDWGIsaUJBQU9pRDtBQUFBQSxNQUFJLENBQUNDLE9BQU9SLFVBQ2xCLHVCQUFDLFFBQW1CLFdBQVUsMkRBQzVCO0FBQUEsK0JBQUMsU0FBSSxLQUFLUSxNQUFNaEIsS0FBSyxLQUFLZ0IsTUFBTWIsS0FBSyxXQUFVLG9DQUEvQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQStFO0FBQUEsUUFFOUVLLFVBQVUsS0FDVCx1QkFBQyxVQUFLLFdBQVUsb0dBQ2J2QyxZQUFFLGlCQUFpQixLQUR0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUdGLHVCQUFDLFNBQUksV0FBVSwwREFDWnVDO0FBQUFBLG9CQUFVLEtBQ1Q7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLFNBQVMsTUFBTUksVUFBVUosS0FBSztBQUFBLGNBQzlCLGNBQVl2QyxFQUFFLGVBQWU7QUFBQSxjQUM3QixPQUFPQSxFQUFFLGVBQWU7QUFBQSxjQUN4QixXQUFVO0FBQUEsY0FFVixpQ0FBQyxRQUFLLE1BQU0sSUFBSSxlQUFXLFFBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTJCO0FBQUE7QUFBQSxZQVA3QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFRQTtBQUFBLFVBRUY7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLFNBQVMsTUFBTXNDLE9BQU9DLEtBQUs7QUFBQSxjQUMzQixjQUFZdkMsRUFBRSxlQUFlO0FBQUEsY0FDN0IsV0FBVTtBQUFBLGNBRVYsaUNBQUMsS0FBRSxNQUFNLElBQUksZUFBVyxRQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF3QjtBQUFBO0FBQUEsWUFOMUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBT0E7QUFBQSxhQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBb0JBO0FBQUEsV0E3Qk8rQyxNQUFNaEIsS0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBOEJBO0FBQUEsSUFDRCxLQWpDSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBa0NBO0FBQUEsSUFHRjtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsS0FBSzdCO0FBQUFBLFFBQ0wsTUFBSztBQUFBLFFBQ0wsUUFBTztBQUFBLFFBQ1A7QUFBQSxRQUNBO0FBQUEsUUFDQSxVQUFVLENBQUM4QyxNQUFNLEtBQUtyQyxZQUFZcUMsRUFBRUMsT0FBT3JDLEtBQUs7QUFBQTtBQUFBLE1BTmxEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQU1vRDtBQUFBLElBR3BELHVCQUFDLFNBQUksV0FBVSxxQ0FDYjtBQUFBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxTQUFRO0FBQUEsVUFDUixVQUFVLENBQUNMLGFBQWFKLFFBQVFNLGFBQWE7QUFBQSxVQUM3QyxTQUFTLE1BQU1QLFNBQVNrQyxTQUFTYyxNQUFNO0FBQUEsVUFFdEMvQztBQUFBQSxtQkFDQyx1QkFBQyxXQUFRLE1BQU0sSUFBSSxXQUFVLGdCQUFlLGVBQVcsUUFBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBdUQsSUFFdkQsdUJBQUMsYUFBVSxNQUFNLElBQUksZUFBVyxRQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFnQztBQUFBLFlBRWpDQSxPQUFPSCxFQUFFLGdCQUFnQixJQUFJQSxFQUFFLGdCQUFnQjtBQUFBO0FBQUE7QUFBQSxRQVZsRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFXQTtBQUFBLE1BRUEsdUJBQUMsT0FBRSxXQUFXakMsR0FBRyxXQUFXOEIsT0FBT2EsV0FBVyxJQUFJLGVBQWUsZUFBZSxHQUM3RWIsaUJBQU9hLFdBQVcsSUFBSVYsRUFBRSxlQUFlLElBQUlBLEVBQUUsZ0JBQWdCLEtBRGhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FpQkE7QUFBQSxJQUVDLENBQUNPLGFBQ0EsdUJBQUMsT0FBRSxXQUFVLDhDQUNWNUMscUJBQVdxQyxFQUFFLHFCQUFxQixJQUFJQSxFQUFFLGlCQUFpQixLQUQ1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxJQUdESyxTQUFTLHVCQUFDLE9BQUUsV0FBVSxnQ0FBZ0NBLG1CQUE3QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQW1EO0FBQUEsT0F6RS9EO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0EwRUE7QUFFSjtBQUFDTixHQXhKZUosZUFBYTtBQUFBLFVBVWIvQixTQUNNQyxPQUFPO0FBQUE7QUFBQSxLQVhiOEI7QUFBYSxJQUFBd0Q7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsidXNlUmVmIiwidXNlU3RhdGUiLCJJbWFnZVBsdXMiLCJYIiwiU3RhciIsIkxvYWRlcjIiLCJjbGllbnQiLCJpc1JlbW90ZSIsInVzZUkxOG4iLCJ1c2VBdXRoIiwiQnV0dG9uIiwiY24iLCJNQVhfUEhPVE9TIiwiTUFYX0VER0UiLCJUQVJHRVRfUVVBTElUWSIsIkhBUkRfTElNSVRfQllURVMiLCJjb21wcmVzcyIsImZpbGUiLCJiaXRtYXAiLCJjcmVhdGVJbWFnZUJpdG1hcCIsInNjYWxlIiwiTWF0aCIsIm1pbiIsIm1heCIsIndpZHRoIiwiaGVpZ2h0Iiwicm91bmQiLCJjYW52YXMiLCJkb2N1bWVudCIsImNyZWF0ZUVsZW1lbnQiLCJjdHgiLCJnZXRDb250ZXh0IiwiRXJyb3IiLCJkcmF3SW1hZ2UiLCJjbG9zZSIsImJsb2IiLCJQcm9taXNlIiwicmVzb2x2ZSIsInRvQmxvYiIsIlBob3RvVXBsb2FkZXIiLCJzcGFjZUlkIiwiaW1hZ2VzIiwib25DaGFuZ2UiLCJfcyIsInQiLCJhY2NvdW50IiwiaW5wdXRSZWYiLCJidXN5Iiwic2V0QnVzeSIsImVycm9yIiwic2V0RXJyb3IiLCJjYW5VcGxvYWQiLCJCb29sZWFuIiwicmVtYWluaW5nIiwibGVuZ3RoIiwiaGFuZGxlRmlsZXMiLCJmaWxlcyIsImNob3NlbiIsIkFycmF5IiwiZnJvbSIsInNsaWNlIiwiYWRkZWQiLCJzaXplIiwicGF0aCIsImlkIiwiY3J5cHRvIiwicmFuZG9tVVVJRCIsInVwbG9hZEVycm9yIiwic3RvcmFnZSIsInVwbG9hZCIsImNvbnRlbnRUeXBlIiwidXBzZXJ0IiwiZGF0YSIsImdldFB1YmxpY1VybCIsInB1c2giLCJ1cmwiLCJwdWJsaWNVcmwiLCJsYWJlbCIsImFsdCIsImRlbW8iLCJjdXJyZW50IiwidmFsdWUiLCJyZW1vdmUiLCJpbmRleCIsImZpbHRlciIsIl8iLCJpIiwibWFrZUNvdmVyIiwibmV4dCIsInNwbGljZSIsIm1hcCIsImltYWdlIiwiZSIsInRhcmdldCIsImNsaWNrIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiUGhvdG9VcGxvYWRlci50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlUmVmLCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgSW1hZ2VQbHVzLCBYLCBTdGFyLCBMb2FkZXIyIH0gZnJvbSBcImx1Y2lkZS1yZWFjdFwiO1xuaW1wb3J0IHsgY2xpZW50LCBpc1JlbW90ZSB9IGZyb20gXCJAL2xpYi9zdXBhYmFzZVwiO1xuaW1wb3J0IHsgdXNlSTE4biB9IGZyb20gXCJAL2kxOG5cIjtcbmltcG9ydCB7IHVzZUF1dGggfSBmcm9tIFwiQC9ob29rcy91c2VBdXRoXCI7XG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tIFwiQC9jb21wb25lbnRzL3VpL0J1dHRvblwiO1xuaW1wb3J0IHsgY24gfSBmcm9tIFwiQC9saWIvY25cIjtcbmltcG9ydCB0eXBlIHsgU3BhY2VJbWFnZSB9IGZyb20gXCJAL3R5cGVzL3NwYWNlXCI7XG5cbmNvbnN0IE1BWF9QSE9UT1MgPSA2O1xuY29uc3QgTUFYX0VER0UgPSAxNjAwO1xuY29uc3QgVEFSR0VUX1FVQUxJVFkgPSAwLjgyO1xuY29uc3QgSEFSRF9MSU1JVF9CWVRFUyA9IDUgKiAxMDI0ICogMTAyNDtcblxuLyoqXG4gKiBTaHJpbmtzIGFuIGltYWdlIGluIHRoZSBicm93c2VyIGJlZm9yZSBpdCBldmVyIGxlYXZlcyB0aGUgZGV2aWNlLlxuICpcbiAqIEEgcGhvbmUgcGhvdG8gaXMgcm91dGluZWx5IDTigJM4IE1CLiBPbiBtb2JpbGUgZGF0YSBpbiBCYW5nbGFkZXNoIHRoYXQgaXMgYVxuICogbWludXRlIG9mIHVwbG9hZGluZyBhbmQgYSByZWFsIGNvc3QgdG8gdGhlIHBlcnNvbiBsaXN0aW5nIGEgcm9vbSwgc28gdGhlXG4gKiBsb25nIGVkZ2UgaXMgY2FwcGVkIGFuZCB0aGUgZmlsZSByZS1lbmNvZGVkIHRvIEpQRUcgZmlyc3QuXG4gKi9cbmFzeW5jIGZ1bmN0aW9uIGNvbXByZXNzKGZpbGU6IEZpbGUpOiBQcm9taXNlPEJsb2I+IHtcbiAgY29uc3QgYml0bWFwID0gYXdhaXQgY3JlYXRlSW1hZ2VCaXRtYXAoZmlsZSk7XG5cbiAgY29uc3Qgc2NhbGUgPSBNYXRoLm1pbigxLCBNQVhfRURHRSAvIE1hdGgubWF4KGJpdG1hcC53aWR0aCwgYml0bWFwLmhlaWdodCkpO1xuICBjb25zdCB3aWR0aCA9IE1hdGgucm91bmQoYml0bWFwLndpZHRoICogc2NhbGUpO1xuICBjb25zdCBoZWlnaHQgPSBNYXRoLnJvdW5kKGJpdG1hcC5oZWlnaHQgKiBzY2FsZSk7XG5cbiAgY29uc3QgY2FudmFzID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImNhbnZhc1wiKTtcbiAgY2FudmFzLndpZHRoID0gd2lkdGg7XG4gIGNhbnZhcy5oZWlnaHQgPSBoZWlnaHQ7XG5cbiAgY29uc3QgY3R4ID0gY2FudmFzLmdldENvbnRleHQoXCIyZFwiKTtcbiAgaWYgKCFjdHgpIHRocm93IG5ldyBFcnJvcihcIkNvdWxkIG5vdCBwcm9jZXNzIHRoYXQgaW1hZ2UuXCIpO1xuICBjdHguZHJhd0ltYWdlKGJpdG1hcCwgMCwgMCwgd2lkdGgsIGhlaWdodCk7XG4gIGJpdG1hcC5jbG9zZSgpO1xuXG4gIGNvbnN0IGJsb2IgPSBhd2FpdCBuZXcgUHJvbWlzZTxCbG9iIHwgbnVsbD4oKHJlc29sdmUpID0+XG4gICAgY2FudmFzLnRvQmxvYihyZXNvbHZlLCBcImltYWdlL2pwZWdcIiwgVEFSR0VUX1FVQUxJVFkpLFxuICApO1xuXG4gIGlmICghYmxvYikgdGhyb3cgbmV3IEVycm9yKFwiQ291bGQgbm90IHByb2Nlc3MgdGhhdCBpbWFnZS5cIik7XG4gIHJldHVybiBibG9iO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gUGhvdG9VcGxvYWRlcih7XG4gIHNwYWNlSWQsXG4gIGltYWdlcyxcbiAgb25DaGFuZ2UsXG59OiB7XG4gIC8qKiBQaG90b3MgYXJlIGZpbGVkIHVuZGVyIHRoZSB1cGxvYWRlcidzIGlkLCB3aGljaCBpcyBob3cgc3RvcmFnZSBjaGVja3Mgb3duZXJzaGlwLiAqL1xuICBzcGFjZUlkOiBzdHJpbmc7XG4gIGltYWdlczogU3BhY2VJbWFnZVtdO1xuICBvbkNoYW5nZTogKGltYWdlczogU3BhY2VJbWFnZVtdKSA9PiB2b2lkO1xufSkge1xuICBjb25zdCB7IHQgfSA9IHVzZUkxOG4oKTtcbiAgY29uc3QgeyBhY2NvdW50IH0gPSB1c2VBdXRoKCk7XG4gIGNvbnN0IGlucHV0UmVmID0gdXNlUmVmPEhUTUxJbnB1dEVsZW1lbnQ+KG51bGwpO1xuXG4gIGNvbnN0IFtidXN5LCBzZXRCdXN5XSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW2Vycm9yLCBzZXRFcnJvcl0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcblxuICBjb25zdCBjYW5VcGxvYWQgPSBpc1JlbW90ZSAmJiBCb29sZWFuKGFjY291bnQpO1xuICBjb25zdCByZW1haW5pbmcgPSBNQVhfUEhPVE9TIC0gaW1hZ2VzLmxlbmd0aDtcblxuICBjb25zdCBoYW5kbGVGaWxlcyA9IGFzeW5jIChmaWxlczogRmlsZUxpc3QgfCBudWxsKSA9PiB7XG4gICAgaWYgKCFmaWxlcyB8fCBmaWxlcy5sZW5ndGggPT09IDAgfHwgIWFjY291bnQpIHJldHVybjtcblxuICAgIHNldEJ1c3kodHJ1ZSk7XG4gICAgc2V0RXJyb3IobnVsbCk7XG5cbiAgICBjb25zdCBjaG9zZW4gPSBBcnJheS5mcm9tKGZpbGVzKS5zbGljZSgwLCByZW1haW5pbmcpO1xuICAgIGNvbnN0IGFkZGVkOiBTcGFjZUltYWdlW10gPSBbXTtcblxuICAgIGZvciAoY29uc3QgZmlsZSBvZiBjaG9zZW4pIHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IGJsb2IgPSBhd2FpdCBjb21wcmVzcyhmaWxlKTtcblxuICAgICAgICBpZiAoYmxvYi5zaXplID4gSEFSRF9MSU1JVF9CWVRFUykge1xuICAgICAgICAgIHNldEVycm9yKHQoXCJsaXN0LnBob3RvVG9vTGFyZ2VcIikpO1xuICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgcGF0aCA9IGAke2FjY291bnQuaWR9LyR7c3BhY2VJZH0vJHtjcnlwdG8ucmFuZG9tVVVJRCgpfS5qcGdgO1xuICAgICAgICBjb25zdCB7IGVycm9yOiB1cGxvYWRFcnJvciB9ID0gYXdhaXQgY2xpZW50KClcbiAgICAgICAgICAuc3RvcmFnZS5mcm9tKFwic3BhY2UtcGhvdG9zXCIpXG4gICAgICAgICAgLnVwbG9hZChwYXRoLCBibG9iLCB7IGNvbnRlbnRUeXBlOiBcImltYWdlL2pwZWdcIiwgdXBzZXJ0OiBmYWxzZSB9KTtcblxuICAgICAgICBpZiAodXBsb2FkRXJyb3IpIHtcbiAgICAgICAgICBzZXRFcnJvcih0KFwibGlzdC5waG90b0ZhaWxlZFwiKSk7XG4gICAgICAgICAgY29udGludWU7XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCB7IGRhdGEgfSA9IGNsaWVudCgpLnN0b3JhZ2UuZnJvbShcInNwYWNlLXBob3Rvc1wiKS5nZXRQdWJsaWNVcmwocGF0aCk7XG5cbiAgICAgICAgYWRkZWQucHVzaCh7XG4gICAgICAgICAgdXJsOiBkYXRhLnB1YmxpY1VybCxcbiAgICAgICAgICBsYWJlbDogYFBob3RvICR7aW1hZ2VzLmxlbmd0aCArIGFkZGVkLmxlbmd0aCArIDF9YCxcbiAgICAgICAgICBhbHQ6IFwiUGhvdG9ncmFwaCBwcm92aWRlZCBieSB0aGUgb3duZXIgb2YgdGhpcyBzcGFjZVwiLFxuICAgICAgICAgIC8vIE93bmVyIHBob3RvZ3JhcGhzIGFyZSByZWFsOyBvbmx5IHNlZWQgYXJ0d29yayBjYXJyaWVzIHRoZSBkZW1vIGZsYWcuXG4gICAgICAgICAgZGVtbzogZmFsc2UgYXMgdW5rbm93biBhcyB0cnVlLFxuICAgICAgICB9KTtcbiAgICAgIH0gY2F0Y2gge1xuICAgICAgICBzZXRFcnJvcih0KFwibGlzdC5waG90b0ZhaWxlZFwiKSk7XG4gICAgICB9XG4gICAgfVxuXG4gICAgaWYgKGFkZGVkLmxlbmd0aCkgb25DaGFuZ2UoWy4uLmltYWdlcywgLi4uYWRkZWRdKTtcbiAgICBzZXRCdXN5KGZhbHNlKTtcbiAgICBpZiAoaW5wdXRSZWYuY3VycmVudCkgaW5wdXRSZWYuY3VycmVudC52YWx1ZSA9IFwiXCI7XG4gIH07XG5cbiAgY29uc3QgcmVtb3ZlID0gKGluZGV4OiBudW1iZXIpID0+IG9uQ2hhbmdlKGltYWdlcy5maWx0ZXIoKF8sIGkpID0+IGkgIT09IGluZGV4KSk7XG5cbiAgY29uc3QgbWFrZUNvdmVyID0gKGluZGV4OiBudW1iZXIpID0+IHtcbiAgICBjb25zdCBuZXh0ID0gWy4uLmltYWdlc107XG4gICAgY29uc3QgW2Nob3Nlbl0gPSBuZXh0LnNwbGljZShpbmRleCwgMSk7XG4gICAgb25DaGFuZ2UoW2Nob3NlbiwgLi4ubmV4dF0pO1xuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPGRpdj5cbiAgICAgIHtpbWFnZXMubGVuZ3RoID4gMCAmJiAoXG4gICAgICAgIDx1bCBjbGFzc05hbWU9XCJtYi00IGdyaWQgZ3JpZC1jb2xzLTMgZ2FwLTIgc206Z3JpZC1jb2xzLTRcIj5cbiAgICAgICAgICB7aW1hZ2VzLm1hcCgoaW1hZ2UsIGluZGV4KSA9PiAoXG4gICAgICAgICAgICA8bGkga2V5PXtpbWFnZS51cmx9IGNsYXNzTmFtZT1cImdyb3VwIHJlbGF0aXZlIG92ZXJmbG93LWhpZGRlbiByb3VuZGVkLXhsIGJnLWl2b3J5LWRlZXBcIj5cbiAgICAgICAgICAgICAgPGltZyBzcmM9e2ltYWdlLnVybH0gYWx0PXtpbWFnZS5hbHR9IGNsYXNzTmFtZT1cImFzcGVjdC00LzMgdy1mdWxsIG9iamVjdC1jb3ZlclwiIC8+XG5cbiAgICAgICAgICAgICAge2luZGV4ID09PSAwICYmIChcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBsZWZ0LTEuNSB0b3AtMS41IHJvdW5kZWQtZnVsbCBiZy1pbmsvODUgcHgtMiBweS0wLjUgdGV4dC1bMC42NXJlbV0gZm9udC1ib2xkIHRleHQtaXZvcnlcIj5cbiAgICAgICAgICAgICAgICAgIHt0KFwibGlzdC5jb3ZlclBob3RvXCIpfVxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIGluc2V0LXgtMS41IGJvdHRvbS0xLjUgZmxleCBqdXN0aWZ5LWVuZCBnYXAtMVwiPlxuICAgICAgICAgICAgICAgIHtpbmRleCAhPT0gMCAmJiAoXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBtYWtlQ292ZXIoaW5kZXgpfVxuICAgICAgICAgICAgICAgICAgICBhcmlhLWxhYmVsPXt0KFwibGlzdC5zZXRDb3ZlclwiKX1cbiAgICAgICAgICAgICAgICAgICAgdGl0bGU9e3QoXCJsaXN0LnNldENvdmVyXCIpfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJyb3VuZGVkLWZ1bGwgYmctc3VyZmFjZS85MCBwLTEuNSB0ZXh0LWluay1zb2Z0IGJhY2tkcm9wLWJsdXIgaG92ZXI6dGV4dC1hcXVhLTcwMFwiXG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIDxTdGFyIHNpemU9ezEzfSBhcmlhLWhpZGRlbiAvPlxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHJlbW92ZShpbmRleCl9XG4gICAgICAgICAgICAgICAgICBhcmlhLWxhYmVsPXt0KFwiYWN0aW9uLnJlbW92ZVwiKX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQtZnVsbCBiZy1zdXJmYWNlLzkwIHAtMS41IHRleHQtaW5rLXNvZnQgYmFja2Ryb3AtYmx1ciBob3Zlcjp0ZXh0LWRhbmdlci02MDBcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxYIHNpemU9ezEzfSBhcmlhLWhpZGRlbiAvPlxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvbGk+XG4gICAgICAgICAgKSl9XG4gICAgICAgIDwvdWw+XG4gICAgICApfVxuXG4gICAgICA8aW5wdXRcbiAgICAgICAgcmVmPXtpbnB1dFJlZn1cbiAgICAgICAgdHlwZT1cImZpbGVcIlxuICAgICAgICBhY2NlcHQ9XCJpbWFnZS9qcGVnLGltYWdlL3BuZyxpbWFnZS93ZWJwXCJcbiAgICAgICAgbXVsdGlwbGVcbiAgICAgICAgaGlkZGVuXG4gICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gdm9pZCBoYW5kbGVGaWxlcyhlLnRhcmdldC5maWxlcyl9XG4gICAgICAvPlxuXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxuICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgdmFyaWFudD1cInNlY29uZGFyeVwiXG4gICAgICAgICAgZGlzYWJsZWQ9eyFjYW5VcGxvYWQgfHwgYnVzeSB8fCByZW1haW5pbmcgPD0gMH1cbiAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBpbnB1dFJlZi5jdXJyZW50Py5jbGljaygpfVxuICAgICAgICA+XG4gICAgICAgICAge2J1c3kgPyAoXG4gICAgICAgICAgICA8TG9hZGVyMiBzaXplPXsxNn0gY2xhc3NOYW1lPVwiYW5pbWF0ZS1zcGluXCIgYXJpYS1oaWRkZW4gLz5cbiAgICAgICAgICApIDogKFxuICAgICAgICAgICAgPEltYWdlUGx1cyBzaXplPXsxNn0gYXJpYS1oaWRkZW4gLz5cbiAgICAgICAgICApfVxuICAgICAgICAgIHtidXN5ID8gdChcImxpc3QudXBsb2FkaW5nXCIpIDogdChcImxpc3QuYWRkUGhvdG9zXCIpfVxuICAgICAgICA8L0J1dHRvbj5cblxuICAgICAgICA8cCBjbGFzc05hbWU9e2NuKFwidGV4dC14c1wiLCBpbWFnZXMubGVuZ3RoID09PSAwID8gXCJ0ZXh0LW11dGVkXCIgOiBcInRleHQtaW5rLXNvZnRcIil9PlxuICAgICAgICAgIHtpbWFnZXMubGVuZ3RoID09PSAwID8gdChcImxpc3Qubm9QaG90b3NcIikgOiB0KFwibGlzdC5waG90b0hpbnRcIil9XG4gICAgICAgIDwvcD5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7IWNhblVwbG9hZCAmJiAoXG4gICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC14cyBsZWFkaW5nLXJlbGF4ZWQgdGV4dC13YXJuLTcwMFwiPlxuICAgICAgICAgIHtpc1JlbW90ZSA/IHQoXCJpbnF1aXJ5LnNpZ25JbkZpcnN0XCIpIDogdChcImF1dGgubm9EYXRhYmFzZVwiKX1cbiAgICAgICAgPC9wPlxuICAgICAgKX1cblxuICAgICAge2Vycm9yICYmIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LWRhbmdlci02MDBcIj57ZXJyb3J9PC9wPn1cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiRDovSTJJIFByb2plY3QgLSBIYWJpdG8vQXBwIEZvbGRlci9oYWJpdG8vc3JjL2NvbXBvbmVudHMvc3BhY2UvUGhvdG9VcGxvYWRlci50c3gifQ==