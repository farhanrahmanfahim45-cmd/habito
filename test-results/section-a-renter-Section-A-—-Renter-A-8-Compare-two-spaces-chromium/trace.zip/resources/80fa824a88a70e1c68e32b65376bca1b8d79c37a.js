import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Requests.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=9ceb86a3"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("D:/I2I Project - Habito/App Folder/habito/src/pages/Requests.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9ceb86a3"; const useState = __vite__cjsImport3_react["useState"];
import { Megaphone, Plus } from "/node_modules/.vite/deps/lucide-react.js?v=9ceb86a3";
import { useHabito } from "/src/hooks/useHabito.tsx";
import { PageHeader } from "/src/components/layout/PageHeader.tsx";
import { Button } from "/src/components/ui/Button.tsx";
import { Modal } from "/src/components/ui/Modal.tsx";
import { CATEGORY_STYLE } from "/src/data/catalog.ts";
import { AreaPicker } from "/src/components/ui/AreaPicker.tsx";
import { money, longDate } from "/src/lib/format.ts";
import { CATEGORY_LABEL } from "/src/types/space.ts";
import { cn } from "/src/lib/cn.ts";
import { useI18n } from "/src/i18n/index.tsx";
const inputClass = "h-11 w-full rounded-xl bg-ivory px-3 text-[0.9375rem] text-ink ring-1 ring-hairline-strong focus:outline-none focus:ring-2 focus:ring-aqua-600";
export default function Requests() {
  _s();
  const { t } = useI18n();
  const { requests, addRequest, requirements, role } = useHabito();
  const [open, setOpen] = useState(false);
  const [category, setCategory] = useState(requirements.category);
  const [transaction, setTransaction] = useState("rent");
  const [area, setArea] = useState(requirements.area);
  const [budgetMin, setBudgetMin] = useState(requirements.budgetMin);
  const [budgetMax, setBudgetMax] = useState(requirements.budgetMax);
  const [neededBy, setNeededBy] = useState(requirements.moveInDate);
  const [note, setNote] = useState("");
  const submit = async () => {
    await addRequest({
      category,
      spaceType: "any",
      transaction,
      area,
      budgetMin,
      budgetMax,
      neededBy,
      note: note.trim()
    });
    setOpen(false);
    setNote("");
  };
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(
      PageHeader,
      {
        title: role === "owner" ? "What people are asking for" : "Request a space",
        lead: role === "owner" ? "Open requests from people who haven't found what they need. If you have something close, you already know their budget." : "Can't find it? Post what you need and let owners come to you.",
        actions: /* @__PURE__ */ jsxDEV(Button, { onClick: () => setOpen(true), children: [
          /* @__PURE__ */ jsxDEV(Plus, { size: 16, "aria-hidden": true }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Requests.tsx",
            lineNumber: 80,
            columnNumber: 13
          }, this),
          "Post a request"
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Requests.tsx",
          lineNumber: 79,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Requests.tsx",
        lineNumber: 71,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { className: "container-page py-8 md:py-10", children: requests.length === 0 ? /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col items-center rounded-card bg-surface px-6 py-16 text-center ring-1 ring-hairline", children: [
      /* @__PURE__ */ jsxDEV("span", { className: "mb-4 flex size-12 items-center justify-center rounded-full bg-lilac/50 text-lilac-ink", children: /* @__PURE__ */ jsxDEV(Megaphone, { size: 22, "aria-hidden": true }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Requests.tsx",
        lineNumber: 90,
        columnNumber: 15
      }, this) }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Requests.tsx",
        lineNumber: 89,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("h2", { className: "font-display text-xl font-bold text-ink", children: "No open requests." }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Requests.tsx",
        lineNumber: 92,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "mt-2 max-w-sm text-sm text-muted", children: "Post one and it appears here for owners to answer. Requests are stored on this device." }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Requests.tsx",
        lineNumber: 93,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(Button, { className: "mt-5", onClick: () => setOpen(true), children: "Post a request" }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Requests.tsx",
        lineNumber: 96,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Requests.tsx",
      lineNumber: 88,
      columnNumber: 9
    }, this) : /* @__PURE__ */ jsxDEV("ul", { className: "grid gap-4 sm:grid-cols-2 lg:grid-cols-3", children: requests.map((r) => {
      const style = r.category === "any" ? null : CATEGORY_STYLE[r.category];
      return /* @__PURE__ */ jsxDEV("li", { className: "rounded-card bg-surface p-5 ring-1 ring-hairline", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsxDEV(
            "span",
            {
              className: cn(
                "rounded-full px-2.5 py-1 text-xs font-semibold",
                style ? style.chip : "bg-ivory-deep text-ink-soft"
              ),
              children: r.category === "any" ? "Any space" : CATEGORY_LABEL[r.category]
            },
            void 0,
            false,
            {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Requests.tsx",
              lineNumber: 107,
              columnNumber: 21
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("span", { className: "rounded-full bg-ivory-deep px-2.5 py-1 text-xs font-semibold capitalize text-ink-soft", children: r.transaction === "rent" ? "Renting" : "Buying" }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Requests.tsx",
            lineNumber: 115,
            columnNumber: 21
          }, this)
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Requests.tsx",
          lineNumber: 106,
          columnNumber: 19
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "mt-3 font-display text-lg font-bold text-ink", children: r.area }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Requests.tsx",
          lineNumber: 120,
          columnNumber: 19
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-sm tnum text-ink-soft", children: [
          money(r.budgetMin),
          " – ",
          money(r.budgetMax)
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Requests.tsx",
          lineNumber: 121,
          columnNumber: 19
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-muted", children: [
          "Needed by ",
          longDate(r.neededBy)
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Requests.tsx",
          lineNumber: 124,
          columnNumber: 19
        }, this),
        r.note && /* @__PURE__ */ jsxDEV("p", { className: "mt-3 text-sm leading-relaxed text-ink-soft", children: r.note }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Requests.tsx",
          lineNumber: 126,
          columnNumber: 30
        }, this),
        role === "owner" && /* @__PURE__ */ jsxDEV(Button, { size: "sm", variant: "secondary", className: "mt-4", onClick: () => alert("Replying to requests is part of the next build."), children: "I have something" }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Requests.tsx",
          lineNumber: 129,
          columnNumber: 17
        }, this)
      ] }, r.id, true, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Requests.tsx",
        lineNumber: 105,
        columnNumber: 15
      }, this);
    }) }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Requests.tsx",
      lineNumber: 101,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Requests.tsx",
      lineNumber: 86,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        open,
        onClose: () => setOpen(false),
        title: t("requests.post"),
        footer: /* @__PURE__ */ jsxDEV("div", { className: "flex gap-2", children: [
          /* @__PURE__ */ jsxDEV(Button, { variant: "secondary", fullWidth: true, onClick: () => setOpen(false), children: "Cancel" }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Requests.tsx",
            lineNumber: 146,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(Button, { fullWidth: true, onClick: () => void submit(), children: "Post" }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Requests.tsx",
            lineNumber: 149,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Requests.tsx",
          lineNumber: 145,
          columnNumber: 9
        }, this),
        children: /* @__PURE__ */ jsxDEV("div", { className: "space-y-4", children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "mb-1.5 block text-sm font-medium text-ink-soft", children: "What kind of space" }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Requests.tsx",
              lineNumber: 157,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("select", { value: category, onChange: (e) => setCategory(e.target.value), className: inputClass, children: [
              /* @__PURE__ */ jsxDEV("option", { value: "any", children: "Anything" }, void 0, false, {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Requests.tsx",
                lineNumber: 159,
                columnNumber: 15
              }, this),
              Object.keys(CATEGORY_STYLE).map(
                (c) => /* @__PURE__ */ jsxDEV("option", { value: c, children: CATEGORY_LABEL[c] }, c, false, {
                  fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Requests.tsx",
                  lineNumber: 161,
                  columnNumber: 15
                }, this)
              )
            ] }, void 0, true, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Requests.tsx",
              lineNumber: 158,
              columnNumber: 13
            }, this)
          ] }, void 0, true, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Requests.tsx",
            lineNumber: 156,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV("label", { className: "block", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "mb-1.5 block text-sm font-medium text-ink-soft", children: "Renting or buying" }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Requests.tsx",
              lineNumber: 169,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("select", { value: transaction, onChange: (e) => setTransaction(e.target.value), className: inputClass, children: [
              /* @__PURE__ */ jsxDEV("option", { value: "rent", children: "Renting" }, void 0, false, {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Requests.tsx",
                lineNumber: 171,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("option", { value: "sale", children: "Buying" }, void 0, false, {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Requests.tsx",
                lineNumber: 172,
                columnNumber: 15
              }, this)
            ] }, void 0, true, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Requests.tsx",
              lineNumber: 170,
              columnNumber: 13
            }, this)
          ] }, void 0, true, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Requests.tsx",
            lineNumber: 168,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV("label", { className: "block", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "mb-1.5 block text-sm font-medium text-ink-soft", children: "Where" }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Requests.tsx",
              lineNumber: 177,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV(AreaPicker, { value: area, onChange: setArea }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Requests.tsx",
              lineNumber: 178,
              columnNumber: 13
            }, this)
          ] }, void 0, true, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Requests.tsx",
            lineNumber: 176,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-3", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "mb-1.5 block text-sm font-medium text-ink-soft", children: "Budget from" }, void 0, false, {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Requests.tsx",
                lineNumber: 183,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("input", { type: "number", step: 500, value: budgetMin, onChange: (e) => setBudgetMin(Number(e.target.value)), className: cn(inputClass, "tnum") }, void 0, false, {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Requests.tsx",
                lineNumber: 184,
                columnNumber: 15
              }, this)
            ] }, void 0, true, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Requests.tsx",
              lineNumber: 182,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("label", { className: "block", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "mb-1.5 block text-sm font-medium text-ink-soft", children: "Up to" }, void 0, false, {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Requests.tsx",
                lineNumber: 187,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("input", { type: "number", step: 500, value: budgetMax, onChange: (e) => setBudgetMax(Number(e.target.value)), className: cn(inputClass, "tnum") }, void 0, false, {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Requests.tsx",
                lineNumber: 188,
                columnNumber: 15
              }, this)
            ] }, void 0, true, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Requests.tsx",
              lineNumber: 186,
              columnNumber: 13
            }, this)
          ] }, void 0, true, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Requests.tsx",
            lineNumber: 181,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV("label", { className: "block", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "mb-1.5 block text-sm font-medium text-ink-soft", children: "Needed by" }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Requests.tsx",
              lineNumber: 193,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("input", { type: "date", value: neededBy, onChange: (e) => setNeededBy(e.target.value), className: inputClass }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Requests.tsx",
              lineNumber: 194,
              columnNumber: 13
            }, this)
          ] }, void 0, true, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Requests.tsx",
            lineNumber: 192,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV("label", { className: "block", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "mb-1.5 block text-sm font-medium text-ink-soft", children: "Anything else" }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Requests.tsx",
              lineNumber: 198,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV(
              "textarea",
              {
                rows: 3,
                value: note,
                onChange: (e) => setNote(e.target.value),
                placeholder: "e.g. ground floor preferred, near the main road",
                className: "w-full rounded-xl bg-ivory p-3 text-[0.9375rem] ring-1 ring-hairline-strong focus:outline-none focus:ring-2 focus:ring-aqua-600"
              },
              void 0,
              false,
              {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Requests.tsx",
                lineNumber: 199,
                columnNumber: 13
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Requests.tsx",
            lineNumber: 197,
            columnNumber: 11
          }, this)
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Requests.tsx",
          lineNumber: 155,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Requests.tsx",
        lineNumber: 140,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Requests.tsx",
    lineNumber: 70,
    columnNumber: 5
  }, this);
}
_s(Requests, "8BQThCNXFfazOWRRj7QNI8gPFVc=", false, function() {
  return [useI18n, useHabito];
});
_c = Requests;
var _c;
$RefreshReg$(_c, "Requests");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/I2I Project - Habito/App Folder/habito/src/pages/Requests.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/I2I Project - Habito/App Folder/habito/src/pages/Requests.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa0RJLG1CQVVRLGNBVlI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBbERKLFNBQVNBLGdCQUFnQjtBQUN6QixTQUFTQyxXQUFXQyxZQUFZO0FBQ2hDLFNBQVNDLGlCQUFpQjtBQUMxQixTQUFTQyxrQkFBa0I7QUFDM0IsU0FBU0MsY0FBYztBQUN2QixTQUFTQyxhQUFhO0FBQ3RCLFNBQVNDLHNCQUFzQjtBQUMvQixTQUFTQyxrQkFBa0I7QUFDM0IsU0FBU0MsT0FBT0MsZ0JBQWdCO0FBQ2hDLFNBQVNDLHNCQUFzQjtBQUUvQixTQUFTQyxVQUFVO0FBQ25CLFNBQVNDLGVBQWU7QUFFeEIsTUFBTUMsYUFDSjtBQU1GLHdCQUF3QkMsV0FBVztBQUFBQyxLQUFBO0FBQ2pDLFFBQU0sRUFBRUMsRUFBRSxJQUFJSixRQUFRO0FBQ3RCLFFBQU0sRUFBRUssVUFBVUMsWUFBWUMsY0FBY0MsS0FBSyxJQUFJbEIsVUFBVTtBQUMvRCxRQUFNLENBQUNtQixNQUFNQyxPQUFPLElBQUl2QixTQUFTLEtBQUs7QUFFdEMsUUFBTSxDQUFDd0IsVUFBVUMsV0FBVyxJQUFJekIsU0FBZ0NvQixhQUFhSSxRQUFRO0FBQ3JGLFFBQU0sQ0FBQ0UsYUFBYUMsY0FBYyxJQUFJM0IsU0FBMEIsTUFBTTtBQUN0RSxRQUFNLENBQUM0QixNQUFNQyxPQUFPLElBQUk3QixTQUFTb0IsYUFBYVEsSUFBSTtBQUNsRCxRQUFNLENBQUNFLFdBQVdDLFlBQVksSUFBSS9CLFNBQVNvQixhQUFhVSxTQUFTO0FBQ2pFLFFBQU0sQ0FBQ0UsV0FBV0MsWUFBWSxJQUFJakMsU0FBU29CLGFBQWFZLFNBQVM7QUFDakUsUUFBTSxDQUFDRSxVQUFVQyxXQUFXLElBQUluQyxTQUFTb0IsYUFBYWdCLFVBQVU7QUFDaEUsUUFBTSxDQUFDQyxNQUFNQyxPQUFPLElBQUl0QyxTQUFTLEVBQUU7QUFFbkMsUUFBTXVDLFNBQVMsWUFBWTtBQUN6QixVQUFNcEIsV0FBVztBQUFBLE1BQ2ZLO0FBQUFBLE1BQ0FnQixXQUFXO0FBQUEsTUFDWGQ7QUFBQUEsTUFDQUU7QUFBQUEsTUFDQUU7QUFBQUEsTUFDQUU7QUFBQUEsTUFDQUU7QUFBQUEsTUFDQUcsTUFBTUEsS0FBS0ksS0FBSztBQUFBLElBQ2xCLENBQUM7QUFDRGxCLFlBQVEsS0FBSztBQUNiZSxZQUFRLEVBQUU7QUFBQSxFQUNaO0FBRUEsU0FDRSxtQ0FDRTtBQUFBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxPQUFPakIsU0FBUyxVQUFVLCtCQUErQjtBQUFBLFFBQ3pELE1BQ0VBLFNBQVMsVUFDTCw0SEFDQTtBQUFBLFFBRU4sU0FDRSx1QkFBQyxVQUFPLFNBQVMsTUFBTUUsUUFBUSxJQUFJLEdBQ2pDO0FBQUEsaUNBQUMsUUFBSyxNQUFNLElBQUksZUFBVyxRQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEyQjtBQUFBO0FBQUEsYUFEN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUE7QUFBQSxNQVhKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQVlHO0FBQUEsSUFHSCx1QkFBQyxTQUFJLFdBQVUsZ0NBQ1pMLG1CQUFTd0IsV0FBVyxJQUNuQix1QkFBQyxTQUFJLFdBQVUsa0dBQ2I7QUFBQSw2QkFBQyxVQUFLLFdBQVUseUZBQ2QsaUNBQUMsYUFBVSxNQUFNLElBQUksZUFBVyxRQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWdDLEtBRGxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsUUFBRyxXQUFVLDJDQUEwQyxpQ0FBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF5RTtBQUFBLE1BQ3pFLHVCQUFDLE9BQUUsV0FBVSxvQ0FBa0Msc0dBQS9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsVUFBTyxXQUFVLFFBQU8sU0FBUyxNQUFNbkIsUUFBUSxJQUFJLEdBQUUsOEJBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVdBLElBRUEsdUJBQUMsUUFBRyxXQUFVLDRDQUNYTCxtQkFBU3lCLElBQUksQ0FBQ0MsTUFBTTtBQUNuQixZQUFNQyxRQUFRRCxFQUFFcEIsYUFBYSxRQUFRLE9BQU9qQixlQUFlcUMsRUFBRXBCLFFBQVE7QUFDckUsYUFDRSx1QkFBQyxRQUFjLFdBQVUsb0RBQ3ZCO0FBQUEsK0JBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFdBQVdaO0FBQUFBLGdCQUNUO0FBQUEsZ0JBQ0FpQyxRQUFRQSxNQUFNQyxPQUFPO0FBQUEsY0FDdkI7QUFBQSxjQUVDRixZQUFFcEIsYUFBYSxRQUFRLGNBQWNiLGVBQWVpQyxFQUFFcEIsUUFBUTtBQUFBO0FBQUEsWUFOakU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBT0E7QUFBQSxVQUNBLHVCQUFDLFVBQUssV0FBVSx5RkFDYm9CLFlBQUVsQixnQkFBZ0IsU0FBUyxZQUFZLFlBRDFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFZQTtBQUFBLFFBRUEsdUJBQUMsT0FBRSxXQUFVLGdEQUFnRGtCLFlBQUVoQixRQUEvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW9FO0FBQUEsUUFDcEUsdUJBQUMsT0FBRSxXQUFVLDhCQUNWbkI7QUFBQUEsZ0JBQU1tQyxFQUFFZCxTQUFTO0FBQUEsVUFBRTtBQUFBLFVBQUlyQixNQUFNbUMsRUFBRVosU0FBUztBQUFBLGFBRDNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsT0FBRSxXQUFVLDJCQUEwQjtBQUFBO0FBQUEsVUFBV3RCLFNBQVNrQyxFQUFFVixRQUFRO0FBQUEsYUFBckU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1RTtBQUFBLFFBRXRFVSxFQUFFUCxRQUFRLHVCQUFDLE9BQUUsV0FBVSw4Q0FBOENPLFlBQUVQLFFBQTdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0U7QUFBQSxRQUU1RWhCLFNBQVMsV0FDUix1QkFBQyxVQUFPLE1BQUssTUFBSyxTQUFRLGFBQVksV0FBVSxRQUFPLFNBQVMsTUFBTTBCLE1BQU0saURBQWlELEdBQUUsZ0NBQS9IO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBMUJLSCxFQUFFSSxJQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUE0QkE7QUFBQSxJQUVKLENBQUMsS0FsQ0g7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW1DQSxLQWxESjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBb0RBO0FBQUEsSUFFQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0M7QUFBQSxRQUNBLFNBQVMsTUFBTXpCLFFBQVEsS0FBSztBQUFBLFFBQzVCLE9BQU9OLEVBQUUsZUFBZTtBQUFBLFFBQ3hCLFFBQ0UsdUJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSxpQ0FBQyxVQUFPLFNBQVEsYUFBWSxXQUFTLE1BQUMsU0FBUyxNQUFNTSxRQUFRLEtBQUssR0FBRSxzQkFBcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsVUFBTyxXQUFTLE1BQUMsU0FBUyxNQUFNLEtBQUtnQixPQUFPLEdBQUUsb0JBQS9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFPQTtBQUFBLFFBR0YsaUNBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSxpQ0FBQyxXQUFNLFdBQVUsU0FDZjtBQUFBLG1DQUFDLFVBQUssV0FBVSxrREFBaUQsa0NBQWpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW1GO0FBQUEsWUFDbkYsdUJBQUMsWUFBTyxPQUFPZixVQUFVLFVBQVUsQ0FBQ3lCLE1BQU14QixZQUFZd0IsRUFBRUMsT0FBT0MsS0FBOEIsR0FBRyxXQUFXckMsWUFDekc7QUFBQSxxQ0FBQyxZQUFPLE9BQU0sT0FBTSx3QkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNEI7QUFBQSxjQUMxQnNDLE9BQU9DLEtBQUs5QyxjQUFjLEVBQXNCb0M7QUFBQUEsZ0JBQUksQ0FBQ1csTUFDckQsdUJBQUMsWUFBZSxPQUFPQSxHQUNwQjNDLHlCQUFlMkMsQ0FBQyxLQUROQSxHQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxjQUNEO0FBQUEsaUJBTkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFPQTtBQUFBLGVBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFVQTtBQUFBLFVBRUEsdUJBQUMsV0FBTSxXQUFVLFNBQ2Y7QUFBQSxtQ0FBQyxVQUFLLFdBQVUsa0RBQWlELGlDQUFqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFrRjtBQUFBLFlBQ2xGLHVCQUFDLFlBQU8sT0FBTzVCLGFBQWEsVUFBVSxDQUFDdUIsTUFBTXRCLGVBQWVzQixFQUFFQyxPQUFPQyxLQUF3QixHQUFHLFdBQVdyQyxZQUN6RztBQUFBLHFDQUFDLFlBQU8sT0FBTSxRQUFPLHVCQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE0QjtBQUFBLGNBQzVCLHVCQUFDLFlBQU8sT0FBTSxRQUFPLHNCQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEyQjtBQUFBLGlCQUY3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUEsZUFMRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU1BO0FBQUEsVUFFQSx1QkFBQyxXQUFNLFdBQVUsU0FDZjtBQUFBLG1DQUFDLFVBQUssV0FBVSxrREFBaUQscUJBQWpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXNFO0FBQUEsWUFDdEUsdUJBQUMsY0FBVyxPQUFPYyxNQUFNLFVBQVVDLFdBQW5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTJDO0FBQUEsZUFGN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFVBRUEsdUJBQUMsU0FBSSxXQUFVLDBCQUNiO0FBQUEsbUNBQUMsV0FBTSxXQUFVLFNBQ2Y7QUFBQSxxQ0FBQyxVQUFLLFdBQVUsa0RBQWlELDJCQUFqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE0RTtBQUFBLGNBQzVFLHVCQUFDLFdBQU0sTUFBSyxVQUFTLE1BQU0sS0FBSyxPQUFPQyxXQUFXLFVBQVUsQ0FBQ21CLE1BQU1sQixhQUFhd0IsT0FBT04sRUFBRUMsT0FBT0MsS0FBSyxDQUFDLEdBQUcsV0FBV3ZDLEdBQUdFLFlBQVksTUFBTSxLQUF6STtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEySTtBQUFBLGlCQUY3STtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUEsWUFDQSx1QkFBQyxXQUFNLFdBQVUsU0FDZjtBQUFBLHFDQUFDLFVBQUssV0FBVSxrREFBaUQscUJBQWpFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXNFO0FBQUEsY0FDdEUsdUJBQUMsV0FBTSxNQUFLLFVBQVMsTUFBTSxLQUFLLE9BQU9rQixXQUFXLFVBQVUsQ0FBQ2lCLE1BQU1oQixhQUFhc0IsT0FBT04sRUFBRUMsT0FBT0MsS0FBSyxDQUFDLEdBQUcsV0FBV3ZDLEdBQUdFLFlBQVksTUFBTSxLQUF6STtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEySTtBQUFBLGlCQUY3STtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUEsZUFSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVNBO0FBQUEsVUFFQSx1QkFBQyxXQUFNLFdBQVUsU0FDZjtBQUFBLG1DQUFDLFVBQUssV0FBVSxrREFBaUQseUJBQWpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTBFO0FBQUEsWUFDMUUsdUJBQUMsV0FBTSxNQUFLLFFBQU8sT0FBT29CLFVBQVUsVUFBVSxDQUFDZSxNQUFNZCxZQUFZYyxFQUFFQyxPQUFPQyxLQUFLLEdBQUcsV0FBV3JDLGNBQTdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXdHO0FBQUEsZUFGMUc7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFVBRUEsdUJBQUMsV0FBTSxXQUFVLFNBQ2Y7QUFBQSxtQ0FBQyxVQUFLLFdBQVUsa0RBQWlELDZCQUFqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE4RTtBQUFBLFlBQzlFO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBTTtBQUFBLGdCQUNOLE9BQU91QjtBQUFBQSxnQkFDUCxVQUFVLENBQUNZLE1BQU1YLFFBQVFXLEVBQUVDLE9BQU9DLEtBQUs7QUFBQSxnQkFDdkMsYUFBWTtBQUFBLGdCQUNaLFdBQVU7QUFBQTtBQUFBLGNBTFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBSzZJO0FBQUEsZUFQL0k7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFTQTtBQUFBLGFBbkRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFvREE7QUFBQTtBQUFBLE1BbkVGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQW9FQTtBQUFBLE9BMUlGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0EySUE7QUFFSjtBQUFDbkMsR0ExS3VCRCxVQUFRO0FBQUEsVUFDaEJGLFNBQ3VDVixTQUFTO0FBQUE7QUFBQSxLQUZ4Q1k7QUFBUSxJQUFBeUM7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJNZWdhcGhvbmUiLCJQbHVzIiwidXNlSGFiaXRvIiwiUGFnZUhlYWRlciIsIkJ1dHRvbiIsIk1vZGFsIiwiQ0FURUdPUllfU1RZTEUiLCJBcmVhUGlja2VyIiwibW9uZXkiLCJsb25nRGF0ZSIsIkNBVEVHT1JZX0xBQkVMIiwiY24iLCJ1c2VJMThuIiwiaW5wdXRDbGFzcyIsIlJlcXVlc3RzIiwiX3MiLCJ0IiwicmVxdWVzdHMiLCJhZGRSZXF1ZXN0IiwicmVxdWlyZW1lbnRzIiwicm9sZSIsIm9wZW4iLCJzZXRPcGVuIiwiY2F0ZWdvcnkiLCJzZXRDYXRlZ29yeSIsInRyYW5zYWN0aW9uIiwic2V0VHJhbnNhY3Rpb24iLCJhcmVhIiwic2V0QXJlYSIsImJ1ZGdldE1pbiIsInNldEJ1ZGdldE1pbiIsImJ1ZGdldE1heCIsInNldEJ1ZGdldE1heCIsIm5lZWRlZEJ5Iiwic2V0TmVlZGVkQnkiLCJtb3ZlSW5EYXRlIiwibm90ZSIsInNldE5vdGUiLCJzdWJtaXQiLCJzcGFjZVR5cGUiLCJ0cmltIiwibGVuZ3RoIiwibWFwIiwiciIsInN0eWxlIiwiY2hpcCIsImFsZXJ0IiwiaWQiLCJlIiwidGFyZ2V0IiwidmFsdWUiLCJPYmplY3QiLCJrZXlzIiwiYyIsIk51bWJlciIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlJlcXVlc3RzLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgTWVnYXBob25lLCBQbHVzIH0gZnJvbSBcImx1Y2lkZS1yZWFjdFwiO1xuaW1wb3J0IHsgdXNlSGFiaXRvIH0gZnJvbSBcIkAvaG9va3MvdXNlSGFiaXRvXCI7XG5pbXBvcnQgeyBQYWdlSGVhZGVyIH0gZnJvbSBcIkAvY29tcG9uZW50cy9sYXlvdXQvUGFnZUhlYWRlclwiO1xuaW1wb3J0IHsgQnV0dG9uIH0gZnJvbSBcIkAvY29tcG9uZW50cy91aS9CdXR0b25cIjtcbmltcG9ydCB7IE1vZGFsIH0gZnJvbSBcIkAvY29tcG9uZW50cy91aS9Nb2RhbFwiO1xuaW1wb3J0IHsgQ0FURUdPUllfU1RZTEUgfSBmcm9tIFwiQC9kYXRhL2NhdGFsb2dcIjtcbmltcG9ydCB7IEFyZWFQaWNrZXIgfSBmcm9tIFwiQC9jb21wb25lbnRzL3VpL0FyZWFQaWNrZXJcIjtcbmltcG9ydCB7IG1vbmV5LCBsb25nRGF0ZSB9IGZyb20gXCJAL2xpYi9mb3JtYXRcIjtcbmltcG9ydCB7IENBVEVHT1JZX0xBQkVMIH0gZnJvbSBcIkAvdHlwZXMvc3BhY2VcIjtcbmltcG9ydCB0eXBlIHsgU3BhY2VDYXRlZ29yeSwgVHJhbnNhY3Rpb25UeXBlIH0gZnJvbSBcIkAvdHlwZXMvc3BhY2VcIjtcbmltcG9ydCB7IGNuIH0gZnJvbSBcIkAvbGliL2NuXCI7XG5pbXBvcnQgeyB1c2VJMThuIH0gZnJvbSBcIkAvaTE4blwiO1xuXG5jb25zdCBpbnB1dENsYXNzID1cbiAgXCJoLTExIHctZnVsbCByb3VuZGVkLXhsIGJnLWl2b3J5IHB4LTMgdGV4dC1bMC45Mzc1cmVtXSB0ZXh0LWluayByaW5nLTEgcmluZy1oYWlybGluZS1zdHJvbmcgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWFxdWEtNjAwXCI7XG5cbi8qKlxuICogVGhlIGRlbWFuZCBzaWRlLiBTdXBwbHkgaXMgbGlzdGluZ3M7IHRoaXMgaXMgcGVvcGxlIHNheWluZyB3aGF0IHRoZXkgbmVlZCxcbiAqIHdoaWNoIG93bmVycyBjYW4gdGhlbiBhbnN3ZXIuXG4gKi9cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFJlcXVlc3RzKCkge1xuICBjb25zdCB7IHQgfSA9IHVzZUkxOG4oKTtcbiAgY29uc3QgeyByZXF1ZXN0cywgYWRkUmVxdWVzdCwgcmVxdWlyZW1lbnRzLCByb2xlIH0gPSB1c2VIYWJpdG8oKTtcbiAgY29uc3QgW29wZW4sIHNldE9wZW5dID0gdXNlU3RhdGUoZmFsc2UpO1xuXG4gIGNvbnN0IFtjYXRlZ29yeSwgc2V0Q2F0ZWdvcnldID0gdXNlU3RhdGU8U3BhY2VDYXRlZ29yeSB8IFwiYW55XCI+KHJlcXVpcmVtZW50cy5jYXRlZ29yeSk7XG4gIGNvbnN0IFt0cmFuc2FjdGlvbiwgc2V0VHJhbnNhY3Rpb25dID0gdXNlU3RhdGU8VHJhbnNhY3Rpb25UeXBlPihcInJlbnRcIik7XG4gIGNvbnN0IFthcmVhLCBzZXRBcmVhXSA9IHVzZVN0YXRlKHJlcXVpcmVtZW50cy5hcmVhKTtcbiAgY29uc3QgW2J1ZGdldE1pbiwgc2V0QnVkZ2V0TWluXSA9IHVzZVN0YXRlKHJlcXVpcmVtZW50cy5idWRnZXRNaW4pO1xuICBjb25zdCBbYnVkZ2V0TWF4LCBzZXRCdWRnZXRNYXhdID0gdXNlU3RhdGUocmVxdWlyZW1lbnRzLmJ1ZGdldE1heCk7XG4gIGNvbnN0IFtuZWVkZWRCeSwgc2V0TmVlZGVkQnldID0gdXNlU3RhdGUocmVxdWlyZW1lbnRzLm1vdmVJbkRhdGUpO1xuICBjb25zdCBbbm90ZSwgc2V0Tm90ZV0gPSB1c2VTdGF0ZShcIlwiKTtcblxuICBjb25zdCBzdWJtaXQgPSBhc3luYyAoKSA9PiB7XG4gICAgYXdhaXQgYWRkUmVxdWVzdCh7XG4gICAgICBjYXRlZ29yeSxcbiAgICAgIHNwYWNlVHlwZTogXCJhbnlcIixcbiAgICAgIHRyYW5zYWN0aW9uLFxuICAgICAgYXJlYSxcbiAgICAgIGJ1ZGdldE1pbixcbiAgICAgIGJ1ZGdldE1heCxcbiAgICAgIG5lZWRlZEJ5LFxuICAgICAgbm90ZTogbm90ZS50cmltKCksXG4gICAgfSk7XG4gICAgc2V0T3BlbihmYWxzZSk7XG4gICAgc2V0Tm90ZShcIlwiKTtcbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDw+XG4gICAgICA8UGFnZUhlYWRlclxuICAgICAgICB0aXRsZT17cm9sZSA9PT0gXCJvd25lclwiID8gXCJXaGF0IHBlb3BsZSBhcmUgYXNraW5nIGZvclwiIDogXCJSZXF1ZXN0IGEgc3BhY2VcIn1cbiAgICAgICAgbGVhZD17XG4gICAgICAgICAgcm9sZSA9PT0gXCJvd25lclwiXG4gICAgICAgICAgICA/IFwiT3BlbiByZXF1ZXN0cyBmcm9tIHBlb3BsZSB3aG8gaGF2ZW4ndCBmb3VuZCB3aGF0IHRoZXkgbmVlZC4gSWYgeW91IGhhdmUgc29tZXRoaW5nIGNsb3NlLCB5b3UgYWxyZWFkeSBrbm93IHRoZWlyIGJ1ZGdldC5cIlxuICAgICAgICAgICAgOiBcIkNhbid0IGZpbmQgaXQ/IFBvc3Qgd2hhdCB5b3UgbmVlZCBhbmQgbGV0IG93bmVycyBjb21lIHRvIHlvdS5cIlxuICAgICAgICB9XG4gICAgICAgIGFjdGlvbnM9e1xuICAgICAgICAgIDxCdXR0b24gb25DbGljaz17KCkgPT4gc2V0T3Blbih0cnVlKX0+XG4gICAgICAgICAgICA8UGx1cyBzaXplPXsxNn0gYXJpYS1oaWRkZW4gLz5cbiAgICAgICAgICAgIFBvc3QgYSByZXF1ZXN0XG4gICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgIH1cbiAgICAgIC8+XG5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29udGFpbmVyLXBhZ2UgcHktOCBtZDpweS0xMFwiPlxuICAgICAgICB7cmVxdWVzdHMubGVuZ3RoID09PSAwID8gKFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIgcm91bmRlZC1jYXJkIGJnLXN1cmZhY2UgcHgtNiBweS0xNiB0ZXh0LWNlbnRlciByaW5nLTEgcmluZy1oYWlybGluZVwiPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWItNCBmbGV4IHNpemUtMTIgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHJvdW5kZWQtZnVsbCBiZy1saWxhYy81MCB0ZXh0LWxpbGFjLWlua1wiPlxuICAgICAgICAgICAgICA8TWVnYXBob25lIHNpemU9ezIyfSBhcmlhLWhpZGRlbiAvPlxuICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cImZvbnQtZGlzcGxheSB0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LWlua1wiPk5vIG9wZW4gcmVxdWVzdHMuPC9oMj5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgbWF4LXctc20gdGV4dC1zbSB0ZXh0LW11dGVkXCI+XG4gICAgICAgICAgICAgIFBvc3Qgb25lIGFuZCBpdCBhcHBlYXJzIGhlcmUgZm9yIG93bmVycyB0byBhbnN3ZXIuIFJlcXVlc3RzIGFyZSBzdG9yZWQgb24gdGhpcyBkZXZpY2UuXG4gICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICA8QnV0dG9uIGNsYXNzTmFtZT1cIm10LTVcIiBvbkNsaWNrPXsoKSA9PiBzZXRPcGVuKHRydWUpfT5cbiAgICAgICAgICAgICAgUG9zdCBhIHJlcXVlc3RcbiAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICApIDogKFxuICAgICAgICAgIDx1bCBjbGFzc05hbWU9XCJncmlkIGdhcC00IHNtOmdyaWQtY29scy0yIGxnOmdyaWQtY29scy0zXCI+XG4gICAgICAgICAgICB7cmVxdWVzdHMubWFwKChyKSA9PiB7XG4gICAgICAgICAgICAgIGNvbnN0IHN0eWxlID0gci5jYXRlZ29yeSA9PT0gXCJhbnlcIiA/IG51bGwgOiBDQVRFR09SWV9TVFlMRVtyLmNhdGVnb3J5XTtcbiAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICA8bGkga2V5PXtyLmlkfSBjbGFzc05hbWU9XCJyb3VuZGVkLWNhcmQgYmctc3VyZmFjZSBwLTUgcmluZy0xIHJpbmctaGFpcmxpbmVcIj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW5cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgICAgICAgICAgICAgICAgICAgXCJyb3VuZGVkLWZ1bGwgcHgtMi41IHB5LTEgdGV4dC14cyBmb250LXNlbWlib2xkXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICBzdHlsZSA/IHN0eWxlLmNoaXAgOiBcImJnLWl2b3J5LWRlZXAgdGV4dC1pbmstc29mdFwiLFxuICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICB7ci5jYXRlZ29yeSA9PT0gXCJhbnlcIiA/IFwiQW55IHNwYWNlXCIgOiBDQVRFR09SWV9MQUJFTFtyLmNhdGVnb3J5XX1cbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJyb3VuZGVkLWZ1bGwgYmctaXZvcnktZGVlcCBweC0yLjUgcHktMSB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgY2FwaXRhbGl6ZSB0ZXh0LWluay1zb2Z0XCI+XG4gICAgICAgICAgICAgICAgICAgICAge3IudHJhbnNhY3Rpb24gPT09IFwicmVudFwiID8gXCJSZW50aW5nXCIgOiBcIkJ1eWluZ1wifVxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMyBmb250LWRpc3BsYXkgdGV4dC1sZyBmb250LWJvbGQgdGV4dC1pbmtcIj57ci5hcmVhfTwvcD5cbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdG51bSB0ZXh0LWluay1zb2Z0XCI+XG4gICAgICAgICAgICAgICAgICAgIHttb25leShyLmJ1ZGdldE1pbil9IOKAkyB7bW9uZXkoci5idWRnZXRNYXgpfVxuICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXNtIHRleHQtbXV0ZWRcIj5OZWVkZWQgYnkge2xvbmdEYXRlKHIubmVlZGVkQnkpfTwvcD5cblxuICAgICAgICAgICAgICAgICAge3Iubm90ZSAmJiA8cCBjbGFzc05hbWU9XCJtdC0zIHRleHQtc20gbGVhZGluZy1yZWxheGVkIHRleHQtaW5rLXNvZnRcIj57ci5ub3RlfTwvcD59XG5cbiAgICAgICAgICAgICAgICAgIHtyb2xlID09PSBcIm93bmVyXCIgJiYgKFxuICAgICAgICAgICAgICAgICAgICA8QnV0dG9uIHNpemU9XCJzbVwiIHZhcmlhbnQ9XCJzZWNvbmRhcnlcIiBjbGFzc05hbWU9XCJtdC00XCIgb25DbGljaz17KCkgPT4gYWxlcnQoXCJSZXBseWluZyB0byByZXF1ZXN0cyBpcyBwYXJ0IG9mIHRoZSBuZXh0IGJ1aWxkLlwiKX0+XG4gICAgICAgICAgICAgICAgICAgICAgSSBoYXZlIHNvbWV0aGluZ1xuICAgICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgIH0pfVxuICAgICAgICAgIDwvdWw+XG4gICAgICAgICl9XG4gICAgICA8L2Rpdj5cblxuICAgICAgPE1vZGFsXG4gICAgICAgIG9wZW49e29wZW59XG4gICAgICAgIG9uQ2xvc2U9eygpID0+IHNldE9wZW4oZmFsc2UpfVxuICAgICAgICB0aXRsZT17dChcInJlcXVlc3RzLnBvc3RcIil9XG4gICAgICAgIGZvb3Rlcj17XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC0yXCI+XG4gICAgICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJzZWNvbmRhcnlcIiBmdWxsV2lkdGggb25DbGljaz17KCkgPT4gc2V0T3BlbihmYWxzZSl9PlxuICAgICAgICAgICAgICBDYW5jZWxcbiAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgPEJ1dHRvbiBmdWxsV2lkdGggb25DbGljaz17KCkgPT4gdm9pZCBzdWJtaXQoKX0+XG4gICAgICAgICAgICAgIFBvc3RcbiAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICB9XG4gICAgICA+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS00XCI+XG4gICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrXCI+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtYi0xLjUgYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWluay1zb2Z0XCI+V2hhdCBraW5kIG9mIHNwYWNlPC9zcGFuPlxuICAgICAgICAgICAgPHNlbGVjdCB2YWx1ZT17Y2F0ZWdvcnl9IG9uQ2hhbmdlPXsoZSkgPT4gc2V0Q2F0ZWdvcnkoZS50YXJnZXQudmFsdWUgYXMgU3BhY2VDYXRlZ29yeSB8IFwiYW55XCIpfSBjbGFzc05hbWU9e2lucHV0Q2xhc3N9PlxuICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiYW55XCI+QW55dGhpbmc8L29wdGlvbj5cbiAgICAgICAgICAgICAgeyhPYmplY3Qua2V5cyhDQVRFR09SWV9TVFlMRSkgYXMgU3BhY2VDYXRlZ29yeVtdKS5tYXAoKGMpID0+IChcbiAgICAgICAgICAgICAgICA8b3B0aW9uIGtleT17Y30gdmFsdWU9e2N9PlxuICAgICAgICAgICAgICAgICAge0NBVEVHT1JZX0xBQkVMW2NdfVxuICAgICAgICAgICAgICAgIDwvb3B0aW9uPlxuICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgIDwvbGFiZWw+XG5cbiAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2tcIj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1iLTEuNSBibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtaW5rLXNvZnRcIj5SZW50aW5nIG9yIGJ1eWluZzwvc3Bhbj5cbiAgICAgICAgICAgIDxzZWxlY3QgdmFsdWU9e3RyYW5zYWN0aW9ufSBvbkNoYW5nZT17KGUpID0+IHNldFRyYW5zYWN0aW9uKGUudGFyZ2V0LnZhbHVlIGFzIFRyYW5zYWN0aW9uVHlwZSl9IGNsYXNzTmFtZT17aW5wdXRDbGFzc30+XG4gICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJyZW50XCI+UmVudGluZzwvb3B0aW9uPlxuICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwic2FsZVwiPkJ1eWluZzwvb3B0aW9uPlxuICAgICAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgICAgPC9sYWJlbD5cblxuICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9ja1wiPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWItMS41IGJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1pbmstc29mdFwiPldoZXJlPC9zcGFuPlxuICAgICAgICAgICAgPEFyZWFQaWNrZXIgdmFsdWU9e2FyZWF9IG9uQ2hhbmdlPXtzZXRBcmVhfSAvPlxuICAgICAgICAgIDwvbGFiZWw+XG5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTNcIj5cbiAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9ja1wiPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtYi0xLjUgYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWluay1zb2Z0XCI+QnVkZ2V0IGZyb208L3NwYW4+XG4gICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwibnVtYmVyXCIgc3RlcD17NTAwfSB2YWx1ZT17YnVkZ2V0TWlufSBvbkNoYW5nZT17KGUpID0+IHNldEJ1ZGdldE1pbihOdW1iZXIoZS50YXJnZXQudmFsdWUpKX0gY2xhc3NOYW1lPXtjbihpbnB1dENsYXNzLCBcInRudW1cIil9IC8+XG4gICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrXCI+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1iLTEuNSBibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtaW5rLXNvZnRcIj5VcCB0bzwvc3Bhbj5cbiAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJudW1iZXJcIiBzdGVwPXs1MDB9IHZhbHVlPXtidWRnZXRNYXh9IG9uQ2hhbmdlPXsoZSkgPT4gc2V0QnVkZ2V0TWF4KE51bWJlcihlLnRhcmdldC52YWx1ZSkpfSBjbGFzc05hbWU9e2NuKGlucHV0Q2xhc3MsIFwidG51bVwiKX0gLz5cbiAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2tcIj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1iLTEuNSBibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtaW5rLXNvZnRcIj5OZWVkZWQgYnk8L3NwYW4+XG4gICAgICAgICAgICA8aW5wdXQgdHlwZT1cImRhdGVcIiB2YWx1ZT17bmVlZGVkQnl9IG9uQ2hhbmdlPXsoZSkgPT4gc2V0TmVlZGVkQnkoZS50YXJnZXQudmFsdWUpfSBjbGFzc05hbWU9e2lucHV0Q2xhc3N9IC8+XG4gICAgICAgICAgPC9sYWJlbD5cblxuICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9ja1wiPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWItMS41IGJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1pbmstc29mdFwiPkFueXRoaW5nIGVsc2U8L3NwYW4+XG4gICAgICAgICAgICA8dGV4dGFyZWFcbiAgICAgICAgICAgICAgcm93cz17M31cbiAgICAgICAgICAgICAgdmFsdWU9e25vdGV9XG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Tm90ZShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiZS5nLiBncm91bmQgZmxvb3IgcHJlZmVycmVkLCBuZWFyIHRoZSBtYWluIHJvYWRcIlxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcm91bmRlZC14bCBiZy1pdm9yeSBwLTMgdGV4dC1bMC45Mzc1cmVtXSByaW5nLTEgcmluZy1oYWlybGluZS1zdHJvbmcgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWFxdWEtNjAwXCJcbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L01vZGFsPlxuICAgIDwvPlxuICApO1xufVxuIl0sImZpbGUiOiJEOi9JMkkgUHJvamVjdCAtIEhhYml0by9BcHAgRm9sZGVyL2hhYml0by9zcmMvcGFnZXMvUmVxdWVzdHMudHN4In0=