import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/@fs/D:\\I2I Project - Habito\\App Folder\\habito\\src\\pages\\Search.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=9ceb86a3"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9ceb86a3"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useMemo = __vite__cjsImport3_react["useMemo"]; const useState = __vite__cjsImport3_react["useState"];
import { Link, useSearchParams } from "/node_modules/.vite/deps/react-router-dom.js?v=9ceb86a3";
import { SlidersHorizontal, Sparkles, Compass } from "/node_modules/.vite/deps/lucide-react.js?v=9ceb86a3";
import { useHabito } from "/src/hooks/useHabito.tsx";
import { PageHeader } from "/src/components/layout/PageHeader.tsx";
import { SpaceCard } from "/src/components/space/SpaceCard.tsx";
import { SpaceCardSkeleton } from "/src/components/ui/Skeleton.tsx";
import { Coachmark } from "/src/components/ui/Coachmark.tsx";
import __vite__cjsImport11_react from "/node_modules/.vite/deps/react.js?v=9ceb86a3"; const lazy = __vite__cjsImport11_react["lazy"]; const Suspense = __vite__cjsImport11_react["Suspense"];
import { Map as MapIcon, List as ListIcon } from "/node_modules/.vite/deps/lucide-react.js?v=9ceb86a3";
const SpaceMap = lazy(
  _c = () => import("/src/components/space/SpaceMap.tsx").then((m) => ({ default: m.SpaceMap }))
);
_c2 = SpaceMap;
import { Button } from "/src/components/ui/Button.tsx";
import { Modal } from "/src/components/ui/Modal.tsx";
import { scoreAll, nearbyAlternatives, acceptsOccupancy } from "/src/lib/matching.ts";
import { money, isStale, moneyCompact } from "/src/lib/format.ts";
import { CATEGORY_STYLE, AMENITY_KEYS } from "/src/data/catalog.ts";
import { AreaPicker } from "/src/components/ui/AreaPicker.tsx";
import { trustLevel } from "/src/components/space/badges.tsx";
import { cn } from "/src/lib/cn.ts";
import { displayImage } from "/src/lib/localize.ts";
import { useI18n } from "/src/i18n/index.tsx";
const SORTS = [
  { value: "best-match", label: "Best match" },
  { value: "price-low", label: "Price: low to high" },
  { value: "price-high", label: "Price: high to low" },
  { value: "recent", label: "Recently updated" },
  { value: "size", label: "Largest first" }
];
const PRICE_CEILING = 15e4;
const DEFAULTS = {
  area: "all",
  category: "all",
  geography: "all",
  priceMax: PRICE_CEILING,
  availableOnly: true,
  freshOnly: false,
  verifiedOnly: false,
  fullCostOnly: false,
  amenities: [],
  occupancy: "any"
};
export default function Search() {
  _s();
  const { t } = useI18n();
  const [view, setView] = useState("list");
  const [params] = useSearchParams();
  const { listings, ready, requirements, hasStatedNeeds, isSaved, toggleSaved, isComparing, toggleCompare } = useHabito();
  const [filters, setFilters] = useState(DEFAULTS);
  const [sort, setSort] = useState("best-match");
  const [sheetOpen, setSheetOpen] = useState(false);
  const categoryParam = params.get("category");
  const geoParam = params.get("geography");
  useEffect(() => {
    setFilters((f) => ({
      ...f,
      category: categoryParam ?? "all",
      geography: geoParam ?? "all"
    }));
  }, [categoryParam, geoParam]);
  const matches = useMemo(() => scoreAll(listings, requirements), [listings, requirements]);
  const results = useMemo(() => {
    const filtered = listings.filter((l) => {
      const { space, property } = l;
      if (filters.area !== "all" && property.area !== filters.area) return false;
      if (filters.category !== "all" && space.category !== filters.category) return false;
      if (filters.geography !== "all" && property.geography !== filters.geography) return false;
      if (space.transaction === "rent" && space.cost.price > filters.priceMax) return false;
      if (filters.availableOnly && (space.availability.status === "occupied" || space.availability.status === "maintenance"))
        return false;
      if (filters.freshOnly && isStale(space.lastUpdated)) return false;
      if (filters.verifiedOnly && trustLevel(space.verification) !== "verified") return false;
      if (filters.fullCostOnly && space.cost.estimatedMonthly === null) return false;
      if (filters.amenities.some((a) => !space.amenities.includes(a))) return false;
      if (!acceptsOccupancy(l, filters.occupancy)) return false;
      return true;
    });
    const score = (id) => matches.get(id)?.score ?? 0;
    return [...filtered].sort((a, b) => {
      switch (sort) {
        case "price-low":
          return a.space.cost.price - b.space.cost.price;
        case "price-high":
          return b.space.cost.price - a.space.cost.price;
        case "recent":
          return new Date(b.space.lastUpdated).getTime() - new Date(a.space.lastUpdated).getTime();
        case "size":
          return (b.space.attributes.sizeSqft ?? 0) - (a.space.attributes.sizeSqft ?? 0);
        default:
          return score(b.space.id) - score(a.space.id);
      }
    });
  }, [listings, filters, sort, matches]);
  const thin = results.length < 4;
  const nearby = useMemo(
    () => thin && ready ? nearbyAlternatives(listings, requirements, results.map((r) => r.space.id)) : [],
    [thin, ready, listings, requirements, results]
  );
  const activeCount = countActive(filters);
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(
      PageHeader,
      {
        title: filters.category === "all" ? "Find a space" : CATEGORY_STYLE[filters.category].label,
        lead: hasStatedNeeds ? `Scored against your needs: ${requirements.area}, ${money(requirements.budgetMin)}–${money(requirements.budgetMax)}.` : "Browse everything on the platform, or tell us what you need and each space gets a score.",
        actions: /* @__PURE__ */ jsxDEV(Link, { to: "/find", children: /* @__PURE__ */ jsxDEV(Button, { variant: hasStatedNeeds ? "secondary" : "primary", children: [
          /* @__PURE__ */ jsxDEV(Sparkles, { size: 16, "aria-hidden": true }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx",
            lineNumber: 166,
            columnNumber: 15
          }, this),
          hasStatedNeeds ? "Change needs" : "Tell us what you need"
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx",
          lineNumber: 165,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx",
          lineNumber: 164,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx",
        lineNumber: 156,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { className: "container-page py-8 md:py-10", children: /* @__PURE__ */ jsxDEV("div", { className: "grid gap-8 lg:grid-cols-[16rem_1fr]", children: [
      /* @__PURE__ */ jsxDEV("aside", { className: "hidden lg:block", children: /* @__PURE__ */ jsxDEV("div", { className: "sticky top-24 max-h-[calc(100vh-8rem)] overflow-y-auto overscroll-contain rounded-card bg-surface p-5 ring-1 ring-hairline", children: /* @__PURE__ */ jsxDEV(FilterPanel, { filters, onChange: setFilters }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx",
        lineNumber: 177,
        columnNumber: 15
      }, this) }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx",
        lineNumber: 176,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx",
        lineNumber: 175,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("div", { className: "mb-5 flex flex-wrap items-center gap-3", children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-sm tnum text-muted", children: ready ? `${results.length} ${results.length === 1 ? "space" : "spaces"}` : "Loading…" }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx",
            lineNumber: 183,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "ml-auto flex flex-wrap items-center justify-end gap-2", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "flex items-center gap-2 text-sm text-muted", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "hidden sm:inline", children: "Sort" }, void 0, false, {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx",
                lineNumber: 189,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(
                "select",
                {
                  value: sort,
                  onChange: (e) => setSort(e.target.value),
                  className: "h-10 rounded-full bg-surface px-3 text-sm text-ink ring-1 ring-hairline-strong focus:outline-none focus:ring-2 focus:ring-aqua-600",
                  children: SORTS.map(
                    (s) => /* @__PURE__ */ jsxDEV("option", { value: s.value, children: s.label }, s.value, false, {
                      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx",
                      lineNumber: 196,
                      columnNumber: 21
                    }, this)
                  )
                },
                void 0,
                false,
                {
                  fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx",
                  lineNumber: 190,
                  columnNumber: 19
                },
                this
              )
            ] }, void 0, true, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx",
              lineNumber: 188,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(
              "div",
              {
                role: "group",
                "aria-label": `${t("map.list")} / ${t("map.title")}`,
                className: "flex items-center rounded-full bg-ivory-deep p-0.5 ring-1 ring-hairline",
                children: [
                  { key: "list", label: t("map.list"), icon: ListIcon },
                  { key: "map", label: t("map.title"), icon: MapIcon }
                ].map(
                  (option) => /* @__PURE__ */ jsxDEV(
                    "button",
                    {
                      type: "button",
                      "aria-pressed": view === option.key,
                      onClick: () => setView(option.key),
                      className: cn(
                        "press inline-flex items-center gap-1.5 rounded-full px-3 py-2 text-xs font-bold transition-colors",
                        view === option.key ? "bg-ink text-ivory" : "text-muted hover:text-ink"
                      ),
                      children: [
                        /* @__PURE__ */ jsxDEV(option.icon, { size: 14, "aria-hidden": true }, void 0, false, {
                          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx",
                          lineNumber: 222,
                          columnNumber: 23
                        }, this),
                        option.label
                      ]
                    },
                    option.key,
                    true,
                    {
                      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx",
                      lineNumber: 212,
                      columnNumber: 19
                    },
                    this
                  )
                )
              },
              void 0,
              false,
              {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx",
                lineNumber: 203,
                columnNumber: 17
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(Button, { variant: "secondary", className: "lg:hidden", onClick: () => setSheetOpen(true), children: [
              /* @__PURE__ */ jsxDEV(SlidersHorizontal, { size: 16, "aria-hidden": true }, void 0, false, {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx",
                lineNumber: 229,
                columnNumber: 19
              }, this),
              t("search.filters"),
              activeCount > 0 && /* @__PURE__ */ jsxDEV("span", { className: "rounded-full bg-aqua-400 px-1.5 text-[0.65rem] font-bold tnum text-ink", children: activeCount }, void 0, false, {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx",
                lineNumber: 232,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx",
              lineNumber: 228,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx",
            lineNumber: 187,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx",
          lineNumber: 182,
          columnNumber: 13
        }, this),
        !ready ? /* @__PURE__ */ jsxDEV("div", { className: "stagger grid gap-5 sm:grid-cols-2 xl:grid-cols-3", children: Array.from(
          { length: 6 },
          (_, i) => /* @__PURE__ */ jsxDEV(SpaceCardSkeleton, {}, i, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx",
            lineNumber: 243,
            columnNumber: 15
          }, this)
        ) }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx",
          lineNumber: 241,
          columnNumber: 13
        }, this) : results.length === 0 ? /* @__PURE__ */ jsxDEV(NothingYet, { onReset: () => setFilters(DEFAULTS) }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx",
          lineNumber: 247,
          columnNumber: 13
        }, this) : view === "map" ? /* @__PURE__ */ jsxDEV(
          Suspense,
          {
            fallback: /* @__PURE__ */ jsxDEV("div", { className: "h-[70vh] min-h-96 animate-pulse rounded-card bg-ivory-deep" }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx",
              lineNumber: 251,
              columnNumber: 15
            }, this),
            children: /* @__PURE__ */ jsxDEV(SpaceMap, { listings: results, className: "h-[70vh] min-h-96 w-full max-w-full" }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx",
              lineNumber: 254,
              columnNumber: 17
            }, this)
          },
          void 0,
          false,
          {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx",
            lineNumber: 249,
            columnNumber: 13
          },
          this
        ) : /* @__PURE__ */ jsxDEV("div", { className: "stagger grid gap-5 sm:grid-cols-2 xl:grid-cols-3", children: [
          hasStatedNeeds && /* @__PURE__ */ jsxDEV(
            Coachmark,
            {
              id: "match",
              titleKey: "coach.matchTitle",
              bodyKey: "coach.matchBody",
              className: "sm:col-span-2 xl:col-span-3"
            },
            void 0,
            false,
            {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx",
              lineNumber: 259,
              columnNumber: 15
            },
            this
          ),
          results.map(
            (l) => /* @__PURE__ */ jsxDEV(
              SpaceCard,
              {
                listing: l,
                matchScore: hasStatedNeeds ? matches.get(l.space.id)?.score : void 0,
                saved: isSaved(l.space.id),
                comparing: isComparing(l.space.id),
                onToggleSave: (id) => void toggleSaved(id),
                onToggleCompare: toggleCompare
              },
              l.space.id,
              false,
              {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx",
                lineNumber: 267,
                columnNumber: 15
              },
              this
            )
          )
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx",
          lineNumber: 257,
          columnNumber: 13
        }, this),
        nearby.length > 0 && /* @__PURE__ */ jsxDEV("section", { className: "mt-10 rounded-card bg-surface p-6 ring-1 ring-hairline", children: [
          /* @__PURE__ */ jsxDEV("h2", { className: "font-display text-xl font-bold text-ink", children: results.length === 0 ? "Nothing perfect yet." : "Also worth a look." }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx",
            lineNumber: 282,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-muted", children: "These sit just outside what you asked for. Here's how each one differs." }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx",
            lineNumber: 285,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("ul", { className: "mt-5 space-y-2.5", children: nearby.map(
            ({ listing, score, reason }) => /* @__PURE__ */ jsxDEV("li", { children: /* @__PURE__ */ jsxDEV(
              Link,
              {
                to: `/space/${listing.space.id}`,
                className: "flex items-center gap-3.5 rounded-2xl p-2 transition-colors hover:bg-ivory",
                children: [
                  /* @__PURE__ */ jsxDEV(
                    "img",
                    {
                      src: displayImage(listing.space.images[0]),
                      alt: "",
                      className: "size-16 shrink-0 rounded-xl object-cover"
                    },
                    void 0,
                    false,
                    {
                      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx",
                      lineNumber: 296,
                      columnNumber: 25
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV("div", { className: "min-w-0 flex-1", children: [
                    /* @__PURE__ */ jsxDEV("p", { className: "truncate font-semibold text-ink", children: [
                      listing.space.name,
                      /* @__PURE__ */ jsxDEV("span", { className: "ml-2 font-normal text-muted", children: listing.property.area }, void 0, false, {
                        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx",
                        lineNumber: 304,
                        columnNumber: 29
                      }, this)
                    ] }, void 0, true, {
                      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx",
                      lineNumber: 302,
                      columnNumber: 27
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "mt-0.5 truncate text-sm text-ink-soft", children: reason }, void 0, false, {
                      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx",
                      lineNumber: 306,
                      columnNumber: 27
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx",
                    lineNumber: 301,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "shrink-0 text-right", children: [
                    /* @__PURE__ */ jsxDEV("p", { className: "font-bold tnum text-ink", children: moneyCompact(listing.space.cost.price) }, void 0, false, {
                      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx",
                      lineNumber: 309,
                      columnNumber: 27
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "text-xs tnum text-aqua-700", children: [
                      score,
                      "% match"
                    ] }, void 0, true, {
                      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx",
                      lineNumber: 310,
                      columnNumber: 27
                    }, this)
                  ] }, void 0, true, {
                    fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx",
                    lineNumber: 308,
                    columnNumber: 25
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx",
                lineNumber: 292,
                columnNumber: 23
              },
              this
            ) }, listing.space.id, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx",
              lineNumber: 291,
              columnNumber: 17
            }, this)
          ) }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx",
            lineNumber: 289,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx",
          lineNumber: 281,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx",
        lineNumber: 181,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx",
      lineNumber: 174,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx",
      lineNumber: 173,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        open: sheetOpen,
        onClose: () => setSheetOpen(false),
        title: "Filters",
        footer: /* @__PURE__ */ jsxDEV("div", { className: "flex gap-2", children: [
          /* @__PURE__ */ jsxDEV(Button, { variant: "secondary", fullWidth: true, onClick: () => setFilters(DEFAULTS), children: "Reset" }, void 0, false, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx",
            lineNumber: 328,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(Button, { fullWidth: true, onClick: () => setSheetOpen(false), children: [
            "Show ",
            results.length
          ] }, void 0, true, {
            fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx",
            lineNumber: 331,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx",
          lineNumber: 327,
          columnNumber: 9
        }, this),
        children: /* @__PURE__ */ jsxDEV(FilterPanel, { filters, onChange: setFilters }, void 0, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx",
          lineNumber: 337,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx",
        lineNumber: 322,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx",
    lineNumber: 155,
    columnNumber: 5
  }, this);
}
_s(Search, "TF37O5kVHv+Khiyk4aATFX0nAYI=", false, function() {
  return [useI18n, useSearchParams, useHabito];
});
_c3 = Search;
function NothingYet({ onReset }) {
  return /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col items-center rounded-card bg-surface px-6 py-14 text-center ring-1 ring-hairline", children: [
    /* @__PURE__ */ jsxDEV("span", { className: "mb-4 flex size-12 items-center justify-center rounded-full bg-aqua-100 text-aqua-700", children: /* @__PURE__ */ jsxDEV(Compass, { size: 22, "aria-hidden": true }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx",
      lineNumber: 347,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx",
      lineNumber: 346,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("h2", { className: "font-display text-xl font-bold text-ink", children: "Nothing matches those filters." }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx",
      lineNumber: 349,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("p", { className: "mt-2 max-w-sm text-sm text-muted", children: "Widen the price, open it to more categories, or include areas further out." }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx",
      lineNumber: 350,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Button, { variant: "secondary", className: "mt-5", onClick: onReset, children: "Clear all filters" }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx",
      lineNumber: 353,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx",
    lineNumber: 345,
    columnNumber: 5
  }, this);
}
_c4 = NothingYet;
function countActive(f) {
  let n = 0;
  if (f.area !== "all") n++;
  if (f.category !== "all") n++;
  if (f.geography !== "all") n++;
  if (f.priceMax !== PRICE_CEILING) n++;
  if (!f.availableOnly) n++;
  if (f.freshOnly) n++;
  if (f.verifiedOnly) n++;
  if (f.fullCostOnly) n++;
  if (f.occupancy !== "any") n++;
  return n + f.amenities.length;
}
function FilterPanel({ filters, onChange }) {
  _s2();
  const { t } = useI18n();
  const set = (k, v) => onChange({ ...filters, [k]: v });
  return /* @__PURE__ */ jsxDEV("div", { className: "space-y-6", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
      /* @__PURE__ */ jsxDEV("h2", { className: "font-display font-bold text-ink", children: "Filters" }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx",
        lineNumber: 381,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          onClick: () => onChange(DEFAULTS),
          className: "text-xs font-semibold text-muted hover:text-ink",
          children: "Reset"
        },
        void 0,
        false,
        {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx",
          lineNumber: 382,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx",
      lineNumber: 380,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Group, { label: t("filter.category"), children: /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-1.5", children: [
      /* @__PURE__ */ jsxDEV(Pill, { active: filters.category === "all", onClick: () => set("category", "all"), children: "All" }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx",
        lineNumber: 393,
        columnNumber: 11
      }, this),
      Object.keys(CATEGORY_STYLE).map(
        (c) => /* @__PURE__ */ jsxDEV(Pill, { active: filters.category === c, onClick: () => set("category", c), children: CATEGORY_STYLE[c].label }, c, false, {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx",
          lineNumber: 397,
          columnNumber: 11
        }, this)
      )
    ] }, void 0, true, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx",
      lineNumber: 392,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx",
      lineNumber: 391,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Group, { label: t("filter.area"), children: /* @__PURE__ */ jsxDEV(AreaPicker, { value: filters.area, onChange: (v) => set("area", v), allowAnywhere: true }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx",
      lineNumber: 405,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx",
      lineNumber: 404,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Group, { label: t("filter.setting"), children: /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-1.5", children: ["all", "urban", "suburban", "rural"].map(
      (g) => /* @__PURE__ */ jsxDEV(Pill, { active: filters.geography === g, onClick: () => set("geography", g), children: g === "all" ? "Anywhere" : g }, g, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx",
        lineNumber: 411,
        columnNumber: 11
      }, this)
    ) }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx",
      lineNumber: 409,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx",
      lineNumber: 408,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Group, { label: `Rent up to ${money(filters.priceMax)}`, children: [
      /* @__PURE__ */ jsxDEV(
        "input",
        {
          type: "range",
          "aria-label": "Maximum monthly price",
          min: 2e3,
          max: PRICE_CEILING,
          step: 1e3,
          value: filters.priceMax,
          onChange: (e) => set("priceMax", Number(e.target.value)),
          className: "w-full accent-aqua-600"
        },
        void 0,
        false,
        {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx",
          lineNumber: 419,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-xs text-muted", children: "Sale listings aren't filtered by this." }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx",
        lineNumber: 429,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx",
      lineNumber: 418,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Group, { label: t("filter.whoCanLive"), children: /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-1.5", children: [
      { key: "any", label: t("filter.all") },
      { key: "family", label: t("filter.familyAllowed") },
      { key: "bachelor", label: t("filter.bachelorAllowed") },
      { key: "student", label: t("filter.studentFriendly") }
    ].map(
      (option) => /* @__PURE__ */ jsxDEV(
        Pill,
        {
          active: filters.occupancy === option.key,
          onClick: () => set("occupancy", option.key),
          children: option.label
        },
        option.key,
        false,
        {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx",
          lineNumber: 440,
          columnNumber: 11
        },
        this
      )
    ) }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx",
      lineNumber: 433,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx",
      lineNumber: 432,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Group, { label: t("filter.showOnly"), children: /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
      /* @__PURE__ */ jsxDEV(Check, { label: t("filter.available"), checked: filters.availableOnly, onChange: (v) => set("availableOnly", v) }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx",
        lineNumber: 453,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Check, { label: t("filter.fresh"), checked: filters.freshOnly, onChange: (v) => set("freshOnly", v) }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx",
        lineNumber: 454,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Check, { label: t("filter.fullCost"), checked: filters.fullCostOnly, onChange: (v) => set("fullCostOnly", v) }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx",
        lineNumber: 455,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Check, { label: t("filter.verified"), checked: filters.verifiedOnly, onChange: (v) => set("verifiedOnly", v) }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx",
        lineNumber: 456,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx",
      lineNumber: 452,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx",
      lineNumber: 451,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Group, { label: t("filter.amenities"), children: /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-1.5", children: AMENITY_KEYS.slice(0, 14).map(
      (key) => /* @__PURE__ */ jsxDEV(
        Pill,
        {
          active: filters.amenities.includes(key),
          onClick: () => set(
            "amenities",
            filters.amenities.includes(key) ? filters.amenities.filter((a) => a !== key) : [...filters.amenities, key]
          ),
          children: t(`amenity.${key}`)
        },
        key,
        false,
        {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx",
          lineNumber: 463,
          columnNumber: 11
        },
        this
      )
    ) }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx",
      lineNumber: 461,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx",
      lineNumber: 460,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx",
    lineNumber: 379,
    columnNumber: 5
  }, this);
}
_s2(FilterPanel, "82N5KF9nLzZ6+2WH7KIjzIXRkLw=", false, function() {
  return [useI18n];
});
_c5 = FilterPanel;
function Group({ label, children }) {
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("p", { className: "mb-2 text-sm font-semibold text-ink-soft", children: label }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx",
      lineNumber: 487,
      columnNumber: 7
    }, this),
    children
  ] }, void 0, true, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx",
    lineNumber: 486,
    columnNumber: 5
  }, this);
}
_c6 = Group;
function Pill({ active, onClick, children }) {
  return /* @__PURE__ */ jsxDEV(
    "button",
    {
      type: "button",
      "aria-pressed": active,
      onClick,
      className: cn(
        "rounded-full px-2.5 py-1.5 text-xs font-semibold capitalize transition-colors",
        active ? "bg-ink text-ivory" : "bg-ivory-deep text-ink-soft hover:bg-hairline"
      ),
      children
    },
    void 0,
    false,
    {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx",
      lineNumber: 495,
      columnNumber: 5
    },
    this
  );
}
_c7 = Pill;
function Check({ label, checked, onChange }) {
  return /* @__PURE__ */ jsxDEV("label", { className: "flex cursor-pointer items-center gap-2.5 text-sm text-ink-soft", children: [
    /* @__PURE__ */ jsxDEV(
      "input",
      {
        type: "checkbox",
        checked,
        onChange: (e) => onChange(e.target.checked),
        className: "size-4 accent-aqua-600"
      },
      void 0,
      false,
      {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx",
        lineNumber: 512,
        columnNumber: 7
      },
      this
    ),
    label
  ] }, void 0, true, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx",
    lineNumber: 511,
    columnNumber: 5
  }, this);
}
_c8 = Check;
var _c, _c2, _c3, _c4, _c5, _c6, _c7, _c8;
$RefreshReg$(_c, "SpaceMap$lazy");
$RefreshReg$(_c2, "SpaceMap");
$RefreshReg$(_c3, "Search");
$RefreshReg$(_c4, "NothingYet");
$RefreshReg$(_c5, "FilterPanel");
$RefreshReg$(_c6, "Group");
$RefreshReg$(_c7, "Pill");
$RefreshReg$(_c8, "Check");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/I2I Project - Habito/App Folder/habito/src/pages/Search.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdUlJLG1CQVdVLGNBWFY7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBdklKLFNBQVNBLFdBQVdDLFNBQVNDLGdCQUFnQjtBQUM3QyxTQUFTQyxNQUFNQyx1QkFBdUI7QUFDdEMsU0FBU0MsbUJBQW1CQyxVQUFVQyxlQUFlO0FBQ3JELFNBQVNDLGlCQUFpQjtBQUMxQixTQUFTQyxrQkFBa0I7QUFDM0IsU0FBU0MsaUJBQWlCO0FBQzFCLFNBQVNDLHlCQUF5QjtBQUNsQyxTQUFTQyxpQkFBaUI7QUFDMUIsU0FBU0MsTUFBTUMsZ0JBQWdCO0FBQy9CLFNBQVNDLE9BQU9DLFNBQVNDLFFBQVFDLGdCQUFnQjtBQUlqRCxNQUFNQyxXQUFXTjtBQUFBQSxFQUFJTyxLQUFDQSxNQUNwQixPQUFPLDZCQUE2QixFQUFFQyxLQUFLLENBQUNDLE9BQU8sRUFBRUMsU0FBU0QsRUFBRUgsU0FBUyxFQUFFO0FBQzdFO0FBQUVLLE1BRklMO0FBR04sU0FBU00sY0FBYztBQUN2QixTQUFTQyxhQUFhO0FBQ3RCLFNBQVNDLFVBQVVDLG9CQUFvQkMsd0JBQXdCO0FBQy9ELFNBQVNDLE9BQU9DLFNBQVNDLG9CQUFvQjtBQUM3QyxTQUFTQyxnQkFBZ0JDLG9CQUFvQjtBQUM3QyxTQUFTQyxrQkFBa0I7QUFDM0IsU0FBU0Msa0JBQWtCO0FBQzNCLFNBQVNDLFVBQVU7QUFDbkIsU0FBU0Msb0JBQW9CO0FBQzdCLFNBQVNDLGVBQWU7QUFLeEIsTUFBTUMsUUFBa0Q7QUFBQSxFQUN0RCxFQUFFQyxPQUFPLGNBQWNDLE9BQU8sYUFBYTtBQUFBLEVBQzNDLEVBQUVELE9BQU8sYUFBYUMsT0FBTyxxQkFBcUI7QUFBQSxFQUNsRCxFQUFFRCxPQUFPLGNBQWNDLE9BQU8scUJBQXFCO0FBQUEsRUFDbkQsRUFBRUQsT0FBTyxVQUFVQyxPQUFPLG1CQUFtQjtBQUFBLEVBQzdDLEVBQUVELE9BQU8sUUFBUUMsT0FBTyxnQkFBZ0I7QUFBQztBQWdCM0MsTUFBTUMsZ0JBQWdCO0FBRXRCLE1BQU1DLFdBQW9CO0FBQUEsRUFDeEJDLE1BQU07QUFBQSxFQUNOQyxVQUFVO0FBQUEsRUFDVkMsV0FBVztBQUFBLEVBQ1hDLFVBQVVMO0FBQUFBLEVBQ1ZNLGVBQWU7QUFBQSxFQUNmQyxXQUFXO0FBQUEsRUFDWEMsY0FBYztBQUFBLEVBQ2RDLGNBQWM7QUFBQSxFQUNkQyxXQUFXO0FBQUEsRUFDWEMsV0FBVztBQUNiO0FBRUEsd0JBQXdCQyxTQUFTO0FBQUFDLEtBQUE7QUFDL0IsUUFBTSxFQUFFQyxFQUFFLElBQUlsQixRQUFRO0FBQ3RCLFFBQU0sQ0FBQ21CLE1BQU1DLE9BQU8sSUFBSXpELFNBQXlCLE1BQU07QUFDdkQsUUFBTSxDQUFDMEQsTUFBTSxJQUFJeEQsZ0JBQWdCO0FBQ2pDLFFBQU0sRUFBRXlELFVBQVVDLE9BQU9DLGNBQWNDLGdCQUFnQkMsU0FBU0MsYUFBYUMsYUFBYUMsY0FBYyxJQUN0RzVELFVBQVU7QUFFWixRQUFNLENBQUM2RCxTQUFTQyxVQUFVLElBQUlwRSxTQUFrQjBDLFFBQVE7QUFDeEQsUUFBTSxDQUFDMkIsTUFBTUMsT0FBTyxJQUFJdEUsU0FBa0IsWUFBWTtBQUN0RCxRQUFNLENBQUN1RSxXQUFXQyxZQUFZLElBQUl4RSxTQUFTLEtBQUs7QUFHaEQsUUFBTXlFLGdCQUFnQmYsT0FBT2dCLElBQUksVUFBVTtBQUMzQyxRQUFNQyxXQUFXakIsT0FBT2dCLElBQUksV0FBVztBQUN2QzVFLFlBQVUsTUFBTTtBQUNkc0UsZUFBVyxDQUFDUSxPQUFPO0FBQUEsTUFDakIsR0FBR0E7QUFBQUEsTUFDSGhDLFVBQVc2QixpQkFBbUM7QUFBQSxNQUM5QzVCLFdBQVk4QixZQUEwQjtBQUFBLElBQ3hDLEVBQUU7QUFBQSxFQUNKLEdBQUcsQ0FBQ0YsZUFBZUUsUUFBUSxDQUFDO0FBRTVCLFFBQU1FLFVBQVU5RSxRQUFRLE1BQU0wQixTQUFTa0MsVUFBVUUsWUFBWSxHQUFHLENBQUNGLFVBQVVFLFlBQVksQ0FBQztBQUV4RixRQUFNaUIsVUFBVS9FLFFBQVEsTUFBTTtBQUM1QixVQUFNZ0YsV0FBV3BCLFNBQVNxQixPQUFPLENBQUNDLE1BQU07QUFDdEMsWUFBTSxFQUFFQyxPQUFPQyxTQUFTLElBQUlGO0FBQzVCLFVBQUlkLFFBQVF4QixTQUFTLFNBQVN3QyxTQUFTeEMsU0FBU3dCLFFBQVF4QixLQUFNLFFBQU87QUFDckUsVUFBSXdCLFFBQVF2QixhQUFhLFNBQVNzQyxNQUFNdEMsYUFBYXVCLFFBQVF2QixTQUFVLFFBQU87QUFDOUUsVUFBSXVCLFFBQVF0QixjQUFjLFNBQVNzQyxTQUFTdEMsY0FBY3NCLFFBQVF0QixVQUFXLFFBQU87QUFDcEYsVUFBSXFDLE1BQU1FLGdCQUFnQixVQUFVRixNQUFNRyxLQUFLQyxRQUFRbkIsUUFBUXJCLFNBQVUsUUFBTztBQUNoRixVQUFJcUIsUUFBUXBCLGtCQUFrQm1DLE1BQU1LLGFBQWFDLFdBQVcsY0FBY04sTUFBTUssYUFBYUMsV0FBVztBQUN0RyxlQUFPO0FBQ1QsVUFBSXJCLFFBQVFuQixhQUFhbkIsUUFBUXFELE1BQU1PLFdBQVcsRUFBRyxRQUFPO0FBQzVELFVBQUl0QixRQUFRbEIsZ0JBQWdCZixXQUFXZ0QsTUFBTVEsWUFBWSxNQUFNLFdBQVksUUFBTztBQUNsRixVQUFJdkIsUUFBUWpCLGdCQUFnQmdDLE1BQU1HLEtBQUtNLHFCQUFxQixLQUFNLFFBQU87QUFDekUsVUFBSXhCLFFBQVFoQixVQUFVeUMsS0FBSyxDQUFDQyxNQUFNLENBQUNYLE1BQU0vQixVQUFVMkMsU0FBU0QsQ0FBQyxDQUFDLEVBQUcsUUFBTztBQUV4RSxVQUFJLENBQUNsRSxpQkFBaUJzRCxHQUFHZCxRQUFRZixTQUFTLEVBQUcsUUFBTztBQUNwRCxhQUFPO0FBQUEsSUFDVCxDQUFDO0FBRUQsVUFBTTJDLFFBQVFBLENBQUNDLE9BQWVuQixRQUFRSCxJQUFJc0IsRUFBRSxHQUFHRCxTQUFTO0FBRXhELFdBQU8sQ0FBQyxHQUFHaEIsUUFBUSxFQUFFVixLQUFLLENBQUN3QixHQUFHSSxNQUFNO0FBQ2xDLGNBQVE1QixNQUFJO0FBQUEsUUFDVixLQUFLO0FBQ0gsaUJBQU93QixFQUFFWCxNQUFNRyxLQUFLQyxRQUFRVyxFQUFFZixNQUFNRyxLQUFLQztBQUFBQSxRQUMzQyxLQUFLO0FBQ0gsaUJBQU9XLEVBQUVmLE1BQU1HLEtBQUtDLFFBQVFPLEVBQUVYLE1BQU1HLEtBQUtDO0FBQUFBLFFBQzNDLEtBQUs7QUFDSCxpQkFBTyxJQUFJWSxLQUFLRCxFQUFFZixNQUFNTyxXQUFXLEVBQUVVLFFBQVEsSUFBSSxJQUFJRCxLQUFLTCxFQUFFWCxNQUFNTyxXQUFXLEVBQUVVLFFBQVE7QUFBQSxRQUN6RixLQUFLO0FBQ0gsa0JBQVFGLEVBQUVmLE1BQU1rQixXQUFXQyxZQUFZLE1BQU1SLEVBQUVYLE1BQU1rQixXQUFXQyxZQUFZO0FBQUEsUUFDOUU7QUFDRSxpQkFBT04sTUFBTUUsRUFBRWYsTUFBTWMsRUFBRSxJQUFJRCxNQUFNRixFQUFFWCxNQUFNYyxFQUFFO0FBQUEsTUFDL0M7QUFBQSxJQUNGLENBQUM7QUFBQSxFQUNILEdBQUcsQ0FBQ3JDLFVBQVVRLFNBQVNFLE1BQU1RLE9BQU8sQ0FBQztBQUVyQyxRQUFNeUIsT0FBT3hCLFFBQVF5QixTQUFTO0FBQzlCLFFBQU1DLFNBQVN6RztBQUFBQSxJQUNiLE1BQU91RyxRQUFRMUMsUUFBUWxDLG1CQUFtQmlDLFVBQVVFLGNBQWNpQixRQUFRMkIsSUFBSSxDQUFDQyxNQUFNQSxFQUFFeEIsTUFBTWMsRUFBRSxDQUFDLElBQUk7QUFBQSxJQUNwRyxDQUFDTSxNQUFNMUMsT0FBT0QsVUFBVUUsY0FBY2lCLE9BQU87QUFBQSxFQUMvQztBQUVBLFFBQU02QixjQUFjQyxZQUFZekMsT0FBTztBQUV2QyxTQUNFLG1DQUNFO0FBQUE7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLE9BQU9BLFFBQVF2QixhQUFhLFFBQVEsaUJBQWlCYixlQUFlb0MsUUFBUXZCLFFBQVEsRUFBRUo7QUFBQUEsUUFDdEYsTUFDRXNCLGlCQUNJLDhCQUE4QkQsYUFBYWxCLElBQUksS0FBS2YsTUFBTWlDLGFBQWFnRCxTQUFTLENBQUMsSUFBSWpGLE1BQU1pQyxhQUFhaUQsU0FBUyxDQUFDLE1BQ2xIO0FBQUEsUUFFTixTQUNFLHVCQUFDLFFBQUssSUFBRyxTQUNQLGlDQUFDLFVBQU8sU0FBU2hELGlCQUFpQixjQUFjLFdBQzlDO0FBQUEsaUNBQUMsWUFBUyxNQUFNLElBQUksZUFBVyxRQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUErQjtBQUFBLFVBQzlCQSxpQkFBaUIsaUJBQWlCO0FBQUEsYUFGckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBLEtBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUtBO0FBQUE7QUFBQSxNQWJKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQWNHO0FBQUEsSUFHSCx1QkFBQyxTQUFJLFdBQVUsZ0NBQ2IsaUNBQUMsU0FBSSxXQUFVLHVDQUNiO0FBQUEsNkJBQUMsV0FBTSxXQUFVLG1CQUNmLGlDQUFDLFNBQUksV0FBVSw4SEFDYixpQ0FBQyxlQUFZLFNBQWtCLFVBQVVNLGNBQXpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBb0QsS0FEdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUlBO0FBQUEsTUFFQSx1QkFBQyxTQUNDO0FBQUEsK0JBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEsaUNBQUMsT0FBRSxXQUFVLDJCQUNWUixrQkFBUSxHQUFHa0IsUUFBUXlCLE1BQU0sSUFBSXpCLFFBQVF5QixXQUFXLElBQUksVUFBVSxRQUFRLEtBQUssY0FEOUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBRUEsdUJBQUMsU0FBSSxXQUFVLHlEQUNiO0FBQUEsbUNBQUMsV0FBTSxXQUFVLDhDQUNmO0FBQUEscUNBQUMsVUFBSyxXQUFVLG9CQUFtQixvQkFBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBdUM7QUFBQSxjQUN2QztBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxPQUFPbEM7QUFBQUEsa0JBQ1AsVUFBVSxDQUFDMEMsTUFBTXpDLFFBQVF5QyxFQUFFQyxPQUFPekUsS0FBZ0I7QUFBQSxrQkFDbEQsV0FBVTtBQUFBLGtCQUVURCxnQkFBTW1FO0FBQUFBLG9CQUFJLENBQUNRLE1BQ1YsdUJBQUMsWUFBcUIsT0FBT0EsRUFBRTFFLE9BQzVCMEUsWUFBRXpFLFNBRFF5RSxFQUFFMUUsT0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsa0JBQ0Q7QUFBQTtBQUFBLGdCQVRIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVVBO0FBQUEsaUJBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFhQTtBQUFBLFlBRUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsY0FBWSxHQUFHZ0IsRUFBRSxVQUFVLENBQUMsTUFBTUEsRUFBRSxXQUFXLENBQUM7QUFBQSxnQkFDaEQsV0FBVTtBQUFBLGdCQUVSO0FBQUEsa0JBQ0EsRUFBRTJELEtBQUssUUFBaUIxRSxPQUFPZSxFQUFFLFVBQVUsR0FBRzRELE1BQU1uRyxTQUFTO0FBQUEsa0JBQzdELEVBQUVrRyxLQUFLLE9BQWdCMUUsT0FBT2UsRUFBRSxXQUFXLEdBQUc0RCxNQUFNckcsUUFBUTtBQUFBLGdCQUFDLEVBQzVEMkY7QUFBQUEsa0JBQUksQ0FBQ1csV0FDTjtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFFQyxNQUFLO0FBQUEsc0JBQ0wsZ0JBQWM1RCxTQUFTNEQsT0FBT0Y7QUFBQUEsc0JBQzlCLFNBQVMsTUFBTXpELFFBQVEyRCxPQUFPRixHQUFHO0FBQUEsc0JBQ2pDLFdBQVcvRTtBQUFBQSx3QkFDVDtBQUFBLHdCQUNBcUIsU0FBUzRELE9BQU9GLE1BQU0sc0JBQXNCO0FBQUEsc0JBQzlDO0FBQUEsc0JBRUE7QUFBQSwrQ0FBQyxPQUFPLE1BQVAsRUFBWSxNQUFNLElBQUksZUFBVyxRQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUFrQztBQUFBLHdCQUNqQ0UsT0FBTzVFO0FBQUFBO0FBQUFBO0FBQUFBLG9CQVZINEUsT0FBT0Y7QUFBQUEsb0JBRGQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFZQTtBQUFBLGdCQUNEO0FBQUE7QUFBQSxjQXRCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUF1QkE7QUFBQSxZQUVBLHVCQUFDLFVBQU8sU0FBUSxhQUFZLFdBQVUsYUFBWSxTQUFTLE1BQU0xQyxhQUFhLElBQUksR0FDaEY7QUFBQSxxQ0FBQyxxQkFBa0IsTUFBTSxJQUFJLGVBQVcsUUFBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBd0M7QUFBQSxjQUN2Q2pCLEVBQUUsZ0JBQWdCO0FBQUEsY0FDbEJvRCxjQUFjLEtBQ2IsdUJBQUMsVUFBSyxXQUFVLDBFQUNiQSx5QkFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBTko7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFRQTtBQUFBLGVBakRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBa0RBO0FBQUEsYUF2REY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXdEQTtBQUFBLFFBRUMsQ0FBQy9DLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLG9EQUNaeUQsZ0JBQU1DO0FBQUFBLFVBQUssRUFBRWYsUUFBUSxFQUFFO0FBQUEsVUFBRyxDQUFDZ0IsR0FBR0MsTUFDN0IsdUJBQUMsdUJBQXVCQSxHQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEwQjtBQUFBLFFBQzNCLEtBSEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUlBLElBQ0UxQyxRQUFReUIsV0FBVyxJQUNyQix1QkFBQyxjQUFXLFNBQVMsTUFBTW5DLFdBQVcxQixRQUFRLEtBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ0QsSUFDOUNjLFNBQVMsUUFDWDtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsVUFDRSx1QkFBQyxTQUFJLFdBQVUsZ0VBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMkU7QUFBQSxZQUc3RSxpQ0FBQyxZQUFTLFVBQVVzQixTQUFTLFdBQVUseUNBQXZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTRFO0FBQUE7QUFBQSxVQUw5RTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFNQSxJQUVBLHVCQUFDLFNBQUksV0FBVSxvREFDWmhCO0FBQUFBLDRCQUNDO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxJQUFHO0FBQUEsY0FDSCxVQUFTO0FBQUEsY0FDVCxTQUFRO0FBQUEsY0FDUixXQUFVO0FBQUE7QUFBQSxZQUpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUl5QztBQUFBLFVBRzFDZ0IsUUFBUTJCO0FBQUFBLFlBQUksQ0FBQ3hCLE1BQ1o7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFFQyxTQUFTQTtBQUFBQSxnQkFDVCxZQUFZbkIsaUJBQWlCZSxRQUFRSCxJQUFJTyxFQUFFQyxNQUFNYyxFQUFFLEdBQUdELFFBQVEwQjtBQUFBQSxnQkFDOUQsT0FBTzFELFFBQVFrQixFQUFFQyxNQUFNYyxFQUFFO0FBQUEsZ0JBQ3pCLFdBQVcvQixZQUFZZ0IsRUFBRUMsTUFBTWMsRUFBRTtBQUFBLGdCQUNqQyxjQUFjLENBQUNBLE9BQU8sS0FBS2hDLFlBQVlnQyxFQUFFO0FBQUEsZ0JBQ3pDLGlCQUFpQjlCO0FBQUFBO0FBQUFBLGNBTlplLEVBQUVDLE1BQU1jO0FBQUFBLGNBRGY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU9pQztBQUFBLFVBRWxDO0FBQUEsYUFuQkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQW9CQTtBQUFBLFFBR0RRLE9BQU9ELFNBQVMsS0FDZix1QkFBQyxhQUFRLFdBQVUsMERBQ2pCO0FBQUEsaUNBQUMsUUFBRyxXQUFVLDJDQUNYekIsa0JBQVF5QixXQUFXLElBQUkseUJBQXlCLHdCQURuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxPQUFFLFdBQVUsMkJBQXlCLHVGQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFFQSx1QkFBQyxRQUFHLFdBQVUsb0JBQ1hDLGlCQUFPQztBQUFBQSxZQUFJLENBQUMsRUFBRWlCLFNBQVMzQixPQUFPNEIsT0FBTyxNQUNwQyx1QkFBQyxRQUNDO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsSUFBSSxVQUFVRCxRQUFReEMsTUFBTWMsRUFBRTtBQUFBLGdCQUM5QixXQUFVO0FBQUEsZ0JBRVY7QUFBQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxLQUFLNUQsYUFBYXNGLFFBQVF4QyxNQUFNMEMsT0FBTyxDQUFDLENBQUM7QUFBQSxzQkFDekMsS0FBSTtBQUFBLHNCQUNKLFdBQVU7QUFBQTtBQUFBLG9CQUhaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFHc0Q7QUFBQSxrQkFFdEQsdUJBQUMsU0FBSSxXQUFVLGtCQUNiO0FBQUEsMkNBQUMsT0FBRSxXQUFVLG1DQUNWRjtBQUFBQSw4QkFBUXhDLE1BQU0yQztBQUFBQSxzQkFDZix1QkFBQyxVQUFLLFdBQVUsK0JBQStCSCxrQkFBUXZDLFNBQVN4QyxRQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFxRTtBQUFBLHlCQUZ2RTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUdBO0FBQUEsb0JBQ0EsdUJBQUMsT0FBRSxXQUFVLHlDQUF5Q2dGLG9CQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUE2RDtBQUFBLHVCQUwvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQU1BO0FBQUEsa0JBQ0EsdUJBQUMsU0FBSSxXQUFVLHVCQUNiO0FBQUEsMkNBQUMsT0FBRSxXQUFVLDJCQUEyQjdGLHVCQUFhNEYsUUFBUXhDLE1BQU1HLEtBQUtDLEtBQUssS0FBN0U7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBK0U7QUFBQSxvQkFDL0UsdUJBQUMsT0FBRSxXQUFVLDhCQUE4QlM7QUFBQUE7QUFBQUEsc0JBQU07QUFBQSx5QkFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBd0Q7QUFBQSx1QkFGMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFHQTtBQUFBO0FBQUE7QUFBQSxjQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFvQkEsS0FyQk8yQixRQUFReEMsTUFBTWMsSUFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFzQkE7QUFBQSxVQUNELEtBekJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBMEJBO0FBQUEsYUFsQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQW1DQTtBQUFBLFdBdklKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF5SUE7QUFBQSxTQWhKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBaUpBLEtBbEpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FtSkE7QUFBQSxJQUVBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxNQUFNekI7QUFBQUEsUUFDTixTQUFTLE1BQU1DLGFBQWEsS0FBSztBQUFBLFFBQ2pDLE9BQU07QUFBQSxRQUNOLFFBQ0UsdUJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSxpQ0FBQyxVQUFPLFNBQVEsYUFBWSxXQUFTLE1BQUMsU0FBUyxNQUFNSixXQUFXMUIsUUFBUSxHQUFFLHFCQUExRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxVQUFPLFdBQVMsTUFBQyxTQUFTLE1BQU04QixhQUFhLEtBQUssR0FBRTtBQUFBO0FBQUEsWUFDN0NNLFFBQVF5QjtBQUFBQSxlQURoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBT0E7QUFBQSxRQUdGLGlDQUFDLGVBQVksU0FBa0IsVUFBVW5DLGNBQXpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBb0Q7QUFBQTtBQUFBLE1BZnREO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQWdCQTtBQUFBLE9BdkxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F3TEE7QUFFSjtBQUFDZCxHQS9QdUJELFFBQU07QUFBQSxVQUNkaEIsU0FFR25DLGlCQUVmSSxTQUFTO0FBQUE7QUFBQSxNQUxXK0M7QUFpUXhCLFNBQVN5RSxXQUFXLEVBQUVDLFFBQWlDLEdBQUc7QUFDeEQsU0FDRSx1QkFBQyxTQUFJLFdBQVUsa0dBQ2I7QUFBQSwyQkFBQyxVQUFLLFdBQVUsd0ZBQ2QsaUNBQUMsV0FBUSxNQUFNLElBQUksZUFBVyxRQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQThCLEtBRGhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLElBQ0EsdUJBQUMsUUFBRyxXQUFVLDJDQUEwQyw4Q0FBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFzRjtBQUFBLElBQ3RGLHVCQUFDLE9BQUUsV0FBVSxvQ0FBa0MsMEZBQS9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLElBQ0EsdUJBQUMsVUFBTyxTQUFRLGFBQVksV0FBVSxRQUFPLFNBQVNBLFNBQVEsaUNBQTlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLE9BVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVdBO0FBRUo7QUFBQ0MsTUFmUUY7QUFpQlQsU0FBU2xCLFlBQVloQyxHQUFvQjtBQUN2QyxNQUFJcUQsSUFBSTtBQUNSLE1BQUlyRCxFQUFFakMsU0FBUyxNQUFPc0Y7QUFDdEIsTUFBSXJELEVBQUVoQyxhQUFhLE1BQU9xRjtBQUMxQixNQUFJckQsRUFBRS9CLGNBQWMsTUFBT29GO0FBQzNCLE1BQUlyRCxFQUFFOUIsYUFBYUwsY0FBZXdGO0FBQ2xDLE1BQUksQ0FBQ3JELEVBQUU3QixjQUFla0Y7QUFDdEIsTUFBSXJELEVBQUU1QixVQUFXaUY7QUFDakIsTUFBSXJELEVBQUUzQixhQUFjZ0Y7QUFDcEIsTUFBSXJELEVBQUUxQixhQUFjK0U7QUFDcEIsTUFBSXJELEVBQUV4QixjQUFjLE1BQU82RTtBQUMzQixTQUFPQSxJQUFJckQsRUFBRXpCLFVBQVVvRDtBQUN6QjtBQUVBLFNBQVMyQixZQUFZLEVBQUUvRCxTQUFTZ0UsU0FBK0QsR0FBRztBQUFBQyxNQUFBO0FBQ2hHLFFBQU0sRUFBRTdFLEVBQUUsSUFBSWxCLFFBQVE7QUFDdEIsUUFBTWdHLE1BQU0sQ0FBMEJDLEdBQU1DLE1BQWtCSixTQUFTLEVBQUUsR0FBR2hFLFNBQVMsQ0FBQ21FLENBQUMsR0FBR0MsRUFBRSxDQUFDO0FBRTdGLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSwyQkFBQyxTQUFJLFdBQVUscUNBQ2I7QUFBQSw2QkFBQyxRQUFHLFdBQVUsbUNBQWtDLHVCQUFoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXVEO0FBQUEsTUFDdkQ7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE1BQUs7QUFBQSxVQUNMLFNBQVMsTUFBTUosU0FBU3pGLFFBQVE7QUFBQSxVQUNoQyxXQUFVO0FBQUEsVUFBaUQ7QUFBQTtBQUFBLFFBSDdEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQU1BO0FBQUEsU0FSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBU0E7QUFBQSxJQUVBLHVCQUFDLFNBQU0sT0FBT2EsRUFBRSxpQkFBaUIsR0FDL0IsaUNBQUMsU0FBSSxXQUFVLDBCQUNiO0FBQUEsNkJBQUMsUUFBSyxRQUFRWSxRQUFRdkIsYUFBYSxPQUFPLFNBQVMsTUFBTXlGLElBQUksWUFBWSxLQUFLLEdBQUUsbUJBQWhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0VHLE9BQU9DLEtBQUsxRyxjQUFjLEVBQXNCMEU7QUFBQUEsUUFBSSxDQUFDaUMsTUFDckQsdUJBQUMsUUFBYSxRQUFRdkUsUUFBUXZCLGFBQWE4RixHQUFHLFNBQVMsTUFBTUwsSUFBSSxZQUFZSyxDQUFDLEdBQzNFM0cseUJBQWUyRyxDQUFDLEVBQUVsRyxTQURWa0csR0FBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxNQUNEO0FBQUEsU0FSSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBU0EsS0FWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBV0E7QUFBQSxJQUVBLHVCQUFDLFNBQU0sT0FBT25GLEVBQUUsYUFBYSxHQUMzQixpQ0FBQyxjQUFXLE9BQU9ZLFFBQVF4QixNQUFNLFVBQVUsQ0FBQzRGLE1BQU1GLElBQUksUUFBUUUsQ0FBQyxHQUFHLGVBQWEsUUFBL0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUErRSxLQURqRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxJQUVBLHVCQUFDLFNBQU0sT0FBT2hGLEVBQUUsZ0JBQWdCLEdBQzlCLGlDQUFDLFNBQUksV0FBVSwwQkFDWCxXQUFDLE9BQU8sU0FBUyxZQUFZLE9BQU8sRUFBWWtEO0FBQUFBLE1BQUksQ0FBQ2tDLE1BQ3JELHVCQUFDLFFBQWEsUUFBUXhFLFFBQVF0QixjQUFjOEYsR0FBRyxTQUFTLE1BQU1OLElBQUksYUFBYU0sQ0FBQyxHQUM3RUEsZ0JBQU0sUUFBUSxhQUFhQSxLQURuQkEsR0FBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxJQUNELEtBTEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU1BLEtBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVFBO0FBQUEsSUFFQSx1QkFBQyxTQUFNLE9BQU8sY0FBYy9HLE1BQU11QyxRQUFRckIsUUFBUSxDQUFDLElBQ2pEO0FBQUE7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE1BQUs7QUFBQSxVQUNMLGNBQVc7QUFBQSxVQUNYLEtBQUs7QUFBQSxVQUNMLEtBQUtMO0FBQUFBLFVBQ0wsTUFBTTtBQUFBLFVBQ04sT0FBTzBCLFFBQVFyQjtBQUFBQSxVQUNmLFVBQVUsQ0FBQ2lFLE1BQU1zQixJQUFJLFlBQVlPLE9BQU83QixFQUFFQyxPQUFPekUsS0FBSyxDQUFDO0FBQUEsVUFDdkQsV0FBVTtBQUFBO0FBQUEsUUFSWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFRb0M7QUFBQSxNQUVwQyx1QkFBQyxPQUFFLFdBQVUsMkJBQTBCLHNEQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTZFO0FBQUEsU0FYL0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVlBO0FBQUEsSUFFQSx1QkFBQyxTQUFNLE9BQU9nQixFQUFFLG1CQUFtQixHQUNqQyxpQ0FBQyxTQUFJLFdBQVUsMEJBQ1g7QUFBQSxNQUNBLEVBQUUyRCxLQUFLLE9BQU8xRSxPQUFPZSxFQUFFLFlBQVksRUFBRTtBQUFBLE1BQ3JDLEVBQUUyRCxLQUFLLFVBQVUxRSxPQUFPZSxFQUFFLHNCQUFzQixFQUFFO0FBQUEsTUFDbEQsRUFBRTJELEtBQUssWUFBWTFFLE9BQU9lLEVBQUUsd0JBQXdCLEVBQUU7QUFBQSxNQUN0RCxFQUFFMkQsS0FBSyxXQUFXMUUsT0FBT2UsRUFBRSx3QkFBd0IsRUFBRTtBQUFBLElBQUMsRUFDNUNrRDtBQUFBQSxNQUFJLENBQUNXLFdBQ2Y7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUVDLFFBQVFqRCxRQUFRZixjQUFjZ0UsT0FBT0Y7QUFBQUEsVUFDckMsU0FBUyxNQUFNbUIsSUFBSSxhQUFhakIsT0FBT0YsR0FBRztBQUFBLFVBRXpDRSxpQkFBTzVFO0FBQUFBO0FBQUFBLFFBSkg0RSxPQUFPRjtBQUFBQSxRQURkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFNQTtBQUFBLElBQ0QsS0FkSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBZUEsS0FoQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWlCQTtBQUFBLElBRUEsdUJBQUMsU0FBTSxPQUFPM0QsRUFBRSxpQkFBaUIsR0FDL0IsaUNBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSw2QkFBQyxTQUFNLE9BQU9BLEVBQUUsa0JBQWtCLEdBQUcsU0FBU1ksUUFBUXBCLGVBQWUsVUFBVSxDQUFDd0YsTUFBTUYsSUFBSSxpQkFBaUJFLENBQUMsS0FBNUc7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE4RztBQUFBLE1BQzlHLHVCQUFDLFNBQU0sT0FBT2hGLEVBQUUsY0FBYyxHQUFHLFNBQVNZLFFBQVFuQixXQUFXLFVBQVUsQ0FBQ3VGLE1BQU1GLElBQUksYUFBYUUsQ0FBQyxLQUFoRztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWtHO0FBQUEsTUFDbEcsdUJBQUMsU0FBTSxPQUFPaEYsRUFBRSxpQkFBaUIsR0FBRyxTQUFTWSxRQUFRakIsY0FBYyxVQUFVLENBQUNxRixNQUFNRixJQUFJLGdCQUFnQkUsQ0FBQyxLQUF6RztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTJHO0FBQUEsTUFDM0csdUJBQUMsU0FBTSxPQUFPaEYsRUFBRSxpQkFBaUIsR0FBRyxTQUFTWSxRQUFRbEIsY0FBYyxVQUFVLENBQUNzRixNQUFNRixJQUFJLGdCQUFnQkUsQ0FBQyxLQUF6RztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTJHO0FBQUEsU0FKN0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUtBLEtBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU9BO0FBQUEsSUFFQSx1QkFBQyxTQUFNLE9BQU9oRixFQUFFLGtCQUFrQixHQUNoQyxpQ0FBQyxTQUFJLFdBQVUsMEJBQ1p2Qix1QkFBYTZHLE1BQU0sR0FBRyxFQUFFLEVBQUVwQztBQUFBQSxNQUFJLENBQUNTLFFBQzlCO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFFQyxRQUFRL0MsUUFBUWhCLFVBQVUyQyxTQUFTb0IsR0FBRztBQUFBLFVBQ3RDLFNBQVMsTUFDUG1CO0FBQUFBLFlBQ0U7QUFBQSxZQUNBbEUsUUFBUWhCLFVBQVUyQyxTQUFTb0IsR0FBRyxJQUMxQi9DLFFBQVFoQixVQUFVNkIsT0FBTyxDQUFDYSxNQUFNQSxNQUFNcUIsR0FBRyxJQUN6QyxDQUFDLEdBQUcvQyxRQUFRaEIsV0FBVytELEdBQUc7QUFBQSxVQUNoQztBQUFBLFVBR0QzRCxZQUFFLFdBQVcyRCxHQUFHLEVBQVc7QUFBQTtBQUFBLFFBWHZCQTtBQUFBQSxRQURQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFhQTtBQUFBLElBQ0QsS0FoQkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWlCQSxLQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBbUJBO0FBQUEsT0FwR0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXFHQTtBQUVKO0FBQUNrQixJQTVHUUYsYUFBVztBQUFBLFVBQ0o3RixPQUFPO0FBQUE7QUFBQSxNQURkNkY7QUE4R1QsU0FBU1ksTUFBTSxFQUFFdEcsT0FBT3VHLFNBQXVELEdBQUc7QUFDaEYsU0FDRSx1QkFBQyxTQUNDO0FBQUEsMkJBQUMsT0FBRSxXQUFVLDRDQUE0Q3ZHLG1CQUF6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQStEO0FBQUEsSUFDOUR1RztBQUFBQSxPQUZIO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FHQTtBQUVKO0FBQUNDLE1BUFFGO0FBU1QsU0FBU0csS0FBSyxFQUFFQyxRQUFRQyxTQUFTSixTQUE4RSxHQUFHO0FBQ2hILFNBQ0U7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNDLE1BQUs7QUFBQSxNQUNMLGdCQUFjRztBQUFBQSxNQUNkO0FBQUEsTUFDQSxXQUFXL0c7QUFBQUEsUUFDVDtBQUFBLFFBQ0ErRyxTQUFTLHNCQUFzQjtBQUFBLE1BQ2pDO0FBQUEsTUFFQ0g7QUFBQUE7QUFBQUEsSUFUSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFVQTtBQUVKO0FBQUNLLE1BZFFIO0FBZ0JULFNBQVNJLE1BQU0sRUFBRTdHLE9BQU84RyxTQUFTbkIsU0FBOEUsR0FBRztBQUNoSCxTQUNFLHVCQUFDLFdBQU0sV0FBVSxrRUFDZjtBQUFBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxNQUFLO0FBQUEsUUFDTDtBQUFBLFFBQ0EsVUFBVSxDQUFDcEIsTUFBTW9CLFNBQVNwQixFQUFFQyxPQUFPc0MsT0FBTztBQUFBLFFBQzFDLFdBQVU7QUFBQTtBQUFBLE1BSlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBSW9DO0FBQUEsSUFFbkM5RztBQUFBQSxPQVBIO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FRQTtBQUVKO0FBQUMrRyxNQVpRRjtBQUFLLElBQUFuSSxJQUFBSSxLQUFBa0ksS0FBQXhCLEtBQUF5QixLQUFBVCxLQUFBSSxLQUFBRztBQUFBLGFBQUFySSxJQUFBO0FBQUEsYUFBQUksS0FBQTtBQUFBLGFBQUFrSSxLQUFBO0FBQUEsYUFBQXhCLEtBQUE7QUFBQSxhQUFBeUIsS0FBQTtBQUFBLGFBQUFULEtBQUE7QUFBQSxhQUFBSSxLQUFBO0FBQUEsYUFBQUcsS0FBQSIsIm5hbWVzIjpbInVzZUVmZmVjdCIsInVzZU1lbW8iLCJ1c2VTdGF0ZSIsIkxpbmsiLCJ1c2VTZWFyY2hQYXJhbXMiLCJTbGlkZXJzSG9yaXpvbnRhbCIsIlNwYXJrbGVzIiwiQ29tcGFzcyIsInVzZUhhYml0byIsIlBhZ2VIZWFkZXIiLCJTcGFjZUNhcmQiLCJTcGFjZUNhcmRTa2VsZXRvbiIsIkNvYWNobWFyayIsImxhenkiLCJTdXNwZW5zZSIsIk1hcCIsIk1hcEljb24iLCJMaXN0IiwiTGlzdEljb24iLCJTcGFjZU1hcCIsIl9jIiwidGhlbiIsIm0iLCJkZWZhdWx0IiwiX2MyIiwiQnV0dG9uIiwiTW9kYWwiLCJzY29yZUFsbCIsIm5lYXJieUFsdGVybmF0aXZlcyIsImFjY2VwdHNPY2N1cGFuY3kiLCJtb25leSIsImlzU3RhbGUiLCJtb25leUNvbXBhY3QiLCJDQVRFR09SWV9TVFlMRSIsIkFNRU5JVFlfS0VZUyIsIkFyZWFQaWNrZXIiLCJ0cnVzdExldmVsIiwiY24iLCJkaXNwbGF5SW1hZ2UiLCJ1c2VJMThuIiwiU09SVFMiLCJ2YWx1ZSIsImxhYmVsIiwiUFJJQ0VfQ0VJTElORyIsIkRFRkFVTFRTIiwiYXJlYSIsImNhdGVnb3J5IiwiZ2VvZ3JhcGh5IiwicHJpY2VNYXgiLCJhdmFpbGFibGVPbmx5IiwiZnJlc2hPbmx5IiwidmVyaWZpZWRPbmx5IiwiZnVsbENvc3RPbmx5IiwiYW1lbml0aWVzIiwib2NjdXBhbmN5IiwiU2VhcmNoIiwiX3MiLCJ0IiwidmlldyIsInNldFZpZXciLCJwYXJhbXMiLCJsaXN0aW5ncyIsInJlYWR5IiwicmVxdWlyZW1lbnRzIiwiaGFzU3RhdGVkTmVlZHMiLCJpc1NhdmVkIiwidG9nZ2xlU2F2ZWQiLCJpc0NvbXBhcmluZyIsInRvZ2dsZUNvbXBhcmUiLCJmaWx0ZXJzIiwic2V0RmlsdGVycyIsInNvcnQiLCJzZXRTb3J0Iiwic2hlZXRPcGVuIiwic2V0U2hlZXRPcGVuIiwiY2F0ZWdvcnlQYXJhbSIsImdldCIsImdlb1BhcmFtIiwiZiIsIm1hdGNoZXMiLCJyZXN1bHRzIiwiZmlsdGVyZWQiLCJmaWx0ZXIiLCJsIiwic3BhY2UiLCJwcm9wZXJ0eSIsInRyYW5zYWN0aW9uIiwiY29zdCIsInByaWNlIiwiYXZhaWxhYmlsaXR5Iiwic3RhdHVzIiwibGFzdFVwZGF0ZWQiLCJ2ZXJpZmljYXRpb24iLCJlc3RpbWF0ZWRNb250aGx5Iiwic29tZSIsImEiLCJpbmNsdWRlcyIsInNjb3JlIiwiaWQiLCJiIiwiRGF0ZSIsImdldFRpbWUiLCJhdHRyaWJ1dGVzIiwic2l6ZVNxZnQiLCJ0aGluIiwibGVuZ3RoIiwibmVhcmJ5IiwibWFwIiwiciIsImFjdGl2ZUNvdW50IiwiY291bnRBY3RpdmUiLCJidWRnZXRNaW4iLCJidWRnZXRNYXgiLCJlIiwidGFyZ2V0IiwicyIsImtleSIsImljb24iLCJvcHRpb24iLCJBcnJheSIsImZyb20iLCJfIiwiaSIsInVuZGVmaW5lZCIsImxpc3RpbmciLCJyZWFzb24iLCJpbWFnZXMiLCJuYW1lIiwiTm90aGluZ1lldCIsIm9uUmVzZXQiLCJfYzQiLCJuIiwiRmlsdGVyUGFuZWwiLCJvbkNoYW5nZSIsIl9zMiIsInNldCIsImsiLCJ2IiwiT2JqZWN0Iiwia2V5cyIsImMiLCJnIiwiTnVtYmVyIiwic2xpY2UiLCJHcm91cCIsImNoaWxkcmVuIiwiX2M2IiwiUGlsbCIsImFjdGl2ZSIsIm9uQ2xpY2siLCJfYzciLCJDaGVjayIsImNoZWNrZWQiLCJfYzgiLCJfYzMiLCJfYzUiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiU2VhcmNoLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VFZmZlY3QsIHVzZU1lbW8sIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBMaW5rLCB1c2VTZWFyY2hQYXJhbXMgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xuaW1wb3J0IHsgU2xpZGVyc0hvcml6b250YWwsIFNwYXJrbGVzLCBDb21wYXNzIH0gZnJvbSBcImx1Y2lkZS1yZWFjdFwiO1xuaW1wb3J0IHsgdXNlSGFiaXRvIH0gZnJvbSBcIkAvaG9va3MvdXNlSGFiaXRvXCI7XG5pbXBvcnQgeyBQYWdlSGVhZGVyIH0gZnJvbSBcIkAvY29tcG9uZW50cy9sYXlvdXQvUGFnZUhlYWRlclwiO1xuaW1wb3J0IHsgU3BhY2VDYXJkIH0gZnJvbSBcIkAvY29tcG9uZW50cy9zcGFjZS9TcGFjZUNhcmRcIjtcbmltcG9ydCB7IFNwYWNlQ2FyZFNrZWxldG9uIH0gZnJvbSBcIkAvY29tcG9uZW50cy91aS9Ta2VsZXRvblwiO1xuaW1wb3J0IHsgQ29hY2htYXJrIH0gZnJvbSBcIkAvY29tcG9uZW50cy91aS9Db2FjaG1hcmtcIjtcbmltcG9ydCB7IGxhenksIFN1c3BlbnNlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBNYXAgYXMgTWFwSWNvbiwgTGlzdCBhcyBMaXN0SWNvbiB9IGZyb20gXCJsdWNpZGUtcmVhY3RcIjtcblxuLy8gTGVhZmxldCBpcyBhIGxhcmdlIGRlcGVuZGVuY3kgYW5kIG1vc3QgdmlzaXRzIG5ldmVyIG9wZW4gdGhlIG1hcCwgc28gaXQgaXNcbi8vIGxvYWRlZCBvbmx5IHdoZW4gc29tZW9uZSBhc2tzIGZvciBpdC5cbmNvbnN0IFNwYWNlTWFwID0gbGF6eSgoKSA9PlxuICBpbXBvcnQoXCJAL2NvbXBvbmVudHMvc3BhY2UvU3BhY2VNYXBcIikudGhlbigobSkgPT4gKHsgZGVmYXVsdDogbS5TcGFjZU1hcCB9KSksXG4pO1xuaW1wb3J0IHsgQnV0dG9uIH0gZnJvbSBcIkAvY29tcG9uZW50cy91aS9CdXR0b25cIjtcbmltcG9ydCB7IE1vZGFsIH0gZnJvbSBcIkAvY29tcG9uZW50cy91aS9Nb2RhbFwiO1xuaW1wb3J0IHsgc2NvcmVBbGwsIG5lYXJieUFsdGVybmF0aXZlcywgYWNjZXB0c09jY3VwYW5jeSB9IGZyb20gXCJAL2xpYi9tYXRjaGluZ1wiO1xuaW1wb3J0IHsgbW9uZXksIGlzU3RhbGUsIG1vbmV5Q29tcGFjdCB9IGZyb20gXCJAL2xpYi9mb3JtYXRcIjtcbmltcG9ydCB7IENBVEVHT1JZX1NUWUxFLCBBTUVOSVRZX0tFWVMgfSBmcm9tIFwiQC9kYXRhL2NhdGFsb2dcIjtcbmltcG9ydCB7IEFyZWFQaWNrZXIgfSBmcm9tIFwiQC9jb21wb25lbnRzL3VpL0FyZWFQaWNrZXJcIjtcbmltcG9ydCB7IHRydXN0TGV2ZWwgfSBmcm9tIFwiQC9jb21wb25lbnRzL3NwYWNlL2JhZGdlc1wiO1xuaW1wb3J0IHsgY24gfSBmcm9tIFwiQC9saWIvY25cIjtcbmltcG9ydCB7IGRpc3BsYXlJbWFnZSB9IGZyb20gXCJAL2xpYi9sb2NhbGl6ZVwiO1xuaW1wb3J0IHsgdXNlSTE4biB9IGZyb20gXCJAL2kxOG5cIjtcbmltcG9ydCB0eXBlIHsgQW1lbml0eUtleSwgR2VvZ3JhcGh5LCBTcGFjZUNhdGVnb3J5IH0gZnJvbSBcIkAvdHlwZXMvc3BhY2VcIjtcblxudHlwZSBTb3J0S2V5ID0gXCJiZXN0LW1hdGNoXCIgfCBcInByaWNlLWxvd1wiIHwgXCJwcmljZS1oaWdoXCIgfCBcInJlY2VudFwiIHwgXCJzaXplXCI7XG5cbmNvbnN0IFNPUlRTOiBBcnJheTx7IHZhbHVlOiBTb3J0S2V5OyBsYWJlbDogc3RyaW5nIH0+ID0gW1xuICB7IHZhbHVlOiBcImJlc3QtbWF0Y2hcIiwgbGFiZWw6IFwiQmVzdCBtYXRjaFwiIH0sXG4gIHsgdmFsdWU6IFwicHJpY2UtbG93XCIsIGxhYmVsOiBcIlByaWNlOiBsb3cgdG8gaGlnaFwiIH0sXG4gIHsgdmFsdWU6IFwicHJpY2UtaGlnaFwiLCBsYWJlbDogXCJQcmljZTogaGlnaCB0byBsb3dcIiB9LFxuICB7IHZhbHVlOiBcInJlY2VudFwiLCBsYWJlbDogXCJSZWNlbnRseSB1cGRhdGVkXCIgfSxcbiAgeyB2YWx1ZTogXCJzaXplXCIsIGxhYmVsOiBcIkxhcmdlc3QgZmlyc3RcIiB9LFxuXTtcblxuaW50ZXJmYWNlIEZpbHRlcnMge1xuICBhcmVhOiBzdHJpbmcgfCBcImFsbFwiO1xuICBjYXRlZ29yeTogU3BhY2VDYXRlZ29yeSB8IFwiYWxsXCI7XG4gIGdlb2dyYXBoeTogR2VvZ3JhcGh5IHwgXCJhbGxcIjtcbiAgcHJpY2VNYXg6IG51bWJlcjtcbiAgYXZhaWxhYmxlT25seTogYm9vbGVhbjtcbiAgZnJlc2hPbmx5OiBib29sZWFuO1xuICB2ZXJpZmllZE9ubHk6IGJvb2xlYW47XG4gIGZ1bGxDb3N0T25seTogYm9vbGVhbjtcbiAgYW1lbml0aWVzOiBBbWVuaXR5S2V5W107XG4gIG9jY3VwYW5jeTogXCJhbnlcIiB8IFwiZmFtaWx5XCIgfCBcImJhY2hlbG9yXCIgfCBcInN0dWRlbnRcIjtcbn1cblxuY29uc3QgUFJJQ0VfQ0VJTElORyA9IDE1MDAwMDtcblxuY29uc3QgREVGQVVMVFM6IEZpbHRlcnMgPSB7XG4gIGFyZWE6IFwiYWxsXCIsXG4gIGNhdGVnb3J5OiBcImFsbFwiLFxuICBnZW9ncmFwaHk6IFwiYWxsXCIsXG4gIHByaWNlTWF4OiBQUklDRV9DRUlMSU5HLFxuICBhdmFpbGFibGVPbmx5OiB0cnVlLFxuICBmcmVzaE9ubHk6IGZhbHNlLFxuICB2ZXJpZmllZE9ubHk6IGZhbHNlLFxuICBmdWxsQ29zdE9ubHk6IGZhbHNlLFxuICBhbWVuaXRpZXM6IFtdLFxuICBvY2N1cGFuY3k6IFwiYW55XCIsXG59O1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBTZWFyY2goKSB7XG4gIGNvbnN0IHsgdCB9ID0gdXNlSTE4bigpO1xuICBjb25zdCBbdmlldywgc2V0Vmlld10gPSB1c2VTdGF0ZTxcImxpc3RcIiB8IFwibWFwXCI+KFwibGlzdFwiKTtcbiAgY29uc3QgW3BhcmFtc10gPSB1c2VTZWFyY2hQYXJhbXMoKTtcbiAgY29uc3QgeyBsaXN0aW5ncywgcmVhZHksIHJlcXVpcmVtZW50cywgaGFzU3RhdGVkTmVlZHMsIGlzU2F2ZWQsIHRvZ2dsZVNhdmVkLCBpc0NvbXBhcmluZywgdG9nZ2xlQ29tcGFyZSB9ID1cbiAgICB1c2VIYWJpdG8oKTtcblxuICBjb25zdCBbZmlsdGVycywgc2V0RmlsdGVyc10gPSB1c2VTdGF0ZTxGaWx0ZXJzPihERUZBVUxUUyk7XG4gIGNvbnN0IFtzb3J0LCBzZXRTb3J0XSA9IHVzZVN0YXRlPFNvcnRLZXk+KFwiYmVzdC1tYXRjaFwiKTtcbiAgY29uc3QgW3NoZWV0T3Blbiwgc2V0U2hlZXRPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKTtcblxuICAvLyBEZWVwIGxpbmtzIGZyb20gdGhlIGhvbWVwYWdlIHJhaWxzIGFuZCBjYXRlZ29yeSBjYXJkcy5cbiAgY29uc3QgY2F0ZWdvcnlQYXJhbSA9IHBhcmFtcy5nZXQoXCJjYXRlZ29yeVwiKTtcbiAgY29uc3QgZ2VvUGFyYW0gPSBwYXJhbXMuZ2V0KFwiZ2VvZ3JhcGh5XCIpO1xuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIHNldEZpbHRlcnMoKGYpID0+ICh7XG4gICAgICAuLi5mLFxuICAgICAgY2F0ZWdvcnk6IChjYXRlZ29yeVBhcmFtIGFzIFNwYWNlQ2F0ZWdvcnkpID8/IFwiYWxsXCIsXG4gICAgICBnZW9ncmFwaHk6IChnZW9QYXJhbSBhcyBHZW9ncmFwaHkpID8/IFwiYWxsXCIsXG4gICAgfSkpO1xuICB9LCBbY2F0ZWdvcnlQYXJhbSwgZ2VvUGFyYW1dKTtcblxuICBjb25zdCBtYXRjaGVzID0gdXNlTWVtbygoKSA9PiBzY29yZUFsbChsaXN0aW5ncywgcmVxdWlyZW1lbnRzKSwgW2xpc3RpbmdzLCByZXF1aXJlbWVudHNdKTtcblxuICBjb25zdCByZXN1bHRzID0gdXNlTWVtbygoKSA9PiB7XG4gICAgY29uc3QgZmlsdGVyZWQgPSBsaXN0aW5ncy5maWx0ZXIoKGwpID0+IHtcbiAgICAgIGNvbnN0IHsgc3BhY2UsIHByb3BlcnR5IH0gPSBsO1xuICAgICAgaWYgKGZpbHRlcnMuYXJlYSAhPT0gXCJhbGxcIiAmJiBwcm9wZXJ0eS5hcmVhICE9PSBmaWx0ZXJzLmFyZWEpIHJldHVybiBmYWxzZTtcbiAgICAgIGlmIChmaWx0ZXJzLmNhdGVnb3J5ICE9PSBcImFsbFwiICYmIHNwYWNlLmNhdGVnb3J5ICE9PSBmaWx0ZXJzLmNhdGVnb3J5KSByZXR1cm4gZmFsc2U7XG4gICAgICBpZiAoZmlsdGVycy5nZW9ncmFwaHkgIT09IFwiYWxsXCIgJiYgcHJvcGVydHkuZ2VvZ3JhcGh5ICE9PSBmaWx0ZXJzLmdlb2dyYXBoeSkgcmV0dXJuIGZhbHNlO1xuICAgICAgaWYgKHNwYWNlLnRyYW5zYWN0aW9uID09PSBcInJlbnRcIiAmJiBzcGFjZS5jb3N0LnByaWNlID4gZmlsdGVycy5wcmljZU1heCkgcmV0dXJuIGZhbHNlO1xuICAgICAgaWYgKGZpbHRlcnMuYXZhaWxhYmxlT25seSAmJiAoc3BhY2UuYXZhaWxhYmlsaXR5LnN0YXR1cyA9PT0gXCJvY2N1cGllZFwiIHx8IHNwYWNlLmF2YWlsYWJpbGl0eS5zdGF0dXMgPT09IFwibWFpbnRlbmFuY2VcIikpXG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgIGlmIChmaWx0ZXJzLmZyZXNoT25seSAmJiBpc1N0YWxlKHNwYWNlLmxhc3RVcGRhdGVkKSkgcmV0dXJuIGZhbHNlO1xuICAgICAgaWYgKGZpbHRlcnMudmVyaWZpZWRPbmx5ICYmIHRydXN0TGV2ZWwoc3BhY2UudmVyaWZpY2F0aW9uKSAhPT0gXCJ2ZXJpZmllZFwiKSByZXR1cm4gZmFsc2U7XG4gICAgICBpZiAoZmlsdGVycy5mdWxsQ29zdE9ubHkgJiYgc3BhY2UuY29zdC5lc3RpbWF0ZWRNb250aGx5ID09PSBudWxsKSByZXR1cm4gZmFsc2U7XG4gICAgICBpZiAoZmlsdGVycy5hbWVuaXRpZXMuc29tZSgoYSkgPT4gIXNwYWNlLmFtZW5pdGllcy5pbmNsdWRlcyhhKSkpIHJldHVybiBmYWxzZTtcbiAgICAgIC8vIEEgcGxhY2UgdGhhdCB3b24ndCB0YWtlIHlvdSBzaG91bGRuJ3QgYXBwZWFyIGF0IGFsbCwgc2NvcmVkIG9yIG5vdC5cbiAgICAgIGlmICghYWNjZXB0c09jY3VwYW5jeShsLCBmaWx0ZXJzLm9jY3VwYW5jeSkpIHJldHVybiBmYWxzZTtcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH0pO1xuXG4gICAgY29uc3Qgc2NvcmUgPSAoaWQ6IHN0cmluZykgPT4gbWF0Y2hlcy5nZXQoaWQpPy5zY29yZSA/PyAwO1xuXG4gICAgcmV0dXJuIFsuLi5maWx0ZXJlZF0uc29ydCgoYSwgYikgPT4ge1xuICAgICAgc3dpdGNoIChzb3J0KSB7XG4gICAgICAgIGNhc2UgXCJwcmljZS1sb3dcIjpcbiAgICAgICAgICByZXR1cm4gYS5zcGFjZS5jb3N0LnByaWNlIC0gYi5zcGFjZS5jb3N0LnByaWNlO1xuICAgICAgICBjYXNlIFwicHJpY2UtaGlnaFwiOlxuICAgICAgICAgIHJldHVybiBiLnNwYWNlLmNvc3QucHJpY2UgLSBhLnNwYWNlLmNvc3QucHJpY2U7XG4gICAgICAgIGNhc2UgXCJyZWNlbnRcIjpcbiAgICAgICAgICByZXR1cm4gbmV3IERhdGUoYi5zcGFjZS5sYXN0VXBkYXRlZCkuZ2V0VGltZSgpIC0gbmV3IERhdGUoYS5zcGFjZS5sYXN0VXBkYXRlZCkuZ2V0VGltZSgpO1xuICAgICAgICBjYXNlIFwic2l6ZVwiOlxuICAgICAgICAgIHJldHVybiAoYi5zcGFjZS5hdHRyaWJ1dGVzLnNpemVTcWZ0ID8/IDApIC0gKGEuc3BhY2UuYXR0cmlidXRlcy5zaXplU3FmdCA/PyAwKTtcbiAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICByZXR1cm4gc2NvcmUoYi5zcGFjZS5pZCkgLSBzY29yZShhLnNwYWNlLmlkKTtcbiAgICAgIH1cbiAgICB9KTtcbiAgfSwgW2xpc3RpbmdzLCBmaWx0ZXJzLCBzb3J0LCBtYXRjaGVzXSk7XG5cbiAgY29uc3QgdGhpbiA9IHJlc3VsdHMubGVuZ3RoIDwgNDtcbiAgY29uc3QgbmVhcmJ5ID0gdXNlTWVtbyhcbiAgICAoKSA9PiAodGhpbiAmJiByZWFkeSA/IG5lYXJieUFsdGVybmF0aXZlcyhsaXN0aW5ncywgcmVxdWlyZW1lbnRzLCByZXN1bHRzLm1hcCgocikgPT4gci5zcGFjZS5pZCkpIDogW10pLFxuICAgIFt0aGluLCByZWFkeSwgbGlzdGluZ3MsIHJlcXVpcmVtZW50cywgcmVzdWx0c10sXG4gICk7XG5cbiAgY29uc3QgYWN0aXZlQ291bnQgPSBjb3VudEFjdGl2ZShmaWx0ZXJzKTtcblxuICByZXR1cm4gKFxuICAgIDw+XG4gICAgICA8UGFnZUhlYWRlclxuICAgICAgICB0aXRsZT17ZmlsdGVycy5jYXRlZ29yeSA9PT0gXCJhbGxcIiA/IFwiRmluZCBhIHNwYWNlXCIgOiBDQVRFR09SWV9TVFlMRVtmaWx0ZXJzLmNhdGVnb3J5XS5sYWJlbH1cbiAgICAgICAgbGVhZD17XG4gICAgICAgICAgaGFzU3RhdGVkTmVlZHNcbiAgICAgICAgICAgID8gYFNjb3JlZCBhZ2FpbnN0IHlvdXIgbmVlZHM6ICR7cmVxdWlyZW1lbnRzLmFyZWF9LCAke21vbmV5KHJlcXVpcmVtZW50cy5idWRnZXRNaW4pfeKAkyR7bW9uZXkocmVxdWlyZW1lbnRzLmJ1ZGdldE1heCl9LmBcbiAgICAgICAgICAgIDogXCJCcm93c2UgZXZlcnl0aGluZyBvbiB0aGUgcGxhdGZvcm0sIG9yIHRlbGwgdXMgd2hhdCB5b3UgbmVlZCBhbmQgZWFjaCBzcGFjZSBnZXRzIGEgc2NvcmUuXCJcbiAgICAgICAgfVxuICAgICAgICBhY3Rpb25zPXtcbiAgICAgICAgICA8TGluayB0bz1cIi9maW5kXCI+XG4gICAgICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9e2hhc1N0YXRlZE5lZWRzID8gXCJzZWNvbmRhcnlcIiA6IFwicHJpbWFyeVwifT5cbiAgICAgICAgICAgICAgPFNwYXJrbGVzIHNpemU9ezE2fSBhcmlhLWhpZGRlbiAvPlxuICAgICAgICAgICAgICB7aGFzU3RhdGVkTmVlZHMgPyBcIkNoYW5nZSBuZWVkc1wiIDogXCJUZWxsIHVzIHdoYXQgeW91IG5lZWRcIn1cbiAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgIDwvTGluaz5cbiAgICAgICAgfVxuICAgICAgLz5cblxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb250YWluZXItcGFnZSBweS04IG1kOnB5LTEwXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBnYXAtOCBsZzpncmlkLWNvbHMtWzE2cmVtXzFmcl1cIj5cbiAgICAgICAgICA8YXNpZGUgY2xhc3NOYW1lPVwiaGlkZGVuIGxnOmJsb2NrXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInN0aWNreSB0b3AtMjQgbWF4LWgtW2NhbGMoMTAwdmgtOHJlbSldIG92ZXJmbG93LXktYXV0byBvdmVyc2Nyb2xsLWNvbnRhaW4gcm91bmRlZC1jYXJkIGJnLXN1cmZhY2UgcC01IHJpbmctMSByaW5nLWhhaXJsaW5lXCI+XG4gICAgICAgICAgICAgIDxGaWx0ZXJQYW5lbCBmaWx0ZXJzPXtmaWx0ZXJzfSBvbkNoYW5nZT17c2V0RmlsdGVyc30gLz5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvYXNpZGU+XG5cbiAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi01IGZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRudW0gdGV4dC1tdXRlZFwiPlxuICAgICAgICAgICAgICAgIHtyZWFkeSA/IGAke3Jlc3VsdHMubGVuZ3RofSAke3Jlc3VsdHMubGVuZ3RoID09PSAxID8gXCJzcGFjZVwiIDogXCJzcGFjZXNcIn1gIDogXCJMb2FkaW5n4oCmXCJ9XG4gICAgICAgICAgICAgIDwvcD5cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1sLWF1dG8gZmxleCBmbGV4LXdyYXAgaXRlbXMtY2VudGVyIGp1c3RpZnktZW5kIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQtc20gdGV4dC1tdXRlZFwiPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaGlkZGVuIHNtOmlubGluZVwiPlNvcnQ8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8c2VsZWN0XG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzb3J0fVxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFNvcnQoZS50YXJnZXQudmFsdWUgYXMgU29ydEtleSl9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImgtMTAgcm91bmRlZC1mdWxsIGJnLXN1cmZhY2UgcHgtMyB0ZXh0LXNtIHRleHQtaW5rIHJpbmctMSByaW5nLWhhaXJsaW5lLXN0cm9uZyBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctYXF1YS02MDBcIlxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICB7U09SVFMubWFwKChzKSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiBrZXk9e3MudmFsdWV9IHZhbHVlPXtzLnZhbHVlfT5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtzLmxhYmVsfVxuICAgICAgICAgICAgICAgICAgICAgIDwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XG5cbiAgICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAgICByb2xlPVwiZ3JvdXBcIlxuICAgICAgICAgICAgICAgICAgYXJpYS1sYWJlbD17YCR7dChcIm1hcC5saXN0XCIpfSAvICR7dChcIm1hcC50aXRsZVwiKX1gfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgcm91bmRlZC1mdWxsIGJnLWl2b3J5LWRlZXAgcC0wLjUgcmluZy0xIHJpbmctaGFpcmxpbmVcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIHsoW1xuICAgICAgICAgICAgICAgICAgICB7IGtleTogXCJsaXN0XCIgYXMgY29uc3QsIGxhYmVsOiB0KFwibWFwLmxpc3RcIiksIGljb246IExpc3RJY29uIH0sXG4gICAgICAgICAgICAgICAgICAgIHsga2V5OiBcIm1hcFwiIGFzIGNvbnN0LCBsYWJlbDogdChcIm1hcC50aXRsZVwiKSwgaWNvbjogTWFwSWNvbiB9LFxuICAgICAgICAgICAgICAgICAgXSkubWFwKChvcHRpb24pID0+IChcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgIGtleT17b3B0aW9uLmtleX1cbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICBhcmlhLXByZXNzZWQ9e3ZpZXcgPT09IG9wdGlvbi5rZXl9XG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0VmlldyhvcHRpb24ua2V5KX1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgICAgICAgICAgICAgICAgICAgXCJwcmVzcyBpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSByb3VuZGVkLWZ1bGwgcHgtMyBweS0yIHRleHQteHMgZm9udC1ib2xkIHRyYW5zaXRpb24tY29sb3JzXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICB2aWV3ID09PSBvcHRpb24ua2V5ID8gXCJiZy1pbmsgdGV4dC1pdm9yeVwiIDogXCJ0ZXh0LW11dGVkIGhvdmVyOnRleHQtaW5rXCIsXG4gICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24uaWNvbiBzaXplPXsxNH0gYXJpYS1oaWRkZW4gLz5cbiAgICAgICAgICAgICAgICAgICAgICB7b3B0aW9uLmxhYmVsfVxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwic2Vjb25kYXJ5XCIgY2xhc3NOYW1lPVwibGc6aGlkZGVuXCIgb25DbGljaz17KCkgPT4gc2V0U2hlZXRPcGVuKHRydWUpfT5cbiAgICAgICAgICAgICAgICAgIDxTbGlkZXJzSG9yaXpvbnRhbCBzaXplPXsxNn0gYXJpYS1oaWRkZW4gLz5cbiAgICAgICAgICAgICAgICAgIHt0KFwic2VhcmNoLmZpbHRlcnNcIil9XG4gICAgICAgICAgICAgICAgICB7YWN0aXZlQ291bnQgPiAwICYmIChcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicm91bmRlZC1mdWxsIGJnLWFxdWEtNDAwIHB4LTEuNSB0ZXh0LVswLjY1cmVtXSBmb250LWJvbGQgdG51bSB0ZXh0LWlua1wiPlxuICAgICAgICAgICAgICAgICAgICAgIHthY3RpdmVDb3VudH1cbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgeyFyZWFkeSA/IChcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzdGFnZ2VyIGdyaWQgZ2FwLTUgc206Z3JpZC1jb2xzLTIgeGw6Z3JpZC1jb2xzLTNcIj5cbiAgICAgICAgICAgICAgICB7QXJyYXkuZnJvbSh7IGxlbmd0aDogNiB9LCAoXywgaSkgPT4gKFxuICAgICAgICAgICAgICAgICAgPFNwYWNlQ2FyZFNrZWxldG9uIGtleT17aX0gLz5cbiAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApIDogcmVzdWx0cy5sZW5ndGggPT09IDAgPyAoXG4gICAgICAgICAgICAgIDxOb3RoaW5nWWV0IG9uUmVzZXQ9eygpID0+IHNldEZpbHRlcnMoREVGQVVMVFMpfSAvPlxuICAgICAgICAgICAgKSA6IHZpZXcgPT09IFwibWFwXCIgPyAoXG4gICAgICAgICAgICAgIDxTdXNwZW5zZVxuICAgICAgICAgICAgICAgIGZhbGxiYWNrPXtcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaC1bNzB2aF0gbWluLWgtOTYgYW5pbWF0ZS1wdWxzZSByb3VuZGVkLWNhcmQgYmctaXZvcnktZGVlcFwiIC8+XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPFNwYWNlTWFwIGxpc3RpbmdzPXtyZXN1bHRzfSBjbGFzc05hbWU9XCJoLVs3MHZoXSBtaW4taC05NiB3LWZ1bGwgbWF4LXctZnVsbFwiIC8+XG4gICAgICAgICAgICAgIDwvU3VzcGVuc2U+XG4gICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInN0YWdnZXIgZ3JpZCBnYXAtNSBzbTpncmlkLWNvbHMtMiB4bDpncmlkLWNvbHMtM1wiPlxuICAgICAgICAgICAgICAgIHtoYXNTdGF0ZWROZWVkcyAmJiAoXG4gICAgICAgICAgICAgICAgICA8Q29hY2htYXJrXG4gICAgICAgICAgICAgICAgICAgIGlkPVwibWF0Y2hcIlxuICAgICAgICAgICAgICAgICAgICB0aXRsZUtleT1cImNvYWNoLm1hdGNoVGl0bGVcIlxuICAgICAgICAgICAgICAgICAgICBib2R5S2V5PVwiY29hY2gubWF0Y2hCb2R5XCJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwic206Y29sLXNwYW4tMiB4bDpjb2wtc3Bhbi0zXCJcbiAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICB7cmVzdWx0cy5tYXAoKGwpID0+IChcbiAgICAgICAgICAgICAgICAgIDxTcGFjZUNhcmRcbiAgICAgICAgICAgICAgICAgICAga2V5PXtsLnNwYWNlLmlkfVxuICAgICAgICAgICAgICAgICAgICBsaXN0aW5nPXtsfVxuICAgICAgICAgICAgICAgICAgICBtYXRjaFNjb3JlPXtoYXNTdGF0ZWROZWVkcyA/IG1hdGNoZXMuZ2V0KGwuc3BhY2UuaWQpPy5zY29yZSA6IHVuZGVmaW5lZH1cbiAgICAgICAgICAgICAgICAgICAgc2F2ZWQ9e2lzU2F2ZWQobC5zcGFjZS5pZCl9XG4gICAgICAgICAgICAgICAgICAgIGNvbXBhcmluZz17aXNDb21wYXJpbmcobC5zcGFjZS5pZCl9XG4gICAgICAgICAgICAgICAgICAgIG9uVG9nZ2xlU2F2ZT17KGlkKSA9PiB2b2lkIHRvZ2dsZVNhdmVkKGlkKX1cbiAgICAgICAgICAgICAgICAgICAgb25Ub2dnbGVDb21wYXJlPXt0b2dnbGVDb21wYXJlfVxuICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApfVxuXG4gICAgICAgICAgICB7bmVhcmJ5Lmxlbmd0aCA+IDAgJiYgKFxuICAgICAgICAgICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJtdC0xMCByb3VuZGVkLWNhcmQgYmctc3VyZmFjZSBwLTYgcmluZy0xIHJpbmctaGFpcmxpbmVcIj5cbiAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwiZm9udC1kaXNwbGF5IHRleHQteGwgZm9udC1ib2xkIHRleHQtaW5rXCI+XG4gICAgICAgICAgICAgICAgICB7cmVzdWx0cy5sZW5ndGggPT09IDAgPyBcIk5vdGhpbmcgcGVyZmVjdCB5ZXQuXCIgOiBcIkFsc28gd29ydGggYSBsb29rLlwifVxuICAgICAgICAgICAgICAgIDwvaDI+XG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXNtIHRleHQtbXV0ZWRcIj5cbiAgICAgICAgICAgICAgICAgIFRoZXNlIHNpdCBqdXN0IG91dHNpZGUgd2hhdCB5b3UgYXNrZWQgZm9yLiBIZXJlJ3MgaG93IGVhY2ggb25lIGRpZmZlcnMuXG4gICAgICAgICAgICAgICAgPC9wPlxuXG4gICAgICAgICAgICAgICAgPHVsIGNsYXNzTmFtZT1cIm10LTUgc3BhY2UteS0yLjVcIj5cbiAgICAgICAgICAgICAgICAgIHtuZWFyYnkubWFwKCh7IGxpc3RpbmcsIHNjb3JlLCByZWFzb24gfSkgPT4gKFxuICAgICAgICAgICAgICAgICAgICA8bGkga2V5PXtsaXN0aW5nLnNwYWNlLmlkfT5cbiAgICAgICAgICAgICAgICAgICAgICA8TGlua1xuICAgICAgICAgICAgICAgICAgICAgICAgdG89e2Avc3BhY2UvJHtsaXN0aW5nLnNwYWNlLmlkfWB9XG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMy41IHJvdW5kZWQtMnhsIHAtMiB0cmFuc2l0aW9uLWNvbG9ycyBob3ZlcjpiZy1pdm9yeVwiXG4gICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGltZ1xuICAgICAgICAgICAgICAgICAgICAgICAgICBzcmM9e2Rpc3BsYXlJbWFnZShsaXN0aW5nLnNwYWNlLmltYWdlc1swXSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGFsdD1cIlwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNpemUtMTYgc2hyaW5rLTAgcm91bmRlZC14bCBvYmplY3QtY292ZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLXctMCBmbGV4LTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidHJ1bmNhdGUgZm9udC1zZW1pYm9sZCB0ZXh0LWlua1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtsaXN0aW5nLnNwYWNlLm5hbWV9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWwtMiBmb250LW5vcm1hbCB0ZXh0LW11dGVkXCI+e2xpc3RpbmcucHJvcGVydHkuYXJlYX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMC41IHRydW5jYXRlIHRleHQtc20gdGV4dC1pbmstc29mdFwiPntyZWFzb259PC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNocmluay0wIHRleHQtcmlnaHRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRudW0gdGV4dC1pbmtcIj57bW9uZXlDb21wYWN0KGxpc3Rpbmcuc3BhY2UuY29zdC5wcmljZSl9PC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRudW0gdGV4dC1hcXVhLTcwMFwiPntzY29yZX0lIG1hdGNoPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPC9MaW5rPlxuICAgICAgICAgICAgICAgICAgICA8L2xpPlxuICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgPC91bD5cbiAgICAgICAgICAgICAgPC9zZWN0aW9uPlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgICAgPE1vZGFsXG4gICAgICAgIG9wZW49e3NoZWV0T3Blbn1cbiAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0U2hlZXRPcGVuKGZhbHNlKX1cbiAgICAgICAgdGl0bGU9XCJGaWx0ZXJzXCJcbiAgICAgICAgZm9vdGVyPXtcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTJcIj5cbiAgICAgICAgICAgIDxCdXR0b24gdmFyaWFudD1cInNlY29uZGFyeVwiIGZ1bGxXaWR0aCBvbkNsaWNrPXsoKSA9PiBzZXRGaWx0ZXJzKERFRkFVTFRTKX0+XG4gICAgICAgICAgICAgIFJlc2V0XG4gICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgIDxCdXR0b24gZnVsbFdpZHRoIG9uQ2xpY2s9eygpID0+IHNldFNoZWV0T3BlbihmYWxzZSl9PlxuICAgICAgICAgICAgICBTaG93IHtyZXN1bHRzLmxlbmd0aH1cbiAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICB9XG4gICAgICA+XG4gICAgICAgIDxGaWx0ZXJQYW5lbCBmaWx0ZXJzPXtmaWx0ZXJzfSBvbkNoYW5nZT17c2V0RmlsdGVyc30gLz5cbiAgICAgIDwvTW9kYWw+XG4gICAgPC8+XG4gICk7XG59XG5cbmZ1bmN0aW9uIE5vdGhpbmdZZXQoeyBvblJlc2V0IH06IHsgb25SZXNldDogKCkgPT4gdm9pZCB9KSB7XG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlciByb3VuZGVkLWNhcmQgYmctc3VyZmFjZSBweC02IHB5LTE0IHRleHQtY2VudGVyIHJpbmctMSByaW5nLWhhaXJsaW5lXCI+XG4gICAgICA8c3BhbiBjbGFzc05hbWU9XCJtYi00IGZsZXggc2l6ZS0xMiBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC1mdWxsIGJnLWFxdWEtMTAwIHRleHQtYXF1YS03MDBcIj5cbiAgICAgICAgPENvbXBhc3Mgc2l6ZT17MjJ9IGFyaWEtaGlkZGVuIC8+XG4gICAgICA8L3NwYW4+XG4gICAgICA8aDIgY2xhc3NOYW1lPVwiZm9udC1kaXNwbGF5IHRleHQteGwgZm9udC1ib2xkIHRleHQtaW5rXCI+Tm90aGluZyBtYXRjaGVzIHRob3NlIGZpbHRlcnMuPC9oMj5cbiAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgbWF4LXctc20gdGV4dC1zbSB0ZXh0LW11dGVkXCI+XG4gICAgICAgIFdpZGVuIHRoZSBwcmljZSwgb3BlbiBpdCB0byBtb3JlIGNhdGVnb3JpZXMsIG9yIGluY2x1ZGUgYXJlYXMgZnVydGhlciBvdXQuXG4gICAgICA8L3A+XG4gICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJzZWNvbmRhcnlcIiBjbGFzc05hbWU9XCJtdC01XCIgb25DbGljaz17b25SZXNldH0+XG4gICAgICAgIENsZWFyIGFsbCBmaWx0ZXJzXG4gICAgICA8L0J1dHRvbj5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cblxuZnVuY3Rpb24gY291bnRBY3RpdmUoZjogRmlsdGVycyk6IG51bWJlciB7XG4gIGxldCBuID0gMDtcbiAgaWYgKGYuYXJlYSAhPT0gXCJhbGxcIikgbisrO1xuICBpZiAoZi5jYXRlZ29yeSAhPT0gXCJhbGxcIikgbisrO1xuICBpZiAoZi5nZW9ncmFwaHkgIT09IFwiYWxsXCIpIG4rKztcbiAgaWYgKGYucHJpY2VNYXggIT09IFBSSUNFX0NFSUxJTkcpIG4rKztcbiAgaWYgKCFmLmF2YWlsYWJsZU9ubHkpIG4rKztcbiAgaWYgKGYuZnJlc2hPbmx5KSBuKys7XG4gIGlmIChmLnZlcmlmaWVkT25seSkgbisrO1xuICBpZiAoZi5mdWxsQ29zdE9ubHkpIG4rKztcbiAgaWYgKGYub2NjdXBhbmN5ICE9PSBcImFueVwiKSBuKys7XG4gIHJldHVybiBuICsgZi5hbWVuaXRpZXMubGVuZ3RoO1xufVxuXG5mdW5jdGlvbiBGaWx0ZXJQYW5lbCh7IGZpbHRlcnMsIG9uQ2hhbmdlIH06IHsgZmlsdGVyczogRmlsdGVyczsgb25DaGFuZ2U6IChmOiBGaWx0ZXJzKSA9PiB2b2lkIH0pIHtcbiAgY29uc3QgeyB0IH0gPSB1c2VJMThuKCk7XG4gIGNvbnN0IHNldCA9IDxLIGV4dGVuZHMga2V5b2YgRmlsdGVycz4oazogSywgdjogRmlsdGVyc1tLXSkgPT4gb25DaGFuZ2UoeyAuLi5maWx0ZXJzLCBba106IHYgfSk7XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNlwiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgPGgyIGNsYXNzTmFtZT1cImZvbnQtZGlzcGxheSBmb250LWJvbGQgdGV4dC1pbmtcIj5GaWx0ZXJzPC9oMj5cbiAgICAgICAgPGJ1dHRvblxuICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9uQ2hhbmdlKERFRkFVTFRTKX1cbiAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1tdXRlZCBob3Zlcjp0ZXh0LWlua1wiXG4gICAgICAgID5cbiAgICAgICAgICBSZXNldFxuICAgICAgICA8L2J1dHRvbj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICA8R3JvdXAgbGFiZWw9e3QoXCJmaWx0ZXIuY2F0ZWdvcnlcIil9PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGdhcC0xLjVcIj5cbiAgICAgICAgICA8UGlsbCBhY3RpdmU9e2ZpbHRlcnMuY2F0ZWdvcnkgPT09IFwiYWxsXCJ9IG9uQ2xpY2s9eygpID0+IHNldChcImNhdGVnb3J5XCIsIFwiYWxsXCIpfT5cbiAgICAgICAgICAgIEFsbFxuICAgICAgICAgIDwvUGlsbD5cbiAgICAgICAgICB7KE9iamVjdC5rZXlzKENBVEVHT1JZX1NUWUxFKSBhcyBTcGFjZUNhdGVnb3J5W10pLm1hcCgoYykgPT4gKFxuICAgICAgICAgICAgPFBpbGwga2V5PXtjfSBhY3RpdmU9e2ZpbHRlcnMuY2F0ZWdvcnkgPT09IGN9IG9uQ2xpY2s9eygpID0+IHNldChcImNhdGVnb3J5XCIsIGMpfT5cbiAgICAgICAgICAgICAge0NBVEVHT1JZX1NUWUxFW2NdLmxhYmVsfVxuICAgICAgICAgICAgPC9QaWxsPlxuICAgICAgICAgICkpfVxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvR3JvdXA+XG5cbiAgICAgIDxHcm91cCBsYWJlbD17dChcImZpbHRlci5hcmVhXCIpfT5cbiAgICAgICAgPEFyZWFQaWNrZXIgdmFsdWU9e2ZpbHRlcnMuYXJlYX0gb25DaGFuZ2U9eyh2KSA9PiBzZXQoXCJhcmVhXCIsIHYpfSBhbGxvd0FueXdoZXJlIC8+XG4gICAgICA8L0dyb3VwPlxuXG4gICAgICA8R3JvdXAgbGFiZWw9e3QoXCJmaWx0ZXIuc2V0dGluZ1wiKX0+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgZ2FwLTEuNVwiPlxuICAgICAgICAgIHsoW1wiYWxsXCIsIFwidXJiYW5cIiwgXCJzdWJ1cmJhblwiLCBcInJ1cmFsXCJdIGFzIGNvbnN0KS5tYXAoKGcpID0+IChcbiAgICAgICAgICAgIDxQaWxsIGtleT17Z30gYWN0aXZlPXtmaWx0ZXJzLmdlb2dyYXBoeSA9PT0gZ30gb25DbGljaz17KCkgPT4gc2V0KFwiZ2VvZ3JhcGh5XCIsIGcpfT5cbiAgICAgICAgICAgICAge2cgPT09IFwiYWxsXCIgPyBcIkFueXdoZXJlXCIgOiBnfVxuICAgICAgICAgICAgPC9QaWxsPlxuICAgICAgICAgICkpfVxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvR3JvdXA+XG5cbiAgICAgIDxHcm91cCBsYWJlbD17YFJlbnQgdXAgdG8gJHttb25leShmaWx0ZXJzLnByaWNlTWF4KX1gfT5cbiAgICAgICAgPGlucHV0XG4gICAgICAgICAgdHlwZT1cInJhbmdlXCJcbiAgICAgICAgICBhcmlhLWxhYmVsPVwiTWF4aW11bSBtb250aGx5IHByaWNlXCJcbiAgICAgICAgICBtaW49ezIwMDB9XG4gICAgICAgICAgbWF4PXtQUklDRV9DRUlMSU5HfVxuICAgICAgICAgIHN0ZXA9ezEwMDB9XG4gICAgICAgICAgdmFsdWU9e2ZpbHRlcnMucHJpY2VNYXh9XG4gICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXQoXCJwcmljZU1heFwiLCBOdW1iZXIoZS50YXJnZXQudmFsdWUpKX1cbiAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYWNjZW50LWFxdWEtNjAwXCJcbiAgICAgICAgLz5cbiAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXhzIHRleHQtbXV0ZWRcIj5TYWxlIGxpc3RpbmdzIGFyZW4ndCBmaWx0ZXJlZCBieSB0aGlzLjwvcD5cbiAgICAgIDwvR3JvdXA+XG5cbiAgICAgIDxHcm91cCBsYWJlbD17dChcImZpbHRlci53aG9DYW5MaXZlXCIpfT5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBnYXAtMS41XCI+XG4gICAgICAgICAgeyhbXG4gICAgICAgICAgICB7IGtleTogXCJhbnlcIiwgbGFiZWw6IHQoXCJmaWx0ZXIuYWxsXCIpIH0sXG4gICAgICAgICAgICB7IGtleTogXCJmYW1pbHlcIiwgbGFiZWw6IHQoXCJmaWx0ZXIuZmFtaWx5QWxsb3dlZFwiKSB9LFxuICAgICAgICAgICAgeyBrZXk6IFwiYmFjaGVsb3JcIiwgbGFiZWw6IHQoXCJmaWx0ZXIuYmFjaGVsb3JBbGxvd2VkXCIpIH0sXG4gICAgICAgICAgICB7IGtleTogXCJzdHVkZW50XCIsIGxhYmVsOiB0KFwiZmlsdGVyLnN0dWRlbnRGcmllbmRseVwiKSB9LFxuICAgICAgICAgIF0gYXMgY29uc3QpLm1hcCgob3B0aW9uKSA9PiAoXG4gICAgICAgICAgICA8UGlsbFxuICAgICAgICAgICAgICBrZXk9e29wdGlvbi5rZXl9XG4gICAgICAgICAgICAgIGFjdGl2ZT17ZmlsdGVycy5vY2N1cGFuY3kgPT09IG9wdGlvbi5rZXl9XG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldChcIm9jY3VwYW5jeVwiLCBvcHRpb24ua2V5KX1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAge29wdGlvbi5sYWJlbH1cbiAgICAgICAgICAgIDwvUGlsbD5cbiAgICAgICAgICApKX1cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L0dyb3VwPlxuXG4gICAgICA8R3JvdXAgbGFiZWw9e3QoXCJmaWx0ZXIuc2hvd09ubHlcIil9PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxuICAgICAgICAgIDxDaGVjayBsYWJlbD17dChcImZpbHRlci5hdmFpbGFibGVcIil9IGNoZWNrZWQ9e2ZpbHRlcnMuYXZhaWxhYmxlT25seX0gb25DaGFuZ2U9eyh2KSA9PiBzZXQoXCJhdmFpbGFibGVPbmx5XCIsIHYpfSAvPlxuICAgICAgICAgIDxDaGVjayBsYWJlbD17dChcImZpbHRlci5mcmVzaFwiKX0gY2hlY2tlZD17ZmlsdGVycy5mcmVzaE9ubHl9IG9uQ2hhbmdlPXsodikgPT4gc2V0KFwiZnJlc2hPbmx5XCIsIHYpfSAvPlxuICAgICAgICAgIDxDaGVjayBsYWJlbD17dChcImZpbHRlci5mdWxsQ29zdFwiKX0gY2hlY2tlZD17ZmlsdGVycy5mdWxsQ29zdE9ubHl9IG9uQ2hhbmdlPXsodikgPT4gc2V0KFwiZnVsbENvc3RPbmx5XCIsIHYpfSAvPlxuICAgICAgICAgIDxDaGVjayBsYWJlbD17dChcImZpbHRlci52ZXJpZmllZFwiKX0gY2hlY2tlZD17ZmlsdGVycy52ZXJpZmllZE9ubHl9IG9uQ2hhbmdlPXsodikgPT4gc2V0KFwidmVyaWZpZWRPbmx5XCIsIHYpfSAvPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvR3JvdXA+XG5cbiAgICAgIDxHcm91cCBsYWJlbD17dChcImZpbHRlci5hbWVuaXRpZXNcIil9PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGdhcC0xLjVcIj5cbiAgICAgICAgICB7QU1FTklUWV9LRVlTLnNsaWNlKDAsIDE0KS5tYXAoKGtleSkgPT4gKFxuICAgICAgICAgICAgPFBpbGxcbiAgICAgICAgICAgICAga2V5PXtrZXl9XG4gICAgICAgICAgICAgIGFjdGl2ZT17ZmlsdGVycy5hbWVuaXRpZXMuaW5jbHVkZXMoa2V5KX1cbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT5cbiAgICAgICAgICAgICAgICBzZXQoXG4gICAgICAgICAgICAgICAgICBcImFtZW5pdGllc1wiLFxuICAgICAgICAgICAgICAgICAgZmlsdGVycy5hbWVuaXRpZXMuaW5jbHVkZXMoa2V5KVxuICAgICAgICAgICAgICAgICAgICA/IGZpbHRlcnMuYW1lbml0aWVzLmZpbHRlcigoYSkgPT4gYSAhPT0ga2V5KVxuICAgICAgICAgICAgICAgICAgICA6IFsuLi5maWx0ZXJzLmFtZW5pdGllcywga2V5XSxcbiAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAge3QoYGFtZW5pdHkuJHtrZXl9YCBhcyBuZXZlcil9XG4gICAgICAgICAgICA8L1BpbGw+XG4gICAgICAgICAgKSl9XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9Hcm91cD5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cblxuZnVuY3Rpb24gR3JvdXAoeyBsYWJlbCwgY2hpbGRyZW4gfTogeyBsYWJlbDogc3RyaW5nOyBjaGlsZHJlbjogUmVhY3QuUmVhY3ROb2RlIH0pIHtcbiAgcmV0dXJuIChcbiAgICA8ZGl2PlxuICAgICAgPHAgY2xhc3NOYW1lPVwibWItMiB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1pbmstc29mdFwiPntsYWJlbH08L3A+XG4gICAgICB7Y2hpbGRyZW59XG4gICAgPC9kaXY+XG4gICk7XG59XG5cbmZ1bmN0aW9uIFBpbGwoeyBhY3RpdmUsIG9uQ2xpY2ssIGNoaWxkcmVuIH06IHsgYWN0aXZlOiBib29sZWFuOyBvbkNsaWNrOiAoKSA9PiB2b2lkOyBjaGlsZHJlbjogUmVhY3QuUmVhY3ROb2RlIH0pIHtcbiAgcmV0dXJuIChcbiAgICA8YnV0dG9uXG4gICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgIGFyaWEtcHJlc3NlZD17YWN0aXZlfVxuICAgICAgb25DbGljaz17b25DbGlja31cbiAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgIFwicm91bmRlZC1mdWxsIHB4LTIuNSBweS0xLjUgdGV4dC14cyBmb250LXNlbWlib2xkIGNhcGl0YWxpemUgdHJhbnNpdGlvbi1jb2xvcnNcIixcbiAgICAgICAgYWN0aXZlID8gXCJiZy1pbmsgdGV4dC1pdm9yeVwiIDogXCJiZy1pdm9yeS1kZWVwIHRleHQtaW5rLXNvZnQgaG92ZXI6YmctaGFpcmxpbmVcIixcbiAgICAgICl9XG4gICAgPlxuICAgICAge2NoaWxkcmVufVxuICAgIDwvYnV0dG9uPlxuICApO1xufVxuXG5mdW5jdGlvbiBDaGVjayh7IGxhYmVsLCBjaGVja2VkLCBvbkNoYW5nZSB9OiB7IGxhYmVsOiBzdHJpbmc7IGNoZWNrZWQ6IGJvb2xlYW47IG9uQ2hhbmdlOiAodjogYm9vbGVhbikgPT4gdm9pZCB9KSB7XG4gIHJldHVybiAoXG4gICAgPGxhYmVsIGNsYXNzTmFtZT1cImZsZXggY3Vyc29yLXBvaW50ZXIgaXRlbXMtY2VudGVyIGdhcC0yLjUgdGV4dC1zbSB0ZXh0LWluay1zb2Z0XCI+XG4gICAgICA8aW5wdXRcbiAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcbiAgICAgICAgY2hlY2tlZD17Y2hlY2tlZH1cbiAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBvbkNoYW5nZShlLnRhcmdldC5jaGVja2VkKX1cbiAgICAgICAgY2xhc3NOYW1lPVwic2l6ZS00IGFjY2VudC1hcXVhLTYwMFwiXG4gICAgICAvPlxuICAgICAge2xhYmVsfVxuICAgIDwvbGFiZWw+XG4gICk7XG59XG4iXSwiZmlsZSI6IkQ6L0kySSBQcm9qZWN0IC0gSGFiaXRvL0FwcCBGb2xkZXIvaGFiaXRvL3NyYy9wYWdlcy9TZWFyY2gudHN4In0=