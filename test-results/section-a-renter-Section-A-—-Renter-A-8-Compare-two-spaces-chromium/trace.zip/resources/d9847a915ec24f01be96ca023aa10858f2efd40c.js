import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/layout/PrototypeNotice.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=9ceb86a3"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("D:/I2I Project - Habito/App Folder/habito/src/components/layout/PrototypeNotice.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { FlaskConical } from "/node_modules/.vite/deps/lucide-react.js?v=9ceb86a3";
import { useI18n } from "/src/i18n/index.tsx";
export function PrototypeNotice() {
  _s();
  const { t } = useI18n();
  return /* @__PURE__ */ jsxDEV("div", { className: "bg-ink text-ivory", children: /* @__PURE__ */ jsxDEV("p", { className: "container-page flex items-center gap-2 py-2 text-xs", children: [
    /* @__PURE__ */ jsxDEV(FlaskConical, { size: 13, className: "shrink-0 text-aqua-400", "aria-hidden": true }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/layout/PrototypeNotice.tsx",
      lineNumber: 29,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("span", { children: [
      /* @__PURE__ */ jsxDEV("strong", { className: "font-semibold", children: t("prototype.notice") }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/layout/PrototypeNotice.tsx",
        lineNumber: 31,
        columnNumber: 11
      }, this),
      " ",
      t("prototype.detail")
    ] }, void 0, true, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/layout/PrototypeNotice.tsx",
      lineNumber: 30,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/layout/PrototypeNotice.tsx",
    lineNumber: 28,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/layout/PrototypeNotice.tsx",
    lineNumber: 27,
    columnNumber: 5
  }, this);
}
_s(PrototypeNotice, "82N5KF9nLzZ6+2WH7KIjzIXRkLw=", false, function() {
  return [useI18n];
});
_c = PrototypeNotice;
var _c;
$RefreshReg$(_c, "PrototypeNotice");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/I2I Project - Habito/App Folder/habito/src/components/layout/PrototypeNotice.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/I2I Project - Habito/App Folder/habito/src/components/layout/PrototypeNotice.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBU1E7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBVFIsU0FBU0Esb0JBQW9CO0FBQzdCLFNBQVNDLGVBQWU7QUFHakIsZ0JBQVNDLGtCQUFrQjtBQUFBQyxLQUFBO0FBQ2hDLFFBQU0sRUFBRUMsRUFBRSxJQUFJSCxRQUFRO0FBQ3RCLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLHFCQUNiLGlDQUFDLE9BQUUsV0FBVSx1REFDWDtBQUFBLDJCQUFDLGdCQUFhLE1BQU0sSUFBSSxXQUFVLDBCQUF5QixlQUFXLFFBQXRFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBc0U7QUFBQSxJQUN0RSx1QkFBQyxVQUNDO0FBQUEsNkJBQUMsWUFBTyxXQUFVLGlCQUFpQkcsWUFBRSxrQkFBa0IsS0FBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF5RDtBQUFBLE1BQVM7QUFBQSxNQUFFQSxFQUFFLGtCQUFrQjtBQUFBLFNBRDFGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLE9BSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUtBLEtBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQU9BO0FBRUo7QUFBQ0QsR0FaZUQsaUJBQWU7QUFBQSxVQUNmRCxPQUFPO0FBQUE7QUFBQSxLQURQQztBQUFlLElBQUFHO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbIkZsYXNrQ29uaWNhbCIsInVzZUkxOG4iLCJQcm90b3R5cGVOb3RpY2UiLCJfcyIsInQiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJQcm90b3R5cGVOb3RpY2UudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEZsYXNrQ29uaWNhbCB9IGZyb20gXCJsdWNpZGUtcmVhY3RcIjtcbmltcG9ydCB7IHVzZUkxOG4gfSBmcm9tIFwiQC9pMThuXCI7XG5cbi8qKiBNYW5kYXRvcnkgZGlzY2xvc3VyZS4gU2VlZCBsaXN0aW5ncyBhcmUgaW52ZW50ZWQ7IHRoaXMgbXVzdCBzdGF5IHZpc2libGUuICovXG5leHBvcnQgZnVuY3Rpb24gUHJvdG90eXBlTm90aWNlKCkge1xuICBjb25zdCB7IHQgfSA9IHVzZUkxOG4oKTtcbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWluayB0ZXh0LWl2b3J5XCI+XG4gICAgICA8cCBjbGFzc05hbWU9XCJjb250YWluZXItcGFnZSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBweS0yIHRleHQteHNcIj5cbiAgICAgICAgPEZsYXNrQ29uaWNhbCBzaXplPXsxM30gY2xhc3NOYW1lPVwic2hyaW5rLTAgdGV4dC1hcXVhLTQwMFwiIGFyaWEtaGlkZGVuIC8+XG4gICAgICAgIDxzcGFuPlxuICAgICAgICAgIDxzdHJvbmcgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZFwiPnt0KFwicHJvdG90eXBlLm5vdGljZVwiKX08L3N0cm9uZz4ge3QoXCJwcm90b3R5cGUuZGV0YWlsXCIpfVxuICAgICAgICA8L3NwYW4+XG4gICAgICA8L3A+XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXSwiZmlsZSI6IkQ6L0kySSBQcm9qZWN0IC0gSGFiaXRvL0FwcCBGb2xkZXIvaGFiaXRvL3NyYy9jb21wb25lbnRzL2xheW91dC9Qcm90b3R5cGVOb3RpY2UudHN4In0=