import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/hooks/useAuth.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=9ceb86a3"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("D:/I2I Project - Habito/App Folder/habito/src/hooks/useAuth.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9ceb86a3"; const createContext = __vite__cjsImport3_react["createContext"]; const useCallback = __vite__cjsImport3_react["useCallback"]; const useContext = __vite__cjsImport3_react["useContext"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useMemo = __vite__cjsImport3_react["useMemo"]; const useState = __vite__cjsImport3_react["useState"];
import { supabase, isRemote } from "/src/lib/supabase.ts";
const Ctx = createContext(null);
function toAccount(row) {
  return {
    id: row.id,
    name: row.name,
    email: row.email,
    phone: row.phone,
    role: row.role,
    canOwn: row.can_own ?? row.role === "owner",
    verification: row.verification,
    avatarTone: row.avatar_tone,
    suspended: row.suspended
  };
}
export function AuthProvider({ children }) {
  _s();
  const [ready, setReady] = useState(!isRemote);
  const [session, setSession] = useState(null);
  const [account, setAccount] = useState(null);
  const loadProfile = useCallback(async (userId) => {
    if (!supabase) return;
    const { data, error } = await supabase.from("profiles").select("*").eq("id", userId).maybeSingle();
    if (!error && data) setAccount(toAccount(data));
  }, []);
  useEffect(() => {
    if (!supabase) return;
    void supabase.auth.getSession().then(async ({ data }) => {
      setSession(data.session);
      if (data.session?.user) await loadProfile(data.session.user.id);
      setReady(true);
    });
    const { data: sub } = supabase.auth.onAuthStateChange((_event, next) => {
      setSession(next);
      if (next?.user) {
        void loadProfile(next.user.id);
      } else {
        setAccount(null);
      }
    });
    return () => sub.subscription.unsubscribe();
  }, [loadProfile]);
  const signUp = useCallback(async ({ name, email, password, phone, role }) => {
    if (!supabase) throw new Error("Sign-up needs the database. Add your Supabase keys to .env.");
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      // The trigger reads these; role is validated server-side and can never
      // be 'admin' no matter what is sent from here.
      options: { data: { name, phone: phone ?? null, role } }
    });
    if (error) throw new Error(error.message);
    return { needsConfirmation: !data.session };
  }, []);
  const signIn = useCallback(async (email, password) => {
    if (!supabase) throw new Error("Signing in needs the database. Add your Supabase keys to .env.");
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) throw new Error(error.message);
  }, []);
  const signOut = useCallback(async () => {
    if (!supabase) return;
    await supabase.auth.signOut();
    setAccount(null);
  }, []);
  const resetPassword = useCallback(async (email) => {
    if (!supabase) throw new Error("Password reset needs the database.");
    const { error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: `${window.location.origin}/account`
    });
    if (error) throw new Error(error.message);
  }, []);
  const updateProfile = useCallback(
    async (patch) => {
      if (!supabase || !account) return;
      const { data, error } = await supabase.from("profiles").update({ name: patch.name, phone: patch.phone }).eq("id", account.id).select().single();
      if (error) throw new Error(error.message);
      setAccount(toAccount(data));
    },
    [account]
  );
  const enableOwnerTools = useCallback(async () => {
    if (!supabase || !account) return;
    const { data, error } = await supabase.from("profiles").update({ can_own: true }).eq("id", account.id).select().single();
    if (error) throw new Error(error.message);
    setAccount(toAccount(data));
  }, [account]);
  const refreshAccount = useCallback(async () => {
    if (session?.user) await loadProfile(session.user.id);
  }, [session, loadProfile]);
  const value = useMemo(
    () => ({
      ready,
      configured: isRemote,
      session,
      account,
      signUp,
      signIn,
      signOut,
      resetPassword,
      updateProfile,
      enableOwnerTools,
      refreshAccount
    }),
    [ready, session, account, signUp, signIn, signOut, resetPassword, updateProfile, enableOwnerTools, refreshAccount]
  );
  return /* @__PURE__ */ jsxDEV(Ctx.Provider, { value, children }, void 0, false, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/hooks/useAuth.tsx",
    lineNumber: 199,
    columnNumber: 10
  }, this);
}
_s(AuthProvider, "BS19WrXieIEGGR+WkBO/xxYu3t4=");
_c = AuthProvider;
export function useAuth() {
  _s2();
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useAuth must be used inside AuthProvider");
  return ctx;
}
_s2(useAuth, "/dMy7t63NXD4eYACoT93CePwGrg=");
var _c;
$RefreshReg$(_c, "AuthProvider");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/I2I Project - Habito/App Folder/habito/src/hooks/useAuth.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/I2I Project - Habito/App Folder/habito/src/hooks/useAuth.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbUxTOzs7Ozs7Ozs7Ozs7Ozs7OztBQW5MVCxTQUFTQSxlQUFlQyxhQUFhQyxZQUFZQyxXQUFXQyxTQUFTQyxnQkFBZ0I7QUFHckYsU0FBU0MsVUFBVUMsZ0JBQWdCO0FBeUNuQyxNQUFNQyxNQUFNUixjQUFnQyxJQUFJO0FBRWhELFNBQVNTLFVBQVVDLEtBQTBCO0FBQzNDLFNBQU87QUFBQSxJQUNMQyxJQUFJRCxJQUFJQztBQUFBQSxJQUNSQyxNQUFNRixJQUFJRTtBQUFBQSxJQUNWQyxPQUFPSCxJQUFJRztBQUFBQSxJQUNYQyxPQUFPSixJQUFJSTtBQUFBQSxJQUNYQyxNQUFNTCxJQUFJSztBQUFBQSxJQUNWQyxRQUFRTixJQUFJTyxXQUFXUCxJQUFJSyxTQUFTO0FBQUEsSUFDcENHLGNBQWNSLElBQUlRO0FBQUFBLElBQ2xCQyxZQUFZVCxJQUFJVTtBQUFBQSxJQUNoQkMsV0FBV1gsSUFBSVc7QUFBQUEsRUFDakI7QUFDRjtBQUVPLGdCQUFTQyxhQUFhLEVBQUVDLFNBQWtDLEdBQUc7QUFBQUMsS0FBQTtBQUNsRSxRQUFNLENBQUNDLE9BQU9DLFFBQVEsSUFBSXJCLFNBQVMsQ0FBQ0UsUUFBUTtBQUM1QyxRQUFNLENBQUNvQixTQUFTQyxVQUFVLElBQUl2QixTQUF5QixJQUFJO0FBQzNELFFBQU0sQ0FBQ3dCLFNBQVNDLFVBQVUsSUFBSXpCLFNBQXlCLElBQUk7QUFFM0QsUUFBTTBCLGNBQWM5QixZQUFZLE9BQU8rQixXQUFtQjtBQUN4RCxRQUFJLENBQUMxQixTQUFVO0FBQ2YsVUFBTSxFQUFFMkIsTUFBTUMsTUFBTSxJQUFJLE1BQU01QixTQUFTNkIsS0FBSyxVQUFVLEVBQUVDLE9BQU8sR0FBRyxFQUFFQyxHQUFHLE1BQU1MLE1BQU0sRUFBRU0sWUFBWTtBQUdqRyxRQUFJLENBQUNKLFNBQVNELEtBQU1ILFlBQVdyQixVQUFVd0IsSUFBa0IsQ0FBQztBQUFBLEVBQzlELEdBQUcsRUFBRTtBQUVMOUIsWUFBVSxNQUFNO0FBQ2QsUUFBSSxDQUFDRyxTQUFVO0FBRWYsU0FBS0EsU0FBU2lDLEtBQUtDLFdBQVcsRUFBRUMsS0FBSyxPQUFPLEVBQUVSLEtBQUssTUFBTTtBQUN2REwsaUJBQVdLLEtBQUtOLE9BQU87QUFDdkIsVUFBSU0sS0FBS04sU0FBU2UsS0FBTSxPQUFNWCxZQUFZRSxLQUFLTixRQUFRZSxLQUFLL0IsRUFBRTtBQUM5RGUsZUFBUyxJQUFJO0FBQUEsSUFDZixDQUFDO0FBRUQsVUFBTSxFQUFFTyxNQUFNVSxJQUFJLElBQUlyQyxTQUFTaUMsS0FBS0ssa0JBQWtCLENBQUNDLFFBQVFDLFNBQVM7QUFDdEVsQixpQkFBV2tCLElBQUk7QUFDZixVQUFJQSxNQUFNSixNQUFNO0FBQ2QsYUFBS1gsWUFBWWUsS0FBS0osS0FBSy9CLEVBQUU7QUFBQSxNQUMvQixPQUFPO0FBQ0xtQixtQkFBVyxJQUFJO0FBQUEsTUFDakI7QUFBQSxJQUNGLENBQUM7QUFFRCxXQUFPLE1BQU1hLElBQUlJLGFBQWFDLFlBQVk7QUFBQSxFQUM1QyxHQUFHLENBQUNqQixXQUFXLENBQUM7QUFFaEIsUUFBTWtCLFNBQThCaEQsWUFBWSxPQUFPLEVBQUVXLE1BQU1DLE9BQU9xQyxVQUFVcEMsT0FBT0MsS0FBSyxNQUFNO0FBQ2hHLFFBQUksQ0FBQ1QsU0FBVSxPQUFNLElBQUk2QyxNQUFNLDZEQUE2RDtBQUU1RixVQUFNLEVBQUVsQixNQUFNQyxNQUFNLElBQUksTUFBTTVCLFNBQVNpQyxLQUFLVSxPQUFPO0FBQUEsTUFDakRwQztBQUFBQSxNQUNBcUM7QUFBQUE7QUFBQUE7QUFBQUEsTUFHQUUsU0FBUyxFQUFFbkIsTUFBTSxFQUFFckIsTUFBTUUsT0FBT0EsU0FBUyxNQUFNQyxLQUFLLEVBQUU7QUFBQSxJQUN4RCxDQUFDO0FBRUQsUUFBSW1CLE1BQU8sT0FBTSxJQUFJaUIsTUFBTWpCLE1BQU1tQixPQUFPO0FBQ3hDLFdBQU8sRUFBRUMsbUJBQW1CLENBQUNyQixLQUFLTixRQUFRO0FBQUEsRUFDNUMsR0FBRyxFQUFFO0FBRUwsUUFBTTRCLFNBQVN0RCxZQUFZLE9BQU9ZLE9BQWVxQyxhQUFxQjtBQUNwRSxRQUFJLENBQUM1QyxTQUFVLE9BQU0sSUFBSTZDLE1BQU0sZ0VBQWdFO0FBQy9GLFVBQU0sRUFBRWpCLE1BQU0sSUFBSSxNQUFNNUIsU0FBU2lDLEtBQUtpQixtQkFBbUIsRUFBRTNDLE9BQU9xQyxTQUFTLENBQUM7QUFDNUUsUUFBSWhCLE1BQU8sT0FBTSxJQUFJaUIsTUFBTWpCLE1BQU1tQixPQUFPO0FBQUEsRUFDMUMsR0FBRyxFQUFFO0FBRUwsUUFBTUksVUFBVXhELFlBQVksWUFBWTtBQUN0QyxRQUFJLENBQUNLLFNBQVU7QUFDZixVQUFNQSxTQUFTaUMsS0FBS2tCLFFBQVE7QUFDNUIzQixlQUFXLElBQUk7QUFBQSxFQUNqQixHQUFHLEVBQUU7QUFFTCxRQUFNNEIsZ0JBQWdCekQsWUFBWSxPQUFPWSxVQUFrQjtBQUN6RCxRQUFJLENBQUNQLFNBQVUsT0FBTSxJQUFJNkMsTUFBTSxvQ0FBb0M7QUFDbkUsVUFBTSxFQUFFakIsTUFBTSxJQUFJLE1BQU01QixTQUFTaUMsS0FBS29CLHNCQUFzQjlDLE9BQU87QUFBQSxNQUNqRStDLFlBQVksR0FBR0MsT0FBT0MsU0FBU0MsTUFBTTtBQUFBLElBQ3ZDLENBQUM7QUFDRCxRQUFJN0IsTUFBTyxPQUFNLElBQUlpQixNQUFNakIsTUFBTW1CLE9BQU87QUFBQSxFQUMxQyxHQUFHLEVBQUU7QUFFTCxRQUFNVyxnQkFBZ0IvRDtBQUFBQSxJQUNwQixPQUFPZ0UsVUFBb0Q7QUFDekQsVUFBSSxDQUFDM0QsWUFBWSxDQUFDdUIsUUFBUztBQUMzQixZQUFNLEVBQUVJLE1BQU1DLE1BQU0sSUFBSSxNQUFNNUIsU0FDM0I2QixLQUFLLFVBQVUsRUFDZitCLE9BQU8sRUFBRXRELE1BQU1xRCxNQUFNckQsTUFBTUUsT0FBT21ELE1BQU1uRCxNQUFNLENBQUMsRUFDL0N1QixHQUFHLE1BQU1SLFFBQVFsQixFQUFFLEVBQ25CeUIsT0FBTyxFQUNQK0IsT0FBTztBQUVWLFVBQUlqQyxNQUFPLE9BQU0sSUFBSWlCLE1BQU1qQixNQUFNbUIsT0FBTztBQUN4Q3ZCLGlCQUFXckIsVUFBVXdCLElBQWtCLENBQUM7QUFBQSxJQUMxQztBQUFBLElBQ0EsQ0FBQ0osT0FBTztBQUFBLEVBQ1Y7QUFFQSxRQUFNdUMsbUJBQW1CbkUsWUFBWSxZQUFZO0FBQy9DLFFBQUksQ0FBQ0ssWUFBWSxDQUFDdUIsUUFBUztBQUMzQixVQUFNLEVBQUVJLE1BQU1DLE1BQU0sSUFBSSxNQUFNNUIsU0FDM0I2QixLQUFLLFVBQVUsRUFDZitCLE9BQU8sRUFBRWpELFNBQVMsS0FBSyxDQUFDLEVBQ3hCb0IsR0FBRyxNQUFNUixRQUFRbEIsRUFBRSxFQUNuQnlCLE9BQU8sRUFDUCtCLE9BQU87QUFFVixRQUFJakMsTUFBTyxPQUFNLElBQUlpQixNQUFNakIsTUFBTW1CLE9BQU87QUFDeEN2QixlQUFXckIsVUFBVXdCLElBQWtCLENBQUM7QUFBQSxFQUMxQyxHQUFHLENBQUNKLE9BQU8sQ0FBQztBQUVaLFFBQU13QyxpQkFBaUJwRSxZQUFZLFlBQVk7QUFDN0MsUUFBSTBCLFNBQVNlLEtBQU0sT0FBTVgsWUFBWUosUUFBUWUsS0FBSy9CLEVBQUU7QUFBQSxFQUN0RCxHQUFHLENBQUNnQixTQUFTSSxXQUFXLENBQUM7QUFFekIsUUFBTXVDLFFBQVFsRTtBQUFBQSxJQUNaLE9BQU87QUFBQSxNQUNMcUI7QUFBQUEsTUFDQThDLFlBQVloRTtBQUFBQSxNQUNab0I7QUFBQUEsTUFDQUU7QUFBQUEsTUFDQW9CO0FBQUFBLE1BQ0FNO0FBQUFBLE1BQ0FFO0FBQUFBLE1BQ0FDO0FBQUFBLE1BQ0FNO0FBQUFBLE1BQ0FJO0FBQUFBLE1BQ0FDO0FBQUFBLElBQ0Y7QUFBQSxJQUNBLENBQUM1QyxPQUFPRSxTQUFTRSxTQUFTb0IsUUFBUU0sUUFBUUUsU0FBU0MsZUFBZU0sZUFBZUksa0JBQWtCQyxjQUFjO0FBQUEsRUFDbkg7QUFFQSxTQUFPLHVCQUFDLElBQUksVUFBSixFQUFhLE9BQWU5QyxZQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXNDO0FBQy9DO0FBQUNDLEdBeEhlRixjQUFZO0FBQUEsS0FBWkE7QUEwSFQsZ0JBQVNrRCxVQUFxQjtBQUFBQyxNQUFBO0FBQ25DLFFBQU1DLE1BQU14RSxXQUFXTSxHQUFHO0FBQzFCLE1BQUksQ0FBQ2tFLElBQUssT0FBTSxJQUFJdkIsTUFBTSwwQ0FBMEM7QUFDcEUsU0FBT3VCO0FBQ1Q7QUFBQ0QsSUFKZUQsU0FBTztBQUFBLElBQUFHO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbImNyZWF0ZUNvbnRleHQiLCJ1c2VDYWxsYmFjayIsInVzZUNvbnRleHQiLCJ1c2VFZmZlY3QiLCJ1c2VNZW1vIiwidXNlU3RhdGUiLCJzdXBhYmFzZSIsImlzUmVtb3RlIiwiQ3R4IiwidG9BY2NvdW50Iiwicm93IiwiaWQiLCJuYW1lIiwiZW1haWwiLCJwaG9uZSIsInJvbGUiLCJjYW5Pd24iLCJjYW5fb3duIiwidmVyaWZpY2F0aW9uIiwiYXZhdGFyVG9uZSIsImF2YXRhcl90b25lIiwic3VzcGVuZGVkIiwiQXV0aFByb3ZpZGVyIiwiY2hpbGRyZW4iLCJfcyIsInJlYWR5Iiwic2V0UmVhZHkiLCJzZXNzaW9uIiwic2V0U2Vzc2lvbiIsImFjY291bnQiLCJzZXRBY2NvdW50IiwibG9hZFByb2ZpbGUiLCJ1c2VySWQiLCJkYXRhIiwiZXJyb3IiLCJmcm9tIiwic2VsZWN0IiwiZXEiLCJtYXliZVNpbmdsZSIsImF1dGgiLCJnZXRTZXNzaW9uIiwidGhlbiIsInVzZXIiLCJzdWIiLCJvbkF1dGhTdGF0ZUNoYW5nZSIsIl9ldmVudCIsIm5leHQiLCJzdWJzY3JpcHRpb24iLCJ1bnN1YnNjcmliZSIsInNpZ25VcCIsInBhc3N3b3JkIiwiRXJyb3IiLCJvcHRpb25zIiwibWVzc2FnZSIsIm5lZWRzQ29uZmlybWF0aW9uIiwic2lnbkluIiwic2lnbkluV2l0aFBhc3N3b3JkIiwic2lnbk91dCIsInJlc2V0UGFzc3dvcmQiLCJyZXNldFBhc3N3b3JkRm9yRW1haWwiLCJyZWRpcmVjdFRvIiwid2luZG93IiwibG9jYXRpb24iLCJvcmlnaW4iLCJ1cGRhdGVQcm9maWxlIiwicGF0Y2giLCJ1cGRhdGUiLCJzaW5nbGUiLCJlbmFibGVPd25lclRvb2xzIiwicmVmcmVzaEFjY291bnQiLCJ2YWx1ZSIsImNvbmZpZ3VyZWQiLCJ1c2VBdXRoIiwiX3MyIiwiY3R4IiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsidXNlQXV0aC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgY3JlYXRlQ29udGV4dCwgdXNlQ2FsbGJhY2ssIHVzZUNvbnRleHQsIHVzZUVmZmVjdCwgdXNlTWVtbywgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB0eXBlIHsgUmVhY3ROb2RlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgdHlwZSB7IFNlc3Npb24gfSBmcm9tIFwiQHN1cGFiYXNlL3N1cGFiYXNlLWpzXCI7XG5pbXBvcnQgeyBzdXBhYmFzZSwgaXNSZW1vdGUgfSBmcm9tIFwiQC9saWIvc3VwYWJhc2VcIjtcbmltcG9ydCB0eXBlIHsgUHJvZmlsZVJvdyB9IGZyb20gXCJAL2xpYi9zdXBhYmFzZVwiO1xuXG5leHBvcnQgdHlwZSBBY2NvdW50Um9sZSA9IFwicmVudGVyXCIgfCBcIm93bmVyXCIgfCBcImFkbWluXCI7XG5cbmV4cG9ydCBpbnRlcmZhY2UgQWNjb3VudCB7XG4gIGlkOiBzdHJpbmc7XG4gIG5hbWU6IHN0cmluZztcbiAgZW1haWw6IHN0cmluZyB8IG51bGw7XG4gIHBob25lOiBzdHJpbmcgfCBudWxsO1xuICByb2xlOiBBY2NvdW50Um9sZTtcbiAgLyoqIFdoZXRoZXIgb3duZXIgdG9vbHMgYXJlIHN3aXRjaGVkIG9uLiBFdmVyeW9uZSBtYXkgcmVudC4gKi9cbiAgY2FuT3duOiBib29sZWFuO1xuICB2ZXJpZmljYXRpb246IFwidW52ZXJpZmllZFwiIHwgXCJwZW5kaW5nXCIgfCBcInZlcmlmaWVkXCI7XG4gIGF2YXRhclRvbmU6IHN0cmluZztcbiAgc3VzcGVuZGVkOiBib29sZWFuO1xufVxuXG5pbnRlcmZhY2UgQXV0aFN0YXRlIHtcbiAgLyoqIEZhbHNlIHVudGlsIHRoZSBpbml0aWFsIHNlc3Npb24gY2hlY2sgZmluaXNoZXMg4oCUIGd1YXJkcyB3YWl0IG9uIHRoaXMuICovXG4gIHJlYWR5OiBib29sZWFuO1xuICBjb25maWd1cmVkOiBib29sZWFuO1xuICBzZXNzaW9uOiBTZXNzaW9uIHwgbnVsbDtcbiAgYWNjb3VudDogQWNjb3VudCB8IG51bGw7XG5cbiAgc2lnblVwOiAoaW5wdXQ6IHtcbiAgICBuYW1lOiBzdHJpbmc7XG4gICAgZW1haWw6IHN0cmluZztcbiAgICBwYXNzd29yZDogc3RyaW5nO1xuICAgIHBob25lPzogc3RyaW5nO1xuICAgIHJvbGU6IFwicmVudGVyXCIgfCBcIm93bmVyXCI7XG4gIH0pID0+IFByb21pc2U8eyBuZWVkc0NvbmZpcm1hdGlvbjogYm9vbGVhbiB9PjtcbiAgc2lnbkluOiAoZW1haWw6IHN0cmluZywgcGFzc3dvcmQ6IHN0cmluZykgPT4gUHJvbWlzZTx2b2lkPjtcbiAgc2lnbk91dDogKCkgPT4gUHJvbWlzZTx2b2lkPjtcbiAgcmVzZXRQYXNzd29yZDogKGVtYWlsOiBzdHJpbmcpID0+IFByb21pc2U8dm9pZD47XG4gIHVwZGF0ZVByb2ZpbGU6IChwYXRjaDogUGFydGlhbDxQaWNrPEFjY291bnQsIFwibmFtZVwiIHwgXCJwaG9uZVwiPj4pID0+IFByb21pc2U8dm9pZD47XG4gIC8qKiBTd2l0Y2hlcyBvd25lciB0b29scyBvbiBmb3IgYW4gZXhpc3RpbmcgYWNjb3VudC4gKi9cbiAgZW5hYmxlT3duZXJUb29sczogKCkgPT4gUHJvbWlzZTx2b2lkPjtcbiAgcmVmcmVzaEFjY291bnQ6ICgpID0+IFByb21pc2U8dm9pZD47XG59XG5cbmNvbnN0IEN0eCA9IGNyZWF0ZUNvbnRleHQ8QXV0aFN0YXRlIHwgbnVsbD4obnVsbCk7XG5cbmZ1bmN0aW9uIHRvQWNjb3VudChyb3c6IFByb2ZpbGVSb3cpOiBBY2NvdW50IHtcbiAgcmV0dXJuIHtcbiAgICBpZDogcm93LmlkLFxuICAgIG5hbWU6IHJvdy5uYW1lLFxuICAgIGVtYWlsOiByb3cuZW1haWwsXG4gICAgcGhvbmU6IHJvdy5waG9uZSxcbiAgICByb2xlOiByb3cucm9sZSxcbiAgICBjYW5Pd246IHJvdy5jYW5fb3duID8/IHJvdy5yb2xlID09PSBcIm93bmVyXCIsXG4gICAgdmVyaWZpY2F0aW9uOiByb3cudmVyaWZpY2F0aW9uLFxuICAgIGF2YXRhclRvbmU6IHJvdy5hdmF0YXJfdG9uZSxcbiAgICBzdXNwZW5kZWQ6IHJvdy5zdXNwZW5kZWQsXG4gIH07XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBBdXRoUHJvdmlkZXIoeyBjaGlsZHJlbiB9OiB7IGNoaWxkcmVuOiBSZWFjdE5vZGUgfSkge1xuICBjb25zdCBbcmVhZHksIHNldFJlYWR5XSA9IHVzZVN0YXRlKCFpc1JlbW90ZSk7XG4gIGNvbnN0IFtzZXNzaW9uLCBzZXRTZXNzaW9uXSA9IHVzZVN0YXRlPFNlc3Npb24gfCBudWxsPihudWxsKTtcbiAgY29uc3QgW2FjY291bnQsIHNldEFjY291bnRdID0gdXNlU3RhdGU8QWNjb3VudCB8IG51bGw+KG51bGwpO1xuXG4gIGNvbnN0IGxvYWRQcm9maWxlID0gdXNlQ2FsbGJhY2soYXN5bmMgKHVzZXJJZDogc3RyaW5nKSA9PiB7XG4gICAgaWYgKCFzdXBhYmFzZSkgcmV0dXJuO1xuICAgIGNvbnN0IHsgZGF0YSwgZXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlLmZyb20oXCJwcm9maWxlc1wiKS5zZWxlY3QoXCIqXCIpLmVxKFwiaWRcIiwgdXNlcklkKS5tYXliZVNpbmdsZSgpO1xuICAgIC8vIFRoZSBwcm9maWxlIGlzIGNyZWF0ZWQgYnkgYSBkYXRhYmFzZSB0cmlnZ2VyLiBPbiB0aGUgdmVyeSBmaXJzdCBzaWduLWluXG4gICAgLy8gaXQgY2FuIGxhZyBieSBhIG1vbWVudCwgc28gYSBtaXNzIGhlcmUgaXNuJ3QgYW4gZXJyb3IuXG4gICAgaWYgKCFlcnJvciAmJiBkYXRhKSBzZXRBY2NvdW50KHRvQWNjb3VudChkYXRhIGFzIFByb2ZpbGVSb3cpKTtcbiAgfSwgW10pO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKCFzdXBhYmFzZSkgcmV0dXJuO1xuXG4gICAgdm9pZCBzdXBhYmFzZS5hdXRoLmdldFNlc3Npb24oKS50aGVuKGFzeW5jICh7IGRhdGEgfSkgPT4ge1xuICAgICAgc2V0U2Vzc2lvbihkYXRhLnNlc3Npb24pO1xuICAgICAgaWYgKGRhdGEuc2Vzc2lvbj8udXNlcikgYXdhaXQgbG9hZFByb2ZpbGUoZGF0YS5zZXNzaW9uLnVzZXIuaWQpO1xuICAgICAgc2V0UmVhZHkodHJ1ZSk7XG4gICAgfSk7XG5cbiAgICBjb25zdCB7IGRhdGE6IHN1YiB9ID0gc3VwYWJhc2UuYXV0aC5vbkF1dGhTdGF0ZUNoYW5nZSgoX2V2ZW50LCBuZXh0KSA9PiB7XG4gICAgICBzZXRTZXNzaW9uKG5leHQpO1xuICAgICAgaWYgKG5leHQ/LnVzZXIpIHtcbiAgICAgICAgdm9pZCBsb2FkUHJvZmlsZShuZXh0LnVzZXIuaWQpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgc2V0QWNjb3VudChudWxsKTtcbiAgICAgIH1cbiAgICB9KTtcblxuICAgIHJldHVybiAoKSA9PiBzdWIuc3Vic2NyaXB0aW9uLnVuc3Vic2NyaWJlKCk7XG4gIH0sIFtsb2FkUHJvZmlsZV0pO1xuXG4gIGNvbnN0IHNpZ25VcDogQXV0aFN0YXRlW1wic2lnblVwXCJdID0gdXNlQ2FsbGJhY2soYXN5bmMgKHsgbmFtZSwgZW1haWwsIHBhc3N3b3JkLCBwaG9uZSwgcm9sZSB9KSA9PiB7XG4gICAgaWYgKCFzdXBhYmFzZSkgdGhyb3cgbmV3IEVycm9yKFwiU2lnbi11cCBuZWVkcyB0aGUgZGF0YWJhc2UuIEFkZCB5b3VyIFN1cGFiYXNlIGtleXMgdG8gLmVudi5cIik7XG5cbiAgICBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZS5hdXRoLnNpZ25VcCh7XG4gICAgICBlbWFpbCxcbiAgICAgIHBhc3N3b3JkLFxuICAgICAgLy8gVGhlIHRyaWdnZXIgcmVhZHMgdGhlc2U7IHJvbGUgaXMgdmFsaWRhdGVkIHNlcnZlci1zaWRlIGFuZCBjYW4gbmV2ZXJcbiAgICAgIC8vIGJlICdhZG1pbicgbm8gbWF0dGVyIHdoYXQgaXMgc2VudCBmcm9tIGhlcmUuXG4gICAgICBvcHRpb25zOiB7IGRhdGE6IHsgbmFtZSwgcGhvbmU6IHBob25lID8/IG51bGwsIHJvbGUgfSB9LFxuICAgIH0pO1xuXG4gICAgaWYgKGVycm9yKSB0aHJvdyBuZXcgRXJyb3IoZXJyb3IubWVzc2FnZSk7XG4gICAgcmV0dXJuIHsgbmVlZHNDb25maXJtYXRpb246ICFkYXRhLnNlc3Npb24gfTtcbiAgfSwgW10pO1xuXG4gIGNvbnN0IHNpZ25JbiA9IHVzZUNhbGxiYWNrKGFzeW5jIChlbWFpbDogc3RyaW5nLCBwYXNzd29yZDogc3RyaW5nKSA9PiB7XG4gICAgaWYgKCFzdXBhYmFzZSkgdGhyb3cgbmV3IEVycm9yKFwiU2lnbmluZyBpbiBuZWVkcyB0aGUgZGF0YWJhc2UuIEFkZCB5b3VyIFN1cGFiYXNlIGtleXMgdG8gLmVudi5cIik7XG4gICAgY29uc3QgeyBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2UuYXV0aC5zaWduSW5XaXRoUGFzc3dvcmQoeyBlbWFpbCwgcGFzc3dvcmQgfSk7XG4gICAgaWYgKGVycm9yKSB0aHJvdyBuZXcgRXJyb3IoZXJyb3IubWVzc2FnZSk7XG4gIH0sIFtdKTtcblxuICBjb25zdCBzaWduT3V0ID0gdXNlQ2FsbGJhY2soYXN5bmMgKCkgPT4ge1xuICAgIGlmICghc3VwYWJhc2UpIHJldHVybjtcbiAgICBhd2FpdCBzdXBhYmFzZS5hdXRoLnNpZ25PdXQoKTtcbiAgICBzZXRBY2NvdW50KG51bGwpO1xuICB9LCBbXSk7XG5cbiAgY29uc3QgcmVzZXRQYXNzd29yZCA9IHVzZUNhbGxiYWNrKGFzeW5jIChlbWFpbDogc3RyaW5nKSA9PiB7XG4gICAgaWYgKCFzdXBhYmFzZSkgdGhyb3cgbmV3IEVycm9yKFwiUGFzc3dvcmQgcmVzZXQgbmVlZHMgdGhlIGRhdGFiYXNlLlwiKTtcbiAgICBjb25zdCB7IGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZS5hdXRoLnJlc2V0UGFzc3dvcmRGb3JFbWFpbChlbWFpbCwge1xuICAgICAgcmVkaXJlY3RUbzogYCR7d2luZG93LmxvY2F0aW9uLm9yaWdpbn0vYWNjb3VudGAsXG4gICAgfSk7XG4gICAgaWYgKGVycm9yKSB0aHJvdyBuZXcgRXJyb3IoZXJyb3IubWVzc2FnZSk7XG4gIH0sIFtdKTtcblxuICBjb25zdCB1cGRhdGVQcm9maWxlID0gdXNlQ2FsbGJhY2soXG4gICAgYXN5bmMgKHBhdGNoOiBQYXJ0aWFsPFBpY2s8QWNjb3VudCwgXCJuYW1lXCIgfCBcInBob25lXCI+PikgPT4ge1xuICAgICAgaWYgKCFzdXBhYmFzZSB8fCAhYWNjb3VudCkgcmV0dXJuO1xuICAgICAgY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICAgICAgLmZyb20oXCJwcm9maWxlc1wiKVxuICAgICAgICAudXBkYXRlKHsgbmFtZTogcGF0Y2gubmFtZSwgcGhvbmU6IHBhdGNoLnBob25lIH0pXG4gICAgICAgIC5lcShcImlkXCIsIGFjY291bnQuaWQpXG4gICAgICAgIC5zZWxlY3QoKVxuICAgICAgICAuc2luZ2xlKCk7XG5cbiAgICAgIGlmIChlcnJvcikgdGhyb3cgbmV3IEVycm9yKGVycm9yLm1lc3NhZ2UpO1xuICAgICAgc2V0QWNjb3VudCh0b0FjY291bnQoZGF0YSBhcyBQcm9maWxlUm93KSk7XG4gICAgfSxcbiAgICBbYWNjb3VudF0sXG4gICk7XG5cbiAgY29uc3QgZW5hYmxlT3duZXJUb29scyA9IHVzZUNhbGxiYWNrKGFzeW5jICgpID0+IHtcbiAgICBpZiAoIXN1cGFiYXNlIHx8ICFhY2NvdW50KSByZXR1cm47XG4gICAgY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICAgIC5mcm9tKFwicHJvZmlsZXNcIilcbiAgICAgIC51cGRhdGUoeyBjYW5fb3duOiB0cnVlIH0pXG4gICAgICAuZXEoXCJpZFwiLCBhY2NvdW50LmlkKVxuICAgICAgLnNlbGVjdCgpXG4gICAgICAuc2luZ2xlKCk7XG5cbiAgICBpZiAoZXJyb3IpIHRocm93IG5ldyBFcnJvcihlcnJvci5tZXNzYWdlKTtcbiAgICBzZXRBY2NvdW50KHRvQWNjb3VudChkYXRhIGFzIFByb2ZpbGVSb3cpKTtcbiAgfSwgW2FjY291bnRdKTtcblxuICBjb25zdCByZWZyZXNoQWNjb3VudCA9IHVzZUNhbGxiYWNrKGFzeW5jICgpID0+IHtcbiAgICBpZiAoc2Vzc2lvbj8udXNlcikgYXdhaXQgbG9hZFByb2ZpbGUoc2Vzc2lvbi51c2VyLmlkKTtcbiAgfSwgW3Nlc3Npb24sIGxvYWRQcm9maWxlXSk7XG5cbiAgY29uc3QgdmFsdWUgPSB1c2VNZW1vPEF1dGhTdGF0ZT4oXG4gICAgKCkgPT4gKHtcbiAgICAgIHJlYWR5LFxuICAgICAgY29uZmlndXJlZDogaXNSZW1vdGUsXG4gICAgICBzZXNzaW9uLFxuICAgICAgYWNjb3VudCxcbiAgICAgIHNpZ25VcCxcbiAgICAgIHNpZ25JbixcbiAgICAgIHNpZ25PdXQsXG4gICAgICByZXNldFBhc3N3b3JkLFxuICAgICAgdXBkYXRlUHJvZmlsZSxcbiAgICAgIGVuYWJsZU93bmVyVG9vbHMsXG4gICAgICByZWZyZXNoQWNjb3VudCxcbiAgICB9KSxcbiAgICBbcmVhZHksIHNlc3Npb24sIGFjY291bnQsIHNpZ25VcCwgc2lnbkluLCBzaWduT3V0LCByZXNldFBhc3N3b3JkLCB1cGRhdGVQcm9maWxlLCBlbmFibGVPd25lclRvb2xzLCByZWZyZXNoQWNjb3VudF0sXG4gICk7XG5cbiAgcmV0dXJuIDxDdHguUHJvdmlkZXIgdmFsdWU9e3ZhbHVlfT57Y2hpbGRyZW59PC9DdHguUHJvdmlkZXI+O1xufVxuXG5leHBvcnQgZnVuY3Rpb24gdXNlQXV0aCgpOiBBdXRoU3RhdGUge1xuICBjb25zdCBjdHggPSB1c2VDb250ZXh0KEN0eCk7XG4gIGlmICghY3R4KSB0aHJvdyBuZXcgRXJyb3IoXCJ1c2VBdXRoIG11c3QgYmUgdXNlZCBpbnNpZGUgQXV0aFByb3ZpZGVyXCIpO1xuICByZXR1cm4gY3R4O1xufVxuIl0sImZpbGUiOiJEOi9JMkkgUHJvamVjdCAtIEhhYml0by9BcHAgRm9sZGVyL2hhYml0by9zcmMvaG9va3MvdXNlQXV0aC50c3gifQ==