import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/Skeleton.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=9ceb86a3"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("D:/I2I Project - Habito/App Folder/habito/src/components/ui/Skeleton.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { cn } from "/src/lib/cn.ts";
export function Skeleton({ className }) {
  return /* @__PURE__ */ jsxDEV("div", { className: cn("animate-pulse rounded-lg bg-ivory-deep", className), "aria-hidden": true }, void 0, false, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/ui/Skeleton.tsx",
    lineNumber: 23,
    columnNumber: 10
  }, this);
}
_c = Skeleton;
export function SpaceCardSkeleton() {
  return /* @__PURE__ */ jsxDEV("div", { className: "overflow-hidden rounded-card bg-surface ring-1 ring-hairline", children: [
    /* @__PURE__ */ jsxDEV(Skeleton, { className: "aspect-4/3 rounded-none" }, void 0, false, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/ui/Skeleton.tsx",
      lineNumber: 30,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "space-y-2 p-3.5", children: [
      /* @__PURE__ */ jsxDEV(Skeleton, { className: "h-5 w-24" }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/ui/Skeleton.tsx",
        lineNumber: 32,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Skeleton, { className: "h-4 w-40" }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/ui/Skeleton.tsx",
        lineNumber: 33,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Skeleton, { className: "h-3 w-28" }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/ui/Skeleton.tsx",
        lineNumber: 34,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Skeleton, { className: "h-7 w-full" }, void 0, false, {
        fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/ui/Skeleton.tsx",
        lineNumber: 35,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/ui/Skeleton.tsx",
      lineNumber: 31,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/ui/Skeleton.tsx",
    lineNumber: 29,
    columnNumber: 5
  }, this);
}
_c2 = SpaceCardSkeleton;
var _c, _c2;
$RefreshReg$(_c, "Skeleton");
$RefreshReg$(_c2, "SpaceCardSkeleton");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/I2I Project - Habito/App Folder/habito/src/components/ui/Skeleton.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/I2I Project - Habito/App Folder/habito/src/components/ui/Skeleton.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBR1M7Ozs7Ozs7Ozs7Ozs7Ozs7QUFIVCxTQUFTQSxVQUFVO0FBRVosZ0JBQVNDLFNBQVMsRUFBRUMsVUFBa0MsR0FBRztBQUM5RCxTQUFPLHVCQUFDLFNBQUksV0FBV0YsR0FBRywwQ0FBMENFLFNBQVMsR0FBRyxlQUFXLFFBQXBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBb0Y7QUFDN0Y7QUFFQUMsS0FKZ0JGO0FBS1QsZ0JBQVNHLG9CQUFvQjtBQUNsQyxTQUNFLHVCQUFDLFNBQUksV0FBVSxnRUFDYjtBQUFBLDJCQUFDLFlBQVMsV0FBVSw2QkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE2QztBQUFBLElBQzdDLHVCQUFDLFNBQUksV0FBVSxtQkFDYjtBQUFBLDZCQUFDLFlBQVMsV0FBVSxjQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQThCO0FBQUEsTUFDOUIsdUJBQUMsWUFBUyxXQUFVLGNBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBOEI7QUFBQSxNQUM5Qix1QkFBQyxZQUFTLFdBQVUsY0FBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE4QjtBQUFBLE1BQzlCLHVCQUFDLFlBQVMsV0FBVSxnQkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFnQztBQUFBLFNBSmxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FLQTtBQUFBLE9BUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVFBO0FBRUo7QUFBQ0MsTUFaZUQ7QUFBaUIsSUFBQUQsSUFBQUU7QUFBQSxhQUFBRixJQUFBO0FBQUEsYUFBQUUsS0FBQSIsIm5hbWVzIjpbImNuIiwiU2tlbGV0b24iLCJjbGFzc05hbWUiLCJfYyIsIlNwYWNlQ2FyZFNrZWxldG9uIiwiX2MyIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlNrZWxldG9uLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBjbiB9IGZyb20gXCJAL2xpYi9jblwiO1xuXG5leHBvcnQgZnVuY3Rpb24gU2tlbGV0b24oeyBjbGFzc05hbWUgfTogeyBjbGFzc05hbWU/OiBzdHJpbmcgfSkge1xuICByZXR1cm4gPGRpdiBjbGFzc05hbWU9e2NuKFwiYW5pbWF0ZS1wdWxzZSByb3VuZGVkLWxnIGJnLWl2b3J5LWRlZXBcIiwgY2xhc3NOYW1lKX0gYXJpYS1oaWRkZW4gLz47XG59XG5cbi8qKiBNYXRjaGVzIFNwYWNlQ2FyZCdzIGZvb3RwcmludCBzbyBncmlkcyBhbmQgcmFpbHMgZG9uJ3QganVtcCB3aGlsZSBsb2FkaW5nLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIFNwYWNlQ2FyZFNrZWxldG9uKCkge1xuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwib3ZlcmZsb3ctaGlkZGVuIHJvdW5kZWQtY2FyZCBiZy1zdXJmYWNlIHJpbmctMSByaW5nLWhhaXJsaW5lXCI+XG4gICAgICA8U2tlbGV0b24gY2xhc3NOYW1lPVwiYXNwZWN0LTQvMyByb3VuZGVkLW5vbmVcIiAvPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTIgcC0zLjVcIj5cbiAgICAgICAgPFNrZWxldG9uIGNsYXNzTmFtZT1cImgtNSB3LTI0XCIgLz5cbiAgICAgICAgPFNrZWxldG9uIGNsYXNzTmFtZT1cImgtNCB3LTQwXCIgLz5cbiAgICAgICAgPFNrZWxldG9uIGNsYXNzTmFtZT1cImgtMyB3LTI4XCIgLz5cbiAgICAgICAgPFNrZWxldG9uIGNsYXNzTmFtZT1cImgtNyB3LWZ1bGxcIiAvPlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXSwiZmlsZSI6IkQ6L0kySSBQcm9qZWN0IC0gSGFiaXRvL0FwcCBGb2xkZXIvaGFiaXRvL3NyYy9jb21wb25lbnRzL3VpL1NrZWxldG9uLnRzeCJ9