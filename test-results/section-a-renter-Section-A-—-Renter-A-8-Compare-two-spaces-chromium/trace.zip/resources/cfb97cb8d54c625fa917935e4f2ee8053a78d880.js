import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/Modal.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=9ceb86a3"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("D:/I2I Project - Habito/App Folder/habito/src/components/ui/Modal.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9ceb86a3"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useRef = __vite__cjsImport3_react["useRef"];
import __vite__cjsImport4_reactDom from "/node_modules/.vite/deps/react-dom.js?v=9ceb86a3"; const createPortal = __vite__cjsImport4_reactDom["createPortal"];
import { X } from "/node_modules/.vite/deps/lucide-react.js?v=9ceb86a3";
export function Modal({
  open,
  onClose,
  title,
  children,
  footer
}) {
  _s();
  const panelRef = useRef(null);
  useEffect(() => {
    if (!open) return;
    const onKey = (e) => {
      if (e.key === "Escape") onClose();
    };
    document.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    panelRef.current?.focus();
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [open, onClose]);
  if (!open) return null;
  return createPortal(
    /* @__PURE__ */ jsxDEV("div", { className: "fade fixed inset-0 z-50 flex items-end justify-center sm:items-center", children: [
      /* @__PURE__ */ jsxDEV(
        "div",
        {
          className: "absolute inset-0 bg-ink/50",
          onClick: onClose,
          "aria-hidden": true
        },
        void 0,
        false,
        {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/ui/Modal.tsx",
          lineNumber: 63,
          columnNumber: 7
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        "div",
        {
          ref: panelRef,
          role: "dialog",
          "aria-modal": "true",
          "aria-label": title,
          tabIndex: -1,
          className: "sheet relative max-h-[88vh] w-full overflow-y-auto overscroll-contain rounded-t-card bg-surface pb-[env(safe-area-inset-bottom)] sm:max-w-lg sm:rounded-card sm:pb-0",
          children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-start justify-between gap-4 border-b border-hairline px-5 py-4", children: [
              /* @__PURE__ */ jsxDEV("h2", { className: "font-display text-lg font-bold text-ink", children: title }, void 0, false, {
                fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/ui/Modal.tsx",
                lineNumber: 77,
                columnNumber: 11
              }, this),
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "button",
                  onClick: onClose,
                  "aria-label": "Close",
                  className: "-m-1 rounded p-1 text-muted hover:bg-ivory-deep hover:text-ink",
                  children: /* @__PURE__ */ jsxDEV(X, { size: 18 }, void 0, false, {
                    fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/ui/Modal.tsx",
                    lineNumber: 84,
                    columnNumber: 13
                  }, this)
                },
                void 0,
                false,
                {
                  fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/ui/Modal.tsx",
                  lineNumber: 78,
                  columnNumber: 11
                },
                this
              )
            ] }, void 0, true, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/ui/Modal.tsx",
              lineNumber: 76,
              columnNumber: 9
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "px-5 py-4", children }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/ui/Modal.tsx",
              lineNumber: 87,
              columnNumber: 9
            }, this),
            footer && /* @__PURE__ */ jsxDEV("div", { className: "border-t border-hairline px-5 py-4", children: footer }, void 0, false, {
              fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/ui/Modal.tsx",
              lineNumber: 88,
              columnNumber: 20
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/ui/Modal.tsx",
          lineNumber: 68,
          columnNumber: 7
        },
        this
      )
    ] }, void 0, true, {
      fileName: "D:/I2I Project - Habito/App Folder/habito/src/components/ui/Modal.tsx",
      lineNumber: 62,
      columnNumber: 5
    }, this),
    document.body
  );
}
_s(Modal, "2Tru+9IeUxoEksoM8eA1LGy5uk8=");
_c = Modal;
var _c;
$RefreshReg$(_c, "Modal");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/I2I Project - Habito/App Folder/habito/src/components/ui/Modal.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/I2I Project - Habito/App Folder/habito/src/components/ui/Modal.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMkNNOzs7Ozs7Ozs7Ozs7Ozs7OztBQTNDTixTQUFTQSxXQUFXQyxjQUFjO0FBQ2xDLFNBQVNDLG9CQUFvQjtBQUU3QixTQUFTQyxTQUFTO0FBR1gsZ0JBQVNDLE1BQU07QUFBQSxFQUNwQkM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFPRixHQUFHO0FBQUFDLEtBQUE7QUFDRCxRQUFNQyxXQUFXVixPQUF1QixJQUFJO0FBRTVDRCxZQUFVLE1BQU07QUFDZCxRQUFJLENBQUNLLEtBQU07QUFDWCxVQUFNTyxRQUFRQSxDQUFDQyxNQUFxQjtBQUNsQyxVQUFJQSxFQUFFQyxRQUFRLFNBQVVSLFNBQVE7QUFBQSxJQUNsQztBQUNBUyxhQUFTQyxpQkFBaUIsV0FBV0osS0FBSztBQUMxQ0csYUFBU0UsS0FBS0MsTUFBTUMsV0FBVztBQUMvQlIsYUFBU1MsU0FBU0MsTUFBTTtBQUN4QixXQUFPLE1BQU07QUFDWE4sZUFBU08sb0JBQW9CLFdBQVdWLEtBQUs7QUFDN0NHLGVBQVNFLEtBQUtDLE1BQU1DLFdBQVc7QUFBQSxJQUNqQztBQUFBLEVBQ0YsR0FBRyxDQUFDZCxNQUFNQyxPQUFPLENBQUM7QUFFbEIsTUFBSSxDQUFDRCxLQUFNLFFBQU87QUFNbEIsU0FBT0g7QUFBQUEsSUFDTCx1QkFBQyxTQUFJLFdBQVUseUVBQ2I7QUFBQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsV0FBVTtBQUFBLFVBQ1YsU0FBU0k7QUFBQUEsVUFDVCxlQUFXO0FBQUE7QUFBQSxRQUhiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUdhO0FBQUEsTUFFYjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsS0FBS0s7QUFBQUEsVUFDTCxNQUFLO0FBQUEsVUFDTCxjQUFXO0FBQUEsVUFDWCxjQUFZSjtBQUFBQSxVQUNaLFVBQVU7QUFBQSxVQUNWLFdBQVU7QUFBQSxVQUVWO0FBQUEsbUNBQUMsU0FBSSxXQUFVLDZFQUNiO0FBQUEscUNBQUMsUUFBRyxXQUFVLDJDQUEyQ0EsbUJBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQStEO0FBQUEsY0FDL0Q7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLFNBQVNEO0FBQUFBLGtCQUNULGNBQVc7QUFBQSxrQkFDWCxXQUFVO0FBQUEsa0JBRVYsaUNBQUMsS0FBRSxNQUFNLE1BQVQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBWTtBQUFBO0FBQUEsZ0JBTmQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBT0E7QUFBQSxpQkFURjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVVBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsYUFBYUUsWUFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBcUM7QUFBQSxZQUNwQ0MsVUFBVSx1QkFBQyxTQUFJLFdBQVUsc0NBQXNDQSxvQkFBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNEQ7QUFBQTtBQUFBO0FBQUEsUUFwQnpFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQXFCQTtBQUFBLFNBM0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E0QkE7QUFBQSxJQUNBTSxTQUFTRTtBQUFBQSxFQUNYO0FBQ0Y7QUFBQ1AsR0FuRWVOLE9BQUs7QUFBQSxLQUFMQTtBQUFLLElBQUFtQjtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJ1c2VFZmZlY3QiLCJ1c2VSZWYiLCJjcmVhdGVQb3J0YWwiLCJYIiwiTW9kYWwiLCJvcGVuIiwib25DbG9zZSIsInRpdGxlIiwiY2hpbGRyZW4iLCJmb290ZXIiLCJfcyIsInBhbmVsUmVmIiwib25LZXkiLCJlIiwia2V5IiwiZG9jdW1lbnQiLCJhZGRFdmVudExpc3RlbmVyIiwiYm9keSIsInN0eWxlIiwib3ZlcmZsb3ciLCJjdXJyZW50IiwiZm9jdXMiLCJyZW1vdmVFdmVudExpc3RlbmVyIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiTW9kYWwudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUVmZmVjdCwgdXNlUmVmIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBjcmVhdGVQb3J0YWwgfSBmcm9tIFwicmVhY3QtZG9tXCI7XG5pbXBvcnQgdHlwZSB7IFJlYWN0Tm9kZSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgWCB9IGZyb20gXCJsdWNpZGUtcmVhY3RcIjtcblxuLyoqIE1pbmltYWwgYWNjZXNzaWJsZSBkaWFsb2cuIExhdGVyIHBoYXNlcyByZXVzZSBpdCBmb3IgaW5xdWlyeSBhbmQgZmlsdGVycy4gKi9cbmV4cG9ydCBmdW5jdGlvbiBNb2RhbCh7XG4gIG9wZW4sXG4gIG9uQ2xvc2UsXG4gIHRpdGxlLFxuICBjaGlsZHJlbixcbiAgZm9vdGVyLFxufToge1xuICBvcGVuOiBib29sZWFuO1xuICBvbkNsb3NlOiAoKSA9PiB2b2lkO1xuICB0aXRsZTogc3RyaW5nO1xuICBjaGlsZHJlbjogUmVhY3ROb2RlO1xuICBmb290ZXI/OiBSZWFjdE5vZGU7XG59KSB7XG4gIGNvbnN0IHBhbmVsUmVmID0gdXNlUmVmPEhUTUxEaXZFbGVtZW50PihudWxsKTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmICghb3BlbikgcmV0dXJuO1xuICAgIGNvbnN0IG9uS2V5ID0gKGU6IEtleWJvYXJkRXZlbnQpID0+IHtcbiAgICAgIGlmIChlLmtleSA9PT0gXCJFc2NhcGVcIikgb25DbG9zZSgpO1xuICAgIH07XG4gICAgZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcihcImtleWRvd25cIiwgb25LZXkpO1xuICAgIGRvY3VtZW50LmJvZHkuc3R5bGUub3ZlcmZsb3cgPSBcImhpZGRlblwiO1xuICAgIHBhbmVsUmVmLmN1cnJlbnQ/LmZvY3VzKCk7XG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIGRvY3VtZW50LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJrZXlkb3duXCIsIG9uS2V5KTtcbiAgICAgIGRvY3VtZW50LmJvZHkuc3R5bGUub3ZlcmZsb3cgPSBcIlwiO1xuICAgIH07XG4gIH0sIFtvcGVuLCBvbkNsb3NlXSk7XG5cbiAgaWYgKCFvcGVuKSByZXR1cm4gbnVsbDtcblxuICAvLyBSZW5kZXJlZCBpbnRvIDxib2R5Pi4gSW5zaWRlIGEgc2Nyb2xsaW5nIG9yIHRyYW5zZm9ybWVkIGFuY2VzdG9yIOKAlCB0aGVcbiAgLy8gc3RpY2t5IGZpbHRlciBwYW5lbCwgZm9yIG9uZSDigJQgYSBmaXhlZCBlbGVtZW50IGlzIHBvc2l0aW9uZWQgYWdhaW5zdCB0aGF0XG4gIC8vIGFuY2VzdG9yIGluc3RlYWQgb2YgdGhlIHZpZXdwb3J0LCB3aGljaCBpcyB3aGF0IHB1dCB0aGUgYXJlYSBwaWNrZXIgYmVsb3dcbiAgLy8gdGhlIHJlc3VsdHMgcmF0aGVyIHRoYW4gb3ZlciB0aGVtLlxuICByZXR1cm4gY3JlYXRlUG9ydGFsKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZmFkZSBmaXhlZCBpbnNldC0wIHotNTAgZmxleCBpdGVtcy1lbmQganVzdGlmeS1jZW50ZXIgc206aXRlbXMtY2VudGVyXCI+XG4gICAgICA8ZGl2XG4gICAgICAgIGNsYXNzTmFtZT1cImFic29sdXRlIGluc2V0LTAgYmctaW5rLzUwXCJcbiAgICAgICAgb25DbGljaz17b25DbG9zZX1cbiAgICAgICAgYXJpYS1oaWRkZW5cbiAgICAgIC8+XG4gICAgICA8ZGl2XG4gICAgICAgIHJlZj17cGFuZWxSZWZ9XG4gICAgICAgIHJvbGU9XCJkaWFsb2dcIlxuICAgICAgICBhcmlhLW1vZGFsPVwidHJ1ZVwiXG4gICAgICAgIGFyaWEtbGFiZWw9e3RpdGxlfVxuICAgICAgICB0YWJJbmRleD17LTF9XG4gICAgICAgIGNsYXNzTmFtZT1cInNoZWV0IHJlbGF0aXZlIG1heC1oLVs4OHZoXSB3LWZ1bGwgb3ZlcmZsb3cteS1hdXRvIG92ZXJzY3JvbGwtY29udGFpbiByb3VuZGVkLXQtY2FyZCBiZy1zdXJmYWNlIHBiLVtlbnYoc2FmZS1hcmVhLWluc2V0LWJvdHRvbSldIHNtOm1heC13LWxnIHNtOnJvdW5kZWQtY2FyZCBzbTpwYi0wXCJcbiAgICAgID5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLXN0YXJ0IGp1c3RpZnktYmV0d2VlbiBnYXAtNCBib3JkZXItYiBib3JkZXItaGFpcmxpbmUgcHgtNSBweS00XCI+XG4gICAgICAgICAgPGgyIGNsYXNzTmFtZT1cImZvbnQtZGlzcGxheSB0ZXh0LWxnIGZvbnQtYm9sZCB0ZXh0LWlua1wiPnt0aXRsZX08L2gyPlxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgb25DbGljaz17b25DbG9zZX1cbiAgICAgICAgICAgIGFyaWEtbGFiZWw9XCJDbG9zZVwiXG4gICAgICAgICAgICBjbGFzc05hbWU9XCItbS0xIHJvdW5kZWQgcC0xIHRleHQtbXV0ZWQgaG92ZXI6YmctaXZvcnktZGVlcCBob3Zlcjp0ZXh0LWlua1wiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgPFggc2l6ZT17MTh9IC8+XG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTUgcHktNFwiPntjaGlsZHJlbn08L2Rpdj5cbiAgICAgICAge2Zvb3RlciAmJiA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlci10IGJvcmRlci1oYWlybGluZSBweC01IHB5LTRcIj57Zm9vdGVyfTwvZGl2Pn1cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PixcbiAgICBkb2N1bWVudC5ib2R5LFxuICApO1xufVxuIl0sImZpbGUiOiJEOi9JMkkgUHJvamVjdCAtIEhhYml0by9BcHAgRm9sZGVyL2hhYml0by9zcmMvY29tcG9uZW50cy91aS9Nb2RhbC50c3gifQ==